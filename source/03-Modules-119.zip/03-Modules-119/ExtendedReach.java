package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.ExtendedTargetingEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.ObjectIterable;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class ExtendedReach extends Module {
   private FloatSetting a;
   private MultiModeSetting c;
   private BooleanSetting d;
   public static ExtendedReach e;
   private int f = -1;
   private int g = 0;
   private static final long k = 70703755291335L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[121];
   private static final String[] q = new String[121];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Spear;
      return Set.of(var4);
   }

   public ExtendedReach() {
      e = this;
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 63152326138861L ^ 132609891540635L;
      int var6 = Event.bReturningInt();
      int var18 = var6;
      ExtendedReach var17 = this;
      ExtendedReach var16 = var17;
      ExtendedReach var12 = var17;
      if (var18 == 0) {
         int var19 = var12.g;
         if (var19 == 0) {
            int var21 = var6;
            int var20 = this.f;
            int var15 = var20;
            int var13 = var20;
            if (var21 == 0) {
               int var22 = var13;
               int var14 = var22;
               
               if (var23 == var24) {
                  return;
               }

               int var25 = this.f;
               var15 = var25;
            }

            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var15;
            Object[] var11 = var10003;
            InventoryUtil.aReturningVoid(var11);
            this.f = -1;
            int var26 = var6;
            if (var26 == 0) {
               return;
            }
         }

         ExtendedReach var27 = this;
         var16 = var27;
      }

      var16.g--;
   }

   @EventListener
   public void a(ExtendedTargetingEvent var1) {
      long var10001 = 81599091892436L ^ 65188131317547L;
      Object[] var7 = new Object[]{124790535604223L};
      ExtendedReach var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 89345901427480L ^ 35448399117543L;
      Object[] var7 = new Object[]{124790535604223L};
      ExtendedReach var6 = this;
      var6.jReturningVoid(var7);
   }

   public void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 70703755291335L ^ var2;
      long var4 = var2 ^ 129248782265721L;
      long var6 = var2 ^ 98559078867320L;
      long var8 = var2 ^ 31006336395831L;
      long var10 = var2 ^ 123993041528910L;
      long var12 = var2 ^ 50117779975128L;
      int var14 = Event.cReturningInt();
      Object[] var16 = new Object[]{var6};
      Entity var49 = aReturningEntity(var16);
      if (var49 != null) {
         Random var18 = RandomUtil.a;
         float var10000 = var18.nextFloat() * 100.0F;
         FloatSetting var19 = this.a;
         Float var20 = (Float)var19.aReturningObject();
         float var73;
         int var72 = (var73 = var10000 - var20) == 0.0F ? 0 : (var73 < 0.0F ? -1 : 1);
         int var51 = var14;
         int var50 = var72;
         int var38 = var50;
         int var37 = var50;
         if (var51 != 0) {
            int var52 = var37;
            if (var52 > 0) {
               this.g = 1;
            }

            var38 = this.g;
         }

         int var54 = var14;
         int var53 = var38;
         int var40 = var53;
         int var39 = var53;
         if (var54 != 0) {
            int var55 = var39;
            if (var55 > 0) {
               return;
            }

            MinecraftClient var24 = b;
            ClientPlayerEntity var25 = var24.player;
            double var74;
            var40 = (var74 = var25.fallDistance - 1.5) == 0.0 ? 0 : (var74 < 0.0 ? -1 : 1);
         }

         int var57 = var14;
         int var56 = var40;
         int var42 = var56;
         int var41 = var56;
         if (var57 != 0) {
            int var58 = var41;
            if (var58 > 0) {
               return;
            }

            var42 = this.f;
         }

         int var60 = var14;
         int var59 = var42;
         int var44 = var59;
         int var43 = var59;
         if (var60 != 0) {
            
            if (var61 != var62) {
               return;
            }

            Object[] var30 = new Object[]{var12};
            ExtendedReach var29 = this;
            var44 = (((var29.dReturningBoolean(var30)) ? 1 : 0));
         }

         int var64 = var14;
         int var63 = var44;
         int var46 = var63;
         int var45 = var63;
         if (var64 != 0) {
            int var65 = var45;
            if (var65 == 0) {
               return;
            }

            Object[] var32 = new Object[]{var8};
            this.f = InventoryUtil.aReturningInt(var32);
            Object[] var33 = new Object[]{var4};
            var46 = aReturningInt(var33);
         }

         int var15 = var46;
         int var67 = var14;
         int var66 = var15;
         int var48 = var66;
         int var47 = var66;
         if (var67 != 0) {
            
            if (var68 == var69) {
               return;
            }

            int var70 = var15;
            var48 = var70;
         }

         Object[] var10003 = new Object[]{null, var10};
         var10003[0] = var48;
         Object[] var36 = var10003;
         InventoryUtil.aReturningVoid(var36);
         this.g = 1;
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      label61: {
         long var2 = (Long)var1[0];
         var2 = 70703755291335L ^ var2;
         long var4 = var2 ^ 92859345793097L;
         long var6 = var2 ^ 17259956874561L;
         long var8 = var2 ^ 30861708588617L;
         long var10 = var2 ^ 85063019606939L;
         int var12 = Event.bReturningInt();
         MultiModeSetting var10000 = this.c;
         short var10001 = 18054;
         long var10002 = 109859414639148331L ^ var2;
         Object[] var14 = new Object[]{"Sword", var8};
         MultiModeSetting var13 = var10000;
         byte var75 = ((byte)((var13.aReturningBoolean(var14)) ? 1 : 0));
         int var51 = var12;
         byte var50 = var75;
         byte var40 = var50;
         byte var37 = var50;
         if (var51 == 0) {
            byte var52 = var37;
            if (var52 != 0) {
               MinecraftClient var16 = b;
               ClientPlayerEntity var17 = var16.player;
               Object[] var18 = new Object[]{var17.getMainHandStack(), var10};
               byte var76 = ((byte)((InventoryUtil.aReturningBoolean(var18)) ? 1 : 0));
               int var54 = var12;
               byte var53 = var76;
               byte var48 = var53;
               byte var38 = var53;
               if (var54 != 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var48);
               }

               byte var55 = var38;
               byte var39 = var55;
               byte var56 = var39;
               if (var56 != 0) {
                  break label61;
               }
            }

            var10000 = this.c;
            var10001 = 7410;
            var10002 = 356261755767990109L ^ var2;
            Object[] var22 = new Object[]{"Axe", var8};
            MultiModeSetting var21 = var10000;
            byte var57 = ((byte)((var21.aReturningBoolean(var22)) ? 1 : 0));
            var40 = var57;
         }

         int var59 = var12;
         byte var58 = var40;
         byte var44 = var58;
         byte var41 = var58;
         if (var59 == 0) {
            byte var60 = var41;
            if (var60 != 0) {
               MinecraftClient var25 = b;
               ClientPlayerEntity var26 = var25.player;
               Object[] var27 = new Object[]{var26.getMainHandStack(), var4};
               byte var78 = ((byte)((InventoryUtil.bReturningBoolean(var27)) ? 1 : 0));
               int var62 = var12;
               byte var61 = var78;
               byte var84 = var61;
               byte var42 = var61;
               if (var62 != 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var84);
               }

               byte var63 = var42;
               byte var43 = var63;
               byte var64 = var43;
               if (var64 != 0) {
                  break label61;
               }
            }

            var10000 = this.c;
            var10001 = 11104;
            var10002 = 4208938506447687886L ^ var2;
            Object[] var31 = new Object[]{"Mace", var8};
            MultiModeSetting var30 = var10000;
            byte var65 = ((byte)((var30.aReturningBoolean(var31)) ? 1 : 0));
            var44 = var65;
         }

         int var67 = var12;
         byte var66 = var44;
         byte var46 = var66;
         byte var45 = var66;
         if (var67 == 0) {
            byte var68 = var45;
            if (var68 == 0) {
               return false;
            }

            MinecraftClient var34 = b;
            ClientPlayerEntity var35 = var34.player;
            Object[] var36 = new Object[]{var35.getMainHandStack(), var6};
            byte var69 = ((byte)((InventoryUtil.o(var36)) ? 1 : 0));
            var46 = var69;
         }

         int var71 = var12;
         byte var70 = var46;
         byte var85 = var70;
         byte var47 = var70;
         if (var71 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var85);
         }

         byte var72 = var47;
         if (var72 == 0) {
            return false;
         }
      }

      byte var86 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var86);
   }

   private static int aReturningInt(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 70703755291335L ^ var1;
      long var3 = var1 ^ 117920030415597L;
      int var10000 = Event.cReturningInt();
      int var5 = var10000;

      byte var27;
      while (true) {
         int var29 = (int)o;
         int var28 = var6;
         if (var28 < var29) {
            MinecraftClient var9 = b;
            ClientPlayerEntity var10 = var9.player;
            PlayerInventory var45 = var10.getInventory();
            int var12 = var6;
            PlayerInventory var11 = var45;
            ItemStack var7 = var11.getStack(var12);
            TagKey var14 = ItemTags.SPEARS;
            ItemStack var13 = var7;
            byte var46 = ((byte)((var13.isIn(var14)) ? 1 : 0));
            int var31 = var5;
            byte var30 = var46;
            var27 = var30;
            byte var18 = var30;
            if (var31 == 0) {
               break;
            }

            label57: {
               int var33 = var5;
               byte var32 = var18;
               int var21 = var32;
               byte var19 = var32;
               if (var33 != 0) {
                  byte var34 = var19;
                  byte var20 = var34;
                  byte var35 = var20;
                  if (var35 == 0) {
                     break label57;
                  }

                  Object[] var17 = new Object[]{var7, Enchantments.LUNGE, var3};
                  var21 = cReturningInt(var17);
               }

               int var24;
               label44: {
                  int var37 = var5;
                  int var36 = var21;
                  int var23 = var36;
                  int var22 = var36;
                  if (var37 != 0) {
                     int var38 = var22;
                     if (var38 != 0) {
                        var24 = 0;
                        break label44;
                     }

                     var23 = 1;
                  }

                  int var39 = var23;
                  var24 = var39;
               }

               int var8 = var24;
               int var41 = var5;
               int var40 = var8;
               int var26 = var40;
               int var25 = var40;
               if (var41 == 0) {
                  return var26;
               }

               int var42 = var25;
               if (var42 != 0) {
                  var26 = var6;
                  return var26;
               }
            }

            var6++;
            int var43 = var5;
            if (var43 != 0) {
               continue;
            }
         }

         var27 = -1;
         break;
      }

      return var27;
   }

   public static int cReturningInt(Object[] var0) {
      ItemStack var4 = (ItemStack)var0[0];
      RegistryKey var1 = (RegistryKey)var0[1];
      long var2 = (Long)var0[2];
      var2 = 70703755291335L ^ var2;
      long var5 = var2 ^ 101731480180889L;
      long var7 = var2 ^ 56469414637582L;
      int var9 = Event.bReturningInt();
      ItemStack var11 = var4;
      byte var10000 = ((byte)((var11.isEmpty()) ? 1 : 0));
      int var18 = var9;
      byte var17 = var10000;
      byte var16 = var17;
      byte var15 = var17;
      if (var18 == 0) {
         byte var19 = var15;
         if (var19 == 0) {
            Object2IntArrayMap var10 = new Object2IntArrayMap();
            Object[] var13 = new Object[]{var4, var10, var7};
            kReturningVoid(var13);
            Object[] var14 = new Object[]{var10, var1, var5};
            return dReturningInt(var14);
         }

         var16 = 0;
      }

      return var16;
   }

   public static int dReturningInt(Object[] var0) {
      Object2IntMap var2 = (Object2IntMap)var0[0];
      RegistryKey var1 = (RegistryKey)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 70703755291335L ^ var3;
      int var32 = Event.cReturningInt();
      Object2IntMap var8 = var2;
      ObjectIterable var9 = Object2IntMaps.fastIterable(var8);
      ObjectIterator var6 = var9.iterator();
      int var5 = var32;

      byte var22;
      while (true) {
         ObjectIterator var10 = var6;
         boolean var23 = ((Iterator)var10).hasNext();
         if (var23) {
            ObjectIterator var11 = var6;
            Entry var7 = (Entry)((Iterator)var11).next();
            Entry var12 = var7;
            RegistryEntry var33 = (RegistryEntry)var12.getKey();
            RegistryKey var14 = var1;
            RegistryEntry var13 = var33;
            byte var34 = ((byte)((var13.matchesKey(var14)) ? 1 : 0));
            int var25 = var5;
            byte var24 = var34;
            var22 = var24;
            byte var18 = var24;
            if (var25 == 0) {
               break;
            }

            int var27 = var5;
            byte var26 = var18;
            int var21 = var26;
            byte var19 = var26;
            if (var27 == 0) {
               return var21;
            }

            byte var28 = var19;
            byte var20 = var28;
            byte var29 = var20;
            if (var29 != 0) {
               Entry var17 = var7;
               int var30 = var17.getIntValue();
               var21 = var30;
               return var21;
            }

            int var31 = var5;
            if (var31 != 0) {
               continue;
            }
         }

         var22 = 0;
         break;
      }

      return var22;
   }

   public static void kReturningVoid(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      Object2IntMap var4 = (Object2IntMap)var0[1];
      long var2 = (Long)var0[2];
      long var10000 = 70703755291335L ^ var2;
      int var46 = Event.bReturningInt();
      Object2IntMap var9 = var4;
      var9.clear();
      int var5 = var46;
      int var36 = var5;
      ItemStack var35 = var1;
      ItemStack var31 = var35;
      ItemStack var30 = var35;
      if (var36 == 0) {
         ItemStack var10 = var30;
         boolean var37 = var10.isEmpty();
         if (var37) {
            return;
         }

         ItemStack var38 = var1;
         var31 = var38;
      }

      Set var34;
      label28: {
         int var40 = var5;
         ItemStack var39 = var31;
         ItemStack var33 = var39;
         ItemStack var32 = var39;
         if (var40 == 0) {
            ItemStack var13 = var32;
            Item var47 = var13.getItem();
            Item var42 = Items.ENCHANTED_BOOK;
            Item var41 = var47;
            if (var41 == var42) {
               ItemEnchantmentsComponent var17 = ItemEnchantmentsComponent.DEFAULT;
               ComponentType var16 = DataComponentTypes.STORED_ENCHANTMENTS;
               ItemStack var15 = var1;
               ItemEnchantmentsComponent var18 = (ItemEnchantmentsComponent)var15.getOrDefault(var16, var17);
               Set var43 = var18.getEnchantmentEntries();
               var34 = var43;
               break label28;
            }

            var33 = var1;
         }

         ItemStack var20 = var33;
         ItemEnchantmentsComponent var21 = var20.getEnchantments();
         var34 = var21.getEnchantmentEntries();
      }

      Set var6 = var34;
      Set var22 = var6;
      Iterator var7 = var22.iterator();

      int var45;
      do {
         Iterator var23 = var7;
         boolean var44 = var23.hasNext();
         if (!var44) {
            break;
         }

         Iterator var24 = var7;
         Entry var8 = (Entry)var24.next();
         Entry var25 = var8;
         RegistryEntry var10001 = (RegistryEntry)var25.getKey();
         Entry var26 = var8;
         int var29 = var26.getIntValue();
         RegistryEntry var28 = var10001;
         Object2IntMap var27 = var4;
         var27.put(var28, var29);
         var45 = var5;
      } while (var45 == 0);
   }

   public static Entity aReturningEntity(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 70703755291335L ^ var1;
      long var3 = var1 ^ 119161738258118L;
      long var5 = var1 ^ 115593862060353L;
      int var7 = Event.bReturningInt();
      ExtendedReach var13 = e;
      int var10000 = (((var13.aReturningBoolean()) ? 1 : 0));
      int var78 = var7;
      byte var77 = (byte)var10000;
      int var58 = var77;
      byte var57 = var77;
      if (var78 == 0) {
         byte var79 = var57;
         if (var79 == 0) {
            return null;
         }

         Object[] var16 = new Object[]{var3};
         var58 = aReturningInt(var16);
      }

      int var81 = var7;
      int var80 = var58;
      int var60 = var80;
      int var59 = var80;
      if (var81 == 0) {
         
         if (var82 == var83) {
            return null;
         }

         MinecraftClient var19 = b;
         float var21 = 0.0F;
         ClientPlayerEntity var20 = var19.player;
         float var116;
         var60 = (var116 = var20.getAttackCooldownProgress(var21) - 1.0F) == 0.0F ? 0 : (var116 < 0.0F ? -1 : 1);
      }

      HitResult var64;
      label98: {
         int var85 = var7;
         int var84 = var60;
         int var63 = var84;
         int var61 = var84;
         if (var85 == 0) {
            int var86 = var61;
            if (var86 < 0) {
               return null;
            }

            MinecraftClient var24 = b;
            int var88 = var7;
            HitResult var87 = var24.crosshairTarget;
            var64 = var87;
            HitResult var62 = var87;
            if (var88 != 0) {
               break label98;
            }

            byte var89 = ((byte)((var62 instanceof EntityHitResult) ? 1 : 0));
            var63 = var89;
         }

         int var90 = var63;
         if (var90 != 0) {
            return null;
         }

         MinecraftClient var27 = b;
         ClientPlayerEntity var28 = var27.player;
         float var10002 = var28.getYaw();
         MinecraftClient var29 = b;
         ClientPlayerEntity var30 = var29.player;
         Rotation var112 = new Rotation(var10002, var30.getPitch());
         Object[] var10004 = new Object[]{null, null, var5};
         var10004[1] = 4.75F;
         var10004[0] = var112;
         Object[] var31 = var10004;
         var64 = RotationUtil.bReturningHitResult(var31);
      }

      HitResult var8 = var64;
      int var92 = var7;
      HitResult var91 = var8;
      HitResult var66 = var91;
      HitResult var65 = var91;
      if (var92 == 0) {
         HitResult var32 = var65;
         Type var113 = var32.getType();
         Type var94 = Type.MISS;
         Type var93 = var113;
         if (var93 != var94) {
            return null;
         }

         var66 = var8;
      }

      HitResult var35 = var66;
      Vec3d var9 = var35.getPos();
      Entity var10 = null;
      MinecraftClient var36 = b;
      ClientWorld var37 = var36.world;
      Iterable var38 = var37.getEntities();
      Iterator var11 = var38.iterator();

      while (true) {
         Iterator var39 = var11;
         boolean var95 = var39.hasNext();
         if (!var95) {
            break;
         }

         Iterator var40 = var11;
         Entity var12 = (Entity)var40.next();
         MinecraftClient var41 = b;
         int var98 = var7;
         ClientPlayerEntity var97 = var41.player;
         Entity var96 = var12;
         Entity var69 = var96;
         ClientPlayerEntity var70 = var97;
         Entity var67 = var96;
         ClientPlayerEntity var68 = var97;
         if (var98 == 0) {
            ClientPlayerEntity var100 = var68;
            Entity var99 = var67;
            if (var99 == var100) {
               continue;
            }

            MinecraftClient var43 = b;
            var70 = var43.player;
            var69 = var12;
         }

         ClientPlayerEntity var45 = var70;
         Entity var44 = var69;
         float var117;
         var10000 = (var117 = var44.distanceTo((Entity)var45) - 6.0F) == 0.0F ? 0 : (var117 < 0.0F ? -1 : 1);
         int var102 = var7;
         int var101 = var10000;
         int var72 = var101;
         int var71 = var101;
         if (var102 == 0) {
            int var103 = var71;
            if (var103 > 0) {
               continue;
            }

            MinecraftClient var47 = b;
            Entity var49 = var12;
            ClientPlayerEntity var48 = var47.player;
            var72 = (((var48.canSee(var49)) ? 1 : 0));
         }

         Entity var76;
         label101: {
            int var105 = var7;
            int var104 = var72;
            int var75 = var104;
            int var73 = var104;
            if (var105 == 0) {
               int var106 = var73;
               if (var106 == 0) {
                  continue;
               }

               int var108 = var7;
               Entity var107 = var12;
               var76 = var107;
               Entity var74 = var107;
               if (var108 != 0) {
                  break label101;
               }

               Entity var51 = var74;
               Box var115 = var51.getBoundingBox();
               MinecraftClient var52 = b;
               ClientPlayerEntity var53 = var52.player;
               Vec3d var10001 = var53.getEyePos();
               Vec3d var56 = var9;
               Vec3d var55 = var10001;
               Box var54 = var115;
               byte var109 = ((byte)((var54.intersects(var55, var56)) ? 1 : 0));
               var75 = var109;
            }

            int var110 = var75;
            if (var110 == 0) {
               continue;
            }

            var76 = var12;
         }

         var10 = var76;
         break;
      }

      return var10;
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(67031156912395L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[3];
      String var11 = "\u0000î\\^\u0015L8ö¶Î\u0082¬d\u0017\u009e\u0084\u0010Í\u0089'Q\u0017Û©EEE÷\u0011\u001bÅ\"2\u0010+\u0082Í(¡\u008c§~GÈÏDJÅ.r";
      int var13 = "\u0000î\\^\u0015L8ö¶Î\u0082¬d\u0017\u009e\u0084\u0010Í\u0089'Q\u0017Û©EEE÷\u0011\u001bÅ\"2\u0010+\u0082Í(¡\u008c§~GÈÏDJÅ.r".length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = b(var15).intern();
         
         if ((var9 += var10) >= var13) {
            l = var14;
            m = new String[3];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(67031156912395L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = -4688533994492555866L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)190L,
                  (byte)48878L,
                  (byte)12513019L,
                  (byte)3203332908L,
                  (byte)820053224516L,
                  (byte)209933625476333L,
                  (byte)53743008121941389L,
                  (byte)-4688533994492555866L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            o = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6024;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eC", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eC_C0221",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 15;
            yield var15;
         }
         case 1 -> {
            byte var16 = 48;
            yield var16;
         }
         case 2 -> {
            byte var17 = 17;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 34;
            yield var20;
         }
         case 6 -> {
            byte var21 = 8;
            yield var21;
         }
         case 7 -> {
            byte var22 = 39;
            yield var22;
         }
         case 8 -> {
            byte var23 = 0;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 47;
            yield var25;
         }
         case 11 -> {
            byte var26 = 25;
            yield var26;
         }
         case 12 -> {
            byte var27 = 14;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 11;
            yield var29;
         }
         case 15 -> {
            byte var30 = 53;
            yield var30;
         }
         case 16 -> {
            byte var31 = 57;
            yield var31;
         }
         case 17 -> {
            byte var32 = 40;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 23;
            yield var34;
         }
         case 20 -> {
            byte var35 = 22;
            yield var35;
         }
         case 21 -> {
            byte var36 = 4;
            yield var36;
         }
         case 22 -> {
            byte var37 = 36;
            yield var37;
         }
         case 23 -> {
            byte var38 = 59;
            yield var38;
         }
         case 24 -> {
            byte var39 = 42;
            yield var39;
         }
         case 25 -> {
            byte var40 = 30;
            yield var40;
         }
         case 26 -> {
            byte var41 = 27;
            yield var41;
         }
         case 27 -> {
            byte var42 = 9;
            yield var42;
         }
         case 28 -> {
            byte var43 = 24;
            yield var43;
         }
         case 29 -> {
            byte var44 = 6;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 58;
            yield var47;
         }
         case 33 -> {
            byte var48 = 41;
            yield var48;
         }
         case 34 -> {
            byte var49 = 46;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 38;
            yield var51;
         }
         case 37 -> {
            byte var52 = 56;
            yield var52;
         }
         case 38 -> {
            byte var53 = 61;
            yield var53;
         }
         case 39 -> {
            byte var54 = 44;
            yield var54;
         }
         case 40 -> {
            byte var55 = 28;
            yield var55;
         }
         case 41 -> {
            byte var56 = 26;
            yield var56;
         }
         case 42 -> {
            byte var57 = 1;
            yield var57;
         }
         case 43 -> {
            byte var58 = 32;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 43;
            yield var62;
         }
         case 48 -> {
            byte var63 = 3;
            yield var63;
         }
         case 49 -> {
            byte var64 = 63;
            yield var64;
         }
         case 50 -> {
            byte var65 = 55;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 10;
            yield var67;
         }
         case 53 -> {
            byte var68 = 21;
            yield var68;
         }
         case 54 -> {
            byte var69 = 29;
            yield var69;
         }
         case 55 -> {
            byte var70 = 12;
            yield var70;
         }
         case 56 -> {
            byte var71 = 60;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 35;
            yield var73;
         }
         case 59 -> {
            byte var74 = 62;
            yield var74;
         }
         case 60 -> {
            byte var75 = 54;
            yield var75;
         }
         case 61 -> {
            byte var76 = 49;
            yield var76;
         }
         case 62 -> {
            byte var77 = 37;
            yield var77;
         }
         default -> 7;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "V:yf \u001f@:|<3\bWq\u007f:?\u001cF6h-t\nq";
      p[1] = ">78TD2K\u00173[U}*\u00198PQ'^";
      p[2] = void.class;
      q[2] = "java/lang/Void";
      p[3] = "Ed%cQ\rSd 9B\u001aD/#?N\u000eUh4(\u0005\u001cd";
      p[4] = int.class;
      q[4] = "java/lang/Integer";
      p[5] = "\u007f\u0000U:=d\u007f\u0000Bf1keKBx1~b:\u0010#i4";
      p[6] = boolean.class;
      q[6] = "java/lang/Boolean";
      p[7] = "{-\u0017~+o\u000e\r\u001cq: o\u0003\u0017z>z\u001b";
      p[8] = "$`?]\u0006\u0003/o.\u0012e\u000e:b!yP\f+q=UG\u0001";
      p[9] = "\n\u0018C_@L\n\u0018T\u0003LC\u0010ST\u001dLV\u0017\"\u0000E\u001b";
      p[10] = "ObSu\n-ObD)\u0006\"U)D7\u00067RX\u0016mQu";
      p[11] = "cz?CT8cz(\u001fX7y1(\u0001X\"~@xY\u0001h";
      p[12] = "p\u0018l\u0003?_p\u0018{_3PjS{A3Em\".\u0015d\u0004";
      p[13] = "A3\nc\u000byA3\u001d?\u0007v[x\u001d!\u0007c\\\tM|V";
      p[14] = ":FB,\u0012z:FUp\u001eu \rUn\u001e`'|\u0007:F ";
      p[15] = "@Xq+.B@Xfw\"MZ\u0013fi\"X]b06q\u001a";
      p[16] = "xXktPU\rx`{A\u001alvkpE@\u0018";
      p[17] = "A\u007f\u00130=IA\u007f\u0004l1F[4\u0004r1S\\EU*c";
      p[18] = "\u0004=(W\u0019\u0007q\u001d#X\bH\u0010\u0013(S\f\u0012d";
      p[19] = "R7;4lnY8*{\u000bv]$,7.g";
      p[20] = "o\u001atFJvq\u0012n\t-w`\tcS\u000bq";
      p[21] = "-*C\u001c~]-*T@rR7aT^rG0\u0010\u0005\u0001*\u0010 #VA`kq{\u0007";
      p[22] = float.class;
      q[22] = "java/lang/Float";
      p[23] = "O\u0000j67jO\u0000}j;eUK}t;pR:,+c";
      p[24] = "`!8\u0003nR`!/_b]zj/AbH}\u001b~\u001e;";
      p[25] = "5w-\u000fQ&5w:S])/<:M]<(Mh\u0013\u0005x";
      p[26] = "#20$pD525~cS\"y6xoG3>!o$P\u0016";
      p[27] = "\u0013\"\u001d1*'\u0013\"\nm&(\ti\ns&=\u000e\u0018_,\u007f";
      p[28] = "APSG^YWPV\u001dMN@\u001bU\u001bAZQ\\B\f\nMg";
      p[29] = "1@4(V\u000fD`?'G@%n4,C\u001aQ";
      p[30] = "\u000fEb9\u0005\u0001\u0004Jsvd\u000f\u000fAw,";
      p[31] = "]\u0007m`\u001f'('fo\u000ehI)md\n2=";
      p[32] = "0\u0005FG4K0\u0005Q\u001b8D*NQ\u00058Q-?\u000bZj\u0013";
      p[33] = "0\r$+DR0\r3wH]*F3iHH-7a2\u0010\t";
      p[34] = "\u001d\u001e4$]\r\u001d\u001e#xQ\u0002\u0007U#fQ\u0017\u0000$y9\u0000P";
      p[35] = "-\u0006\u001dK\u0010j3\u000e\u0007\u0004mz3";
      p[36] = "Y\u0013]L\u0001\u001f]\u000e]]\u001c\u001f\u001e\u0001\u0012J\u001b\u0003D\u000e\u001f\u0017\u0000\u0014Z\u0002\u0010M\u001cX\u007f\u0005\u0019\\\f\u0002\u0002.\u001dM\"\u0017@";
      p[37] = "qr.F\u0019\u0014qr9\u001a\u0015\u001bk99\u0004\u0015\u000elHc[GI";
      p[38] = "W}K\u000f&\u001cS`K\u001e;\u001c\u0010o\u0004\t<\u0000J`\tT'\u0017Tl\u0006\u000e;[qk\u000f\u001f+\u0001\f@\u000b\u000e\u0005\u0014N- \u0014<\u0007G";
      p[39] = "\u0006kR\u0019-E\u0006kEE!J\u001c E[!_\u001bQ\u0017\u000fp\u001e";
      p[40] = "i,}\u0019TDi,jEXKsgj[X^t\u0016?\u000f\u0001\u001d";
      p[41] = "84P2&m<)P#;m\u007f&\u001f4<q%)\u0012i'f;%\u001d3;*\u001e\"\u0014\"+pc\t\u00103\u0005e!3";
      p[42] = "w\u0018\u0018)\u0003:s\u0005\u00188\u001e:0\nW/\u0019&j\u0005Zr\u00021t\tU(\u001e}Q\u000e\\9\u000e'W\u0018S.\f1r\t";
      p[43] = "\u0010\"d5ig\u0014?d$tgW0+3s{\r?&nhl\u00133)4t 64 %dz0\"/2fz\u0016$";
      p[44] = "\u0002L\u0000Vxi\u0014L\u0005\fk~\u0003\u0007\u0006\ngj\u0012@\u0011\u001d,}(";
      p[45] = "gGFm\\N\u0012gMbM\u0001siFiI[\u0007";
      p[46] = "\u0000\u001d\u0003j\u001d\u0013\u0016\u001d\u00060\u000e\u0004\u0001V\u00056\u0002\u0010\u0010\u0011\u0012!I\u0000\u000b";
      p[47] = "6lq\u001a,BCLz\u0015=\r\"Bq\u001e9WV";
      p[48] = "\u0019+F5\u000eDl\u000bM:\u001f\u000b\r\u0005F1\u001bQy";
      p[49] = "^\u0007px\u001al+'{w\u000b#J)p|\u000fy>";
      p[50] = "\"5Zy\u0006FW\u0015Qv\u0017\t6\u001bZ}\u0013SB";
      p[51] = "d/mSEw\u0011\u000ff\\T8p\u0001mWPb\u0004";
      p[52] = double.class;
      q[52] = "java/lang/Double";
      p[53] = "\"Rb_\u001b\u00044Rg\u0005\b\u0013#\u0019d\u0003\u0004\u00072^s\u0014O\u0010\u0000";
      p[54] = "\u0017d\u0018CY\"\u001ck\t\f1\"\u0012d\u001a";
      p[55] = "iV*V~Q\u001cv!Yo\u001e}x*RkD\t";
      p[56] = "F}_XHrXuE\u00174fBxFT";
      p[57] = "%|\u0019N92P\\\u0012A(}1R\u0019J,'E";
      p[58] = "w&0^JU1+5\t3\u000f$%k\u0007_=r`6\\\u0003jv85XQ\u0006(#w]3";
      p[59] = " .PV/\u001cf#U\u0001VFs-\u000b\u000f:t%oWUj#p(PR2@s#S\u0018V";
      p[60] = "?\u00151\u0001\u001c&,\u0013d\u0000l,:T_\t]ixL RP4.(e\u0013\u00065.S1\b\u0003nG\u0012!\u0007\r=<F:\u0002VT";
      p[61] = "\u0010$\u007f\rDsZ7c\u001fy)F!g\u0014\u0015\u001b\u0014l9KypA%7\u0015C=\u001a`8s";
      p[62] = ")\u0005>1\u001d\u001d'\u00031\u000f\u001ee/^-l\u0015^'\u001f-wGe/\u00036o\u0012\u001b'\t1p|";
      p[63] = "1\u0017rkw'w\u001aw<\u000e}b\u0014)2bO4Vuh3\u0018a\u0011roj{b\u001aq%\u000e";
      p[64] = "(\u00069!z\u0017.\fn>\u001d\t*\u0015a)q;~V>~!l,\u0002p!|\u00148\u00168t\u001d";
      p[65] = ":\n\u001cRA\u0006+\u000f\u0017K>\u0019:\u0011\f ZNj^\u0014_\u0001C7\bp";
      p[66] = "\u0017\u0016XD\u000b\\\t\u000fB\\t^\u001a\u000fX]\u0018lJL\u0003\u000bt[\u0012\u0013FE\u0013E\u000b\t^:\u001aBLI\\Y\u0019IO\u00038";
      p[67] = "\u0019\u000f)\u0005\u0011P\u0000\u0000 \u001fqBfYc\u0006\u0012A]Q\"\u0006\t\u0013f\\2\u0004AN\\\u0011iAN(";
      p[68] = "FXg\u00137-H^h-=U@\u0003tN?nHBtUmUCFdL?.\u0017]a\u0017V";
      p[69] = "\r\u0011^05|\u0003\u0017Q\u000e=\u0004\fOE2=gI\b\u000f2T:\f\u0003\u000bg7\u007fKI\u000b\u000e";
      p[70] = "-=n\u001d](k0kJ$r~>5DH@(yh\u001c\u001d\u0017x)$LEol=l\u0019$";
      p[71] = "kC\u001b|%ieE\u0014B'\u0011m\u0018\b!-*eY\b:\u007f\u0011mE\u0013\"*oeO\u0014=D";
      p[72] = ";C\u0003^):5E\f`!B=\u0018\u0010\u0003!y5Y\u0010\u0018sBdF\n\u001e7%z_\u0010\u0006H";
      p[73] = "\bN +stRR+a\u001dz\u0003Q%<qHS\u0012x`,\u001f\t\u001c5 {f\u0011U>*\u001d";
      p[74] = "[v)\u0001s\u001eC?\"\u000b\u0015\u0006@*#\u0013i\u0000FG4\u0011y\u0015C>%\u0014r\f<";
      p[75] = "\u0005F\u0001Sd\u0006^@\u001dZ\u001fVUD\u001fXH\u0001\u000b\u0017F4pW\fF\u001cOv][Y";
      p[76] = "3Q.g KmJlbBBaLp8.p1\f+oB\u001drZq69Ii_*_y^tN-`3Mh\\\u0010";
      p[77] = "u_\u0005i$\u0000{Y\nW)xs\u0004\u00164,C{E\u0016/~xpA\u00066,\u0003$Z\u0003mE";
      p[78] = "Nk*@mk\u0015m6I\u0016;\u001ei4KAlA4o'w)O|h_khO`";
      p[79] = "&9\u0003ch?la\f)\f wh\b?[p-?Ql\f~p?\u0013n7,(8]";
      p[80] = "0h_G+\r)=YDFP&xAN*bw<\u001b\u0013{5\"|Z\u00129\bpa\u001d\u0016F\t!|\u0011O|Dz9\u001e)";
      p[81] = "\u000fe\u001cY4\u0018\toKFS\u0006\rvDQ?4Y5\u001b\u0006hc\u000e:GL.S]h\u001aNS";
      p[82] = "\"gbrBEbwx)+\u00110}oQW\u0012#oytF\u007f!;}|[\r2=(}+\u00037i-!E\u0019d8u\u0010";
      p[83] = "\"23<\u0015\u0003h!/.(Yt7+%Dk\"rv}\u0013<)-q=\u0015\u0007{uvs(\u0000s3{$\u0012M(vtB";
      p[84] = "iG>\u007f\u0018\u0003jT+.`\u0015}V\u0018r\u001c$yN$y`@n@8}\u001b\u0014uEc\u0014";
      p[85] = "q}\u0014yJ(hr\u001dc*9\u000e+^zI95#\u001fzRk\u000e.\u000fx\u001a64cT=\u0015P";
      p[86] = "\u0007)Y6&.\u0014/\f7V7\u001by^ Ve\u0019uW4(m\u0013rHZ";
      p[87] = "*~]0A}$xR\u000eL\u0005,%NmI>$dNv\u001b\u0005)tL>F?d/\t1 ";
      p[88] = "\u001dT%Bm+\u0013R*|eS\u001b\u000f6\u001feh\u0013N6\u00047S\u0018J&\u001de(LQ#F\f";
      p[89] = "\u000bM+y\u0002\u007f\rY6x\u007fx1\u000e-y\u001e{JZ6|E\u0012";
      p[90] = "~=d})br`d=P0\u0003e.8308mo8(b\u0003`\u007f:`?9-$\u007foY";
      p[91] = ":\u0015C'E\u0000p\u0006_5xZl\u0010[>\u0014h<\\\u0005hE?d\u000fU!HCd\u001dB5x[0Q\u0004=\u0007\u0000=\fRY\u001c\u000e<S_&G\u0003a\u0005;";
      p[92] = "#\u0007\u001cWs\u0012pUAU\u000eL,Z\u001bAY\u001bv\fD-`\u0012.M\u0002\u001d3@sO";
      p[93] = "xk6\bga2x*\u001aZ;.n.\u00116\t|#vGZ;<h3\u000f? ){$v";
      p[94] = "9p\u0011S\u000b[\u007f}\u0014\u0004r\nfbN\u0001%Z?6\u0015mK\\gj\u0010R\u001fUwh[";
      p[95] = "6\u001eC\u0004:~.WH\u000e\\`?/WNa85P\fC<nQH\u0002\u000f'a(PK\u0004-\u0007";
      p[96] = "[A3m=}BN:w]l$\u0017yn>l\u001f\u001f8n%>$\u0017$u=kZ\u001f.r\"\u0005";
      p[97] = "E\u0017^h5K\u001f\u000bU\"[NB\u0019_t\f\u001c\u0012O\u000b%[F@\u0011Kv0\u001c\\\u001a\u0001";
      p[98] = "F#8!\u0017P@7% jV|`>!\u000bT\u00074%$P=";
      p[99] = "\u0003rbHc.\u001fr#\u0000\u0013$\u000eg\u007f_\u007f\u0016R*$8x*\u0012t~@l>Z!\u001fSx0\fzgGlxY\u001b#Rkq\u0005!n\t.~c";
      p[100] = "b\u0006\\RQ%|\u001fFJ.'o\u001f\\KB\u0015?S\u0006\u001d.\"k\u001eL\\A>k_\u0004,";
      p[101] = "${9IEhs!s\bHTtC&\bEky<}\u0005\u0018=\u001d";
      p[102] = "8G5HH|~J0\u001f1&kDn\u0011]\u00149\u00020O1-\u007f\u00034\u0012R.t\u0000~v_:=\u0002j\u0015\\1>H\u000e";
      p[103] = "fV\u0000\u001fr\u001f [\u0005H\u000bE5U[Fgwf\u0011\u0006\u001e\u000b@=IE^l^$S]!7J \u0019]\u001bz\u0011e\u0016;";
      p[104] = "X1\u00032m^\u00037\u001f;\u0016\u000e\b3\u001d9AYVdEU(\u001fR`\u0000jn\u0012W7";
      p[105] = "qH\u001c>5+k\u001bMf\u0004$qK\tix\"w&\u000f\u007fm~3W\f0t5\r";
      p[106] = "\u0017\u00057/Vi\u000e\n>56xhS},UxS[<,N*hP8<Wx\u0013\u0004#9\f\u0011";
      p[107] = "a\\6c~BpY=z\u0001[eL\u001c|qG\f\u000b0i1]6Fk,>;";
      p[108] = "++\u001cJT:2$\u0015P4%T}VIW+ou\u0017ILyTx\u0007K\u0004$n5\\\u000e\u000bB";
      p[109] = "\u001d\u0000H\\\u0013a\u000bQ\u0013Ysc\rSTP\u000fe\u000b>CR\u001fp\u000eGRW\u0014iq";
      p[110] = "K`}EVc\rmx\u0012/9\u0018c&\u001cC\u000bK'zD/g\fg8F\u0010-\u001f{*{";
      p[111] = "R+[`P LpDl193sHx\u00016\t>\u0013=\u000eP";
      p[112] = "S\u0006M\u0002\t\u000fP\u0006I\u00186\u00181X\u001c\u0006U\u001b\nP]\u0006NI1\u000eHDY\u0015J\bB\u0013Fr";
      p[113] = "^>\u0019#?{\u001b~\u0011\"<\u0014\tc\u000fz;J\u000ec\u0015~Gz\u001e<Rw$y\u0015?\u0018\u0013";
      p[114] = "%_4\u0000hp4]!\u0006\tq-\r+U^!w\\u\u0001\tv4\u001btF4$)\\p";
      p[115] = "\u0013\ti;>4\u0001Tp%\u000f6\n\u0002\u007f,XdZQ'{\u000f=\b\u0001cps=\u001a\u0016w";
      p[116] = "TZ\u000e~09WI\u001b/H/@K*x9@I\u0006T*,?\u0012\u000b\t|H";
      p[117] = "\u0013\u000657jNY\u0015)%W\u0014E\u0003-.;&\u0015OsthqN\u001c(99\u001a\u0014\u0000#sW";
      p[118] = "W\u0013\u0004\u000f`6\u0014[\u0017\f5T\bD\n\u0011\u00150\t@\u0006m5-U\u0013\u001e\u000e6&VYz";
      p[119] = "Tl\u001dQ\u0017JH-\u001dM/WXlMNCe\f \u0014\u0010\u00152Y.KLOQO\u007f\u0010I/";
      p[120] = ";Zo\u0010\u0005g3Jq\u0004ju Uu\u0005=+|\t!i\u000fd;Eh\f\u0014q(R";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2158557461370478L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2158557461370478L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2158557461370478L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 81;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 97;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 220;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 79;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 98;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 122;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 81;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 97;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 220;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eC_C0221",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
