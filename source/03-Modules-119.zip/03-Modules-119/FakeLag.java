package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;

public class FakeLag extends Module {
   private ModeSetting a;
   private MinMaxSetting c;
   private FloatSetting d;
   private MinMaxSetting e;
   private MinMaxSetting f;
   private MultiModeSetting g;
   private BooleanSetting h;
   private Queue i;
   private ElapsedTimer j;
   private ElapsedTimer k;
   private Vec3d l;
   private boolean m;
   private boolean n;
   private boolean o;
   private float p;
   private static final long q = 73256956199987L;
   private static final String[] r;
   private static final String[] s;
   private static final Map t = new HashMap(13);
   private static final Object[] u = new Object[111];
   private static final String[] v = new String[111];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;

   public FakeLag() {
      super();
      long var10001 = 112100975017571L ^ 5489327294794L;
      var10001 = 112100975017571L ^ 52177554666676L;
      var10001 = 112100975017571L ^ 132163413772L;
      var10001 = 112100975017571L ^ 134700248714420L;

      this.i = new ConcurrentLinkedQueue();
      this.j = new ElapsedTimer(106698256430889L);
      this.k = new ElapsedTimer(106698256430889L);
      this.l = Vec3d.ZERO;
      this.p = 0.0F;
      MinMaxSetting var10000 = this.e;
      Object[] var12 = new Object[]{invokeBinding1(this), 112057026795887L};
      MinMaxSetting var11 = var10000;
      var11.aReturningMinMaxSetting(var12);
      MultiModeSetting var21 = this.g;
      Object[] var14 = new Object[]{invokeBinding2(this), 81913655528151L};
      MultiModeSetting var13 = var21;
      var13.aReturningMultiModeSetting(var14);
      var10000 = this.c;
      Object[] var16 = new Object[]{invokeBinding3(this), 112057026795887L};
      MinMaxSetting var15 = var10000;
      var15.aReturningMinMaxSetting(var16);
      FloatSetting var23 = this.d;
      Object[] var18 = new Object[]{invokeBinding4(this), 34595201528535L};
      FloatSetting var17 = var23;
      var17.aReturningFloatSetting(var18);
      var10000 = this.f;
      Object[] var20 = new Object[]{invokeBinding5(this), 112057026795887L};
      MinMaxSetting var19 = var10000;
      var19.aReturningMinMaxSetting(var20);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 100777065459655L ^ 44446275850632L;
      var10001 = 100777065459655L ^ 137793985923015L;
      var10001 = 100777065459655L ^ 20446695750570L;
      var10001 = 100777065459655L ^ 30088593569193L;
      int var12 = Event.bReturningInt();
      int var85 = var12;
      MinecraftClient var84 = b;
      MinecraftClient var73 = var84;
      MinecraftClient var72 = var84;
      if (var85 == 0) {
         MinecraftClient var15 = var72;
         ClientWorld var86 = var15.world;
         if (var86 == null) {
            return;
         }

         MinecraftClient var87 = b;
         var73 = var87;
      }

      MinecraftClient var18 = var73;
      int var89 = var12;
      ClientPlayerEntity var88 = var18.player;
      Object var75 = var88;
      ClientPlayerEntity var74 = var88;
      if (var89 == 0) {
         ClientPlayerEntity var90 = var74;
         if (var90 == null) {
            return;
         }

         ModeSetting var20 = this.a;
         var75 = var20.aReturningObject();
      }

      boolean var81;
      String var10000 = (String)var75;
      String var22 = "Manual";
      String var21 = var10000;
      boolean var111 = var21.equals(var22);
      int var92 = var12;
      boolean var91 = var111;
      var81 = var91;
      boolean var76 = var91;
      label63:
      if (var92 == 0) {
         boolean var93 = var76;
         if (!var93) {
            Object[] var25 = new Object[0];
            PacketReceiveEvent var24 = var1;
            boolean var112 = var24.aReturningVoid(var25) instanceof ExplosionS2CPacket;
            int var95 = var12;
            boolean var94 = var112;
            var81 = var94;
            boolean var77 = var94;
            if (var95 != 0) {
               break label63;
            }

            boolean var96 = var77;
            boolean var78 = var96;
            boolean var97 = var78;
            if (var97) {
               MultiModeSetting var113 = this.g;
               Object[] var29 = new Object[]{"On Explosion", 71444480285294L};
               MultiModeSetting var28 = var113;
               boolean var114 = var28.aReturningBoolean(var29);
               int var99 = var12;
               boolean var98 = var114;
               var81 = var98;
               boolean var79 = var98;
               if (var99 != 0) {
                  break label63;
               }

               boolean var100 = var79;
               boolean var80 = var100;
               boolean var101 = var80;
               if (var101) {
                  MinecraftClient var32 = b;
                  ClientPlayerEntity var116 = var32.player;
                  Object[] var34 = new Object[0];
                  PacketReceiveEvent var33 = var1;
                  ExplosionS2CPacket var35 = (ExplosionS2CPacket)var33.aReturningVoid(var34);
                  Vec3d var36 = var35.center();
                  double var123 = var36.getX();
                  Object[] var38 = new Object[0];
                  PacketReceiveEvent var37 = var1;
                  ExplosionS2CPacket var39 = (ExplosionS2CPacket)var37.aReturningVoid(var38);
                  Vec3d var40 = var39.center();
                  double var10002 = var40.getY();
                  Object[] var42 = new Object[0];
                  PacketReceiveEvent var41 = var1;
                  ExplosionS2CPacket var43 = (ExplosionS2CPacket)var41.aReturningVoid(var42);
                  Vec3d var44 = var43.center();
                  double var50 = var44.getZ();
                  double var48 = var10002;
                  double var46 = var123;
                  ClientPlayerEntity var45 = var116;
                  double var124;
                  int var102 = (var124 = var45.squaredDistanceTo(var46, var48, var50) - 100.0) == 0.0 ? 0 : (var124 < 0.0 ? -1 : 1);
                  if (var102 > 0) {
                     return;
                  }

                  Object[] var55 = new Object[]{80536596468845L};
                  FakeLag var54 = this;
                  var54.jReturningVoid(var55);
                  return;
               }
            }
         }

         ModeSetting var56 = this.a;
         var10000 = (String)var56.aReturningObject();
         String var58 = "Knockback";
         String var57 = var10000;
         var81 = var57.equals(var58);
      }

      boolean var103 = var81;
      if (var103) {
         Object[] var60 = new Object[0];
         PacketReceiveEvent var59 = var1;
         Packet var14 = var59.aReturningVoid(var60);
         int var105 = var12;
         Packet var104 = var14;
         Packet var83 = var104;
         Packet var82 = var104;
         if (var105 == 0) {
            boolean var106 = var82 instanceof EntityVelocityUpdateS2CPacket;
            if (!var106) {
               return;
            }

            Packet var107 = var14;
            var83 = var107;
         }

         EntityVelocityUpdateS2CPacket var13 = (EntityVelocityUpdateS2CPacket)var83;
         int var108 = var12;
         if (var108 == 0) {
            EntityVelocityUpdateS2CPacket var63 = var13;
            int var117 = var63.getEntityId();
            MinecraftClient var64 = b;
            ClientPlayerEntity var65 = var64.player;
            int var110 = var65.getId();
            int var109 = var117;
            if (var109 != var110) {
               return;
            }

            this.o = dev.prestige.recovery.SourceSupport.asBoolean(1);
            ElapsedTimer var118 = this.k;
            Object[] var68 = new Object[]{42835128969216L};
            ElapsedTimer var67 = var118;
            var67.aReturningVoid(var68);
         }

         MinMaxSetting var119 = this.e;
         Object[] var71 = new Object[]{127318019014223L};
         MinMaxSetting var70 = var119;
         var70.bReturningVoid(var71);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 60128512321103L ^ 140259164123682L;
      var10001 = 60128512321103L ^ 130110468422689L;
      var10001 = 60128512321103L ^ 72290097888308L;
      int var10 = Event.cReturningInt();
      int var118 = var10;
      MinecraftClient var117 = b;
      MinecraftClient var83 = var117;
      MinecraftClient var82 = var117;
      if (var118 != 0) {
         MinecraftClient var11 = var82;
         ClientWorld var119 = var11.world;
         if (var119 == null) {
            return;
         }

         MinecraftClient var120 = b;
         var83 = var120;
      }

      MinecraftClient var14 = var83;
      int var122 = var10;
      ClientPlayerEntity var121 = var14.player;
      Object var85 = var121;
      ClientPlayerEntity var84 = var121;
      if (var122 != 0) {
         ClientPlayerEntity var123 = var84;
         if (var123 == null) {
            return;
         }

         ModeSetting var16 = this.a;
         var85 = var16.aReturningObject();
      }

      FakeLag var107;
      label165: {
         boolean var108;
         String var10000 = (String)var85;
         String var18 = "Manual";
         String var17 = var10000;
         boolean var181 = var17.equals(var18);
         int var125 = var10;
         boolean var124 = var181;
         var108 = var124;
         boolean var86 = var124;
         label106:
         if (var125 != 0) {
            label138: {
               boolean var126 = var86;
               if (!var126) {
                  Object[] var21 = new Object[0];
                  PacketSendEvent var20 = var1;
                  boolean var182 = var20.aReturningVoid(var21) instanceof PlayerInteractEntityC2SPacket;
                  int var128 = var10;
                  boolean var127 = var182;
                  boolean var91 = var127;
                  boolean var87 = var127;
                  if (var128 != 0) {
                     boolean var129 = var87;
                     boolean var88 = var129;
                     boolean var130 = var88;
                     if (var130) {
                        int var132 = var10;
                        FakeLag var131 = this;
                        var107 = var131;
                        FakeLag var89 = var131;
                        if (var132 == 0) {
                           break label165;
                        }

                        FakeLag var133 = var89;
                        FakeLag var90 = var133;
                        MultiModeSetting var183 = var90.g;
                        Object[] var26 = new Object[]{"On Interact Entity", 71444480285294L};
                        MultiModeSetting var25 = var183;
                        boolean var134 = var25.aReturningBoolean(var26);
                        if (var134) {
                           break label138;
                        }
                     }

                     Object[] var29 = new Object[0];
                     PacketSendEvent var28 = var1;
                     boolean var135 = var28.aReturningVoid(var29) instanceof HandSwingC2SPacket;
                     var91 = var135;
                  }

                  int var137 = var10;
                  boolean var136 = var91;
                  boolean var95 = var136;
                  boolean var92 = var136;
                  if (var137 != 0) {
                     boolean var138 = var92;
                     if (var138) {
                        int var140 = var10;
                        FakeLag var139 = this;
                        var107 = var139;
                        FakeLag var93 = var139;
                        if (var140 == 0) {
                           break label165;
                        }

                        FakeLag var141 = var93;
                        FakeLag var94 = var141;
                        MultiModeSetting var184 = var94.g;
                        Object[] var34 = new Object[]{"On Hand Swing", 71444480285294L};
                        MultiModeSetting var33 = var184;
                        boolean var142 = var33.aReturningBoolean(var34);
                        if (var142) {
                           break label138;
                        }
                     }

                     Object[] var37 = new Object[0];
                     PacketSendEvent var36 = var1;
                     boolean var143 = var36.aReturningVoid(var37) instanceof PlayerInteractBlockC2SPacket;
                     var95 = var143;
                  }

                  int var145 = var10;
                  boolean var144 = var95;
                  boolean var99 = var144;
                  boolean var96 = var144;
                  if (var145 != 0) {
                     boolean var146 = var96;
                     if (var146) {
                        int var148 = var10;
                        FakeLag var147 = this;
                        var107 = var147;
                        FakeLag var97 = var147;
                        if (var148 == 0) {
                           break label165;
                        }

                        FakeLag var149 = var97;
                        FakeLag var98 = var149;
                        MultiModeSetting var185 = var98.g;
                        Object[] var42 = new Object[]{"On Interact Block", 71444480285294L};
                        MultiModeSetting var41 = var185;
                        boolean var150 = var41.aReturningBoolean(var42);
                        if (var150) {
                           break label138;
                        }
                     }

                     Object[] var45 = new Object[0];
                     PacketSendEvent var44 = var1;
                     boolean var151 = var44.aReturningVoid(var45) instanceof PlayerInteractItemC2SPacket;
                     var99 = var151;
                  }

                  int var153 = var10;
                  boolean var152 = var99;
                  boolean var103 = var152;
                  boolean var100 = var152;
                  if (var153 != 0) {
                     boolean var154 = var100;
                     if (var154) {
                        int var156 = var10;
                        FakeLag var155 = this;
                        var107 = var155;
                        FakeLag var101 = var155;
                        if (var156 == 0) {
                           break label165;
                        }

                        FakeLag var157 = var101;
                        FakeLag var102 = var157;
                        MultiModeSetting var186 = var102.g;
                        Object[] var50 = new Object[]{"On Interact Item", 71444480285294L};
                        MultiModeSetting var49 = var186;
                        boolean var158 = var49.aReturningBoolean(var50);
                        if (var158) {
                           break label138;
                        }
                     }

                     Object[] var53 = new Object[0];
                     PacketSendEvent var52 = var1;
                     boolean var159 = var52.aReturningVoid(var53) instanceof ClickSlotC2SPacket;
                     var103 = var159;
                  }

                  int var161 = var10;
                  boolean var160 = var103;
                  var108 = var160;
                  boolean var104 = var160;
                  if (var161 == 0) {
                     break label106;
                  }

                  boolean var162 = var104;
                  if (var162) {
                     MultiModeSetting var187 = this.g;
                     Object[] var57 = new Object[]{"On Click Slot", 71444480285294L};
                     MultiModeSetting var56 = var187;
                     boolean var188 = var56.aReturningBoolean(var57);
                     int var164 = var10;
                     boolean var163 = var188;
                     var108 = var163;
                     boolean var105 = var163;
                     if (var164 == 0) {
                        break label106;
                     }

                     boolean var165 = var105;
                     boolean var106 = var165;
                     boolean var166 = var106;
                     if (var166) {
                        break label138;
                     }
                  }
               }

               var108 = this.m;
               break label106;
            }

            var107 = this;
            break label165;
         }

         int var168 = var10;
         boolean var167 = var108;
         boolean var110 = var167;
         boolean var109 = var167;
         if (var168 != 0) {
            boolean var169 = var109;
            if (var169) {
               return;
            }

            ModeSetting var63 = this.a;
            var10000 = (String)var63.aReturningObject();
            String var65 = "Knockback";
            String var64 = var10000;
            boolean var170 = var64.equals(var65);
            var110 = var170;
         }

         boolean var114;
         int var172 = var10;
         boolean var171 = var110;
         var114 = var171;
         boolean var111 = var171;
         label89:
         if (var172 != 0) {
            boolean var173 = var111;
            if (var173) {
               ElapsedTimer var190 = this.k;
               Object[] var69 = new Object[]{this.e, 130913203968635L};
               ElapsedTimer var68 = var190;
               boolean var191 = var68.bReturningBoolean(var69);
               int var175 = var10;
               boolean var174 = var191;
               var114 = var174;
               boolean var112 = var174;
               if (var175 == 0) {
                  break label89;
               }

               boolean var176 = var112;
               boolean var113 = var176;
               boolean var177 = var113;
               if (var177) {
                  return;
               }
            }

            var114 = AutoElytra.u;
         }

         int var179 = var10;
         boolean var178 = var114;
         boolean var115 = var178;
         if (var179 != 0) {
            boolean var180 = var115;
            if (var180) {
               Object[] var74 = new Object[]{80536596468845L};
               FakeLag var73 = this;
               var73.jReturningVoid(var74);
               return;
            }

            Queue var192 = this.i;
            Object[] var77 = new Object[0];
            PacketSendEvent var76 = var1;
            Packet var79 = var76.aReturningVoid(var77);
            Queue var78 = var192;
            boolean var116 = var78.add(var79);
         }

         Object[] var81 = new Object[0];
         PacketSendEvent var80 = var1;
         var80.aReturningVoid(var81);
         return;
      }

      Object[] var61 = new Object[]{80536596468845L};
      FakeLag var60 = var107;
      var60.jReturningVoid(var61);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var14;
      boolean var141;
      label165: {
         label168: {
            Object var117;
            label169: {
               boolean var114;
               long var10001 = 60519874353756L ^ 75597478306835L;
               var10001 = 60519874353756L ^ 19789954789980L;
               var10001 = 60519874353756L ^ 67685984930082L;
               var10001 = 60519874353756L ^ 138768290254385L;
               var10001 = 60519874353756L ^ 70482470109223L;
               int var10000 = Event.cReturningInt();
               this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
               var14 = var10000;
               ModeSetting var18 = this.a;
               String var217 = (String)var18.aReturningObject();
               String var20 = "Knockback";
               String var19 = var217;
               boolean var218 = var19.equals(var20);
               int var148 = var14;
               boolean var147 = var218;
               var114 = var147;
               boolean var110 = var147;
               label162:
               if (var148 != 0) {
                  boolean var149 = var110;
                  if (var149) {
                     ElapsedTimer var219 = this.k;
                     Object[] var23 = new Object[]{this.e, 130913203968635L};
                     ElapsedTimer var22 = var219;
                     var218 = var22.bReturningBoolean(var23);
                     int var151 = var14;
                     boolean var150 = var218;
                     var114 = var150;
                     boolean var111 = var150;
                     if (var151 == 0) {
                        break label162;
                     }

                     boolean var152 = var111;
                     boolean var112 = var152;
                     boolean var153 = var112;
                     if (var153) {
                        this.o = dev.prestige.recovery.SourceSupport.asBoolean(0);
                        Object[] var27 = new Object[]{80536596468845L};
                        FakeLag var26 = this;
                        var26.jReturningVoid(var27);
                     }
                  }

                  ModeSetting var29 = this.a;
                  String var221 = (String)var29.aReturningObject();
                  int var155 = var14;
                  String var154 = var221;
                  var117 = var154;
                  String var113 = var154;
                  if (var155 == 0) {
                     break label169;
                  }

                  String var31 = "Ranged";
                  String var30 = var113;
                  boolean var156 = var30.equals(var31);
                  var114 = var156;
               }

               boolean var157 = var114;
               if (!var157) {
                  ModeSetting var33 = this.a;
                  String var222 = (String)var33.aReturningObject();
                  String var35 = "Dynamic";
                  String var34 = var222;
                  var218 = var34.equals(var35);
                  int var159 = var14;
                  boolean var158 = var218;
                  var141 = var158;
                  boolean var115 = var158;
                  if (var159 == 0) {
                     break label165;
                  }

                  boolean var160 = var115;
                  boolean var116 = var160;
                  boolean var161 = var116;
                  if (!var161) {
                     break label168;
                  }
               }

               FloatSetting var38 = this.d;
               Object var162 = var38.aReturningObject();
               var117 = var162;
            }

            FakeLag var140;
            label171: {
               Float var40 = (Float)var117;
               float var224 = var40;
               Object[] var10003 = new Object[]{null, 11569543664510L};
               var10003[0] = var224;
               Object[] var41 = var10003;
               PlayerEntity var15 = EntityUtil.bReturningPlayerEntity(var41);
               int var164 = var14;
               PlayerEntity var163 = var15;
               Object var135 = var163;
               PlayerEntity var118 = var163;
               if (var164 != 0) {
                  PlayerEntity var165 = var118;
                  if (var165 != null) {
                     double var16;
                     FakeLag var132;
                     label142: {
                        label141: {
                           FakeLag var131;
                           label174: {
                              int var128;
                              MinecraftClient var43 = b;
                              PlayerEntity var45 = var15;
                              ClientPlayerEntity var44 = var43.player;
                              double var46 = var44.squaredDistanceTo((Entity)var45);
                              var16 = (float)Math.sqrt(var46);
                              MinMaxSetting var48 = this.c;
                              double var242;
                              int var225 = (var242 = var16 - var48.bReturningVoid()) == 0.0 ? 0 : (var242 < 0.0 ? -1 : 1);
                              int var167 = var14;
                              int var166 = var225;
                              var128 = var166;
                              int var119 = var166;
                              label139:
                              if (var167 != 0) {
                                 int var168 = var119;
                                 if (var168 < 0) {
                                    MinMaxSetting var50 = this.c;
                                    double var243;
                                    int var226 = (var243 = var16 - var50.aReturningVoid()) == 0.0 ? 0 : (var243 < 0.0 ? -1 : 1);
                                    int var170 = var14;
                                    int var169 = var226;
                                    var128 = var169;
                                    int var120 = var169;
                                    if (var170 == 0) {
                                       break label139;
                                    }

                                    int var171 = var120;
                                    int var121 = var171;
                                    int var172 = var121;
                                    if (var172 > 0) {
                                       double var244;
                                       int var227 = (var244 = var16 - this.p) == 0.0 ? 0 : (var244 < 0.0 ? -1 : 1);
                                       int var174 = var14;
                                       int var173 = var227;
                                       var128 = var173;
                                       int var122 = var173;
                                       if (var174 == 0) {
                                          break label139;
                                       }

                                       int var175 = var122;
                                       int var123 = var175;
                                       int var176 = var123;
                                       if (var176 <= 0) {
                                          int var178 = var14;
                                          FakeLag var177 = this;
                                          var132 = var177;
                                          FakeLag var124 = var177;
                                          if (var178 == 0) {
                                             break label142;
                                          }

                                          FakeLag var179 = var124;
                                          FakeLag var125 = var179;
                                          ElapsedTimer var228 = var125.j;
                                          Object[] var57 = new Object[]{this.f, 130913203968635L};
                                          ElapsedTimer var56 = var228;
                                          boolean var180 = var56.bReturningBoolean(var57);
                                          if (!var180) {
                                             break label141;
                                          }

                                          ElapsedTimer var229 = this.j;
                                          Object[] var60 = new Object[]{42835128969216L};
                                          ElapsedTimer var59 = var229;
                                          var59.aReturningVoid(var60);
                                          MinMaxSetting var230 = this.f;
                                          Object[] var62 = new Object[]{127318019014223L};
                                          MinMaxSetting var61 = var230;
                                          var61.bReturningVoid(var62);
                                          Object[] var64 = new Object[]{80536596468845L};
                                          FakeLag var63 = this;
                                          var63.jReturningVoid(var64);
                                          this.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
                                          int var181 = var14;
                                          if (var181 != 0) {
                                             break label141;
                                          }
                                       }
                                    }
                                 }

                                 int var183 = var14;
                                 FakeLag var182 = this;
                                 var131 = var182;
                                 FakeLag var126 = var182;
                                 if (var183 == 0) {
                                    break label174;
                                 }

                                 FakeLag var184 = var126;
                                 FakeLag var127 = var184;
                                 ModeSetting var67 = var127.a;
                                 String var231 = (String)var67.aReturningObject();
                                 String var69 = "Ranged";
                                 String var68 = var231;
                                 byte var185 = ((byte)((var68.equals(var69)) ? 1 : 0));
                                 var128 = var185;
                              }

                              int var186 = var128;
                              if (var186 == 0) {
                                 int var188 = var14;
                                 FakeLag var187 = this;
                                 var131 = var187;
                                 FakeLag var129 = var187;
                                 if (var188 == 0) {
                                    break label174;
                                 }

                                 FakeLag var189 = var129;
                                 FakeLag var130 = var189;
                                 ElapsedTimer var232 = var130.j;
                                 Object[] var73 = new Object[]{this.e, 130913203968635L};
                                 ElapsedTimer var72 = var232;
                                 boolean var190 = var72.bReturningBoolean(var73);
                                 if (!var190) {
                                    MinecraftClient var75 = b;
                                    ClientPlayerEntity var76 = var75.player;
                                    boolean var191 = var76.isUsingItem();
                                    if (!var191) {
                                       break label141;
                                    }
                                 }
                              }

                              FakeLag var192 = this;
                              var131 = var192;
                           }

                           Object[] var80 = new Object[]{80536596468845L};
                           FakeLag var79 = var131;
                           var79.jReturningVoid(var80);
                        }

                        var132 = this;
                     }

                     var132.p = (float)var16;
                     int var193 = var14;
                     if (var193 != 0) {
                        break label168;
                     }
                  }

                  int var195 = var14;
                  FakeLag var194 = this;
                  var140 = var194;
                  FakeLag var133 = var194;
                  if (var195 == 0) {
                     break label171;
                  }

                  FakeLag var196 = var133;
                  FakeLag var134 = var196;
                  ModeSetting var82 = var134.a;
                  Object var197 = var82.aReturningObject();
                  var135 = var197;
               }

               String var233 = (String)var135;
               String var85 = "Ranged";
               String var84 = var233;
               boolean var198 = var84.equals(var85);
               if (!var198) {
                  int var200 = var14;
                  FakeLag var199 = this;
                  var140 = var199;
                  FakeLag var136 = var199;
                  if (var200 == 0) {
                     break label171;
                  }

                  FakeLag var201 = var136;
                  FakeLag var137 = var201;
                  ElapsedTimer var234 = var137.j;
                  Object[] var88 = new Object[]{this.e, 130913203968635L};
                  ElapsedTimer var87 = var234;
                  boolean var202 = var87.bReturningBoolean(var88);
                  if (!var202) {
                     MinecraftClient var90 = b;
                     ClientPlayerEntity var91 = var90.player;
                     boolean var235 = var91.isUsingItem();
                     int var204 = var14;
                     boolean var203 = var235;
                     var141 = var203;
                     boolean var138 = var203;
                     if (var204 == 0) {
                        break label165;
                     }

                     boolean var205 = var138;
                     boolean var139 = var205;
                     boolean var206 = var139;
                     if (!var206) {
                        break label168;
                     }
                  }
               }

               var140 = this;
            }

            Object[] var95 = new Object[]{80536596468845L};
            FakeLag var94 = var140;
            var94.jReturningVoid(var95);
         }

         ModeSetting var96 = this.a;
         String var236 = (String)var96.aReturningObject();
         String var98 = "Timed";
         String var97 = var236;
         var141 = var97.equals(var98);
      }

      FakeLag var146;
      label177: {
         int var208 = var14;
         boolean var207 = var141;
         boolean var145 = var207;
         boolean var142 = var207;
         if (var208 != 0) {
            boolean var209 = var142;
            if (!var209) {
               return;
            }

            int var211 = var14;
            FakeLag var210 = this;
            var146 = var210;
            FakeLag var143 = var210;
            if (var211 == 0) {
               break label177;
            }

            FakeLag var212 = var143;
            FakeLag var144 = var212;
            ElapsedTimer var237 = var144.j;
            Object[] var102 = new Object[]{this.e, 130913203968635L};
            ElapsedTimer var101 = var237;
            boolean var213 = var101.bReturningBoolean(var102);
            var145 = var213;
         }

         boolean var214 = var145;
         if (!var214) {
            MinecraftClient var104 = b;
            ClientPlayerEntity var105 = var104.player;
            boolean var215 = var105.isUsingItem();
            if (!var215) {
               return;
            }
         }

         FakeLag var216 = this;
         var146 = var216;
      }

      Object[] var109 = new Object[]{80536596468845L};
      FakeLag var108 = var146;
      var108.jReturningVoid(var109);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      int var12;
      ElapsedTimer var55;
      label56: {
         FakeLag var54;
         label59: {
            long var10001 = 43677724258635L ^ 7899437907530L;
            var10001 = 43677724258635L ^ 111748444599138L;
            var10001 = 43677724258635L ^ 41609727431545L;
            var10001 = 43677724258635L ^ 42789508745992L;
            var12 = Event.cReturningInt();
            BooleanSetting var15 = this.h;
            Boolean var16 = (Boolean)var15.aReturningObject();
            boolean var10000 = var16;
            int var62 = var12;
            boolean var61 = var10000;
            boolean var53 = var61;
            boolean var51 = var61;
            if (var62 != 0) {
               boolean var63 = var51;
               if (!var63) {
                  return;
               }

               int var65 = var12;
               FakeLag var64 = this;
               var54 = var64;
               FakeLag var52 = var64;
               if (var65 == 0) {
                  break label59;
               }

               boolean var66 = var52.o;
               var53 = var66;
            }

            boolean var67 = var53;
            if (var67) {
               ElapsedTimer var68 = this.k;
               var55 = var68;
               break label56;
            }

            var54 = this;
         }

         var55 = var54.j;
      }

      ElapsedTimer var13;
      float var60;
      label45: {
         FakeLag var59;
         label61: {
            var13 = var55;
            ModeSetting var20 = this.a;
            String var80 = (String)var20.aReturningObject();
            String var22 = "Manual";
            String var21 = var80;
            boolean var81 = var21.equals(var22);
            int var70 = var12;
            boolean var69 = var81;
            boolean var58 = var69;
            boolean var56 = var69;
            if (var70 != 0) {
               boolean var71 = var56;
               if (var71) {
                  float var72 = 1000.0F;
                  var60 = var72;
                  break label45;
               }

               int var74 = var12;
               FakeLag var73 = this;
               var59 = var73;
               FakeLag var57 = var73;
               if (var74 == 0) {
                  break label61;
               }

               boolean var75 = var57.n;
               var58 = var75;
            }

            boolean var76 = var58;
            if (var76) {
               MinMaxSetting var82 = this.f;
               Object[] var27 = new Object[0];
               MinMaxSetting var26 = var82;
               float var77 = var26.eReturningFloat(var27);
               var60 = var77;
               break label45;
            }

            var59 = this;
         }

         MinMaxSetting var83 = var59.e;
         Object[] var30 = new Object[0];
         MinMaxSetting var29 = var83;
         var60 = var29.eReturningFloat(var30);
      }

      float var14 = var60;
      int var78 = var12;
      if (var78 != 0) {
         Object[] var32 = new Object[]{35831705079553L};
         ElapsedTimer var31 = var13;
         float var91;
         int var79 = (var91 = var31.aReturningFloat(var32) / var14 / 2.0F - 0.1F) == 0.0F ? 0 : (var91 < 0.0F ? -1 : 1);
         if (var79 < 0) {
            return;
         }

         RenderContext var84 = var1.b;
         MeshBufferManager var88 = var1.a;
         Vec3d var35 = this.l;
         float var10002 = (float)var35.x;
         Vec3d var36 = this.l;
         float var10003 = (float)var36.y;
         Vec3d var37 = this.l;
         float var10004 = (float)var37.z;
         Object[] var39 = new Object[]{35831705079553L};
         ElapsedTimer var38 = var13;
         float var41 = var38.aReturningFloat(var39) / var14 / 2.0F;
         float var40 = 0.5F;
         float var10005 = Math.min(var40, var41);
         Object[] var42 = new Object[]{2617886958130L};
         Color var43 = ClientUiUtil.dReturningColor(var42);
         Color var10008 = var43.brighter();
         Object[] var45 = new Object[]{35831705079553L};
         ElapsedTimer var44 = var13;
         float var47 = var44.aReturningFloat(var45) / var14;
         float var46 = 1.0F;
         float var10009 = Math.min(var46, var47);
         Object[] var10012 = new Object[]{null, null, 1456904419907L};
         var10012[1] = var10009;
         var10012[0] = var10008;
         Object[] var48 = var10012;
         var10008 = ClientUiUtil.bReturningColor(var48);
         Object[] var49 = new Object[]{2617886958130L};
         var10012 = new Object[]{null, null, null, null, null, null, null, null, var10008, ClientUiUtil.dReturningColor(var49), 72687848587817L};
         var10012[7] = 0.1F;
         var10012[6] = 0.005F;
         var10012[5] = var10005;
         var10012[4] = var10004;
         var10012[3] = var10003;
         var10012[2] = var10002;
         var10012[1] = var88;
         var10012[0] = var84;
         Object[] var50 = var10012;
         ShapeRenderer.fReturningVoid(var50);
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 13970279202175L;
      long var6 = var2 ^ 14307093244588L;
      ElapsedTimer var10000 = this.j;
      Object[] var9 = new Object[]{var4};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      Object[] var10 = new Object[]{var6};
      this.l = RaycastUtil.bReturningVec3d(var10);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 90673761422607L;
      Object[] var7 = new Object[]{var4};
      FakeLag var6 = this;
      var6.jReturningVoid(var7);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 73256956199987L ^ var2;
      long var4 = var2 ^ 113748745075610L;
      long var6 = var2 ^ 132304800886289L;
      long var8 = var2 ^ 49934384904286L;
      long var10 = var2 ^ 49331288977293L;
      int var12 = Event.cReturningInt();
      int var37 = var12;
      MinecraftClient var36 = b;
      MinecraftClient var31 = var36;
      MinecraftClient var30 = var36;
      if (var37 != 0) {
         MinecraftClient var13 = var30;
         ClientPlayerEntity var38 = var13.player;
         if (var38 == null) {
            return;
         }

         MinecraftClient var39 = b;
         var31 = var39;
      }

      MinecraftClient var16 = var31;
      ClientWorld var40 = var16.world;
      if (var40 != null) {
         this.m = dev.prestige.recovery.SourceSupport.asBoolean(1);

         FakeLag var35;
         while (true) {
            MinecraftClient var18 = b;
            ClientPlayNetworkHandler var41 = var18.getNetworkHandler();
            if (var41 != null) {
               int var43 = var12;
               FakeLag var42 = this;
               var35 = var42;
               FakeLag var32 = var42;
               if (var43 == 0) {
                  break;
               }

               int var45 = var12;
               FakeLag var44 = var32;
               var35 = var44;
               FakeLag var33 = var44;
               if (var45 == 0) {
                  break;
               }

               FakeLag var46 = var33;
               FakeLag var34 = var46;
               Queue var20 = var34.i;
               boolean var47 = var20.isEmpty();
               if (!var47) {
                  Queue var22 = this.i;
                  Object[] var23 = new Object[]{(Packet)var22.poll(), var4};
                  PacketUtil.aReturningVoid(var23);
                  int var48 = var12;
                  if (var48 != 0) {
                     continue;
                  }
               }
            }

            this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
            ElapsedTimer var10000 = this.j;
            Object[] var26 = new Object[]{var8};
            ElapsedTimer var25 = var10000;
            var25.aReturningVoid(var26);
            MinMaxSetting var50 = this.e;
            Object[] var28 = new Object[]{var6};
            MinMaxSetting var27 = var50;
            var27.bReturningVoid(var28);
            var35 = this;
            break;
         }

         Object[] var29 = new Object[]{var10};
         var35.l = RaycastUtil.bReturningVec3d(var29);
      }
   }

   @Override
   public String aReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      return invokeBinding10(
         invokeBinding6(8774, 7361109313182661321L ^ var2),
         new Object[]{
            invokeBinding9(
               invokeBinding8(invokeBinding7(this.e, new Object[0], -4955421918140463752L, var2), -4957321721964530899L, var2), -4956806926987800753L, var2
            )
         },
         -4954187940337975596L,
         var2
      );
   }

   private boolean lambda$new$4(String var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Manual";
      String var6 = var10000;
      byte var15 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var12 = var4;
      byte var11 = var15;
      byte var9 = var11;
      byte var8 = var11;
      if (var12 != 0) {
         byte var13 = var8;
         if (var13 != 0) {
            return false;
         }

         var9 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var9);
   }

   private boolean lambda$new$3(Float var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Ranged";
      String var6 = var10000;
      byte var25 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var18 = var4;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            ModeSetting var9 = this.a;
            var10000 = (String)var9.aReturningObject();
            String var11 = "Dynamic";
            String var10 = var10000;
            byte var27 = ((byte)((var10.equals(var11)) ? 1 : 0));
            int var21 = var4;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$2(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Timed";
      String var6 = var10000;
      byte var36 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var25 = var4;
      byte var24 = var36;
      byte var22 = var24;
      byte var17 = var24;
      if (var25 != 0) {
         byte var26 = var17;
         if (var26 == 0) {
            ModeSetting var9 = this.a;
            var10000 = (String)var9.aReturningObject();
            String var11 = "Dynamic";
            String var10 = var10000;
            boolean var38 = var10.equals(var11);
            int var28 = var4;
            boolean var27 = var38;
            byte var41 = ((byte)((var27) ? 1 : 0));
            boolean var18 = var27;
            if (var28 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var41);
            }

            boolean var29 = var18;
            boolean var19 = var29;
            boolean var30 = var19;
            if (!var30) {
               ModeSetting var14 = this.a;
               var10000 = (String)var14.aReturningObject();
               String var16 = "Knockback";
               String var15 = var10000;
               byte var40 = ((byte)((var15.equals(var16)) ? 1 : 0));
               int var32 = var4;
               byte var31 = var40;
               var41 = var31;
               byte var20 = var31;
               if (var32 == 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var41);
               }

               byte var33 = var20;
               byte var21 = var33;
               byte var34 = var21;
               if (var34 == 0) {
                  return false;
               }
            }
         }

         var22 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var22);
   }

   private boolean lambda$new$1(Float var1) {
      int var4 = Event.bReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Ranged";
      String var6 = var10000;
      byte var25 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var18 = var4;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            ModeSetting var9 = this.a;
            var10000 = (String)var9.aReturningObject();
            String var11 = "Dynamic";
            String var10 = var10000;
            byte var27 = ((byte)((var10.equals(var11)) ? 1 : 0));
            int var21 = var4;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$0(Float var1) {
      int var4 = Event.cReturningInt();
      ModeSetting var5 = this.a;
      String var10000 = (String)var5.aReturningObject();
      String var7 = "Ranged";
      String var6 = var10000;
      byte var25 = ((byte)((var6.equals(var7)) ? 1 : 0));
      int var18 = var4;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            ModeSetting var9 = this.a;
            var10000 = (String)var9.aReturningObject();
            String var11 = "Dynamic";
            String var10 = var10000;
            byte var27 = ((byte)((var10.equals(var11)) ? 1 : 0));
            int var21 = var4;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(30458335652835L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[17];
      String var6 = "ô6É¼Ò`Lù\"Ø#\u009f\u0012\u008cJ\u009dÛ\u001d\u0090$\u0003Ú\u008a\u007f0O/\u0002æö\u008eýËá\u0097Jb\r\u001aäþQKr\u0089þ\u009bàÒ\fÎG\u000fþE\u0090r\u009c±ï\u00ad>\u009e\u008bWWú½\u009f\u0017\"y\u009d Ïúäß½\u0081Ù\u0018a\u0005$ÿ5¿gÖiñhLÅ;\u0010A\u0096æ\u0010Ý\u000fPGZ\u0010\u0001+5x6¬À´ý\u009f9\u0015\u008b9:À\u0010ÛÆ\u0010É±}ôÊ^ö´`Å\u00868[ \u0086û$©\u008f\u0080èË³L\u0095ËÕNåws¤§\u008f\u0018²\u001e\u0093¯\u0089`ëz¶6Þ\u0010Q\r'·¯ô\u0089¼ê9%ÕÆ\u0096-\u008f\u0010$\u0087\u009f>\u0093ì¹\u0085ïJêõñ·µt mª\u00982\n\båº\u0080rr.\u0000ÝÛ\u0013eïûÆ\u0097&Ý \u001bH.Ðð\u000eÐÁ\u0010«E¡\u0093ÿòãù\u0094\fï\u0006×4\u0002\u0092\u0010\u0088=\u0001q8\u0011\u0088\u0092D\t\u0093n×'£ß\u0010l;ü² Ý\"ê÷ä\fo«6cî \u001d\u001bE\u008d}Ç»\u0012q\u0098õ,xëû\u0083hh¡4\u0000£\u0080ÅÖ\u000e½¯\u0095º\u0013ç\u0010\u0006\u0083cËV\u008f\u0002ï\f/\u0015ç#êS¾\u0018î_\u000eóp\u0083S?'ùÚ³iEt\u0089øÒýF\u008ew^S";
      int var8 = "ô6É¼Ò`Lù\"Ø#\u009f\u0012\u008cJ\u009dÛ\u001d\u0090$\u0003Ú\u008a\u007f0O/\u0002æö\u008eýËá\u0097Jb\r\u001aäþQKr\u0089þ\u009bàÒ\fÎG\u000fþE\u0090r\u009c±ï\u00ad>\u009e\u008bWWú½\u009f\u0017\"y\u009d Ïúäß½\u0081Ù\u0018a\u0005$ÿ5¿gÖiñhLÅ;\u0010A\u0096æ\u0010Ý\u000fPGZ\u0010\u0001+5x6¬À´ý\u009f9\u0015\u008b9:À\u0010ÛÆ\u0010É±}ôÊ^ö´`Å\u00868[ \u0086û$©\u008f\u0080èË³L\u0095ËÕNåws¤§\u008f\u0018²\u001e\u0093¯\u0089`ëz¶6Þ\u0010Q\r'·¯ô\u0089¼ê9%ÕÆ\u0096-\u008f\u0010$\u0087\u009f>\u0093ì¹\u0085ïJêõñ·µt mª\u00982\n\båº\u0080rr.\u0000ÝÛ\u0013eïûÆ\u0097&Ý \u001bH.Ðð\u000eÐÁ\u0010«E¡\u0093ÿòãù\u0094\fï\u0006×4\u0002\u0092\u0010\u0088=\u0001q8\u0011\u0088\u0092D\t\u0093n×'£ß\u0010l;ü² Ý\"ê÷ä\fo«6cî \u001d\u001bE\u008d}Ç»\u0012q\u0098õ,xëû\u0083hh¡4\u0000£\u0080ÅÖ\u000e½¯\u0095º\u0013ç\u0010\u0006\u0083cËV\u008f\u0002ï\f/\u0015ç#êS¾\u0018î_\u000eóp\u0083S?'ùÚ³iEt\u0089øÒýF\u008ew^S"
         .length();
      char var5 = 24;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         // while (true) {
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     r = var9;
                     s = new String[17];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "q8ÿ\u0012©»\u008byûv\u00197$CºÕ0ö\u000bÍzH§+\u0098Ô\u009e$±äÔ8n\u0017p\u009f\u0090°²ñéÅýçå\u000b\u001eDïù\u001b\njE(0»\u0087T¤°\u000fù{\u009e";
                  var8 = "q8ÿ\u0012©»\u008byûv\u00197$CºÕ0ö\u000bÍzH§+\u0098Ô\u009e$±äÔ8n\u0017p\u009f\u0090°²ñéÅýçå\u000b\u001eDïù\u001b\njE(0»\u0087T¤°\u000fù{\u009e"
                     .length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 25512;
      if (s[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])t.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eD", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = r[var5].getBytes("ISO-8859-1");
         s[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return s[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eD_C0223",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eD" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = v[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = u[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 14;
            yield var15;
         }
         case 1 -> {
            byte var16 = 52;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 15;
            yield var18;
         }
         case 4 -> {
            byte var19 = 26;
            yield var19;
         }
         case 5 -> {
            byte var20 = 16;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 11;
            yield var23;
         }
         case 9 -> {
            byte var24 = 58;
            yield var24;
         }
         case 10 -> {
            byte var25 = 10;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 39;
            yield var27;
         }
         case 13 -> {
            byte var28 = 57;
            yield var28;
         }
         case 14 -> {
            byte var29 = 40;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 23;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 47;
            yield var34;
         }
         case 20 -> {
            byte var35 = 4;
            yield var35;
         }
         case 21 -> {
            byte var36 = 59;
            yield var36;
         }
         case 22 -> {
            byte var37 = 55;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 62;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 34;
            yield var41;
         }
         case 27 -> {
            byte var42 = 28;
            yield var42;
         }
         case 28 -> {
            byte var43 = 51;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 7;
            yield var47;
         }
         case 33 -> {
            byte var48 = 31;
            yield var48;
         }
         case 34 -> {
            byte var49 = 12;
            yield var49;
         }
         case 35 -> {
            byte var50 = 46;
            yield var50;
         }
         case 36 -> {
            byte var51 = 17;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 6;
            yield var53;
         }
         case 39 -> {
            byte var54 = 38;
            yield var54;
         }
         case 40 -> {
            byte var55 = 18;
            yield var55;
         }
         case 41 -> {
            byte var56 = 50;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 3;
            yield var58;
         }
         case 44 -> {
            byte var59 = 30;
            yield var59;
         }
         case 45 -> {
            byte var60 = 8;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 42;
            yield var62;
         }
         case 48 -> {
            byte var63 = 41;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 21;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 32;
            yield var67;
         }
         case 53 -> {
            byte var68 = 22;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 33;
            yield var72;
         }
         case 58 -> {
            byte var73 = 43;
            yield var73;
         }
         case 59 -> {
            byte var74 = 35;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 9;
            yield var76;
         }
         case 62 -> {
            byte var77 = 24;
            yield var77;
         }
         default -> 53;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            v[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      u[0] = "\u001cJ-;_\t\nJ(aL\u001e\u001d\u0001+g@\n\fF<p\u000b\u001d4";
      u[1] = "O\fL\n\u0014E:,G\u0005\u0005\n[\"L\u000e\u0001P/";
      u[2] = void.class;
      v[2] = "java/lang/Void";
      u[3] = "o\u0004dp\u0018\u0014q\f~?g\u0014`\u0010w";
      u[4] = "`'\f|=mk(\u001d3\\c`#\u0019i";
      u[5] = "h\u001c&unA~\u001c#/}ViW )qBx\u00107>:TH";
      u[6] = ">Cpi\u0005m5La&f` AnMSb1RraDo";
      u[7] = "9?WP\fw/?R\n\u001f`8tQ\f\u0013t)3F\u001bXf\u0018";
      u[8] = int.class;
      v[8] = "java/lang/Integer";
      u[9] = "u(<op\fc(95c\u001btc:3o\u000fe$-$$\u001f\"";
      u[10] = "V\u001bbU'\u0014#;iZ6[B5bQ2\u00016";
      u[11] = "yO7RqsyO \u000e}|c\u0004 \u0010}iduqH/";
      u[12] = "|~\u000b9'\u0001|~\u001ce+\u000ef5\u001c{+\u001baDL&z";
      u[13] = "Tc7AHkTc \u001dDdN( \u0003DqIYu\\\u0011";
      u[14] = "\u001d4]t!-\u001d4J(-\"\u0007\u007fJ6-7\u0000\u000e\u001fit";
      u[15] = "\u007f\u000bX7!7\u007f\u000bOk-8e@Ou--b1\u001b-z";
      u[16] = "]s\u0011,9cKs\u0014v*t\\8\u0017p&`M\u007f\u0000gmu`";
      u[17] = "O8<\u0007\u0004$:\u00187\b\u0015k[\u0016<\u0003\u00111/";
      u[18] = boolean.class;
      v[18] = "java/lang/Boolean";
      u[19] = "\u0018R*[9\u0006\u000eR/\u0001*\u0011\u0019\u0019,\u0007&\u0005\b^;\u0010m\u0015L";
      u[20] = "f`1+=\t\u0013@:$,FrN1/(\u001c\u0006";
      u[21] = "=2\u0011]>s6=\u0000\u0012Ck%:\t[";
      u[22] = "4`\u000e#3!\"`\u000by 65+\b\u007f,\"$l\u001fhg5\u0016";
      u[23] = "\u0012.]$:\u000b\u0004.X~)\u001c\u0013e[x%\b\u0002\"Lon\u001f<";
      u[24] = "\u001e\u0012\u007f;\u000f_k2t4\u001e\u0010\n<\u007f?\u001aJ~";
      u[25] = "\u000e<\u0002\u0019\u0013J{\u001c\t\u0016\u0002\u0005\u001a\u0012\u0002\u001d\u0006_n";
      u[26] = "`q\u000eGLLvq\u000b\u001d_[a:\b\u001bSOp}\u001f\f\u0018XJ";
      u[27] = "*Q#N7+_q(A&d>\u007f#J\">J";
      u[28] = "\u001d&\u000eX( h\u0006\u0005W9o\t\b\u000e\\=5}";
      u[29] = "GWEeFi2wNjW&SyEaS|'";
      u[30] = "7\u0003hHd\u001d7\u0003\u007f\u0014h\u0012-H\u007f\nh\u0007*9.P?@";
      u[31] = double.class;
      v[31] = "java/lang/Double";
      u[32] = "\u001f\u001c^6\u0015p\u001f\u001cIj\u0019\u007f\u0005WIt\u0019j\u0002&\u0018/L*";
      u[33] = "qYgP#\rgYb\n0\u001ap\u0012a\f<\u000eaUv\u001bw\u001fq";
      u[34] = "\u0003\b\"6\u001ekv()9\u000f$\u0017&\"2\u000b~c";
      u[35] = "\u0000S7B{\u001e\u0000S \u001ew\u0011\u001a\u0018 \u0000w\u0004\u001diqY/A";
      u[36] = "1\u00127v<sD2<y-<%<7r)fQ";
      u[37] = "G!v5K\u00172\u0001}:ZXS\u000fv1^\u0002'";
      u[38] = "\u0016\u0019\u0017\u0007,Z\u0000\u0019\u0012]?M\u0017R\u0011[3Y\u0006\u0015\u0006LxH\u0017";
      u[39] = "~H\u001aumw\u000bh\u0011z|8jf\u001aqxb\u001e";
      u[40] = float.class;
      v[40] = "java/lang/Float";
      u[41] = "A%CR2\u000fA%T\u000e>\u0000[nT\u0010>\u0015\\\u001f\u0006NfQ";
      u[42] = "?c\u00186wK4l\ty\u001fK:c\u001a";
      u[43] = "M\u0012F\u0011\u000f\\F\u001dW^lQS\u001b";
      u[44] = "%r=+V53r8qE\"$9;wI65~,`\u0002#\u0014";
      u[45] = "c\u007fYI\u00025\u0016_RF\u0013zwQYM\u0017 \u0003";
      u[46] = "eH_\u001f\u000f@eHHC\u0003O\u007f\u0003H]\u0003Zxr\u001a\u0007W\u001e";
      u[47] = "\u0011)x\u0001\u0014\r\u0007)}[\u0007\u001a\u0010b~]\u000b\u000e\u0001%iJ@\u001c7";
      u[48] = "d\u0011k{=x\u00111`t,7p?k\u007f(m\u0004";
      u[49] = "\\+\u001aK\u000e/A>BiO\"Y8";
      u[50] = ":\u0005N!\u0000C1\n_nl@?\b]!@";
      u[51] = "\u0005U;\n~kpu0\u0005o$\u0011{;\u000ek~e";
      u[52] = "n>2$?\"x>7~,5ou4x !~2#ok6|";
      u[53] = "wF\u000f\u00101\u001f\u0002f\u0004\u001f Pch\u000f\u0014$\n\u0017";
      u[54] = "6wR%n}CWY*\u007f2\"YR!{hV";
      u[55] = "\u0007+S\u0000\u0016ir\u000bX\u000f\u0007&\u0013\u0005S\u0004\u0003|g";
      u[56] = "&,-OukS\f&@d$2\u0002-K`~F";
      u[57] = "\u0010X~'!\b\u001bWohK\u000b\u000f[d#";
      u[58] = "\u001fK\f\u0011~\r\n\u0001\ba\u007f2C@[]~U\u001a\u0017M\u0010l2C\u001cK_j\u000b\b\u0006\u000f\u0007\u0015";
      u[59] = "!~DH<t44@8=K?#\u001dE9+$uG^W";
      u[60] = "Yh18q\u0011K$qi\u0014\u0017S{o2h\u0010S\u001ap %\u0017LvbleF)";
      u[61] = "x\u0006\rqh|/\u0006U7U~%\u001aQ\nnlyADeov(\u00155";
      u[62] = "\tZ(h\u001e\u0018\bI;l{\u00052\u0012xzG\fUK/l\n\u001e2\u0012$jE\u0018\u000bY>.\u001dg";
      u[63] = "j(\u0003Rw\u001c{7\u0014UMCw1mB Fk9\rYv\u001cpW\u0016T-[x7\r\u0002w@\u0016,\u0000Y0Hv7V\u0003+&";
      u[64] = "\u00050t!\u001bG\u001e-c*!Y\u00012d=MkQp>j!\u0002Tvf:@\r\u0016/4Z";
      u[65] = "\u00142VO\u00166E5OMz9I1WF\u0016\u000b\u001dp\t\u001bzmO(H\u001aK7_*I!";
      u[66] = "zbJ4#wi2K6Qn\u00155Obmlrl\u0018t ~\u0015c\u001a2iuepJ3k\u0007";
      u[67] = "Df\u0010\u000eV%\u0003:J\u0007YC\u0013^JYW\u007f\u00169\u0013\u000eA2\u0004^J\u0005G}\u0002g\u0001\u001f\u0003%}";
      u[68] = "A\u0012p28\b\u0016\u0005r0Q\u000f+D&3m\rL\u001dq% \u001f+\u0006p=,\bK\u001d&g7f";
      u[69] = "@\u0019UP\u001an\u0013FLQf;I^TC\u001aU@\u0019UP\u001an\u0013FLQfl\u0015J\rA\u00015B\\@Sf;\u0013@KV]hLYJ*";
      u[70] = "XG{KpJ\u001b\ri\u0004\u0001NeE<\u001a=L\u0002\u001ck\fp^eE`\n?X\\\u000ezNg'";
      u[71] = "v hA\u0013Xg?\u007fF)\u0019s%z*M\u001b6\"d\u0015\u0015\u0018df\u0006NP^w=9\u0016S\f3_";
      u[72] = "@?wg9W\u0013`nfE\u0001W\u007fzy>l\u0015h(\"4\u0003\u0014ryvE\u0007Je~oz\u0006Cfm\u001d";
      u[73] = "\u0007|$\nwmImeS\u00149Y`x\u0001Cn\u00030&mp.\u0004p~R(-V4";
      u[74] = "\u0012`\u0013;{,\\qRb\u0018xL|O0O/\u0016,\u0012\\|o\u0011lIc$lC(";
      u[75] = "H>?\u000f'Y\u00109+\u0018NIKc*5t\u0012\u001c=R]?\u001aKeh\u0013.[\u0012\u0006";
      u[76] = "WVIjXiVEZn=\u007fl\u001bXu\u0004.\u001cUP&L\u0016P]A/\u0005f\u001eU\u0012g=";
      u[77] = "\u0006IC0\u001c%\u001dTT;&;\u0002KS,J\tR\t\u000fz&:\u0016\u000bN)\u0019b\u0015Y\nKB'SJQt\u001a$\u0001\u000e3/_b\u0012U\fw\\0V7W2\u001a#\r\b\u000f1Hgo";
      u[78] = "[Yh2e\f\fY0tX\u001f\rMPr2M^P?s(\u001c\n!;-?\u001b\u0013\u001e:$<\ba";
      u[79] = "Jj1i1\u0015\u0004{p0RJ\u0018gii>xL#37n/\u0011b5s0\u0010Iag7R";
      u[80] = "}^k9\u000e:(Aya0.C\u0006)m\f/$_~{A=C\u0000c;W'yNrz\u000eD";
      u[81] = "Bv\u0004\t\bTW<\u0000y\nk\\+]\u0004\r\u000bG}\u0007\u001fc";
      u[82] = "2YX\u001a1\u001b'\u0013\\j7$nR\u000fV1C7\u0005\u0019\u001b#$,\u0004\u0001\u00174D7R[\fZ";
      u[83] = "w:\u001d$:}&=\u0004&Vy&(\u0018&\u0001.yuCJ?|6&\u0003s7mw8";
      u[84] = ">`i>'x6etg\u0018/_b/5$-8;x#i?_:/&}ya2*;$F";
      u[85] = "hP'^\u0005>jU1_h=\u0015\u0014l\rT<rM;\u001b\u0019.\u0015S)\u0006\u00116+\\,\u001d\u000bW";
      u[86] = "\u000b\t9[\u001a\u0016\u0010\u0014.P \b\u000f\u000b)GL:\\Np\u001d \u0006\u0006\u0010$R\u001f\u0007\u000f\u00137 ";
      u[87] = "\u0016\u0006\u0004~\u001b UL\u00161j'+\u0003@y\b-J\f\u0002 ZM";
      u[88] = "{y\u001d+/js|\u0000r\u0010=\u001a{[ ,?}\"\f6a-\u001a)\u0004)}&%(\r*nT";
      u[89] = "cXRJh*-I\u0013\u0013\u000bu1U\nJgGe\u0011P\u00145\u00108PVPi/`S\u0004\u0014\u000b";
      u[90] = "(yl%\u0004\u001b3d{.>\u0005,{|9R7|7!n>\u001b:f$%C\u001f'{c^Z\u0019}z~a\u0002\u001a/>\u001c";
      u[91] = "]\u0005U=G\u000f\u001eOGr6\t`\u0000\u0011:T\u0002\u0001\u000fSc\u0006b";
      u[92] = "q}7d6Nf0/5JEd*12#I]$1\"'/h)228\u0010i 1!J";
      u[93] = "4\u0002x1]2c\u0015z346^T.0\b79\ry&E%^\u0006q9Y.a\u0007x:J\\";
      u[94] = "PM\u0016;s~E\u0007\u0012KqA\fFAws&U\u0011W:aAPM\u0016;s~E\u0007\u0012K";
      u[95] = "\u0005i\u0005\u0014\u00165\u000bk\u000b\nu&k=Q@J>\u0004<K\u0011\u001eO";
      u[96] = "n\f\u001ak\\~ \u001d[2?*0\u0010F`h}j@\u001a\f[=m\u0000@3\u0003>?D";
      u[97] = ".T{RV\u0005`E:\u000b5Z|Y#RYh(\u001dy\f\b?u\\\u007fHW\u0000-_-\f5";
      u[98] = "\u0011`j\u000b.\r@gs\tB\t@ro\t\u0015^\u001e%7e+\u0019Qd1\u001e0\u0004Fo";
      u[99] = "\bwSq\u0011d_`Qsxcb!\u0005pDa\u0005xRf\tsb!Y`Fu[jC$\u001e\n";
      u[100] = "\u001dN]}U\u0018\u001b\u0017\nh+\u0011\u0015Q\u0003tG#A\u0014S*\u001btF\u0015[qK\u0015IW\u0002#+";
      u[101] = "\u0014-<SszZ<}\n\u0010.J1`XGy\u0010a?4/1\u0013;g\u000ea Rb";
      u[102] = "k>~\u0013\u000f<| /R4k\u0012fy\u0007\biu?.\u0011E{\u00128-\u0017Q<h6;WP\u0002";
      u[103] = "z7(o\u0016?/l?<k+\u0016ob;W)q65-\u001a;\u0016o>+U=/$$o\rB";
      u[104] = "s\u0016\u0006\u0017.v}\u0013A\u0007\u001e \u0003\u0016F\u0006\"'dO\u0011\u0010o5\u0003_\u000fYt)oMC\u0019%L";
      u[105] = " mbFjy1ruAP(1sh-4:`on\u0012l92+\fI)\u007f!p3\u0011*-e\u0012";
      u[106] = "S9aM\u0005j]<&]5:#9!\\\t;D`vJD)#ph\u0003_5Ob$C\u000eP";
      u[107] = "il\u001fn\u0014%iaBq+/qfM}u(q|I\u0001P,u|JaKz/g$";
      u[108] = "$T4fO\u0006(\u0006k'5\u001fBThp\t\u001d%\r?fD\u000fB\n<`PH8\u0004* Qv";
      u[109] = "C<u3]7\u0014<-u`,\u0002\t(0\u001c<y/)/\r?F. ,\u001eM";
      u[110] = "@6<S/2\u001er;\n=X\u0007ca\u00172\u001f\u0017\na\u0013c%\u001b59\u00101ay39Sf(\u0013m}T?:y";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = u[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(v[var4]);
            u[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            u[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  u[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(335964491816232L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  u[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(335964491816232L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        u[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(335964491816232L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 208;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 111;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 84;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 205;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 225;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 75;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 208;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 111;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 84;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eD_C0223",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eD" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(FakeLag var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eD_C0223;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eD_C0223", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FakeLag)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(FakeLag var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eD_C0223;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eD_C0223", "lambda$new$4", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FakeLag)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(FakeLag var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eD_C0223;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eD_C0223", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FakeLag)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(FakeLag var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eD_C0223;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eD_C0223", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((FakeLag)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(FakeLag var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eD_C0223;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eD_C0223", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((FakeLag)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static String invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = b(MethodHandles.lookup(), "h", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static float invokeBinding7(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = c(MethodHandles.lookup(), "á", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding8(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Double invokeBinding9(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(MethodHandles.lookup(), "K", SourceSupport.methodType("(DJJ)Ljava/lang/Double;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding10(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache10;
         MethodHandle var9 = bindingCache10;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache10 = c(
                  MethodHandles.lookup(), "K", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
