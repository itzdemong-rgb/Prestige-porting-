package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;

public class FastBridge extends Module {
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final long k = 11453445353553L;
   private static final Object[] l = new Object[37];
   private static final String[] m = new String[37];

   @EventListener
   public void a(TickEvent var1) {
      int var6;
      byte var59;
      label88: {
         byte var58;
         label87: {
            label91: {
               long var10001 = 65945643751845L ^ 31580537775734L;
               var6 = Event.cReturningInt();
               MinecraftClient var9 = b;
               ClientPlayerEntity var10 = var9.player;
               ItemStack var11 = var10.getMainHandStack();
               byte var10000 = ((byte)((var11.getItem() instanceof BlockItem) ? 1 : 0));
               int var75 = var6;
               byte var74 = var10000;
               byte var56 = var74;
               byte var55 = var74;
               if (var75 != 0) {
                  byte var76 = var55;
                  if (var76 != 0) {
                     break label91;
                  }

                  MinecraftClient var13 = b;
                  ClientPlayerEntity var14 = var13.player;
                  ItemStack var15 = var14.getOffHandStack();
                  byte var77 = ((byte)((var15.getItem() instanceof BlockItem) ? 1 : 0));
                  var56 = var77;
               }

               int var79 = var6;
               byte var78 = var56;
               var58 = var78;
               byte var57 = var78;
               if (var79 == 0) {
                  break label87;
               }

               byte var80 = var57;
               if (var80 == 0) {
                  var58 = 1;
                  break label87;
               }
            }

            var59 = 0;
            break label88;
         }

         byte var81 = var58;
         var59 = var81;
      }

      int var7;
      label75: {
         var7 = var59;
         MinecraftClient var18 = b;
         ClientPlayerEntity var19 = var18.player;
         float var111;
         int var105 = (var111 = var19.getPitch() - 70.0F) == 0.0F ? 0 : (var111 < 0.0F ? -1 : 1);
         int var83 = var6;
         int var82 = var105;
         int var61 = var82;
         int var60 = var82;
         if (var83 != 0) {
            int var84 = var60;
            if (var84 >= 0) {
               break label75;
            }

            var61 = 1;
         }

         var7 = var61;
      }

      int var68;
      label69: {
         label68: {
            byte var67;
            Object[] var21 = new Object[]{43167644123091L};
            Vec3d var22 = RaycastUtil.bReturningVec3d(var21);
            BlockPos var23 = BlockPos.ofFloored((Position)var22);
            BlockPos var8 = var23.down();
            MinecraftClient var24 = b;
            BlockPos var26 = var8;
            ClientWorld var25 = var24.world;
            BlockState var27 = var25.getBlockState(var26);
            byte var106 = ((byte)((var27.isReplaceable()) ? 1 : 0));
            int var86 = var6;
            byte var85 = var106;
            var67 = var85;
            byte var62 = var85;
            label67:
            if (var86 != 0) {
               byte var87 = var62;
               if (var87 != 0) {
                  MinecraftClient var29 = b;
                  ClientWorld var107 = var29.world;
                  BlockPos var30 = var8;
                  BlockPos var32 = var30.down();
                  ClientWorld var31 = var107;
                  BlockState var33 = var31.getBlockState(var32);
                  var106 = ((byte)((var33.isReplaceable()) ? 1 : 0));
                  int var89 = var6;
                  byte var88 = var106;
                  var67 = var88;
                  byte var63 = var88;
                  if (var89 == 0) {
                     break label67;
                  }

                  byte var90 = var63;
                  byte var64 = var90;
                  byte var91 = var64;
                  if (var91 != 0) {
                     MinecraftClient var36 = b;
                     ClientWorld var109 = var36.world;
                     BlockPos var37 = var8;
                     BlockPos var38 = var37.down();
                     BlockPos var40 = var38.down();
                     ClientWorld var39 = var109;
                     BlockState var41 = var39.getBlockState(var40);
                     var106 = ((byte)((var41.isReplaceable()) ? 1 : 0));
                     int var93 = var6;
                     byte var92 = var106;
                     var68 = var92;
                     byte var65 = var92;
                     if (var93 == 0) {
                        break label69;
                     }

                     byte var94 = var65;
                     byte var66 = var94;
                     byte var95 = var66;
                     if (var95 != 0) {
                        break label68;
                     }
                  }
               }

               var67 = 1;
            }

            var7 = var67;
         }

         var68 = var7;
      }

      FastBridge var73;
      label92: {
         int var97 = var6;
         int var96 = var68;
         int var72 = var96;
         int var69 = var96;
         if (var97 != 0) {
            int var98 = var69;
            if (var98 == 0) {
               MinecraftClient var52 = b;
               GameOptions var53 = var52.options;
               KeyBinding var54 = var53.sneakKey;
               var54.setPressed(true);
               this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
               return;
            }

            int var100 = var6;
            FastBridge var99 = this;
            var73 = var99;
            FastBridge var70 = var99;
            if (var100 == 0) {
               break label92;
            }

            FastBridge var101 = var70;
            FastBridge var71 = var101;
            byte var102 = ((byte)((var71.i) ? 1 : 0));
            var72 = var102;
         }

         int var103 = var72;
         if (var103 == 0) {
            return;
         }

         MinecraftClient var47 = b;
         GameOptions var48 = var47.options;
         KeyBinding var49 = var48.sneakKey;
         var49.setPressed(false);
         FastBridge var104 = this;
         var73 = var104;
      }

      var73.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 11;
            yield var15;
         }
         case 1 -> {
            byte var16 = 27;
            yield var16;
         }
         case 2 -> {
            byte var17 = 63;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 32;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 56;
            yield var21;
         }
         case 7 -> {
            byte var22 = 42;
            yield var22;
         }
         case 8 -> {
            byte var23 = 62;
            yield var23;
         }
         case 9 -> {
            byte var24 = 13;
            yield var24;
         }
         case 10 -> {
            byte var25 = 19;
            yield var25;
         }
         case 11 -> {
            byte var26 = 55;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 10;
            yield var28;
         }
         case 14 -> {
            byte var29 = 48;
            yield var29;
         }
         case 15 -> {
            byte var30 = 2;
            yield var30;
         }
         case 16 -> {
            byte var31 = 52;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 46;
            yield var33;
         }
         case 19 -> {
            byte var34 = 16;
            yield var34;
         }
         case 20 -> {
            byte var35 = 37;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 57;
            yield var38;
         }
         case 24 -> {
            byte var39 = 28;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 17;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 45;
            yield var44;
         }
         case 30 -> {
            byte var45 = 7;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 35;
            yield var47;
         }
         case 33 -> {
            byte var48 = 6;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 4;
            yield var50;
         }
         case 36 -> {
            byte var51 = 8;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 49;
            yield var53;
         }
         case 39 -> {
            byte var54 = 34;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 33;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 54;
            yield var59;
         }
         case 45 -> {
            byte var60 = 53;
            yield var60;
         }
         case 46 -> {
            byte var61 = 40;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 14;
            yield var63;
         }
         case 49 -> {
            byte var64 = 12;
            yield var64;
         }
         case 50 -> {
            byte var65 = 23;
            yield var65;
         }
         case 51 -> {
            byte var66 = 38;
            yield var66;
         }
         case 52 -> {
            byte var67 = 18;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 43;
            yield var69;
         }
         case 55 -> {
            byte var70 = 61;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 59;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 22;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 58;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u001cQB\u0016\u0015B\u001cQUJ\u0019M\u0006\u001aUT\u0019X\u0001k\u0005\tH";
      l[1] = "j/\u000b\u0004IAj/\u001cXENpd\u001cFE[w\u0015L\u001b\u0011";
      l[2] = "CPI61\u0018CP^j=\u0017Y\u001b^t=\u0002^j\f/eH";
      l[3] = "}No+\u0011.}Nxw\u001d!g\u0005xi\u001d4`t*2Eu";
      l[4] = "8Yod\u000bN8Yx8\u0007A\"\u0012x&\u0007T%c,~P";
      l[5] = "\u0004<o2x%\u0012<jhk2\u0005wing&\u00140~y,4%";
      l[6] = int.class;
      m[6] = "java/lang/Integer";
      l[7] = "\u0012<})U2\u0012<juY=\bwjkY(\u000f\u0006:7\f";
      l[8] = "XU+gq\u0003NU.=b\u0014Y\u001e-;n\u0000HY:,%\u0010\u000f";
      l[9] = "\u000ecW\u001b\u0001&{C\\\u0014\u0010i\u001aMW\u001f\u00143n";
      l[10] = "\u007fjTI%7\u007fjC\u0015)8e!C\u000b)-bP\u0012S{";
      l[11] = boolean.class;
      m[11] = "java/lang/Boolean";
      l[12] = void.class;
      m[12] = "java/lang/Void";
      l[13] = "or?~s\u0015or(\"\u007f\u001au9(<\u007f\u000frHyc-D";
      l[14] = "9N\u001c>bO9N\u000bbn@#\u0005\u000b|nU$t^#7";
      l[15] = float.class;
      m[15] = "java/lang/Float";
      l[16] = "\n\u00048#B*\n\u0004/\u007fN%\u0010O/aN0\u0017>~>\u0018w";
      l[17] = "\u0016\u001at\u000f:F\u0000\u001aqU)Q\u0017QrS%E\u0006\u0016eDnS7";
      l[18] = "TO\u007fyX\u0018_@n6;\u0015JMa]\u000e\u0017[^}q\u0019\u001a";
      l[19] = "HI&1'\u0012HI1m+\u001dR\u00021s+\bUs`)rK";
      l[20] = "x2!NP/s=0\u00011!x64[";
      l[21] = "v5:3?-v(3\u0002j.{7.U=q'kB;m0m50l4t-";
      l[22] = "Us4*8m\u0014p4iF2\u0001o3w*\u0000S\"k!FmR|(n$4\u0007,\"\u0010";
      l[23] = "Yn\b)H\u001f\u001b!\bxrE\u000f#S%\u001ew\\g\u000f}r\u0019\u00028\t<HX\u00018JB";
      l[24] = "-|Ih9bw \u0005oYr\u0011x]l( ax\u0004{6\u0019";
      l[25] = "x&>Mdx/\u007fz\r\u0002d \"%ZU3qt{6?c 2|\bh`33";
      l[26] = "l\fJ@7<.\u0018\u001aYY2QBSO&(/\u000eMK2Xn\u0018\u0011Ha:+A\u0016YY";
      l[27] = "@o0\u0000Hx\u0017l#\u0001u#\u0010z1\u001a\u0019\u0011G=mMLFMo#A\u0012<\u0011e#\fuv\u001c|=\u001c\r(\u0004m6}";
      l[28] = "C\u001cf=2W\u0017C6zMQ\u001f\u000f<$!cKKd|q4C\u001cf=2W\u0017C6zM";
      l[29] = "\t`U/8O\t}\\\u001emL\u0004bAI:\u0013Y9-/r\u0017\u0018:\u0012#=UR";
      l[30] = "\u0000=\u007fub;Br\u007f$XaVp$y4S\u00002x#e\u0004Rs8d!<K7\"qX";
      l[31] = "%`\u0019\u0003\u0016g%}\u00102Cd(b\re\u0014:\u007f:a\t\u001c>.<^KS>\u007f";
      l[32] = "\u001aMMX\u001b)X\u0002M\t!sL\u0000\u0016TMA\u001fDI\u0002!/A\u001bLM\u001bnB\u001b\u000f3";
      l[33] = ":}M\u0015\u0005\u0019n\"\u001dRz\u001ffn\u0017\f\u0016-7#IPJzaxI\u0001AAl/\u0012\u0006zKd(\t\u0014\u0019\u001f;xNk";
      l[34] = "-5_W\u0006\u000f~ \rWf\u001aG/F\u0010Y\u0015;&\u0003SWs,>DW\u0000\u000f%{\u0007Yf";
      l[35] = "Y\u001f\u00171/MQ^\r.\u0011RX]\u00149}`\t\u001cHa-7\u0005H\u0006bvMYB\u0006/\u0011";
      l[36] = "{D\u000b\u0006rTw\u000bILN\u000e'IQ\u0010\"<z\u000e\u000bONZ%\u000fO\b-\u000ez_\bw\"U)Z\u000f\r*\u00143E1";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1452654262782166L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1452654262782166L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1452654262782166L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 194;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 104;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 205;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 68;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 196;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 84;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 194;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 104;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 205;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eE_C0225",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eE" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
