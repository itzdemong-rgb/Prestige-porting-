package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import org.lwjgl.glfw.GLFW;

public class FastEXP extends Module implements RotationSource {
   private ModeSetting a;
   private MinMaxSetting c;
   private BooleanSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private ElapsedTimer g;
   private int h;
   private int i;
   private static final long k = 7121527586720L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[128];
   private static final String[] s = new String[128];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public FastEXP() {
      super();
      long var10001 = 111956023330743L ^ 5327180034206L;
      var10001 = 111956023330743L ^ 58357928496155L;

      this.g = new ElapsedTimer(106698256430889L);
      this.h = -1;
      this.i = -1;
      BooleanSetting var10000 = this.e;
      Object[] var8 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var7 = var10000;
      var7.aReturningBooleanSetting(var8);
      var10000 = this.f;
      Object[] var10 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var9 = var10000;
      var9.aReturningBooleanSetting(var10);
      var10000 = this.d;
      Object[] var12 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var11 = var10000;
      var11.aReturningBooleanSetting(var12);
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 100337629420687L ^ 64492581678572L;
      Object[] var7 = new Object[]{107642444427619L};
      FastEXP var6 = this;
      boolean var10 = var6.fReturningBoolean(var7);
      if (var10) {
         Object[] var9 = new Object[0];
         ItemUseEvent var8 = var1;
         var8.aReturningVoid(var9);
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 140663824480209L;
      long var6 = var2 ^ 89714324847032L;
      int var8 = Event.cReturningInt();
      int var31 = var8;
      MinecraftClient var30 = b;
      MinecraftClient var25 = var30;
      MinecraftClient var24 = var30;
      if (var31 != 0) {
         MinecraftClient var9 = var24;
         Screen var32 = var9.currentScreen;
         if (var32 != null) {
            return null;
         }

         MinecraftClient var33 = b;
         var25 = var33;
      }

      FastEXP var29;
      label35: {
         MinecraftClient var12 = var25;
         boolean var10000 = var12.isWindowFocused();
         int var35 = var8;
         boolean var34 = var10000;
         boolean var28 = var34;
         boolean var26 = var34;
         if (var35 != 0) {
            boolean var36 = var26;
            if (!var36) {
               return null;
            }

            int var38 = var8;
            FastEXP var37 = this;
            var29 = var37;
            FastEXP var27 = var37;
            if (var38 == 0) {
               break label35;
            }

            ModeSetting var15 = var27.a;
            String var41 = (String)var15.aReturningObject();
            short var10001 = 5678;
            long var10002 = 2511041170134809217L ^ var2;
            String var17 = "Automatic";
            String var16 = var41;
            boolean var39 = var16.equals(var17);
            var28 = var39;
         }

         boolean var40 = var28;
         if (var40) {
            Object[] var20 = new Object[]{var6};
            FastEXP var19 = this;
            return var19.cReturningdx_C0210(var20);
         }

         var29 = this;
      }

      Object[] var23 = new Object[]{var4};
      FastEXP var22 = var29;
      return var22.bReturningdx_C0210(var23);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      long var4 = var2 ^ 39593986363762L;
      long var6 = var2 ^ 87792511344692L;
      long var8 = var2 ^ 59576793456222L;
      long var10 = var2 ^ 108927089035281L;
      long var12 = var2 ^ 56025161103978L;
      long var14 = var2 ^ 130627542817436L;
      int var16 = Event.cReturningInt();
      Object[] var19 = new Object[]{var4};
      FastEXP var18 = this;
      byte var10000 = ((byte)((var18.fReturningBoolean(var19)) ? 1 : 0));
      int var78 = var16;
      byte var77 = var10000;
      int var66 = var77;
      byte var65 = var77;
      if (var78 != 0) {
         byte var79 = var65;
         if (var79 == 0) {
            return null;
         }

         MinecraftClient var21 = b;
         Window var22 = var21.getWindow();
         long var23 = var22.getHandle();
         int var80 = GLFW.glfwGetMouseButton(var23, 1);
         var66 = var80;
      }

      int var82 = var16;
      int var81 = var66;
      int var68 = var81;
      int var67 = var81;
      if (var82 != 0) {
         byte var84 = 1;
         int var83 = var67;
         if (var83 != var84) {
            return null;
         }

         ElapsedTimer var104 = this.g;
         Object[] var29 = new Object[]{this.c, var12};
         ElapsedTimer var28 = var104;
         byte var85 = ((byte)((var28.bReturningBoolean(var29)) ? 1 : 0));
         var68 = var85;
      }

      int var75;
      int var87 = var16;
      int var86 = var68;
      var75 = var86;
      int var69 = var86;
      label55:
      if (var87 != 0) {
         int var88 = var69;
         if (var88 != 0) {
            MinecraftClient var32 = b;
            ClientPlayerEntity var33 = var32.player;
            float var17 = var33.getPitch();
            BooleanSetting var34 = this.d;
            Boolean var35 = (Boolean)var34.aReturningObject();
            boolean var89 = var35;
            if (var89) {
               MinecraftClient var36 = b;
               float var38 = 90.0F;
               ClientPlayerEntity var37 = var36.player;
               var37.setPitch(var38);
            }

            Object var73;
            MinecraftClient var40 = b;
            int var91 = var16;
            HitResult var90 = var40.crosshairTarget;
            var73 = var90;
            HitResult var70 = var90;
            label49:
            if (var91 != 0) {
               HitResult var92 = var70;
               if (var92 != null) {
                  MinecraftClient var42 = b;
                  HitResult var43 = var42.crosshairTarget;
                  Type var105 = var43.getType();
                  int var94 = var16;
                  Type var93 = var105;
                  var73 = var93;
                  Type var71 = var93;
                  if (var94 == 0) {
                     break label49;
                  }

                  Type var95 = var71;
                  Type var72 = var95;
                  Type var97 = Type.BLOCK;
                  Type var96 = var72;
                  if (var96 == var97) {
                     MinecraftClient var46 = b;
                     Object[] var47 = new Object[]{(BlockHitResult)var46.crosshairTarget, var6};
                     ItemUseUtil.aReturningBoolean(var47);
                  }
               }

               Object[] var49 = new Object[]{Hand.MAIN_HAND, var14};
               ItemUseUtil.cReturningBoolean(var49);
               MinMaxSetting var106 = this.c;
               Object[] var51 = new Object[]{var8};
               MinMaxSetting var50 = var106;
               var50.bReturningVoid(var51);
               ElapsedTimer var107 = this.g;
               Object[] var53 = new Object[]{var10};
               ElapsedTimer var52 = var107;
               var52.aReturningVoid(var53);
               BooleanSetting var54 = this.d;
               var73 = var54.aReturningObject();
            }

            Boolean var55 = (Boolean)var73;
            var10000 = ((byte)(((java.lang.Boolean)(var55)).booleanValue() ? 1 : 0));
            int var99 = var16;
            byte var98 = var10000;
            var75 = var98;
            byte var74 = var98;
            if (var99 == 0) {
               break label55;
            }

            byte var100 = var74;
            if (var100 != 0) {
               MinecraftClient var57 = b;
               float var59 = var17;
               ClientPlayerEntity var58 = var57.player;
               var58.setPitch(var59);
            }
         }

         BooleanSetting var61 = this.d;
         Boolean var62 = (Boolean)var61.aReturningObject();
         var75 = ((((java.lang.Boolean)(var62)).booleanValue() ? 1 : 0));
      }

      int var101 = var75;
      Rotation var76;
      if (var101 != 0) {
         MinecraftClient var63 = b;
         ClientPlayerEntity var64 = var63.player;
         Rotation var102 = new Rotation(var64.getYaw(), 90.0F);
         var76 = var102;
      } else {
         var76 = null;
      }

      return var76;
   }

   private Rotation cReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      long var4 = var2 ^ 11494779707163L;
      long var6 = var2 ^ 28528690644073L;
      long var8 = var2 ^ 107400729144925L;
      long var10 = var2 ^ 26773393805367L;
      long var12 = var2 ^ 84809664417390L;
      long var14 = var2 ^ 85106778572408L;
      long var16 = var2 ^ 93586116403303L;
      long var18 = var2 ^ 28847971588830L;
      long var20 = var2 ^ 31347774043139L;
      long var22 = var2 ^ 97551583106293L;
      int var10000 = Event.bReturningInt();
      Object[] var28 = new Object[]{var16};
      FastEXP var27 = this;
      boolean var25 = var27.eReturningBoolean(var28);
      int var24 = var10000;
      int var111 = var24;
      boolean var110 = var25;
      boolean var88 = var110;
      boolean var87 = var110;
      if (var111 == 0) {
         boolean var112 = var87;
         if (!var112) {
            Object[] var31 = new Object[]{var6};
            FastEXP var30 = this;
            var30.jReturningVoid(var31);
            return null;
         }

         Object[] var34 = new Object[]{var4};
         FastEXP var33 = this;
         var88 = var33.fReturningBoolean(var34);
      }

      int var114 = var24;
      boolean var113 = var88;
      boolean var105 = var113;
      boolean var89 = var113;
      if (var114 == 0) {
         boolean var115 = var89;
         if (!var115) {
            int var102;
            label94: {
               int var118 = var24;
               // int var116 = this.h;
               int var100 = var116;
               byte var101 = var117;
               int var90 = var116;
               byte var91 = var117;
               if (var118 == 0) {
                  int var98;
                  label74: {
                     byte var120 = var91;
                     int var119 = var90;
                     int var92 = var119;
                     byte var93 = var120;
                     byte var122 = var93;
                     int var121 = var92;
                     label73:
                     if (var121 != var122) {
                        int var124 = var24;
                        PacketQueueManager var123 = Prestige.u;
                        PacketQueueManager var96 = var123;
                        PacketQueueManager var94 = var123;
                        if (var124 == 0) {
                           PacketQueueManager var125 = var94;
                           PacketQueueManager var95 = var125;
                           PacketQueueManager var126 = var95;
                           if (var126 == null) {
                              break label73;
                           }

                           var96 = Prestige.u;
                        }

                        Object[] var41 = new Object[]{var12};
                        PacketQueueManager var40 = var96;
                        byte var153 = ((byte)((var40.aReturningBoolean(var41)) ? 1 : 0));
                        int var128 = var24;
                        byte var127 = var153;
                        var98 = var127;
                        byte var97 = var127;
                        if (var128 != 0) {
                           break label74;
                        }

                        byte var129 = var97;
                        if (var129 != 0) {
                           return null;
                        }
                     }

                     var98 = this.h;
                  }

                  int var131 = var24;
                  int var130 = var98;
                  var102 = var130;
                  int var99 = var130;
                  if (var131 != 0) {
                     break label94;
                  }

                  // int var132 = var99;
                  var100 = var132;
                  var101 = var133;
               }

               byte var135 = var101;
               int var134 = var100;
               if (var134 != var135) {
                  Object[] var46 = new Object[]{var6};
                  FastEXP var45 = this;
                  var45.jReturningVoid(var46);
                  return null;
               }

               ElapsedTimer var154 = this.g;
               Object[] var49 = new Object[]{this.c, var20};
               ElapsedTimer var48 = var154;
               var102 = (((var48.bReturningBoolean(var49)) ? 1 : 0));
            }

            int var137 = var24;
            int var136 = var102;
            int var103 = var136;
            if (var137 == 0) {
               int var138 = var103;
               if (var138 == 0) {
                  return null;
               }

               Object[] var53 = new Object[]{var18};
               FastEXP var52 = this;
               boolean var104 = var52.dReturningBoolean(var53);
            }

            ElapsedTimer var155 = this.g;
            Object[] var55 = new Object[]{var14};
            ElapsedTimer var54 = var155;
            var54.aReturningVoid(var55);
            MinMaxSetting var156 = this.c;
            Object[] var57 = new Object[]{var10};
            MinMaxSetting var56 = var156;
            var56.bReturningVoid(var57);
            return null;
         }

         ElapsedTimer var149 = this.g;
         Object[] var59 = new Object[]{this.c, var20};
         ElapsedTimer var58 = var149;
         var105 = var58.bReturningBoolean(var59);
      }

      boolean var139 = var105;
      if (!var139) {
         MinecraftClient var60 = b;
         ClientPlayerEntity var61 = var60.player;
         return new Rotation(var61.getYaw(), 90.0F);
      }

      float var26;
      MinecraftClient var109;
      MinecraftClient var63 = b;
      ClientPlayerEntity var64 = var63.player;
      var26 = var64.getPitch();
      MinecraftClient var65 = b;
      float var67 = 90.0F;
      ClientPlayerEntity var66 = var65.player;
      var66.setPitch(var67);
      int var141 = var24;
      MinecraftClient var140 = b;
      var109 = var140;
      MinecraftClient var106 = var140;
      label86:
      if (var141 == 0) {
         MinecraftClient var68 = var106;
         HitResult var142 = var68.crosshairTarget;
         if (var142 != null) {
            int var144 = var24;
            MinecraftClient var143 = b;
            var109 = var143;
            MinecraftClient var107 = var143;
            if (var144 != 0) {
               break label86;
            }

            MinecraftClient var145 = var107;
            MinecraftClient var108 = var145;
            MinecraftClient var71 = var108;
            HitResult var72 = var71.crosshairTarget;
            Type var150 = var72.getType();
            Type var147 = Type.BLOCK;
            Type var146 = var150;
            if (var146 == var147) {
               MinecraftClient var74 = b;
               Object[] var75 = new Object[]{(BlockHitResult)var74.crosshairTarget, var8};
               ItemUseUtil.aReturningBoolean(var75);
            }
         }

         Object[] var77 = new Object[]{Hand.MAIN_HAND, var22};
         ItemUseUtil.cReturningBoolean(var77);
         var109 = b;
      }

      MinecraftClient var78 = var109;
      float var80 = var26;
      ClientPlayerEntity var79 = var78.player;
      var79.setPitch(var80);
      MinMaxSetting var151 = this.c;
      Object[] var82 = new Object[]{var10};
      MinMaxSetting var81 = var151;
      var81.bReturningVoid(var82);
      ElapsedTimer var152 = this.g;
      Object[] var84 = new Object[]{var14};
      ElapsedTimer var83 = var152;
      var83.aReturningVoid(var84);
      MinecraftClient var85 = b;
      ClientPlayerEntity var86 = var85.player;
      return new Rotation(var86.getYaw(), 90.0F);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      long var4 = var2 ^ 14137614465131L;
      long var6 = var2 ^ 99878272994313L;
      long var8 = var2 ^ 59514831294064L;
      long var10 = var2 ^ 124256252488475L;
      long var12 = var2 ^ 117720916098978L;
      int var10000 = Event.bReturningInt();
      Object[] var19 = new Object[]{var4};
      FastEXP var18 = this;
      int var15 = var18.dReturningInt(var19);
      int var14 = var10000;
      int var41 = var14;
      int var40 = var15;
      int var35 = var40;
      int var34 = var40;
      if (var41 == 0) {
         // int var42 = var34;
         if (var42 != var43) {
            Object[] var21 = new Object[]{var6};
            this.h = InventoryUtil.aReturningInt(var21);
            this.i = -1;
            Object[] var10003 = new Object[]{null, var8};
            var10003[0] = var15;
            Object[] var22 = var10003;
            InventoryUtil.aReturningVoid(var22);
            return true;
         }

         BooleanSetting var24 = this.e;
         Boolean var25 = (Boolean)var24.aReturningObject();
         var35 = ((((java.lang.Boolean)(var25)).booleanValue() ? 1 : 0));
      }

      int var45 = var14;
      int var44 = var35;
      int var37 = var44;
      int var36 = var44;
      if (var45 == 0) {
         int var46 = var36;
         if (var46 == 0) {
            return false;
         }

         Object[] var29 = new Object[]{var12};
         FastEXP var28 = this;
         var37 = var28.eReturningInt(var29);
      }

      int var16 = var37;
      int var48 = var14;
      int var47 = var16;
      int var39 = var47;
      int var38 = var47;
      if (var48 == 0) {
         // int var49 = var38;
         if (var49 == var50) {
            return false;
         }

         Object[] var32 = new Object[]{var6};
         var39 = InventoryUtil.aReturningInt(var32);
      }

      int var17 = var39;
      this.h = var17;
      this.i = var16;
      Object[] var10004 = new Object[]{null, null, var10};
      var10004[1] = var17;
      var10004[0] = var16;
      Object[] var33 = var10004;
      InventoryUtil.fReturningBoolean(var33);
      return true;
   }

   private void jReturningVoid(Object[] var1) {
      FastEXP var26;
      label42: {
         long var2 = (Long)var1[0];
         var2 = 7121527586720L ^ var2;
         long var4 = var2 ^ 59296503124167L;
         long var6 = var2 ^ 126221617460652L;
         int var8 = Event.cReturningInt();
         int var28 = var8;
         int var27 = this.h;
         int var22 = var27;
         int var20 = var27;
         if (var28 != 0) {
            // int var29 = var20;
            if (var29 == var30) {
               return;
            }

            int var32 = var8;
            FastEXP var31 = this;
            var26 = var31;
            FastEXP var21 = var31;
            if (var32 == 0) {
               break label42;
            }

            BooleanSetting var11 = var21.f;
            Boolean var12 = (Boolean)var11.aReturningObject();
            byte var33 = ((byte)(((java.lang.Boolean)(var12)).booleanValue() ? 1 : 0));
            var22 = var33;
         }

         int var34 = var22;
         label28:
         if (var34 != 0) {
            int var36 = var8;
            int var35 = this.i;
            int var25 = var35;
            int var23 = var35;
            if (var36 != 0) {
               int var37 = var23;
               int var24 = var37;
               // int var38 = var24;
               if (var38 != var39) {
                  int var10000 = this.i;
                  int var10001 = this.h;
                  Object[] var10004 = new Object[]{null, null, var6};
                  var10004[1] = var10001;
                  var10004[0] = var10000;
                  Object[] var16 = var10004;
                  InventoryUtil.fReturningBoolean(var16);
                  int var40 = var8;
                  if (var40 != 0) {
                     break label28;
                  }
               }

               int var41 = this.h;
               var25 = var41;
            }

            Object[] var10003 = new Object[]{null, var4};
            var10003[0] = var25;
            Object[] var19 = var10003;
            InventoryUtil.aReturningVoid(var19);
         }

         this.h = -1;
         var26 = this;
      }

      var26.i = -1;
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      int var15;
      do {
         short var10001 = 20986;
         long var10002 = 6315464656677312797L ^ var2;
         byte var12 = 8;
         int var11 = var5;
         if (var11 > var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.EXPERIENCE_BOTTLE;
         Item var13 = var18;
         if (var13 == var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 != 0);

      return -1;
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      int var10000 = Event.bReturningInt();
      short var10001 = 8474;
      long var10002 = 4085983489020227127L ^ var2;
      int var5 = 9;
      int var4 = var10000;

      int var15;
      do {
         var10001 = 30975;
         var10002 = 7180567271926544336L ^ var2;
         byte var12 = 35;
         int var11 = var5;
         if (var11 > var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.EXPERIENCE_BOTTLE;
         Item var13 = var18;
         if (var13 == var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 == 0);

      return -1;
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7121527586720L ^ var2;
      long var4 = var2 ^ 125197191976886L;
      int var10000 = Event.bReturningInt();
      AttributeModifierSlot var10 = AttributeModifierSlot.ARMOR;
      Iterator var7 = var10.iterator();
      int var6 = var10000;

      boolean var26;
      while (true) {
         Iterator var11 = var7;
         boolean var27 = var11.hasNext();
         if (var27) {
            Iterator var12 = var7;
            EquipmentSlot var8 = (EquipmentSlot)var12.next();
            MinecraftClient var13 = b;
            EquipmentSlot var15 = var8;
            ClientPlayerEntity var14 = var13.player;
            ItemStack var9 = var14.getEquippedStack(var15);
            Object[] var16 = new Object[]{var9, var4};
            boolean var36 = aReturningBoolean(var16);
            int var29 = var6;
            boolean var28 = var36;
            var26 = var28;
            boolean var22 = var28;
            if (var29 != 0) {
               break;
            }

            int var31 = var6;
            boolean var30 = var22;
            boolean var25 = var30;
            boolean var23 = var30;
            if (var31 != 0) {
               return var25;
            }

            boolean var32 = var23;
            boolean var24 = var32;
            boolean var33 = var24;
            if (var33) {
               return true;
            }

            int var34 = var6;
            if (var34 == 0) {
               continue;
            }
         }

         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         Object[] var21 = new Object[]{var20.getOffHandStack(), var4};
         var26 = aReturningBoolean(var21);
         break;
      }

      return var26;
   }

   private static boolean aReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 7121527586720L ^ var1;
      int var4 = Event.bReturningInt();
      ItemStack var7 = var3;
      byte var47 = ((byte)((var7.isEmpty()) ? 1 : 0));
      int var32 = var4;
      byte var31 = var47;
      byte var24 = var31;
      byte var21 = var31;
      if (var32 == 0) {
         byte var33 = var21;
         label50:
         if (var33 == 0) {
            int var35 = var4;
            ItemStack var34 = var3;
            ItemStack var25 = var34;
            ItemStack var22 = var34;
            if (var35 == 0) {
               ItemStack var36 = var22;
               ItemStack var23 = var36;
               ItemStack var10 = var23;
               boolean var37 = var10.isDamaged();
               if (!var37) {
                  break label50;
               }

               var25 = var3;
            }

            ItemStack var13 = var25;
            ItemEnchantmentsComponent var14 = var13.getEnchantments();
            Set var15 = var14.getEnchantmentEntries();
            Iterator var5 = var15.iterator();

            byte var30;
            while (true) {
               Iterator var16 = var5;
               boolean var39 = var16.hasNext();
               if (var39) {
                  Iterator var17 = var5;
                  Entry var6 = (Entry)var17.next();
                  Entry var18 = var6;
                  RegistryEntry var48 = (RegistryEntry)var18.getKey();
                  RegistryKey var20 = Enchantments.MENDING;
                  RegistryEntry var19 = var48;
                  byte var49 = ((byte)((var19.matchesKey(var20)) ? 1 : 0));
                  int var41 = var4;
                  byte var40 = var49;
                  var30 = var40;
                  byte var26 = var40;
                  if (var41 != 0) {
                     break;
                  }

                  int var43 = var4;
                  byte var42 = var26;
                  byte var29 = var42;
                  byte var27 = var42;
                  if (var43 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var29);
                  }

                  byte var44 = var27;
                  byte var28 = var44;
                  byte var45 = var28;
                  if (var45 != 0) {
                     var29 = 1;
                     return dev.prestige.recovery.SourceSupport.asBoolean(var29);
                  }

                  int var46 = var4;
                  if (var46 == 0) {
                     continue;
                  }
               }

               var30 = 0;
               break;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var30);
         }

         byte var38 = 0;
         var24 = var38;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   private boolean fReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 7121527586720L ^ var2;
      int var4 = Event.bReturningInt();
      MinecraftClient var5 = b;
      int var15 = var4;
      ClientPlayerEntity var14 = var5.player;
      ClientPlayerEntity var12 = var14;
      ClientPlayerEntity var11 = var14;
      if (var15 == 0) {
         ClientPlayerEntity var16 = var11;
         if (var16 == null) {
            return false;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var17 = var7.player;
         var12 = var17;
      }

      ClientPlayerEntity var9 = var12;
      ItemStack var10 = var9.getMainHandStack();
      Item var21 = var10.getItem();
      Item var19 = Items.EXPERIENCE_BOTTLE;
      Item var18 = var21;
      return var18 == var19;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 115623673590643L;
      int var10000 = Event.bReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var10 = new Object[]{this, var4};
      RotationManager var9 = var10001;
      var9.eReturningVoid(var10);
      int var8 = var10000;
      int var30 = var8;
      FastEXP var29 = this;
      FastEXP var28 = var29;
      FastEXP var22 = var29;
      if (var30 == 0) {
         // int var31 = var22.h;
         label30:
         if (var31 != var32) {
            int var34 = var8;
            MinecraftClient var33 = b;
            MinecraftClient var25 = var33;
            MinecraftClient var23 = var33;
            if (var34 == 0) {
               MinecraftClient var35 = var23;
               MinecraftClient var24 = var35;
               MinecraftClient var13 = var24;
               ClientPlayerEntity var36 = var13.player;
               if (var36 == null) {
                  break label30;
               }

               MinecraftClient var37 = b;
               var25 = var37;
            }

            int var39 = var8;
            MinecraftClient var38 = var25;
            MinecraftClient var27 = var38;
            MinecraftClient var26 = var38;
            if (var39 == 0) {
               MinecraftClient var16 = var26;
               ClientWorld var40 = var16.world;
               if (var40 == null) {
                  break label30;
               }

               MinecraftClient var41 = b;
               var27 = var41;
            }

            MinecraftClient var19 = var27;
            Screen var42 = var19.currentScreen;
            if (var42 == null) {
               Object[] var21 = new Object[]{var6};
               FastEXP var20 = this;
               var20.jReturningVoid(var21);
            }
         }

         this.h = -1;
         var28 = this;
      }

      var28.i = -1;
   }

   private boolean lambda$new$2(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Automatic";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Manual";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(118272887038454L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[3];
      String var17 = "4%gÚ±\"\u0085mØ\u0082 \fb*\u001d0C¾\u0090°×\u0090ôÝ\u0012\u001ef\u001b\u0012gy¤\u0018¦\u0093ó\u008e6xlXÁèQ.S|bÈqo\r°\t\u0014iÐ\u0010\n\u001b@Ò1\u0005?Êé¡Ü:êE\u00933";
      int var19 = "4%gÚ±\"\u0085mØ\u0082 \fb*\u001d0C¾\u0090°×\u0090ôÝ\u0012\u001ef\u001b\u0012gy¤\u0018¦\u0093ó\u008e6xlXÁèQ.S|bÈqo\r°\t\u0014iÐ\u0010\n\u001b@Ò1\u0005?Êé¡Ü:êE\u00933"
         .length();
      char var16 = ' ';
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var27 = b(var21).intern();
         int var10001 = -1;
         var20[var18++] = var27;
         if ((var15 += var16) >= var19) {
            l = var20;
            m = new String[3];
            q = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(118272887038454L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[3];
            String var4 = "ù\bæ\u0012úlíÉY«\u008d§LhÛÛ\"Ûf\u0014B\u0001\u001aq";
            int var5 = "ù\bæ\u0012úlíÉY«\u008d§LhÛÛ\"Ûf\u0014B\u0001\u001aq".length();
            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var10001] = var10004;
            } while (var2 < var5);

            o = var6;
            p = new Integer[3];
            break;
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 17615;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eF", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eF_C0227",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1067;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eF", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eF_C0227",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 55;
            yield var15;
         }
         case 1 -> {
            byte var16 = 33;
            yield var16;
         }
         case 2 -> {
            byte var17 = 40;
            yield var17;
         }
         case 3 -> {
            byte var18 = 10;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 7;
            yield var20;
         }
         case 6 -> {
            byte var21 = 3;
            yield var21;
         }
         case 7 -> {
            byte var22 = 4;
            yield var22;
         }
         case 8 -> {
            byte var23 = 18;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 6;
            yield var25;
         }
         case 11 -> {
            byte var26 = 57;
            yield var26;
         }
         case 12 -> {
            byte var27 = 30;
            yield var27;
         }
         case 13 -> {
            byte var28 = 44;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 11;
            yield var31;
         }
         case 17 -> {
            byte var32 = 49;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 32;
            yield var35;
         }
         case 21 -> {
            byte var36 = 28;
            yield var36;
         }
         case 22 -> {
            byte var37 = 19;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 39;
            yield var39;
         }
         case 25 -> {
            byte var40 = 62;
            yield var40;
         }
         case 26 -> {
            byte var41 = 43;
            yield var41;
         }
         case 27 -> {
            byte var42 = 12;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 34;
            yield var46;
         }
         case 32 -> {
            byte var47 = 29;
            yield var47;
         }
         case 33 -> {
            byte var48 = 22;
            yield var48;
         }
         case 34 -> {
            byte var49 = 56;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 46;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 51;
            yield var53;
         }
         case 39 -> {
            byte var54 = 41;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 45;
            yield var56;
         }
         case 42 -> {
            byte var57 = 60;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 15;
            yield var59;
         }
         case 45 -> {
            byte var60 = 48;
            yield var60;
         }
         case 46 -> {
            byte var61 = 59;
            yield var61;
         }
         case 47 -> {
            byte var62 = 1;
            yield var62;
         }
         case 48 -> {
            byte var63 = 63;
            yield var63;
         }
         case 49 -> {
            byte var64 = 8;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 25;
            yield var66;
         }
         case 52 -> {
            byte var67 = 21;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 35;
            yield var69;
         }
         case 55 -> {
            byte var70 = 9;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 47;
            yield var72;
         }
         case 58 -> {
            byte var73 = 50;
            yield var73;
         }
         case 59 -> {
            byte var74 = 58;
            yield var74;
         }
         case 60 -> {
            byte var75 = 54;
            yield var75;
         }
         case 61 -> {
            byte var76 = 13;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 14;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "Y\u0005r\u001bB\u0001R\ncT?\u0019A\rj\u001d";
      r[1] = "z10z[Bq>!5:Lz5%o";
      r[2] = boolean.class;
      s[2] = "java/lang/Boolean";
      r[3] = "i7p]\u001d\u0003\u007f7u\u0007\u000e\u0014h|v\u0001\u0002\u0000y;a\u0016I\u0017K";
      r[4] = "a\u0019@-,?w\u0019Ew?(`RFq3<q\u0015Qfx.@";
      r[5] = int.class;
      s[5] = "java/lang/Integer";
      r[6] = "N\r643GX\r3n POF0h,D^\u0001'\u007fgRl";
      r[7] = "KI[\u0013f\n@FJ\\\u0005\u0007UKE70\u0005DXY\u001b'\b";
      r[8] = "gS\u0014&3'gS\u0003z?(}\u0018\u0003d?=ziQ?gw";
      r[9] = "R#\u001a\u0016PJR#\rJ\\EHh\rT\\PO\u0019_\u000f\u0004\u0011";
      r[10] = ",]f!\n\u000b,]q}\u0006\u00046\u0016qc\u0006\u00111g#7WP";
      r[11] = "(WyW'\u001c(Wn\u000b+\u00132\u001cn\u0015+\u00065m:M|";
      r[12] = "?i\u0003\"jG?i\u0014~fH%\"\u0014`f]\"SD=7";
      r[13] = "8\u0017r{\u007f\n8\u0017e's\u0005\"\\e9s\u0010%-4f+G5\u001eg&a<dF6";
      r[14] = "\u0011\u0001|nm\\\u0007\u0001y4~K\u0010Jz2r_\u0001\rm%9H9";
      r[15] = "d\b\u001bd\u0002'\u0011(\u0010k\u0013hp&\u001b`\u00172\u0004";
      r[16] = void.class;
      s[16] = "java/lang/Void";
      r[17] = "S--}\u0007)S-:!\u000b&If:?\u000b3N\u0017hc^q";
      r[18] = long.class;
      s[18] = "java/lang/Long";
      r[19] = float.class;
      s[19] = "java/lang/Float";
      r[20] = "\"%A\u0015\n\t)*PZf\n'(R\u0015J";
      r[21] = "\u0017u7\"P\u0001\u0017u ~\\\u000e\r> `\\\u001b\nOq?\u0004";
      r[22] = "\u0017\u0019`UtH\u0001\u0019e\u000fg_\u0016Rf\tkK\u0007\u0015q\u001e ^*";
      r[23] = "\u001d\u0007MJL\u0011h'FE]^\t)MNY\u0004}";
      r[24] = "x2|\u0013k\tn2yIx\u001eyyzOt\nh>mX?\u001ap";
      r[25] = "#E 3\"\u0018Ve+<3W7k 77\rC";
      r[26] = "\u0019M\u0011ZYSlm\u001aUH\u001c\rc\u0011^LFy";
      r[27] = "]G\r\u001c\u001bC]G\u001a@\u0017LG\f\u001a^\u0017Y@}H\u0000@\u0012";
      r[28] = "U\u001f`\u0006\u0018kP\nk\u0006\u0013p\\\u001a)o8Zm";
      r[29] = "nkUp/)\u001bK^\u007f>fzEUt:<\u000e";
      r[30] = "+K/\u0014Q\\^k$\u001b@\u0013?e/\u0010DIK";
      r[31] = "Yw)yx\u0014,W\"vi[MY)}m\u00019";
      r[32] = "$&*E\u0019\u00122&/\u001f\n\u0005%m,\u0019\u0006\u00114*;\u000eM\u0001,*9\u0005\u0017L\u001019\u0018\u0017\u000b'&";
      r[33] = "\u0010\u0019\u0013\u000ehy\u0006\u0019\u0016T{n\u0011R\u0015Rwz\u0000\u0015\u0002E<k\"";
      r[34] = "3w\u0017zo\\FW\u001cu~\u0013'Y\u0017~zIS";
      r[35] = "\u0005yg~Z`pYlqK/\u0011WgzOue";
      r[36] = "9\u0002\u001d[.\u000bL\"\u0016T?D-,\u001d_;\u001eY";
      r[37] = "o[G6#Dy[Bl0Sn\u0010Aj<G\u007fWV}wPC";
      r[38] = "\u001f1(0\b\u0018j\u0011#?\u0019W\u000b\u001f(4\u001d\r\u007f";
      r[39] = "0\u001bUE|6E;^Jmy$5UAi#P";
      r[40] = "\u0011\u001f5UBF\u0007\u001f0\u000fQQ\u0010T3\t]E\u0001\u0013$\u001e\u0016U\u001a";
      r[41] = "\u0011\u000e=\u0017e\u0004d.6\u0018tK\u0005 =\u0013p\u0011q";
      r[42] = "\u001c\u0013;u/.i30z>a\b=;q:;|";
      r[43] = "k\u0007\fc_N\u001e'\u0007lN\u0001\u007f)\fgJ[\u000b";
      r[44] = "\u0003zQ\u0005B{vZZ\nS4\u0017TQ\u0001Wnc";
      r[45] = "!E%Hu\u0015Te.GdZ5k%L`\u0000A";
      r[46] = "T\f\u0017\u0003\u007fIT\f\u0000_sFNG\u0000AsSI6R\u001b$\u0011";
      r[47] = "\u0003\u0015C\u000b^8\u0003\u0015TWR7\u0019^TIR\"\u001e/\u0003\u0016\u0004";
      r[48] = "}\u0016\u0011o\\h}\u0016\u00063Pgg]\u0006-Pr`,Sr\t";
      r[49] = ";\u00190HSg-\u00195\u0012@p:R6\u0014Ld+\u0015!\u0003\u0007s&";
      r[50] = "ajFL\u001cg\u0014JMC\r(uDFH\tr\u0001";
      r[51] = "\u0013(d`~Af\booo\u000e\u0007\u0006ddkTs";
      r[52] = "03l\u0016Se03{J_j*x{T_\u007f-\t)\u000b\u000e8";
      r[53] = "\f\u00177\u0019eYy7<\u0016t\u0016\u001897\u001dpLl";
      r[54] = ")kbs0Y)ku/<V3 u1<C4Q/oj\u0004";
      r[55] = "`HtYKi~@n\u0016,ho[cL\nn";
      r[56] = "0x{\u0001 g0xl],h*3lC,}-B>\u0017t=";
      r[57] = "+`?,w\u0003+`(p{\f1+(n{\u00196Z~1([";
      r[58] = "uD\u0003\u000e\u0005%uD\u0014R\t*o\u000f\u0014L\t?h~N\u0013Xx";
      r[59] = "\u0019`\\<\u0005\u000e\u0007hFsx\u001e\u0007";
      r[60] = "X&\\X\u0003IX&K\u0004\u000fFBmK\u001a\u000fSE\u001c\u001eNV\u0010";
      r[61] = "S\")\u0004\fQW?)\u0015\u0011Q\u00140f\u0002\u0016MN?k_\rZP3d\u0005\u0011\u0016u4m\u0014\u0001L\b\u001fi\u0005/YJrB\u001f\u0016JC";
      r[62] = ".5p\u0006%\u001c[\u0015{\t4S:\u001bp\u00020\tN";
      r[63] = "n\u001aaSydx\u001ad\tjsoQg\u000ffg~\u0016p\u0018-pr";
      r[64] = "\u00168\u0007m|pc\u0018\fbm?\u0002\u0016\u0007iiev";
      r[65] = "_0D\u0016\u0012]\u0000w_R`M\u000fbP\u00057\u001aU4\u000eiQ\u001c\u001epF\u0017\u000e[\u00054";
      r[66] = "cuH(p\u001925B,\u0016\u0013R4\u00169*\u000650\u001cx&\u0005RgL7w\u0013hoOshy";
      r[67] = "\u001aiq\u001ds\u0013Ws{\u0010\u000f\u000bHd \u0016c9\u001e!}M?nZq8Ic\tZ(&\u0011\u000f";
      r[68] = "~h,w$`~tr)Cw a.'\u0014){<uK}(-1'3>t|u";
      r[69] = ">,k\u0001Hdx<f\\*7Fj=K\u0016!!n7\n\u001a\"F+r\\\u0011<|mbQL^";
      r[70] = " \u0003\u0011\b\u0011Pb]L\u0012\u0010nwY\u0011\u0014B9(\u0001DI.W\"[\u0007\u001d\u001eUk\u0004\u0004\u0016";
      r[71] = "NY$M\u0006b\u0019K{\nom\u001fE#\\8:A\u0015z0\u001f=B\u0015>]\u0016c\u0015U";
      r[72] = "\u0011x\u000f\u0019\u0005?\\b\u0005\u0014y'Cu^\u0012\u0015\u0015\u00157\u0002HEBB9]\f\u0004?DhR\fy";
      r[73] = "M@y\u001f~\u0016\u001a\u0018*\u0016\fK\u001e\u0000v\b`yLM(W\f\u0017\u0003\u001dt^oC\t\u001ado";
      r[74] = " iR##&#hHrB7Qo\u0000m~$6k\n,r'Q<Zc#1k4Y'<[";
      r[75] = "\u00131<,\u001a\u000eD#cks\nN<?6\u001f8\u001a}a`sVS!=`\u0010\u0002Y&-Q";
      r[76] = "h=m+\"*%'g&^2:0< 2\u0000lr`zcW;|?>#*=-0>^";
      r[77] = "\n\u001cxT\u007fGVXf]'xUKk\u0018N\u0002ZB~\u0003!\tU\u001d\u001b";
      r[78] = "f]\u001c\u0019\u0001-4\u001b\u000f\u001bs4]YR\fO\":]XMC!]\n\b\u0002\u00127g\u0002\u000bF\r]";
      r[79] = "5 #\u001dpt3k\u007fE\u0012{Pi.\u000e.m7m$O\"nPin\u001ep#3=d\u0019`\u0012";
      r[80] = "(dI[/\u000e\u007fv\u0016\u001cF\nuiJA*8\"/\u0014\u0016}os/FC6\u0015}u\u0013XF";
      r[81] = "\"vDPjyevYE\u0018g\u001e3\u0017_$ty7\u001d\u001e(w\u001e3WOz:}g]Hj\u000b";
      r[82] = "_\u000e^\r5OV\u0014Ma8FG\u0019E\u001aUES\u0014D\u0006:N\\K!X%^XAB\f/YHp";
      r[83] = "\u007f'\u001b\u001f.)~'\u0003\u0015\\1\u001a}\rD>.|{F\u0018f";
      r[84] = "t\"u4A\u000fvum<_o(sq%J\u0003\u001a#2x\u0016^M'0u\u0016\r<rot\u0010WM";
      r[85] = "\u001eYB_N\u0001K\u0006CY\u0014pF\u0018\u001f\u001eE\f@\u001er]\u0016\u0013\u0017UM\u0001R\r\u001e\rr";
      r[86] = "9%F/(\u0002~%[:Z\u0019\u0005`\u0015 f\u000fbd\u001faj\f\u0005`U08Af4_7(p";
      r[87] = " :zy\u0007Jw(%>nEq&}h9\u0012/u$\u0004\u0003Zq5``_\u0012v2";
      r[88] = "}{\u001cbk%}\"\u0002:\u0007'on\u0004=k\u0015?._j\u0007yzl\u001a<w?i}UZ9~mb\u0016bn&>kd";
      r[89] = "Sl\u000fE3T\u0004~P\u0002Z[\u0002p\bT\r\f]-S8*_\u0003y\u000eVbR\u001cl";
      r[90] = "gt`bs90,3k\u0001d44oumVfy?,\u00018))m#bl#.}\u0012";
      r[91] = "DMH@B\u0005\u0003NKD\u0007e\u0018\u001dH\u001d[\t*L\fG\u0006X}I\u000f\u001eG\bMKFAD\u0003}ID\u001c^T\u001e\u001dN\u001bNe";
      r[92] = "\u007f\\{\u0006\u000b.#\u0014|\u0001r/\u007fQz\u001f\u001e\u001d+\u0012%HIJ#\u0012j\u0007\u00004|UqCr";
      r[93] = "B/V}bB\u000f5\\p\u001eZ\u0010\"\u0007vrhCfX \u001e\u0001A1\u0017c&V\u0019b\u001e\u0011";
      r[94] = "%QJ~6Q5\u0015\u0012b\tR&\u0005\u0012p^\u0001wPF\u001ck\u0005{\nIq{A#\u0016";
      r[95] = "l,\u007fPhQ~)\"BX\u0001j$8g5\u0012K-:S5$s6;O>ne;\"W=\u0001a$xKXUv49N(\u0013e%v(c\u0016p4!X%\u0005a{G";
      r[96] = "?,\u0002R{\u0011x,\u001fG\t\r\u0003iQ]5\u001cdm[\u001c9\u001f\u0003i\u0011MkR`=\u001bJ{c";
      r[97] = "\"\u000e]F7f=\u0018^\u0005XjME\nKd|*A\u0000\nh\u007fMEJ[:2.\u0011@\\*\u0003";
      r[98] = "t+SLc\u0004u~[\u0004\u001aS\u000f(\nM&Bh,\u0000\f*A\u000f(J]x\fl|@Zh=";
      r[99] = "6\rV\u0018\tsq\rK\r{l\nH\u0005\u0017G~mL\u000fVK}\nHE\u0007\u00190i\u001cO\u0000\t\u0001";
      r[100] = "BR\nZ\u001b$\u0010\u0014\u0019Xi>yT\f@\u00172\t\u0012\u001fQXT";
      r[101] = ";\u0017)(Y?|\u00174=+$\u0007V!(Fty\u0019%9TM:\u00004;\u00123u\u0004%)+";
      r[102] = "\u0004u}OA%S-.F3xW5rX_J\u0005x*\u000e3#\u000b%/RK`Wtk?";
      r[103] = "Xjm\u000eT-\u0015pg\u0003(5\ng<\u0005D\u0007Y\"eR(i_wb\u0007P7\u0002|1\u0005(n[t,\u0010\u00109\u0003'%b";
      r[104] = "\u0001\u0017b\u0003\u0014\u000b\u0000BjKm[z\u0014;\u0002QM\u001d\u00101C]NzGa\f\fX@ObH\u00132";
      r[105] = "@oe\u001aF5C9nBYZ\u0018)3_P&\u001e/^\u001c\u00039Ida@G'@<^";
      r[106] = "7\u001bH)I 8GDo'z=DO|Nv\u0004JOlJ\u0010cSJs\u0016s7YMc'";
      r[107] = "i8/\u00028<;~<\u0000J'R>)\u00184*\"x:\t{L";
      r[108] = "\u001aU@q|XWOJ|\u0000@HX\u0011zlr\u001e\u001aM ?%I\u0014\u0012d}XOE\u001dd\u0000OO[\u0010w:GL\u001f\u000f\u001d";
      r[109] = "\u0012\u000b\u001cL\u0012fG\b@Ut0|Q\u0014XH%\u001bU\u001e\u0019D&|QTH\u0016k\u001f\u0005^O\u0006Z";
      r[110] = "b:\u0017;Asal\u001cc^\u001c5aA`RKg1\u0016>\u0002\u001cb:\u0017;Asal\u001cc^";
      r[111] = "k1+X>]`w;\fXRQ3-X=\\>8\"\u0007X";
      r[112] = "twd\u0012\u0000#kagQo-\u001b<3\u001fS9|89^_:\u001b<s\u000f\rwxhy\b\u001dF";
      r[113] = "V\u0011TLEu\u0011\u0011IY7kjT\u0007C\u000bx\rP\r\u0002\u0007{jVOLIa\u001a\u0010\\]\u0006\u0007";
      r[114] = "~(i^\u00137})s\u000fr'\u000f.;\u0010N5h*1QB6\u000f}a\u001e\u0013 5ubZ\fJ";
      r[115] = ".\u000f4AKzy\u001dk\u0006\"u\u007f\u00133Pu\"!Dk<\u001dj/\u0012+APp%\u001f";
      r[116] = "<.~Qy$i-\"H\u001fqRtvE#g5p|\u0004/dR',K~rh//\u000fa\u0018";
      r[117] = "_`*jM\u0018\u0018`7\u007f?\u0007c%ye\u0003\u0015\u0004!s$\u000f\u0016c'1jA\f\u0013a\"{\u000ej";
      r[118] = "r\u0005^'R\fs\u0005F- \u000e\u0017K\u0007#\u001f\bjH\u00069N";
      r[119] = "\biV\f?6\t<^DFfsj\u000f\rzp\u0014n\u0005LvsshG\u00028i\u0003.T\u0013w\u000f";
      r[120] = "\fyx\u0018ECP=f\u0011\u001d|U*`n\u0019\fIC\"X\u0015\u001e\u0004 vR\u0012\u000e5";
      r[121] = "E3#dApKiv\u007f1oCu/f]]\u00125~91a_l0d^e@6,\u0001";
      r[122] = "16\u001d /\u001cv6\u00005]\u0005\rsN/a\u0011jwDnm\u0012\rsNa/\u0011avN5l\u0012\r";
      r[123] = "}\u0017%|zS0\r/q\u0006K/\u001atwjy|^(/\u0006\u0010~\tdb>G&Zm\u0010";
      r[124] = "\fn*q@\u0007Kn7d2\u001f0+y~\u000e\nW/s?\u0002\t0+y0@\n\\.yd\u0003\t0";
      r[125] = "H\u00186K+|\u000f\u0018+^Ylt]eDeq\u0013Yo\u0005irt\u000e?J8dN\u0006<\u000e'\u000e";
      r[126] = "^\u0018MnY=\u0019\u001aYzL_\bKZC].g\\OdU8\bW@;0";
      r[127] = "c\u001ac`\u001dd4B0io90Zlw\u0003\u000b`\u00162-P\\d\u001ata\u0003<fMli\u001d\\";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(77000692929375L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(77000692929375L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(77000692929375L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 216;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 234;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 210;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 80;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 68;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 77;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 216;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 234;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 210;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eF_C0227",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(FastEXP var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eF_C0227;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eF_C0227", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastEXP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(FastEXP var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eF_C0227;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eF_C0227", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastEXP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(FastEXP var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eF_C0227;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eF_C0227", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastEXP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
