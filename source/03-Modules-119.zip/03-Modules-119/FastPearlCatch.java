package dev.zprestige.prestige.client.modules;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket.LookAndOnGround;
import net.minecraft.util.ActionResult;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.client.modules.state.FastPearlCatchState;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class FastPearlCatch extends Module implements RotationSource {
   private static final float a = 1500.0F;
   private ModeSetting c;
   private FloatSetting d;
   private FloatSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private FloatSetting i;
   private boolean j;
   private boolean k;
   private ElapsedTimer l;
   private boolean m;
   private boolean n;
   private float o;
   private float p;
   private Rotation q;
   private boolean r;
   private boolean s;
   private boolean t;
   private boolean u;
   private Object v;
   private Object w;
   private int x;
   private FastPearlCatchState y;
   private int z;
   private int A;
   private static final long B = 127713985863032L;
   private static final String[] C;
   private static final String[] D;
   private static final Map E = new HashMap(13);
   private static final long[] F;
   private static final Integer[] G;
   private static final Map H;
   private static final Object[] I = new Object[177];
   private static final String[] J = new String[177];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;

   public FastPearlCatch() {
      super();
      long var10001 = 125202142434590L ^ 18504775737911L;
      var10001 = 125202142434590L ^ 121668765427657L;
      var10001 = 125202142434590L ^ 36419940703922L;

      this.l = new ElapsedTimer(106698256430889L);
      this.x = Integer.MIN_VALUE;
      this.y = FastPearlCatchState.PREP;
      this.A = -1;
      FloatSetting var10000 = this.d;
      Object[] var10 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var9 = var10000;
      var9.aReturningFloatSetting(var10);
      var10000 = this.i;
      Object[] var12 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var11 = var10000;
      var11.aReturningFloatSetting(var12);
      var10000 = this.e;
      Object[] var14 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var13 = var10000;
      var13.aReturningFloatSetting(var14);
      BooleanSetting var21 = this.g;
      Object[] var16 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var15 = var21;
      var15.aReturningBooleanSetting(var16);
      BooleanSetting var22 = this.h;
      Object[] var18 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var17 = var22;
      var17.aReturningBooleanSetting(var18);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 48646647141422L ^ 104325574716534L;
      var10001 = 48646647141422L ^ 121395696407734L;
      var10001 = 48646647141422L ^ 115315460228731L;
      var10001 = 48646647141422L ^ 126704302158859L;
      var10001 = 48646647141422L ^ 120018761992899L;
      int var14 = Event.cReturningInt();
      int var68 = var14;
      Object var67 = this.w;
      Object var52 = var67;
      Object var51 = var67;
      if (var68 != 0) {
         MinecraftClient var15 = b;
         ClientWorld var70 = var15.world;
         Object var69 = var51;
         if (var69 != var70) {
            Object[] var18 = new Object[]{75722808103509L};
            FastPearlCatch var17 = this;
            var17.lReturningVoid(var18);
         }

         BooleanSetting var20 = this.h;
         var52 = var20.aReturningObject();
      }

      Boolean var21 = (Boolean)var52;
      boolean var10000 = var21;
      int var72 = var14;
      boolean var71 = var10000;
      boolean var54 = var71;
      boolean var53 = var71;
      if (var72 != 0) {
         boolean var73 = var53;
         if (!var73) {
            return;
         }

         ModeSetting var23 = this.c;
         String var98 = (String)var23.aReturningObject();
         String var25 = "Swap";
         String var24 = var98;
         boolean var74 = var24.equals(var25);
         var54 = var74;
      }

      int var76 = var14;
      boolean var75 = var54;
      boolean var56 = var75;
      boolean var55 = var75;
      if (var76 != 0) {
         boolean var77 = var55;
         if (!var77) {
            return;
         }

         Object[] var29 = new Object[]{104465599602725L};
         FastPearlCatch var28 = this;
         var56 = var28.eReturningBoolean(var29);
      }

      int var79 = var14;
      boolean var78 = var56;
      boolean var58 = var78;
      boolean var57 = var78;
      if (var79 != 0) {
         boolean var80 = var57;
         if (var80) {
            Object[] var32 = new Object[]{72940578390168L};
            FastPearlCatch var31 = this;
            var31.jReturningVoid(var32);
            return;
         }

         var58 = this.j;
      }

      FastPearlCatch var66;
      label89: {
         int var82 = var14;
         boolean var81 = var58;
         boolean var62 = var81;
         boolean var59 = var81;
         if (var82 != 0) {
            boolean var83 = var59;
            if (!var83) {
               float var10002 = this.p;
               FloatSetting var35 = this.d;
               Float var36 = (Float)var35.aReturningObject();
               Rotation var99 = new Rotation(var10002, -var36);
               FloatSetting var37 = this.i;
               Float var38 = (Float)var37.aReturningObject();
               float var105 = var38 / 2.0F;
               Object[] var10006 = new Object[]{null, null, null, null, 71564451356397L};
               var10006[3] = 0.2F;
               var10006[2] = 0.0F;
               var10006[1] = var105;
               var10006[0] = var99;
               Object[] var39 = var10006;
               boolean var84 = RotationUtil.cReturningBoolean(var39);
               if (!var84) {
                  return;
               }

               this.m = dev.prestige.recovery.SourceSupport.asBoolean(1);
               int var85 = var14;
               if (var85 != 0) {
                  return;
               }
            }

            int var87 = var14;
            FastPearlCatch var86 = this;
            var66 = var86;
            FastPearlCatch var60 = var86;
            if (var87 == 0) {
               break label89;
            }

            FastPearlCatch var88 = var60;
            FastPearlCatch var61 = var88;
            boolean var89 = var61.k;
            var62 = var89;
         }

         boolean var90 = var62;
         if (var90) {
            int var92 = var14;
            boolean var91 = this.t;
            boolean var65 = var91;
            boolean var63 = var91;
            if (var92 != 0) {
               boolean var93 = var63;
               boolean var64 = var93;
               boolean var94 = var64;
               if (var94) {
                  return;
               }

               Rotation var100 = new Rotation(this.p, this.o);
               FloatSetting var46 = this.i;
               Float var47 = (Float)var46.aReturningObject();
               float var106 = var47 / 2.0F;
               Object[] var107 = new Object[]{null, null, null, null, 71564451356397L};
               var107[3] = 0.2F;
               var107[2] = 0.0F;
               var107[1] = var106;
               var107[0] = var100;
               Object[] var48 = var107;
               var65 = RotationUtil.cReturningBoolean(var48);
            }

            boolean var95 = var65;
            if (!var95) {
               return;
            }

            Object[] var50 = new Object[]{126290808879192L};
            FastPearlCatch var49 = this;
            var49.aReturningVoid(var50);
            int var96 = var14;
            if (var96 != 0) {
               return;
            }
         }

         FastPearlCatch var97 = this;
         var66 = var97;
      }

      var66.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 110146931737985L;
      long var6 = var2 ^ 26568666204291L;
      long var8 = var2 ^ 138705109068024L;
      long var10 = var2 ^ 131025899653717L;
      long var12 = var2 ^ 128805606740735L;
      long var14 = var2 ^ 104913369978519L;
      long var16 = var2 ^ 109344690948165L;
      long var18 = var2 ^ 138007752420630L;
      long var20 = var2 ^ 18698867496473L;
      long var22 = var2 ^ 103512462602515L;
      long var24 = var2 ^ 86502240407608L;
      long var26 = var2 ^ 132691246119477L;
      long var28 = var2 ^ 29159961624672L;
      long var30 = var2 ^ 131036947896900L;
      int var32 = Event.cReturningInt();
      int var385 = var32;
      FastPearlCatch var384 = this;
      FastPearlCatch var269 = var384;
      FastPearlCatch var268 = var384;
      if (var385 != 0) {
         MinecraftClient var45 = b;
         ClientWorld var387 = var45.world;
         Object var386 = var268.w;
         if (var386 != var387) {
            Object[] var48 = new Object[]{var26};
            FastPearlCatch var47 = this;
            var47.lReturningVoid(var48);
         }

         var269 = this;
      }

      Object[] var51 = new Object[]{var16};
      FastPearlCatch var50 = var269;
      boolean var33 = var50.eReturningBoolean(var51);
      RotationManager var10000 = Prestige.o;
      Object[] var53 = new Object[]{var22};
      RotationManager var52 = var10000;
      boolean var619 = var52.eReturningBoolean(var53);
      int var389 = var32;
      boolean var388 = var619;
      boolean var271 = var388;
      boolean var270 = var388;
      if (var389 != 0) {
         boolean var390 = var270;
         if (!var390) {
            Object[] var56 = new Object[]{var26};
            FastPearlCatch var55 = this;
            var55.lReturningVoid(var56);
            return null;
         }

         var271 = var33;
      }

      int var392 = var32;
      boolean var391 = var271;
      boolean var275 = var391;
      boolean var272 = var391;
      if (var392 != 0) {
         boolean var393 = var272;
         if (!var393) {
            boolean var281;
            label502: {
               label523: {
                  int var401 = var32;
                  FastPearlCatch var400 = this;
                  FastPearlCatch var279 = var400;
                  FastPearlCatch var278 = var400;
                  if (var401 != 0) {
                     Rotation var402 = var278.q;
                     if (var402 == null) {
                        break label523;
                     }

                     FastPearlCatch var403 = this;
                     var279 = var403;
                  }

                  int var405 = var32;
                  boolean var404 = var279.t;
                  var281 = var404;
                  boolean var280 = var404;
                  if (var405 == 0) {
                     break label502;
                  }

                  boolean var406 = var280;
                  if (var406) {
                     return this.q;
                  }
               }

               MinecraftClient var67 = b;
               var281 = var67.isWindowFocused();
            }

            Object var289;
            label569: {
               FastPearlCatch var288;
               label525: {
                  int var408 = var32;
                  boolean var407 = var281;
                  boolean var287 = var407;
                  boolean var282 = var407;
                  if (var408 != 0) {
                     boolean var409 = var282;
                     if (var409) {
                        MinecraftClient var69 = b;
                        int var411 = var32;
                        Screen var410 = var69.currentScreen;
                        var289 = var410;
                        Screen var283 = var410;
                        if (var411 == 0) {
                           break label569;
                        }

                        Screen var412 = var283;
                        Screen var284 = var412;
                        Screen var413 = var284;
                        if (var413 == null) {
                           BooleanSetting var76 = this.h;
                           var289 = var76.aReturningObject();
                           break label569;
                        }
                     }

                     int var415 = var32;
                     FastPearlCatch var414 = this;
                     var288 = var414;
                     FastPearlCatch var285 = var414;
                     if (var415 == 0) {
                        break label525;
                     }

                     FastPearlCatch var416 = var285;
                     FastPearlCatch var286 = var416;
                     boolean var417 = var286.t;
                     var287 = var417;
                  }

                  boolean var418 = var287;
                  if (var418) {
                     return null;
                  }

                  var288 = this;
               }

               Object[] var75 = new Object[]{var4};
               FastPearlCatch var74 = var288;
               var74.kReturningVoid(var75);
               return null;
            }

            boolean var337;
            Boolean var77 = (Boolean)var289;
            boolean var620 = var77;
            int var420 = var32;
            boolean var419 = var620;
            var337 = var419;
            boolean var290 = var419;
            label474:
            if (var420 != 0) {
               boolean var421 = var290;
               if (var421) {
                  ModeSetting var79 = this.c;
                  String var621 = (String)var79.aReturningObject();
                  short var10001 = 13002;
                  long var10002 = 2765508659418504298L ^ var2;
                  String var81 = "Swap";
                  String var80 = var621;
                  boolean var622 = var80.equals(var81);
                  int var423 = var32;
                  boolean var422 = var622;
                  var337 = var422;
                  boolean var291 = var422;
                  if (var423 == 0) {
                     break label474;
                  }

                  boolean var424 = var291;
                  boolean var292 = var424;
                  boolean var425 = var292;
                  if (var425) {
                     int var296;
                     label351: {
                        int var427 = var32;
                        FastPearlCatch var426 = this;
                        FastPearlCatch var295 = var426;
                        FastPearlCatch var293 = var426;
                        if (var427 != 0) {
                           FastPearlCatch var428 = var293;
                           FastPearlCatch var294 = var428;
                           boolean var429 = var294.j;
                           if (var429) {
                              // var296 = var430;
                              break label351;
                           }

                           var295 = this;
                        }

                        Object[] var88 = new Object[]{var20};
                        FastPearlCatch var87 = var295;
                        var296 = var87.dReturningInt(var88);
                     }

                     label528: {
                        int var34;
                        int var35;
                        int var306;
                        label529: {
                           int var304;
                           byte var305;
                           label530: {
                              var34 = var296;
                              Object[] var90 = new Object[]{var30};
                              FastPearlCatch var89 = this;
                              var35 = var89.eReturningInt(var90);
                              int var432 = var32;
                              byte var431 = ((byte)((this.j) ? 1 : 0));
                              int var302 = var431;
                              byte var297 = var431;
                              if (var432 != 0) {
                                 byte var433 = var297;
                                 if (var433 == 0) {
                                    int var436 = var32;
                                    // int var434 = var34;
                                    var304 = var434;
                                    var305 = var435;
                                    int var298 = var434;
                                    byte var299 = var435;
                                    if (var436 == 0) {
                                       break label530;
                                    }

                                    byte var438 = var299;
                                    int var437 = var298;
                                    int var300 = var437;
                                    byte var301 = var438;
                                    byte var440 = var301;
                                    int var439 = var300;
                                    if (var439 == var440) {
                                       break label528;
                                    }
                                 }

                                 var302 = var35;
                              }

                              int var442 = var32;
                              int var441 = var302;
                              var306 = var441;
                              int var303 = var441;
                              if (var442 == 0) {
                                 break label529;
                              }

                              // int var443 = var303;
                              var304 = var443;
                              var305 = var444;
                           }

                           byte var446 = var305;
                           int var445 = var304;
                           if (var445 == var446) {
                              break label528;
                           }

                           var306 = (((this.m) ? 1 : 0));
                        }

                        int var448 = var32;
                        int var447 = var306;
                        int var312 = var447;
                        int var307 = var447;
                        if (var448 != 0) {
                           int var449 = var307;
                           if (var449 != 0) {
                              float var650 = this.p;
                              FloatSetting var99 = this.d;
                              Float var100 = (Float)var99.aReturningObject();
                              Object[] var102 = new Object[]{new Rotation(var650, -var100), var6};
                              FastPearlCatch var101 = this;
                              Rotation var597 = var101.cReturningdx_C0210(var102);
                              int var452 = var32;
                              int var451 = var34;
                              FastPearlCatch var450 = this;
                              FastPearlCatch var310 = var450;
                              int var311 = var451;
                              FastPearlCatch var308 = var450;
                              int var309 = var451;
                              if (var452 != 0) {
                                 Object[] var654 = new Object[]{null, Hand.MAIN_HAND, var10};
                                 var654[0] = var309;
                                 Object[] var104 = var654;
                                 FastPearlCatch var103 = var308;
                                 boolean var453 = var103.fReturningBoolean(var104);
                                 if (!var453) {
                                    return var597;
                                 }

                                 this.j = true;
                                 byte var455 = 0;
                                 FastPearlCatch var454 = this;
                                 var310 = var454;
                                 var311 = var455;
                              }

                              var310.m = dev.prestige.recovery.SourceSupport.asBoolean(var311);
                              ElapsedTimer var631 = this.l;
                              Object[] var108 = new Object[]{var28};
                              ElapsedTimer var107 = var631;
                              var107.aReturningVoid(var108);
                              return var597;
                           }

                           var312 = (((this.n) ? 1 : 0));
                        }

                        int var456 = var312;
                        if (var456 != 0) {
                           EnderPearlEntity var36 = null;
                           short var624 = 10410;
                           long var642 = 6267834975750236956L ^ var2;
                           int var37 = Integer.MAX_VALUE;
                           MinecraftClient var109 = b;
                           ClientWorld var110 = var109.world;
                           Iterable var111 = var110.getEntities();
                           Iterator var38 = var111.iterator();

                           FastPearlCatch var336;
                           label532: {
                              boolean var335;
                              label322:
                              while (true) {
                                 Iterator var112 = var38;
                                 boolean var457 = var112.hasNext();
                                 if (var457) {
                                    label534: {
                                       Iterator var113 = var38;
                                       Entity var39 = (Entity)var113.next();
                                       int var459 = var32;
                                       Entity var458 = var39;
                                       Entity var316 = var458;
                                       Entity var313 = var458;
                                       if (var459 != 0) {
                                          boolean var625 = var313 instanceof EnderPearlEntity;
                                          int var461 = var32;
                                          boolean var460 = var625;
                                          var335 = var460;
                                          boolean var314 = var460;
                                          if (var461 == 0) {
                                             break;
                                          }

                                          boolean var462 = var314;
                                          boolean var315 = var462;
                                          boolean var463 = var315;
                                          if (!var463) {
                                             break label534;
                                          }

                                          var316 = var39;
                                       }

                                       EnderPearlEntity var40 = (EnderPearlEntity)var316;
                                       int var465 = var32;
                                       EnderPearlEntity var464 = var40;
                                       EnderPearlEntity var318 = var464;
                                       EnderPearlEntity var317 = var464;
                                       if (var465 != 0) {
                                          EnderPearlEntity var116 = var317;
                                          Entity var626 = var116.getOwner();
                                          MinecraftClient var117 = b;
                                          ClientPlayerEntity var467 = var117.player;
                                          Entity var466 = var626;
                                          if (var466 != var467) {
                                             break label534;
                                          }

                                          EnderPearlEntity var468 = var40;
                                          var318 = var468;
                                       }

                                       EnderPearlEntity var120 = var318;
                                       int var470 = var32;
                                       int var469 = var120.age;
                                       int var320 = var469;
                                       int var319 = var469;
                                       if (var470 != 0) {
                                          int var472 = var37;
                                          int var471 = var319;
                                          if (var471 >= var472) {
                                             break label534;
                                          }

                                          EnderPearlEntity var122 = var40;
                                          int var473 = var122.age;
                                          var320 = var473;
                                       }

                                       var37 = var320;
                                       var36 = var40;
                                    }

                                    int var474 = var32;
                                    if (var474 != 0) {
                                       continue;
                                    }
                                 }

                                 EnderPearlEntity var327;
                                 int var476 = var32;
                                 EnderPearlEntity var475 = var36;
                                 var327 = var475;
                                 EnderPearlEntity var321 = var475;
                                 label301:
                                 if (var476 != 0) {
                                    EnderPearlEntity var477 = var321;
                                    if (var477 == null) {
                                       MinecraftClient var125 = b;
                                       ClientWorld var126 = var125.world;
                                       Iterable var127 = var126.getEntities();
                                       var38 = var127.iterator();

                                       int var490;
                                       do {
                                          Iterator var128 = var38;
                                          boolean var478 = var128.hasNext();
                                          if (!var478) {
                                             break;
                                          }

                                          label537: {
                                             Iterator var129 = var38;
                                             Entity var606 = (Entity)var129.next();
                                             int var480 = var32;
                                             Entity var479 = var606;
                                             Entity var325 = var479;
                                             Entity var322 = var479;
                                             if (var480 != 0) {
                                                boolean var627 = var322 instanceof EnderPearlEntity;
                                                int var482 = var32;
                                                boolean var481 = var627;
                                                var335 = var481;
                                                boolean var323 = var481;
                                                if (var482 == 0) {
                                                   break label322;
                                                }

                                                boolean var483 = var323;
                                                boolean var324 = var483;
                                                boolean var484 = var324;
                                                if (!var484) {
                                                   break label537;
                                                }

                                                var325 = var606;
                                             }

                                             EnderPearlEntity var611 = (EnderPearlEntity)var325;
                                             int var486 = var32;
                                             EnderPearlEntity var485 = var611;
                                             var327 = var485;
                                             EnderPearlEntity var326 = var485;
                                             if (var486 == 0) {
                                                break label301;
                                             }

                                             EnderPearlEntity var132 = var326;
                                             Entity var628 = var132.getOwner();
                                             MinecraftClient var133 = b;
                                             ClientPlayerEntity var488 = var133.player;
                                             Entity var487 = var628;
                                             if (var487 != var488) {
                                                break;
                                             }

                                             var36 = var611;
                                             int var489 = var32;
                                             if (var489 != 0) {
                                                break;
                                             }
                                          }

                                          var490 = var32;
                                       } while (var490 != 0);
                                    }

                                    var327 = var36;
                                 }

                                 EnderPearlEntity var491 = var327;
                                 if (var491 != null) {
                                    Rotation var44;
                                    label539: {
                                       MinecraftClient var136 = b;
                                       ClientPlayerEntity var137 = var136.player;
                                       Vec3d var602 = var137.getVelocity();
                                       float var607 = this.p;
                                       double var138 = var607;
                                       double var612 = Math.toRadians(var138);
                                       double var140 = var612;
                                       double var645 = -Math.sin(var140);
                                       double var142 = var612;
                                       Vec3d var144 = new Vec3d(var645, 0.0, Math.cos(var142));
                                       Vec3d var42 = var144.normalize();
                                       Vec3d var145 = var602;
                                       Vec3d var146 = var42;
                                       double var629 = var145.x * var146.x;
                                       Vec3d var147 = var602;
                                       Vec3d var148 = var42;
                                       float var43 = (float)(var629 + var147.z * var148.z);
                                       float var10003 = this.p;
                                       FloatSetting var149 = this.f;
                                       Float var150 = (Float)var149.aReturningObject();
                                       Object[] var152 = new Object[]{new Rotation(var10003, -var150 + var43 * 1.6F), var6};
                                       FastPearlCatch var151 = this;
                                       var44 = var151.cReturningdx_C0210(var152);
                                       Object[] var10005 = new Object[]{null, Hand.MAIN_HAND, var10};
                                       var10005[0] = var35;
                                       Object[] var154 = var10005;
                                       FastPearlCatch var153 = this;
                                       byte var630 = ((byte)((var153.fReturningBoolean(var154)) ? 1 : 0));
                                       int var493 = var32;
                                       byte var492 = var630;
                                       byte var329 = var492;
                                       byte var328 = var492;
                                       if (var493 != 0) {
                                          byte var494 = var328;
                                          if (var494 == 0) {
                                             break label539;
                                          }

                                          this.k = true;
                                          this.n = false;
                                          BooleanSetting var156 = this.g;
                                          Boolean var157 = (Boolean)var156.aReturningObject();
                                          byte var495 = ((byte)(((java.lang.Boolean)(var157)).booleanValue() ? 1 : 0));
                                          var329 = var495;
                                       }

                                       int var497 = var32;
                                       byte var496 = var329;
                                       int var331 = var496;
                                       byte var330 = var496;
                                       if (var497 != 0) {
                                          byte var498 = var330;
                                          if (var498 == 0) {
                                             break label539;
                                          }

                                          int var499 = this.z;
                                          var331 = var499;
                                       }

                                       int var501 = var32;
                                       int var500 = var331;
                                       int var333 = var500;
                                       int var332 = var500;
                                       if (var501 != 0) {
                                          int var503 = var35;
                                          int var502 = var332;
                                          if (var502 == var503) {
                                             break label539;
                                          }

                                          int var504 = this.z;
                                          var333 = var504;
                                       }

                                       Object[] var649 = new Object[]{null, var18};
                                       var649[0] = var333;
                                       Object[] var163 = var649;
                                       InventoryUtil.aReturningVoid(var163);
                                    }

                                    Object[] var165 = new Object[0];
                                    Rotation var164 = var44;
                                    float var646 = var164.aReturningFloat(var165);
                                    Object[] var167 = new Object[0];
                                    Rotation var166 = var44;
                                    return new Rotation(var646, var166.bReturningFloat(var167));
                                 }

                                 int var506 = var32;
                                 FastPearlCatch var505 = this;
                                 var336 = var505;
                                 FastPearlCatch var334 = var505;
                                 if (var506 == 0) {
                                    break label532;
                                 }

                                 Object[] var169 = new Object[]{var12};
                                 FastPearlCatch var168 = var334;
                                 boolean var507 = var168.dReturningBoolean(var169);
                                 var335 = var507;
                                 break;
                              }

                              boolean var508 = var335;
                              if (!var508) {
                                 return null;
                              }

                              var336 = this;
                           }

                           Object[] var172 = new Object[]{var24};
                           FastPearlCatch var171 = var336;
                           var171.aReturningVoid(var172);
                        }

                        return null;
                     }

                     Object[] var96 = new Object[]{var24};
                     FastPearlCatch var95 = this;
                     var95.aReturningVoid(var96);
                     return null;
                  }
               }

               ModeSetting var173 = this.c;
               String var623 = (String)var173.aReturningObject();
               short var641 = 14135;
               long var644 = 6125029612662954390L ^ var2;
               String var175 = "Offhand";
               String var174 = var623;
               var337 = var174.equals(var175);
            }

            int var342;
            label467: {
               FastPearlCatch var341;
               label540: {
                  int var510 = var32;
                  boolean var509 = var337;
                  boolean var340 = var509;
                  boolean var338 = var509;
                  if (var510 != 0) {
                     boolean var511 = var338;
                     if (var511) {
                        Object[] var178 = new Object[]{var14};
                        FastPearlCatch var177 = this;
                        return var177.bReturningdx_C0210(var178);
                     }

                     int var513 = var32;
                     FastPearlCatch var512 = this;
                     var341 = var512;
                     FastPearlCatch var339 = var512;
                     if (var513 == 0) {
                        break label540;
                     }

                     boolean var514 = var339.j;
                     var340 = var514;
                  }

                  boolean var515 = var340;
                  if (var515) {
                     // var342 = var516;
                     break label467;
                  }

                  var341 = this;
               }

               Object[] var183 = new Object[]{var20};
               FastPearlCatch var182 = var341;
               var342 = var182.dReturningInt(var183);
            }

            label571: {
               FastPearlCatch var354;
               int var595;
               label543: {
                  int var353;
                  int var596;
                  label544: {
                     int var350;
                     byte var351;
                     label545: {
                        var595 = var342;
                        Object[] var185 = new Object[]{var30};
                        FastPearlCatch var184 = this;
                        var596 = var184.eReturningInt(var185);
                        int var518 = var32;
                        byte var517 = ((byte)((this.j) ? 1 : 0));
                        int var348 = var517;
                        byte var343 = var517;
                        if (var518 != 0) {
                           byte var519 = var343;
                           if (var519 == 0) {
                              int var522 = var32;
                              // int var520 = var595;
                              var350 = var520;
                              var351 = var521;
                              int var344 = var520;
                              byte var345 = var521;
                              if (var522 == 0) {
                                 break label545;
                              }

                              byte var524 = var345;
                              int var523 = var344;
                              int var346 = var523;
                              byte var347 = var524;
                              byte var526 = var347;
                              int var525 = var346;
                              if (var525 == var526) {
                                 break label571;
                              }
                           }

                           var348 = var596;
                        }

                        int var528 = var32;
                        int var527 = var348;
                        var353 = var527;
                        int var349 = var527;
                        if (var528 == 0) {
                           break label544;
                        }

                        // int var529 = var349;
                        var350 = var529;
                        var351 = var530;
                     }

                     byte var532 = var351;
                     int var531 = var350;
                     if (var531 == var532) {
                        break label571;
                     }

                     int var534 = var32;
                     FastPearlCatch var533 = this;
                     var354 = var533;
                     FastPearlCatch var352 = var533;
                     if (var534 == 0) {
                        break label543;
                     }

                     byte var535 = ((byte)((var352.j) ? 1 : 0));
                     var353 = var535;
                  }

                  int var536 = var353;
                  if (var536 != 0) {
                     EnderPearlEntity var598 = null;
                     short var632 = 12863;
                     long var643 = 962535551029621131L ^ var2;
                     int var600 = Integer.MAX_VALUE;
                     MinecraftClient var204 = b;
                     ClientWorld var205 = var204.world;
                     Iterable var206 = var205.getEntities();
                     Iterator var603 = var206.iterator();

                     FastPearlCatch var383;
                     label547: {
                        boolean var382;
                        label429:
                        while (true) {
                           Iterator var207 = var603;
                           boolean var543 = var207.hasNext();
                           if (var543) {
                              label549: {
                                 Iterator var208 = var603;
                                 Entity var608 = (Entity)var208.next();
                                 int var545 = var32;
                                 Entity var544 = var608;
                                 Entity var362 = var544;
                                 Entity var359 = var544;
                                 if (var545 != 0) {
                                    boolean var633 = var359 instanceof EnderPearlEntity;
                                    int var547 = var32;
                                    boolean var546 = var633;
                                    var382 = var546;
                                    boolean var360 = var546;
                                    if (var547 == 0) {
                                       break;
                                    }

                                    boolean var548 = var360;
                                    boolean var361 = var548;
                                    boolean var549 = var361;
                                    if (!var549) {
                                       break label549;
                                    }

                                    var362 = var608;
                                 }

                                 EnderPearlEntity var613 = (EnderPearlEntity)var362;
                                 int var551 = var32;
                                 EnderPearlEntity var550 = var613;
                                 EnderPearlEntity var364 = var550;
                                 EnderPearlEntity var363 = var550;
                                 if (var551 != 0) {
                                    EnderPearlEntity var211 = var363;
                                    Entity var634 = var211.getOwner();
                                    MinecraftClient var212 = b;
                                    ClientPlayerEntity var553 = var212.player;
                                    Entity var552 = var634;
                                    if (var552 != var553) {
                                       break label549;
                                    }

                                    EnderPearlEntity var554 = var613;
                                    var364 = var554;
                                 }

                                 EnderPearlEntity var215 = var364;
                                 int var556 = var32;
                                 int var555 = var215.age;
                                 int var366 = var555;
                                 int var365 = var555;
                                 if (var556 != 0) {
                                    int var558 = var600;
                                    int var557 = var365;
                                    if (var557 >= var558) {
                                       break label549;
                                    }

                                    EnderPearlEntity var217 = var613;
                                    int var559 = var217.age;
                                    var366 = var559;
                                 }

                                 var600 = var366;
                                 var598 = var613;
                              }

                              int var560 = var32;
                              if (var560 != 0) {
                                 continue;
                              }
                           }

                           EnderPearlEntity var373;
                           int var562 = var32;
                           EnderPearlEntity var561 = var598;
                           var373 = var561;
                           EnderPearlEntity var367 = var561;
                           label408:
                           if (var562 != 0) {
                              EnderPearlEntity var563 = var367;
                              if (var563 == null) {
                                 MinecraftClient var220 = b;
                                 ClientWorld var221 = var220.world;
                                 Iterable var222 = var221.getEntities();
                                 var603 = var222.iterator();

                                 int var576;
                                 do {
                                    Iterator var223 = var603;
                                    boolean var564 = var223.hasNext();
                                    if (!var564) {
                                       break;
                                    }

                                    label552: {
                                       Iterator var224 = var603;
                                       Entity var609 = (Entity)var224.next();
                                       int var566 = var32;
                                       Entity var565 = var609;
                                       Entity var371 = var565;
                                       Entity var368 = var565;
                                       if (var566 != 0) {
                                          boolean var635 = var368 instanceof EnderPearlEntity;
                                          int var568 = var32;
                                          boolean var567 = var635;
                                          var382 = var567;
                                          boolean var369 = var567;
                                          if (var568 == 0) {
                                             break label429;
                                          }

                                          boolean var569 = var369;
                                          boolean var370 = var569;
                                          boolean var570 = var370;
                                          if (!var570) {
                                             break label552;
                                          }

                                          var371 = var609;
                                       }

                                       EnderPearlEntity var614 = (EnderPearlEntity)var371;
                                       int var572 = var32;
                                       EnderPearlEntity var571 = var614;
                                       var373 = var571;
                                       EnderPearlEntity var372 = var571;
                                       if (var572 == 0) {
                                          break label408;
                                       }

                                       EnderPearlEntity var227 = var372;
                                       Entity var636 = var227.getOwner();
                                       MinecraftClient var228 = b;
                                       ClientPlayerEntity var574 = var228.player;
                                       Entity var573 = var636;
                                       if (var573 != var574) {
                                          break;
                                       }

                                       var598 = var614;
                                       int var575 = var32;
                                       if (var575 != 0) {
                                          break;
                                       }
                                    }

                                    var576 = var32;
                                 } while (var576 != 0);
                              }

                              var373 = var598;
                           }

                           EnderPearlEntity var577 = var373;
                           if (var577 != null) {
                              Rotation var618;
                              label373: {
                                 FastPearlCatch var380;
                                 label554: {
                                    MinecraftClient var231 = b;
                                    ClientPlayerEntity var232 = var231.player;
                                    Vec3d var605 = var232.getVelocity();
                                    float var610 = this.p;
                                    double var233 = var610;
                                    double var615 = Math.toRadians(var233);
                                    double var235 = var615;
                                    double var647 = -Math.sin(var235);
                                    double var237 = var615;
                                    Vec3d var239 = new Vec3d(var647, 0.0, Math.cos(var237));
                                    Vec3d var616 = var239.normalize();
                                    Vec3d var240 = var605;
                                    Vec3d var241 = var616;
                                    double var637 = var240.x * var241.x;
                                    Vec3d var242 = var605;
                                    Vec3d var243 = var616;
                                    float var617 = (float)(var637 + var242.z * var243.z);
                                    float var651 = this.p;
                                    FloatSetting var244 = this.f;
                                    Float var245 = (Float)var244.aReturningObject();
                                    Object[] var247 = new Object[]{new Rotation(var651, -var245 + var617 * 1.6F), var6};
                                    FastPearlCatch var246 = this;
                                    var618 = var246.cReturningdx_C0210(var247);
                                    Object[] var655 = new Object[]{null, Hand.MAIN_HAND, var10};
                                    var655[0] = var596;
                                    Object[] var249 = var655;
                                    FastPearlCatch var248 = this;
                                    boolean var638 = var248.fReturningBoolean(var249);
                                    int var579 = var32;
                                    boolean var578 = var638;
                                    boolean var377 = var578;
                                    boolean var374 = var578;
                                    if (var579 != 0) {
                                       boolean var580 = var374;
                                       if (!var580) {
                                          break label373;
                                       }

                                       int var582 = var32;
                                       FastPearlCatch var581 = this;
                                       var380 = var581;
                                       FastPearlCatch var375 = var581;
                                       if (var582 == 0) {
                                          break label554;
                                       }

                                       FastPearlCatch var583 = var375;
                                       FastPearlCatch var376 = var583;
                                       BooleanSetting var252 = var376.g;
                                       Boolean var253 = (Boolean)var252.aReturningObject();
                                       boolean var584 = var253;
                                       var377 = var584;
                                    }

                                    boolean var585 = var377;
                                    if (var585) {
                                       int var587 = var32;
                                       FastPearlCatch var586 = this;
                                       var380 = var586;
                                       FastPearlCatch var378 = var586;
                                       if (var587 == 0) {
                                          break label554;
                                       }

                                       FastPearlCatch var588 = var378;
                                       FastPearlCatch var379 = var588;
                                       int var590 = var596;
                                       int var589 = var379.z;
                                       if (var589 != var590) {
                                          int var639 = this.z;
                                          Object[] var652 = new Object[]{null, var18};
                                          var652[0] = var639;
                                          Object[] var257 = var652;
                                          InventoryUtil.aReturningVoid(var257);
                                       }
                                    }

                                    var380 = this;
                                 }

                                 var380.u = true;
                              }

                              Object[] var260 = new Object[0];
                              Rotation var259 = var618;
                              float var648 = var259.aReturningFloat(var260);
                              Object[] var262 = new Object[0];
                              Rotation var261 = var618;
                              return new Rotation(var648, var261.bReturningFloat(var262));
                           }

                           int var592 = var32;
                           FastPearlCatch var591 = this;
                           var383 = var591;
                           FastPearlCatch var381 = var591;
                           if (var592 == 0) {
                              break label547;
                           }

                           Object[] var264 = new Object[]{var12};
                           FastPearlCatch var263 = var381;
                           boolean var593 = var263.dReturningBoolean(var264);
                           var382 = var593;
                           break;
                        }

                        boolean var594 = var382;
                        if (!var594) {
                           return null;
                        }

                        var383 = this;
                     }

                     Object[] var267 = new Object[]{var24};
                     FastPearlCatch var266 = var383;
                     var266.aReturningVoid(var267);
                     return null;
                  }

                  var354 = this;
               }

               float var653 = this.p;
               FloatSetting var194 = this.d;
               Float var195 = (Float)var194.aReturningObject();
               Object[] var197 = new Object[]{new Rotation(var653, -var195), var6};
               FastPearlCatch var196 = var354;
               Rotation var599 = var196.cReturningdx_C0210(var197);
               int var539 = var32;
               int var538 = var595;
               FastPearlCatch var537 = this;
               FastPearlCatch var357 = var537;
               int var358 = var538;
               FastPearlCatch var355 = var537;
               int var356 = var538;
               if (var539 != 0) {
                  Object[] var656 = new Object[]{null, Hand.MAIN_HAND, var10};
                  var656[0] = var356;
                  Object[] var199 = var656;
                  FastPearlCatch var198 = var355;
                  boolean var540 = var198.fReturningBoolean(var199);
                  if (!var540) {
                     return var599;
                  }

                  byte var542 = 1;
                  FastPearlCatch var541 = this;
                  var357 = var541;
                  var358 = var542;
               }

               var357.j = dev.prestige.recovery.SourceSupport.asBoolean(var358);
               ElapsedTimer var640 = this.l;
               Object[] var203 = new Object[]{var28};
               ElapsedTimer var202 = var640;
               var202.aReturningVoid(var203);
               return var599;
            }

            Object[] var191 = new Object[]{var24};
            FastPearlCatch var190 = this;
            var190.aReturningVoid(var191);
            return null;
         }

         Object[] var60 = new Object[]{var8};
         FastPearlCatch var59 = this;
         var59.jReturningVoid(var60);
         int var395 = var32;
         FastPearlCatch var394 = this;
         FastPearlCatch var276 = var394;
         FastPearlCatch var273 = var394;
         if (var395 == 0) {
            return var276.q;
         }

         FastPearlCatch var396 = var273;
         FastPearlCatch var274 = var396;
         boolean var397 = var274.t;
         var275 = var397;
      }

      boolean var398 = var275;
      if (!var398) {
         return null;
      }

      FastPearlCatch var657 = this;
      return var657.q;
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 74698342396403L;
      ElapsedTimer var10000 = this.l;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = 1500.0F;
      Object[] var7 = var10004;
      ElapsedTimer var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 56510110335852L;
      long var6 = var2 ^ 60758749284090L;
      long var8 = var2 ^ 123160026792473L;
      long var10 = var2 ^ 101595015561658L;
      long var12 = var2 ^ 103806449457424L;
      long var14 = var2 ^ 95420649563897L;
      long var16 = var2 ^ 64102885891574L;
      long var18 = var2 ^ 136165815371851L;
      long var20 = var2 ^ 112016667384791L;
      long var22 = var2 ^ 64157035785939L;
      long var24 = var2 ^ 54743179414415L;
      long var26 = var2 ^ 101575378833835L;
      long var28 = var2 ^ 64040134026368L;
      int var30 = Event.cReturningInt();
      FastPearlCatchState var38 = this.y;
      int var10000 = var38.ordinal();
      int var205 = var30;
      int var204 = var10000;
      int var166 = var204;
      int var165 = var204;
      if (var205 != 0) {
         int var206 = var165;
         switch (var206) {
            case 0:
               RotationManager var297 = Prestige.o;
               Object[] var41 = new Object[0];
               RotationManager var40 = var297;
               byte var207 = ((byte)((var40.fReturningBoolean(var41)) ? 1 : 0));
               var166 = var207;
               break;
            case 1:
               Object[] var81 = new Object[]{var16};
               FastPearlCatch var80 = this;
               int var284 = var80.dReturningInt(var81);
               int var237 = var30;
               if (var237 != 0) {
                  // int var238 = var284;
                  if (var238 != var239) {
                     float var304 = this.p;
                     FloatSetting var86 = this.e;
                     Float var87 = (Float)var86.aReturningObject();
                     Object[] var89 = new Object[]{new Rotation(var304, -var87), var4};
                     FastPearlCatch var88 = this;
                     Rotation var286 = var88.cReturningdx_C0210(var89);
                     int var241 = var30;
                     FastPearlCatch var240 = this;
                     FastPearlCatch var182 = var240;
                     FastPearlCatch var181 = var240;
                     if (var241 != 0) {
                        Object[] var10005 = new Object[]{null, Hand.MAIN_HAND, var10};
                        var10005[0] = var284;
                        Object[] var91 = var10005;
                        FastPearlCatch var90 = var181;
                        boolean var242 = var90.fReturningBoolean(var91);
                        if (!var242) {
                           return var286;
                        }

                        ElapsedTimer var296 = this.l;
                        Object[] var94 = new Object[]{var24};
                        ElapsedTimer var93 = var296;
                        var93.aReturningVoid(var94);
                        FastPearlCatch var243 = this;
                        var182 = var243;
                     }

                     var182.y = FastPearlCatchState.WIND;
                     return var286;
                  }

                  Object[] var84 = new Object[]{var20};
                  FastPearlCatch var83 = this;
                  var83.aReturningVoid(var84);
               }

               return null;
            case 2:
               Object[] var97 = new Object[]{var22};
               FastPearlCatch var96 = this;
               EnderPearlEntity var31 = var96.aReturningEnderPearlEntity(var97);
               EnderPearlEntity var244 = var31;
               if (var244 == null) {
                  int var246 = var30;
                  FastPearlCatch var245 = this;
                  FastPearlCatch var185 = var245;
                  FastPearlCatch var183 = var245;
                  if (var246 != 0) {
                     FastPearlCatch var247 = var183;
                     FastPearlCatch var184 = var247;
                     Object[] var100 = new Object[]{var12};
                     FastPearlCatch var99 = var184;
                     boolean var248 = var99.dReturningBoolean(var100);
                     if (!var248) {
                        return null;
                     }

                     FastPearlCatch var249 = this;
                     var185 = var249;
                  }

                  Object[] var104 = new Object[]{var20};
                  FastPearlCatch var103 = var185;
                  var103.aReturningVoid(var104);
                  return null;
               }

               Rotation var37;
               label150: {
                  FastPearlCatch var192;
                  label210: {
                     MinecraftClient var105 = b;
                     ClientPlayerEntity var106 = var105.player;
                     Vec3d var32 = var106.getVelocity();
                     double var107 = this.p;
                     double var33 = Math.toRadians(var107);
                     double var109 = var33;
                     double var10002 = -Math.sin(var109);
                     double var111 = var33;
                     Vec3d var113 = new Vec3d(var10002, 0.0, Math.cos(var111));
                     Vec3d var35 = var113.normalize();
                     Vec3d var114 = var32;
                     Vec3d var115 = var35;
                     double var294 = var114.x * var115.x;
                     Vec3d var116 = var32;
                     Vec3d var117 = var35;
                     float var36 = (float)(var294 + var116.z * var117.z);
                     float var303 = this.p;
                     FloatSetting var118 = this.f;
                     Float var119 = (Float)var118.aReturningObject();
                     Object[] var121 = new Object[]{new Rotation(var303, -var119 + var36 * 1.6F), var4};
                     FastPearlCatch var120 = this;
                     var37 = var120.cReturningdx_C0210(var121);
                     Object[] var122 = new Object[]{Items.WIND_CHARGE, var6};
                     boolean var295 = InventoryUtil.mReturningBoolean(var122);
                     int var251 = var30;
                     boolean var250 = var295;
                     boolean var191 = var250;
                     boolean var186 = var250;
                     if (var251 != 0) {
                        boolean var252 = var186;
                        if (!var252) {
                           label138: {
                              int var254 = var30;
                              FastPearlCatch var253 = this;
                              FastPearlCatch var189 = var253;
                              FastPearlCatch var187 = var253;
                              if (var254 != 0) {
                                 FastPearlCatch var255 = var187;
                                 FastPearlCatch var188 = var255;
                                 Object[] var126 = new Object[]{var12};
                                 FastPearlCatch var125 = var188;
                                 boolean var256 = var125.dReturningBoolean(var126);
                                 if (!var256) {
                                    break label138;
                                 }

                                 FastPearlCatch var257 = this;
                                 var189 = var257;
                              }

                              Object[] var130 = new Object[]{var20};
                              FastPearlCatch var129 = var189;
                              var129.aReturningVoid(var130);
                           }

                           Object[] var132 = new Object[0];
                           Rotation var131 = var37;
                           float var301 = var131.aReturningFloat(var132);
                           Object[] var134 = new Object[0];
                           Rotation var133 = var37;
                           return new Rotation(var301, var133.bReturningFloat(var134));
                        }

                        int var259 = var30;
                        FastPearlCatch var258 = this;
                        var192 = var258;
                        FastPearlCatch var190 = var258;
                        if (var259 == 0) {
                           break label210;
                        }

                        Object[] var136 = new Object[]{var37, var8};
                        FastPearlCatch var135 = var190;
                        boolean var260 = var135.aReturningBoolean(var136);
                        var191 = var260;
                     }

                     boolean var261 = var191;
                     if (!var261) {
                        break label150;
                     }

                     var192 = this;
                  }

                  var192.y = FastPearlCatchState.RESTORE;
               }

               Object[] var139 = new Object[0];
               Rotation var138 = var37;
               float var300 = var138.aReturningFloat(var139);
               Object[] var141 = new Object[0];
               Rotation var140 = var37;
               return new Rotation(var300, var140.bReturningFloat(var141));
            case 3:
               RotationManager var289 = Prestige.o;
               Object[] var143 = new Object[0];
               RotationManager var142 = var289;
               int var290 = (((var142.fReturningBoolean(var143)) ? 1 : 0));
               int var263 = var30;
               byte var262 = (byte)var290;
               int var194 = var262;
               byte var193 = var262;
               if (var263 != 0) {
                  byte var264 = var193;
                  if (var264 != 0) {
                     return null;
                  }

                  var194 = this.A;
               }

               label124: {
                  int var203;
                  label206: {
                     int var267 = var30;
                     // int var265 = var194;
                     int var201 = var265;
                     int var202 = var266;
                     int var195 = var265;
                     byte var196 = var266;
                     if (var267 != 0) {
                        byte var269 = var196;
                        int var268 = var195;
                        if (var268 != var269) {
                           label118: {
                              Object[] var147 = new Object[]{var28};
                              var290 = InventoryUtil.aReturningInt(var147);
                              int var271 = var30;
                              int var270 = var290;
                              int var199 = var270;
                              int var197 = var270;
                              if (var271 != 0) {
                                 int var272 = var197;
                                 int var198 = var272;
                                 int var274 = this.A;
                                 int var273 = var198;
                                 if (var273 == var274) {
                                    break label118;
                                 }

                                 int var275 = this.A;
                                 var199 = var275;
                              }

                              Object[] var10003 = new Object[]{null, var14};
                              var10003[0] = var199;
                              Object[] var151 = var10003;
                              InventoryUtil.aReturningVoid(var151);
                              Object[] var152 = new Object[]{var28};
                              Object[] var153 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var152)), var18};
                              PacketUtil.aReturningVoid(var153);
                           }

                           Object[] var154 = new Object[]{new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN), var18};
                           PacketUtil.aReturningVoid(var154);
                        }

                        Object[] var155 = new Object[]{var28};
                        var290 = InventoryUtil.aReturningInt(var155);
                        int var277 = var30;
                        int var276 = var290;
                        var203 = var276;
                        int var200 = var276;
                        if (var277 == 0) {
                           break label206;
                        }

                        int var279 = this.z;
                        int var278 = var200;
                        var201 = var278;
                        var202 = var279;
                     }

                     int var281 = var202;
                     int var280 = var201;
                     if (var280 == var281) {
                        break label124;
                     }

                     int var282 = this.z;
                     var203 = var282;
                  }

                  Object[] var302 = new Object[]{null, var14};
                  var302[0] = var203;
                  Object[] var158 = var302;
                  InventoryUtil.aReturningVoid(var158);
                  Object[] var159 = new Object[]{var28};
                  Object[] var160 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var159)), var18};
                  PacketUtil.aReturningVoid(var160);
               }

               RotationManager var293 = Prestige.o;
               Object[] var162 = new Object[]{true};
               RotationManager var161 = var293;
               var161.fReturningVoid(var162);
               Object[] var164 = new Object[]{var20};
               FastPearlCatch var163 = this;
               var163.aReturningVoid(var164);
               return null;
            default:
               return null;
         }
      }

      int var209 = var30;
      int var208 = var166;
      int var168 = var208;
      int var167 = var208;
      if (var209 != 0) {
         int var210 = var167;
         if (var210 != 0) {
            return null;
         }

         Object[] var46 = new Object[]{var16};
         FastPearlCatch var45 = this;
         var168 = var45.dReturningInt(var46);
      }

      int var285 = var168;
      Object[] var48 = new Object[]{var26};
      FastPearlCatch var47 = this;
      int var287 = var47.eReturningInt(var48);
      Object[] var49 = new Object[]{Items.WIND_CHARGE, var6};
      byte var288 = ((byte)((InventoryUtil.mReturningBoolean(var49)) ? 1 : 0));
      int var211 = var30;
      if (var211 != 0) {
         // int var212 = var285;
         label188:
         if (var212 != var213) {
            int var173;
            int var215 = var30;
            byte var214 = var288;
            var173 = var214;
            byte var169 = var214;
            label194:
            if (var215 != 0) {
               byte var216 = var169;
               byte var170 = var216;
               byte var217 = var170;
               if (var217 == 0) {
                  int var219 = var30;
                  int var218 = var287;
                  var173 = var218;
                  int var171 = var218;
                  if (var219 == 0) {
                     break label194;
                  }

                  int var220 = var171;
                  int var172 = var220;
                  // int var221 = var172;
                  if (var221 == var222) {
                     break label188;
                  }
               }

               Object[] var58 = new Object[]{var28};
               this.z = InventoryUtil.aReturningInt(var58);
               this.A = -1;
               var173 = var288;
            }

            int var224 = var30;
            int var223 = var173;
            int var178 = var223;
            int var174 = var223;
            if (var224 != 0) {
               int var225 = var174;
               if (var225 == 0) {
                  label176: {
                     Object[] var60 = new Object[]{var28};
                     var10000 = InventoryUtil.aReturningInt(var60);
                     int var227 = var30;
                     int var226 = var10000;
                     int var177 = var226;
                     int var175 = var226;
                     if (var227 != 0) {
                        int var228 = var175;
                        int var176 = var228;
                        int var230 = var287;
                        int var229 = var176;
                        if (var229 == var230) {
                           break label176;
                        }

                        int var231 = var287;
                        var177 = var231;
                     }

                     Object[] var305 = new Object[]{null, var14};
                     var305[0] = var177;
                     Object[] var64 = var305;
                     InventoryUtil.aReturningVoid(var64);
                     Object[] var65 = new Object[]{var28};
                     Object[] var66 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var65)), var18};
                     PacketUtil.aReturningVoid(var66);
                  }

                  Object[] var67 = new Object[]{new PlayerActionC2SPacket(Action.SWAP_ITEM_WITH_OFFHAND, BlockPos.ORIGIN, Direction.DOWN), var18};
                  PacketUtil.aReturningVoid(var67);
                  this.A = var287;
               }

               Object[] var68 = new Object[]{var28};
               var178 = InventoryUtil.aReturningInt(var68);
            }

            label168: {
               int var233 = var30;
               int var232 = var178;
               int var180 = var232;
               int var179 = var232;
               if (var233 != 0) {
                  int var235 = var285;
                  int var234 = var179;
                  if (var234 == var235) {
                     break label168;
                  }

                  int var236 = var285;
                  var180 = var236;
               }

               Object[] var306 = new Object[]{null, var14};
               var306[0] = var180;
               Object[] var71 = var306;
               InventoryUtil.aReturningVoid(var71);
               Object[] var72 = new Object[]{var28};
               Object[] var73 = new Object[]{new UpdateSelectedSlotC2SPacket(InventoryUtil.aReturningInt(var72)), var18};
               PacketUtil.aReturningVoid(var73);
            }

            RotationManager var299 = Prestige.o;
            Object[] var75 = new Object[]{true};
            RotationManager var74 = var299;
            var74.fReturningVoid(var75);
            this.y = FastPearlCatchState.PEARL;
            float var307 = this.p;
            FloatSetting var76 = this.e;
            Float var77 = (Float)var76.aReturningObject();
            Object[] var79 = new Object[]{new Rotation(var307, -var77), var4};
            FastPearlCatch var78 = this;
            return var78.cReturningdx_C0210(var79);
         }

         Object[] var56 = new Object[]{var20};
         FastPearlCatch var55 = this;
         var55.aReturningVoid(var56);
      }

      return null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Rotation var2 = (Rotation)var1[0];
      long var3 = (Long)var1[1];
      var3 = 127713985863032L ^ var3;
      long var5 = var3 ^ 140682801518378L;
      int var7 = Event.bReturningInt();
      if (var7 == 0) {
         RotationManager var10000 = Prestige.o;
         Object[] var13 = new Object[0];
         RotationManager var12 = var10000;
         if (var12.fReturningBoolean(var13)) {
            return dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         Object[] var17 = new Object[0];
         float var10002 = var2.aReturningFloat(var17);
         Object[] var19 = new Object[0];
         float var10003 = var2.bReturningFloat(var19);
         MinecraftClient var20 = b;
         ClientPlayerEntity var21 = var20.player;
         boolean var10004 = var21.isOnGround();
         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         Object[] var24 = new Object[]{new LookAndOnGround(var10002, var10003, var10004, var23.horizontalCollision), var5};
         PacketUtil.aReturningVoid(var24);
      }

      MinecraftClient var25 = b;
      ClientPlayerEntity var26 = var25.player;
      float var8 = var26.getYaw();
      MinecraftClient var27 = b;
      ClientPlayerEntity var28 = var27.player;
      float var9 = var28.getPitch();
      boolean var65 = false ;

      boolean var10;
      try {
         var65 = true;
         MinecraftClient var29 = b;
         ClientPlayerEntity var72 = var29.player;
         Object[] var31 = new Object[0];
         float var33 = var2.aReturningFloat(var31);
         ClientPlayerEntity var32 = var72;
         var32.setYaw(var33);
         MinecraftClient var34 = b;
         var72 = var34.player;
         Object[] var36 = new Object[0];
         float var38 = var2.bReturningFloat(var36);
         ClientPlayerEntity var37 = var72;
         var37.setPitch(var38);
         MinecraftClient var39 = b;
         MinecraftClient var40 = b;
         Hand var43 = Hand.OFF_HAND;
         ClientPlayerEntity var42 = var40.player;
         ClientPlayerInteractionManager var41 = var39.interactionManager;
         ActionResult var44 = var41.interactItem((PlayerEntity)var42, var43);
         var10 = var44.isAccepted();
         RotationManager var74 = Prestige.o;
         Object[] var46 = new Object[]{true};
         RotationManager var45 = var74;
         var45.fReturningVoid(var46);
         this.t = dev.prestige.recovery.SourceSupport.asBoolean(1);
         if (var7 != 0) {
            var65 = false;
            return var10;
         }

         if (var10) {
            MinecraftClient var48 = b;
            Hand var50 = Hand.OFF_HAND;
            ClientPlayerEntity var49 = var48.player;
            var49.swingHand(var50);
            var65 = false;
         } else {
            var65 = false;
         }
      } finally {
         if (var65) {
            MinecraftClient var58 = b;
            ClientPlayerEntity var59 = var58.player;
            var59.setYaw(var8);
            MinecraftClient var61 = b;
            ClientPlayerEntity var62 = var61.player;
            var62.setPitch(var9);
         }
      }

      MinecraftClient var52 = b;
      ClientPlayerEntity var53 = var52.player;
      var53.setYaw(var8);
      MinecraftClient var55 = b;
      ClientPlayerEntity var56 = var55.player;
      var56.setPitch(var9);
      return var10;
   }

   
   private EnderPearlEntity aReturningEnderPearlEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      int var10000 = Event.cReturningInt();
      EnderPearlEntity var5 = null;
      short var10001 = 12863;
      long var10002 = 962637588529383887L ^ var2;
      int var6 = Integer.MAX_VALUE;
      MinecraftClient var10 = b;
      ClientWorld var11 = var10.world;
      Iterable var12 = var11.getEntities();
      Iterator var7 = var12.iterator();
      int var4 = var10000;

      while (true) {
         Iterator var13 = var7;
         boolean var50 = var13.hasNext();
         label96:
         if (var50) {
            Iterator var14 = var7;
            Entity var8 = (Entity)var14.next();
            int var52 = var4;
            Entity var51 = var8;
            Entity var38 = var51;
            Entity var35 = var51;
            if (var52 != 0) {
               boolean var97 = var35 instanceof EnderPearlEntity;
               int var54 = var4;
               boolean var53 = var97;
               boolean var44 = var53;
               boolean var36 = var53;
               if (var54 == 0) {
                  boolean var93 = var44;
                  if (!var93) {
                     return var5;
                  }
                  break;
               }

               boolean var55 = var36;
               boolean var37 = var55;
               boolean var56 = var37;
               if (!var56) {
                  int var92 = var4;
                  if (var92 != 0) {
                     continue;
                  }
                  break label96;
               }

               var38 = var8;
            }

            EnderPearlEntity var9 = (EnderPearlEntity)var38;
            int var58 = var4;
            EnderPearlEntity var57 = var9;
            EnderPearlEntity var40 = var57;
            EnderPearlEntity var39 = var57;
            if (var58 != 0) {
               EnderPearlEntity var17 = var39;
               Entity var98 = var17.getOwner();
               MinecraftClient var18 = b;
               ClientPlayerEntity var60 = var18.player;
               Entity var59 = var98;
               if (var59 != var60) {
                  int var91 = var4;
                  if (var91 != 0) {
                     continue;
                  }
                  break label96;
               }

               EnderPearlEntity var61 = var9;
               var40 = var61;
            }

            EnderPearlEntity var21 = var40;
            int var63 = var4;
            int var62 = var21.age;
            int var42 = var62;
            int var41 = var62;
            if (var63 != 0) {
               int var65 = var6;
               int var64 = var41;
               if (var64 < var65) {
                  EnderPearlEntity var23 = var9;
                  int var66 = var23.age;
                  var42 = var66;
                  var6 = var42;
                  var5 = var9;
               }
            } else {
               var6 = var42;
               var5 = var9;
            }

            int var67 = var4;
            if (var67 != 0) {
               continue;
            }
         }

         int var69 = var4;
         EnderPearlEntity var68 = var5;
         EnderPearlEntity var49 = var68;
         EnderPearlEntity var43 = var68;
         if (var69 == 0) {
            return var49;
         }

         EnderPearlEntity var70 = var43;
         if (var70 != null) {
            return var5;
         }

         MinecraftClient var26 = b;
         ClientWorld var27 = var26.world;
         Iterable var28 = var27.getEntities();
         var7 = var28.iterator();
         Iterator var29 = var7;
         boolean var88 = var29.hasNext();
         boolean var71 = var88;
         if (!var71) {
            return var5;
         }
         break;
      }

      boolean var94;
      do {
         label108: {
            Iterator var30 = var7;
            Entity var84 = (Entity)var30.next();
            int var73 = var4;
            Entity var72 = var84;
            Entity var46 = var72;
            Entity var45 = var72;
            if (var73 != 0) {
               boolean var74 = var45 instanceof EnderPearlEntity;
               if (!var74) {
                  int var96 = var4;
                  if (var96 == 0) {
                     break;
                  }
                  break label108;
               }

               Entity var75 = var84;
               var46 = var75;
            }

            EnderPearlEntity var85 = (EnderPearlEntity)var46;
            int var77 = var4;
            EnderPearlEntity var76 = var85;
            EnderPearlEntity var48 = var76;
            EnderPearlEntity var47 = var76;
            if (var77 != 0) {
               EnderPearlEntity var33 = var47;
               Entity var99 = var33.getOwner();
               MinecraftClient var34 = b;
               ClientPlayerEntity var79 = var34.player;
               Entity var78 = var99;
               if (var78 == var79) {
                  EnderPearlEntity var80 = var85;
                  var48 = var80;
                  var5 = var48;
                  int var81 = var4;
                  if (var81 != 0) {
                     break;
                  }
               }
            } else {
               var5 = var48;
               int var95 = var4;
               if (var95 != 0) {
                  break;
               }
            }

            int var82 = var4;
            if (var82 == 0) {
               break;
            }
         }

         Iterator var86 = var7;
         boolean var89 = var86.hasNext();
         var94 = var89;
      } while (var94);

      return var5;
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      int var10000 = Event.bReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      int var5 = var8.age;
      int var4 = var10000;
      MinecraftClient var9 = b;
      ClientPlayerEntity var10 = var9.player;
      byte var50 = ((byte)((var10.isUsingItem()) ? 1 : 0));
      int var29 = var4;
      byte var28 = var50;
      byte var18 = var28;
      byte var15 = var28;
      if (var29 == 0) {
         byte var30 = var15;
         label49:
         if (var30 == 0) {
            MinecraftClient var12 = b;
            GameOptions var13 = var12.options;
            KeyBinding var14 = var13.useKey;
            var50 = ((byte)((var14.isPressed()) ? 1 : 0));
            int var32 = var4;
            byte var31 = var50;
            int var19 = var31;
            byte var16 = var31;
            if (var32 == 0) {
               byte var33 = var16;
               byte var17 = var33;
               byte var34 = var17;
               if (var34 != 0) {
                  break label49;
               }

               var19 = this.x;
            }

            short var10001 = 30218;
            long var10002 = 8677464956069617796L ^ var2;
            int var38 = var4;
            int var37 = Integer.MIN_VALUE;
            int var36 = var19;
            int var22 = var36;
            int var23 = var37;
            int var20 = var36;
            int var21 = var37;
            if (var38 == 0) {
               int var40 = var21;
               int var39 = var20;
               if (var39 == var40) {
                  return false;
               }

               var23 = this.x;
               var22 = var5;
            }

            int var6 = var22 - var23;
            int var42 = var4;
            int var41 = var6;
            int var27 = var41;
            int var24 = var41;
            if (var42 == 0) {
               int var43 = var24;
               if (var43 >= 0) {
                  int var45 = var4;
                  int var44 = var6;
                  var27 = var44;
                  int var25 = var44;
                  if (var45 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var27);
                  }

                  int var46 = var25;
                  int var26 = var46;
                  byte var48 = 1;
                  int var47 = var26;
                  if (var47 <= var48) {
                     return true;
                  }
               }

               var10001 = 22209;
               var10002 = 6061928129658060875L ^ var2;
               this.x = Integer.MIN_VALUE;
               var27 = 0;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var27);
         }

         this.x = var5;
         byte var35 = 1;
         var18 = var35;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 121139061780481L;
      int var6 = Event.bReturningInt();
      int var13 = var6;
      FastPearlCatch var12 = this;
      FastPearlCatch var11 = var12;
      FastPearlCatch var10 = var12;
      if (var13 == 0) {
         boolean var14 = var10.t;
         if (!var14) {
            Object[] var9 = new Object[]{var4};
            FastPearlCatch var8 = this;
            var8.kReturningVoid(var9);
         }

         this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
         var11 = this;
      }

      var11.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private Rotation cReturningdx_C0210(Object[] var1) {
      Rotation var2 = (Rotation)var1[0];
      long var3 = (Long)var1[1];
      var3 = 127713985863032L ^ var3;
      long var5 = var3 ^ 26699013710790L;
      int var7 = Event.bReturningInt();
      int var20 = var7;
      Rotation var19 = this.q;
      Rotation var18 = var19;
      Rotation var17 = var19;
      if (var20 == 0) {
         Rotation var21 = var17;
         if (var21 == null) {
            Object[] var10 = new Object[0];
            Rotation var9 = var2;
            float var10003 = var9.aReturningFloat(var10);
            Object[] var12 = new Object[0];
            Rotation var11 = var2;
            this.q = new Rotation(var10003, var11.bReturningFloat(var12));
            this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
            MinecraftClient var13 = b;
            this.v = var13.world;
         }

         RotationManager var10000 = Prestige.o;
         Object[] var16 = new Object[]{this, this.q, var5};
         RotationManager var15 = var10000;
         var15.cReturningBoolean(var16);
         var18 = this.q;
      }

      return var18;
   }

   private boolean fReturningBoolean(Object[] var1) {
      int var2;
      Hand var5;
      long var6;
      int var8;
      int var73;
      label125: {
         var2 = (Integer)var1[0];
         var5 = (Hand)var1[1];
         long var3 = (Long)var1[2];
         var3 = 127713985863032L ^ var3;
         var6 = var3 ^ 139127110056507L;
         var8 = Event.cReturningInt();
         FastPearlCatch var10000 = this;
         if (var8 != 0) {
            if (this.q == null) {
               return dev.prestige.recovery.SourceSupport.asBoolean(0);
            }

            var10000 = this;
         }

         if (var8 == 0) {
            return var10000.r;
         }

         if (var10000.r) {
            if (var8 == 0) {
               return this.t;
            }

            if (!this.t) {
               RotationManager var72 = Prestige.o;
               Object[] var19 = new Object[0];
               RotationManager var18 = var72;
               var73 = (((var18.fReturningBoolean(var19)) ? 1 : 0));
               if (var8 == 0) {
                  break label125;
               }

               if (var73 == 0) {
                  var73 = var2;
                  break label125;
               }
            }
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(0);
      }

      label93: {
         if (var8 != 0) {
            if (var73 < 0) {
               break label93;
            }

            var73 = var2;
         }

         Object[] var10003 = new Object[]{null, var6};
         var10003[0] = var73;
         Object[] var23 = var10003;
         InventoryUtil.aReturningVoid(var23);
      }

      MinecraftClient var24 = b;
      ClientPlayerEntity var25 = var24.player;
      float var9 = var25.getYaw();
      MinecraftClient var26 = b;
      ClientPlayerEntity var27 = var26.player;
      float var10 = var27.getPitch();
      boolean var64 = false ;

      boolean var11;
      try {
         var64 = true;
         MinecraftClient var28 = b;
         ClientPlayerEntity var74 = var28.player;
         Rotation var10001 = this.q;
         Object[] var30 = new Object[0];
         Rotation var29 = var10001;
         float var32 = var29.aReturningFloat(var30);
         ClientPlayerEntity var31 = var74;
         var31.setYaw(var32);
         MinecraftClient var33 = b;
         ClientPlayerEntity var75 = var33.player;
         var10001 = this.q;
         Object[] var35 = new Object[0];
         Rotation var34 = var10001;
         float var37 = var34.bReturningFloat(var35);
         ClientPlayerEntity var36 = var75;
         var36.setPitch(var37);
         MinecraftClient var38 = b;
         MinecraftClient var39 = b;
         ClientPlayerEntity var41 = var39.player;
         ClientPlayerInteractionManager var40 = var38.interactionManager;
         ActionResult var43 = var40.interactItem((PlayerEntity)var41, var5);
         var11 = var43.isAccepted();
         RotationManager var76 = Prestige.o;
         Object[] var45 = new Object[]{true};
         RotationManager var44 = var76;
         var44.fReturningVoid(var45);
         this.t = dev.prestige.recovery.SourceSupport.asBoolean(1);
         if (var8 == 0) {
            var64 = false;
            return var11;
         }

         if (var11) {
            MinecraftClient var47 = b;
            ClientPlayerEntity var48 = var47.player;
            var48.swingHand(var5);
            var64 = false;
         } else {
            var64 = false;
         }
      } finally {
         if (var64) {
            MinecraftClient var57 = b;
            ClientPlayerEntity var58 = var57.player;
            var58.setYaw(var9);
            MinecraftClient var60 = b;
            ClientPlayerEntity var61 = var60.player;
            var61.setPitch(var10);
         }
      }

      MinecraftClient var51 = b;
      ClientPlayerEntity var52 = var51.player;
      var52.setYaw(var9);
      MinecraftClient var54 = b;
      ClientPlayerEntity var55 = var54.player;
      var55.setPitch(var10);
      return var11;
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 61622635493250L ^ 105923397016163L;
      var10001 = 61622635493250L ^ 82291531534298L;
      var10001 = 61622635493250L ^ 123410497612255L;
      var10001 = 61622635493250L ^ 92958656215419L;
      int var12 = Event.bReturningInt();
      Rotation var62 = this.q;
      if (var62 != null) {
         Object[] var16 = new Object[0];
         PlayerUpdateEvent var15 = var1;
         EventPhase var10000 = var15.aReturningEventPhase(var16);
         int var65 = var12;
         EventPhase var64 = EventPhase.PRE;
         EventPhase var63 = var10000;
         EventPhase var48 = var63;
         EventPhase var49 = var64;
         EventPhase var46 = var63;
         EventPhase var47 = var64;
         if (var65 == 0) {
            EventPhase var67 = var47;
            EventPhase var66 = var46;
            if (var66 == var67) {
               RotationManager var94 = Prestige.o;
               Object[] var19 = new Object[]{this, this.q, 79397261631069L};
               RotationManager var18 = var94;
               boolean var68 = var18.cReturningBoolean(var19);
               if (!var68) {
                  this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  return;
               }

               Rotation var98 = this.q;
               Object[] var23 = new Object[0];
               Rotation var22 = var98;
               Object[] var25 = new Object[]{var22.aReturningFloat(var23)};
               PlayerUpdateEvent var24 = var1;
               var24.bReturningVoid(var25);
               Rotation var99 = this.q;
               Object[] var27 = new Object[0];
               Rotation var26 = var99;
               Object[] var29 = new Object[]{var26.bReturningFloat(var27)};
               PlayerUpdateEvent var28 = var1;
               var28.cReturningVoid(var29);
               this.s = dev.prestige.recovery.SourceSupport.asBoolean(1);
               return;
            }

            Object[] var31 = new Object[0];
            PlayerUpdateEvent var30 = var1;
            var10000 = var30.aReturningEventPhase(var31);
            var49 = EventPhase.POST;
            var48 = var10000;
         }

         EventPhase var70 = var49;
         EventPhase var69 = var48;
         if (var69 == var70) {
            int var72 = var12;
            boolean var71 = this.s;
            boolean var52 = var71;
            boolean var50 = var71;
            if (var72 == 0) {
               boolean var73 = var50;
               boolean var51 = var73;
               boolean var74 = var51;
               if (!var74) {
                  return;
               }

               this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
               RotationManager var93 = Prestige.o;
               Object[] var35 = new Object[]{this, 119298033110777L};
               RotationManager var34 = var93;
               var52 = var34.dReturningBoolean(var35);
            }

            FastPearlCatch var61;
            label96: {
               int var76 = var12;
               boolean var75 = var52;
               boolean var55 = var75;
               boolean var53 = var75;
               if (var76 == 0) {
                  boolean var77 = var53;
                  if (!var77) {
                     return;
                  }

                  int var79 = var12;
                  FastPearlCatch var78 = this;
                  var61 = var78;
                  FastPearlCatch var54 = var78;
                  if (var79 != 0) {
                     break label96;
                  }

                  boolean var80 = var54.t;
                  var55 = var80;
               }

               boolean var81 = var55;
               if (var81) {
                  label61: {
                     FastPearlCatch var60;
                     label90: {
                        boolean var13 = this.u;
                        Object[] var39 = new Object[]{97158959181281L};
                        FastPearlCatch var38 = this;
                        var38.kReturningVoid(var39);
                        int var83 = var12;
                        boolean var82 = var13;
                        boolean var59 = var82;
                        boolean var56 = var82;
                        if (var83 == 0) {
                           boolean var84 = var56;
                           if (!var84) {
                              break label61;
                           }

                           int var86 = var12;
                           FastPearlCatch var85 = this;
                           var60 = var85;
                           FastPearlCatch var57 = var85;
                           if (var86 != 0) {
                              break label90;
                           }

                           FastPearlCatch var87 = var57;
                           FastPearlCatch var58 = var87;
                           FastPearlCatch var42 = var58;
                           boolean var88 = var42.aReturningBoolean();
                           var59 = var88;
                        }

                        boolean var89 = var59;
                        if (!var89) {
                           break label61;
                        }

                        var60 = this;
                     }

                     Object[] var45 = new Object[]{126290808879192L};
                     FastPearlCatch var44 = var60;
                     var44.aReturningVoid(var45);
                  }

                  int var90 = var12;
                  if (var90 == 0) {
                     return;
                  }
               }

               FastPearlCatch var91 = this;
               var61 = var91;
            }

            var61.r = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }
      }
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 41542619997680L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.bReturningVoid(var7);
      this.q = null;
      this.v = null;
      this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.u = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void lReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 115056686211788L;
      long var6 = var2 ^ 24242833057581L;
      long var8 = var2 ^ 32964339566626L;
      int var10 = Event.cReturningInt();
      MinecraftClient var12 = b;
      ClientWorld var31 = var12.world;
      Object var30 = this.w;
      byte var27;
      if (var30 != var31) {
         byte var32 = 1;
         var27 = var32;
      } else {
         var27 = 0;
      }

      label22: {
         byte var11 = var27;
         Object[] var15 = new Object[]{var4};
         FastPearlCatch var14 = this;
         var14.kReturningVoid(var15);
         this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.y = FastPearlCatchState.PREP;
         this.A = -1;
         ElapsedTimer var10000 = this.l;
         Object[] var17 = new Object[]{var6};
         ElapsedTimer var16 = var10000;
         var16.aReturningVoid(var17);
         int var34 = var10;
         FastPearlCatch var33 = this;
         FastPearlCatch var29 = var33;
         FastPearlCatch var28 = var33;
         if (var34 != 0) {
            MinecraftClient var18 = b;
            var28.w = var18.world;
            byte var35 = var11;
            if (var35 == 0) {
               break label22;
            }

            FastPearlCatch var36 = this;
            var29 = var36;
         }

         short var10001 = 22209;
         long var10002 = 6061933439137296955L ^ var2;
         var29.x = Integer.MIN_VALUE;
      }

      MinecraftClient var21 = b;
      ClientPlayerEntity var37 = var21.player;
      if (var37 != null) {
         MinecraftClient var22 = b;
         ClientPlayerEntity var23 = var22.player;
         this.o = var23.getPitch();
         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         this.p = var25.getYaw();
         Object[] var26 = new Object[]{var8};
         this.z = InventoryUtil.aReturningInt(var26);
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      long var10001 = 91300524781027L ^ 26212593106870L;
      this.x = Integer.MIN_VALUE;
      Object[] var7 = new Object[]{75722808103509L};
      FastPearlCatch var6 = this;
      var6.lReturningVoid(var7);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      byte var23;
      while (true) {
         short var10001 = 5964;
         long var10002 = 2859487565454466975L ^ var2;
         byte var25 = 9;
         int var24 = var5;
         if (var24 < var25) {
            label26: {
               MinecraftClient var6 = b;
               ClientPlayerEntity var7 = var6.player;
               PlayerInventory var37 = var7.getInventory();
               int var9 = var5;
               PlayerInventory var8 = var37;
               ItemStack var38 = var8.getStack(var9);
               int var27 = var4;
               ItemStack var26 = var38;
               ItemStack var22 = var26;
               ItemStack var19 = var26;
               if (var27 != 0) {
                  ItemStack var10 = var19;
                  byte var39 = ((byte)((var10.isEmpty()) ? 1 : 0));
                  int var29 = var4;
                  byte var28 = var39;
                  var23 = var28;
                  byte var20 = var28;
                  if (var29 == 0) {
                     break;
                  }

                  byte var30 = var20;
                  byte var21 = var30;
                  byte var31 = var21;
                  if (var31 != 0) {
                     break label26;
                  }

                  MinecraftClient var13 = b;
                  ClientPlayerEntity var14 = var13.player;
                  PlayerInventory var40 = var14.getInventory();
                  int var16 = var5;
                  PlayerInventory var15 = var40;
                  ItemStack var32 = var15.getStack(var16);
                  var22 = var32;
               }

               ItemStack var18 = var22;
               Item var41 = var18.getItem();
               Item var34 = Items.ENDER_PEARL;
               Item var33 = var41;
               if (var33 == var34) {
                  return var5;
               }
            }

            var5++;
            int var35 = var4;
            if (var35 != 0) {
               continue;
            }
         }

         var23 = -1;
         break;
      }

      return var23;
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 127713985863032L ^ var2;
      long var4 = var2 ^ 95025990719481L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var26;
      while (true) {
         short var10001 = 20063;
         long var10002 = 3200327110117788374L ^ var2;
         byte var28 = 9;
         int var27 = var7;
         if (var27 < var28) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var41 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var41;
            ItemStack var12 = var10.getStack(var11);
            byte var42 = ((byte)((var12.isEmpty()) ? 1 : 0));
            int var30 = var6;
            byte var29 = var42;
            var26 = var29;
            byte var20 = var29;
            if (var30 == 0) {
               break;
            }

            label43: {
               int var32 = var6;
               byte var31 = var20;
               byte var23 = var31;
               byte var21 = var31;
               if (var32 != 0) {
                  byte var33 = var21;
                  byte var22 = var33;
                  byte var34 = var22;
                  if (var34 != 0) {
                     break label43;
                  }

                  MinecraftClient var15 = b;
                  ClientPlayerEntity var16 = var15.player;
                  PlayerInventory var43 = var16.getInventory();
                  int var18 = var7;
                  PlayerInventory var17 = var43;
                  Object[] var19 = new Object[]{var17.getStack(var18), var4};
                  byte var35 = ((byte)((gReturningBoolean(var19)) ? 1 : 0));
                  var23 = var35;
               }

               int var37 = var6;
               byte var36 = var23;
               int var25 = var36;
               byte var24 = var36;
               if (var37 == 0) {
                  return var25;
               }

               byte var38 = var24;
               if (var38 != 0) {
                  var25 = var7;
                  return var25;
               }
            }

            var7++;
            int var39 = var6;
            if (var39 != 0) {
               continue;
            }
         }

         var26 = -1;
         break;
      }

      return var26;
   }

   public static boolean gReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 127713985863032L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 121631162107690L;
      long var6 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var9 = new Object[]{this, var6};
      RotationManager var8 = var10000;
      var8.dReturningVoid(var9);
      Object[] var11 = new Object[]{var4};
      FastPearlCatch var10 = this;
      var10.lReturningVoid(var11);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 73758938363011L;
      long var6 = var2 ^ 64097829662901L;
      Object[] var9 = new Object[]{var4};
      FastPearlCatch var8 = this;
      var8.kReturningVoid(var9);
      this.w = null;
      short var10001 = 22209;
      long var10002 = 6061981341320209524L ^ var2;
      this.x = Integer.MIN_VALUE;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var6};
      RotationManager var10 = var10000;
      var10.eReturningVoid(var11);
   }

   private boolean lambda$new$4(Float var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Swap";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$2(Boolean var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Swap";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Float var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Offhand";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.c;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Swap";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(60184834159112L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[4];
      String var17 = "Ð\n\u0003aO8è\u0092Ó5%ÁÏ\u007f´I\u0010fo\u001f\u0015Á!ôeíT\u0000¤3RÉR";
      int var19 = "Ð\n\u0003aO8è\u0092Ó5%ÁÏ\u007f´I\u0010fo\u001f\u0015Á!ôeíT\u0000¤3RÉR".length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     C = var20;
                     D = new String[4];
                     H = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(60184834159112L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[6];
                     String var4 = "l_mÊÐ\u0011·6ä¯åOú2þo¡Eû\u0002\u0080\rÔ«-¬\u008dÀ(I\u0090Õ";
                     int var5 = "l_mÊÐ\u0011·6ä¯åOú2þo¡Eû\u0002\u0080\rÔ«-¬\u008dÀ(I\u0090Õ".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    F = var6;
                                    G = new Integer[6];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "?Ê\u000f\bñ+øÍéPó2ÿâÚ\u001b";
                                 var5 = "?Ê\u000f\bñ+øÍéPó2ÿâÚ\u001b".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "{\u0014\u0094\u0000Z\u009aÀvÃ¡\u001d3\u008cÔ\u009a\u008c\u0010\u009c\u008ao%\u0010üKÒV$2§#°Àe";
                  var19 = "{\u0014\u0094\u0000Z\u009aÀvÃ¡\u001d3\u008cÔ\u009a\u008c\u0010\u009c\u008ao%\u0010üKÒV$2§#°Àe".length();
                  var16 = 16;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18112;
      if (D[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])E.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               E.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eG", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = C[var5].getBytes("ISO-8859-1");
         D[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return D[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eG_C0229",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27607;
      if (G[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = F[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])H.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               H.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eG", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         G[var3] = var15;
      }

      return G[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eG_C0229",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = J[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = I[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 20;
            yield var16;
         }
         case 2 -> {
            byte var17 = 27;
            yield var17;
         }
         case 3 -> {
            byte var18 = 55;
            yield var18;
         }
         case 4 -> {
            byte var19 = 35;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 2;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 0;
            yield var27;
         }
         case 13 -> {
            byte var28 = 34;
            yield var28;
         }
         case 14 -> {
            byte var29 = 17;
            yield var29;
         }
         case 15 -> {
            byte var30 = 30;
            yield var30;
         }
         case 16 -> {
            byte var31 = 15;
            yield var31;
         }
         case 17 -> {
            byte var32 = 48;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 50;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 29;
            yield var36;
         }
         case 22 -> {
            byte var37 = 49;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 3;
            yield var39;
         }
         case 25 -> {
            byte var40 = 4;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 26;
            yield var42;
         }
         case 28 -> {
            byte var43 = 47;
            yield var43;
         }
         case 29 -> {
            byte var44 = 45;
            yield var44;
         }
         case 30 -> {
            byte var45 = 25;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 61;
            yield var49;
         }
         case 35 -> {
            byte var50 = 62;
            yield var50;
         }
         case 36 -> {
            byte var51 = 19;
            yield var51;
         }
         case 37 -> {
            byte var52 = 7;
            yield var52;
         }
         case 38 -> {
            byte var53 = 24;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 10;
            yield var55;
         }
         case 41 -> {
            byte var56 = 60;
            yield var56;
         }
         case 42 -> {
            byte var57 = 54;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 46;
            yield var59;
         }
         case 45 -> {
            byte var60 = 23;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 39;
            yield var62;
         }
         case 48 -> {
            byte var63 = 58;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 43;
            yield var65;
         }
         case 51 -> {
            byte var66 = 28;
            yield var66;
         }
         case 52 -> {
            byte var67 = 9;
            yield var67;
         }
         case 53 -> {
            byte var68 = 5;
            yield var68;
         }
         case 54 -> {
            byte var69 = 33;
            yield var69;
         }
         case 55 -> {
            byte var70 = 8;
            yield var70;
         }
         case 56 -> {
            byte var71 = 22;
            yield var71;
         }
         case 57 -> {
            byte var72 = 53;
            yield var72;
         }
         case 58 -> {
            byte var73 = 16;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 57;
            yield var75;
         }
         case 61 -> {
            byte var76 = 36;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 56;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            J[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      I[0] = "\u0012S/\u0017\u0012z\u0004S*M\u0001m\u0013\u0018)K\ry\u0002_>\\Fh\u0017";
      I[1] = "\u007fi\u0012}bV\nI\u0019rs\u0019kG\u0012ywC\u001f";
      I[2] = void.class;
      J[2] = "java/lang/Void";
      I[3] = "L9s\u0015W\u0017Z9vOD\u0000MruIH\u0014\\5b^\u0003\u0006m";
      I[4] = int.class;
      J[4] = "java/lang/Integer";
      I[5] = "~,\n!fc\u000b\f\u0001.w,j\u0002\n%sv\u001e";
      I[6] = "\u001f+*\u0011sJ\t+/K`]\u001e`,MlI\u000f';Z'^\u0003";
      I[7] = "\u0007\u001c\u001f\u0017[-r<\u0014\u0018Jb\u00132\u001f\u0013N8g";
      I[8] = float.class;
      J[8] = "java/lang/Float";
      I[9] = "Wv\u0015b01\"V\u001em!~CX\u0015f%$7";
      I[10] = "Ol\u0007B_mYl\u0002\u0018LzN'\u0001\u001e@n_`\u0016\t\u000bj";
      I[11] = "e#*Z1os#/\u0000\"xdh,\u0006.lu/;\u0011e{x";
      I[12] = "S='X u&\u001d,W1:G\u0013'\\5`3";
      I[13] = boolean.class;
      J[13] = "java/lang/Boolean";
      I[14] = "C~\u0011f!DU~\u0014<2SB5\u0017:>GSr\u0000-uQ`";
      I[15] = "4Cm'\u0010bAcf(\u0001- mm#\u0005wT";
      I[16] = "*j\u0004e>f<j\u0001?-q+!\u00029!e:f\u0015.jr\u001f";
      I[17] = "4\u0019\u007f@\b\u0002A9tO\u0019M 7\u007fD\u001d\u0017T";
      I[18] = "\u0000n9FjiuN2I{&\u0014@9B\u007f|`";
      I[19] = "\nrv\u0017\n\u0014\u007fR}\u0018\u001b[\u001e\\v\u0013\u001f\u0001j";
      I[20] = "0f\u000e/#Q&f\u000bu0F1-\bs<R j\u001fdwB8j\u001do-\u000f\u0004q\u001dr-H3f";
      I[21] = "\u0006\u0015c\u001cY#\r\u001arS:.\u0018\u0017}8\u000f,\t\u0004a\u0014\u0018!";
      I[22] = "L\u0002.\u0017YsG\r?X:~R\u000b";
      I[23] = double.class;
      J[23] = "java/lang/Double";
      I[24] = "YJ=e\u001aA,j6j\u000b\u000eMd=a\u000fT9";
      I[25] = "T,i:K\u001e!\fb5ZQ@\u0002i>^\u000b4";
      I[26] = "\"3<\u0002xt\"3+^t{8x+@tn?\t{\u001d%";
      I[27] = "o]f\"U\u001do]q~Y\u0012u\u0016q`Y\u0007rg&?\u000f";
      I[28] = "\u00069#\u0006A\u000e\u00109&\\R\u0019\u0007r%Z^\r\u001652M\u0015\u001d\r";
      I[29] = "\\\u00006d\\C) =kM\fH.6`IV<";
      I[30] = "\u0017\u001cRCM\n\u0017\u001cE\u001fA\u0005\rWE\u0001A\u0010\n&\u0014Y\u0013";
      I[31] = "(\u000eUS3<].^\\\"s< UW&)H";
      I[32] = "u\u0017KY\u0006\u0017~\u0018Z\u0016j\u0014p\u001aXYF";
      I[33] = ":\\F\u0014=WO|M\u001b,\u0018.rF\u0010(BZ";
      I[34] = "Be(\u000bp\"7E#\u0004amVK(\u000fe7\"";
      I[35] = "\"6%<8\u0019W\u0016.3)V6\u0018%8-\fB";
      I[36] = ";,pf\u0018?;,g:\u00140!gg$\u0014%&\u00165~Mb";
      I[37] = "\u00119\u0019Hb\n\u00119\u000e\u0014n\u0005\u000br\u000e\nn\u0010\f\u0003\\T6T";
      I[38] = "[+\u0014\u0011\u0005\tM+\u0011K\u0016\u001eZ`\u0012M\u001a\nK'\u0005ZQ\u001dy";
      I[39] = "\u0001*\bH\u000f\f\n%\u0019\u0007n\u0002\u0001.\u001d]";
      I[40] = "(IP\u0018\u0011\u00146AJWv\u0015'ZG\rP\u0013";
      I[41] = "\u0014E\u0006\u0000\u0015Z\u0014E\u0011\\\u0019U\u000e\u000e\u0011B\u0019@\t\u007fE\u001aN";
      I[42] = "+D{2B6=D~hQ!*\u000f}n]5;Hjy\u0016 \u0016";
      I[43] = "KbyU{&>BrZji_LyQn3+";
      I[44] = "MgE#YbFhTl$zUo]%";
      I[45] = "[p\u0003\u0000\u001eTP\u007f\u0012OyLTc\u0014\u0003\\]";
      I[46] = "\u0015Rb\u000f`V`ri\u0000q\u0019\u0001|b\u000buCu";
      I[47] = "Cc\u0006-5:Cc\u0011q95Y(\u0011o9 ^YD0`";
      I[48] = ">~\bW\u0000\u000b5q\u0019\u0018h\u000b;~\n";
      I[49] = "Xs\n3s\t-S\u0001<bFL]\n7f\u001c8";
      I[50] = "\u00050V\t+G\u00050AU'H\u001f{AK']\u0018\n\u0013\u0015p\u0016";
      I[51] = "\u000f^d2@Ez~o=Q\n\u001bpd6UPo";
      I[52] = "Roh\u0004Me'Oc\u000b\\*FAh\u0000Xp2";
      I[53] = "cnX9\u000bdcnOe\u0007ky%O{\u0007~~T\u001e$S=";
      I[54] = "\u000f\tS'{k\u000f\tD{wd\u0015BDewq\u00123\u0015:%:";
      I[55] = "r\u0003a\u001c\u0002[r\u0003v@\u000eThHv^\u000eAo9'\n[\u00048\u0005yS\u001cACT-\u0006X";
      I[56] = "\u001a\u001d)\u0018l\\o=\"\u0017}\u0013\u000e3)\u001cyIz";
      I[57] = "a(u+\u0006Z\u0014\b~$\u0017\u0015u\u0006u/\u0013O\u0001";
      I[58] = "\"-d\u0010c>W\ro\u001frq6\u0003d\u0014v+B";
      I[59] = "\u001a\u0002ZUBW\f\u0002_\u000fQ@\u001bI\\\t]T\n\u000eK\u001e\u0016DN";
      I[60] = "!F2Q\u001dkTf9^\f$5h2U\b~A";
      I[61] = "td\u00178|'bd\u0012bo0u/\u0011dc$dh\u0006s(9";
      I[62] = "xS-&\u001aA\rs&)\u000b\u000el}-\"\u000fT\u0018";
      I[63] = "\u001ci[\u0004 z\u001ciLX,u\u0006\"LF,`\u0001S\u001e\u0012}!";
      I[64] = "obF\u001d1\u0018obQA=\u0017u)Q_=\u0002rX\u0003\u0004eC";
      I[65] = "sw]J\u0000R\u0006WVE\u0011\u001dgY]N\u0015G\u0013";
      I[66] = "|A\u001f\u0012y'\ta\u0014\u001dhhho\u001f\u0016l2\u001c";
      I[67] = "sk8;ynek=ajyr >gfmcg)p-zU";
      I[68] = "\u0019;TJ\u0011 l\u001b_E\u0000o\r\u0015TN\u00045y";
      I[69] = "^/PTtQ+\u000f[[e\u001eJ\u0001PPaD>";
      I[70] = "20TH\u0010'20C\u0014\u001c(({C\n\u001c=/\n\u0011PK\u007f";
      I[71] = "\u0010H\u0016\u0010+^\u0010H\u0001L'Q\n\u0003\u0001R'D\rrS\t\u007f\u000e";
      I[72] = "\u000fz}w\\xzZvxM7\u001bT}sImo";
      I[73] = "*M(ec%<M-?p2+\u0006.9|&:A9.71\u0006";
      I[74] = "p\nEz\u001ej\u0005*Nu\u000f%d$E~\u000b\u007f\u0010";
      I[75] = "yX\u0002f>!oX\u0007<-6x\u0013\u0004:!\"iT\u0013-j5W";
      I[76] = "Xa#4\fR-A(;\u001d\u001dLO#0\u0019G8";
      I[77] = "*:$\u0005\u0015u_\u001a/\n\u0004:>\u0014$\u0001\u0000`J";
      I[78] = "T9O4V\rT9XhZ\u0002NrXvZ\u0017I\u0003\b+\u000e";
      I[79] = "`xbvK%`xu*G*z3u4G?}B%h\u0012";
      I[80] = "kg\u001e-,\u001a\u001eG\u0015\"=U\u007fI\u001e)9\u000f\u000b";
      I[81] = "Ov_\u0010iVOvHLeYU=HReLRL\u001a\f2\u0006";
      I[82] = "SD-!\u0002mSD:}\u000ebI\u000f:c\u000ewN~o<Y";
      I[83] = "W|*p\fWW|=,\u0000XM7=2\u0000MJFohT\t";
      I[84] = "\fVcj5\r\u0012^y%H\u001d\u0012";
      I[85] = "v?YydC\u0003\u001fRvu\fb\u0011Y}qV\u0016";
      I[86] = "(\u0006v\u0012yY<\u0001{\r\u0001\\A\u0002`RyV{\u00078\u001d}MA\no\u0015e_9De]b3";
      I[87] = "u\bClA\u0015 \u0006HqO()\u0006T~CD\u001bQ\u0013 \u001a\u0015LZAg@D4\u0014K/G(";
      I[88] = "\u0018v_k#_\u000egU*\u0019C\u000ewG3uqX2\u001ah)&Z`_2yD\u0006o_+y&";
      I[89] = "* \u0018s}&>'\u0015l\u0005&C$\u000e3})y!V|y2C!\u000fs}\"{z\bwnL";
      I[90] = "W\u000e\u0000E&4\u0001\u001aYIjM\u0007`\u0006Rj5\u000bZ\u0003\n%1\u0010`\u0006Zk<\u001c\u0019PN20P`";
      I[91] = ">pSq$ugp\u0004-\u0018u>\u007f\n-O\"`/SAz%9tP,ri`#";
      I[92] = "\f\u0019\u000e'\u0004U\u001a\b\u0004f>I\u001a\u0018\u0016\u007fR{LZJ%\u0002,J\u001d\u000faTN\u000f\u001a\u000ed>";
      I[93] = "3\u001c{AY;5\t;\u000f\\Wo\u001d{\u0010G;]O6N\u0018W;\u0019~\u0014L/u\u00136\u0013 ";
      I[94] = "\nQy9Fz\u001eVt&>scUoyFuYP76BncUwxW,^\u0006d\u007f\u000f\u0010";
      I[95] = "R,\u0004\"g|Tg\u0010g\u001d\u007fmo\f'evWjThammo\u0014&t/P<\u0007!,\u0013";
      I[96] = "WNmJeM\u000eN:\u0016YF[P0\u001d5t\u000f\u0011nKY\u0012_U4\u0016!\\U\u001d3z";
      I[97] = "A.oa\\8U)b~$0(*y!\\7\u0012/!nX,(*a Mn\u0015yr'\u0015R";
      I[98] = "*\u0013u0`gyMd/f\u0003}Kc-uT*\u0012?y!\u0003*\u0013u0`gyMd/f";
      I[99] = ";`yF\n^a3*R_$k\u000f-P\r\\g5(\bBX|\u000f-Y^T;uw\n\r@n\u000f";
      I[100] = "GO\u0006\u0002mhD\u0011\f\rfP\u0010\u0014\u0002\u0002`\u0007GO^X=PGO\u0006\u0002mhD\u0011\f\rf";
      I[101] = "`CJgX!vR@&b=vBR?\u000e\u000f!\u0002\u0002bRX*WK<\u000e d]\u0003;b";
      I[102] = "3ZL\u000beA0SZK\u0000A&DTWlsq\u0004\u0005\n9$2\t\rSgK'G\u0004K\u0000";
      I[103] = "8Cg+A\u0013f\u000evn&Q1eu{GD0D\u001cx\u001e\u0011;V#tV_4?s/\u001a@?\u0000\u007fgTOV";
      I[104] = "`\u0018\bSzFv\t\u0002\u0012@Zv\u0019\u0010\u000b,h [LQ}?&\u001c\t\u0015*]c\u001b\b\u0010@";
      I[105] = "\u0014\u0010 C~~SFz\u0004\u0001{\u0002Pc?{s_\u0018u\u0005yf\u000bP\u001f";
      I[106] = "w5B3\nM)xSvm\u0018~29`UOt \u0006l\u001d\u0001{IV7Q\u001epvZ\u007f\u001f\u0011\u0019";
      I[107] = ">Gn\u000bV\u0017<R:C<@=T7WG->Gn\u000bV\u0017<R:C<\u001c-P:_DR'\u0018=3";
      I[108] = "a])j}?h\f*`~Q34h=\")=\u000emem-&4`2e54L.8-2X";
      I[109] = "MNf\"UL\u0015J3.3\u001aO\\9~dM\u0015\fg\u0012\\L\u0012\\4-P\u0004\\S";
      I[110] = "p\u0012hcK\u00123\u0010|.u\u0002wRxv\u000eotA!*\u001fUvTubu^gVu~\r\u0010m\u001er\u0012";
      I[111] = "3\u0013oOh#?\ftOUyQDw\u000b-ykA/D)bQLxL1p)\u0002r\u00046\u001c";
      I[112] = "\u00114`\u000f\u0017#H47S+#\u0011;9S|tNge?\u0012,\u0015(mOT<\u0001'?";
      I[113] = "a\b\u0012'Qd?\u000f\u001a\u0018]\u001ch\u0004A`S&m\\\u000edH\u001ch\u001c@q\n!;\u000fG)6";
      I[114] = "\\m\u0001\u001bP\fLm\u000bW:\u00056=\u0017\u0014B\t\f8O[F\u00126=\u000f\u0015SP\u000bn\u001c\u0012\u000bl";
      I[115] = "tX\u000e^yD`_\u0003A\u0001G\u001d\\\u0018\u001eyK'Y@Q}P\u001dT\u0017YeBe\u001a\u001d\u0011b.";
      I[116] = "\u0000sB\u0006I^\u0003zTF,U\u0019|^Q{\u0005@(\u0000=\u0017VF(UE\u0010_\u0015`";
      I[117] = "k\u001a\u0006\rE\"7\u0015\u0006\u0014E@7\u001c\u0002\u000bB,\u0005LBP\u0015@i\u001c@RJ8n\u0015\u0013\u001a%y>\rO\u0012I\u007f+M\u0001\u0017%";
      I[118] = "wIL4u|.I\u001bhI|wF\u0015h\u001e+(\u001bN\u00046vs\u0013\u0014b\"cuW";
      I[119] = "]\b34e#R\u0013,f\u000ftM\u001c,5X'\u001cHpY~cW\u001c\"`qxHN";
      I[120] = "%S\u000b1\u0006(1T\u0006.~/LW\u001dq\u0006'vRE>\u0002<LU\u0016qG-4R\u001f\"\u000fB";
      I[121] = "\t/0\u001d=^\u00064/OW\t\u0019;/\u001c\u0000ZHn{p&\u001e\u0003;!I)\u0005\u001ci";
      I[122] = "!/\u0019X9hg?\rWk\u0018v/\u0011BeO!\u007fD\u001a\t!zs\u0011F2xqp\u0004Z";
      I[123] = "o\u000f=\u001a\u001b*6\u0004>\u000f\u0007\u00113\u0000|\u0017\u001c}\u0001T<LG\u0011g\u0004y\u0013\u0017i)\u000e1\u0014{";
      I[124] = "\u0013f!\u0018\u001aP\u0007a,\u0007bSz6+\u001fZT\u001bf+\u0018\u001d:\u0017!(^\f[G!/\u0019b";
      I[125] = "#{RxS\u007f5jX9ic5zJ \u0005Qf?\u0013zi71\u007fN+\u0011y;7IG";
      I[126] = "(d\nq|\bvc\u0002Nqp!hY6~J$0\u00162ep!pX''Mrc_\u007f\u001b";
      I[127] = "R5,}\"iW.0\"Kchm! rf\u0010j(s:\t";
      I[128] = "Z\\&\u000f(\u001c\u0006\rc\u001bs-\r\u00050\u0001&zZ]e^q-Z\\&\u000f(\u001c\u0006\rc\u001bs";
      I[129] = "i\tK\u0004]M7DZA:\bf\u00130W\u0002Oj\u001c\u000f[J\u0001eu_\u0000\u0006\u001enJSHH\u0011\u0007";
      I[130] = "4Hkr\u000f\u0016\"Ya35\u0001.Xw!bQw\f)M\u000e\u0002q\f|5\t\u000b\"D";
      I[131] = "L_6<n8\u0015_a`R8LPo`\u0005o\u0012\u00032\fk5_^;q2<\u0011Mv";
      I[132] = "\u001bWl\u0018P\u001c\u000fPa\u0007(\u001arSzXP\u0013HV\"\u0017T\br[u\u001fL\u001a\n\u0015\u007fWKv";
      I[133] = ",Rvo\u0014\u001a*G6!\u0011vpSv>\n\u001aB\u0001;f\\v,\u000e{0\u0010\u001d$Zg9Wv";
      I[134] = "+Ea>*?'Zz>\u0017iI\u0012yzoes\u0017!5k~I\u0012a{~<tAr|&\u0000";
      I[135] = "NVr\u001fN,\u0014Nr]X\u0010\u0010]B\u001fZ OYx\u001dOt\u00073{\u0000\u0004j\r\u000f!\u0018\u0004(\u001b3";
      I[136] = "^#u\u0017s!\u0006' \u001b\u0015|P .@yN\u0004dt\u0016\u0015zBg~A-\"F2r'";
      I[137] = "\tL{}\u000f\u001d\fWg\"f\u00143\u0016} \u001e\u0018\t\u0013%o\u001a\u00033\u0010r}^GU_{c\u0018}";
      I[138] = "j\u0003$\u001eZ#~\u0004)\u0001\"\"\u0003\u00072^Z,9\u0002j\u0011^7\u0003\u00023\u001eZ';Y4\u001aII";
      I[139] = "@\u0013|?M\u0002[\u00008\"qSB\u001d .\u0018_{\u0013 >\u001c9\u0014\u0013='\u001dAZ\u0019u q";
      I[140] = "P\u001f&!\twU\u0004:~`|jG+|Yx\u0012@\"/\u0011\u0017";
      I[141] = "(|G.Gw>mMo}k>}_v\u0011Yh?\u0003,B\u000enxFh\u0017l+\u007fGm}7->V-@d>9\u000e\u0011";
      I[142] = "\u0015^o\u000elF\u0001Yb\u0011\u0014B|ZyNlIF_!\u0001hR|Rv\tp@\u0004\u001c|Aw,";
      I[143] = "|GG,TTz\fSi.VC\u0004O)V^y\u0001\u0017fREC\f@nJW;BJ&M;";
      I[144] = "6={c~En9.o\u0018\u00134/$?ODn\u007fxSwEi/)l{\r' ";
      I[145] = "{Yl[xcpO-\u000f\nv\u0002[2U2u8Y'\u0001z\u001f";
      I[146] = "RY\"~^nT\u00126;$om\u001a*{\\dW\u001fr4X\u007fm\u0012%<@m\u0015\\/tG\u0001";
      I[147] = "e;G&f\u000bcpSc\u001c\nZxO#d\u0001`}\u0017l`\u001aZxW\"uXg+D%-d";
      I[148] = "#\u0014=!Pn%_)d*l\u001cW5$Rd&RmkV\u007f\u001cW-%C=!\u0004>\"\u001b\u0001";
      I[149] = "$\u0011@\u0017\u0016<2\u0000JV, 2\u0010XO@\u0012f\\\u0007\u0019\u001cE<\u0013\u0003\u0018J}d\u0017V\u0014,";
      I[150] = "\u0014x_G:@Mx\b\u001b\u0006@\u0014w\u0006\u001bQ\u0017J ^w}S\r%X\u000ekB\u0007d";
      I[151] = "~ji\b!~hmo\f\u001e+\u00025q]f'80)\u0012b<\u00025i\\w~?fz[/B";
      I[152] = "6\u0013E\u0003j\u0000o\u001a\u000b\u0010'}j\u001dK\u0000=\u0011XJ\u0006Yk}6\u0015\n\nd\u001be\u0012E\u0012j}~\tL\r0Dq\u0012S_ZDl\u001bE\u0005g\u0011b\u0010X\u000bZ";
      I[153] = "xGf\u0000_O#@b\u00131\u001eD\u0019~FI\u0012~\u001c&\tM\tD\u001da\u0001H\u001d&Xf\u0000Mw";
      I[154] = "<\u000f;mO\u00057]='$\u0005Q\u000e<;\u001f\u0018>\bw/Z";
      I[155] = "-pis>\u0017;ac2\u0004\u000b;qq+h9h4)p\u0004\u001f/v|&=\u00104i.L=\u0010id-qn\u0003n<\u0011";
      I[156] = "?iV\u0003\u001c\u000f3vM\u0003!Y]>NGYUg;\u0016\b]N]<EG\u0018_%;L\u0014P0";
      I[157] = "C\"{Lbk\u0014r%H~\u0001\u0014s'KjVJ,q\u0013\u00068Jc$Rm0\u001e\u007f-\u0015";
      I[158] = "P1HL\u001b\u0014\u0017g\u0012\u000bd\u0017Bz1]\u0014\u000b+0\u001eI\u0000\u001bS~\u0014\u0001\u0007w";
      I[159] = "\u0015U\f1 7\u0003D\u0006p\u001a+\u0003T\u0014iv\u0019U\u0016H3$NSQ\rwp,\u0016V\fr\u001aw\u0010\u0017\u001d2'$\u0003\u0010E\u000e";
      I[160] = "\u001e\u0015a\u0014\u001diC\u0019>\t\u001b\u0015N(f\u0015\u001emB\u0012cMQiY(f\r\u001f|\u001b\u00155\u001e\u0018$'";
      I[161] = "GZ\nhJ{\u0014\u0002\u0000j]\u001d\u0019\u001eWyRt\u001ad\u0000u\n$\u0011\u001c\u0007|Yl~";
      I[162] = "M]( \u0004pK\u0016<e~ur\u001e %\u0006zH\u001bxj\u0002ar\u001e8$\u0017#OM+#O\u001f";
      I[163] = "\u0006\t>*T\u001d\u0010\u000e8.kHzV&\u007f\u0013D@S~0\u0017_z^)8\u000fM\u0002\u0010#p\b!";
      I[164] = "@\u00174, _E\u001cb%F\u0001B\u001av :\u0007Dwwyy\u001cA\u00140/#[>";
      I[165] = "E-\u0001=>|Q*\f\"F{,)\u0017}>s\u0016,O2:h,!\u0018:\"zTo\u0012r%\u0016";
      I[166] = "\u001bV </x@Q$/A*'\b8z9%\u001d\r`5=>'\f'=8*EI <=@";
      I[167] = "&\u0005@U1> NT\u0010K:\u0019FHP34#C\u0010\u001f7/\u0019NG\u0017/=a\u0000M_(Q";
      I[168] = "Ixre\u0018w\u001e(,a\u0004\u001d\u001e).b\u0010JLy{7L\u001dIx2h\u0001vA,.aF";
      I[169] = "Dm=LT\u001aB&)\t.\u0019{.5IV\u0010A+m\u0006R\u000b{&:\u000eJ\u0019\u0003h0FMu";
      I[170] = "Zt\u001edl\u0006Jt\u0014(\u0006\u000f0,\u0007,b\nHb\rdef";
      I[171] = "_*\u007f\u0017\u0007\u0000C%#Ed\u0005K-)S:\u0002K7-/Y\u0012V3*M\u001c\u0015W6@";
      I[172] = "Wd>>dLCc3!\u001cB>`(~dC\u0004ep1`X>`0\u007fu\u001a\u00033#x-&";
      I[173] = "6tC\u0018)\u0003\"sN\u0007Q\u0000_pUX)\feu\r\u0017-\u0017_1Q\u001ej\f:2X\b*i";
      I[174] = "hBnA6D|Ec^NB\u0001Fx\u00016K;C N2P\u0001Ds\u0001wAyCzR?.";
      I[175] = "\u000bhK|gJ\u001f}M8\u0002I\u0019pN#n{M<\u0017}8,\nl\u0016!d\u0013\u000fg@(\u0002";
      I[176] = "0\u0014\u0019\u001b\u000b)&\u0005\u0013Z1>*\u0004\u0005HfmzV_$\u000092\r\r\\N3z\n";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = I[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(J[var4]);
            I[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = I[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            I[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  I[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2785063061662485L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = I[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  I[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2785063061662485L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        I[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2785063061662485L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 86;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 202;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 87;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 112;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 81;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 240;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 86;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 202;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 87;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eG_C0229",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(FastPearlCatch var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eG_C0229;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eG_C0229", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(FastPearlCatch var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eG_C0229;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eG_C0229", "lambda$new$4", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(FastPearlCatch var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eG_C0229;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eG_C0229", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((FastPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(FastPearlCatch var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eG_C0229;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eG_C0229", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((FastPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(FastPearlCatch var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eG_C0229;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eG_C0229", "lambda$new$3", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((FastPearlCatch)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
