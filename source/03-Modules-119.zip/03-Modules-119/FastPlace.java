package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.MinecraftClientAccessor;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;

public class FastPlace extends Module {
   private BooleanSetting d;
   private IntSetting a;
   private IntSetting c;
   private static final long k = 11844353284755L;
   private static final Object[] l = new Object[36];
   private static final String[] m = new String[36];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @EventListener
   public void a(TickEvent var1) {
      label39: {
         IntSetting var53;
         label41: {
            int var52;
            long var10001 = 53196360420148L ^ 69427322856345L;
            var10001 = 53196360420148L ^ 72148384677861L;
            var10001 = 53196360420148L ^ 69790625682645L;
            int var10 = Event.cReturningInt();
            BooleanSetting var13 = this.d;
            Boolean var14 = (Boolean)var13.aReturningObject();
            byte var10000 = ((byte)(((java.lang.Boolean)(var14)).booleanValue() ? 1 : 0));
            int var55 = var10;
            byte var54 = var10000;
            var52 = var54;
            byte var46 = var54;
            label37:
            if (var55 != 0) {
               byte var56 = var46;
               if (var56 != 0) {
                  MinecraftClient var16 = b;
                  ClientPlayerEntity var17 = var16.player;
                  ItemStack var18 = var17.getMainHandStack();
                  var10000 = ((byte)((var18.getItem() instanceof BlockItem) ? 1 : 0));
                  int var58 = var10;
                  byte var57 = var10000;
                  var52 = var57;
                  byte var47 = var57;
                  if (var58 == 0) {
                     break label37;
                  }

                  byte var59 = var47;
                  byte var48 = var59;
                  byte var60 = var48;
                  if (var60 == 0) {
                     MinecraftClient var21 = b;
                     ClientPlayerEntity var22 = var21.player;
                     ItemStack var23 = var22.getOffHandStack();
                     var10000 = ((byte)((var23.getItem() instanceof BlockItem) ? 1 : 0));
                     int var62 = var10;
                     byte var61 = var10000;
                     var52 = var61;
                     byte var49 = var61;
                     if (var62 == 0) {
                        break label37;
                     }

                     byte var63 = var49;
                     byte var50 = var63;
                     byte var64 = var50;
                     if (var64 == 0) {
                        return;
                     }
                  }
               }

               int var66 = var10;
               IntSetting var65 = this.a;
               var53 = var65;
               IntSetting var51 = var65;
               if (var66 == 0) {
                  break label41;
               }

               IntSetting var26 = var51;
               Integer var27 = (Integer)var26.aReturningObject();
               int var67 = var27;
               var52 = var67;
            }

            IntSetting var29 = this.c;
            Integer var30 = (Integer)var29.aReturningObject();
            int var69 = var30;
            int var68 = var52;
            if (var68 <= var69) {
               break label39;
            }

            IntSetting var70 = this.a;
            var53 = var70;
         }

         IntSetting var32 = this.c;
         Integer var34 = (Integer)var32.aReturningObject();
         IntSetting var33 = var53;
         var33.aReturningVoid(var34);
      }

      MinecraftClientAccessor var11 = new MinecraftClientAccessor(b);
      Object[] var36 = new Object[]{16790918801581L};
      MinecraftClientAccessor var35 = var11;
      int var73 = var35.aReturningInt(var36);
      IntSetting var37 = this.a;
      Integer var38 = (Integer)var37.aReturningObject();
      int var76 = var38;
      IntSetting var39 = this.c;
      Integer var40 = (Integer)var39.aReturningObject();
      int var10002 = var40;
      Object[] var10005 = new Object[]{null, null, 125343872349393L};
      var10005[1] = var10002;
      var10005[0] = var76;
      Object[] var41 = var10005;
      int var43 = RandomUtil.aReturningInt(var41);
      int var42 = var73;
      int var12 = Math.min(var42, var43);
      Object[] var10004 = new Object[]{null, 16599433699297L};
      var10004[0] = var12;
      Object[] var45 = var10004;
      MinecraftClientAccessor var44 = var11;
      var44.aReturningVoid(var45);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 54;
            yield var15;
         }
         case 1 -> {
            byte var16 = 19;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 6;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 17;
            yield var21;
         }
         case 7 -> {
            byte var22 = 44;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 9;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 29;
            yield var27;
         }
         case 13 -> {
            byte var28 = 25;
            yield var28;
         }
         case 14 -> {
            byte var29 = 48;
            yield var29;
         }
         case 15 -> {
            byte var30 = 23;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 46;
            yield var32;
         }
         case 18 -> {
            byte var33 = 35;
            yield var33;
         }
         case 19 -> {
            byte var34 = 53;
            yield var34;
         }
         case 20 -> {
            byte var35 = 51;
            yield var35;
         }
         case 21 -> {
            byte var36 = 28;
            yield var36;
         }
         case 22 -> {
            byte var37 = 27;
            yield var37;
         }
         case 23 -> {
            byte var38 = 31;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 5;
            yield var40;
         }
         case 26 -> {
            byte var41 = 58;
            yield var41;
         }
         case 27 -> {
            byte var42 = 14;
            yield var42;
         }
         case 28 -> {
            byte var43 = 37;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 39;
            yield var47;
         }
         case 33 -> {
            byte var48 = 18;
            yield var48;
         }
         case 34 -> {
            byte var49 = 3;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 45;
            yield var51;
         }
         case 37 -> {
            byte var52 = 62;
            yield var52;
         }
         case 38 -> {
            byte var53 = 41;
            yield var53;
         }
         case 39 -> {
            byte var54 = 1;
            yield var54;
         }
         case 40 -> {
            byte var55 = 38;
            yield var55;
         }
         case 41 -> {
            byte var56 = 52;
            yield var56;
         }
         case 42 -> {
            byte var57 = 43;
            yield var57;
         }
         case 43 -> {
            byte var58 = 4;
            yield var58;
         }
         case 44 -> {
            byte var59 = 33;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 40;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 55;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 50;
            yield var65;
         }
         case 51 -> {
            byte var66 = 10;
            yield var66;
         }
         case 52 -> {
            byte var67 = 32;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 0;
            yield var70;
         }
         case 56 -> {
            byte var71 = 12;
            yield var71;
         }
         case 57 -> {
            byte var72 = 11;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 8;
            yield var75;
         }
         case 61 -> {
            byte var76 = 7;
            yield var76;
         }
         case 62 -> {
            byte var77 = 57;
            yield var77;
         }
         default -> 15;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u001a\feicS\u0004\u0004\u007f&\u001eC\u0004";
      l[1] = "CQj<L\u001eH^{s-\u0010CU\u007f)";
      l[2] = "\r5>jgQ\u001b5;0tF\f~86xR\u001d9/!3o";
      l[3] = "\u0001)SRK~t\tX]Z1\u0015\u0007SV^ka";
      l[4] = void.class;
      m[4] = "java/lang/Void";
      l[5] = "\t\u0000hNLn\t\u0000\u007f\u0012@a\u0013K\u007f\f@t\u0014:-W\u0018>";
      l[6] = "xwT\u001a\u001cwxwCF\u0010xb<CX\u0010meM\u0011\u0003H,";
      l[7] = "PJ\u0010,\u0018\rPJ\u0007p\u0014\u0002J\u0001\u0007n\u0014\u0017MpS6C";
      l[8] = "\u001ay\u0011%VQoY\u001a*G\u001e\u000eW\u0011!CDz";
      l[9] = int.class;
      m[9] = "java/lang/Integer";
      l[10] = "!'LD<>*(]\u000bP=$*_D|";
      l[11] = boolean.class;
      m[11] = "java/lang/Boolean";
      l[12] = "'~\u0010pf91~\u0015*u.&5\u0016,y:7r\u0001;2(\u0006";
      l[13] = "\u0004Wkc\nH\u0012Wn9\u0019_\u0005\u001cm?\u0015K\u0014[z(^](";
      l[14] = "y\u000e'1mWr\u00016~\u000eZg\f9\u0015;Xv\u001f%9,U";
      l[15] = "m\u001856g\u001b{\u00180lt\flS3jx\u0018}\u0014$}3\u000fO";
      l[16] = "{m,\u0012!{pb=]Fyei=\u0016}";
      l[17] = "7u\t\u0010+Z7u\u001eL'U->\u001eR'@*ON\u000fv";
      l[18] = "t_\u0014\u001cP|b_\u0011FCku\u0014\u0012@O\u007fdS\u0005W\u0004hy";
      l[19] = "kxG8yu\u001eXL7h:\u007fVG<l`\u000b";
      l[20] = "_\b\u0001)\u0007\u0011T\u0007\u0010fd\u001cA\u0001";
      l[21] = "\"\u0017\f^gn'\u001b\r\\W`\u001b\tLQ>c`\u0000\u001eX>\t \f\u001b\u0007lx\u007f\u0007\u0000\u0000W";
      l[22] = "Z4\\m'\t\rhS+VR\f.\rv:`^cU V\u000b\b,St*\f\u0011,R\u0011";
      l[23] = "Ssv\u007f\u0005'\run<4&\u00031\u007f X\u0014Pu#x4x\b|c6\n/Ts%G";
      l[24] = "5|XrY'4%\u0010\u0013\u00045^\"\u0010j\u00042?r\u0017l\u0013[5|XrY'4%\u0010\u0013";
      l[25] = "Uq9ZMMP}8X}CloyU\u0014@\u0017f+\\\u0014*R\u007f)J\u0011G\u0001s8_}";
      l[26] = "\u0006pM_hLD0\f[\u0016A^/\u0015M\u007fMg!\u0015]{+\u00060\nOhNTwNY\u0016";
      l[27] = "g\u000f/*6K&\ti%DNWK. 6I:\u0018\"1#%";
      l[28] = "RK`1s\u000f\u0018Ra)\u0018\u000bc\u0018!%#\u001a\r\u00153>\"bRQ)n`\f_C2o\u0018";
      l[29] = "~(u\u000fVst8sKk*\u0017~pJ\f*v.wL\u001bC";
      l[30] = "$Kp1C@/\u0016qj;B(U\u0016h_^#)v}[Q\"D%qJDN";
      l[31] = "a\u0019\u001b\u0017e7v\u001c\u001d\u0012]#k\u001a\u0019A\nt5MA-`scOLI>u{\f";
      l[32] = "ULx \u0019\"\u000bJ`c(#\u0005\u000eq\u007fD\u0011VJ.)(}\u000eCmi\u0016*RL+\u0018";
      l[33] = "\u0019\b\u0007\u0003z\u0004\u0013\u0018\u0001GG]p^\u0002F ]\u0011\u000e\u0005@74K\u000e]\u0004|E\u0014\u0005F\u0003G";
      l[34] = "$Ah\u0011u#1Wk[\u0014tOK*F}w4BxO}\u001dq[zYxp\"WkL\u0014";
      l[35] = "\u000ef+6\u0019t\u0018v!k$}\u0002j\u001b8Xx\u0011`vkTi\u0004\f%zDj\u000favvU\u007fc2gfVt\u000eakwC\u0018";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(103650303082641L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(103650303082641L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(103650303082641L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 121;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 165;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 233;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 217;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 67;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 69;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 121;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 165;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 233;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eH_C0231",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eH" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
