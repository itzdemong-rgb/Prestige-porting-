package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.CameraRotationEvent;
import dev.zprestige.prestige.api.events.MouseLookEvent;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.Perspective;

public class FreeLook extends Module {
   private BooleanSetting d;
   private float a = 0.0F;
   private float c = 0.0F;
   private Perspective e = null;
   private static final long k = 131632006361764L;
   private static final Object[] l = new Object[36];
   private static final String[] m = new String[36];

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @EventListener
   public void a(MouseLookEvent var1) {
      double var10001 = this.a;
      Object[] var5 = new Object[0];
      MouseLookEvent var4 = var1;
      this.a = (float)(var10001 + var4.aReturningDouble(var5) * 0.1F);
      var10001 = this.c;
      Object[] var7 = new Object[0];
      MouseLookEvent var6 = var1;
      this.c = (float)(var10001 + var6.bReturningDouble(var7) * 0.1F);
      Object[] var9 = new Object[0];
      MouseLookEvent var8 = var1;
      var8.aReturningVoid(var9);
   }

   @EventListener
   public void a(CameraRotationEvent var1) {
      Object[] var5 = new Object[]{this.a};
      CameraRotationEvent var4 = var1;
      var4.bReturningVoid(var5);
      Object[] var7 = new Object[]{this.c};
      CameraRotationEvent var6 = var1;
      var6.cReturningVoid(var7);
      Object[] var9 = new Object[0];
      CameraRotationEvent var8 = var1;
      var8.aReturningVoid(var9);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      MinecraftClient var4 = b;
      ClientPlayerEntity var5 = var4.player;
      this.a = var5.getYaw();
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      this.c = var7.getPitch();
      MinecraftClient var8 = b;
      GameOptions var9 = var8.options;
      this.e = var9.getPerspective();
      BooleanSetting var10 = this.d;
      Boolean var11 = (Boolean)var10.aReturningObject();
      boolean var15 = var11;
      if (var15) {
         MinecraftClient var12 = b;
         Perspective var14 = Perspective.THIRD_PERSON_BACK;
         GameOptions var13 = var12.options;
         var13.setPerspective(var14);
      }
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      MinecraftClient var4 = b;
      Perspective var6 = this.e;
      GameOptions var5 = var4.options;
      var5.setPerspective(var6);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 38;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 30;
            yield var17;
         }
         case 3 -> {
            byte var18 = 41;
            yield var18;
         }
         case 4 -> {
            byte var19 = 35;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 60;
            yield var21;
         }
         case 7 -> {
            byte var22 = 0;
            yield var22;
         }
         case 8 -> {
            byte var23 = 44;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 56;
            yield var25;
         }
         case 11 -> {
            byte var26 = 55;
            yield var26;
         }
         case 12 -> {
            byte var27 = 62;
            yield var27;
         }
         case 13 -> {
            byte var28 = 33;
            yield var28;
         }
         case 14 -> {
            byte var29 = 13;
            yield var29;
         }
         case 15 -> {
            byte var30 = 29;
            yield var30;
         }
         case 16 -> {
            byte var31 = 21;
            yield var31;
         }
         case 17 -> {
            byte var32 = 31;
            yield var32;
         }
         case 18 -> {
            byte var33 = 26;
            yield var33;
         }
         case 19 -> {
            byte var34 = 39;
            yield var34;
         }
         case 20 -> {
            byte var35 = 34;
            yield var35;
         }
         case 21 -> {
            byte var36 = 45;
            yield var36;
         }
         case 22 -> {
            byte var37 = 4;
            yield var37;
         }
         case 23 -> {
            byte var38 = 15;
            yield var38;
         }
         case 24 -> {
            byte var39 = 50;
            yield var39;
         }
         case 25 -> {
            byte var40 = 36;
            yield var40;
         }
         case 26 -> {
            byte var41 = 7;
            yield var41;
         }
         case 27 -> {
            byte var42 = 16;
            yield var42;
         }
         case 28 -> {
            byte var43 = 14;
            yield var43;
         }
         case 29 -> {
            byte var44 = 5;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 51;
            yield var46;
         }
         case 32 -> {
            byte var47 = 17;
            yield var47;
         }
         case 33 -> {
            byte var48 = 8;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 23;
            yield var50;
         }
         case 36 -> {
            byte var51 = 20;
            yield var51;
         }
         case 37 -> {
            byte var52 = 9;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 18;
            yield var54;
         }
         case 40 -> {
            byte var55 = 28;
            yield var55;
         }
         case 41 -> {
            byte var56 = 53;
            yield var56;
         }
         case 42 -> {
            byte var57 = 37;
            yield var57;
         }
         case 43 -> {
            byte var58 = 10;
            yield var58;
         }
         case 44 -> {
            byte var59 = 19;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 22;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 57;
            yield var65;
         }
         case 51 -> {
            byte var66 = 3;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 59;
            yield var68;
         }
         case 54 -> {
            byte var69 = 46;
            yield var69;
         }
         case 55 -> {
            byte var70 = 32;
            yield var70;
         }
         case 56 -> {
            byte var71 = 25;
            yield var71;
         }
         case 57 -> {
            byte var72 = 1;
            yield var72;
         }
         case 58 -> {
            byte var73 = 24;
            yield var73;
         }
         case 59 -> {
            byte var74 = 40;
            yield var74;
         }
         case 60 -> {
            byte var75 = 58;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u000fK!QL\t\u000fK6\r@\u0006\u0015\u00006\u0013@\u0013\u0012qfN\u0014";
      l[1] = "\u0007\u0019\u0000\u007f\u0010\n\u0007\u0019\u0017#\u001c\u0005\u001dR\u0017=\u001c\u0010\u001a#AeD[";
      l[2] = void.class;
      m[2] = "java/lang/Void";
      l[3] = "\u0006p\u0016>Er\u0010p\u0013dVe\u0007;\u0010bZq\u0016|\u0007u\u0011g+";
      l[4] = "<6Toh\u000079E \u000b\r\"4JK>\u000f3'Vg)\u0002";
      l[5] = "x\u0000>+hvx\u0000)wdybK)idle:y45";
      l[6] = "u\te3z;u\trov4oBrqv!h3&)!";
      l[7] = float.class;
      m[7] = "java/lang/Float";
      l[8] = "U#\u001ec\u0017G^,\u000f,{DP.\rcW";
      l[9] = boolean.class;
      m[9] = "java/lang/Boolean";
      l[10] = "_\u000fP;8)I\u000fUa+>^DVg'*O\u0003Apl=}";
      l[11] = "E:MP_[N5\\\u001f>UE>XE";
      l[12] = "3))rE\u0005%),(V\u00122b/.Z\u0006#%89\u0011\u0014g";
      l[13] = "RrFcM~'RMl\\1F\\FgXk2";
      l[14] = "|\b=2.m\t(6=?\"h&=6;x\u001c";
      l[15] = "v\f>c\u0005L`\f;9\u0016[wG8?\u001aOf\u0000/(Q]W";
      l[16] = "\u0011q\u001bk>JdQ\u0010d/\u0005\u0005_\u001bo+_q";
      l[17] = "1Lp:8\f'Lu`+\u001b0\u0007vf'\u000f!@aql\u001e\u001d";
      l[18] = "zA\\|]\u001d\u000faWsLRno\\xH\b\u001a";
      l[19] = double.class;
      m[19] = "java/lang/Double";
      l[20] = "3Q\u0007/A\u001eFq\f PQ'\u007f\u0007+T\u000bS";
      l[21] = "2L'77\u001d \u0017-=G\u001bYKmh$\u001c$Af?,r5\u0017/j{\u0018?\u0019?(G";
      l[22] = "yd0D#\u0001-f#6-\r;m6Z\u001f[~5m\rHYv67Mr\n<d`6q\u0006%5.Q'\u0003'=Q";
      l[23] = "CWqQ_@\u001e\u00056S;Qy\u000e2\u001bARFQlKD8B\t?PQ\u0007\u001dWoU;";
      l[24] = "\u001b\u0001d@GZ^\u0006 \u001d?\u0005A\u0011:LhR\u001eMf \u0001\u0002A\u000e5AU\u0000R";
      l[25] = "V\u0017\u000bJbA\u000f\u000f\n\u0019\rNf\u0018\\LnK\u001b\u0012W\u001bf%_\u0013\u0005HrB\t\u0016\u0007@\r";
      l[26] = "\u000bS0&80T\u000f3fV*ZJi\u007f:\u0018\f\b5%jO\u000bFwd*%\nIw(V";
      l[27] = "z^'i\u000bT)F~k`F Gsd\tJ\u0019Ist\r,yD&e\u0018B#\u0011ls`";
      l[28] = ";\u001f9rd4gC=sY`\u0004B?qdin\u0015\u007fui\t";
      l[29] = "L8R\u0002sQ\u0013dQB\u001dK\u001d!\u000b[qyKcW\u0001 .L-\u0015@aDM\"\u0015\f\u001d";
      l[30] = "$y4F\u0001Na~p\u001by\u0011~ijJ.F >2&E\u001a&:`Y\u001aF%z";
      l[31] = "}lWetQ$tV6\u001b_Mc\u0000cx[0i\u000b4p5thYgdR\"m[o\u001b";
      l[32] = "dWBTM\u0018v\fH^=\u001d\u000fP\b\u000b^\u0019rZ\u0003\\Vwc\fJ\t\u0001\u001di\u0002ZK=";
      l[33] = "2U>^rBf\u0018k\u001e\u000f\u001a[E4]l\u001d&O?\ndsbNmYp\u00144KoQ\u000f";
      l[34] = "\u0018\fX\u0013cmKF\nD\u00189@P\u0007\u0019Om\u001f\u0003]H\u0018n\u0010\u0006\u0005\u000e\"=ZTR";
      l[35] = "\u001a\u0015~C]\u000bN\u0017m1S\u0007X\u001cx]aQ\u001dD#\r6S\u0015GyJ\f\u0000_\u0015.1";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(815312694720824L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(815312694720824L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(815312694720824L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 99;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 86;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 89;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 222;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 213;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 225;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 99;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 86;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 89;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eI_C0233",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eI" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
