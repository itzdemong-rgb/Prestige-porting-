package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.api.events.CameraPositionEvent;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket.Mode;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Freecam extends Module {
   private FloatSetting a;
   private BooleanSetting d;
   private Vec3d c = Vec3d.ZERO;
   private Vec3d e = Vec3d.ZERO;
   private Vec3d f = Vec3d.ZERO;
   private float g = 0.0F;
   private float h = 0.0F;
   private Vec3d i = Vec3d.ZERO;
   private static final long k = 55258731057711L;
   private static final Object[] l = new Object[111];
   private static final String[] m = new String[111];

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 14307093244588L;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      int var24 = var6;
      ClientPlayerEntity var23 = var7.player;
      ClientPlayerEntity var22 = var23;
      ClientPlayerEntity var21 = var23;
      if (var24 != 0) {
         ClientPlayerEntity var25 = var21;
         if (var25 == null) {
            return;
         }

         MinecraftClient var9 = b;
         ClientPlayerEntity var10 = var9.player;
         this.c = var10.getEyePos();
         this.e = this.c;
         Object[] var11 = new Object[]{var4};
         this.f = RaycastUtil.bReturningVec3d(var11);
         MinecraftClient var12 = b;
         ClientPlayerEntity var13 = var12.player;
         this.g = var13.getYaw();
         MinecraftClient var14 = b;
         ClientPlayerEntity var15 = var14.player;
         this.h = var15.getPitch();
         MinecraftClient var16 = b;
         ClientPlayerEntity var17 = var16.player;
         this.i = var17.getVelocity();
         MinecraftClient var18 = b;
         var22 = var18.player;
      }

      Vec3d var20 = Vec3d.ZERO;
      ClientPlayerEntity var19 = var22;
      var19.setVelocity(var20);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      int var4 = Event.bReturningInt();
      int var10 = var4;
      if (var10 == 0) {
         MinecraftClient var5 = b;
         ClientPlayerEntity var11 = var5.player;
         if (var11 != null) {
            MinecraftClient var7 = b;
            Vec3d var9 = this.i;
            ClientPlayerEntity var8 = var7.player;
            var8.setVelocity(var9);
         }

         this.i = Vec3d.ZERO;
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 139239414524182L ^ 33873329909741L;
      int var6 = Event.cReturningInt();
      int var198 = var6;
      MinecraftClient var197 = b;
      MinecraftClient var169 = var197;
      MinecraftClient var168 = var197;
      if (var198 != 0) {
         MinecraftClient var16 = var168;
         Screen var199 = var16.currentScreen;
         if (var199 != null) {
            return;
         }

         MinecraftClient var19 = b;
         GameOptions var20 = var19.options;
         KeyBinding var21 = var20.forwardKey;
         var21.setPressed(false);
         MinecraftClient var23 = b;
         GameOptions var24 = var23.options;
         KeyBinding var25 = var24.backKey;
         var25.setPressed(false);
         MinecraftClient var27 = b;
         GameOptions var28 = var27.options;
         KeyBinding var29 = var28.leftKey;
         var29.setPressed(false);
         MinecraftClient var31 = b;
         GameOptions var32 = var31.options;
         KeyBinding var33 = var32.rightKey;
         var33.setPressed(false);
         MinecraftClient var35 = b;
         GameOptions var36 = var35.options;
         KeyBinding var37 = var36.jumpKey;
         var37.setPressed(false);
         MinecraftClient var39 = b;
         GameOptions var40 = var39.options;
         KeyBinding var41 = var40.sneakKey;
         var41.setPressed(false);
         var169 = b;
      }

      MinecraftClient var43 = var169;
      ClientPlayerEntity var44 = var43.player;
      var44.setSneaking(false);
      float var7 = (float) (Math.PI / 180.0);
      float var8 = (float) Math.PI;
      MinecraftClient var46 = b;
      ClientPlayerEntity var47 = var46.player;
      double var48 = -var47.getYaw() * var7 - var8;
      float var9 = MathHelper.cos(var48);
      MinecraftClient var50 = b;
      ClientPlayerEntity var51 = var50.player;
      double var52 = -var51.getYaw() * var7 - var8;
      float var10 = MathHelper.sin(var52);
      Vec3d var11 = new Vec3d(-var10, 0.0, -var9);
      Vec3d var12 = new Vec3d(0.0, 1.0, 0.0);
      Vec3d var55 = var11;
      Vec3d var54 = var12;
      Vec3d var13 = var54.crossProduct(var55);
      Vec3d var57 = var12;
      Vec3d var56 = var11;
      Vec3d var14 = var56.crossProduct(var57);
      Vec3d var15 = Vec3d.ZERO;
      MinecraftClient var58 = b;
      Window var59 = var58.getWindow();
      long var10000 = var59.getHandle();
      MinecraftClient var60 = b;
      GameOptions var61 = var60.options;
      KeyBindingAccessor var247 = new KeyBindingAccessor(var61.forwardKey);
      Object[] var63 = new Object[]{106023618381563L};
      KeyBindingAccessor var62 = var247;
      Key var64 = var62.aReturningVoid(var63);
      int var67 = var64.getCode();
      long var65 = var10000;
      int var235 = GLFW.glfwGetKey(var65, var67);
      int var202 = var6;
      byte var201 = 1;
      int var200 = var235;
      int var172 = var200;
      byte var173 = var201;
      int var170 = var200;
      byte var171 = var201;
      if (var202 != 0) {
         byte var204 = var171;
         int var203 = var170;
         if (var203 == var204) {
            Vec3d var70 = var11;
            Vec3d var69 = var15;
            var15 = var69.add(var70);
         }

         MinecraftClient var71 = b;
         Window var72 = var71.getWindow();
         var10000 = var72.getHandle();
         MinecraftClient var73 = b;
         GameOptions var74 = var73.options;
         KeyBindingAccessor var248 = new KeyBindingAccessor(var74.backKey);
         Object[] var76 = new Object[]{106023618381563L};
         KeyBindingAccessor var75 = var248;
         Key var77 = var75.aReturningVoid(var76);
         int var80 = var77.getCode();
         long var78 = var10000;
         int var237 = GLFW.glfwGetKey(var78, var80);
         var173 = 1;
         var172 = var237;
      }

      int var207 = var6;
      byte var206 = var173;
      int var205 = var172;
      int var176 = var205;
      byte var177 = var206;
      int var174 = var205;
      byte var175 = var206;
      if (var207 != 0) {
         byte var209 = var175;
         int var208 = var174;
         if (var208 == var209) {
            Vec3d var83 = var11;
            Vec3d var82 = var15;
            var15 = var82.subtract(var83);
         }

         MinecraftClient var84 = b;
         Window var85 = var84.getWindow();
         var10000 = var85.getHandle();
         MinecraftClient var86 = b;
         GameOptions var87 = var86.options;
         KeyBindingAccessor var249 = new KeyBindingAccessor(var87.leftKey);
         Object[] var89 = new Object[]{106023618381563L};
         KeyBindingAccessor var88 = var249;
         Key var90 = var88.aReturningVoid(var89);
         int var93 = var90.getCode();
         long var91 = var10000;
         int var239 = GLFW.glfwGetKey(var91, var93);
         var177 = 1;
         var176 = var239;
      }

      int var212 = var6;
      byte var211 = var177;
      int var210 = var176;
      int var180 = var210;
      byte var181 = var211;
      int var178 = var210;
      byte var179 = var211;
      if (var212 != 0) {
         byte var214 = var179;
         int var213 = var178;
         if (var213 == var214) {
            Vec3d var96 = var13;
            Vec3d var95 = var15;
            var15 = var95.add(var96);
         }

         MinecraftClient var97 = b;
         Window var98 = var97.getWindow();
         var10000 = var98.getHandle();
         MinecraftClient var99 = b;
         GameOptions var100 = var99.options;
         KeyBindingAccessor var250 = new KeyBindingAccessor(var100.rightKey);
         Object[] var102 = new Object[]{106023618381563L};
         KeyBindingAccessor var101 = var250;
         Key var103 = var101.aReturningVoid(var102);
         int var106 = var103.getCode();
         long var104 = var10000;
         int var241 = GLFW.glfwGetKey(var104, var106);
         var181 = 1;
         var180 = var241;
      }

      int var217 = var6;
      byte var216 = var181;
      int var215 = var180;
      int var184 = var215;
      byte var185 = var216;
      int var182 = var215;
      byte var183 = var216;
      if (var217 != 0) {
         byte var219 = var183;
         int var218 = var182;
         if (var218 == var219) {
            Vec3d var109 = var14;
            Vec3d var108 = var15;
            var15 = var108.add(var109);
         }

         MinecraftClient var110 = b;
         Window var111 = var110.getWindow();
         var10000 = var111.getHandle();
         MinecraftClient var112 = b;
         GameOptions var113 = var112.options;
         KeyBindingAccessor var251 = new KeyBindingAccessor(var113.jumpKey);
         Object[] var115 = new Object[]{106023618381563L};
         KeyBindingAccessor var114 = var251;
         Key var116 = var114.aReturningVoid(var115);
         int var119 = var116.getCode();
         long var117 = var10000;
         int var243 = GLFW.glfwGetKey(var117, var119);
         var185 = 1;
         var184 = var243;
      }

      int var222 = var6;
      byte var221 = var185;
      int var220 = var184;
      int var188 = var220;
      byte var189 = var221;
      int var186 = var220;
      byte var187 = var221;
      if (var222 != 0) {
         byte var224 = var187;
         int var223 = var186;
         if (var223 == var224) {
            FloatSetting var121 = this.a;
            Float var122 = (Float)var121.aReturningObject();
            double var10002 = var122.floatValue();
            double var126 = var10002;
            Vec3d var123 = var15;
            var15 = var123.add(var124, var126, var128);
         }

         MinecraftClient var130 = b;
         Window var131 = var130.getWindow();
         var10000 = var131.getHandle();
         MinecraftClient var132 = b;
         GameOptions var133 = var132.options;
         KeyBindingAccessor var252 = new KeyBindingAccessor(var133.sneakKey);
         Object[] var135 = new Object[]{106023618381563L};
         KeyBindingAccessor var134 = var252;
         Key var136 = var134.aReturningVoid(var135);
         int var139 = var136.getCode();
         long var137 = var10000;
         int var245 = GLFW.glfwGetKey(var137, var139);
         var189 = 1;
         var188 = var245;
      }

      byte var226 = var189;
      int var225 = var188;
      if (var225 == var226) {
         FloatSetting var140 = this.a;
         Float var141 = (Float)var140.aReturningObject();
         double var254 = -var141;
         double var145 = var254;
         Vec3d var142 = var15;
         var15 = var142.add(var143, var145, var147);
      }

      Vec3d var149 = var15;
      Vec3d var246 = var149.normalize();
      FloatSetting var150 = this.a;
      Float var151 = (Float)var150.aReturningObject();
      float var253 = var151;
      MinecraftClient var152 = b;
      Window var153 = var152.getWindow();
      long var255 = var153.getHandle();
      MinecraftClient var154 = b;
      GameOptions var155 = var154.options;
      KeyBindingAccessor var10003 = new KeyBindingAccessor(var155.sprintKey);
      Object[] var157 = new Object[]{106023618381563L};
      KeyBindingAccessor var156 = var10003;
      Key var158 = var156.aReturningVoid(var157);
      int var161 = var158.getCode();
      long var159 = var255;
      int var256 = GLFW.glfwGetKey(var159, var161);
      byte var230 = 1;
      int var229 = var256;
      float var228 = var253;
      Vec3d var227 = var246;
      Vec3d var192 = var227;
      float var193 = var228;
      Vec3d var190 = var227;
      float var191 = var228;
      Vec3d var194;
      float var195;
      float var196;
      if (var229 == var230) {
         float var233 = 2.0F;
         float var232 = var191;
         Vec3d var231 = var190;
         var194 = var231;
         var195 = var232;
         var196 = var233;
      } else {
         var196 = 1.0F;
         var195 = var193;
         var194 = var192;
      }

      double var164 = var195 * var196;
      Vec3d var163 = var194;
      var15 = var163.multiply(var164);
      this.e = this.c;
      Vec3d var167 = var15;
      Vec3d var166 = this.c;
      this.c = var166.add(var167);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      int var4 = Event.bReturningInt();
      Object[] var6 = new Object[0];
      PlayerUpdateEvent var5 = var1;
      EventPhase var10000 = var5.aReturningEventPhase(var6);
      EventPhase var33 = EventPhase.PRE;
      EventPhase var32 = var10000;
      if (var32 == var33) {
         MinecraftClient var8 = b;
         int var35 = var4;
         ClientPlayerEntity var34 = var8.player;
         ClientPlayerEntity var31 = var34;
         ClientPlayerEntity var30 = var34;
         if (var35 == 0) {
            ClientPlayerEntity var36 = var30;
            if (var36 == null) {
               return;
            }

            MinecraftClient var10 = b;
            Vec3d var11 = this.f;
            Vec3d var12 = this.f;
            Vec3d var13 = this.f;
            double var19 = var13.z;
            double var17 = var12.y;
            double var15 = var11.x;
            ClientPlayerEntity var14 = var10.player;
            var14.setPosition(var15, var17, var19);
            MinecraftClient var21 = b;
            var31 = var21.player;
         }

         Vec3d var23 = Vec3d.ZERO;
         ClientPlayerEntity var22 = var31;
         var22.setVelocity(var23);
         Object[] var25 = new Object[]{this.g};
         PlayerUpdateEvent var24 = var1;
         var24.bReturningVoid(var25);
         Object[] var27 = new Object[]{this.h};
         PlayerUpdateEvent var26 = var1;
         var26.cReturningVoid(var27);
         Object[] var29 = new Object[0];
         PlayerUpdateEvent var28 = var1;
         var28.aReturningVoid(var29);
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var9 = new Object[0];
      PacketSendEvent var8 = var1;
      Packet var6 = var8.aReturningVoid(var9);
      int var4 = var10000;
      int var27 = var4;
      Packet var26 = var6;
      Packet var20 = var26;
      Packet var19 = var26;
      if (var27 == 0) {
         boolean var28 = var19 instanceof ClientCommandC2SPacket;
         if (!var28) {
            return;
         }

         Packet var29 = var6;
         var20 = var29;
      }

      ClientCommandC2SPacket var5 = (ClientCommandC2SPacket)var20;
      int var30 = var4;
      if (var30 == 0) {
         byte var25;
         label29: {
            label28: {
               ClientCommandC2SPacket var13 = var5;
               Mode var42 = var13.getMode();
               int var33 = var4;
               Mode var32 = Mode.START_SPRINTING;
               Mode var31 = var42;
               Mode var23 = var31;
               Mode var24 = var32;
               Mode var21 = var31;
               Mode var22 = var32;
               if (var33 == 0) {
                  Mode var35 = var22;
                  Mode var34 = var21;
                  if (var34 == var35) {
                     break label28;
                  }

                  Mode var37 = Mode.STOP_SPRINTING;
                  Mode var36 = var42;
                  var23 = var36;
                  var24 = var37;
               }

               Mode var39 = var24;
               Mode var38 = var23;
               if (var38 != var39) {
                  var25 = 0;
                  break label29;
               }
            }

            byte var40 = 1;
            var25 = var40;
         }

         byte var7 = var25;
         byte var41 = var7;
         if (var41 != 0) {
            Object[] var18 = new Object[0];
            PacketSendEvent var17 = var1;
            var17.aReturningVoid(var18);
         }
      }
   }

   @EventListener
   public void a(CameraPositionEvent var1) {
      long var10001 = 114193671475872L ^ 8625244361877L;
      Object[] var7 = new Object[]{105570054506037L};
      float var6 = GameRenderUtil.aReturningFloat(var7);
      Vec3d var8 = this.e;
      float var10002 = (float)var8.x;
      Vec3d var9 = this.c;
      float var12 = (float)var9.x;
      float var11 = var10002;
      float var10 = var6;
      Object[] var14 = new Object[]{(double)MathHelper.lerp(var10, var11, var12)};
      CameraPositionEvent var13 = var1;
      var13.bReturningVoid(var14);
      Vec3d var15 = this.e;
      var10002 = (float)var15.y;
      Vec3d var16 = this.c;
      float var19 = (float)var16.y;
      float var18 = var10002;
      float var17 = var6;
      Object[] var21 = new Object[]{(double)MathHelper.lerp(var17, var18, var19)};
      CameraPositionEvent var20 = var1;
      var20.cReturningVoid(var21);
      Vec3d var22 = this.e;
      var10002 = (float)var22.z;
      Vec3d var23 = this.c;
      float var26 = (float)var23.z;
      float var25 = var10002;
      float var24 = var6;
      Object[] var28 = new Object[]{(double)MathHelper.lerp(var24, var25, var26)};
      CameraPositionEvent var27 = var1;
      var27.dReturningVoid(var28);
      Object[] var30 = new Object[0];
      CameraPositionEvent var29 = var1;
      var29.aReturningVoid(var30);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 79972998802576L ^ 82315935452834L;
      var10001 = 79972998802576L ^ 81291322742483L;
      var10001 = 79972998802576L ^ 57500539755344L;
      var10001 = 79972998802576L ^ 44810184096916L;
      int var12 = Event.cReturningInt();
      int var35 = var12;
      Freecam var34 = this;
      Freecam var33 = var34;
      Freecam var32 = var34;
      if (var35 != 0) {
         BooleanSetting var16 = var32.d;
         Boolean var17 = (Boolean)var16.aReturningObject();
         boolean var36 = var17;
         if (!var36) {
            return;
         }

         Freecam var37 = this;
         var33 = var37;
      }

      Vec3d var20 = var33.f;
      float var13 = (float)var20.x;
      Vec3d var21 = this.f;
      float var14 = (float)var21.y;
      Vec3d var22 = this.f;
      float var15 = (float)var22.z;
      RenderContext var10000 = var1.b;
      MeshBufferManager var42 = var1.a;
      float var10002 = var13 - 0.3F;
      float var10004 = var15 - 0.3F;
      float var10005 = var13 + 0.3F;
      MinecraftClient var23 = b;
      ClientPlayerEntity var24 = var23.player;
      float var10006 = var14 + var24.getHeight();
      float var10007 = var15 + 0.3F;
      Object[] var25 = new Object[]{2617886958130L};
      Color var10008 = ClientUiUtil.dReturningColor(var25);
      Object[] var10012 = new Object[]{null, null, 1456904419907L};
      var10012[1] = 0.1F;
      var10012[0] = var10008;
      Object[] var26 = var10012;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.bReturningColor(var26), 137403672065984L};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var14;
      var10011[2] = var10002;
      var10011[1] = var42;
      var10011[0] = var10000;
      Object[] var27 = var10011;
      ShapeRenderer.hReturningVoid(var27);
      var10000 = var1.b;
      MeshBufferManager var43 = var1.a;
      var10002 = var13 - 0.3F;
      var10004 = var15 - 0.3F;
      var10005 = var13 + 0.3F;
      MinecraftClient var28 = b;
      ClientPlayerEntity var29 = var28.player;
      var10006 = var14 + var29.getHeight();
      var10007 = var15 + 0.3F;
      Object[] var30 = new Object[]{2617886958130L};
      var10011 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.dReturningColor(var30), 106090074574852L};
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var14;
      var10011[2] = var10002;
      var10011[1] = var43;
      var10011[0] = var10000;
      Object[] var31 = var10011;
      ShapeRenderer.gReturningVoid(var31);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 1;
            yield var16;
         }
         case 2 -> {
            byte var17 = 20;
            yield var17;
         }
         case 3 -> {
            byte var18 = 57;
            yield var18;
         }
         case 4 -> {
            byte var19 = 45;
            yield var19;
         }
         case 5 -> {
            byte var20 = 8;
            yield var20;
         }
         case 6 -> {
            byte var21 = 61;
            yield var21;
         }
         case 7 -> {
            byte var22 = 5;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 55;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 54;
            yield var28;
         }
         case 14 -> {
            byte var29 = 10;
            yield var29;
         }
         case 15 -> {
            byte var30 = 35;
            yield var30;
         }
         case 16 -> {
            byte var31 = 49;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 15;
            yield var33;
         }
         case 19 -> {
            byte var34 = 30;
            yield var34;
         }
         case 20 -> {
            byte var35 = 24;
            yield var35;
         }
         case 21 -> {
            byte var36 = 50;
            yield var36;
         }
         case 22 -> {
            byte var37 = 41;
            yield var37;
         }
         case 23 -> {
            byte var38 = 11;
            yield var38;
         }
         case 24 -> {
            byte var39 = 37;
            yield var39;
         }
         case 25 -> {
            byte var40 = 9;
            yield var40;
         }
         case 26 -> {
            byte var41 = 62;
            yield var41;
         }
         case 27 -> {
            byte var42 = 39;
            yield var42;
         }
         case 28 -> {
            byte var43 = 53;
            yield var43;
         }
         case 29 -> {
            byte var44 = 13;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 23;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 40;
            yield var48;
         }
         case 34 -> {
            byte var49 = 7;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 34;
            yield var51;
         }
         case 37 -> {
            byte var52 = 12;
            yield var52;
         }
         case 38 -> {
            byte var53 = 44;
            yield var53;
         }
         case 39 -> {
            byte var54 = 43;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 29;
            yield var56;
         }
         case 42 -> {
            byte var57 = 58;
            yield var57;
         }
         case 43 -> {
            byte var58 = 26;
            yield var58;
         }
         case 44 -> {
            byte var59 = 42;
            yield var59;
         }
         case 45 -> {
            byte var60 = 22;
            yield var60;
         }
         case 46 -> {
            byte var61 = 6;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 19;
            yield var67;
         }
         case 53 -> {
            byte var68 = 25;
            yield var68;
         }
         case 54 -> {
            byte var69 = 48;
            yield var69;
         }
         case 55 -> {
            byte var70 = 18;
            yield var70;
         }
         case 56 -> {
            byte var71 = 16;
            yield var71;
         }
         case 57 -> {
            byte var72 = 3;
            yield var72;
         }
         case 58 -> {
            byte var73 = 63;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 32;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 59;
            yield var77;
         }
         default -> 60;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "h\u0012N\u000e\u000bgh\u0012YR\u0007hrYYL\u0007}u(\r\u0014P";
      l[1] = "i@\u0001Mj.i@\u0016\u0011f!s\u000b\u0016\u000ff4tzGW4";
      l[2] = "\u001fxD+*w\txAq9`\u001e3Bw5t\u000ftU`~b1";
      l[3] = "u;<AcW~4-\u000e\u0000Zk9\"e5Xz*>I\"U";
      l[4] = float.class;
      m[4] = "java/lang/Float";
      l[5] = "\u0016s^DZT\u0000s[\u001eIC\u00178X\u0018EW\u0006\u007fO\u000f\u000eE7";
      l[6] = int.class;
      m[6] = "java/lang/Integer";
      l[7] = "\u0002Q=\bC{\u0014Q8RPl\u0003\u001a;T\\x\u0012],C\u0017hU";
      l[8] = "\u000eN}\fl`{nv\u0003}/\u001a`}\byun";
      l[9] = void.class;
      m[9] = "java/lang/Void";
      l[10] = "~Q-4\bo~Q:h\u0004`d\u001a:v\u0004uckj+U";
      l[11] = "B\u0007GV=]B\u0007P\n1RXLP\u00141G_=\u0000Ie";
      l[12] = "\u0017Zpr,A\u0017Zg. N\r\u0011g0 [\n`7lu";
      l[13] = "1'\u0007Fpo1'\u0010\u001a|`+l\u0010\u0004|u,\u001dG[*";
      l[14] = "<\u0006xUd\\<\u0006o\thS&Mo\u0017hF!<?N:\u0007";
      l[15] = double.class;
      m[15] = "java/lang/Double";
      l[16] = "\u001e=~5\u000b\u0002\u001e=ii\u0007\r\u0004viw\u0007\u0018\u0003\u00079-Q^T;fz\u0015\u0018/k:-";
      l[17] = "\u0001Pzc[u\u0004EqcPn\bU3\n{D9";
      l[18] = long.class;
      m[18] = "java/lang/Long";
      l[19] = "\u000e\u0016Q\u001e1;\u0018\u0016TD\",\u000f]WB.8\u001e\u001a@Ue/,";
      l[20] = "A\u0012DQ) J\u001dU\u001eH.A\u0016QD";
      l[21] = boolean.class;
      m[21] = "java/lang/Boolean";
      l[22] = "wTp>\u0007ZwTgb\u000bUm\u001fg|\u000b@jn5 ^\u0002";
      l[23] = "\u001et#Ymo\bt&\u0003~x\u001f?%\u0005rl\u000ex2\u00129S";
      l[24] = "\u0012\u0017\r\u0012\t*g7\u0006\u001d\u0018e\u00069\r\u0016\u001c?r";
      l[25] = "\n\u001eRIpU\u0001\u0011C\u0006\u0018U\u000f\u001eP";
      l[26] = "\u0005\u0012_\u001375\u0013\u0012ZI$\"\u0004YYO(6\u0015\u001eNXc$#";
      l[27] = "\bx\"H\\&}X)GMi\u001cV\"LI3h";
      l[28] = "L-\u0018T\u001fpQ8@v^}I>";
      l[29] = "G\\\u000bv\u001aFQ\\\u000e,\tQF\u0017\r*\u0005EWP\u001a=NRU";
      l[30] = "f\u0016\n\u0016\u0012V\u00136\u0001\u0019\u0003\u0019r8\n\u0012\u0007C\u0006";
      l[31] = "H\u001e\u0000vdWC\u0011\u00119\bTM\u0013\u0013v$";
      l[32] = "4b\u0013\u001f[zAB\u0018\u0010J5 L\u0013\u001bNoT";
      l[33] = "lm=>j\f\u0019M61{CxC=:\u007f\u0019\f";
      l[34] = "\u0003/uPG\f\u0015/p\nT\u001b\u0002ds\fX\u000f\u0013#d\u001b\u0013\u001e\u0006";
      l[35] = "i8#l%D\u001c\u0018(c4\u000b}\u0016#h0Q\t";
      l[36] = "m^Og&\f\u0018~Dh7CypOc3\u0019\r";
      l[37] = "A($TZ|4\b/[K3U\u0006$POi!";
      l[38] = ":{oL\u007f\u0002,{j\u0016l\u0015;0i\u0010`\u0001*w~\u0007+\u0005";
      l[39] = "h{h ^-\u001d[c/Ob|Uh$K8\b";
      l[40] = "6\tX\f\u0019\u00126\tOP\u0015\u001d,BON\u0015\b+3\u001e\u001a@C|\u000f@C\u0007\b\u0007^\u0014\u0016M";
      l[41] = "\u000f/\u0003:\u0000G\u000f/\u0014f\fH\u0015d\u0014x\f]\u0012\u0015E,Y\u0016";
      l[42] = "Ur5F6\bCr0\u001c%\u001fT93\u001a)\u000bE~$\rb\u001aT";
      l[43] = "(5s\u001c\u001c<]\u0015x\u0013\rs<\u001bs\u0018\t)H";
      l[44] = "=\"y23\n=\"nn?\u0005'inp?\u0010 \u0018?)gU";
      l[45] = "Ex\u001aQ]\u0011Sx\u001f\u000bN\u0006D3\u001c\rB\u0012Ut\u000b\u001a\t\u0000p";
      l[46] = "cHaSNB\u0016hj\\_\rwfaW[W\u0003";
      l[47] = "o{_4{5\u001a[T;jz{U_0n \u000f";
      l[48] = "CZk)!CUZns2TB\u0011mu>@SVzbuWP";
      l[49] = "\u001cO/'l>io$(}q\ba/#y+|";
      l[50] = "%\u0006S\u001c\u0000\u007fP&X\u0013\u001101(S\u0018\u0015jE";
      l[51] = "\u0011\u0011@2x\u0016\u0004F\u001b7DEo\u0006\u0007r=\u0014R\u001e\u0019+=)Q\u0010\u001a#-O\u0005K\u0012pD";
      l[52] = "Q\u0001\u001ei\u0006C\u0004\u0013@\"<\u0016\u000f\u0012BwkA^C\u0017\u001b\f\u0012\u0001\u0015\u0018fA\bR\u0007";
      l[53] = "\u0000Vj?1\u0002\u000f\u001fc6\u0000\u0014_Ii+WC\u0001\u00190G1\u001eCYo>8\u001eNZ";
      l[54] = "}\b\u0017UJ c\u000b\u001f;C'a\u0017AWqq#K\u001b\u0007&p`\u0006YTW'~\u001e\u001a;";
      l[55] = "\u0001=\u0011K+[Q2\u0011TPW]>\f]<e\t\u007fW\u0004j2Y#\bYlNO'\u001e\u0002P\bM3\u0013U!_S+P:";
      l[56] = "\u001c9>x@)\u000fo1+$0\u001b+1'H\u0002Okm|$i\u000e3=%G,\u0013l=@";
      l[57] = "d[\u000b|&xzX\u0003\u0012/\u007fxD]~\u001d+4\u001b\u000b#Jlg\u0015Xbvu>B:,-wjM\\xv\u007f9$";
      l[58] = "[ \u000e\n\u0010+E#\u0006d\u0019,G?X\b+z\u0005c\u0002Y|{F.@\u000b\r,X6\u0003d";
      l[59] = "H\u000fd3t1\u001d\u001d:xNd\u0016\u001c8-\u00193G@`A~`\u0018\u001bb<3zK\t";
      l[60] = "\u0015R\u001bD\u0013{U\u000bX\u0000bh)\u001f\\\u0000\u001b<\u0014\u0007BY\u001b\u0001\u0017\tAQ\u000bgCRI\u0002b";
      l[61] = "l\u0011,xAD<\u001e,g:H0\u00121nVzdPm2\u000b-g\u0013 vU\\0\r85:\u0017 \u001f.fK@>\u0007m\t\u0000P,\u0011>xWN4RQ3G\\\"\u0001 dYDan";
      l[62] = ".;\u0018Ag1!r\u0011HV,}5\u001f^:\u001e*sA\tmI~4\u000eGi&ur\u0007\u0004V";
      l[63] = "\u0013>\u0000X\u001e\t\r=\b6\u0017\u000e\u000f!VZ%XH|\u000e\u000fr\u001d\u0010pSFN\u0004I'1";
      l[64] = "\u0017e_B|1\u000e<\b bl\u0004b\u0002w56T<nImi\n:\u0012_i\u007fQ";
      l[65] = "a/q\u0002pMxv&`n\u0010r(,79J\"u@\ta\u0015|p<\u001fe\u0003'";
      l[66] = "\u0016.\u001b.\u001ct\u0019g\u0012'-bI1\u0018:z5\u0016mDV\u0012r\u0010.FmG`Ne";
      l[67] = ">q}Wajd5&P\u0002{X|b\b{-ed|Q{\u0010fj\u007fYkv21w\n\u0002";
      l[68] = "\u0012UUT%\u0013\u0007\u0002\u000eQ\u0019GlB\u0012\u0014`\u0011QZ\fM`,RT\u000fEpJ\u0006\u000f\u0007\u0016\u0019";
      l[69] = "-\\UKDx>\fOJ#!]MJNZu`UT\u0017ZHgAC\u000eL90_[M#";
      l[70] = "j-E;Wb??\u001bpm74>\u0019%:`dkFI]3:9C4\u0010)i+";
      l[71] = "S\u0017r\u0000iZF@)\u0005U\u000f-\u00005@,X\u0010\u0018+\u0019,e\u0013\u0016(\u0011<\u0003GM BU";
      l[72] = "3\u001a+`BVc\u0015+\u007f9Zo\u00196vUh;Xm.\u0005?k\u00042r\u0005C}\u0000$)9\u0005\u007f\u0014)~HRa\fj\u0011";
      l[73] = "Y;\\3Su\u001e \u00065,|d!\u001ecU+Y9\u0000:U\u0016\u001a3W>\\*\u0003j\u0000\\";
      l[74] = "(\u0000hY\b\u00027N%\u000frUKAm\f\u000b\u0007vYsU\u000b:uWp]\u001b\\!\fx\u000er";
      l[75] = "cK}\fV_z\u0012*nC\u000eaH+\u0002qZ%\u0012tnX\u0000,J<RAY{(2\r\u0017\u0001m\u0014+T@c";
      l[76] = "\u0018Hz;8OMZ$p\u0002\u001aF[&%UM\u0016\u000fyI2\u001eH\\|4\u007f\u0004\u001bN";
      l[77] = "j\u0019\u0012(I\\?\u000bLcs\t4\nN6$^eY\u0015ZC\r:\r\u0014'\u000e\u0017i\u001f";
      l[78] = ":zh\u0003|X`>3\u0004\u001fH\\ww\\f\u001faoi\u0005f\"baj\rvD6:b^\u001f";
      l[79] = "\u0006\u0006f>1SS\u00148u\u000b\u0006X\u0015: \\Q\tHgL;\u0002V\u0012`1v\u0018\u0005\u0000";
      l[80] = "O\rf\u0018V\u000eN\u0013`\u001d(\u001dvLdYV\u001fO\u00185\u001bUtLKb\u001cCM\u0018\u001a \u001f(";
      l[81] = "\u0003ER`l\u0012C\u001c\u0011$\u001d\u0002?E\u0015\u007fq\r\\\u0000\b qh";
      l[82] = ":\u0006(\u00006\u0006#_\u007fb#W8\u0005~\u000e\u0011\u0003|^'b8Yu\u0007i^!\u0000\"eg\u0001wX4Y~X :";
      l[83] = "WiZFU\u001bH'\u0017\u0010/C4(_\u0013V\u001e\t0AJV#\n>BBFE^eJ\u0011/";
      l[84] = "GR\u001c-G\u001c^\u000bKORMEQJ#`\u0019\u0001\u000b\u001cOIC\bS]sP\u001a_1";
      l[85] = "\u0015\u0018C`l\u0018UA\u0000$\u001d\u000b)U\u0004$d_\u0014M\u001a}dbP\\\u001awl\u0018NZ\u0004p\u001d";
      l[86] = "gbN8&>ckK$\u0016mha\u000e\f{~Ob\u0000Cz?5b@ ,s7vq\u007fnf`j\u0012:s9`\u000fM;rnil\b&-n\f";
      l[87] = "<\r}\"\u0011B|T>f`S\u0000\r:=\f]cH'b\f8";
      l[88] = "\u0002QI\u0012\u0013`V\u001c\u0002A,5\u0000\u000bV\u0013E99\u0005V\u0003A_\n\tC\u0010\u00141\u001b\u0006W\u0014,";
      l[89] = "h?~Ix2*0h\r\u001cerlu^K2)0!\u000b\u001cp-njV%2\"x.";
      l[90] = "^h\u0015_U5B`\u0011\b?-Hd\u0012TS\u001f\u001c\"I\r\u0002H^&\u001dH[q\u001c)\u000b\f?";
      l[91] = "\u0007.;'D{\u0011%xq{qk/p3\u0003~V81v\u0000\u0018";
      l[92] = "PY\u0015\u001fW6I\u0000B}IkC^H*\u001e1\u0013\u0002$\u0014FnM\u0006X\u0002Bx\u0016";
      l[93] = "1\u000f\r!TJ/\f\u0005O]M-\u0010[#o\u0019aO\r\u007f8^2A^?\u0004Gk\u0016<";
      l[94] = "1cIia\u001d>*@`P\u000bn|J}\u0007\\0+\u0012\u00110\u001a>\u007fB{.\u00196";
      l[95] = "u4x\u001a@!lm/x^|f3%/\t&6lI\u0006S,i'u\u001f\n{";
      l[96] = "2J\u00063\u0016\u0015,I\u000e]\u001f\u0012.UP1-Bl\u000b\u000f]\u0017\u001a#[\u000f3\u0006\u00157_7c\u001d\u001a<\\Q7F\u0012o5";
      l[97] = "&~\f6T.8}\u0004X]):aZ4oyv8\u0001XQ%\"b\u0001$G!49=1Y %=A']6~\u0001T9\\'z}B=J|F?Z=V- k\u00015\u0005D";
      l[98] = "E\f*qC}\u0002\u000f\"wxv9\u001a()\u0001\"\u0004\u00026p\u0001\u001fD\u000f/x\tu\u0003[9xx";
      l[99] = "U/h\u0016A$^iaU~.V.y\u000f\u0012\u001c\u0007n(P~'\u0006ktY\u001dqJi`h";
      l[100] = "A\u001dP$<-\\\u001eS&\fy V\u0017uu(\u001dN\t,u\u0015BF^t}~@H\bw\f";
      l[101] = ")Ij\u001f\u007f{z\u0006,\f\u0002+F\bhC{\u007f{\u0010v\u001a{B,\u0017\u007fDf>?Ap\u0017\u0002";
      l[102] = "(v\u000e\t*\u001fjy\u0018MNH2%\u0005\u001e\u0019\u001fiyQON]m'\u001a\u0016w\u001fb1^";
      l[103] = "\u0016\u0011S|~aC\u0003\r7D4H\u0002\u000fb\u0013c\u0019TQ\u000et0F\u0005Us9*\u0015\u0017";
      l[104] = "`/@V \b-5\u0013D\u001e\u0010=9O[r\"j~\u0013\f'u= ^R&\u001b,/JV\u001eK7 AUx\u001fl(\u0012<";
      l[105] = "9\u007f\u00009@i &W[U8;|V7gl\u007f%\u0000[N6v~AgWo!\u001cO8\u000177 VaVU";
      l[106] = "}6c\u0010(h`5`\u0012\u0018:\u001c}$Aam!e:\u0018aP~mm@i;|c;C\u0018";
      l[107] = "b-s-rS:1w3\t\u0001f-&2W\u0006f7\"N3\u0012s5 ?d\fkvO";
      l[108] = "\u0000v\u000b4@P\u001eu\u0003ZIW\u001ci]6{\u0003_7\n`,\u0000\u001dxE5]W\u0003`\u0006Z";
      l[109] = "!G\u0017\u001d\u0012j8\u001e@\u007f\u0007;#DA\u00135og\u001e\u001f\u007f\u000b7;G\u001a\u0003\u001d3-\u001c&\u0001\u0001g=T\u001a\u0018X0_";
      l[110] = "Ki[\u000fV\u0013R0\fmCBIj\r\u0001q\u0016\r1SmONQiV\u0011YJG2j\u0004GKV6\u0016\u0012C]\r\n\u0003\fBL\tv\u0015\bT\u00175t\t\\D_\tmP\u000b&";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1449401034936808L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1449401034936808L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1449401034936808L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 84;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 208;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 120;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 196;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 231;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 236;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 84;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 208;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 120;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eJ_C0235",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eJ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
