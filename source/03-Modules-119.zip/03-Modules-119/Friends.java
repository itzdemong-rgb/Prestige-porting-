package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.PlayerNameEvent;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.AttackCooldownEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;

public class Friends extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private static final long k = 19714280384828L;
   private static final Object[] l = new Object[62];
   private static final String[] m = new String[62];

   @EventListener
   public void a(PlayerNameEvent var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var7 = this.a;
      Boolean var8 = (Boolean)var7.aReturningObject();
      boolean var30 = var8;
      if (var30) {
         SocialsManager var10 = Prestige.g;
         List var11 = var10.aReturningVoid();
         Iterator var5 = var11.iterator();

         int var36;
         do {
            Iterator var12 = var5;
            boolean var31 = var12.hasNext();
            if (!var31) {
               break;
            }

            label24: {
               Iterator var13 = var5;
               String var6 = (String)var13.next();
               int var33 = var4;
               PlayerNameEvent var32 = var1;
               PlayerNameEvent var29 = var32;
               PlayerNameEvent var28 = var32;
               if (var33 == 0) {
                  Object[] var15 = new Object[0];
                  PlayerNameEvent var14 = var28;
                  String var10000 = var14.bReturningString(var15);
                  String var17 = var6;
                  String var16 = var10000;
                  boolean var34 = var16.contains(var17);
                  if (!var34) {
                     break label24;
                  }

                  Object[] var20 = new Object[]{var6};
                  PlayerNameEvent var19 = var1;
                  var19.bReturningVoid(var20);
                  Formatting var21 = Formatting.AQUA;
                  String var10001 = String.valueOf(var21);
                  Formatting var22 = Formatting.RESET;
                  Object[] var24 = new Object[]{var10001 + var6 + var22};
                  PlayerNameEvent var23 = var1;
                  var23.cReturningVoid(var24);
                  PlayerNameEvent var35 = var1;
                  var29 = var35;
               }

               Object[] var27 = new Object[0];
               PlayerNameEvent var26 = var29;
               var26.aReturningVoid(var27);
            }

            var36 = var4;
         } while (var36 == 0);
      }
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 84581974549278L ^ 114643398139599L;
      int var6 = Event.cReturningInt();
      BooleanSetting var8 = this.d;
      Boolean var9 = (Boolean)var8.aReturningObject();
      boolean var23 = var9;
      if (var23) {
         Object[] var12 = new Object[0];
         AttackEntityEvent var11 = var1;
         Entity var7 = var11.aReturningEntity(var12);
         boolean var10000 = var7 instanceof PlayerEntity;
         int var25 = var6;
         boolean var24 = var10000;
         boolean var22 = var24;
         boolean var21 = var24;
         if (var25 != 0) {
            boolean var26 = var21;
            if (!var26) {
               return;
            }

            SocialsManager var29 = Prestige.g;
            Entity var14 = var7;
            Text var15 = var14.getName();
            Object[] var17 = new Object[]{var15.getString(), 40309233401297L};
            SocialsManager var16 = var29;
            boolean var27 = var16.aReturningBoolean(var17);
            var22 = var27;
         }

         boolean var28 = var22;
         if (var28) {
            Object[] var20 = new Object[0];
            AttackEntityEvent var19 = var1;
            var19.aReturningVoid(var20);
         }
      }
   }

   @EventListener
   public void a(AttackCooldownEvent var1) {
      long var10001 = 117208534283064L ^ 85970288725737L;
      int var6 = Event.cReturningInt();
      BooleanSetting var9 = this.d;
      Boolean var10 = (Boolean)var9.aReturningObject();
      boolean var32 = var10;
      if (var32) {
         MinecraftClient var12 = b;
         HitResult var7 = var12.crosshairTarget;
         int var34 = var6;
         HitResult var33 = var7;
         HitResult var27 = var33;
         HitResult var26 = var33;
         if (var34 != 0) {
            HitResult var35 = var26;
            if (var35 == null) {
               return;
            }

            var27 = var7;
         }

         int var37 = var6;
         HitResult var36 = var27;
         HitResult var29 = var36;
         HitResult var28 = var36;
         if (var37 != 0) {
            HitResult var14 = var28;
            Type var10000 = var14.getType();
            Type var39 = Type.ENTITY;
            Type var38 = var10000;
            if (var38 != var39) {
               return;
            }

            HitResult var40 = var7;
            var29 = var40;
         }

         EntityHitResult var17 = (EntityHitResult)var29;
         Entity var8 = var17.getEntity();
         boolean var46 = var8 instanceof PlayerEntity;
         int var42 = var6;
         boolean var41 = var46;
         boolean var31 = var41;
         boolean var30 = var41;
         if (var42 != 0) {
            boolean var43 = var30;
            if (!var43) {
               return;
            }

            SocialsManager var47 = Prestige.g;
            Entity var19 = var8;
            Text var20 = var19.getName();
            Object[] var22 = new Object[]{var20.getString(), 40309233401297L};
            SocialsManager var21 = var47;
            boolean var44 = var21.aReturningBoolean(var22);
            var31 = var44;
         }

         boolean var45 = var31;
         if (var45) {
            Object[] var25 = new Object[0];
            AttackCooldownEvent var24 = var1;
            var24.aReturningVoid(var25);
         }
      }
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      long var10001 = 21789110373918L ^ 60988898849743L;
      int var6 = Event.bReturningInt();
      Object[] var10 = new Object[0];
      AttackAttemptEvent var9 = var1;
      EventPhase var10000 = var9.aReturningEventPhase(var10);
      int var42 = var6;
      EventPhase var41 = var10000;
      Object var34 = var41;
      EventPhase var33 = var41;
      if (var42 == 0) {
         EventPhase var44 = EventPhase.PRE;
         EventPhase var43 = var33;
         if (var43 != var44) {
            return;
         }

         BooleanSetting var13 = this.d;
         var34 = var13.aReturningObject();
      }

      Boolean var14 = (Boolean)var34;
      boolean var45 = var14;
      if (var45) {
         MinecraftClient var16 = b;
         HitResult var7 = var16.crosshairTarget;
         int var47 = var6;
         HitResult var46 = var7;
         HitResult var36 = var46;
         HitResult var35 = var46;
         if (var47 == 0) {
            HitResult var48 = var35;
            if (var48 == null) {
               return;
            }

            var36 = var7;
         }

         int var50 = var6;
         HitResult var49 = var36;
         HitResult var38 = var49;
         HitResult var37 = var49;
         if (var50 == 0) {
            HitResult var18 = var37;
            Type var59 = var18.getType();
            Type var52 = Type.ENTITY;
            Type var51 = var59;
            if (var51 != var52) {
               return;
            }

            HitResult var53 = var7;
            var38 = var53;
         }

         EntityHitResult var21 = (EntityHitResult)var38;
         Entity var8 = var21.getEntity();
         boolean var60 = var8 instanceof PlayerEntity;
         int var55 = var6;
         boolean var54 = var60;
         boolean var40 = var54;
         boolean var39 = var54;
         if (var55 == 0) {
            boolean var56 = var39;
            if (!var56) {
               return;
            }

            SocialsManager var61 = Prestige.g;
            Entity var23 = var8;
            Text var24 = var23.getName();
            Object[] var26 = new Object[]{var24.getString(), 40309233401297L};
            SocialsManager var25 = var61;
            boolean var57 = var25.aReturningBoolean(var26);
            var40 = var57;
         }

         boolean var58 = var40;
         if (var58) {
            MinecraftClient var28 = b;
            ClientPlayerEntity var29 = var28.player;
            var29.handSwinging = dev.prestige.recovery.SourceSupport.asBoolean(0);
            Object[] var32 = new Object[0];
            AttackAttemptEvent var31 = var1;
            var31.aReturningVoid(var32);
         }
      }
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 12;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 33;
            yield var17;
         }
         case 3 -> {
            byte var18 = 49;
            yield var18;
         }
         case 4 -> {
            byte var19 = 5;
            yield var19;
         }
         case 5 -> {
            byte var20 = 16;
            yield var20;
         }
         case 6 -> {
            byte var21 = 48;
            yield var21;
         }
         case 7 -> {
            byte var22 = 9;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 35;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 61;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 22;
            yield var31;
         }
         case 17 -> {
            byte var32 = 60;
            yield var32;
         }
         case 18 -> {
            byte var33 = 31;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 21;
            yield var36;
         }
         case 22 -> {
            byte var37 = 10;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 59;
            yield var39;
         }
         case 25 -> {
            byte var40 = 20;
            yield var40;
         }
         case 26 -> {
            byte var41 = 28;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 26;
            yield var43;
         }
         case 29 -> {
            byte var44 = 42;
            yield var44;
         }
         case 30 -> {
            byte var45 = 18;
            yield var45;
         }
         case 31 -> {
            byte var46 = 25;
            yield var46;
         }
         case 32 -> {
            byte var47 = 19;
            yield var47;
         }
         case 33 -> {
            byte var48 = 53;
            yield var48;
         }
         case 34 -> {
            byte var49 = 36;
            yield var49;
         }
         case 35 -> {
            byte var50 = 44;
            yield var50;
         }
         case 36 -> {
            byte var51 = 47;
            yield var51;
         }
         case 37 -> {
            byte var52 = 15;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 8;
            yield var54;
         }
         case 40 -> {
            byte var55 = 27;
            yield var55;
         }
         case 41 -> {
            byte var56 = 56;
            yield var56;
         }
         case 42 -> {
            byte var57 = 24;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 4;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 29;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 41;
            yield var63;
         }
         case 49 -> {
            byte var64 = 46;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 11;
            yield var66;
         }
         case 52 -> {
            byte var67 = 34;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 3;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 6;
            yield var74;
         }
         case 60 -> {
            byte var75 = 23;
            yield var75;
         }
         case 61 -> {
            byte var76 = 17;
            yield var76;
         }
         case 62 -> {
            byte var77 = 0;
            yield var77;
         }
         default -> 40;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "h=\u0018h\u001fx~=\u001d2\foiv\u001e4\u0000{x1\t#KiI";
      l[1] = int.class;
      m[1] = "java/lang/Integer";
      l[2] = "\u0001 tb~3\u0017 q8m$\u0000kr>a0\u0011,e)* \t,g\"pm57g?p*\u0002 ";
      l[3] = "8G*TCz.G/\u000ePm9\f,\b\\y(K;\u001f\u0017l\u0013";
      l[4] = "V\u0014}Z\u007fz@\u0014x\u0000lmW_{\u0006`yF\u0018l\u0011+oy";
      l[5] = "\f+w\nL\u001c\u0007$fE/\u0011\u0012)i.\u001a\u0013\u0003:u\u0002\r\u001e";
      l[6] = "_VL\u0018 k_V[D,dE\u001d[Z,qBl\u000f\u0002{";
      l[7] = boolean.class;
      m[7] = "java/lang/Boolean";
      l[8] = "\u0014d}g\u001a\u0010aDvh\u000b_\u0000J}c\u000f\u0005t";
      l[9] = "M3\t\u0019x>8\u0013\u0002\u0016iqY\u001d\t\u001dm+-";
      l[10] = "%}\u000e\u0019\u0002*3}\u000bC\u0011=$6\bE\u001d)5q\u001fRV-";
      l[11] = "2AT^N{9NE\u0011\"x7LG^\u000e";
      l[12] = "]s\u0017Rpc]s\u0000\u000e|lG8\u0000\u0010|y@IPM-";
      l[13] = "&j8$]$&j/xQ+<!/fQ>;P~9\t";
      l[14] = "FBN]`\u0012FBY\u0001l\u001d\\\tY\u001fl\b[x\tJ;M";
      l[15] = "y!P Ayy!G|MvcjGbMcd\u001b\u0015<\u0015'";
      l[16] = "\r<=\u0002En\u001b<8XVy\fw;^Zm\u001d0,I\u0011z/";
      l[17] = "^\"i[9`U-x\u0014Xn^&|N";
      l[18] = "&\rrhG~&\re4Kq<Fe*Kd;74s\u001c&";
      l[19] = "\u0016 8b;x\u001d/)-F`\u000e( d";
      l[20] = "\u001f\u001dc>\"\f\u001f\u001dtb.\u0003\u0005Vt|.\u0016\u0002'%#vA\u0012\u0014vc<:CL'";
      l[21] = "bGs;\u0012N\u0017gx4\u0003\u0001vis?\u0007[\u0002";
      l[22] = void.class;
      m[22] = "java/lang/Void";
      l[23] = "\u0015\u0017\u0003Y[\u0017\u0003\u0017\u0006\u0003H\u0000\u0014\\\u0005\u0005D\u0014\u0005\u001b\u0012\u0012\u000f\u0006.";
      l[24] = "9&('W\u0014L\u0006#(F[-\b(#B\u0001Y";
      l[25] = "8k\bV\u001cO3d\u0019\u0019qK3x-RCV7d\u001dR";
      l[26] = "M,1\u0005n5M,&Yb:Wg&Gb/P\u0016t\u00197";
      l[27] = "\u007f\u0018%A?/\n8.N.`k6%E*:\u001f";
      l[28] = "moEN%_sg_\u0001GCtz";
      l[29] = "\u001b-\u0007\u0011K\n\u0005%\u001d^,\u000b\u0014>\u0010\u0004\n\r";
      l[30] = ":\u0019dC\u001e%O9oL\u000fj.7dG\u000b0Z";
      l[31] = "+\"\u0015\u001e\u0015v=\"\u0010D\u0006a*i\u0013B\nu;.\u0004UAg\u0007";
      l[32] = "e:r([7\u0010\u001ay'Jxq\u0014r,N\"\u0005";
      l[33] = "4\"Z0*-8(\u00065\u0012%[.Bs,w!s\u0001.nO7 Y&k/>;U!\u0012";
      l[34] = "IF\u001c\u001e=ZW\u0017^o.:\u0011\u0014@\u0002t\nD\u0002G\u0004D";
      l[35] = ")l?\b9\u0007 w3\u000f@\f\"a!\u000f!\u0001>\u0007=\t/\u0018#v\"\u001d?\u0017E; \u0001=\u0018}=$].g";
      l[36] = "^Aj\u0018\u0017\u0011WE8_g\u0003g\u0015=\u0004\u001fT\u001d\u0016d\u0000_";
      l[37] = "|hC\u001d3\u001db4O\u0015H\u000f|c\u001a\u001d\u001fX%1Fq)\u0007 b\u0005\r7[,j";
      l[38] = "o<H*`yc6\u0014/Xq\u00000Pif#zm\u00134$\u001bn>\u0018<efl9B*X";
      l[39] = "qi\b@\u0004Mo5\u0004H\u007f_qbQ@(\b(0\b,\u001eW-cNP\u0000\u000b!k";
      l[40] = "&gb\u0005B\nq`x\u0001r\u0004\u001d6q\u0013\u0015\u0006|s3\u0016\u000bm&\u007fm\u001a\u0019\fc=h\u0004r";
      l[41] = "r\u00059\u0010\u001885^a\u000b\u007f7/\r`\u0016(gt]>zC$)\u001d{BE u\u000e";
      l[42] = "2\u0000\u0003S6),QA\"&I6A\u0003\u001cw3k\u0002^^Ovb\b_^\"t=]A\"";
      l[43] = "7#,,eM1}/.\u000bN(w)!wH.\u001a0sdLeg2r5ST";
      l[44] = "$'7 !#$~aiJ#|'k5#/E)k%'I'=h%5q!946J";
      l[45] = "!\u0003<_\u001ff?R~.\r\u0006yQ`CV6,GgEf";
      l[46] = "#qR\u001b`t (V[Xg\u0019.\n\u001c<`{(T\u001f>\u000e";
      l[47] = "@g\u0017tEy@pY/x!$r\u0011%Fp^/Rx\u0004HN/Yz\u0006(Eg\u0001yx";
      l[48] = "yFWr\u0001VtN]n~R\u0013UQx\u001f\u0005\"[@:\u0003;";
      l[49] = "j\u0010v\u0018r^f\u001a*\u001dJW\u0005\u001cn[t\u0004\u007fA-\u00066<k\u0012&\u000ewAi\u0015|\u0018J";
      l[50] = "5\u0003ChRp7\u0002\u0012wck;HP\u000b\bg.Y\u0012:\u0006vlE,";
      l[51] = "-$+=JWd|bcr\u0000|)\u007fm%W\"~'\u0001N\u000b .|`\tPx5";
      l[52] = "oFbR,\u0004<A`AU\u0015iG_P/\u001bbT\u0004@>\u0018jBdI%\u0014m;";
      l[53] = "TL\bCv\u000e\u0007L\\\u001f\u000e\u000bY^\u0001\u001fY\\\u0003\b\\sb\u001aU\u0003\u001d\u00181\u001a\u0001_";
      l[54] = "\u0011\u001e1\u0004\u001fG\u000fOsu\u000f'\u0015_1K^]H\u001cl\tfI\u001b\u0017dH\u001bK\u001cMru";
      l[55] = "Ikcb\bdB#;avaN/2a\u001aS\u001eom9vo^5,\u007f\b<Y7?\u0006";
      l[56] = "[q|o\u0012\"Yp-p#?Q1UaS#8vnk^ \u0000pj7M_";
      l[57] = "Rfto4)Q?p/\f:h?l,2k\u0012b/qpST'rjskR#.y\f";
      l[58] = "|j\u0017\u0005Xd52^[`3-gCU7ds4\u001a9Qd!{[C\\`!p";
      l[59] = "m\nn\u0019_\\{\u001f%\f!\u0003i\u001a?\u0017M1=Y`@\u001bfn^n\u0014_\u0006e\u00166\u0017!";
      l[60] = "xq\u001f>\r6qj\u00139t(}~\u0000=38\u0014q\u0017(\u0015h%\u007f\u0006j\tVxq\u001f>\r6qj\u00139t";
      l[61] = "AhF\u000f\u001eiLlF\u0004bv\u001d-K\u0019\u000eDIn\u0014NY\u0013\u001c.FN\u001axO.\u0012\u0012b";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1251750354163878L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1251750354163878L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1251750354163878L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 248;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 237;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 86;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 120;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 97;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 248;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 237;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eK_C0237",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eK" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
