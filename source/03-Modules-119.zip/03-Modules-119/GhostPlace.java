package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.ItemUseEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.events.PlayerUpdateEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class GhostPlace extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private long c;
   private static final long k = 3050433557292L;
   private static final long l;
   private static final Object[] m = new Object[105];
   private static final String[] n = new String[105];

   public GhostPlace() {
      this.c = l;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @EventListener
   public void a(PlayerUpdateEvent var1) {
      long var10001 = 120641681120642L ^ 96377630972012L;
      var10001 = 120641681120642L ^ 19423222023116L;
      var10001 = 120641681120642L ^ 115973778275081L;
      var10001 = 120641681120642L ^ 130627259680060L;
      int var12 = Event.bReturningInt();
      int var68 = var12;
      MinecraftClient var67 = b;
      MinecraftClient var52 = var67;
      MinecraftClient var51 = var67;
      if (var68 == 0) {
         MinecraftClient var15 = var51;
         ClientPlayerEntity var69 = var15.player;
         if (var69 == null) {
            return;
         }

         MinecraftClient var70 = b;
         var52 = var70;
      }

      int var72 = var12;
      MinecraftClient var71 = var52;
      MinecraftClient var54 = var71;
      MinecraftClient var53 = var71;
      if (var72 == 0) {
         MinecraftClient var18 = var53;
         ClientWorld var73 = var18.world;
         if (var73 == null) {
            return;
         }

         var54 = b;
      }

      int var75 = var12;
      MinecraftClient var74 = var54;
      MinecraftClient var56 = var74;
      MinecraftClient var55 = var74;
      if (var75 == 0) {
         MinecraftClient var21 = var55;
         Screen var76 = var21.currentScreen;
         if (var76 != null) {
            return;
         }

         MinecraftClient var77 = b;
         var56 = var77;
      }

      MinecraftClient var24 = var56;
      boolean var10000 = var24.isWindowFocused();
      int var79 = var12;
      boolean var78 = var10000;
      boolean var58 = var78;
      boolean var57 = var78;
      if (var79 == 0) {
         boolean var80 = var57;
         if (!var80) {
            return;
         }

         MinecraftClient var26 = b;
         ClientPlayerEntity var27 = var26.player;
         boolean var81 = var27.isUsingItem();
         var58 = var81;
      }

      int var83 = var12;
      boolean var82 = var58;
      boolean var60 = var82;
      boolean var59 = var82;
      if (var83 == 0) {
         boolean var84 = var59;
         if (var84) {
            return;
         }

         RotationManager var98 = Prestige.o;
         Object[] var31 = new Object[0];
         RotationManager var30 = var98;
         var60 = var30.fReturningBoolean(var31);
      }

      int var86 = var12;
      boolean var85 = var60;
      boolean var62 = var85;
      boolean var61 = var85;
      if (var86 == 0) {
         boolean var87 = var61;
         if (var87) {
            return;
         }

         MinecraftClient var33 = b;
         GameOptions var34 = var33.options;
         KeyBinding var35 = var34.useKey;
         var62 = var35.isPressed();
      }

      boolean var88 = var62;
      if (var88) {
         Object[] var37 = new Object[]{30198248839358L};
         GhostPlace var36 = this;
         Hand var13 = var36.aReturningHand(var37);
         Hand var89 = var13;
         if (var89 != null) {
            MinecraftClient var39 = b;
            Object[] var40 = new Object[]{var39.crosshairTarget, 63903727420910L};
            boolean var90 = dReturningBoolean(var40);
            if (var90) {
               Object[] var43 = new Object[]{5236292265611L};
               GhostPlace var42 = this;
               BlockHitResult var14 = var42.aReturningBlockHitResult(var43);
               int var92 = var12;
               BlockHitResult var91 = var14;
               BlockHitResult var64 = var91;
               BlockHitResult var63 = var91;
               if (var92 == 0) {
                  BlockHitResult var93 = var63;
                  if (var93 == null) {
                     return;
                  }

                  var64 = var14;
               }

               int var95 = var12;
               BlockHitResult var94 = var64;
               BlockHitResult var66 = var94;
               BlockHitResult var65 = var94;
               if (var95 == 0) {
                  BlockHitResult var45 = var65;
                  Type var99 = var45.getType();
                  Type var97 = Type.BLOCK;
                  Type var96 = var99;
                  if (var96 != var97) {
                     return;
                  }

                  var66 = var14;
               }

               Object[] var48 = new Object[]{var66, var13, 136422232399438L};
               ItemUseUtil.bReturningBoolean(var48);
               MinecraftClient var49 = b;
               ClientWorld var50 = var49.world;
               this.c = var50.getTime();
            }
         }
      }
   }

   @EventListener
   public void a(ItemUseEvent var1) {
      long var10001 = 66786696651932L ^ 7298284872050L;
      var10001 = 66786696651932L ^ 62117407572503L;
      var10001 = 66786696651932L ^ 43752541486114L;
      int var10 = Event.bReturningInt();
      int var52 = var10;
      MinecraftClient var51 = b;
      MinecraftClient var42 = var51;
      MinecraftClient var41 = var51;
      if (var52 == 0) {
         MinecraftClient var12 = var41;
         ClientPlayerEntity var53 = var12.player;
         if (var53 == null) {
            return;
         }

         MinecraftClient var54 = b;
         var42 = var54;
      }

      int var56 = var10;
      MinecraftClient var55 = var42;
      MinecraftClient var44 = var55;
      MinecraftClient var43 = var55;
      if (var56 == 0) {
         MinecraftClient var15 = var43;
         ClientWorld var57 = var15.world;
         if (var57 == null) {
            return;
         }

         var44 = b;
      }

      MinecraftClient var18 = var44;
      Object[] var19 = new Object[]{var18.crosshairTarget, 63903727420910L};
      boolean var58 = dReturningBoolean(var19);
      if (var58) {
         int var60 = var10;
         GhostPlace var59 = this;
         GhostPlace var46 = var59;
         GhostPlace var45 = var59;
         if (var60 == 0) {
            Object[] var22 = new Object[]{30198248839358L};
            GhostPlace var21 = var45;
            Hand var61 = var21.aReturningHand(var22);
            if (var61 == null) {
               return;
            }

            var46 = this;
         }

         MinecraftClient var25 = b;
         ClientWorld var26 = var25.world;
         long var74;
         int var10000 = (var74 = var46.c - var26.getTime()) == 0L ? 0 : (var74 < 0L ? -1 : 1);
         int var63 = var10;
         int var62 = var10000;
         int var48 = var62;
         int var47 = var62;
         if (var63 == 0) {
            int var64 = var47;
            if (!((var64) != 0)) {
               Object[] var29 = new Object[0];
               ItemUseEvent var28 = var1;
               var28.aReturningVoid(var29);
               return;
            }

            MinecraftClient var31 = b;
            GameOptions var32 = var31.options;
            KeyBinding var33 = var32.useKey;
            var48 = (((var33.isPressed()) ? 1 : 0));
         }

         int var65 = var48;
         if (((var65) != 0)) {
            Object[] var35 = new Object[]{5236292265611L};
            GhostPlace var34 = this;
            BlockHitResult var11 = var34.aReturningBlockHitResult(var35);
            int var67 = var10;
            BlockHitResult var66 = var11;
            BlockHitResult var50 = var66;
            BlockHitResult var49 = var66;
            if (var67 == 0) {
               BlockHitResult var68 = var49;
               if (var68 == null) {
                  return;
               }

               var50 = var11;
            }

            BlockHitResult var37 = var50;
            Type var71 = var37.getType();
            Type var70 = Type.BLOCK;
            Type var69 = var71;
            if (var69 == var70) {
               Object[] var40 = new Object[0];
               ItemUseEvent var39 = var1;
               var39.aReturningVoid(var40);
            }
         }
      }
   }

   private Hand aReturningHand(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 3050433557292L ^ var2;
      long var4 = var2 ^ 132398366466758L;
      int var6 = Event.bReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      Object[] var10 = new Object[]{var8.getMainHandStack(), var4};
      GhostPlace var9 = this;
      boolean var10000 = var9.aReturningBoolean(var10);
      int var25 = var6;
      boolean var24 = var10000;
      boolean var21 = var24;
      boolean var20 = var24;
      if (var25 == 0) {
         boolean var26 = var20;
         if (var26) {
            return Hand.MAIN_HAND;
         }

         BooleanSetting var13 = this.a;
         Boolean var14 = (Boolean)var13.aReturningObject();
         var21 = var14;
      }

      int var28 = var6;
      boolean var27 = var21;
      boolean var23 = var27;
      boolean var22 = var27;
      if (var28 == 0) {
         boolean var29 = var22;
         if (!var29) {
            return null;
         }

         MinecraftClient var16 = b;
         ClientPlayerEntity var17 = var16.player;
         Object[] var19 = new Object[]{var17.getOffHandStack(), var4};
         GhostPlace var18 = this;
         boolean var30 = var18.aReturningBoolean(var19);
         var23 = var30;
      }

      boolean var31 = var23;
      return var31 ? Hand.OFF_HAND : null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 3050433557292L ^ var3;
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      boolean var12 = var6;
      byte var11;
      if (var12) {
         ItemStack var7 = var2;
         Item var17 = var7.getItem();
         Item var14 = Items.COBWEB;
         Item var13 = var17;
         if (var13 == var14) {
            byte var15 = 1;
            var11 = var15;
         } else {
            byte var16 = 0;
            var11 = var16;
         }
      } else {
         ItemStack var10 = var2;
         var11 = ((byte)((var10.getItem() instanceof BlockItem) ? 1 : 0));
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var11);
   }

   private static boolean dReturningBoolean(Object[] var0) {
      HitResult var3 = (HitResult)var0[0];
      long var1 = (Long)var0[1];
      var1 = 3050433557292L ^ var1;
      long var4 = var1 ^ 107849899324422L;
      long var6 = var1 ^ 31274801728275L;
      int var8 = Event.cReturningInt();
      byte var10000 = ((byte)((var3 instanceof EntityHitResult) ? 1 : 0));
      int var32 = var8;
      byte var31 = var10000;
      byte var26 = var31;
      byte var24 = var31;
      if (var32 != 0) {
         byte var33 = var24;
         if (var33 != 0) {
            EntityHitResult var9 = (EntityHitResult)var3;
            EntityHitResult var13 = var9;
            Entity var11 = var13.getEntity();
            byte var46 = ((byte)((var11 instanceof LivingEntity) ? 1 : 0));
            int var35 = var8;
            boolean var34 = dev.prestige.recovery.SourceSupport.asBoolean(var46);
            boolean var50 = var34;
            boolean var25 = var34;
            if (var35 == 0) {
               return var50;
            }

            boolean var36 = var25;
            if (var36) {
               LivingEntity var10 = (LivingEntity)var11;
               int var37 = var8;
               if (var37 != 0) {
                  SocialsManager var47 = Prestige.g;
                  LivingEntity var16 = var10;
                  Text var17 = var16.getName();
                  Object[] var19 = new Object[]{var17.getString(), var6};
                  SocialsManager var18 = var47;
                  var46 = ((byte)((var18.aReturningBoolean(var19)) ? 1 : 0));
                  int var40 = var8;
                  byte var39 = var46;
                  byte var28 = var39;
                  byte var27 = var39;
                  if (var40 != 0) {
                     byte var41 = var27;
                     if (var41 != 0) {
                        return false;
                     }

                     PlayerValidationTracker var49 = Prestige.i;
                     Object[] var23 = new Object[]{var10, var4};
                     PlayerValidationTracker var22 = var49;
                     var28 = ((byte)((var22.aReturningBoolean(var23)) ? 1 : 0));
                  }

                  int var43 = var8;
                  byte var42 = var28;
                  byte var30 = var42;
                  byte var29 = var42;
                  if (var43 != 0) {
                     byte var44 = var29;
                     if (var44 == 0) {
                        return false;
                     }

                     var30 = 1;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var30);
               }
            }
         }

         byte var38 = 0;
         var26 = var38;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var26);
   }

   private BlockHitResult aReturningBlockHitResult(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 3050433557292L ^ var2;
      long var4 = var2 ^ 120691892918683L;
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      Vec3d var6 = var11.getEyePos();
      RotationManager var10000 = Prestige.o;
      Object[] var13 = new Object[0];
      RotationManager var12 = var10000;
      Rotation var7 = var12.bReturningdx_C0210(var13);
      Rotation var37 = var7;
      Vec3d var36;
      if (var37 != null) {
         MinecraftClient var14 = b;
         ClientPlayerEntity var40 = var14.player;
         Object[] var16 = new Object[0];
         Rotation var15 = var7;
         float var10001 = var15.bReturningFloat(var16);
         Object[] var18 = new Object[0];
         Rotation var17 = var7;
         float var21 = var17.aReturningFloat(var18);
         float var20 = var10001;
         ClientPlayerEntity var19 = var40;
         Vec3d var38 = var19.getRotationVector(var20, var21);
         var36 = var38;
      } else {
         MinecraftClient var23 = b;
         float var25 = 1.0F;
         ClientPlayerEntity var24 = var23.player;
         var36 = var24.getRotationVec(var25);
      }

      Vec3d var8 = var36;
      Object[] var26 = new Object[]{var4};
      double var28 = ItemUseUtil.bReturningFloat(var26);
      Vec3d var27 = var8;
      Vec3d var31 = var27.multiply(var28);
      Vec3d var30 = var6;
      Vec3d var9 = var30.add(var31);
      MinecraftClient var32 = b;
      ClientWorld var41 = var32.world;
      MinecraftClient var33 = b;
      RaycastContext var35 = new RaycastContext(var6, var9, ShapeType.OUTLINE, FluidHandling.NONE, var33.player);
      ClientWorld var34 = var41;
      return var34.raycast(var35);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(65520512290063L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -6207390615667152588L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)169L,
            (byte)43482L,
            (byte)11131627L,
            (byte)2849696543L,
            (byte)729522315147L,
            (byte)186757712677648L,
            (byte)47809974445478121L,
            (byte)-6207390615667152588L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 43;
            yield var16;
         }
         case 2 -> {
            byte var17 = 14;
            yield var17;
         }
         case 3 -> {
            byte var18 = 30;
            yield var18;
         }
         case 4 -> {
            byte var19 = 46;
            yield var19;
         }
         case 5 -> {
            byte var20 = 35;
            yield var20;
         }
         case 6 -> {
            byte var21 = 44;
            yield var21;
         }
         case 7 -> {
            byte var22 = 32;
            yield var22;
         }
         case 8 -> {
            byte var23 = 15;
            yield var23;
         }
         case 9 -> {
            byte var24 = 53;
            yield var24;
         }
         case 10 -> {
            byte var25 = 27;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 9;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 52;
            yield var29;
         }
         case 15 -> {
            byte var30 = 63;
            yield var30;
         }
         case 16 -> {
            byte var31 = 50;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 19;
            yield var35;
         }
         case 21 -> {
            byte var36 = 61;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 7;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 23;
            yield var40;
         }
         case 26 -> {
            byte var41 = 28;
            yield var41;
         }
         case 27 -> {
            byte var42 = 59;
            yield var42;
         }
         case 28 -> {
            byte var43 = 47;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 60;
            yield var45;
         }
         case 31 -> {
            byte var46 = 17;
            yield var46;
         }
         case 32 -> {
            byte var47 = 25;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 11;
            yield var49;
         }
         case 35 -> {
            byte var50 = 45;
            yield var50;
         }
         case 36 -> {
            byte var51 = 41;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 55;
            yield var53;
         }
         case 39 -> {
            byte var54 = 51;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 26;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 16;
            yield var59;
         }
         case 45 -> {
            byte var60 = 56;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 24;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 13;
            yield var66;
         }
         case 52 -> {
            byte var67 = 40;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 12;
            yield var69;
         }
         case 55 -> {
            byte var70 = 10;
            yield var70;
         }
         case 56 -> {
            byte var71 = 37;
            yield var71;
         }
         case 57 -> {
            byte var72 = 8;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 22;
            yield var75;
         }
         case 61 -> {
            byte var76 = 20;
            yield var76;
         }
         case 62 -> {
            byte var77 = 54;
            yield var77;
         }
         default -> 58;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "\u007fZvA=/\u007fZa\u001d1 e\u0011a\u000315b`0\\ibrSc\u001c#\u0019#\u000b2";
      m[1] = "1\u000e@\u0013sQ'\u000eEI`F0EFOlR!\u0002QX'@\u0010";
      m[2] = int.class;
      n[2] = "java/lang/Integer";
      m[3] = "hE?\u007f\u0003\u001chE(#\u000f\u0013r\u000e(=\u000f\u0006u\u007fx`^";
      m[4] = "#+T\u0003,3#+C_ <9`CA )>\u0011\u0013\u001ct";
      m[5] = "rX\u001fAl\u0004rX\b\u001d`\u000bh\u0013\b\u0003`\u001eobXV7X";
      m[6] = "j-0$77|-5~$ kf6x(4z!!oc\"B";
      m[7] = " @_3+\u0003U`T<:L4n_7>\u0016@";
      m[8] = boolean.class;
      n[8] = "java/lang/Boolean";
      m[9] = "G|5ff\tG|\":j\u0006]7\"$j\u0013ZFu{<";
      m[10] = ":7:=\\F,7?gOQ;|<aCE*;+v\bU2";
      m[11] = ":\u0007:..iO'1!?&.):*;|Z";
      m[12] = "ge]j\u007frljL%\u001c\u007fygCN)}ht_b>p";
      m[13] = "\u000bh\u0011U@x~H\u001aZQ7\u001fF\u0011QUmk";
      m[14] = "y!\u0011\u001c[Xy!\u0006@WWcj\u0006^WBd\u001bW\u0001\u000f";
      m[15] = "\u001d:o\u0001V8\u001d:x]Z7\u0007qxCZ\"\u0000\u0000-\u001c\u0003";
      m[16] = "\u001a:hA\n/\f:m\u001b\u00198\u001bqn\u001d\u0015,\n6y\n^;\u0007";
      m[17] = "\f&Lw[sy\u0006GxJ<\u0018\bLsNfl";
      m[18] = "F4\u0014lyXF4\u00030uW\\\u007f\u0003.uB[\u000eWv\"";
      m[19] = "& 3\u001a\u00188S\u00008\u0015\tw2\u000e3\u001e\r-F";
      m[20] = "O\u001b0\u0016pUO\u001b'J|ZUP'T|OR!u\n+\u0004";
      m[21] = "\u001co\\\u001e.G\u001coKB\"H\u0006$K\\\"]\u0001U\u001b\u0000w";
      m[22] = "\u0002\u001b\u00100lU\u0014\u001b\u0015j\u007fB\u0003P\u0016lsV\u0012\u0017\u0001{8F\n\u0017\u0003pb\u000b6\f\u0003mbL\u0001\u001b";
      m[23] = long.class;
      n[23] = "java/lang/Long";
      m[24] = "\n\u000bL\u00036\u0018\n\u000b[_:\u0017\u0010@[A:\u0002\u00171\t\u001abH";
      m[25] = ":2(X\n71=9\u0017f4??;XJ";
      m[26] = "\u001fY\u0011xDS\tY\u0014\"WD\u001e\u0012\u0017$[P\u000fU\u00003\u0010G=";
      m[27] = "&5~Ni\u0016-:o\u0001\b\u0018&1k[";
      m[28] = "\u0005z\u000bk\u00162pZ\u0000d\u0007}\u0011T\u000bo\u0003'e";
      m[29] = ">-O\u0014gq>-XHk~$fXVkk#\u0017\n\u0002:*";
      m[30] = "b\r\u0017'\u0017wb\r\u0000{\u001bxxF\u0000e\u001bm\u007f7R>C,";
      m[31] = "\bQ\t\te(\u0016Y\u0013F\u00188\u0016";
      m[32] = "\u0013\"Ic)0\u0005\"L9:'\u0012iO?63\u0003.X(}!\u0011";
      m[33] = "\\c\u000eb\u0000\u007f)C\u0005m\u00110HM\u000ef\u0015j<";
      m[34] = "}V\u0002Lj7kV\u0007\u0016y |\u001d\u0004\u0010u4mZ\u0013\u0007>!V";
      m[35] = "\u0011k\u001eAd\fdK\u0015NuC\u0005E\u001eEq\u0019q";
      m[36] = "BC$=\u0003.BC3a\u000f!X\b3\u007f\u000f4_yc*Xq";
      m[37] = "=4[\u0000\"^=4L\\.Q'\u007fLB.D \u000e\u001e\u001cv\u0000";
      m[38] = "HL!Yj#HL6\u0005f,R\u00076\u001bf9UvdD7s";
      m[39] = "yha@1\u0002yhv\u001c=\rc#v\u0002=\u0018dR'[jZ";
      m[40] = " y\u0015\u0017@\u001c+v\u0004X=\u00048q\r\u0011";
      m[41] = ":&l\u0019\u0016pO\u0006g\u0016\u0007?.\bl\u001d\u0003eZ";
      m[42] = void.class;
      n[42] = "java/lang/Void";
      m[43] = "\u0014%Q\u0013w\u0019\u0014%FO{\u0016\u000enFQ{\u0003\t\u001f\u0017\t)";
      m[44] = float.class;
      n[44] = "java/lang/Float";
      m[45] = "e\bq9<\u0004s\btc/\u0013dCwe#\u0007u\u0004`rh\u0010y";
      m[46] = "?\u0014B!\u001d7J4I.\fx+:B%\b\"_";
      m[47] = "\u0003\u0011=E`j\u0003\u0011*\u0019le\u0019Z*\u0007lp\u001e+zR8:";
      m[48] = "x<b\u0006r\u0000\r\u001ci\tcOl\u0012b\u0002g\u0015\u0018";
      m[49] = "g !\u000f>\n\u0012\u0000*\u0000/Es\u000e!\u000b+\u001f\u0007";
      m[50] = "<uLR,)IUG]=f([LV9<\\";
      m[51] = double.class;
      n[51] = "java/lang/Double";
      m[52] = "Bj\"rWYBj5.[VX!50[C_Pee\u000f\t\bl:=ICs<oj\n";
      m[53] = "z7@Hq\u001cz7W\u0014}\u0013`|W\n}\u0006g\r\u0007_)L01X\u0007o\u0006K`\u0000T";
      m[54] = "Qyzt\u0005\u001cQ&*\f\u0007\r\u0007|-[PWQ\"A7\bW\u0012t17W\u0007";
      m[55] = "TI`3\u0006eXRp5c8:Ege\f0^Zuw\u001d";
      m[56] = "l\u0010_qH\u0007s\u0002M`!\n\t\fRn\u001cYl\u0012Qa_c4\u0003Xu\u001f\b6\u0005Y.!";
      m[57] = "T\u0001[\u001b:,X\u001aK\u001d_\u007f:\u000eNXgjJ\u0018VXn";
      m[58] = "\"[r\u0017\u001f\u000e#TnN}\u0001\u001e\u0015k\u0004@W{\u000bh\u000b\u0003m#\u001aa\u001fC\u0006!\u001c`D}";
      m[59] = "A\u0014\u0005\u0005g<K\u0004E\u000e\u001fl\u001a\u0017\u001d\u001bH;DGDw!gA\u0014\t\u001egp\u001a\u0002";
      m[60] = "&\u001fA nD,\u000f\u0001+\u0016\u001fq\r]5z-%L\u0003c\u0016Gb\u001cVl}Ed\u001d\rR";
      m[61] = "\u000fsNK\u00108\u000e|\u001eO+>\u0018a*QQ0\u0013rqVGa\u0005\u007f\u0018\u0016Z:\u000b\u001d";
      m[62] = ";\nk\u0014!X:\u0005wMCR\u0007Dr\u0007~\u0001bZq\b=;kDv\u001d.Z6\\+\u0016C";
      m[63] = "HUC\u0007lE\u001eA\u0002Q\u0011L\"@[\u0019,\u001cG^X\u0016o&\\_\u0004\u000f(\u0018LV\u0007T\u0011";
      m[64] = "eHhb\\\rkE5\u0002Ogh\u0012&?\u001c\u0002v\u0011)|&\u001bx\u001e22AY~\u001c<\u0002";
      m[65] = "V,5H-CWk9Jn'\u0001u2MypV+b\u0014$'V,5H-CWk9Jn";
      m[66] = "4\u0013H(\u0001Xs\u0016G?\u00177cJZ5\u0000`4\u0010\u000bal\u000e5TN<\u0003I0[Y*";
      m[67] = " gzSx5*!dMH*&ccL$\u0018p$>\u0014qO6u3\u001a% 0&oGH";
      m[68] = "?\u0005\r&Cw5\u0015M-;'d\u0006\u00158lp;ZIT\u0000#g\u0007\u0018k\u000b5oT";
      m[69] = "\f\u0018$Gi_\u0007\u001f*\u000f\u0007DZ\u0005#\u0010kv\u000eF|G<!\f\u0018x\u000fkQ\fG(w";
      m[70] = "%_&\u0004\\&pT%L$q\u001aN0\u0006\u0019!\u007fP3\tZ\u001b'A:\u001d\u001ap%G;F$";
      m[71] = "LV!.\u0010cZN!'jz*X9fW)OF:i\u0014\u0013\u0017W3}Tx\u0015Q2&j";
      m[72] = "z#ze5#p3:nMs! b{\u001a$\u007fs;\u0017|o!<jy=a#}";
      m[73] = "5r\u000b\u001dE\u0002p|\tH8\u001b o\u0016DT)t,I\u0013\u0002~5n\tGF\u00013p\u0011@8";
      m[74] = "=G\u0014Q\u0010p7WTZh fD\fO?w9\u0019W#\u00017w\u0012V[\f$x\u0017";
      m[75] = "i6pD8<4.-OU3d*wB\u0002`5~+.9,f-~Od4;&";
      m[76] = "V\u0018g\f\bT\\^y\u00128KP\u001c~\u0013Ty\u0003X!E8N\u0006\u001b/O_L\u0003\fyt";
      m[77] = ",sZ4Fa'eRg/0vt\\4xg&!\u0004XA`(xI:\u0010.zh";
      m[78] = "U\u000fy\"H\u001a\b\u0017$)%\u0015X\u0013~$rF\tF*HI\nZ\u0014w)\u0014\u0012\u0007\u001f";
      m[79] = "7\u0000b\u0006Jx=F|\u0018zg1\u0004{\u0019\u0016UaF Gz\u007f?Df\u0010\u0000h \u0007v~\u0007a`\u0005u\u0004\u0010~#\u0015\u001b\u0003\u00102m\u0015t\u0005Cn0x";
      m[80] = "%K\t%-)t\u0005[5\\.&\tV#0\u001crI\rx\\v5\u0018]z7t3\u0019\u0006D";
      m[81] = "\u0005K}BB\u0003\u000f\rc\\r\u001c\u0003Od]\u001e.P\n=\u0007rD\u0010^o\u0004\u0019F\u0016_4:";
      m[82] = "\u007fTVr\u000b\u001b#\rP*5\u0007}Z[%bY#\u0007\u0001IQUmR\u000e6J\f~T";
      m[83] = "2*j\u0001\u001b\u0012<'7a\u000bxwy-\u001d\\\u00043sjPa";
      m[84] = "6\u00169Vtu4\u0013.\u0000Ow;Q\"\u0000#Ei\u001czVOvj\\'V0m3O!g";
      m[85] = "F\u001eMk^qD\u0012T}e,LbS5\bsP\u001aT:\u000es\"\u0006Mx\np\u0018\u0004Aa\u001cK";
      m[86] = "P\tU#\u0015!NB\u000fr%5W\u001eR$L9n\u0010R4H_\r\u0007[\"\u001b4\u000f\u0001Zy%";
      m[87] = "\u0015C1@Eq\u001bNl T\u001bP\u0010v\\\u0002g\u0014\u001a1\u0011?";
      m[88] = "d\u0018\u00066/l2\fG`Ra\u000e\r\u001e(o5k\u0013\u001d',\u000f3\u0002\u00143ld1\u0004\u0015hR";
      m[89] = "\u001eZ]\f\tP\u0019XG\u00104C\u007f\u0002\r\u0004\fX\u0007\u0005\u0002\u0002\f*";
      m[90] = "\u0018Es\u001b1I\u0019JoBSC$\u000bj\bn\u0010A\u0015i\u0007-*\u0019\u0004`\u0013mA\u001b\u0002aHS";
      m[91] = "\u001f'9#\\.\u00157y($~D$!=s)\u001asyQOh\\1u+E.B/";
      m[92] = "tY\u0010+\u0006XxB\u0000-c\u0003\u001aZ\u001eh\r\u0019y\f\n)[";
      m[93] = "Mz?\b\u001e$]s<S's3e`\u001e\u001a V{c\u0011Y\u001aNw;\u0013I`Yhx\u0003'";
      m[94] = "\u00070}\fVd\rvc\u0012f{\u00014d\u0013\nIQx>Dfc\u000fty\u001a\u001ct\u00107it\u001bt\\yi\u001b\u001d'\u0000$\u0004";
      m[95] = "Q0\u0017ME\u0016[v\tSu\tW4\u000eR\u0019;\u0004pR\nu\f\u00013_\u000e\u0012\u000e\u0004$\t5";
      m[96] = "\b+C4L8\t$_m.24$\\>\u0010\"M*]9Q[\u0004uTiW\"\ntS(.";
      m[97] = "[\u001bA\u0018Q\u001aK\u0012BChN%\u0004\u001e\u000eU\u001e@\u001a\u001d\u0001\u0016$X\u0016E\u0003\u0006^O\t\u0006\u0013h";
      m[98] = "_6.Y\u001a\n^92\u0000x\u0000cx7JES\u0006f4E\u0006iXh7\n\u0016\u0017So9Bx";
      m[99] = "71Cr\u001fA:\"Lw!\\34S.Mngw\fu\u001b9!1N'G[d&V;!\u0002?/\u0003'_\t8!KI";
      m[100] = "\u0005i0\u000b\u00131\u0003:lV~;\u0015\u007f`]\u0012\tA;9\u000b~#\u001231W\u0011%Aol:\u00034H2mU\u0005g\u0014o\u0000";
      m[101] = "QT~c?a\u0017\u0014)nOaF\u0010%4#S\u0016PzlO~ES#h&\u007fJ\u0003'S";
      m[102] = "fKJ]\u000bU3@I\u0015s\u0002YZ\\_NR<D_P\rh$H\u0007R\u001d\u00123WDBs";
      m[103] = "h<\u0006s\u0003/noZ.n%x*V%\u0002\u0017,n\f{n2k-[!\u0011=q,DB\u0013*%g[-\u0015yy:6";
      m[104] = ",veM7u!ejH\th(su\u0011eZz2/H1\r+~h\rn4uouH\t";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1956128423505552L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1956128423505552L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1956128423505552L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 220;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 237;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 198;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 106;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 170;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 164;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 220;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 237;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 198;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eL_C0239",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eL" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
