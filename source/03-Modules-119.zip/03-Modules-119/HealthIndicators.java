package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PlayerHealthIndicatorEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Formatting;

public class HealthIndicators extends Module {
   private static final long k = 85775749265329L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[35];
   private static final String[] p = new String[35];

   @EventListener
   public void a(PlayerHealthIndicatorEvent var1) {
      long var10001 = 92444066228059L ^ 48199223555186L;
      var10001 = 92444066228059L ^ 15508228246313L;
      Object[] var14 = new Object[0];
      PlayerHealthIndicatorEvent var13 = var1;
      Object[] var16 = new Object[]{var13.aReturningPlayerEntity(var14), 140486469980969L};
      HealthIndicators var15 = this;
      double var17 = var15.bReturningFloat(var16);
      float var8 = (float)Math.ceil(var17);
      Object[] var10004 = new Object[]{null, 98994799062130L};
      var10004[0] = var8;
      Object[] var20 = var10004;
      HealthIndicators var19 = this;
      Formatting var21 = var19.aReturningVoid(var20);
      String var10000 = String.valueOf(var21);
      Formatting var22 = Formatting.RESET;
      String var10 = String.valueOf(var22);
      float var11 = var8;
      String var12 = var10000;
      String var9 = " | " + var12 + var11 + var10 + " | ";
      Object[] var24 = new Object[]{var9};
      PlayerHealthIndicatorEvent var23 = var1;
      var23.bReturningVoid(var24);
      Object[] var26 = new Object[0];
      PlayerHealthIndicatorEvent var25 = var1;
      var25.aReturningVoid(var26);
   }

   private Formatting a(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 85775749265329L ^ var3;
      int var5 = Event.bReturningInt();
      float var23;
      int var22 = (var23 = var2 - 5.0F) == 0.0F ? 0 : (var23 < 0.0F ? -1 : 1);
      int var13 = var5;
      int var12 = var22;
      int var7 = var12;
      int var6 = var12;
      if (var13 == 0) {
         int var14 = var6;
         if (var14 <= 0) {
            return Formatting.RED;
         }

         float var24;
         var7 = (var24 = var2 - 10.0F) == 0.0F ? 0 : (var24 < 0.0F ? -1 : 1);
      }

      int var16 = var5;
      int var15 = var7;
      int var9 = var15;
      int var8 = var15;
      if (var16 == 0) {
         int var17 = var8;
         if (var17 <= 0) {
            return Formatting.GOLD;
         }

         float var25;
         var9 = (var25 = var2 - 15.0F) == 0.0F ? 0 : (var25 < 0.0F ? -1 : 1);
      }

      int var19 = var5;
      int var18 = var9;
      int var11 = var18;
      int var10 = var18;
      if (var19 == 0) {
         int var20 = var10;
         if (var20 <= 0) {
            return Formatting.YELLOW;
         }

         float var26;
         var11 = (var26 = var2 - 20.0F) == 0.0F ? 0 : (var26 < 0.0F ? -1 : 1);
      }

      int var21 = var11;
      return var21 <= 0 ? Formatting.GREEN : Formatting.DARK_GREEN;
   }

   private float bReturningFloat(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 85775749265329L ^ var2;
      PlayerEntity var5 = var4;
      float var7 = var5.getHealth();
      PlayerEntity var6 = var4;
      return var7 + var6.getAbsorptionAmount();
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(26844748540821L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      String var6 = "5½)åaêË\u009e|sá\u009eB\u001e©ô\u0010~Atg\u0006b§¾\u009d\u000fåK¿\u008bÑÙ";
      int var8 = "5½)åaêË\u009e|sá\u009eB\u001e©ô\u0010~Atg\u0006b§¾\u009d\u000fåK¿\u008bÑÙ".length();
      char var5 = 16;
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[2];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 842;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eM", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eM_C0241",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eM" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 14;
            yield var16;
         }
         case 2 -> {
            byte var17 = 26;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 31;
            yield var20;
         }
         case 6 -> {
            byte var21 = 48;
            yield var21;
         }
         case 7 -> {
            byte var22 = 41;
            yield var22;
         }
         case 8 -> {
            byte var23 = 62;
            yield var23;
         }
         case 9 -> {
            byte var24 = 15;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 43;
            yield var26;
         }
         case 12 -> {
            byte var27 = 23;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 22;
            yield var30;
         }
         case 16 -> {
            byte var31 = 34;
            yield var31;
         }
         case 17 -> {
            byte var32 = 39;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 63;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 52;
            yield var36;
         }
         case 22 -> {
            byte var37 = 32;
            yield var37;
         }
         case 23 -> {
            byte var38 = 18;
            yield var38;
         }
         case 24 -> {
            byte var39 = 60;
            yield var39;
         }
         case 25 -> {
            byte var40 = 3;
            yield var40;
         }
         case 26 -> {
            byte var41 = 29;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 51;
            yield var45;
         }
         case 31 -> {
            byte var46 = 38;
            yield var46;
         }
         case 32 -> {
            byte var47 = 47;
            yield var47;
         }
         case 33 -> {
            byte var48 = 53;
            yield var48;
         }
         case 34 -> {
            byte var49 = 4;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 19;
            yield var51;
         }
         case 37 -> {
            byte var52 = 28;
            yield var52;
         }
         case 38 -> {
            byte var53 = 57;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 1;
            yield var55;
         }
         case 41 -> {
            byte var56 = 27;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 9;
            yield var59;
         }
         case 45 -> {
            byte var60 = 2;
            yield var60;
         }
         case 46 -> {
            byte var61 = 54;
            yield var61;
         }
         case 47 -> {
            byte var62 = 7;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 42;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 46;
            yield var67;
         }
         case 53 -> {
            byte var68 = 40;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 8;
            yield var70;
         }
         case 56 -> {
            byte var71 = 16;
            yield var71;
         }
         case 57 -> {
            byte var72 = 13;
            yield var72;
         }
         case 58 -> {
            byte var73 = 10;
            yield var73;
         }
         case 59 -> {
            byte var74 = 58;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 44;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "4\u001aTO\r\u001e4\u001aC\u0013\u0001\u0011.QC\r\u0001\u0004) \u0011ST";
      o[1] = "Y\u0005\fwAuO\u0005\t-RbXN\n+^vI\t\u001d<\u0015dx";
      o[2] = int.class;
      p[2] = "java/lang/Integer";
      o[3] = "6\u001bYgIk \u001b\\=Z|7P_;Vh&\u0017H,\u001d~\u001f";
      o[4] = "\u007f,<*T\u001ft#-e7\u0012a.\"\u000e\u0002\u0010p=>\"\u0015\u001d";
      o[5] = "%kAS[j.dP\u001c8g;b";
      o[6] = double.class;
      p[6] = "java/lang/Double";
      o[7] = "1EJ\u001a\u0014-'EO@\u0007:0\u000eLF\u000b.!I[Q@?>";
      o[8] = "\u0017ZQ\b\u000eNbzZ\u0007\u001f\u0001\u0003tQ\f\u001b[w";
      o[9] = "\u0016S\u000bt*]\u0016S\u001c(&R\f\u0018\u001c6&G\u000biNlr\u0003";
      o[10] = "\u0017E?\u001ccIbe4\u0013r\u0006\u0003k?\u0018v\\w";
      o[11] = float.class;
      p[11] = "java/lang/Float";
      o[12] = "y?M&+Fr0\\iV^a7U ";
      o[13] = "NNC\u0005`tEARJ\u0001zNJV\u0010";
      o[14] = "\u0002\u001b3!\u000b8w;8.\u001aw\u001653%\u001e-b";
      o[15] = void.class;
      p[15] = "java/lang/Void";
      o[16] = "Hlvz*:=L}u;u\\Bv~?/(";
      o[17] = ", \u001b|\u0016eY\u0000\u0010s\u0007*8\u000e\u001bx\u0003pL";
      o[18] = "ca%q0\u000e3`#\u0016&_4y3Aq\u0006f\"_,4D>eo|5B";
      o[19] = "fXc\u0011tu1\u0002u\u0015Mm_Yp^|}b\u0004a\u000f1\u0007";
      o[20] = "h1\u0013d\"A80\u0015\u00034\u0010?)\u0005TcIlti9&\u000b55Yi'\r";
      o[21] = "r?V\u0004(6\">Pc>g%'@4i>v{,Y,|/;\u001c\t-z";
      o[22] = "u\u0007GOP1<\\X\u0013n5#\u0002@*Rn>\u0005\u001cI\u0016.4\u001c$\u0016^.([GR\u001e$1c";
      o[23] = "3zxAN'bf(\u001aw}`y)\u001c\u001bO3=wDw'pn&G\u0015%6;4{";
      o[24] = "e\u000fz\tu\u00015\u000e|ncP2\u0017l94\t`K\u0000TqK8\u000b0\u0004pM";
      o[25] = "ql{%H`)uq.6oMu*9My<}~\u007fN\u0006sa*\u007f\u000f9\"}z$6";
      o[26] = "+E\fK)e+A\f\u001bGq\u0011L_V<d`D\u000b\u0010?\u001b.Z\u0005E{y,\u001cPWG";
      o[27] = "B\u0011WB\u000e\u0007\u0012\u0010Q%\u0018V\u0015\tArO\u000fEQ-\u001f\nM\u001f\u0015\u001dO\u000bK";
      o[28] = "\u0011\u0001yS\u0019|A\u0000\u007f4\u000f-F\u0019ocXt\u0015@\u0003\u000e\u001d6L\u00053^\u001c0";
      o[29] = "\u0012U@[LE\u0013@N\\!\u0002KK^Uf\u0012\"\u001eIEM\u0003YNFE@|\u0012U@[LE\u0013@N\\!";
      o[30] = "\u0016HQ>%>\u0016LQnK),\u0010B&tpAGY?w@\u0016[J`{-A@ScK";
      o[31] = "\u001es>,6\u0011Oonw\u000fKMpoqcy\u001e44,\u000f\u0011]g`*m\u0013\u001b2r\u0016";
      o[32] = "9O5\"2tn\u0015#&\u000bo\u0000\u001cx pyq\u0014,fs\u0006i\u0016,=;ff\f\"$\u000b";
      o[33] = "R$R\u001a\u0007pR RJigh-\u0001\u0007\u0012q\u0019%UA\u0011\u000eR:J\u001c\u0011>\u0002;L{";
      o[34] = "o9\n\b1}7 \u0000\u0003OqS [\u00144d\"(\u000fR7\u001b:*\u000f\t\u007f{50\u0001\u0010O";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(947453024907306L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(947453024907306L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(947453024907306L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 102;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 233;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 106;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 225;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 109;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 242;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 102;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 233;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 106;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eM_C0241",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eM" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
