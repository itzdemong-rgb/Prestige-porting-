package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.api.util.MotionPredictor;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.util.MotionPredictionMode;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Matrix4f;
import org.joml.Vector3d;

public class HitEffect extends Module {
   private IntSetting a;
   private IntSetting c;
   private BooleanSetting d;
   private BooleanSetting e;
   private static ManagedGlTexture f;
   private static ManagedGlTexture g;
   private static final long h;
   private ArrayList i;
   private ElapsedTimer j;
   private static final long k = 25175650421003L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final long[] r;
   private static final Long[] s;
   private static final Map t;
   private static final Object[] u = new Object[160];
   private static final String[] v = new String[160];
   private static volatile MethodHandle bindingCache1;

   public HitEffect() {
      super();
      long var10001 = 53148211388440L ^ 89455980353329L;

      this.i = new ArrayList();
      this.j = new ElapsedTimer(106698256430889L);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 97434553232679L;
      int var10000 = Event.bReturningInt();
      ModuleManager var9 = Prestige.d;
      List var10 = var9.aReturningVoid();
      Iterator var7 = var10.iterator();
      int var6 = var10000;

      int var39;
      do {
         Iterator var11 = var7;
         boolean var29 = var11.hasNext();
         if (!var29) {
            break;
         }

         label30: {
            Module var28;
            label38: {
               Iterator var12 = var7;
               Module var8 = (Module)var12.next();
               Class var40 = var8.getClass();
               Class<CrystalOptimizer> var14 = CrystalOptimizer.class;
               Class var13 = var40;
               boolean var41 = var13.equals(var14);
               int var31 = var6;
               boolean var30 = var41;
               boolean var27 = var30;
               boolean var24 = var30;
               if (var31 == 0) {
                  boolean var32 = var24;
                  if (!var32) {
                     break label30;
                  }

                  int var34 = var6;
                  Module var33 = var8;
                  var28 = var33;
                  Module var25 = var33;
                  if (var34 != 0) {
                     break label38;
                  }

                  Module var35 = var25;
                  Module var26 = var35;
                  Module var17 = var26;
                  boolean var36 = var17.aReturningBoolean();
                  var27 = var36;
               }

               boolean var37 = var27;
               if (!var37) {
                  break label30;
               }

               Object[] var20 = new Object[]{var4};
               Module var19 = var8;
               var19.aReturningVoid(var20);
               Module var38 = var8;
               var28 = var38;
            }

            Object[] var23 = new Object[]{var4};
            Module var22 = var28;
            var22.aReturningVoid(var23);
         }

         var39 = var6;
      } while (var39 == 0);
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 129501747723698L ^ 100828096759432L;
      var10001 = 129501747723698L ^ 2723890048991L;
      int var10000 = Event.cReturningInt();
      Object[] var12 = new Object[0];
      AttackEntityEvent var11 = var1;
      Entity var9 = var11.aReturningEntity(var12);
      int var8 = var10000;

      int var34;
      do {
         IntSetting var13 = this.a;
         Integer var14 = (Integer)var13.aReturningObject();
         int var29 = var14;
         int var28 = var10;
         if (var28 >= var29) {
            break;
         }

         ArrayList var15 = this.i;
         var10000 = var15.size();
         int var31 = var8;
         int var30 = var10000;
         int var26 = var30;
         if (var31 != 0) {
            IntSetting var16 = this.c;
            Integer var17 = (Integer)var16.aReturningObject();
            int var33 = var17 * 20;
            int var32 = var26;
            if (var32 <= var33) {
               ArrayList var36 = this.i;
               Object[] var20 = new Object[]{var9, 131657085751917L};
               Vec3d var10003 = RaycastUtil.aReturningVec3d(var20);
               Entity var21 = var9;
               double var10006 = var21.getX() + (Math.random() - 0.5) * 0.5;
               Entity var22 = var9;
               double var10007 = var22.getY() + Math.random() * 1.0 + 0.5;
               Entity var23 = var9;
               MotionPredictor var25 = new MotionPredictor(
                  var10003, new Vec3d(var10006, var10007, var23.getZ() + (Math.random() - 0.5) * 0.5), MotionPredictionMode.LEGACY, 51076410620730L
               );
               ArrayList var24 = var36;
               boolean var27 = var24.add(var25);
            }
         }

         var10++;
         var34 = var8;
      } while (var34 != 0);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 94531997747266L ^ 129120846006083L;
      var10001 = 94531997747266L ^ 92951119483549L;
      var10001 = 94531997747266L ^ 126498170216514L;
      var10001 = 94531997747266L ^ 96312294746736L;
      var10001 = 94531997747266L ^ 78954355639676L;
      int var14 = Event.bReturningInt();
      ArrayList var22 = this.i;
      short var10000 = ((short)((var22.isEmpty()) ? 1 : 0));
      int var54 = var14;
      boolean var53 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var50 = var53;
      boolean var49 = var53;
      if (var54 == 0) {
         boolean var55 = var49;
         if (var55) {
            ElapsedTimer var65 = this.j;
            Object[] var25 = new Object[]{42835128969216L};
            ElapsedTimer var24 = var65;
            var24.aReturningVoid(var25);
            return;
         }

         BooleanSetting var27 = this.d;
         Boolean var28 = (Boolean)var27.aReturningObject();
         var50 = var28;
      }

      boolean var15 = var50;
      var10000 = 11684;
      ElapsedTimer var70 = this.j;
      Object[] var30 = new Object[]{35831705079553L};
      ElapsedTimer var29 = var70;
      float var71 = var29.aReturningFloat(var30);
      float var32 = 20.0F;
      float var31 = var71;
      long var16 = (long)Math.min(var31, var32);
      var10001 = 574469362580522253L;
      ArrayList var52;
      while (true) {
         long var73;
         int var56 = (var73 = var18 - var16) == 0L ? 0 : (var73 < 0L ? -1 : 1);
         if (var56 <= 0) {
            int var58 = var14;
            ArrayList var57 = this.i;
            var52 = var57;
            ArrayList var51 = var57;
            if (var58 != 0) {
               break;
            }

            ArrayList var33 = var51;
            Iterator var20 = var33.iterator();

            label37: {
               int var61;
               do {
                  Iterator var34 = var20;
                  boolean var59 = var34.hasNext();
                  if (!var59) {
                     break;
                  }

                  Iterator var35 = var20;
                  MotionPredictor var21 = (MotionPredictor)var35.next();
                  Object[] var10004 = new Object[]{null, 20027641630014L};
                  var10004[0] = var15;
                  Object[] var37 = var10004;
                  MotionPredictor var36 = var21;
                  var36.aReturningVoid(var37);
                  int var60 = var14;
                  if (var60 != 0) {
                     break label37;
                  }

                  var61 = var14;
               } while (var61 == 0);

               var18++;
            }

            int var62 = var14;
            if (var62 == 0) {
               continue;
            }
         }

         var52 = this.i;
         break;
      }

      Predicate var40 = invokeBinding1(this);
      ArrayList var39 = var52;
      var39.removeIf(var40);
      ElapsedTimer var64 = this.j;
      Object[] var42 = new Object[]{42835128969216L};
      ElapsedTimer var41 = var64;
      var41.aReturningVoid(var42);
      ArrayList var10002 = this.i;
      Object[] var43 = new Object[]{2617886958130L};
      Color var44 = ClientUiUtil.dReturningColor(var43);
      Color var10003 = var44.brighter();
      Object[] var45 = new Object[]{2617886958130L};
      Color var46 = ClientUiUtil.dReturningColor(var45);
      Object[] var48 = new Object[]{var1, var10002, var10003, var46.darker(), 1581291412191L};
      HitEffect var47 = this;
      var47.jReturningVoid(var48);
   }

   public void jReturningVoid(Object[] var1) {
      Render3DEvent var2 = (Render3DEvent)var1[0];
      ArrayList var3 = (ArrayList)var1[1];
      Color var6 = (Color)var1[2];
      Color var7 = (Color)var1[3];
      long var4 = (Long)var1[4];
      var4 = 25175650421003L ^ var4;
      long var8 = var4 ^ 64402430141699L;
      long var10 = var4 ^ 53701149764615L;
      long var12 = var4 ^ 57153883041022L;
      long var14 = var4 ^ 84767820751015L;
      long var16 = var4 ^ 104069747741398L;
      MinecraftClient var31 = b;
      EntityRenderManager var32 = var31.getEntityRenderDispatcher();
      int var10000 = Event.cReturningInt();
      Object[] var33 = new Object[]{var8};
      GameRenderUtil.cReturningVec3d(var33);
      int var18 = var10000;
      ArrayList var34 = new ArrayList(var3);
      Iterator var22 = var34.iterator();

      while (true) {
         Iterator var35 = var22;
         boolean var86 = var35.hasNext();
         if (!var86) {
            break;
         }

         Iterator var36 = var22;
         MotionPredictor var23 = (MotionPredictor)var36.next();
         var21++;
         Object[] var38 = new Object[0];
         MotionPredictor var37 = var23;
         Vec3d var24 = var37.bReturningVec3d(var38);
         Object[] var39 = new Object[]{var10};
         Vec3d var113 = RaycastUtil.bReturningVec3d(var39);
         Vec3d var41 = var24;
         Vec3d var40 = var113;
         double var25 = var40.distanceTo(var41);
         MinecraftClient var42 = b;
         ClientWorld var114 = var42.world;
         Vec3d var43 = var24;
         BlockPos var45 = BlockPos.ofFloored((Position)var43);
         ClientWorld var44 = var114;
         BlockState var46 = var44.getBlockState(var45);
         int var115 = (((var46.isAir()) ? 1 : 0));
         int var88 = var18;
         byte var87 = (byte)var115;
         int var69 = var87;
         byte var68 = var87;
         if (var88 != 0) {
            byte var89 = var68;
            if (var89 == 0) {
               continue;
            }

            short var10001 = 19644;
            long var10002 = 4421425483507736412L ^ var4;
            var69 = var21 % 10;
         }

         int var73;
         int var91 = var18;
         int var90 = var69;
         var73 = var90;
         int var70 = var90;
         label53:
         if (var91 != 0) {
            int var92 = var70;
            if (var92 != 0) {
               double var124;
               var115 = (var124 = var25 - 25.0) == 0.0 ? 0 : (var124 < 0.0 ? -1 : 1);
               int var94 = var18;
               int var93 = var115;
               var73 = var93;
               int var71 = var93;
               if (var94 == 0) {
                  break label53;
               }

               int var95 = var71;
               int var72 = var95;
               int var96 = var72;
               if (var96 > 0) {
                  continue;
               }
            }

            var73 = var21 % 3;
         }

         label46: {
            int var98 = var18;
            int var97 = var73;
            int var75 = var97;
            int var74 = var97;
            if (var98 != 0) {
               int var99 = var74;
               if (var99 != 0) {
                  break label46;
               }

               double var125;
               int var100 = (var125 = var25 - 15.0) == 0.0 ? 0 : (var125 < 0.0 ? -1 : 1);
               var75 = var100;
            }

            int var101 = var75;
            if (var101 > 0) {
               continue;
            }
         }

         IntSetting var53 = this.c;
         Integer var54 = (Integer)var53.aReturningObject();
         float var118 = var54.intValue() * 1000.0F;
         Object[] var10004 = new Object[]{null, var16};
         var10004[0] = var118;
         Object[] var56 = var10004;
         MotionPredictor var55 = var23;
         float var27 = var55.aReturningFloat(var56);
         int var28 = (int)(255.0F * (1.0F - var27));
         byte var119 = 0;
         int var120 = 16325;
         long var10003 = 6232780757627104288L ^ var4;
         int var57 = var28;
         var28 = MathHelper.clamp(var57, 0, 255);
         float var117 = var21 / 5.0F;
         Object[] var10006 = new Object[]{null, null, var6, var7, var12};
         var10006[1] = 0.5F;
         var10006[0] = var117;
         Object[] var60 = var10006;
         Color var29 = aReturningColor(var60);
         Color var61 = var29;
         var120 = var61.getRed();
         Color var62 = var29;
         int var122 = var62.getGreen();
         Color var63 = var29;
         Color var30 = new Color(var120, var122, var63.getBlue(), var28);
         MotionPredictionMode var65 = MotionPredictionMode.POP;
         MotionPredictionMode var64 = var23.g;
         boolean var105 = var64.equals(var65);
         Color var104 = var30;
         MotionPredictor var103 = var23;
         Render3DEvent var102 = var2;
         Render3DEvent var79 = var102;
         MotionPredictor var80 = var103;
         Color var81 = var104;
         Render3DEvent var76 = var102;
         MotionPredictor var77 = var103;
         Color var78 = var104;
         Render3DEvent var82;
         MotionPredictor var83;
         Color var84;
         float var85;
         if (var105) {
            float var109 = 7.0F;
            Color var108 = var78;
            MotionPredictor var107 = var77;
            Render3DEvent var106 = var76;
            var82 = var106;
            var83 = var107;
            var84 = var108;
            var85 = var109;
         } else {
            var85 = 4.5F;
            var84 = var81;
            var83 = var80;
            var82 = var79;
         }

         var10006 = new Object[]{null, null, null, null, var14};
         var10006[3] = var85;
         var10006[2] = var84;
         var10006[1] = var83;
         var10006[0] = var82;
         Object[] var67 = var10006;
         kReturningVoid(var67);
         int var110 = var18;
         if (var110 == 0) {
            break;
         }
      }
   }

   public static void kReturningVoid(Object[] var0) {
      Render3DEvent var6 = (Render3DEvent)var0[0];
      MotionPredictor var1 = (MotionPredictor)var0[1];
      Color var2 = (Color)var0[2];
      float var3 = (Float)var0[3];
      long var4 = (Long)var0[4];
      var4 = 25175650421003L ^ var4;
      long var7 = var4 ^ 108561787569995L;
      long var9 = var4 ^ 48381678168261L;
      long var11 = var4 ^ 101960576794193L;
      int var13 = Event.cReturningInt();
      int var58 = var13;
      ManagedGlTexture var57 = f;
      ManagedGlTexture var53 = var57;
      ManagedGlTexture var52 = var57;
      if (var58 != 0) {
         ManagedGlTexture var59 = var52;
         if (var59 == null) {
            short var10000 = 14431;
            long var10001 = 84400212915454971L ^ var4;
            Object[] var18 = new Object[]{"assets/prestige/particles/glow.png", var11};
            f = TextureLoader.aReturningbT_C0095(var18);
         }

         var53 = g;
      }

      label27: {
         int var61 = var13;
         ManagedGlTexture var60 = var53;
         ManagedGlTexture var55 = var60;
         ManagedGlTexture var54 = var60;
         if (var61 != 0) {
            ManagedGlTexture var62 = var54;
            if (var62 != null) {
               break label27;
            }

            short var67 = 32730;
            long var70 = 6714249562254001279L ^ var4;
            Object[] var21 = new Object[]{"assets/prestige/particles/pop.png", var11};
            ManagedGlTexture var63 = TextureLoader.aReturningbT_C0095(var21);
            var55 = var63;
         }

         g = var55;
      }

      RenderContext var68 = var6.b;
      Vec3d var23 = var1.c;
      double var71 = var23.x;
      Vec3d var24 = var1.c;
      double var10002 = var24.y;
      Vec3d var25 = var1.c;
      double var10003 = var25.z;
      Object[] var10006 = new Object[]{null, null, null, null, var7};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var71;
      var10006[0] = var68;
      Object[] var26 = var10006;
      Vector3d var14 = RenderThreadUtil.aReturningVector3d(var26);
      MotionPredictionMode var28 = MotionPredictionMode.POP;
      MotionPredictionMode var27 = var1.g;
      boolean var64 = var27.equals(var28);
      ManagedGlTexture var56;
      if (var64) {
         ManagedGlTexture var65 = g;
         var56 = var65;
      } else {
         var56 = f;
      }

      ManagedGlTexture var15 = var56;
      Matrix4f var16 = new Matrix4f();
      Vector3d var30 = var14;
      float var72 = (float)var30.x;
      Vector3d var31 = var14;
      float var74 = (float)var31.y;
      Vector3d var32 = var14;
      float var36 = (float)var32.z;
      float var35 = var74;
      float var34 = var72;
      Matrix4f var33 = var16;
      var33.translate(var34, var35, var36);
      float var38 = 0.04F;
      Matrix4f var37 = var16;
      var37.scale(var38);
      RenderContext var39 = var6.b;
      Camera var40 = var39.bo();
      double var41 = -var40.getYaw();
      float var44 = (float)Math.toRadians(var41);
      Matrix4f var43 = var16;
      var43.rotateY(var44);
      RenderContext var45 = var6.b;
      Camera var46 = var45.bo();
      double var47 = var46.getPitch();
      float var50 = (float)Math.toRadians(var47);
      Matrix4f var49 = var16;
      var49.rotateX(var50);
      MeshBufferManager var69 = var6.a;
      RenderContext var73 = var6.b;
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var9};
      var10014[11] = 0.0F;
      var10014[10] = var2;
      var10014[9] = 0.0F;
      var10014[8] = var3;
      var10014[7] = var3;
      var10014[6] = 0.0F;
      var10014[5] = 0.0F;
      var10014[4] = 0.0F;
      var10014[3] = var15;
      var10014[2] = var16;
      var10014[1] = var73;
      var10014[0] = var69;
      Object[] var51 = var10014;
      TexturedRectangleRenderer.mReturningVoid(var51);
   }

   public static Color aReturningColor(Object[] var0) {
      float var5 = (Float)var0[0];
      float var3 = (Float)var0[1];
      Color var4 = (Color)var0[2];
      Color var6 = (Color)var0[3];
      long var1 = (Long)var0[4];
      var1 = 25175650421003L ^ var1;
      long var7 = var1 ^ 97759283928897L;
      int var10000 = Event.bReturningInt();
      Color var10 = Color.BLACK;
      int var9 = var10000;
      int var23 = var9;
      Color var22 = var4;
      Color var20 = var22;
      Color var17 = var22;
      if (var23 == 0) {
         Color var24 = var17;
         label23:
         if (var24 != null) {
            int var26 = var9;
            Color var25 = var6;
            Color var21 = var25;
            Color var18 = var25;
            if (var26 == 0) {
               Color var27 = var18;
               Color var19 = var27;
               Color var28 = var19;
               if (var28 == null) {
                  break label23;
               }

               double var14 = System.currentTimeMillis() / 1.0E8 * var3 * 400000.0 + var5 * 0.55F;
               double var10002 = (Math.sin(var14) + 1.0) * 0.5;
               Object[] var10005 = new Object[]{null, null, null, var7};
               var10005[2] = var10002;
               var10005[1] = var6;
               var10005[0] = var4;
               Object[] var16 = var10005;
               var10 = bReturningColor(var16);
               var21 = var10;
            }

            return var21;
         }

         var20 = var10;
      }

      return var20;
   }

   public static Color bReturningColor(Object[] var0) {
      int var7;
      int var10;
      int var11;
      int var12;
      int var47;
      long var91;
      label66: {
         label65: {
            Color var6 = (Color)var0[0];
            Color var1 = (Color)var0[1];
            double var2 = (Double)var0[2];
            var91 = (Long)var0[3];
            var91 = 25175650421003L ^ var91;
            int var10000 = Event.bReturningInt();
            double var8 = 1.0 - var2;
            Color var13 = var6;
            double var10001 = var13.getRed() * var2;
            Color var14 = var1;
            var10 = (int)(var10001 + var14.getRed() * var8);
            Color var15 = var6;
            var10001 = var15.getGreen() * var2;
            Color var16 = var1;
            var11 = (int)(var10001 + var16.getGreen() * var8);
            var7 = var10000;
            Color var17 = var6;
            double var92 = var17.getBlue() * var2;
            Color var18 = var1;
            var12 = (int)(var92 + var18.getBlue() * var8);
            int var62 = var7;
            int var61 = var10;
            int var46 = var61;
            int var43 = var61;
            if (var62 == 0) {
               int var63 = var43;
               if (var63 >= 0) {
                  int var65 = var7;
                  int var64 = var10;
                  var47 = var64;
                  int var44 = var64;
                  if (var65 != 0) {
                     break label66;
                  }

                  int var66 = var44;
                  int var45 = var66;
                  short var96 = 11314;
                  long var10002 = 1588046073779145833L ^ var91;
                  short var68 = 255;
                  int var67 = var45;
                  if (var67 <= var68) {
                     break label65;
                  }
               }

               byte var93 = 0;
               short var97 = 16325;
               long var105 = 6232737801201377183L ^ var91;
               short var98 = 255;
               int var23 = var10;
               int var25 = Math.min(255, var23);
               int var69 = Math.max(0, var25);
               var46 = var69;
            }

            var10 = var46;
         }

         var47 = var11;
      }

      int var52;
      label55: {
         label54: {
            int var71 = var7;
            int var70 = var47;
            int var51 = var70;
            int var48 = var70;
            if (var71 == 0) {
               int var72 = var48;
               if (var72 >= 0) {
                  int var74 = var7;
                  int var73 = var11;
                  var52 = var73;
                  int var49 = var73;
                  if (var74 != 0) {
                     break label55;
                  }

                  int var75 = var49;
                  int var50 = var75;
                  short var99 = 16325;
                  long var106 = 6232737801201377183L ^ var91;
                  short var77 = 255;
                  int var76 = var50;
                  if (var76 <= var77) {
                     break label54;
                  }
               }

               byte var94 = 0;
               short var100 = 16325;
               long var107 = 6232737801201377183L ^ var91;
               var100 = 255;
               int var31 = var11;
               int var33 = Math.min(255, var31);
               int var78 = Math.max(0, var33);
               var51 = var78;
            }

            var11 = var51;
         }

         var52 = var12;
      }

      int var80 = var7;
      int var79 = var52;
      int var60 = var79;
      int var53 = var79;
      if (var80 == 0) {
         int var58;
         int var59;
         label41: {
            int var81 = var53;
            if (var81 >= 0) {
               short var102 = 16325;
               long var108 = 6232737801201377183L ^ var91;
               int var84 = var7;
               short var83 = 255;
               int var82 = var12;
               var58 = var82;
               var59 = var83;
               int var54 = var82;
               short var55 = var83;
               if (var84 != 0) {
                  break label41;
               }

               short var86 = var55;
               int var85 = var54;
               int var56 = var85;
               short var57 = var86;
               short var88 = var57;
               int var87 = var56;
               if (var87 <= var88) {
                  return new Color(var10, var11, var12);
               }
            }

            short var103 = 16325;
            long var109 = 6232737801201377183L ^ var91;
            var103 = 255;
            int var39 = var12;
            int var90 = Math.min(255, var39);
            byte var89 = 0;
            var58 = var89;
            var59 = var90;
         }

         int var42 = var59;
         int var41 = var58;
         var60 = Math.max(var41, var42);
      }

      var12 = var60;
      return new Color(var10, var11, var12);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 11610859514054L ^ 40662508999676L;
      var10001 = 11610859514054L ^ 137656134285995L;
      int var8 = Event.cReturningInt();
      BooleanSetting var12 = this.e;
      Boolean var13 = (Boolean)var12.aReturningObject();
      boolean var48 = var13;
      if (var48) {
         Object[] var16 = new Object[0];
         PacketReceiveEvent var15 = var1;
         Packet var10 = var15.aReturningVoid(var16);
         int var50 = var8;
         Packet var49 = var10;
         Packet var41 = var49;
         Packet var40 = var49;
         if (var50 != 0) {
            boolean var51 = var40 instanceof EntityStatusS2CPacket;
            if (!var51) {
               return;
            }

            Packet var52 = var10;
            var41 = var52;
         }

         EntityStatusS2CPacket var9 = (EntityStatusS2CPacket)var41;
         int var54 = var8;
         EntityStatusS2CPacket var53 = var9;
         EntityStatusS2CPacket var43 = var53;
         EntityStatusS2CPacket var42 = var53;
         if (var54 != 0) {
            EntityStatusS2CPacket var19 = var42;
            byte var10000 = var19.getStatus();
            byte var56 = 35;
            byte var55 = var10000;
            if (var55 != var56) {
               return;
            }

            EntityStatusS2CPacket var57 = var9;
            var43 = var57;
         }

         MinecraftClient var22 = b;
         ClientWorld var24 = var22.world;
         EntityStatusS2CPacket var23 = var43;
         Entity var11 = var23.getEntity((World)var24);
         int var59 = var8;
         Entity var58 = var11;
         Entity var45 = var58;
         Entity var44 = var58;
         if (var59 != 0) {
            boolean var60 = var44 instanceof PlayerEntity;
            if (!var60) {
               return;
            }

            Entity var61 = var11;
            var45 = var61;
         }

         PlayerEntity var69 = (PlayerEntity)var45;
         int var68;
         do {
            IntSetting var27 = this.a;
            Integer var28 = (Integer)var27.aReturningObject();
            int var63 = var28 * 2;
            int var62 = var70;
            if (var62 >= var63) {
               break;
            }

            ArrayList var29 = this.i;
            int var71 = var29.size();
            int var65 = var8;
            int var64 = var71;
            int var46 = var64;
            if (var65 != 0) {
               IntSetting var30 = this.c;
               Integer var31 = (Integer)var30.aReturningObject();
               int var67 = var31 * 20;
               int var66 = var46;
               if (var66 <= var67) {
                  ArrayList var72 = this.i;
                  Object[] var34 = new Object[]{var69, 131657085751917L};
                  Vec3d var10003 = RaycastUtil.aReturningVec3d(var34);
                  PlayerEntity var35 = var69;
                  double var10006 = var35.getX() + (Math.random() - 0.5) * 0.5;
                  PlayerEntity var36 = var69;
                  double var10007 = var36.getY() + Math.random() * 1.0 + 0.5;
                  PlayerEntity var37 = var69;
                  MotionPredictor var39 = new MotionPredictor(
                     var10003, new Vec3d(var10006, var10007, var37.getZ() + (Math.random() - 0.5) * 0.5), MotionPredictionMode.POP, 51076410620730L
                  );
                  ArrayList var38 = var72;
                  boolean var47 = var38.add(var39);
               }
            }

            var70++;
            var68 = var8;
         } while (var68 != 0);
      }
   }

   private boolean lambda$onRenderWorld$0(MotionPredictor var1) {
      long var10001 = 80940742095323L ^ 60607141832655L;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var10000 = var7.player;
      Object[] var9 = new Object[0];
      MotionPredictor var8 = var1;
      Vec3d var11 = var8.bReturningVec3d(var9);
      ClientPlayerEntity var10 = var10000;
      double var12 = var10.squaredDistanceTo(var11);
      double var38;
      int var34 = (var38 = Math.sqrt(var12) - 20.0) == 0.0 ? 0 : (var38 < 0.0 ? -1 : 1);
      int var27 = var6;
      int var26 = var34;
      int var24 = var26;
      int var21 = var26;
      if (var27 != 0) {
         int var28 = var21;
         if (var28 <= 0) {
            Object[] var16 = new Object[0];
            MotionPredictor var15 = var1;
            ElapsedTimer var35 = var15.aReturningfY_C0319(var16);
            IntSetting var17 = this.c;
            Integer var18 = (Integer)var17.aReturningObject();
            float var37 = var18 * 1000;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var37;
            Object[] var20 = var10004;
            ElapsedTimer var19 = var35;
            byte var36 = ((byte)((var19.aReturningBoolean(var20)) ? 1 : 0));
            int var30 = var6;
            byte var29 = var36;
            byte var39 = var29;
            byte var22 = var29;
            if (var30 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var39);
            }

            byte var31 = var22;
            byte var23 = var31;
            byte var32 = var23;
            if (var32 == 0) {
               return false;
            }
         }

         var24 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var24);
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(62468479531941L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[2];
      String var28 = "vÙÒ\u001c\\\u0086Ý\rp¢Xà,¡\u0086ºô@\u0083ñ¬¤-Ç\u009c\u0089\u009eÎcYmù\u0091±¸s\u0083ã~¨d0¸xRiµw2\u0083Á±8ï$î\u0003ë\u0090ä{\u0012\b+@ô»+T\u0018\u000eÎµ\u0019Å/ù6´#\u0099É¡\u009d3?\b¯¶KÚ\u0086wØ\u0011ëá\u001f/mÍÉ\u008d\"ô\u0099Ö½\u0003\u001cÙÛDøïIl\u0080ÄÜ§\u001dK\u0006L ¬¾\u0012";
      int var30 = "vÙÒ\u001c\\\u0086Ý\rp¢Xà,¡\u0086ºô@\u0083ñ¬¤-Ç\u009c\u0089\u009eÎcYmù\u0091±¸s\u0083ã~¨d0¸xRiµw2\u0083Á±8ï$î\u0003ë\u0090ä{\u0012\b+@ô»+T\u0018\u000eÎµ\u0019Å/ù6´#\u0099É¡\u009d3?\b¯¶KÚ\u0086wØ\u0011ëá\u001f/mÍÉ\u008d\"ô\u0099Ö½\u0003\u001cÙÛDøïIl\u0080ÄÜ§\u001dK\u0006L ¬¾\u0012"
         .length();
      char var27 = '@';
      int var26 = -1;

      while (true) {
         byte[] var32 = var24.doFinal(var28.substring(++var26, var26 + var27).getBytes("ISO-8859-1"));
         String var44 = b(var32).intern();
         int var10001 = -1;
         var31[var29++] = var44;
         if ((var26 += var27) >= var30) {
            l = var31;
            m = new String[2];
            q = new HashMap(13);
            Cipher var11;
            var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(62468479531941L << var12 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var17 = new long[7];
            String var15 = "¥~\u000b\u000f*T[\u0088ü\n\u0010¨gü\u0012¡¤XÞ{¨Fq7\u001b¼Àî\u009fV rib£H\u009eÛ=}";
            int var16 = "¥~\u000b\u000f*T[\u0088ü\n\u0010¨gü\u0012¡¤XÞ{¨Fq7\u001b¼Àî\u009fV rib£H\u009eÛ=}".length();
            label50:
            while (true) {
               var10001 = var13;
               var13 += 8;
               byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
               long[] var36 = var17;
               var10001 = var14++;
               long var47 = (var18[0] & 255L) << 56
                  | (var18[1] & 255L) << 48
                  | (var18[2] & 255L) << 40
                  | (var18[3] & 255L) << 32
                  | (var18[4] & 255L) << 24
                  | (var18[5] & 255L) << 16
                  | (var18[6] & 255L) << 8
                  | var18[7] & 255L;
               
                  long var19 = var47;
                  byte[] var21 = var11.doFinal(
                     new byte[]{
                        (byte)(var19 >>> 56),
                        (byte)(var19 >>> 48),
                        (byte)(var19 >>> 40),
                        (byte)(var19 >>> 32),
                        (byte)(var19 >>> 24),
                        (byte)(var19 >>> 16),
                        (byte)(var19 >>> 8),
                        (byte)var19
                     }
                  );
                  long var55 = (var21[0] & 255L) << 56
                     | (var21[1] & 255L) << 48
                     | (var21[2] & 255L) << 40
                     | (var21[3] & 255L) << 32
                     | (var21[4] & 255L) << 24
                     | (var21[5] & 255L) << 16
                     | (var21[6] & 255L) << 8
                     | var21[7] & 255L;
                  switch (var51) {
                     case 0:
                        var36[var10001] = var55;
                        if (var13 >= var16) {
                           o = var17;
                           p = new Integer[7];
                           t = new HashMap(13);
                           Cipher var0;
                           var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                           var10002 = SecretKeyFactory.getInstance("DES");
                           var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                           for (int var1 = 1; var1 < 8; var1++) {
                              var10003[var1] = (byte)(62468479531941L << var1 * 8 >>> 56);
                           }

                           var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                           long[] var6 = new long[3];
                           String var4 = "\u0017=ú\u0081\u001d°X\u0084½WÎµ4ô\u009aë´êl-\u0012\u0090üq";
                           int var5 = "\u0017=ú\u0081\u001d°X\u0084½WÎµ4ô\u009aë´êl-\u0012\u0090üq".length();
                           do {
                              int var42 = var2;
                              var2 += 8;
                              byte[] var7 = var4.substring(var42, var2).getBytes("ISO-8859-1");
                              var42 = var3++;
                              long var8 = (var7[0] & 255L) << 56
                                 | (var7[1] & 255L) << 48
                                 | (var7[2] & 255L) << 40
                                 | (var7[3] & 255L) << 32
                                 | (var7[4] & 255L) << 24
                                 | (var7[5] & 255L) << 16
                                 | (var7[6] & 255L) << 8
                                 | var7[7] & 255L;
                              byte[] var10 = var0.doFinal(
                                 new byte[]{
                                    (byte)(var8 >>> 56),
                                    (byte)(var8 >>> 48),
                                    (byte)(var8 >>> 40),
                                    (byte)(var8 >>> 32),
                                    (byte)(var8 >>> 24),
                                    (byte)(var8 >>> 16),
                                    (byte)(var8 >>> 8),
                                    (byte)var8
                                 }
                              );
                              var55 = (var10[0] & 255L) << 56
                                 | (var10[1] & 255L) << 48
                                 | (var10[2] & 255L) << 40
                                 | (var10[3] & 255L) << 32
                                 | (var10[4] & 255L) << 24
                                 | (var10[5] & 255L) << 16
                                 | (var10[6] & 255L) << 8
                                 | var10[7] & 255L;
                              
                           } while (var2 < var5);

                           r = var6;
                           s = new Long[3];
                           h = 20L;
                           break;
                        }
                        break;
                     default:
                        var36[var10001] = var55;
                        if (var13 < var16) {
                           continue label50;
                        }

                        var15 = "Àâ\u001cý&\u008e¯Û|NÄõ,\u0083Ø±";
                        var16 = "Àâ\u001cý&\u008e¯Û|NÄõ,\u0083Ø±".length();
                        var13 = 0;
                  }

                  int var41 = var13;
                  var13 += 8;
                  var18 = var15.substring(var41, var13).getBytes("ISO-8859-1");
                  var36 = var17;
                  var10001 = var14++;
                  var47 = (var18[0] & 255L) << 56
                     | (var18[1] & 255L) << 48
                     | (var18[2] & 255L) << 40
                     | (var18[3] & 255L) << 32
                     | (var18[4] & 255L) << 24
                     | (var18[5] & 255L) << 16
                     | (var18[6] & 255L) << 8
                     | var18[7] & 255L;
                  var51 = 0;
               }
            }
         }

         var27 = var28.charAt(var26);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 477;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eN", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eN_C0243",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eN" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 48;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eN", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eN_C0243",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eN" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10411;
      if (s[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = r[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])t.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eN", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         s[var3] = var15;
      }

      return s[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eN_C0243",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eN" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = v[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = u[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 14;
            yield var15;
         }
         case 1 -> {
            byte var16 = 10;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 36;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 21;
            yield var21;
         }
         case 7 -> {
            byte var22 = 26;
            yield var22;
         }
         case 8 -> {
            byte var23 = 46;
            yield var23;
         }
         case 9 -> {
            byte var24 = 1;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 3;
            yield var26;
         }
         case 12 -> {
            byte var27 = 32;
            yield var27;
         }
         case 13 -> {
            byte var28 = 53;
            yield var28;
         }
         case 14 -> {
            byte var29 = 9;
            yield var29;
         }
         case 15 -> {
            byte var30 = 5;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 20;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 15;
            yield var34;
         }
         case 20 -> {
            byte var35 = 11;
            yield var35;
         }
         case 21 -> {
            byte var36 = 35;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 0;
            yield var39;
         }
         case 25 -> {
            byte var40 = 57;
            yield var40;
         }
         case 26 -> {
            byte var41 = 58;
            yield var41;
         }
         case 27 -> {
            byte var42 = 51;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 61;
            yield var44;
         }
         case 30 -> {
            byte var45 = 39;
            yield var45;
         }
         case 31 -> {
            byte var46 = 23;
            yield var46;
         }
         case 32 -> {
            byte var47 = 54;
            yield var47;
         }
         case 33 -> {
            byte var48 = 25;
            yield var48;
         }
         case 34 -> {
            byte var49 = 31;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 48;
            yield var51;
         }
         case 37 -> {
            byte var52 = 29;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 44;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 52;
            yield var58;
         }
         case 44 -> {
            byte var59 = 16;
            yield var59;
         }
         case 45 -> {
            byte var60 = 13;
            yield var60;
         }
         case 46 -> {
            byte var61 = 56;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 42;
            yield var63;
         }
         case 49 -> {
            byte var64 = 24;
            yield var64;
         }
         case 50 -> {
            byte var65 = 60;
            yield var65;
         }
         case 51 -> {
            byte var66 = 55;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 45;
            yield var68;
         }
         case 54 -> {
            byte var69 = 7;
            yield var69;
         }
         case 55 -> {
            byte var70 = 6;
            yield var70;
         }
         case 56 -> {
            byte var71 = 28;
            yield var71;
         }
         case 57 -> {
            byte var72 = 49;
            yield var72;
         }
         case 58 -> {
            byte var73 = 34;
            yield var73;
         }
         case 59 -> {
            byte var74 = 62;
            yield var74;
         }
         case 60 -> {
            byte var75 = 59;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 63;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            v[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      u[0] = "\u001b\u000b\u0017(f\u0011\r\u000b\u0012ru\u0006\u001a@\u0011ty\u0012\u000b\u0007\u0006c2\u0002L";
      u[1] = "!D_Q\u0016_TdT^\u0007\u00105j_U\u0003JA";
      u[2] = "*x~h\u0007\n*xi4\u000b\u000503i*\u000b\u00107B8rY";
      u[3] = "il%[~Gil2\u0007rHs'2\u0019r]tV`C&\u0019";
      u[4] = double.class;
      v[4] = "java/lang/Double";
      u[5] = "A\u001b`0I{_\u0013z\u007f&|Y\u001bo\u001d\u000e}_";
      u[6] = int.class;
      v[6] = "java/lang/Integer";
      u[7] = "\u0011\u0019W\by`\u0007\u0019RRjw\u0010RQTfc\u0001\u0015FC-u;";
      u[8] = "^qh\u0019\u0000\u0013U~yVc\u001e@sv=V\u001cQ`j\u0011A\u0011";
      u[9] = "=\u0017\u0006m\u001by6\u0018\u0017\"wz8\u001a\u0015m[";
      u[10] = boolean.class;
      v[10] = "java/lang/Boolean";
      u[11] = "I08\u0003??_0=Y,(H{>_ <Y<)Hk.h";
      u[12] = "8okn7H3`z!VF8k~{";
      u[13] = "iF\u0011|\u0001OiF\u0006 \r@s\r\u0006>\rUt|Vc\\";
      u[14] = "YRbqZ1YRu-V>C\u0019u3V+Dh l\u000f";
      u[15] = "V*C$\u001aSV*Tx\u0016\\LaTf\u0016IK\u0010\u0005<A\t";
      u[16] = "[5N\u001ce\u0004[5Y@i\u000bA~Y^i\u001eF\u000f\u000b\u000b;Z";
      u[17] = "$\u001duE\u0011D$\u001db\u0019\u001dK>Vb\u0007\u001d^9'0YE\u001a";
      u[18] = "gq9r\u001bUqq<(\bBf:?.\u0004Vw}(9OAE";
      u[19] = ",&Y\u0012z'')H]\u001d%2\"H\u0016&";
      u[20] = "\u0016p)A\u0000}\u0000p,\u001b\u0013j\u0017;/\u001d\u001f~\u0006|8\nTo\u0016";
      u[21] = "\u0018:3\u0010A\u001em\u001a8\u001fPQ\f\u00143\u0014T\u000bx";
      u[22] = "\u007fs\u001dYiD\u007fs\n\u0005eKe8\n\u001be^bI[B=\u001b";
      u[23] = "cfJy\u0017!hi[6t,}o";
      u[24] = byte.class;
      v[24] = "java/lang/Byte";
      u[25] = "\u0004\b~#!O\u0019\u001d&\u0001`B\u0001\u001b";
      u[26] = "\b\u00063{w@\u0016\u000e)4\u0015\\\u0011\u0013";
      u[27] = "v(\u001e4$@h \u0004{CAy;\t!eG";
      u[28] = "\u0010%kM\u007f9\u0006%n\u0017l.\u0011nm\u0011`:\u0000)z\u0006+-%";
      u[29] = "W|V\u0004t\n\"\\]\u000beECRV\u0000a\u001f7";
      u[30] = void.class;
      v[30] = "java/lang/Void";
      u[31] = "\b`\u001cR'\r\u001e`\u0019\b4\u001a\t+\u001a\u000e8\u000e\u0018l\r\u0019s\u001e+";
      u[32] = "u5/L\u001fQc5*\u0016\fFt~)\u0010\u0000Re9>\u0007KB}9<\f\u0011\u000fA\"<\u0011\u0011Hv5";
      u[33] = "?\u0016r7H\u0006)\u0016wm[\u0011>]tkW\u0005/\u001ac|\u001c\u0014\u0003";
      u[34] = "\u0011_@\n\u0001)d\u007fK\u0005\u0010f\u0005q@\u000e\u0014<q";
      u[35] = "y)\u001fFD\u0015o)\u001a\u001cW\u0002xb\u0019\u001a[\u0016i%\u000e\r\u0010\u0004_";
      u[36] = "fi|\u00068e\u0013Iw\t)*rG|\u0002-p\u0006";
      u[37] = "\u00165\u000b\u001bc\u0005c\u0015\u0000\u0014rJ\u0002\u001b\u000b\u001fv\u0010v";
      u[38] = float.class;
      v[38] = "java/lang/Float";
      u[39] = "hv\rbz\u0016v~\u0017-2\u0016lt\u000fj;\r,G\tf0\nav\u000ff";
      u[40] = "<gLt$1*gI.7&=,J(;2,k]?p'\u0001";
      u[41] = "y<MoHY\f\u001cF`Y\u0016m\u0012Mk]L\u0019";
      u[42] = "\u00105\fc\u0001;e\u0015\u0007l\u0010t\u0004\u001b\fg\u0014.p";
      u[43] = "{@\u00041\u0001\u001a\u000e`\u000f>\u0010Uon\u00045\u0014\u000f\u001b";
      u[44] = "i\u0003OE\fHi\u0003X\u0019\u0000GsHX\u0007\u0000Rt9\u0003RY";
      u[45] = "\rB)v,\u000f\rB>* \u0000\u0017\t>4 \u0015\u0010xiiyR";
      u[46] = "eT4%aj\u0010t?*p%qz4!t\u007f\u0005";
      u[47] = "_\u0005o\u0011\tvI\u0005jK\u001aa^NiM\u0016uO\t~Z]bL";
      u[48] = "?z\nJ<MJZ\u0001E-\u0002+T\nN)X_";
      u[49] = "!O3z}\u0012To8ul]5a3~h\u0007A";
      u[50] = "tLPSY+tLG\u000fU$n\u0007G\u0011U1iv\u0016N\u0007z";
      u[51] = "\u0007\u001cP:\b0\u0007\u001cGf\u0004?\u001dWGx\u0004*\u001a&\u0016\"]i";
      u[52] = "mcQ\u0000.4mcF\\\";w(FB\".pY\u0016\u001bpo";
      u[53] = "\u001d\u001fy>vt\u000b\u001f|dec\u001cT\u007fbiw\r\u0013hu\"u";
      u[54] = ")h)F\"K\\H\"I3\u0004=F)B7^I";
      u[55] = "\u0004y8\u0002\"|qY3\r33\u0010W8\u00067id";
      u[56] = "G\u0015\u0017P)\u0007G\u0015\u0000\f%\b]^\u0000\u0012%\u001dZ/QMsZ";
      u[57] = "O\u0004]}\u0003\u0012Y\u0004X'\u0010\u0005NO[!\u001c\u0011_\bL6W\u0003c";
      u[58] = "Mgi\u000fF\u00068Gb\u0000WIYIi\u000bS\u0013-";
      u[59] = "\u0018\u0011.5*m\u0013\u001e?zWx\u0001\u0004=9";
      u[60] = long.class;
      v[60] = "java/lang/Long";
      u[61] = "'Q?-?\bRq4\".G3\u007f?)*\u001dG";
      u[62] = "&1zT4s&1m\b8|<zm\u00168i;\u000b9No";
      u[63] = "kpSO^_\u001ePX@O\u0010\u007f^SKKJ\u000b";
      u[64] = "s\u0004=>\u0019-\u0006$61\bbg*=:\f8\u0013";
      u[65] = "d~\u0003[E(f`J8N3ye\u001cAI";
      u[66] = ">(\u000e\u0000&5<6Gx)9%5\u001b\u001d(";
      u[67] = "nntj,hxnq0?\u007fo%r63k~be!x|m";
      u[68] = "4\u0018OR,\u007fA8D]=0 6OV9jT";
      u[69] = "\u0006\u0007\u0019'7\u0013\u0010\u0007\u001c}$\u0004\u0007L\u001f{(\u0010\u0016\u000b\blc\u0007\b";
      u[70] = "{7[\u001a2Z\u000e\u0017P\u0015#\u0015o\u0019[\u001e'O\u001b";
      u[71] = "5\u0007A~`F#\u0007D$sQ4LG\"\u007fE%\u000bP54R9";
      u[72] = "\u0006D\".\u000fCsd)!\u001e\f\u0012j\"*\u001aVf";
      u[73] = "H3J)p\u000b^3Osc\u001cIxLuo\bX?[b$\u0019x";
      u[74] = "tfg,W\tbfbvD\u001eu-apH\ndjvg\u0003\u001ej";
      u[75] = "\u001c')\nV\u0012\u001e*%\u0010-\u001d\u001a7\u0019K\u001c\u0006\u0017=%\u0016_\u0002IG%FS\u001c\t{x\u0005WBs{(\tI\u0002O&k\r\u0017x";
      u[76] = "P<1soQ\u0010<<2t(\u0019Ue?wU\u0018%c1$\u0015";
      u[77] = "oNn\u007fu\t>\u0016n&\u0005\u0011i\ri~i#>J2 :t>\u0001cdt\u00048\u000f0$\u0005";
      u[78] = "\u0005A\u0010>9D\u0015C\u0019cFL\u001fB\u001b2:K\u001f#\u00140\"J\u001aA\u00042+\u0017e";
      u[79] = "2jE\t\u001c&i:\f_\u0004^`+O\u0018\r8w\nT\u0007\r\u001bj2Q\u0003\u001b^2kHR\u00003f6SX\u000b^";
      u[80] = "VRKQmp^\u0007\u0001U\u0000b0T\u0017\u0018btU\t\u0017Fg30\u0016BFo;U\rJ\u0017y\u000b";
      u[81] = "K:\u0018dD\u0017I7\u0014~?\u0018E<(`E\u001b]gY}\u0000\u0014OZQcY\u0004\u0019+L&V\u0016$#R\u007fF@U>\u0017pT}";
      u[82] = "NK0\"GCHI.nw]SE,w\u000b[U(7oI\fTX0d\u0017Q/";
      u[83] = "TwEt1A@aL7I\u0016+<Py+\u0002NaP'.E+?\u0007-%\u0004\u001al\u000477}";
      u[84] = "3=#FUhq8|\u0014[Sc\u0006|\u0015\u00071uc!\u0015Y42\u0006.GP5z{\u007f\u001fPl\n";
      u[85] = "\u000e*i F:\bri5&<\u00041Q%B \u000fM3}X9\u0018qn>\\gb";
      u[86] = "\tv)43\u001a\u00011=0\u000f\u0011l,#,3H\u0013*!2\u007fx";
      u[87] = "\u0014\u0018n\n\u0010\b\u0016\u0015b\u0010k\u001e\u001c\"7\u001b\n\u000b\u001d\u0003^M\u001b\b\u0006\t.K\u0015[Fxd\u0007\u0001\u001f\n\bb\tR_{";
      u[88] = "7i#&8=0b}{C+;ha\u0016s17s')/,4b\u001d";
      u[89] = "m@`)BDvH1?rH\u0016Acv\u0010^s\u001cc(\u0015\u0019\u0016\u0001t \u000b\u001cg\u001c1/\u0019!";
      u[90] = "m{I;vX1fJ*L\n$zA47gm{I;vX1fJ*LX0bB0&\u0002'zKP";
      u[91] = "RGs\tP`BEzT/Hvl\\&/bPA{\u001aMrRH&";
      u[92] = "h\u001f\u001e\u0004u\u0010j\u0012\u0012\u001e\u000e\u0001~\u0005Ry4\nm\u0002_\t2\u0004>B.C~\u0010z\u000e^EpC:\u007f";
      u[93] = "99\u001a^2B'x\u0000SCV*;\u0011\t/d~vJTr3>=\u0017\u0017~B#x\u0018\u0005C";
      u[94] = "R\u0010\u00034wH\u000e\u0005\u00004FF\u000e\u0003\u00054*tZB[jF^\u0006\u0007\u0017?!\u001aR\u001b\\S";
      u[95] = "j\u0017_N\u001cb;O_\u0017lzlTXO\u0000H;\u0013\u0003\u0011\\\u001f;XRU\u001do=V\u0001\u0015l";
      u[96] = "\u0015N\u0003+l\n\u0005L\nv\u0013\u0007\u0018P=*\u007fhI\u001d\u0019#iT\u0014^\u001d}\u0013";
      u[97] = "!t\u007f\u000bzW}#d\tan}!eR\u007f\u0002Ou$\t$V\u0018p(L|\u0014$-kH\"n$}gVbRy>c\b\u0018R)2}H$\u000fj6#2$_f(c\u000ey\u001cbv\u0019";
      u[98] = ";%\u0004?2e<y[n=\f~n\u000fi7hkh\u000b\u000f5vdm[~(3k\u007ffv6j{)\u0017ksei\u0014\u001fu*u?e\u00020%g\u0002-Wm|rk*\u000b2-}\u0002";
      u[99] = "\u0014ytJ*_GznXS\u0000O.tJ\u0004W\u0015~*&i\u001eD>aVo\u0010\u0017~";
      u[100] = "\u0000\rB(\u0017$S\u000eX:n{[ZB(9,\u0001\n\u001fDTePJW4Rk\u0003\n";
      u[101] = "\u001cR7\u001aboYRw\u0011\u001bc[Zv\u0014ge]7m\f%2\\Gj\u0007{o'";
      u[102] = "\u0007!}\u0001S6[f,\u0010!*:%\u007fNC7_x\u007f\u0010Fp:\u007f`\u0017Y,Weh\u001c\u001eH";
      u[103] = "\u00079j=I\\\u0004\"(:'\u0004ed;tE\u0012\u00009;*@Ue>$-_\t\b$,&\u0018m";
      u[104] = "H M<\u0004H\f,WQ\u0004*H*\u001d3\u0011O\u0015*C6V*K}I=\u0017\u001b\u0018~S/n";
      u[105] = "\u00053\u001f\n&\u000b\u00151\u0016WY\u0005\f+\u0018\u000b#i\u00053\u001f\n&\u000b\u00151\u0016WY";
      u[106] = "\u001b\u000eX\u001c?3[\u001fVU/KKb\u0005H})]\u0007XH#,\u001ab\u0005H)9Y\u001eY@t7\u001cb";
      u[107] = "\u0000Z\b\u0015s>\\O\u000b\u0015B;PX\n\u001e\u0015l\u000f\u0005Qrs'UJQ\u0018s4\r\u000b";
      u[108] = "2|F<*\u0010c$FeZ\b4?A=6:cx\u001a`cmc3K'+\u001de=\u0018gZ";
      u[109] = "c\u0006\u0016I?taB\u000eIM~g\u0000\u0010W!L3EL\u000e|\u001b`L\u000eZ1%7\u0017HPMp5\u001b\u0016@0!m\u001bO0";
      u[110] = "n\u0000+3U\n'\u000e-+\u0003i=\tT/@\u0002g\u001f%1\u0001\u0018jn";
      u[111] = "8\n\t \u001d,%^\u0002gy''O\u0010?\u0015\u0015v\u0002NcIBs\bL;\u001f,2P@'IB8\n\t \u001d,%^\u0002gy";
      u[112] = "5DV\u0010\u007fDpD\u0016\u001b\u0006Hul\b\u000fzX\u000e\u001e\u0000\u0012lIdD\u0017\ne)";
      u[113] = "R8EJr\u0018K|U\u001d\u0003\u0011M8_\u0010o#\u001az\u0005N>t\u001f)Z\u001dc\u001eE>B\u0014\u0003";
      u[114] = "P\u0001%bqXR\f)x\nHV\u0007yxo2\u0005\u0011\u007fb{B\u0003\u001f,\"\n";
      u[115] = "n-\u007f':8lig'H2j+y9$\u0000>n%apWh+z .:\u007f-b%H";
      u[116] = "\r8P\u001f'q\u001d:YBX|\u0000&{\t5~\u000bZ\bB&w\u0017fU\u0001\")m";
      u[117] = "\u0013cT/S\nCl\n.5\u001a,!T+Q\n\u0010|\u0017/\u000fp";
      u[118] = "_~i,nJW+#(\u0003X9x5eaN\\%5;d\t9\"*<{UT8\"7<1";
      u[119] = "H\u0004>\u001alPJ\t2\u0000\u0017AF\u0002\u000e]gPZ\u0015~[i\u0003\u001ad4\u0017}GV\u00142\u0019.\u0007'";
      u[120] = "\u0012nn8toRncyo\u0016Y\u0007:tlkZw<z?+";
      u[121] = "S!T\u0010z\u001dSk\n\u0014\u0002\b\u0004fZ\u0014n:S!\u0001I;mSjP\u000es\u001dUd\u0003N\u0002";
      u[122] = "=e,\u0016\u001d\u001750f\u0012p\u0005[cp_\u0012\u0013>>p\u0001\u0017T[#g\t\tQ*>\"\u0006\u001bl";
      u[123] = "B@c\u00038\u0000\u0006\u0014\u007fHT\t^H\u007f\u001d\u0003[\u0001\u0015%q*\u0019T\u0015j\u00004XN\u0018";
      u[124] = "\u0004LAuA}\\\u001aX \u000e\u0012T&\u0007$@pBCZ$\u001eu\u0005&\u0007 \u001e.O_G \u0013oT&";
      u[125] = "=q~l-`:-!=\"\t\u007f+u8>\t}:z%nx`\u007fu7S05\",\":7i}}-S";
      u[126] = "M\u0000% lg\b\u0000e+\u0015q\u0017\u0017sG);\b\u0001d{tx\f_\u001e";
      u[127] = "\u0016Z M\u0010\u0012\u001e\u000fjI}\u0003p\\|\u0004\u001f\u0016\u0015\u0001|Z\u001aQp_+P\u0011\u0010A\f(J\u0003i";
      u[128] = "\u00073M\u001e\r*E6\u001e\u0006o<^/@\u0015\u00060g!@\u0005\u0002V\u0006%A\u0012\u000f<\\2Y\u001bo";
      u[129] = "$:VbQ\u0007t5\bc7\u0016\u001bxVfS\u0007'%\u0015b\r}";
      u[130] = "}#?ir\b)\"mm\u0017_\u0016k}a|\f)7`bm6";
      u[131] = "\u0017\u0003H:y?R\u0003\b1\u0000(A\u0003\u0014#m\u0013Bf\tc>2\\\u0002\u0011aj?,Y\u001e8j2F\u0003\t cR";
      u[132] = "\n\u001f\\i&oY\u001cF{_0QH\\i\bg\u000b\u0018\u0000\u0005e.ZXIuc \t\u0018";
      u[133] = "vE[\u0014|\r*\u0002\n\u0005\u000e\u001aKAY[l\f.\u001cY\u0005iKK\u0018V\u000fb\f)\bT\u0006?s";
      u[134] = "y\u001e'\f\u0015\u000bb\u0016v\u001a%\u0007\u0002\u001f$SG\u0011gB$\rBV\u0002E;\n]\no_3\u0001\u001an";
      u[135] = "G`\f\u007f%5\u001bu\u000f\u007f\u00140\u0017b\u000etCgI5V\u0018-aH0\u0000~}3Jk\u000f";
      u[136] = "\u000fj\u0016BM\u0007\u000f9EQq\u0000jc\u001dZ\u000fP\bkZN\u000b";
      u[137] = "Z*T\u0019so]v\u000bH|\u0006\u0019|J@qk2\u001bOSk\u007f^jR\u0016dmc\"\u0007K=x\n%[\u0014lwc";
      u[138] = "\u000f8sFv\u001b\b3-\u001b\r\u000b\u00072\u000b\u001b}\u0017nv \u0013g\u000b\u0004,7\u000bnk";
      u[139] = "qp\u000f\u0001l\u0013\"s\u0015\u0013\u0015G&6\u000b\nyurrQW\u0015\u0018q.\u0007\u0014$Kr4\u0015m/R!7\u001a\u001d)\\rwk";
      u[140] = "?%o:.\u0014=(c U\u001b1#_{d\u00004?c&'\u0004jEcv+\u001a*y>5/DPyn91\u0004l$-=o~";
      u[141] = "\u0000mVJ'\u0015\u0000~\u000e\u000b\u0018\u001a\\cRRt(\u0001$\b\r\u0018\r\bfJQv\u0010\\m\r5j\u0003K\"CYsG[u2";
      u[142] = "h\u0011\u001b[r\r6GVFxg<P\u001bIz\u001cQ\u0019\u001aAu]nE\u0007BdgnD\u0003J~\r4S\u001bC\u001e";
      u[143] = "\u001d\u000b\u0000Lm\u0007Y\u0007\u001a!ne\u001d\u0001PCx\u0000@\u0001\u000eF?e\u001eV\u0004M~TMU\u001e_\u0007";
      u[144] = "\u0013\u001cJ?0XO[\u001b.BE.\u0018Hp YKEH.%\u001e.BW):BCX_\"}&";
      u[145] = "a2\u0018z)]<oRk[\t\u0006lM29\u001ac1Ml<]\u00065Bf7\u001ad%@oje";
      u[146] = " bz\u001c\u0004Tp0xG\u000b2|08C\t^N`{\u001bQ2#g O\u0017\u0003pd:]n\bi79R\u001e\u000egdy#";
      u[147] = "q)\r7=%j!\\!\r)\n(\u000eho?ou\u000e6jx\n.\u000e=g `t\u0019%n@";
      u[148] = "a\u0003\u000b\u0005rxgZ\u0004R;\u0012=jBYrp'\u000f\u001fY,u`j\u0018F+j<\u0007\u0002N -X";
      u[149] = "*}qwMN:\u007fx*2C'c_\u007fOAJ#$eVVv~ga\b,";
      u[150] = "\b\n]\nSE\b@\u0003\u000e+P_MS\u000eGb\b\n\bP\u001b5\bAY\u0014ZE\u000eO\nT+";
      u[151] = "VDDp\u0000(\n\u0003\u0015ar?kDQ6M3\b\u000bHs\u000eVV\u0003\u00120\u00175\u0019\u001aWsr";
      u[152] = "Fwd\u007f\\@\u0003w$t%D\u0011~_(YL\u0016(`tDO\u0007\u0012`u@G\u001dx:bXN}";
      u[153] = "6w\u0018A3)5lZF]qT,I]7x>v^E>\u0018";
      u[154] = "nkao\u0000Np*{bqZ}ij8\u001dh)$1dI?iol&LNt*c4q";
      u[155] = "\b[\u001du\u001ch\u000f\u0007B$\u0013\u0001K\r\u0003,\u001elaj\u0006?\u0004x\f\u001b\u001bz\u000bj1SN'R\u007fXT\u0012x\u0003p1";
      u[156] = "G\u0002x%D\u001e\u001bE)46\nz\u0006zjT\u001f\u001f[z4QXz_u>Z\u001f\u0018Ow7\u0007`";
      u[157] = "d*$\u0002ubd`z\u0006\rw3m*\u0006aEd*qX2\u0012da \u001c|bbos\\\r";
      u[158] = "_\u000f'\u0014\u001f%B\u0011 Lv-2T2F\u0014;W\t2\u0018\u0011|2\u0003?J\u001c'\\\u00166OHD";
      u[159] = "\u001a[%1%<Z[(p>ER2q}=8RBwsnx";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = u[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(v[var4]);
            u[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            u[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  u[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(895728650325543L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  u[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(895728650325543L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        u[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(895728650325543L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 100;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 85;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 254;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 116;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 121;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 104;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 100;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 85;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 254;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eN_C0243",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eN" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(HitEffect var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eN_C0243;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/eN_C0243", "lambda$onRenderWorld$0", "(Ldev/zprestige/prestige/bX_C0103;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/bX_C0103;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((HitEffect)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
