package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.PostAttackEvent;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.AttackCooldownEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;

public class HitFix extends Module implements RotationSource {
   private BooleanSetting d;
   private BooleanSetting a;
   private BooleanSetting c;
   private ElapsedTimer e;
   private boolean i;
   private boolean f;
   private PlayerEntity g;
   private static final long k = 104668827501479L;
   private static final Object[] l = new Object[80];
   private static final String[] m = new String[80];

   public HitFix() {
      super();
      long var10001 = 74816863992520L ^ 40687151468001L;

      this.e = new ElapsedTimer(106698256430889L);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.g = null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 104668827501479L ^ var2;
      long var5 = var2 ^ 103289419492851L;
      long var7 = var2 ^ 2294001254406L;
      int var9 = Event.cReturningInt();
      int var48 = var9;
      PlayerEntity var47 = var4;
      Object var33 = var47;
      PlayerEntity var32 = var47;
      if (var48 != 0) {
         PlayerEntity var49 = var32;
         if (var49 == null) {
            return false;
         }

         BooleanSetting var12 = this.d;
         var33 = var12.aReturningObject();
      }

      byte var37;
      Boolean var13 = (Boolean)var33;
      byte var10000 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
      int var51 = var9;
      byte var50 = var10000;
      var37 = var50;
      byte var34 = var50;
      label68:
      if (var51 != 0) {
         byte var52 = var34;
         if (var52 != 0) {
            MinecraftClient var15 = b;
            ClientPlayerEntity var16 = var15.player;
            Object[] var17 = new Object[]{var16.getMainHandStack(), var7};
            var10000 = ((byte)((InventoryUtil.aReturningBoolean(var17)) ? 1 : 0));
            int var54 = var9;
            byte var53 = var10000;
            var37 = var53;
            byte var35 = var53;
            if (var54 == 0) {
               break label68;
            }

            byte var55 = var35;
            byte var36 = var55;
            byte var56 = var36;
            if (var56 == 0) {
               return false;
            }
         }

         BooleanSetting var21 = this.c;
         Boolean var22 = (Boolean)var21.aReturningObject();
         var37 = ((byte)(((java.lang.Boolean)(var22)).booleanValue() ? 1 : 0));
      }

      int var41;
      int var58 = var9;
      byte var57 = var37;
      var41 = var57;
      byte var38 = var57;
      label61:
      if (var58 != 0) {
         byte var59 = var38;
         if (var59 != 0) {
            PlayerEntity var24 = var4;
            int var61 = var9;
            int var60 = var24.hurtTime;
            var41 = var60;
            int var39 = var60;
            if (var61 == 0) {
               break label61;
            }

            int var62 = var39;
            int var40 = var62;
            int var63 = var40;
            if (var63 != 0) {
               return true;
            }
         }

         BooleanSetting var28 = this.a;
         Boolean var29 = (Boolean)var28.aReturningObject();
         var41 = ((((java.lang.Boolean)(var29)).booleanValue() ? 1 : 0));
      }

      int var65 = var9;
      int var64 = var41;
      int var43 = var64;
      int var42 = var64;
      if (var65 != 0) {
         int var66 = var42;
         if (var66 == 0) {
            return false;
         }

         Object[] var31 = new Object[]{var4, var5};
         double var74;
         int var67 = (var74 = RaycastUtil.aReturningDouble(var31) - 0.3F) == 0.0 ? 0 : (var74 < 0.0 ? -1 : 1);
         var43 = var67;
      }

      int var69 = var9;
      int var68 = var43;
      int var45 = var68;
      int var44 = var68;
      if (var69 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var45);
      } else {
         int var70 = var44;
         if (var70 > 0) {
            byte var75 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var75);
         } else {
            return false;
         }
      }
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      long var10001 = 82279609218387L ^ 6904351435086L;
      var10001 = 82279609218387L ^ 118886343400787L;
      int var8 = Event.bReturningInt();
      int var60 = var8;
      MinecraftClient var59 = b;
      MinecraftClient var46 = var59;
      MinecraftClient var45 = var59;
      if (var60 == 0) {
         MinecraftClient var11 = var45;
         Screen var61 = var11.currentScreen;
         if (var61 != null) {
            return;
         }

         MinecraftClient var62 = b;
         var46 = var62;
      }

      MinecraftClient var14 = var46;
      boolean var63 = var14.isWindowFocused();
      if (var63) {
         Object[] var17 = new Object[0];
         AttackAttemptEvent var16 = var1;
         EventPhase var10000 = var16.aReturningEventPhase(var17);
         EventPhase var65 = EventPhase.PRE;
         EventPhase var64 = var10000;
         if (var64 == var65) {
            boolean var66 = this.f;
            if (var66) {
               Object[] var20 = new Object[]{true};
               AttackAttemptEvent var19 = var1;
               var19.bReturningVoid(var20);
            } else {
               MinecraftClient var22 = b;
               int var68 = var8;
               HitResult var67 = var22.crosshairTarget;
               HitResult var48 = var67;
               HitResult var47 = var67;
               if (var68 == 0) {
                  HitResult var69 = var47;
                  if (var69 == null) {
                     return;
                  }

                  MinecraftClient var24 = b;
                  HitResult var70 = var24.crosshairTarget;
                  var48 = var70;
               }

               int var72 = var8;
               HitResult var71 = var48;
               HitResult var50 = var71;
               HitResult var49 = var71;
               if (var72 == 0) {
                  HitResult var26 = var49;
                  Type var89 = var26.getType();
                  Type var74 = Type.ENTITY;
                  Type var73 = var89;
                  if (var73 != var74) {
                     return;
                  }

                  MinecraftClient var29 = b;
                  var50 = var29.crosshairTarget;
               }

               int var76 = var8;
               HitResult var75 = var50;
               HitResult var52 = var75;
               HitResult var51 = var75;
               if (var76 == 0) {
                  boolean var77 = var51 instanceof EntityHitResult;
                  if (!var77) {
                     return;
                  }

                  MinecraftClient var32 = b;
                  var52 = var32.crosshairTarget;
               }

               EntityHitResult var33 = (EntityHitResult)var52;
               Entity var10 = var33.getEntity();
               int var79 = var8;
               Entity var78 = var10;
               Entity var54 = var78;
               Entity var53 = var78;
               if (var79 == 0) {
                  boolean var80 = var53 instanceof PlayerEntity;
                  if (!var80) {
                     return;
                  }

                  Entity var81 = var10;
                  var54 = var81;
               }

               PlayerEntity var9 = (PlayerEntity)var54;
               int var82 = var8;
               if (var82 == 0) {
                  int var85 = var8;
                  PlayerEntity var84 = var9;
                  HitFix var83 = this;
                  HitFix var57 = var83;
                  PlayerEntity var58 = var84;
                  HitFix var55 = var83;
                  PlayerEntity var56 = var84;
                  if (var85 == 0) {
                     Object[] var38 = new Object[]{var56, 84193128946717L};
                     HitFix var37 = var55;
                     boolean var86 = var37.aReturningBoolean(var38);
                     if (!var86) {
                        return;
                     }

                     this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                     PlayerEntity var88 = var9;
                     HitFix var87 = this;
                     var57 = var87;
                     var58 = var88;
                  }

                  var57.g = var58;
                  ElapsedTimer var90 = this.e;
                  Object[] var42 = new Object[]{42835128969216L};
                  ElapsedTimer var41 = var90;
                  var41.aReturningVoid(var42);
                  Object[] var44 = new Object[0];
                  AttackAttemptEvent var43 = var1;
                  var43.aReturningVoid(var44);
               }
            }
         }
      }
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 125493482823167L ^ 68925769122274L;
      var10001 = 125493482823167L ^ 93286401471999L;
      int var8 = Event.cReturningInt();
      int var63 = var8;
      MinecraftClient var62 = b;
      MinecraftClient var43 = var62;
      MinecraftClient var42 = var62;
      if (var63 != 0) {
         MinecraftClient var11 = var42;
         Screen var64 = var11.currentScreen;
         if (var64 != null) {
            return;
         }

         MinecraftClient var65 = b;
         var43 = var65;
      }

      int var67 = var8;
      MinecraftClient var66 = var43;
      MinecraftClient var45 = var66;
      MinecraftClient var44 = var66;
      if (var67 != 0) {
         MinecraftClient var14 = var44;
         boolean var68 = var14.isWindowFocused();
         if (!var68) {
            return;
         }

         var45 = b;
      }

      MinecraftClient var17 = var45;
      int var70 = var8;
      HitResult var69 = var17.crosshairTarget;
      HitResult var47 = var69;
      HitResult var46 = var69;
      if (var70 != 0) {
         HitResult var71 = var46;
         if (var71 == null) {
            return;
         }

         MinecraftClient var19 = b;
         HitResult var72 = var19.crosshairTarget;
         var47 = var72;
      }

      int var74 = var8;
      HitResult var73 = var47;
      HitResult var49 = var73;
      HitResult var48 = var73;
      if (var74 != 0) {
         HitResult var21 = var48;
         Type var10000 = var21.getType();
         Type var76 = Type.ENTITY;
         Type var75 = var10000;
         if (var75 != var76) {
            return;
         }

         MinecraftClient var24 = b;
         var49 = var24.crosshairTarget;
      }

      int var78 = var8;
      HitResult var77 = var49;
      HitResult var51 = var77;
      HitResult var50 = var77;
      if (var78 != 0) {
         boolean var79 = var50 instanceof EntityHitResult;
         if (!var79) {
            return;
         }

         MinecraftClient var27 = b;
         var51 = var27.crosshairTarget;
      }

      EntityHitResult var28 = (EntityHitResult)var51;
      Entity var10 = var28.getEntity();
      int var81 = var8;
      Entity var80 = var10;
      Entity var53 = var80;
      Entity var52 = var80;
      if (var81 != 0) {
         boolean var82 = var52 instanceof PlayerEntity;
         if (!var82) {
            return;
         }

         Entity var83 = var10;
         var53 = var83;
      }

      PlayerEntity var9 = (PlayerEntity)var53;
      int var84 = var8;
      if (var84 != 0) {
         int var86 = var8;
         HitFix var85 = this;
         HitFix var61 = var85;
         HitFix var54 = var85;
         if (var86 != 0) {
            HitFix var59;
            PlayerEntity var60;
            label53: {
               boolean var87 = var54.i;
               if (!var87) {
                  int var90 = var8;
                  PlayerEntity var89 = var9;
                  HitFix var88 = this;
                  var59 = var88;
                  var60 = var89;
                  HitFix var55 = var88;
                  PlayerEntity var56 = var89;
                  if (var90 == 0) {
                     break label53;
                  }

                  PlayerEntity var92 = var56;
                  HitFix var91 = var55;
                  HitFix var57 = var91;
                  PlayerEntity var58 = var92;
                  Object[] var35 = new Object[]{var58, 84193128946717L};
                  HitFix var34 = var57;
                  boolean var93 = var34.aReturningBoolean(var35);
                  if (!var93) {
                     return;
                  }
               }

               this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
               PlayerEntity var95 = var9;
               HitFix var94 = this;
               var59 = var94;
               var60 = var95;
            }

            var59.g = var60;
            var61 = this;
         }

         ElapsedTimer var96 = var61.e;
         Object[] var39 = new Object[]{42835128969216L};
         ElapsedTimer var38 = var96;
         var38.aReturningVoid(var39);
         Object[] var41 = new Object[0];
         AttackEntityEvent var40 = var1;
         var40.aReturningVoid(var41);
      }
   }

   @EventListener
   public void a(AttackCooldownEvent var1) {
      long var10001 = 70082316546481L ^ 126649762721196L;
      var10001 = 70082316546481L ^ 27797484493233L;
      int var8 = Event.cReturningInt();
      int var63 = var8;
      MinecraftClient var62 = b;
      MinecraftClient var43 = var62;
      MinecraftClient var42 = var62;
      if (var63 != 0) {
         MinecraftClient var11 = var42;
         Screen var64 = var11.currentScreen;
         if (var64 != null) {
            return;
         }

         MinecraftClient var65 = b;
         var43 = var65;
      }

      int var67 = var8;
      MinecraftClient var66 = var43;
      MinecraftClient var45 = var66;
      MinecraftClient var44 = var66;
      if (var67 != 0) {
         MinecraftClient var14 = var44;
         boolean var68 = var14.isWindowFocused();
         if (!var68) {
            return;
         }

         var45 = b;
      }

      MinecraftClient var17 = var45;
      int var70 = var8;
      HitResult var69 = var17.crosshairTarget;
      HitResult var47 = var69;
      HitResult var46 = var69;
      if (var70 != 0) {
         HitResult var71 = var46;
         if (var71 == null) {
            return;
         }

         MinecraftClient var19 = b;
         HitResult var72 = var19.crosshairTarget;
         var47 = var72;
      }

      int var74 = var8;
      HitResult var73 = var47;
      HitResult var49 = var73;
      HitResult var48 = var73;
      if (var74 != 0) {
         HitResult var21 = var48;
         Type var10000 = var21.getType();
         Type var76 = Type.ENTITY;
         Type var75 = var10000;
         if (var75 != var76) {
            return;
         }

         MinecraftClient var24 = b;
         var49 = var24.crosshairTarget;
      }

      int var78 = var8;
      HitResult var77 = var49;
      HitResult var51 = var77;
      HitResult var50 = var77;
      if (var78 != 0) {
         boolean var79 = var50 instanceof EntityHitResult;
         if (!var79) {
            return;
         }

         MinecraftClient var27 = b;
         var51 = var27.crosshairTarget;
      }

      EntityHitResult var28 = (EntityHitResult)var51;
      Entity var10 = var28.getEntity();
      int var81 = var8;
      Entity var80 = var10;
      Entity var53 = var80;
      Entity var52 = var80;
      if (var81 != 0) {
         boolean var82 = var52 instanceof PlayerEntity;
         if (!var82) {
            return;
         }

         Entity var83 = var10;
         var53 = var83;
      }

      PlayerEntity var9 = (PlayerEntity)var53;
      int var84 = var8;
      if (var84 != 0) {
         int var86 = var8;
         HitFix var85 = this;
         HitFix var61 = var85;
         HitFix var54 = var85;
         if (var86 != 0) {
            HitFix var59;
            PlayerEntity var60;
            label53: {
               boolean var87 = var54.i;
               if (!var87) {
                  int var90 = var8;
                  PlayerEntity var89 = var9;
                  HitFix var88 = this;
                  var59 = var88;
                  var60 = var89;
                  HitFix var55 = var88;
                  PlayerEntity var56 = var89;
                  if (var90 == 0) {
                     break label53;
                  }

                  PlayerEntity var92 = var56;
                  HitFix var91 = var55;
                  HitFix var57 = var91;
                  PlayerEntity var58 = var92;
                  Object[] var35 = new Object[]{var58, 84193128946717L};
                  HitFix var34 = var57;
                  boolean var93 = var34.aReturningBoolean(var35);
                  if (!var93) {
                     return;
                  }
               }

               this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
               PlayerEntity var95 = var9;
               HitFix var94 = this;
               var59 = var94;
               var60 = var95;
            }

            var59.g = var60;
            var61 = this;
         }

         ElapsedTimer var96 = var61.e;
         Object[] var39 = new Object[]{42835128969216L};
         ElapsedTimer var38 = var96;
         var38.aReturningVoid(var39);
         Object[] var41 = new Object[0];
         AttackCooldownEvent var40 = var1;
         var40.aReturningVoid(var41);
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var4;
      long var6;
      long var8;
      long var10;
      long var12;
      long var14;
      int var16;
      Object var59;
      label97: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 124119119688829L;
         var6 = var2 ^ 19256669677348L;
         var8 = var2 ^ 73608466808436L;
         var10 = var2 ^ 30352829501857L;
         var12 = var2 ^ 134366226930033L;
         var14 = var2 ^ 100729554575240L;
         var16 = Event.cReturningInt();
         int var75 = var16;
         boolean var74 = this.i;
         boolean var58 = var74;
         boolean var56 = var74;
         if (var75 != 0) {
            boolean var76 = var56;
            if (!var76) {
               return null;
            }

            MinecraftClient var21 = b;
            int var78 = var16;
            ClientPlayerEntity var77 = var21.player;
            var59 = var77;
            ClientPlayerEntity var57 = var77;
            if (var78 == 0) {
               break label97;
            }

            ClientPlayerEntity var22 = var57;
            boolean var79 = var22.isUsingItem();
            var58 = var79;
         }

         boolean var80 = var58;
         if (var80) {
            return null;
         }

         var59 = this.g;
      }

      Object var64;
      label87: {
         label99: {
            int var82 = var16;
            Object var81 = var59;
            Object var61 = var81;
            Object var60 = var81;
            if (var82 != 0) {
               Object var83 = var60;
               if (var83 == null) {
                  break label99;
               }

               PlayerEntity var84 = this.g;
               var61 = var84;
            }

            int var86 = var16;
            Object var85 = var61;
            Object var63 = var85;
            Object var62 = var85;
            if (var86 == 0) {
               Object var89 = var63;
               var64 = var89;
               break label87;
            }

            Object var27 = var62;
            boolean var87 = ((PlayerEntity)var27).isAlive();
            if (var87) {
               PlayerEntity var88 = this.g;
               var64 = var88;
               break label87;
            }
         }

         Object[] var30 = new Object[]{var12};
         var64 = EntityUtil.aReturningPlayerEntity(var30);
      }

      Object var17 = var64;
      int var90 = var16;
      if (var90 != 0) {
         Object var91 = var17;
         label73:
         if (var91 != null) {
            MinecraftClient var32 = b;
            Object var34 = var17;
            ClientPlayerEntity var33 = var32.player;
            float var110;
            int var10000 = (var110 = var33.distanceTo((Entity)var34) - 3.0F) == 0.0F ? 0 : (var110 < 0.0F ? -1 : 1);
            int var93 = var16;
            int var92 = var10000;
            int var67 = var92;
            int var65 = var92;
            if (var93 != 0) {
               int var94 = var65;
               int var66 = var94;
               int var95 = var66;
               if (var95 > 0) {
                  break label73;
               }

               MinecraftClient var37 = b;
               Object var39 = var17;
               ClientPlayerEntity var38 = var37.player;
               byte var96 = ((byte)((var38.canSee((Entity)var39)) ? 1 : 0));
               var67 = var96;
            }

            int var98 = var16;
            int var97 = var67;
            int var69 = var97;
            int var68 = var97;
            if (var98 != 0) {
               int var99 = var68;
               if (var99 == 0) {
                  break label73;
               }

               Object[] var44 = new Object[]{var17, var4};
               HitFix var43 = this;
               var69 = (((var43.aReturningBoolean(var44)) ? 1 : 0));
            }

            HitFix var73;
            label102: {
               int var101 = var16;
               int var100 = var69;
               int var72 = var100;
               int var70 = var100;
               if (var101 != 0) {
                  int var102 = var70;
                  if (var102 != 0) {
                     return null;
                  }

                  int var104 = var16;
                  HitFix var103 = this;
                  var73 = var103;
                  HitFix var71 = var103;
                  if (var104 == 0) {
                     break label102;
                  }

                  ElapsedTimer var108 = var71.e;
                  Object[] var10004 = new Object[]{null, var8};
                  var10004[0] = 1000.0F;
                  Object[] var48 = var10004;
                  ElapsedTimer var47 = var108;
                  byte var105 = ((byte)((var47.aReturningBoolean(var48)) ? 1 : 0));
                  var72 = var105;
               }

               int var106 = var72;
               if (var106 == 0) {
                  Object var51 = var17;
                  Object[] var52 = new Object[]{((PlayerEntity)var51).getEyePos(), var10};
                  Rotation var18 = RotationUtil.aReturningdx_C0210(var52);
                  this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  this.g = null;
                  PostAttackEvent var109 = new PostAttackEvent();
                  Object[] var54 = new Object[]{var6};
                  PostAttackEvent var53 = var109;
                  var53.bReturningBoolean(var54);
                  this.f = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  Object[] var55 = new Object[]{var17, var14};
                  ItemUseUtil.aReturningVoid(var55);
                  this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  return var18;
               }

               this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
               HitFix var107 = this;
               var73 = var107;
            }

            var73.g = null;
            return null;
         }

         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         this.g = null;
      }

      return null;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.g = null;
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.g = null;
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 35;
            yield var15;
         }
         case 1 -> {
            byte var16 = 4;
            yield var16;
         }
         case 2 -> {
            byte var17 = 52;
            yield var17;
         }
         case 3 -> {
            byte var18 = 16;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 59;
            yield var20;
         }
         case 6 -> {
            byte var21 = 48;
            yield var21;
         }
         case 7 -> {
            byte var22 = 24;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 37;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 12;
            yield var26;
         }
         case 12 -> {
            byte var27 = 27;
            yield var27;
         }
         case 13 -> {
            byte var28 = 34;
            yield var28;
         }
         case 14 -> {
            byte var29 = 15;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 21;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 58;
            yield var38;
         }
         case 24 -> {
            byte var39 = 62;
            yield var39;
         }
         case 25 -> {
            byte var40 = 28;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 17;
            yield var42;
         }
         case 28 -> {
            byte var43 = 39;
            yield var43;
         }
         case 29 -> {
            byte var44 = 61;
            yield var44;
         }
         case 30 -> {
            byte var45 = 29;
            yield var45;
         }
         case 31 -> {
            byte var46 = 54;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 44;
            yield var48;
         }
         case 34 -> {
            byte var49 = 31;
            yield var49;
         }
         case 35 -> {
            byte var50 = 47;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 45;
            yield var53;
         }
         case 39 -> {
            byte var54 = 11;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 56;
            yield var56;
         }
         case 42 -> {
            byte var57 = 50;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 42;
            yield var59;
         }
         case 45 -> {
            byte var60 = 23;
            yield var60;
         }
         case 46 -> {
            byte var61 = 46;
            yield var61;
         }
         case 47 -> {
            byte var62 = 38;
            yield var62;
         }
         case 48 -> {
            byte var63 = 5;
            yield var63;
         }
         case 49 -> {
            byte var64 = 8;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 63;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 7;
            yield var68;
         }
         case 54 -> {
            byte var69 = 9;
            yield var69;
         }
         case 55 -> {
            byte var70 = 57;
            yield var70;
         }
         case 56 -> {
            byte var71 = 55;
            yield var71;
         }
         case 57 -> {
            byte var72 = 40;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 13;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 1;
            yield var77;
         }
         default -> 10;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u0016\u0010\rC\"q\u0016\u0010\u001a\u001f.~\f[\u001a\u0001.k\u000b*J\\\u007f";
      l[1] = "{ %Yz6{ 2\u0005v9ak2\u001bv,f\u001aeD ";
      l[2] = boolean.class;
      m[2] = "java/lang/Boolean";
      l[3] = "GIq\u0014R\u001eQItNA\tF\u0002wHM\u001dWE`_\u0006\u000ff";
      l[4] = int.class;
      m[4] = "java/lang/Integer";
      l[5] = "PnS|b\u000ePnD n\u0001J%D>n\u0014MT\u0015a6";
      l[6] = "\"*\r*Q?4*\bpB(#a\u000bvN<2&\u001ca\u0005*\t";
      l[7] = ",v5\u0010Z\u0007YV>\u001fKH8X5\u0014O\u0012L";
      l[8] = "=\u000e 2\u001b,=\u000e7n\u0017#'E7p\u00176 4g%@s";
      l[9] = "`F=$ud`F*xykz\r*fy~}|x8!:";
      l[10] = "]\u000f41\u0019dV\u0000%~ziC\r*\u0015OkR\u001e69Xf";
      l[11] = "afGx5SafP$9\\{-P:9I|\\\u0001ea\u001eloR%+e=7\u0003";
      l[12] = "7/`m\"V!/e71A6df1=U'#q&v@\n";
      l[13] = "bV`i@A\u0017vkfQ\u000evx`mUT\u0002";
      l[14] = void.class;
      m[14] = "java/lang/Void";
      l[15] = "\u0000#\u001e\u0019:7u\u0003\u0015\u0016+x\u0014\r\u001e\u001d/\"`";
      l[16] = "3\u0013qGqY%\u0013t\u001dbN2Xw\u001bnZ#\u001f`\f%M.";
      l[17] = "\u001c&7xN\u0006i\u0006<w_I\b\b7|[\u0013|";
      l[18] = "k\u000f%l\u001eM}\u000f 6\rZjD#0\u0001N{\u00034'J^c\u00036,\u0010\u0013_\u001861\u0010Th\u000f";
      l[19] = ")p%)\u0010\u001e?p s\u0003\t(;#u\u000f\u001d9|4bD\r~";
      l[20] = "|&|^el\t\u0006wQt#h\b|Zpy\u001c";
      l[21] = double.class;
      m[21] = "java/lang/Double";
      l[22] = "f4n\u000b7)f4yW;&|\u007fyI;3{\u000e-\u0011l";
      l[23] = "yU_F\u000fpyUH\u001a\u0003\u007fc\u001eH\u0004\u0003jdo\u001a_[ ";
      l[24] = "\u001dd'^rC\u001dd0\u0002~L\u0007/0\u001c~Y\u0000^bF*\u001d";
      l[25] = "qJLr\nuzE]=fvtG_rJ";
      l[26] = "n0/Qsnx0*\u000b`yo{)\rlm~<>\u001a'zL";
      l[27] = "N6\rt1}E9\u001c;PsN2\u0018a";
      l[28] = "*D}s\u0014I<Dx)\u0007^+\u000f{/\u000bJ:Hl8@Z!";
      l[29] = "\fB\u0013\u001a\u0005dyb\u0018\u0015\u0014+\u0018l\u0013\u001e\u0010ql";
      l[30] = "}b;e\f\u0001kb>?\u001f\u0016|)=9\u0013\u0002mn*.X\u0015[";
      l[31] = "\tm]}-(|MVr<g\u001dC]y8=i";
      l[32] = "!>Vd!\u00007>S>2\u0017 uP8>\u000312G/u\u0014=";
      l[33] = "a\n\u0010\u001elt\u0014*\u001b\u0011};u$\u0010\u001aya\u0001";
      l[34] = ":G! \nn,G$z\u0019y;\f'|\u0015m*K0k^x\u000b";
      l[35] = "+\nwUJy^*|Z[6?$wQ_lK";
      l[36] = "k\u001c\u0017%\"-\u001e<\u001c*3b\u007f2\u0017!78\u000b";
      l[37] = "\u0013\u0010,?1+\u0005\u0010)e\"<\u0012[*c.(\u0003\u001c=te8\u001b";
      l[38] = "8\u0002Q\u0018?\u000bM\"Z\u0017.D,,Q\u001c*\u001eX";
      l[39] = float.class;
      m[39] = "java/lang/Float";
      l[40] = "RNX\u0002O\u0007RNO^C\bH\u0005O@C\u001dOt\u001e\u0018\u0011";
      l[41] = "\u001a\u0003Hr}Co#C}l\f\u000e-HvhVz";
      l[42] = ";6j\r37-6oW  :}lQ,4+:{Fg0";
      l[43] = "\u001a\u00135UOi\f\u00130\u000f\\~\u001bX3\tPj\n\u001f$\u001e\u001b{?";
      l[44] = "\u0019of[]|lOmTL3\rAf_Hiy";
      l[45] = "x7\u001b+Pn\r\u0017\u0010$A!l\u0019\u001b/E{\u0018";
      l[46] = "\u00105\u001a\tnD\fjDJ\u0016Mtq\u001e\rwI\t\u007fJJr$\u0011u\u0002Aw\u001e\u001b7GJ\u0016";
      l[47] = "]+aF}\u001f\u0001/=E\u0007\u0017gy2D7\f\u001d;+\u0001\u007f}";
      l[48] = ",6u$\rRp:('0@-2/)g\u0010vdvE\u000bEvo:?I\\3'";
      l[49] = "wBoAh4jJx%~8|Bhr)f,\u001b\u0004\u001c-dnCxBa#q";
      l[50] = ",DcC(4p@?@R?\u0016S>\u00063;k]jA6VjAg\u0000ml'B'\u0004R";
      l[51] = "Tb\u0005KD5W\"\u0003\fy$>-Y\r\u0018%C#\rJ\u001dHWb\u0002NDpEmU\u0002y";
      l[52] = "S\u001d\n\u001d\u0016TN\u0015\u001dy\u000bTI\u0019\u0006\u00159\u0000\bGPyT\u0001\bG\u0006F\rB\fEa";
      l[53] = "\u0011g1\u0002\u0003BMcm\u0001yK+5b\u0000IQQw{E\u0001 ";
      l[54] = "\u000b\u0016F\t\u0002\u0004U\u0000N\u0010=^\f\u0015C\u0019TR5\u001bC\tP4QJ\u001aJZ\u000b\b\t\u001eH=";
      l[55] = "\u0014Fz#rF\u0016A`u\u000fT(\u0012j&tMTFf/n=\u0017M`7\u007fACAi-\u000f";
      l[56] = "B5\u0013Hl[V&\u001cF\u0016I:6\u0013KwMG8G\fr SyH\b+\u0018Av\u001fD\u0016";
      l[57] = "\u0004j7|]S\u0017=d- \u000beai<\u0011Y\t}j.^b";
      l[58] = "\"\u0001/$Y\u0005*Uwf#\f!\u0013~?O>qP%i#W}U})A\r(\u0013wXY\tr\u0015!&I\u00042W\u001e";
      l[59] = "u.!A\u001f\u0005vn'\u0006\"\u0015\u001fa}\u0007C\u0015bo)@Fxv.&D\u001f@d!q\b\"";
      l[60] = ">\u0007co\u0003\u00196S;-y\u0010=\u00152t\u0015\"nQo,yKaS1b\u001b\u00114\u0015;\u0013CMmW5,\u001a\u000eiUR";
      l[61] = "\u0017j3\u0010\u0001\u0013Kfn\u0013<\n\u001a\u007fm\u0016P8L80N\u0005o\r}f\bS\bO=hO<";
      l[62] = "%5_\u001bGN{8M\u0018#\u001a\u0015-X\u001cB\u001eh#\f[Gs|b\u0003_\u001eKnmT\u0013#";
      l[63] = "j@i{`\fwH~\u001fv\u0000a@nH!^6\u0018\u0002qvPp^ny\"\b2";
      l[64] = "v\u001cLy@x*P[88-(\rAkozr[\u001c\u0007\u0007? \u001e]<[s7_";
      l[65] = "6<-\u001fjuma,\u001f\tv]0x\u001d2, 38\u001bu";
      l[66] = "71?-oNk5c.\u0015E\r&bhtAp(6/q,di9+(\u0014vfng\u0015";
      l[67] = "\"?[\rr\u0018~3\u0006\u000eO\u0001/*\u0005\u000b#3\u007ff]QO^zk[\u000bp\u00079oYl";
      l[68] = "\u001c)\u007f\u007ft`B$m|\u00104,1xxq0Q?,?t]\u0016w ;wbO4$9\u0010";
      l[69] = "7\u001f~EeDjFsW^B[\u0006vC?F&\b\"\u0004:+6\u0002z_8\u00148Dq\u0000^";
      l[70] = "0lj#2O882aHF3~;8$t`:g`HLb{e-pGgk2_";
      l[71] = "MJU|<UG\u001a\u001f \u0005C*\tK=dGW\u0007\u001fza*J\u001e\u0010!8V\u0016\u0012M\"\u0005";
      l[72] = "[\u00182H0rF\u0010%,&~P\u00185{q \u0003AY\u0017-sP\u001c2\u0017)z\u0004";
      l[73] = "e\u0000A:.\"g\u0007[lS0Y\u0015T(24$\u001b\u0000o7YcS\fk4f:\u0010\biS";
      l[74] = "\bEGX\\\u0001TA\u001b[&\t2R\u001a\u001dG\u000eO\\NZBc\b\u0014B^A\\QWF\\&";
      l[75] = "G\u0003B\u000e\u0004=\u001c\f\u0000Fd)\u0014O\u0012\u001b\b\u001b@\fML^LG\u0002H\u001f\u0015.\u001dW\u000e\u0015d";
      l[76] = "\u0004\u0006\u00011P\u0004@D\u0011':\bx\n\r#[\u000f\u0005\u0004Yd^b\u0011EV`\u0007Z\u0003J\u0001,:";
      l[77] = "H.C?\u001f=H*Jk\u007f3\u001e7O5\u0013\u0001Jt\u0010bDVL7F,\u0007m\u0010{Qm\u007f";
      l[78] = "`U\u001f,c[bJ\u0010y\u000fH\u0002N\u0011knL\u007f@E,k!8\bI(h\u001eaKM*\u000f";
      l[79] = "\u0016\u000ek4 \u0010\u001eZ3vZ\u0019\u0015\u001c:/6+FYcuZF@]d/e\u001f\u0003YfH";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1945958718560935L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1945958718560935L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1945958718560935L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 243;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 236;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 230;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 120;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 196;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 243;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 236;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eO_C0245",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eO" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
