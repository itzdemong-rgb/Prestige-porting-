package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.modules.state.HitFlickState;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

public class HitFlick extends Module implements RotationSource {
   private BooleanSetting d;
   private BooleanSetting a;
   private FloatSetting c;
   private FloatSetting e;
   private ModeSetting f;
   private HitFlickState g = HitFlickState.IDLE;
   private Entity h;
   private float i;
   private boolean j;
   private static final long k = 94983482980825L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[78];
   private static final String[] p = new String[78];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
      this.g = HitFlickState.IDLE;
      this.h = null;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      this.g = HitFlickState.IDLE;
      this.h = null;
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 59750760797043L ^ 119406782075319L;
      var10001 = 59750760797043L ^ 20886280662690L;
      int var8 = Event.bReturningInt();
      boolean var118 = this.j;
      if (!var118) {
         int var120 = var8;
         MinecraftClient var119 = b;
         MinecraftClient var86 = var119;
         MinecraftClient var85 = var119;
         if (var120 == 0) {
            MinecraftClient var16 = var85;
            ClientPlayerEntity var121 = var16.player;
            if (var121 == null) {
               return;
            }

            MinecraftClient var122 = b;
            var86 = var122;
         }

         int var124 = var8;
         MinecraftClient var123 = var86;
         MinecraftClient var88 = var123;
         MinecraftClient var87 = var123;
         if (var124 == 0) {
            MinecraftClient var19 = var87;
            ClientWorld var125 = var19.world;
            if (var125 == null) {
               return;
            }

            var88 = b;
         }

         int var127 = var8;
         MinecraftClient var126 = var88;
         MinecraftClient var90 = var126;
         MinecraftClient var89 = var126;
         if (var127 == 0) {
            MinecraftClient var22 = var89;
            Screen var128 = var22.currentScreen;
            if (var128 != null) {
               return;
            }

            MinecraftClient var129 = b;
            var90 = var129;
         }

         MinecraftClient var25 = var90;
         byte var10000 = ((byte)((var25.isWindowFocused()) ? 1 : 0));
         int var131 = var8;
         boolean var130 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
         boolean var92 = var130;
         boolean var91 = var130;
         if (var131 == 0) {
            boolean var132 = var91;
            if (!var132) {
               return;
            }

            MinecraftClient var27 = b;
            ClientPlayerEntity var28 = var27.player;
            boolean var133 = var28.isUsingItem();
            var92 = var133;
         }

         boolean var134 = var92;
         if (!var134) {
            int var136 = var8;
            HitFlickState var135 = this.g;
            Object var94 = var135;
            HitFlickState var93 = var135;
            if (var136 == 0) {
               HitFlickState var138 = HitFlickState.IDLE;
               HitFlickState var137 = var93;
               if (var137 != var138) {
                  return;
               }

               BooleanSetting var32 = this.a;
               var94 = var32.aReturningObject();
            }

            Object var99;
            label145: {
               label144: {
                  Boolean var33 = (Boolean)var94;
                  var10000 = ((byte)(((java.lang.Boolean)(var33)).booleanValue() ? 1 : 0));
                  int var140 = var8;
                  boolean var139 = ((((int)(var10000) & 1) != 0));
                  boolean var98 = var139;
                  boolean var95 = var139;
                  if (var140 == 0) {
                     boolean var141 = var95;
                     if (!var141) {
                        break label144;
                     }

                     MinecraftClient var35 = b;
                     int var143 = var8;
                     ClientPlayerEntity var142 = var35.player;
                     var99 = var142;
                     ClientPlayerEntity var96 = var142;
                     if (var143 != 0) {
                        break label145;
                     }

                     ClientPlayerEntity var144 = var96;
                     ClientPlayerEntity var97 = var144;
                     ClientPlayerEntity var37 = var97;
                     boolean var145 = var37.isSprinting();
                     var98 = var145;
                  }

                  boolean var146 = var98;
                  if (!var146) {
                     return;
                  }
               }

               Object[] var40 = new Object[0];
               AttackEntityEvent var39 = var1;
               var99 = var39.aReturningEntity(var40);
            }

            Object var9 = var99;
            int var148 = var8;
            Object var147 = var9;
            Object var101 = var147;
            Object var100 = var147;
            if (var148 == 0) {
               Object var149 = var100;
               if (var149 == null) {
                  return;
               }

               var101 = var9;
            }

            int var151 = var8;
            Object var150 = var101;
            Object var103 = var150;
            Object var102 = var150;
            if (var151 == 0) {
               MinecraftClient var42 = b;
               ClientPlayerEntity var153 = var42.player;
               Object var152 = var102;
               if (var152 == var153) {
                  return;
               }

               BooleanSetting var45 = this.d;
               var103 = var45.aReturningObject();
            }

            boolean var107;
            Boolean var46 = (Boolean)var103;
            var10000 = ((byte)(((java.lang.Boolean)(var46)).booleanValue() ? 1 : 0));
            int var155 = var8;
            boolean var154 = ((((int)(var10000) & 1) != 0));
            var107 = var154;
            boolean var104 = var154;
            label124:
            if (var155 == 0) {
               boolean var156 = var104;
               if (var156) {
                  var10000 = ((byte)((var9 instanceof PlayerEntity) ? 1 : 0));
                  int var158 = var8;
                  boolean var157 = ((((int)(var10000) & 1) != 0));
                  var107 = var157;
                  boolean var105 = var157;
                  if (var158 != 0) {
                     break label124;
                  }

                  boolean var159 = var105;
                  boolean var106 = var159;
                  boolean var160 = var106;
                  if (!var160) {
                     return;
                  }
               }

               var107 = var9 instanceof PlayerEntity;
            }

            Object var112;
            label178: {
               boolean var111;
               int var162 = var8;
               boolean var161 = var107;
               var111 = var161;
               boolean var108 = var161;
               label116:
               if (var162 == 0) {
                  boolean var163 = var108;
                  if (var163) {
                     PlayerEntity var10 = (PlayerEntity)var9;
                     SocialsManager var187 = Prestige.g;
                     PlayerEntity var51 = var10;
                     Text var52 = var51.getName();
                     Object[] var54 = new Object[]{var52.getString(), 40309233401297L};
                     SocialsManager var53 = var187;
                     var10000 = ((byte)((var53.aReturningBoolean(var54)) ? 1 : 0));
                     int var165 = var8;
                     boolean var164 = ((((int)(var10000) & 1) != 0));
                     var111 = var164;
                     boolean var109 = var164;
                     if (var165 != 0) {
                        break label116;
                     }

                     boolean var166 = var109;
                     if (var166) {
                        return;
                     }
                  }

                  int var168 = var8;
                  PlayerValidationTracker var167 = Prestige.i;
                  var112 = var167;
                  PlayerValidationTracker var110 = var167;
                  if (var168 != 0) {
                     break label178;
                  }

                  Object[] var57 = new Object[]{var9, 99841884226244L};
                  PlayerValidationTracker var56 = var110;
                  boolean var169 = var56.aReturningBoolean(var57);
                  var111 = var169;
               }

               boolean var170 = var111;
               if (!var170) {
                  return;
               }

               ModeSetting var59 = this.f;
               var112 = var59.aReturningObject();
            }

            float var183;
            label180: {
               String var11 = (String)var112;
               String var61 = "Left";
               String var60 = var11;
               var10000 = ((byte)((var60.equals(var61)) ? 1 : 0));
               int var172 = var8;
               byte var171 = var10000;
               byte var114 = var171;
               byte var113 = var171;
               if (var172 == 0) {
                  byte var173 = var113;
                  if (var173 != 0) {
                     var183 = -1.0F;
                     int var174 = var8;
                     if (var174 == 0) {
                        break label180;
                     }
                  }

                  String var64 = "Right";
                  String var63 = var11;
                  byte var175 = ((byte)((var63.equals(var64)) ? 1 : 0));
                  var114 = var175;
               }

               int var177 = var8;
               byte var176 = var114;
               int var116 = var176;
               byte var115 = var176;
               if (var177 == 0) {
                  byte var178 = var115;
                  if (var178 != 0) {
                     var183 = 1.0F;
                     int var179 = var8;
                     if (var179 == 0) {
                        break label180;
                     }
                  }

                  double var193;
                  int var180 = (var193 = Math.random() - 0.5) == 0.0 ? 0 : (var193 < 0.0 ? -1 : 1);
                  var116 = var180;
               }

               int var181 = var116;
               float var117;
               if (var181 < 0) {
                  float var182 = -1.0F;
                  var117 = var182;
               } else {
                  var117 = 1.0F;
               }

               var183 = var117;
            }

            FloatSetting var69 = this.c;
            Float var70 = (Float)var69.aReturningObject();
            float var190 = var70;
            FloatSetting var71 = this.e;
            Float var72 = (Float)var71.aReturningObject();
            float var74 = var72;
            float var73 = var190;
            float var12 = Math.min(var73, var74);
            FloatSetting var75 = this.c;
            Float var76 = (Float)var75.aReturningObject();
            float var191 = var76;
            FloatSetting var77 = this.e;
            Float var78 = (Float)var77.aReturningObject();
            float var80 = var78;
            float var79 = var191;
            float var13 = Math.max(var79, var80);
            float var14 = var12 + (float)(Math.random() * (var13 - var12));
            MinecraftClient var81 = b;
            ClientPlayerEntity var82 = var81.player;
            this.i = var82.getYaw() + var183 * var14;
            this.h = (Entity)var9;
            this.g = HitFlickState.FLICK;
            Object[] var84 = new Object[0];
            AttackEntityEvent var83 = var1;
            var83.aReturningVoid(var84);
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var4;
      long var6;
      int var8;
      HitFlick var40;
      label45: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 30352829501857L;
         var6 = var2 ^ 100729554575240L;
         var8 = Event.bReturningInt();
         int var47 = var8;
         HitFlickState var46 = HitFlickState.IDLE;
         HitFlickState var45 = this.g;
         HitFlickState var38 = var45;
         HitFlickState var39 = var46;
         HitFlickState var35 = var45;
         HitFlickState var36 = var46;
         if (var47 == 0) {
            HitFlickState var49 = var36;
            HitFlickState var48 = var35;
            if (var48 == var49) {
               return null;
            }

            int var51 = var8;
            HitFlick var50 = this;
            var40 = var50;
            HitFlick var37 = var50;
            if (var51 != 0) {
               break label45;
            }

            HitFlickState var53 = HitFlickState.FLICK;
            HitFlickState var52 = var37.g;
            var38 = var52;
            var39 = var53;
         }

         HitFlickState var55 = var39;
         HitFlickState var54 = var38;
         if (var54 == var55) {
            float var9 = this.i + (float)(Math.random() * 3.0 - 1.5);
            MinecraftClient var16 = b;
            ClientPlayerEntity var17 = var16.player;
            float var10000 = var17.getPitch() + (float)(Math.random() * 2.0 - 1.0);
            float var20 = 89.9F;
            float var19 = -89.9F;
            float var18 = var10000;
            float var10 = MathHelper.clamp(var18, var19, var20);
            this.g = HitFlickState.ATTACK;
            return new Rotation(var9, var10);
         }

         this.g = HitFlickState.IDLE;
         var40 = this;
      }

      Entity var62 = var40.h;
      this.h = null;
      int var57 = var8;
      Entity var56 = var62;
      Entity var42 = var56;
      Entity var41 = var56;
      if (var57 == 0) {
         Entity var58 = var41;
         if (var58 == null) {
            return null;
         }

         var42 = var62;
      }

      int var60 = var8;
      Entity var59 = var42;
      Entity var44 = var59;
      Entity var43 = var59;
      if (var60 == 0) {
         Entity var22 = var43;
         boolean var61 = var22.isAlive();
         if (!var61) {
            return null;
         }

         var44 = var62;
      }

      Entity var25 = var44;
      Object[] var26 = new Object[]{var25.getEyePos(), var4};
      Rotation var63 = RotationUtil.aReturningdx_C0210(var26);
      Object[] var28 = new Object[0];
      Rotation var27 = var63;
      float var11 = var27.aReturningFloat(var28) + (float)(Math.random() * 3.0 - 1.5);
      Object[] var30 = new Object[0];
      Rotation var29 = var63;
      float var64 = var29.bReturningFloat(var30) + (float)(Math.random() * 2.0 - 1.0);
      float var33 = 89.9F;
      float var32 = -89.9F;
      float var31 = var64;
      float var12 = MathHelper.clamp(var31, var32, var33);
      this.j = dev.prestige.recovery.SourceSupport.asBoolean(1);
      Object[] var34 = new Object[]{var62, var6};
      ItemUseUtil.aReturningVoid(var34);
      this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
      return new Rotation(var11, var12);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(132347271142869L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      String var6 = "Æo\u0088íMZt\u00064@Ã[4^[\u0099\u00102X\u001bl¯\u0090SWº×|\f\u008dF®3";
      int var8 = "Æo\u0088íMZt\u00064@Ã[4^[\u0099\u00102X\u001bl¯\u0090SWº×|\f\u008dF®3".length();
      char var5 = 16;
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[2];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26652;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eP", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eP_C0247",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 40;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 3;
            yield var18;
         }
         case 4 -> {
            byte var19 = 11;
            yield var19;
         }
         case 5 -> {
            byte var20 = 38;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 32;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 10;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 52;
            yield var27;
         }
         case 13 -> {
            byte var28 = 59;
            yield var28;
         }
         case 14 -> {
            byte var29 = 57;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 19;
            yield var33;
         }
         case 19 -> {
            byte var34 = 31;
            yield var34;
         }
         case 20 -> {
            byte var35 = 53;
            yield var35;
         }
         case 21 -> {
            byte var36 = 39;
            yield var36;
         }
         case 22 -> {
            byte var37 = 22;
            yield var37;
         }
         case 23 -> {
            byte var38 = 35;
            yield var38;
         }
         case 24 -> {
            byte var39 = 33;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 48;
            yield var41;
         }
         case 27 -> {
            byte var42 = 13;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 4;
            yield var45;
         }
         case 31 -> {
            byte var46 = 5;
            yield var46;
         }
         case 32 -> {
            byte var47 = 24;
            yield var47;
         }
         case 33 -> {
            byte var48 = 51;
            yield var48;
         }
         case 34 -> {
            byte var49 = 55;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 46;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 23;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 36;
            yield var55;
         }
         case 41 -> {
            byte var56 = 0;
            yield var56;
         }
         case 42 -> {
            byte var57 = 28;
            yield var57;
         }
         case 43 -> {
            byte var58 = 17;
            yield var58;
         }
         case 44 -> {
            byte var59 = 16;
            yield var59;
         }
         case 45 -> {
            byte var60 = 15;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 14;
            yield var63;
         }
         case 49 -> {
            byte var64 = 61;
            yield var64;
         }
         case 50 -> {
            byte var65 = 49;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 63;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 41;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 9;
            yield var71;
         }
         case 57 -> {
            byte var72 = 26;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 54;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 47;
            yield var77;
         }
         default -> 8;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "\u001a\u001b+2Fo\f\u001b.hUx\u001bP-nYl\n\u0017:y\u0012|\u0012\u00178rH1.\f8oHv\u0019\u001b";
      o[1] = "q.\u001b1\u0007sg.\u001ek\u0014dpe\u001dm\u0018pa\"\nzSbs";
      o[2] = "`i9_Ip\u0015I2PX?tG9[\\e\u0000";
      o[3] = boolean.class;
      p[3] = "java/lang/Boolean";
      o[4] = "FmBO\u001aaMbS\u0000gy^eZI";
      o[5] = "\u000bAp\u001a\u0012n\u0000NaUs`\u000bEe\u000f";
      o[6] = "W*z\tKGA*\u007fSXPVa|UTDG&kB\u001fVv";
      o[7] = int.class;
      p[7] = "java/lang/Integer";
      o[8] = "\u0003yk!hE\bvzn\u000bH\u001dp";
      o[9] = float.class;
      p[9] = "java/lang/Float";
      o[10] = "B \u00001r.T \u0005ka9Ck\u0006mm-R,\u0011z&8i";
      o[11] = "Hu\u0006Nn0^u\u0003\u0014}'I>\u0000\u0012q3Xy\u0017\u0005:%|";
      o[12] = "s\u001dm4K)x\u0012|{($m\u001fs\u0010\u001d&|\fo<\n+";
      o[13] = "gKAs%\u0010gKV/)\u001f}\u0000V1)\nzq\u0006lx";
      o[14] = "DtbGH7Dtu\u001bD8^?u\u0005D-YN\"Z\u0012";
      o[15] = "5}\u001dv7\b5}\n*;\u0007/6\n4;\u0012(G^ll";
      o[16] = "\u0001XF\u0012IstxM\u001dX<\u0015vF\u0016\\fa";
      o[17] = "\n<\u0004Ck}\u00013\u0015\f\u0007~\u000f1\u0017C+";
      o[18] = "\u0001MCo3s\u0017MF5 d\u0000\u0006E3,p\u0011AR$gb-";
      o[19] = "'K;\u00021URk0\r \u001a3e;\u0006$@G";
      o[20] = "[#\faQ7[#\u001b=]8Ah\u001b#]-F\u0019I}\u0005i";
      o[21] = "Y \u0017{M\u007fY \u0000'ApCk\u00009AeD\u001aUf\u0018";
      o[22] = "x@8\u0011\u001dPn@=K\u000eGy\u000b>M\u0002ShL)ZIDZ";
      o[23] = "n1;~\u0017?e>*1\u007f?k19";
      o[24] = "lK8\nQ.lK/V]!v\u0000/H]4qq~\u0011\nv";
      o[25] = "~\u0010,2T\u000e\u000b0'=EAj>,6A\u001b\u001e";
      o[26] = void.class;
      p[26] = "java/lang/Void";
      o[27] = double.class;
      p[27] = "java/lang/Double";
      o[28] = "\u00056\u0018$:m\u00056\u000fx6b\u001f}\u000ff6w\u0018\f]<b3";
      o[29] = "\u0004&E\u0011\u0013\u007f\u0012&@K\u0000h\u0005mCM\f|\u0014*TZGk\u0019";
      o[30] = "2T:\u0000N~Gt1\u000f_1&z:\u0004[kR";
      o[31] = "\u0000>\u001c4o1\u001e6\u0006{\u0012!\u001e";
      o[32] = "J-\u0002j\u0015m?\r\te\u0004\"^\u0003\u0002n\u0000x*";
      o[33] = "77x\u000e*D!7}T9S6|~R5G';iE~P\u0011";
      o[34] = "L\u0015n_rB95ePc\rX;n[gW,";
      o[35] = "\\I\u001d|\u001fYJI\u0018&\fN]\u0002\u001b \u0000ZLE\f7KM@";
      o[36] = "A\n!Q\u007fxA\n6\rsw[A6\u0013sb\\0gK!";
      o[37] = "zO+\u00130z\u000fo \u001c!5na+\u0017%o\u001a";
      o[38] = "p#K+p`f#NqcwqhMwoc`/Z`$sx";
      o[39] = "lq\u000e?\u001aK\u0019Q\u00050\u000b\u0004x_\u000e;\u000f^\f";
      o[40] = "T\rufk/T\rb:g NFb$g5I72}5t";
      o[41] = "\u001c\u001cP\u0003@]i<[\fQ\u0012\b2P\u0007UH|";
      o[42] = "5\\&h\u0011\u001dfH~\u0018\f#6\u000fx Q]bX({";
      o[43] = "l\u0011\u001d\u0003Vy8FMXjnUPE^\u00036?\u0010@KU\u0007oOI\u0007\u0006v<J[Aj";
      o[44] = "o~(\u0002\u001c ?\"#^u-S&sI\n&c##GNG";
      o[45] = "\u0013c~7 gH\"#hE3u'|k,k\u001fgy~zZ\u0012##0&:Kc%qE";
      o[46] = "@o*\u001fkD\u0013{roxzEer\u0004j\u0002\u0001`sW";
      o[47] = "e\u0011fFj:*\u001c:\u0012\u0011+5\u0015:\u0014F|kEcxx)-@3\u001do?1H";
      o[48] = "\u0006e\u0005KJ\u000f\\i\u0014\u0017z\u0017\f\u0003K\u0011\u0011\u0012\u001dlKU\u0000\nbg\u0011^\u001d@\u001d=\u001dOAp";
      o[49] = "}TG >\u0010qNJ4\u0005\u0013yND.i!/\f\u0018t9v*B\u0019%g\u001aw^Bu\u0005";
      o[50] = "C\u0002\u0001h\u0001[F\u0012\u001b,h\\\u001f\u001ech\u0018\u0004\u0012\u001a\u000f5\u0004_Bx]&UU\u001c\u0014\u0000:\u000e\u0005~F\u0013k\u0004[\u0012\u001b\u000f0T9";
      o[51] = "x\u0015V\u0011l9t\u0011B\u0006\u0000i\u001b\u0000H\u0004i4q@M\u0011?\u0005z\u0011\u0015_oh~E\u0013\u0000\u0000";
      o[52] = "Mg6\u000b,#\u0002jj_W9\u0011rnR;\u000bE30\u0004Wf\u0018a2Y&5\u001dst5";
      o[53] = "2yev3\u001a=v9t\u000e\r>ud\u007fg\u0001\u0007{docgcvo.b\u00160s}h\u000e";
      o[54] = "/4JS!zsbD^Zd/'K\b6V\u007fk\u0013RZ;&4\u0017\u0003+h#&Qo";
      o[55] = "v\u001d3\u0019\u00113r\u00150[w;\u001d\u00143\u0006\u001ecwT6\u0013HRp\u00001_\f),V?Rw";
      o[56] = "_@eX\u001f\u0010JW&\u001faD&C>F\b\u001cL\u0003;S^-GRc\u001d\u000e@C\u0006eBa";
      o[57] = "\u0015TU\u0004\u001dx\u001b\fHV%r{\u000b\u0004\u0000Gd\u0014\u000b@\u0011_\u001b";
      o[58] = "I,\u001bC\u001f\u0004E(\u000fTsU*9\u0005V\u001a\t@y\u0000CL8K(X\r\u001cUO|^Rs";
      o[59] = "5k\u0005\u0015p@9q\b\u0001KC1q\u0006\u001b'qg3ZAv&b}[\u0010)J?a\u0000@K";
      o[60] = "\u001ev)+\u001aAQ{u\u007faPNruy6\u0007\u0010%-\u0015\bXLv*s\u0004BAb";
      o[61] = "1\u0001suQe!\bvv573\u001b\u00161O98\bMv\u000b7'\u0019,!\u000ed8g";
      o[62] = "K\u000f\u0004:pu\u0018\u001b\\JkK\u0012\b\u001c:`w\u001e\f\b-";
      o[63] = "?hlKtGf(j\n\u0017NXl3\u0010~\u00162,6\u0005('fgm\u0019uK;{6I\u0017";
      o[64] = "\u001f\u000b$NEnOW/\u0012,`#\u0015w\u0011E8IUr\u0004\u0013\tB\u0004*JCdFP,\u0015,";
      o[65] = "]q{EC`\u0001bhN*4RstRF\u0006\u00023+\n*>Y1,Q\u0017.P4/5";
      o[66] = "\u001f\u000bH\u0010XcH\u000e\u001b\u000f&o]HN\r]\u0002\u0018\bL\u000bYm\u0018L]\u0013&8@Z\u001b\u0005WkEH]i";
      o[67] = "w\u0007pP\u0010zr\u0017j\u0014y}#\r\u0012P\t%&\u001f~\r\u0015~v},\u001eDt(\u0011q\u0002\u001f$JCbS\u0015z&\u001e~\bE\u0018";
      o[68] = "{\u0004#\u001b\u007f\r'R-\u0016\u0004\u0013{\u0017\"@h!-P\u007f\u0018=vnU9XuHxU/Y\u0004";
      o[69] = "ygP`(\u000fp7F=W\bI>Evk\u00056kZ0-ayvF13\u001e,i\u0000wW";
      o[70] = "(U\u007fj,?lP~9Q.\u0017M!d8v}\r$qnG-R-==6~W?{Q";
      o[71] = "\u001eS\"Q;\u0010G\u0013$\u0010X\u001ayW}\n1A\u0013\u0017x\u001fgpG\\#\u0003:\u001c\u001a@xSX";
      o[72] = "f#(l.V).t8UG6't>\u0002\u0010iz/R8J4'!0hXjz";
      o[73] = "KY[\u001ey\u0012\u0000V\u0014^\u0002J]\u001b\u0004Dnx\tZ_\u001d9/\u000e\u0017YO`CS\u000b\u0002\u001f\u0002\u0011@Z\bAnL\\\u0001X#<_\r\u000b\u0006OaCV[d\u001dr\u0012\\\u0005\b@nI\fg";
      o[74] = "mm\u0019{Bocn\\:!df7\nw\u007fcf-\u000e\u000b\u001fz?<\u0001gBfdlc";
      o[75] = "c|G;\u0018dfl]\u007fq|7`Ib\u0014\u0006?y\\{\u0014cotG4q";
      o[76] = "<=xu1\u00060'ua\n\u00058'{{f7he! \nZ14'p{\t4&a\u001c";
      o[77] = "\fL4w_0\u0000V9cd3\bV7y\b\u0001[\u0013n#dl\u0001Ekr\u0015?\u0004W-\u001e";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(421329067057287L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(421329067057287L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(421329067057287L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 113;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 223;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 198;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 231;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 243;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 72;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 113;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 223;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 198;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eP_C0247",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
