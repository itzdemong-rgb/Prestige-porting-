package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.EntityBoundingBoxEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class Hitboxes extends Module implements RotationSource {
   private BooleanSetting d;
   private FloatSetting a;
   private BooleanSetting c;
   private FloatSetting e;
   private ModeSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private boolean i;
   private boolean j;
   private static final long k = 74953467714361L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[119];
   private static final String[] p = new String[119];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public Hitboxes() {
      super();
      long var10001 = 81283264604531L ^ 27678724170463L;

      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
      BooleanSetting var10000 = this.g;
      Object[] var6 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var5 = var10000;
      var5.aReturningBooleanSetting(var6);
      var10000 = this.h;
      Object[] var8 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var7 = var10000;
      var7.aReturningBooleanSetting(var8);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 98209419914634L ^ 3970321706830L;
      var10001 = 98209419914634L ^ 62874775190926L;
      var10001 = 98209419914634L ^ 34182490053787L;
      int var10 = Event.cReturningInt();
      BooleanSetting var21 = this.c;
      Boolean var22 = (Boolean)var21.aReturningObject();
      boolean var73 = var22;
      if (var73) {
         Object[] var24 = new Object[]{77260333461777L};
         PlayerEntity var11 = EntityUtil.aReturningPlayerEntity(var24);
         FloatSetting var25 = this.e;
         Float var26 = (Float)var25.aReturningObject();
         float var12 = var26;
         ModeSetting var27 = this.f;
         String var10000 = (String)var27.aReturningObject();
         String var29 = "Grim/Vulcan";
         String var28 = var10000;
         byte var13 = ((byte)((var28.equals(var29)) ? 1 : 0));
         byte var74 = var13;
         double var63;
         if (var74 != 0) {
            FloatSetting var30 = this.a;
            Float var31 = (Float)var30.aReturningObject();
            double var75 = var31.floatValue() / 5.0;
            var63 = var75;
         } else {
            var63 = 0.0;
         }

         double var14 = var63;
         MinecraftClient var33 = b;
         ClientWorld var34 = var33.world;
         List var35 = var34.getPlayers();
         Iterator var16 = var35.iterator();

         while (true) {
            Iterator var36 = var16;
            boolean var77 = var36.hasNext();
            if (!var77) {
               break;
            }

            Iterator var37 = var16;
            PlayerEntity var17 = (PlayerEntity)var37.next();
            MinecraftClient var38 = b;
            PlayerEntity var40 = var17;
            ClientPlayerEntity var39 = var38.player;
            float var18 = var39.distanceTo((Entity)var40);
            float var104;
            int var96 = (var104 = var18 - var12) == 0.0F ? 0 : (var104 < 0.0F ? -1 : 1);
            int var79 = var10;
            int var78 = var96;
            int var66 = var78;
            int var65 = var78;
            if (var79 != 0) {
               int var80 = var65;
               if (var80 > 0) {
                  int var81 = var10;
                  if (var81 != 0) {
                     continue;
                  }
               }

               PlayerValidationTracker var97 = Prestige.i;
               Object[] var44 = new Object[]{var17, 99841884226244L};
               PlayerValidationTracker var43 = var97;
               var66 = (((var43.aReturningBoolean(var44)) ? 1 : 0));
            }

            int var83 = var10;
            int var82 = var66;
            int var68 = var82;
            int var67 = var82;
            if (var83 != 0) {
               int var84 = var67;
               if (var84 == 0) {
                  int var85 = var10;
                  if (var85 != 0) {
                     continue;
                  }
               }

               var68 = var13;
            }

            int var86 = var68;
            Box var69;
            if (var86 != 0) {
               PlayerEntity var47 = var17;
               Box var98 = var47.getBoundingBox();
               double var49 = var14;
               Box var48 = var98;
               Box var87 = var48.expand(var49);
               var69 = var87;
            } else {
               PlayerEntity var52 = var17;
               var69 = var52.getBoundingBox();
            }

            Box var19;
            Color var72;
            label61: {
               label60: {
                  var19 = var69;
                  float var105;
                  int var99 = (var105 = var18 - 3.0F) == 0.0F ? 0 : (var105 < 0.0F ? -1 : 1);
                  int var89 = var10;
                  int var88 = var99;
                  int var71 = var88;
                  int var70 = var88;
                  if (var89 != 0) {
                     int var90 = var70;
                     if (var90 > 0) {
                        break label60;
                     }

                     var71 = var13;
                  }

                  int var91 = var71;
                  if (var91 != 0) {
                     PlayerEntity var93 = var17;
                     PlayerEntity var92 = var11;
                     if (var92 == var93) {
                        Color var94 = Color.GREEN;
                        var72 = var94;
                        break label61;
                     }
                  }
               }

               var72 = Color.RED;
            }

            Color var20 = var72;
            RenderContext var100 = var1.b;
            MeshBufferManager var103 = var1.a;
            Box var56 = var19;
            float var10002 = (float)var56.minX;
            Box var57 = var19;
            float var10003 = (float)var57.minY;
            Box var58 = var19;
            float var10004 = (float)var58.minZ;
            Box var59 = var19;
            float var10005 = (float)var59.maxX;
            Box var60 = var19;
            float var10006 = (float)var60.maxY;
            Box var61 = var19;
            float var10007 = (float)var61.maxZ;
            Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var20, 106090074574852L};
            var10011[7] = var10007;
            var10011[6] = var10006;
            var10011[5] = var10005;
            var10011[4] = var10004;
            var10011[3] = var10003;
            var10011[2] = var10002;
            var10011[1] = var103;
            var10011[0] = var100;
            Object[] var62 = var10011;
            ShapeRenderer.gReturningVoid(var62);
            int var95 = var10;
            if (var95 == 0) {
               break;
            }
         }
      }
   }

   @EventListener
   public void a(EntityBoundingBoxEvent var1) {
      long var10001 = 132217892627719L ^ 37993826936771L;
      int var6 = Event.bReturningInt();
      ModeSetting var7 = this.f;
      String var10000 = (String)var7.aReturningObject();
      String var9 = "None";
      String var8 = var10000;
      byte var84 = ((byte)((var8.equals(var9)) ? 1 : 0));
      int var64 = var6;
      byte var63 = var84;
      byte var52 = var63;
      byte var51 = var63;
      if (var64 == 0) {
         byte var65 = var51;
         if (var65 == 0) {
            return;
         }

         Object[] var12 = new Object[0];
         EntityBoundingBoxEvent var11 = var1;
         Entity var85 = var11.aReturningEntity(var12);
         MinecraftClient var13 = b;
         ClientPlayerEntity var15 = var13.player;
         Entity var14 = var85;
         var52 = ((byte)((var14.equals(var15)) ? 1 : 0));
      }

      int var67 = var6;
      byte var66 = var52;
      byte var54 = var66;
      byte var53 = var66;
      if (var67 == 0) {
         byte var68 = var53;
         if (var68 != 0) {
            return;
         }

         BooleanSetting var17 = this.d;
         Boolean var18 = (Boolean)var17.aReturningObject();
         var54 = ((byte)(((java.lang.Boolean)(var18)).booleanValue() ? 1 : 0));
      }

      byte var58;
      int var70 = var6;
      byte var69 = var54;
      var58 = var69;
      byte var55 = var69;
      label56:
      if (var70 == 0) {
         byte var71 = var55;
         if (var71 != 0) {
            Object[] var21 = new Object[0];
            EntityBoundingBoxEvent var20 = var1;
            byte var86 = ((byte)((var20.aReturningEntity(var21) instanceof PlayerEntity) ? 1 : 0));
            int var73 = var6;
            byte var72 = var86;
            var58 = var72;
            byte var56 = var72;
            if (var73 != 0) {
               break label56;
            }

            byte var74 = var56;
            byte var57 = var74;
            byte var75 = var57;
            if (var75 == 0) {
               return;
            }
         }

         Object[] var25 = new Object[0];
         EntityBoundingBoxEvent var24 = var1;
         var58 = ((byte)((var24.aReturningEntity(var25) instanceof PlayerEntity) ? 1 : 0));
      }

      byte var62;
      int var77 = var6;
      byte var76 = var58;
      var62 = var76;
      byte var59 = var76;
      label49:
      if (var77 == 0) {
         byte var78 = var59;
         if (var78 != 0) {
            PlayerValidationTracker var87 = Prestige.i;
            Object[] var28 = new Object[0];
            EntityBoundingBoxEvent var27 = var1;
            Object[] var30 = new Object[]{(PlayerEntity)var27.aReturningEntity(var28), 99841884226244L};
            PlayerValidationTracker var29 = var87;
            byte var88 = ((byte)((var29.aReturningBoolean(var30)) ? 1 : 0));
            int var80 = var6;
            byte var79 = var88;
            var62 = var79;
            byte var60 = var79;
            if (var80 != 0) {
               break label49;
            }

            byte var81 = var60;
            byte var61 = var81;
            byte var82 = var61;
            if (var82 == 0) {
               return;
            }
         }

         MinecraftClient var33 = b;
         ClientPlayerEntity var89 = var33.player;
         Object[] var35 = new Object[0];
         EntityBoundingBoxEvent var34 = var1;
         Entity var37 = var34.aReturningEntity(var35);
         ClientPlayerEntity var36 = var89;
         float var90 = var36.distanceTo(var37);
         FloatSetting var38 = this.e;
         Float var39 = (Float)var38.aReturningObject();
         float var92;
         var62 = (byte)((var92 = var90 - var39) == 0.0F ? 0 : (var92 < 0.0F ? -1 : 1));
      }

      byte var83 = var62;
      if (var83 <= 0) {
         Object[] var41 = new Object[0];
         EntityBoundingBoxEvent var40 = var1;
         Box var91 = var40.aReturningBox(var41);
         FloatSetting var42 = this.a;
         Float var43 = (Float)var42.aReturningObject();
         double var45 = var43.floatValue() / 5.0;
         Box var44 = var91;
         Object[] var48 = new Object[]{var44.expand(var45)};
         EntityBoundingBoxEvent var47 = var1;
         var47.bReturningVoid(var48);
         Object[] var50 = new Object[0];
         EntityBoundingBoxEvent var49 = var1;
         var49.aReturningVoid(var50);
      }
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      long var10001 = 67593203139167L ^ 4927767442502L;
      var10001 = 67593203139167L ^ 135503372874574L;
      int var8 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      AttackAttemptEvent var12 = var1;
      EventPhase var10000 = var12.aReturningEventPhase(var13);
      int var81 = var8;
      EventPhase var80 = var10000;
      Object var66 = var80;
      EventPhase var65 = var80;
      if (var81 == 0) {
         EventPhase var83 = EventPhase.PRE;
         EventPhase var82 = var65;
         if (var82 != var83) {
            return;
         }

         ModeSetting var16 = this.f;
         var66 = var16.aReturningObject();
      }

      String var113 = (String)var66;
      String var18 = "Grim/Vulcan";
      String var17 = var113;
      boolean var114 = var17.equals(var18);
      int var85 = var8;
      boolean var84 = var114;
      boolean var68 = var84;
      boolean var67 = var84;
      if (var85 == 0) {
         boolean var86 = var67;
         if (!var86) {
            return;
         }

         var68 = this.j;
      }

      boolean var87 = var68;
      if (var87) {
         Object[] var21 = new Object[]{true};
         AttackAttemptEvent var20 = var1;
         var20.bReturningVoid(var21);
      } else {
         MinecraftClient var23 = b;
         HitResult var9 = var23.crosshairTarget;
         int var89 = var8;
         HitResult var88 = var9;
         HitResult var70 = var88;
         HitResult var69 = var88;
         if (var89 == 0) {
            HitResult var90 = var69;
            if (var90 == null) {
               return;
            }

            var70 = var9;
         }

         HitResult var25 = var70;
         Type var115 = var25.getType();
         Type var92 = Type.MISS;
         Type var91 = var115;
         if (var91 == var92) {
            Object[] var27 = new Object[]{77260333461777L};
            PlayerEntity var10 = EntityUtil.aReturningPlayerEntity(var27);
            PlayerEntity var93 = var10;
            if (var93 != null) {
               MinecraftClient var28 = b;
               PlayerEntity var30 = var10;
               ClientPlayerEntity var29 = var28.player;
               float var121;
               int var116 = (var121 = var29.distanceTo((Entity)var30) - 3.0F) == 0.0F ? 0 : (var121 < 0.0F ? -1 : 1);
               int var95 = var8;
               int var94 = var116;
               int var73 = var94;
               int var71 = var94;
               if (var95 == 0) {
                  int var96 = var71;
                  int var72 = var96;
                  int var97 = var72;
                  if (var97 > 0) {
                     return;
                  }

                  BooleanSetting var33 = this.g;
                  Boolean var34 = (Boolean)var33.aReturningObject();
                  byte var98 = ((byte)(((java.lang.Boolean)(var34)).booleanValue() ? 1 : 0));
                  var73 = var98;
               }

               int var77;
               int var100 = var8;
               int var99 = var73;
               var77 = var99;
               int var74 = var99;
               label79:
               if (var100 == 0) {
                  int var101 = var74;
                  if (var101 == 0) {
                     MinecraftClient var37 = b;
                     PlayerEntity var39 = var10;
                     ClientPlayerEntity var38 = var37.player;
                     byte var117 = ((byte)((var38.canSee((Entity)var39)) ? 1 : 0));
                     int var103 = var8;
                     byte var102 = var117;
                     var77 = var102;
                     byte var75 = var102;
                     if (var103 != 0) {
                        break label79;
                     }

                     byte var104 = var75;
                     byte var76 = var104;
                     byte var105 = var76;
                     if (var105 == 0) {
                        return;
                     }
                  }

                  BooleanSetting var42 = this.h;
                  Boolean var43 = (Boolean)var42.aReturningObject();
                  var77 = ((((java.lang.Boolean)(var43)).booleanValue() ? 1 : 0));
               }

               label64: {
                  int var107 = var8;
                  int var106 = var77;
                  int var79 = var106;
                  int var78 = var106;
                  if (var107 == 0) {
                     int var108 = var78;
                     if (var108 == 0) {
                        break label64;
                     }

                     Object[] var46 = new Object[]{var10, 62683186411033L};
                     Hitboxes var45 = this;
                     byte var109 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
                     var79 = var109;
                  }

                  int var110 = var79;
                  if (var110 != 0) {
                     return;
                  }
               }

               PlayerEntity var48 = var10;
               Box var118 = var48.getBoundingBox();
               FloatSetting var49 = this.a;
               Float var50 = (Float)var49.aReturningObject();
               double var52 = var50.floatValue() / 5.0;
               Box var51 = var118;
               Box var11 = var51.expand(var52);
               int var111 = var8;
               if (var111 == 0) {
                  MinecraftClient var54 = b;
                  ClientPlayerEntity var55 = var54.player;
                  Vec3d var120 = var55.getEyePos();
                  HitResult var56 = var9;
                  Vec3d var59 = var56.getPos();
                  Vec3d var58 = var120;
                  Box var57 = var11;
                  Optional var60 = var57.raycast(var58, var59);
                  boolean var112 = var60.isEmpty();
                  if (var112) {
                     return;
                  }

                  this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  Object[] var64 = new Object[0];
                  AttackAttemptEvent var63 = var1;
                  var63.aReturningVoid(var64);
               }
            }
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 5989609627257L;
      long var6 = var2 ^ 77379818547405L;
      long var8 = var2 ^ 134366226930033L;
      long var10 = var2 ^ 101783648619701L;
      long var12 = var2 ^ 100729554575240L;
      int var14 = Event.bReturningInt();
      ModeSetting var21 = this.f;
      String var10000 = (String)var21.aReturningObject();
      short var10001 = 22648;
      long var10002 = 170105157263869836L ^ var2;
      String var23 = "Grim/Vulcan";
      String var22 = var10000;
      boolean var148 = var22.equals(var23);
      int var115 = var14;
      boolean var114 = var148;
      boolean var99 = var114;
      boolean var98 = var114;
      if (var115 == 0) {
         boolean var116 = var98;
         if (!var116) {
            return null;
         }

         var99 = this.i;
      }

      boolean var117 = var99;
      if (!var117) {
         return null;
      }

      MinecraftClient var27 = b;
      HitResult var15 = var27.crosshairTarget;
      int var118 = var14;
      if (var118 == 0) {
         HitResult var119 = var15;
         if (var119 != null) {
            HitResult var29 = var15;
            Type var149 = var29.getType();
            Type var121 = Type.MISS;
            Type var120 = var149;
            if (var120 == var121) {
               Object[] var32 = new Object[]{var8};
               PlayerEntity var16 = EntityUtil.aReturningPlayerEntity(var32);
               int var122 = var14;
               if (var122 == 0) {
                  PlayerEntity var123 = var16;
                  label79:
                  if (var123 != null) {
                     MinecraftClient var34 = b;
                     PlayerEntity var36 = var16;
                     ClientPlayerEntity var35 = var34.player;
                     float var155;
                     int var150 = (var155 = var35.distanceTo((Entity)var36) - 3.0F) == 0.0F ? 0 : (var155 < 0.0F ? -1 : 1);
                     int var125 = var14;
                     int var124 = var150;
                     int var102 = var124;
                     int var100 = var124;
                     if (var125 == 0) {
                        int var126 = var100;
                        int var101 = var126;
                        int var127 = var101;
                        if (var127 > 0) {
                           break label79;
                        }

                        BooleanSetting var39 = this.g;
                        Boolean var40 = (Boolean)var39.aReturningObject();
                        byte var128 = ((byte)(((java.lang.Boolean)(var40)).booleanValue() ? 1 : 0));
                        var102 = var128;
                     }

                     int var106;
                     int var130 = var14;
                     int var129 = var102;
                     var106 = var129;
                     int var103 = var129;
                     label86:
                     if (var130 == 0) {
                        int var131 = var103;
                        if (var131 == 0) {
                           MinecraftClient var43 = b;
                           PlayerEntity var45 = var16;
                           ClientPlayerEntity var44 = var43.player;
                           byte var151 = ((byte)((var44.canSee((Entity)var45)) ? 1 : 0));
                           int var133 = var14;
                           byte var132 = var151;
                           var106 = var132;
                           byte var104 = var132;
                           if (var133 != 0) {
                              break label86;
                           }

                           byte var134 = var104;
                           byte var105 = var134;
                           byte var135 = var105;
                           if (var135 == 0) {
                              break label79;
                           }
                        }

                        BooleanSetting var49 = this.h;
                        Boolean var50 = (Boolean)var49.aReturningObject();
                        var106 = ((((java.lang.Boolean)(var50)).booleanValue() ? 1 : 0));
                     }

                     Hitboxes var111;
                     label105: {
                        label67: {
                           int var137 = var14;
                           int var136 = var106;
                           int var110 = var136;
                           int var107 = var136;
                           if (var137 == 0) {
                              int var138 = var107;
                              if (var138 == 0) {
                                 break label67;
                              }

                              int var140 = var14;
                              Hitboxes var139 = this;
                              var111 = var139;
                              Hitboxes var108 = var139;
                              if (var140 != 0) {
                                 break label105;
                              }

                              Hitboxes var141 = var108;
                              Hitboxes var109 = var141;
                              Object[] var54 = new Object[]{var16, var4};
                              Hitboxes var53 = var109;
                              byte var142 = ((byte)((var53.aReturningBoolean(var54)) ? 1 : 0));
                              var110 = var142;
                           }

                           int var143 = var110;
                           if (var143 != 0) {
                              var111 = this;
                              break label105;
                           }
                        }

                        PlayerEntity var56 = var16;
                        Box var152 = var56.getBoundingBox();
                        FloatSetting var57 = this.a;
                        Float var58 = (Float)var57.aReturningObject();
                        double var60 = var58.floatValue() / 5.0;
                        Box var59 = var152;
                        Box var17 = var59.expand(var60);
                        HitResult var62 = var15;
                        Vec3d var18 = var62.getPos();
                        Vec3d var63 = var18;
                        Box var64 = var17;
                        Box var65 = var17;
                        double var70 = var65.maxX;
                        double var68 = var64.minX;
                        double var66 = var63.x;
                        double var154 = MathHelper.clamp(var66, var68, var70);
                        Vec3d var72 = var18;
                        Box var73 = var17;
                        Box var74 = var17;
                        double var79 = var74.maxY;
                        double var77 = var73.minY;
                        double var75 = var72.y;
                        double var10003 = MathHelper.clamp(var75, var77, var79);
                        Vec3d var81 = var18;
                        Box var82 = var17;
                        Box var83 = var17;
                        double var88 = var83.maxZ;
                        double var86 = var82.minZ;
                        double var84 = var81.z;
                        Vec3d var19 = new Vec3d(var154, var10003, MathHelper.clamp(var84, var86, var88));
                        RotationManager var153 = Prestige.o;
                        Object[] var91 = new Object[]{var19, var6};
                        RotationManager var90 = var153;
                        Rotation var20 = var90.aReturningdx_C0210(var91);
                        Object[] var92 = new Object[]{var20, var19, var10};
                        var20 = RotationUtil.dReturningdx_C0210(var92);
                        int var145 = var14;
                        Rotation var144 = var20;
                        Rotation var113 = var144;
                        Rotation var112 = var144;
                        if (var145 == 0) {
                           Object[] var94 = new Object[0];
                           Rotation var93 = var112;
                           boolean var146 = var93.aReturningBoolean(var94);
                           if (var146) {
                              return var20;
                           }

                           this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                           this.j = dev.prestige.recovery.SourceSupport.asBoolean(1);
                           Object[] var97 = new Object[]{var16, var12};
                           ItemUseUtil.aReturningVoid(var97);
                           this.j = dev.prestige.recovery.SourceSupport.asBoolean(0);
                           var113 = var20;
                        }

                        return var113;
                     }

                     var111.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
                     return null;
                  }

                  this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
               }

               return null;
            }
         }

         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      }

      return null;
   }

   private boolean aReturningBoolean(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 74953467714361L ^ var3;
      int var5 = Event.cReturningInt();
      int var20 = var5;
      PlayerEntity var19 = var2;
      PlayerEntity var13 = var19;
      PlayerEntity var12 = var19;
      if (var20 != 0) {
         PlayerEntity var21 = var12;
         if (var21 == null) {
            return false;
         }

         var13 = var2;
      }

      PlayerEntity var7 = var13;
      byte var30 = ((byte)((var7.isUsingItem()) ? 1 : 0));
      int var23 = var5;
      byte var22 = var30;
      byte var15 = var22;
      byte var14 = var22;
      if (var23 != 0) {
         byte var24 = var14;
         if (var24 == 0) {
            return false;
         }

         PlayerEntity var9 = var2;
         ItemStack var31 = var9.getActiveItem();
         Item var11 = Items.SHIELD;
         ItemStack var10 = var31;
         byte var25 = ((byte)((var10.isOf(var11)) ? 1 : 0));
         var15 = var25;
      }

      int var27 = var5;
      byte var26 = var15;
      byte var17 = var26;
      byte var16 = var26;
      if (var27 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var17);
      } else {
         byte var28 = var16;
         if (var28 != 0) {
            var17 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var17);
         } else {
            return false;
         }
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Grim/Vulcan";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.f;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Grim/Vulcan";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(50690965211884L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      String var6 = "wÈÖe\u008c¥\fÞfX!\u0083í\u0006½\u008bI¼ù]\n3\u001f¦þwkWéõÖ\u001a\u0010\u0090\u009e\u0002$%Å\u0095¸\u008dDp}\u0082uöÞ \u000f,F\u008e\u0092é*\t\u0087T³È!¢æl\u00811(TÔG±¥ÃÞqOÏ\u0005\u0095)";
      int var8 = "wÈÖe\u008c¥\fÞfX!\u0083í\u0006½\u008bI¼ù]\n3\u001f¦þwkWéõÖ\u001a\u0010\u0090\u009e\u0002$%Å\u0095¸\u008dDp}\u0082uöÞ \u000f,F\u008e\u0092é*\t\u0087T³È!¢æl\u00811(TÔG±¥ÃÞqOÏ\u0005\u0095)"
         .length();
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[3];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 30614;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eQ", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eQ_C0249",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 18;
            yield var16;
         }
         case 2 -> {
            byte var17 = 22;
            yield var17;
         }
         case 3 -> {
            byte var18 = 47;
            yield var18;
         }
         case 4 -> {
            byte var19 = 54;
            yield var19;
         }
         case 5 -> {
            byte var20 = 44;
            yield var20;
         }
         case 6 -> {
            byte var21 = 5;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 9;
            yield var23;
         }
         case 9 -> {
            byte var24 = 2;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 57;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 1;
            yield var28;
         }
         case 14 -> {
            byte var29 = 34;
            yield var29;
         }
         case 15 -> {
            byte var30 = 11;
            yield var30;
         }
         case 16 -> {
            byte var31 = 27;
            yield var31;
         }
         case 17 -> {
            byte var32 = 26;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 39;
            yield var34;
         }
         case 20 -> {
            byte var35 = 58;
            yield var35;
         }
         case 21 -> {
            byte var36 = 29;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 6;
            yield var38;
         }
         case 24 -> {
            byte var39 = 41;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 19;
            yield var41;
         }
         case 27 -> {
            byte var42 = 35;
            yield var42;
         }
         case 28 -> {
            byte var43 = 37;
            yield var43;
         }
         case 29 -> {
            byte var44 = 62;
            yield var44;
         }
         case 30 -> {
            byte var45 = 48;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 49;
            yield var48;
         }
         case 34 -> {
            byte var49 = 32;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 42;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 61;
            yield var53;
         }
         case 39 -> {
            byte var54 = 12;
            yield var54;
         }
         case 40 -> {
            byte var55 = 38;
            yield var55;
         }
         case 41 -> {
            byte var56 = 55;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 8;
            yield var58;
         }
         case 44 -> {
            byte var59 = 43;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 60;
            yield var61;
         }
         case 47 -> {
            byte var62 = 7;
            yield var62;
         }
         case 48 -> {
            byte var63 = 50;
            yield var63;
         }
         case 49 -> {
            byte var64 = 51;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 15;
            yield var66;
         }
         case 52 -> {
            byte var67 = 13;
            yield var67;
         }
         case 53 -> {
            byte var68 = 4;
            yield var68;
         }
         case 54 -> {
            byte var69 = 53;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 59;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 36;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 3;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "T*8\u001c[\u0015_%)S&\rL\" \u001a";
      o[1] = "&LR)bJ-CCf\u0003D&HG<";
      o[2] = boolean.class;
      p[2] = "java/lang/Boolean";
      o[3] = "\rqa,X\u0002\u001bqdvK\u0015\f:gpG\u0001\u001d}pg\f\u0016/";
      o[4] = "A\fPC;\u0000W\fU\u0019(\u0017@GV\u001f$\u0003Q\u0000A\bo\u0014\\";
      o[5] = "Hl\u001dm\u0014c=L\u0016b\u0005,\\B\u001di\u0001v(";
      o[6] = void.class;
      p[6] = "java/lang/Void";
      o[7] = ";'\u000fBy\"-'\n\u0018j5:l\t\u001ef!++\u001e\t-13+\u001c\u0002w|\u000f0\u001c\u001fw;8'";
      o[8] = "G#nU7\u001bQ#k\u000f$\fFhh\t(\u0018W/\u007f\u001ec\u000er";
      o[9] = "o\u0016*37pd\u0019;|T}q\u00144\u0017a\u007f`\u0007(;vr";
      o[10] = "+8<\u0002/h=89X<\u007f*s:^0k;4-I{y\n";
      o[11] = int.class;
      p[11] = "java/lang/Integer";
      o[12] = "\u0004L9\u0001!y\u0004L.]-v\u001e\u0007.C-c\u0019v|\u0019y'";
      o[13] = "}x\u0018YS{}x\u000f\u0005_tg3\u000f\u001b_a`B]@\u0007+";
      o[14] = "\r-@\u0011\u00148\r-WM\u00187\u0017fWS\u0018\"\u0010\u0017\u0005\u0007Ic";
      o[15] = "H\u0004\u0017}WCH\u0004\u0000![LRO\u0000?[YU>Rd\u0003\u0018";
      o[16] = ">Q>\u0013Hr>Q)OD}$\u001a)QDh#kx\u000e\u001d";
      o[17] = double.class;
      p[17] = "java/lang/Double";
      o[18] = "s\u0001OvgTs\u0001X*k[iJX4kNn;\tk3\u0019~\bZ+yb/P\u000b";
      o[19] = "l\u0007^.Wj\u0019'U!F%x)^*B\u007f\f";
      o[20] = "}\u001c6\u0015#\u000ev\u0013'ZO\rx\u0011%\u0015c";
      o[21] = "\u0015\fH%;\u001f\u0003\fM\u007f(\b\u0014GNy$\u001c\u0005\u0000Yno\f\u001d";
      o[22] = "ef/>l\u0002\u0010F$1}MqH/:y\u0017\u0005";
      o[23] = "\\IB?l&\\IUc`)F\u0002U}`<As\u0004%2";
      o[24] = "\u0001<\u001f\u001b\u0003Y\u0001<\bG\u000fV\u001bw\bY\u000fC\u001c\u0006\\\u0001X";
      o[25] = "\u0007qj@\u001e.\u0007q}\u001c\u0012!\u001d:}\u0002\u00124\u001aK/\\Jp";
      o[26] = float.class;
      p[26] = "java/lang/Float";
      o[27] = "[=1\u0007|5[=&[p:Av&Ep/F\u0007w\u001a(";
      o[28] = "`+3/\u000f\u000f`+$s\u0003\u0000z`$m\u0003\u0015}\u0011t0R";
      o[29] = "F$FH2nP$C\u0012!yGo@\u0014-mV(W\u0003fz`";
      o[30] = "alS?\u0002 \u0014LX0\u0013ouBS;\u00175\u0001";
      o[31] = "XO-:kkNO(`x|Y\u0004+fthHC<q?\u007fD";
      o[32] = "\u0011@-U'+\u0011@:\t+$\u000b\u000b:\u0017+1\fzjNyp";
      o[33] = "\u007f8r\u0019Kbi8wCXu~stETao4cR\u001ftN";
      o[34] = "b1+\u000614\u0017\u0011 \t {v\u001f+\u0002$!\u0002";
      o[35] = "er\u001e7%@\u0010R\u001584\u000fq\\\u001e30U\u0005";
      o[36] = "gHo\rPulG~B8ubHm";
      o[37] = "#3b'>zV\u0013i(/57\u001db#+oC";
      o[38] = "|\u0012lMd*j\u0012i\u0017w=}Yj\u0011{)l\u001e}\u00060;W";
      o[39] = "\u0019P\u0018\rO\u0014lp\u0013\u0002^[\r~\u0018\tZ\u0001y";
      o[40] = "B\rp\u0012*4T\ruH9#CFvN57R\u0001aY~%@";
      o[41] = "\u0001#\rT\u001eHt\u0003\u0006[\u000f\u0007\u0015\r\rP\u000b]a";
      o[42] = "~Z5\u0012=T\u000bz>\u001d,\u001bjt5\u0016(A\u001e";
      o[43] = "GqV\\-K2Q]S<\u0004S_VX8^'";
      o[44] = "P\u0006Se\f*%&Xj\u001deD(Sa\u0019?0";
      o[45] = " \u000b-*n\u000f6\u000b(p}\u0018!@+vq\f0\u0007<a:\u001b\f";
      o[46] = "TX_kS_!xTdB\u0010@v_oFJ4";
      o[47] = "\u0014SS;si\n[It\u0012l\n[J4<p";
      o[48] = ">s\u00176u\u0012KS\u001c9d]*]\u00172`\u0007^";
      o[49] = "/;S'\u000eq9;V}\u001df.pU{\u0011r?7BlZv";
      o[50] = "#*@qEH5*E+V_\"aF-ZK3&Q:\u0011Z\u0006";
      o[51] = "\u0006y]b0QsYVm!\u001e\u0012W]f%Df";
      o[52] = "0+}N\\\u001dE\u000bvAMR$\u0005}JI\bP";
      o[53] = "~W\u0002(p^`_\u0018g\u0012BgB";
      o[54] = "!\u0015x\u0015:Z?\u001dbZ][.\u0006o\u0000{]";
      o[55] = "\u001b19z\u000e;\u001b1.&\u00024\u0001z.8\u0002!\u0006\u000b{g[";
      o[56] = "\u001c6>JT~\u0001#fh\u0015s\u0019%";
      o[57] = "\u0006F\u0004`<@\u0010F\u0001:/W\u0007\r\u0002<#C\u0016J\u0015+hT\u0014";
      o[58] = "\t{A\"[\t|[J-JF\u001dUA&N\u001ci";
      o[59] = "BpA-{\u0015Ja^0\u0005@;5\u0010.|IBeH;bI;0\u0011(\u007f\u0013ZuWe=*";
      o[60] = "\u0017(f\u0013A,O{\u007f\u0018(+*kj\u0014W'Ft8EH";
      o[61] = "_)\u000e2\u001bF@{_-vC$yR6\u000fI])\n#\u0011I$y\u0015,\u000fQY\"\u001f1\t*";
      o[62] = "9\t{\u000bOf8\u001a \u001c~g2\u0005#\u001c)0hR}p\u0014x3\u0014<\u000e\u00185-\u0007";
      o[63] = "x\u0007=Et\u00076\u0004kJ\u0015\u0013\u0006S1]l\u0019\u007f\u0003iHr\u0019\u0006\u0014`\u0016v\u001b{Zc@yz";
      o[64] = "bKY\u0014!B;\u000fO@Y\u001b_\u000bRMaNaVM\u0014!raQT\u0017eL<N\rWY";
      o[65] = "oAn\u0019d47R5\u001a\u001ciU\u00067\fef,Vo\u0019{fU\u00036\nf<4FpG$\u0005";
      o[66] = "m3UG&jnlRG&\u00035vTM1\u007f3p9\u000eax(3HW9;.;9";
      o[67] = "\u0017]\u000e6C;\u0016^S.|\"z\u001b\f1\u0005(\u0003KT$\u001b(z\u001e\r7\u0006r\u001b[KzDK";
      o[68] = "\u0014fB'G,Ic\u0011h+?\rw\u0015=PRM6\u0013'Tb\u0015lF\"+k\u000fk\u0005\"V0\u0005v\u0003Y";
      o[69] = ">\u0003MPE$;\u0002JP<|2\u0003T\u0007PNf@\u000bP\u0000\u00190\u001f\u000bZY f\u0019H\u0018<";
      o[70] = "C\nxjRV\u001aR;lZ'\u001c^sjk\u001eF\\}i[F\u001c\tx\u0016";
      o[71] = "i$S}o\n7tNgW\u001cV,\u0000{.\u0016/|Xn0\u0016V)\u0001}-L7lG0ou";
      o[72] = "K\u0019\u0018\u0007dNJ\nC\u0010UO@\u0015@\u0010\u0002\u0018\u001aB\u001d|?PA\u0004_\u00023\u001d_\u0017";
      o[73] = "0\u0015\u0019*W\u0003(\n\u0016 :\u00038\u0012\u0017,V1lSLv\u0002f?\u001f\u00177A\u00183R\t$:\f$\u000e\u000b0D\u0000i\u0010\u0018KP\u00175\u0012\f5\\Z+\u0001w!K\u0006)\u0015\t-\u0006\u0018:n";
      o[74] = "^~7\u0016m\n\u0005+r\u0012c2\u0002)1\u001bi^0}}G3\fg}t\u0017~L\u000e~+\u0010~Lg";
      o[75] = "\u0002!Zu\u001c4Xg\u0003%`0\u000fg\u0000#\f\u0002Y ]{YU\r{_~\u0005l[}\u001c<`";
      o[76] = "\r\u0014\tfnJ\u0012\u0014N_bQ\u001f\u001b\u0014$\u000f\u0011^\u001d\u000e ?I\u0004H\u000b_6S\u0003\u000b\u000b\"mY\u001e\rp";
      o[77] = "l0e%.\u000e:6&gKYb=>s\u001c\u000e8m`\u001f!Fc,!a-\u000b}?";
      o[78] = "#jQc\b\u001eul\u0012!mI-g\n5:\u001ew7WY\u0007V,v\u0015'\u000b\u001b2e";
      o[79] = "m,Jwq\u0017l?\u0011`@\u0016f \u0012`\u0017A<wN\f*\tg1\rr&Dy\"";
      o[80] = "bl~M\u0015+y)~Iuxa|z_\"/?/#3\u0014jy!g\u000e\u0011k~!";
      o[81] = ";\u0018\u001aU1\u0018m\u0012\u000b\u000fvwMx%}Hw;\u0018\u001aU1\u0018m\u0012\u000b\u000fv";
      o[82] = "RNx\u0000/<\\Dc\r\u00135 \u001d%\u0004j<YM}\u0011t< \u0018$\u0002ifA]bO+_";
      o[83] = "\u001b|GpJ:\u00009Gt*i\u0018lCb}>G1\u0018\u000e\u0013=\u0003lD6HhFhJ";
      o[84] = "q%P+\u0010/f \u0012%n8\u0014$\u0012o\u00172mtJz\t2\u0014$Uu\u0017*i\u007f_h\u0011Q";
      o[85] = "9T@\u001bZ88G\u001b\fk92X\u0018\f<nh\u000fG`\u0001&3I\u0007\u001e\rk-Z";
      o[86] = "\u0019IR\u0014\u0012S\u001cHU\u0014k\u000b\u0015IKC\u00079A\n\u0014\u0014Pn\u0013T\u0013Y\u0004V\u0003\u000eM\u0015k";
      o[87] = "o\u001aZ\u001bP-9K\bV\u001fR9&XZ\u001b+5_\b\u0002\u000e55&][\u001d(oG\u0018\u001dPjV";
      o[88] = "\u0018J\u001a:1N\u0013Z\u001fm[IEI\u000577{\u0015\u0005_a[FI\t\u001ea4GZR\tP";
      o[89] = "3S0+sZ8C5|\u0019]nP/&uo=\u0015v|\u0019\u0001xM6:dZrP0A";
      o[90] = "M\u001btdqFE\nky\u000f\u00104^%gv\u001aM\u000e}rh\u001a4\u0007u\"q\u0015JZpq>y";
      o[91] = "a\u007f|z\u000fa?/a`7t^~*>Uo/u}{L\u001e";
      o[92] = "@DRI|G^@R\u0002\u0013\u001cDq\tAo\f?\u0005\u0017Xj\u0006B^\u001dEl}";
      o[93] = "o1\u000e9e^\u007fkPu\n\be=R(]_?k\rDa\u0007<-Y|q]ba";
      o[94] = "s[i@\u0011&-\u000btZ)0LS:FP:5\u0003bSN:L\u001b9W\u0016\"/\u0006z\u0006XY";
      o[95] = "\u001as\u001e&8rD#\u0003<\u0000f%rHbb|Ty\u001f'{\r";
      o[96] = "\u0014\u0011k\u000f2=MU}[Jd)V8O3nP\u0006`Z-n)V\u007fU3vT\ruH5\r";
      o[97] = "L3\u0002a?h^-Vy\u0001mF:\b~ha\u007f4\bnl\u0007\u0018&\rjzzC,\u0010l\u0001";
      o[98] = "Ja>N:\u000fKreY\u000b\u0005M|bRg7\u0011185d\u0000\u001f:g\f2\u0006\\x\u0002Zk_\u001ae;\fm\u001cX\u0000}M5\u0010O:cI5[ ";
      o[99] = "j M\u0019\u0016Ih<O\u0015|ZPwN\u0007\u0002L`/\u0014R\u00073";
      o[100] = "P\u001b\u001bJ5g\u0006\u001dX\bP0^\u0016@\u001c\u0007g\u0004F\u001cp:/_\u0007_\u000e6bA\u0014";
      o[101] = "j9\u0004\u001f6\u00190\u007f]OJ\u001dg\u007f^I&/7<\u0005\u001fJ\u0018f=@B4Ecn\u000f.+DolRE!D`q>";
      o[102] = "c'Z\u0010gc;4\u0001\u0013\u001f?Y`\u0003\u0005f1 0[\u0010x1Ye\u0002\u0003ek8 DN'R";
      o[103] = "\\k^R\u0007\u001f\u0006-\u0007\u0002{\u001bQ-\u0004\u0004\u0017)\u0002iY\\{\u001ePo\u001a\u000f\u0005CU<UcB\u0005](\u001f\u001e\u0019\u000f@.d";
      o[104] = "9fO\n,\u00142vJ]F\u0013deP\u0007*!7!\u000bXFG1eB\u000e|\u0011drL`";
      o[105] = "\u000fB\"vI]\u000eQyax\\\u0004Nza/\u000b^\u0019#\r\u0012C\u0005_es\u001e\u000e\u001bL";
      o[106] = "\beW\u0014b\u0003\u0013 W\u0010\u0002P\u000buS\u0006U\u0007U\"\u000bjb\u0004P)K\u000b8B\ty";
      o[107] = "IV\r\\\u0015]AG\u0012Ak\u000b0\u0013\\_\u0012\u0001IC\u0004J\f\u00010@\u0001\u0018\u0010S_A\u0012C\u0007b";
      o[108] = "l\u0000H\bm24SQ\u0003\u00043Q\u0002S\nj,`Z@Qi";
      o[109] = ":{<8!{;hg/\u0010z1wd/G-k <Cze0f{=v(.u";
      o[110] = " oM\u001c\"|y7\u000e\u001a*\ry?M&v}eV\u000f\u001bztb+T\u0011gr\u0019";
      o[111] = "Kn\u000bx,}Nj\u00044\u0014m(3[?mbQc\u0003*sb(o_:+\u007fVxZx%\u0001";
      o[112] = "+r\u0014Y\u0016Pux\u0013LzIM$HX\u0003C4t\u0010M\u001dCM-\u000b\\\u0010J/&\u001bYG ";
      o[113] = "\u0015z2,\u0002+Cp#vEDv\r\fI\u0004~^%\u007f&RtO\u007f8";
      o[114] = "_h7t\u001f:\n%l1&nW:4%q0\fjmIObV4l4\u001d|\u0006f";
      o[115] = "&Z7?2X#\u0012y~]\b%O!=\u0003\u000f%U%A<Z$G$*6Z+ZH";
      o[116] = "|\u007f\u001b 0`**\f.^? ;\u000752\rv~ZmbZ$%\u00071b'v;Wc^c6&\u001e)#8<;\u0018R";
      o[117] = "\u000en\u001a\u0011CnV}A\u0012;64)C\u0004B<My\u001b\u0011\\<4uG\u0001\u0004!JbBC\n_";
      o[118] = "m%\u0003\b\u000fsl6X\u001f>yj8_\u0014RK>|\u0006O>vv$C\b@z;:PsT};?\u000e\u001cUn`(?";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(114167652400468L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(114167652400468L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(114167652400468L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 122;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 98;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 78;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 195;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 86;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 193;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 122;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 98;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 78;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eQ_C0249",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Hitboxes var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eQ_C0249;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eQ_C0249", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Hitboxes)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(Hitboxes var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eQ_C0249;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eQ_C0249", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Hitboxes)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
