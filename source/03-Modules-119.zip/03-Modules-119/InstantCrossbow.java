package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public class InstantCrossbow extends Module {
   private BooleanSetting d;
   private int a = -1;
   private int c = -1;
   private int e = -1;
   private static final long k = 116171832601340L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[82];
   private static final String[] p = new String[82];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var6 = CombatProfile.Crystal;
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5, var6);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 13589499428872L;
      int var6 = Event.bReturningInt();
      int var17 = var6;
      MinecraftClient var16 = b;
      MinecraftClient var15 = var16;
      MinecraftClient var14 = var16;
      if (var17 == 0) {
         MinecraftClient var7 = var14;
         ClientPlayerEntity var18 = var7.player;
         if (var18 == null) {
            return;
         }

         MinecraftClient var19 = b;
         var15 = var19;
      }

      MinecraftClient var10 = var15;
      ClientWorld var20 = var10.world;
      if (var20 != null) {
         Object[] var13 = new Object[]{var4};
         InstantCrossbow var12 = this;
         var12.jReturningVoid(var13);
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 118804978388635L ^ 33883773335235L;
      var10001 = 118804978388635L ^ 82176054423181L;
      var10001 = 118804978388635L ^ 27818986051140L;
      var10001 = 118804978388635L ^ 117490301513350L;
      int var12 = Event.cReturningInt();
      int var143 = var12;
      MinecraftClient var142 = b;
      MinecraftClient var102 = var142;
      MinecraftClient var101 = var142;
      if (var143 != 0) {
         MinecraftClient var16 = var101;
         ClientPlayerEntity var144 = var16.player;
         if (var144 == null) {
            return;
         }

         MinecraftClient var145 = b;
         var102 = var145;
      }

      int var147 = var12;
      MinecraftClient var146 = var102;
      MinecraftClient var104 = var146;
      MinecraftClient var103 = var146;
      if (var147 != 0) {
         MinecraftClient var19 = var103;
         ClientWorld var148 = var19.world;
         if (var148 == null) {
            return;
         }

         var104 = b;
      }

      MinecraftClient var22 = var104;
      ClientPlayerEntity var23 = var22.player;
      boolean var149 = var23.isAlive();
      if (!var149) {
         Object[] var25 = new Object[0];
         InstantCrossbow var24 = this;
         var24.lReturningVoid(var25);
         Object[] var27 = new Object[]{128919554545887L};
         InstantCrossbow var26 = this;
         var26.mReturningVoid(var27);
      } else {
         byte var109;
         label171: {
            byte var108;
            label170: {
               label185: {
                  int var151 = var12;
                  PacketQueueManager var150 = Prestige.u;
                  PacketQueueManager var106 = var150;
                  PacketQueueManager var105 = var150;
                  if (var151 != 0) {
                     PacketQueueManager var152 = var105;
                     if (var152 == null) {
                        break label185;
                     }

                     var106 = Prestige.u;
                  }

                  Object[] var31 = new Object[]{42539134525462L};
                  PacketQueueManager var30 = var106;
                  byte var10000 = ((byte)((var30.aReturningBoolean(var31)) ? 1 : 0));
                  int var154 = var12;
                  byte var153 = var10000;
                  var108 = var153;
                  byte var107 = var153;
                  if (var154 == 0) {
                     break label170;
                  }

                  byte var155 = var107;
                  if (var155 != 0) {
                     var108 = 1;
                     break label170;
                  }
               }

               var109 = 0;
               break label171;
            }

            byte var156 = var108;
            var109 = var156;
         }

         byte var13;
         MinecraftClient var114;
         label158: {
            label157: {
               var13 = var109;
               int var158 = var12;
               int var157 = this.c;
               int var111 = var157;
               int var110 = var157;
               if (var158 != 0) {
                  // int var159 = var110;
                  if (var159 == var160) {
                     break label157;
                  }

                  byte var161 = var13;
                  var111 = var161;
               }

               int var162 = var111;
               if (var162 == 0) {
                  int var164 = var12;
                  MinecraftClient var163 = b;
                  var114 = var163;
                  MinecraftClient var112 = var163;
                  if (var164 == 0) {
                     break label158;
                  }

                  MinecraftClient var165 = var112;
                  MinecraftClient var113 = var165;
                  MinecraftClient var36 = var113;
                  ClientPlayerEntity var37 = var36.player;
                  PlayerInventory var220 = var37.getInventory();
                  int var39 = this.c;
                  PlayerInventory var38 = var220;
                  ItemStack var40 = var38.getStack(var39);
                  Item var221 = var40.getItem();
                  Item var167 = Items.CROSSBOW;
                  Item var166 = var221;
                  if (var166 != var167) {
                     Object[] var43 = new Object[0];
                     InstantCrossbow var42 = this;
                     var42.lReturningVoid(var43);
                  }
               }
            }

            var114 = b;
         }

         int var169 = var12;
         MinecraftClient var168 = var114;
         MinecraftClient var116 = var168;
         MinecraftClient var115 = var168;
         if (var169 != 0) {
            MinecraftClient var45 = var115;
            Screen var170 = var45.currentScreen;
            if (var170 != null) {
               Object[] var48 = new Object[]{128919554545887L};
               InstantCrossbow var47 = this;
               var47.mReturningVoid(var48);
               return;
            }

            var116 = b;
         }

         InstantCrossbow var124;
         label200: {
            ItemStack var14;
            ItemStack var135;
            label187: {
               MinecraftClient var50 = var116;
               ClientPlayerEntity var51 = var50.player;
               var14 = var51.getMainHandStack();
               ItemStack var52 = var14;
               Item var222 = var52.getItem();
               int var173 = var12;
               Item var172 = Items.CROSSBOW;
               Item var171 = var222;
               Item var126 = var171;
               Item var127 = var172;
               Item var117 = var171;
               Item var118 = var172;
               if (var173 != 0) {
                  Item var175 = var118;
                  Item var174 = var117;
                  label141:
                  if (var174 != var175) {
                     int var177 = var12;
                     byte var176 = var13;
                     int var123 = var176;
                     byte var119 = var176;
                     if (var177 != 0) {
                        byte var178 = var119;
                        byte var120 = var178;
                        byte var179 = var120;
                        if (var179 == 0) {
                           break label141;
                        }

                        int var181 = var12;
                        InstantCrossbow var180 = this;
                        var124 = var180;
                        InstantCrossbow var121 = var180;
                        if (var181 == 0) {
                           break label200;
                        }

                        InstantCrossbow var182 = var121;
                        InstantCrossbow var122 = var182;
                        int var183 = var122.e;
                        var123 = var183;
                     }

                     // int var184 = var123;
                     if (var184 != var185) {
                        InstantCrossbow var186 = this;
                        var124 = var186;
                        break label200;
                     }
                  }

                  int var188 = var12;
                  ItemStack var187 = var14;
                  var135 = var187;
                  ItemStack var125 = var187;
                  if (var188 == 0) {
                     break label187;
                  }

                  ItemStack var61 = var125;
                  var222 = var61.getItem();
                  Item var190 = Items.CROSSBOW;
                  Item var189 = var222;
                  var126 = var189;
                  var127 = var190;
               }

               Item var192 = var127;
               Item var191 = var126;
               if (var191 != var192) {
                  InstantCrossbow var134;
                  label191: {
                     int var133;
                     Object[] var64 = new Object[]{128919554545887L};
                     InstantCrossbow var63 = this;
                     var63.mReturningVoid(var64);
                     int var194 = var12;
                     int var193 = this.e;
                     var133 = var193;
                     int var128 = var193;
                     label110:
                     if (var194 != 0) {
                        int var195 = var128;
                        int var129 = var195;
                        // int var196 = var129;
                        if (var196 != var197) {
                           int var199 = var12;
                           int var198 = this.c;
                           var133 = var198;
                           int var130 = var198;
                           if (var199 == 0) {
                              break label110;
                           }

                           int var200 = var130;
                           int var131 = var200;
                           // int var201 = var131;
                           if (var201 != var202) {
                              int var224 = this.e;
                              int var231 = this.c;
                              Object[] var10004 = new Object[]{null, null, 7516849659933L};
                              var10004[1] = var231;
                              var10004[0] = var224;
                              Object[] var69 = var10004;
                              InventoryUtil.fReturningBoolean(var69);
                           }
                        }

                        Object[] var72 = new Object[0];
                        InstantCrossbow var71 = this;
                        var71.lReturningVoid(var72);
                        int var204 = var12;
                        InstantCrossbow var203 = this;
                        var134 = var203;
                        InstantCrossbow var132 = var203;
                        if (var204 == 0) {
                           break label191;
                        }

                        InstantCrossbow var73 = var132;
                        byte var205 = ((byte)((var73.aReturningBoolean()) ? 1 : 0));
                        var133 = var205;
                     }

                     int var206 = var133;
                     if (var206 == 0) {
                        return;
                     }

                     var134 = this;
                  }

                  Object[] var76 = new Object[]{126290808879192L};
                  InstantCrossbow var75 = var134;
                  var75.aReturningVoid(var76);
                  return;
               }

               var135 = var14;
            }

            ItemStack var77 = var135;
            int var225 = (((CrossbowItem.isCharged(var77)) ? 1 : 0));
            int var208 = var12;
            byte var207 = (byte)var225;
            int var137 = var207;
            byte var136 = var207;
            if (var208 != 0) {
               byte var209 = var136;
               if (var209 != 0) {
                  Object[] var80 = new Object[]{128919554545887L};
                  InstantCrossbow var79 = this;
                  var79.mReturningVoid(var80);
                  return;
               }

               var225 = (byte)1;
               MinecraftClient var82 = b;
               ClientPlayerEntity var84 = var82.player;
               ItemStack var83 = var14;
               int var86 = CrossbowItem.getPullTime(var83, (LivingEntity)var84);
               var137 = Math.max(1, var86);
            }

            MinecraftClient var141;
            int var15 = var137;
            int var211 = var12;
            MinecraftClient var210 = b;
            var141 = var210;
            MinecraftClient var138 = var210;
            label124:
            if (var211 != 0) {
               MinecraftClient var87 = var138;
               ClientPlayerEntity var88 = var87.player;
               boolean var212 = var88.isUsingItem();
               if (var212) {
                  int var214 = var12;
                  MinecraftClient var213 = b;
                  var141 = var213;
                  MinecraftClient var139 = var213;
                  if (var214 == 0) {
                     break label124;
                  }

                  MinecraftClient var215 = var139;
                  MinecraftClient var140 = var215;
                  MinecraftClient var91 = var140;
                  ClientPlayerEntity var92 = var91.player;
                  var225 = var92.getItemUseTime();
                  int var217 = var15;
                  int var216 = var225;
                  if (var216 >= var217) {
                     Object[] var95 = new Object[]{128919554545887L};
                     InstantCrossbow var94 = this;
                     var94.mReturningVoid(var95);
                     int var218 = var12;
                     if (var218 != 0) {
                        return;
                     }
                  }
               }

               MinecraftClient var219 = b;
               var141 = var219;
            }

            MinecraftClient var98 = var141;
            GameOptions var99 = var98.options;
            KeyBinding var100 = var99.useKey;
            var100.setPressed(true);
            return;
         }

         Object[] var60 = new Object[]{128919554545887L};
         InstantCrossbow var59 = var124;
         var59.mReturningVoid(var60);
      }
   }

   
   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 116171832601340L ^ var2;
      long var4 = var2 ^ 108540378052740L;
      long var6 = var2 ^ 15676063759101L;
      long var8 = var2 ^ 80692094214038L;
      int var10 = Event.bReturningInt();
      MinecraftClient var13 = b;
      ClientPlayerEntity var14 = var13.player;
      ItemStack var15 = var14.getMainHandStack();
      Item var10000 = var15.getItem();
      Item var43 = Items.CROSSBOW;
      Item var42 = var10000;
      if (var42 != var43) {
         while (true) {
            short var10001 = 16577;
            long var10002 = 5179227306532852888L ^ var2;
            byte var45 = 9;
            int var44 = var11;
            if (var44 < var45) {
               MinecraftClient var17 = b;
               ClientPlayerEntity var18 = var17.player;
               PlayerInventory var77 = var18.getInventory();
               int var20 = var11;
               PlayerInventory var19 = var77;
               ItemStack var21 = var19.getStack(var20);
               var10000 = var21.getItem();
               int var48 = var10;
               Item var47 = Items.CROSSBOW;
               Item var46 = var10000;
               Item var40 = var46;
               Item var41 = var47;
               Item var36 = var46;
               Item var37 = var47;
               if (var48 == 0) {
                  Item var50 = var37;
                  Item var49 = var36;
                  if (var49 == var50) {
                     Object[] var23 = new Object[]{var4};
                     this.a = InventoryUtil.aReturningInt(var23);
                     this.c = var11;
                     this.e = -1;
                     Object[] var10003 = new Object[]{null, var6};
                     var10003[0] = var11;
                     Object[] var24 = var10003;
                     InventoryUtil.aReturningVoid(var24);
                     return;
                  }

                  var11++;
                  int var51 = var10;
                  if (var51 == 0) {
                     continue;
                  }

                  BooleanSetting var26 = this.d;
                  Boolean var27 = (Boolean)var26.aReturningObject();
                  byte var79 = ((byte)(((java.lang.Boolean)(var27)).booleanValue() ? 1 : 0));
                  int var53 = var10;
                  byte var52 = var79;
                  byte var39 = var52;
                  byte var38 = var52;
                  if (var53 == 0) {
                     byte var54 = var38;
                     if (var54 == 0) {
                        return;
                     }

                     short var80 = 1769;
                     long var85 = 3165932969204093617L ^ var2;
                     var39 = 9;
                  }

                  var11 = var39;
               } else {
                  Item var58 = var41;
                  Item var57 = var40;
                  if (var57 == var58) {
                     Object[] var34 = new Object[]{var4};
                     int var12 = InventoryUtil.aReturningInt(var34);
                     this.a = var12;
                     this.c = var12;
                     this.e = var11;
                     Object[] var10004 = new Object[]{null, null, var8};
                     var10004[1] = var12;
                     var10004[0] = var11;
                     Object[] var35 = var10004;
                     InventoryUtil.fReturningBoolean(var35);
                     return;
                  }

                  var11++;
                  int var59 = var10;
                  if (var59 != 0) {
                     return;
                  }
               }
            } else {
               BooleanSetting var63 = this.d;
               Boolean var64 = (Boolean)var63.aReturningObject();
               byte var81 = ((byte)(((java.lang.Boolean)(var64)).booleanValue() ? 1 : 0));
               int var72 = var10;
               byte var71 = var81;
               byte var68 = var71;
               byte var67 = var71;
               if (var72 == 0) {
                  byte var73 = var67;
                  if (var73 == 0) {
                     return;
                  }

                  short var82 = 1769;
                  long var86 = 3165932969204093617L ^ var2;
                  var68 = 9;
               }

               var11 = var68;
            }

            int var76;
            do {
               var10001 = 19539;
               var10002 = 5883349981185693704L ^ var2;
               byte var56 = 36;
               int var55 = var11;
               if (var55 >= var56) {
                  return;
               }

               MinecraftClient var29 = b;
               ClientPlayerEntity var30 = var29.player;
               PlayerInventory var83 = var30.getInventory();
               int var32 = var11;
               PlayerInventory var31 = var83;
               ItemStack var33 = var31.getStack(var32);
               var10000 = var33.getItem();
               Item var70 = Items.CROSSBOW;
               Item var69 = var10000;
               Item var75 = var70;
               Item var74 = var69;
               if (var74 == var75) {
                  Object[] var65 = new Object[]{var4};
                  int var62 = InventoryUtil.aReturningInt(var65);
                  this.a = var62;
                  this.c = var62;
                  this.e = var11;
                  Object[] var89 = new Object[]{null, null, var8};
                  var89[1] = var62;
                  var89[0] = var11;
                  Object[] var66 = var89;
                  InventoryUtil.fReturningBoolean(var66);
                  return;
               }

               var11++;
               var76 = var10;
            } while (var76 == 0);

            return;
         }
      }
   }

   private void kReturningVoid(Object[] var1) {
      InstantCrossbow var24;
      label26: {
         label25: {
            long var2 = (Long)var1[0];
            var2 = 116171832601340L ^ var2;
            long var4 = var2 ^ 80914183758379L;
            long var6 = var2 ^ 16170627663680L;
            int var8 = Event.cReturningInt();
            int var27 = var8;
            // int var25 = this.e;
            int var22 = var25;
            byte var23 = var26;
            int var18 = var25;
            byte var19 = var26;
            if (var27 != 0) {
               byte var29 = var19;
               int var28 = var18;
               if (var28 != var29) {
                  int var10000 = this.e;
                  int var10001 = this.c;
                  Object[] var10004 = new Object[]{null, null, var6};
                  var10004[1] = var10001;
                  var10004[0] = var10000;
                  Object[] var10 = var10004;
                  InventoryUtil.fReturningBoolean(var10);
                  int var30 = var8;
                  if (var30 != 0) {
                     break label25;
                  }
               }

               int var32 = var8;
               InstantCrossbow var31 = this;
               var24 = var31;
               InstantCrossbow var20 = var31;
               if (var32 == 0) {
                  break label26;
               }

               InstantCrossbow var33 = var20;
               InstantCrossbow var21 = var33;
               // int var34 = var21.a;
               var22 = var34;
               var23 = var35;
            }

            byte var37 = var23;
            int var36 = var22;
            if (var36 != var37) {
               int var39 = this.a;
               Object[] var10003 = new Object[]{null, var4};
               var10003[0] = var39;
               Object[] var14 = var10003;
               InventoryUtil.aReturningVoid(var14);
            }
         }

         var24 = this;
      }

      Object[] var17 = new Object[0];
      InstantCrossbow var16 = var24;
      var16.lReturningVoid(var17);
   }

   private void lReturningVoid(Object[] var1) {
      this.a = -1;
      this.c = -1;
      this.e = -1;
   }

   private void mReturningVoid(Object[] var1) {
      int var8;
      label40: {
         int var45;
         label39: {
            int var44;
            label42: {
               long var2 = (Long)var1[0];
               var2 = 116171832601340L ^ var2;
               long var4 = var2 ^ 136913835848920L;
               int var10000 = Event.cReturningInt();
               MinecraftClient var9 = b;
               GameOptions var10 = var9.options;
               KeyBindingAccessor var10001 = new KeyBindingAccessor(var10.useKey);
               Object[] var12 = new Object[]{var4};
               KeyBindingAccessor var11 = var10001;
               Key var13 = var11.aReturningVoid(var12);
               int var7 = var13.getCode();
               int var6 = var10000;
               short var72 = 3810;
               long var10002 = 2641733448647350032L ^ var2;
               int var48 = var6;
               byte var47 = 8;
               int var46 = var7;
               int var42 = var46;
               byte var43 = var47;
               int var34 = var46;
               byte var35 = var47;
               if (var48 != 0) {
                  byte var50 = var35;
                  int var49 = var34;
                  if (var49 < var50) {
                     MinecraftClient var15 = b;
                     Window var16 = var15.getWindow();
                     long var68 = var16.getHandle();
                     int var19 = var7;
                     long var17 = var68;
                     var10000 = GLFW.glfwGetMouseButton(var17, var19);
                     int var52 = var6;
                     int var51 = var10000;
                     int var38 = var51;
                     int var36 = var51;
                     int var39;
                     if (var52 != 0) {
                        int var53 = var36;
                        int var37 = var53;
                        byte var55 = 1;
                        int var54 = var37;
                        if (var54 == var55) {
                           byte var56 = 1;
                           var39 = var56;
                        } else {
                           var39 = 0;
                        }
                     } else {
                        int var57 = var38;
                        var39 = var57;
                     }

                     var8 = var39;
                     int var58 = var6;
                     if (var58 != 0) {
                        break label40;
                     }
                  }

                  MinecraftClient var23 = b;
                  Window var24 = var23.getWindow();
                  long var70 = var24.getHandle();
                  int var27 = var7;
                  long var25 = var70;
                  var10000 = GLFW.glfwGetKey(var25, var27);
                  int var60 = var6;
                  int var59 = var10000;
                  var44 = var59;
                  int var40 = var59;
                  if (var60 == 0) {
                     break label42;
                  }

                  int var61 = var40;
                  int var41 = var61;
                  byte var63 = 1;
                  int var62 = var41;
                  var42 = var62;
                  var43 = var63;
               }

               byte var65 = var43;
               int var64 = var42;
               if (var64 != var65) {
                  var45 = 0;
                  break label39;
               }

               var44 = 1;
            }

            int var66 = var44;
            var45 = var66;
         }

         var8 = var45;
      }

      MinecraftClient var30 = b;
      GameOptions var31 = var30.options;
      int var33 = var8;
      KeyBinding var32 = var31.useKey;
      var32.setPressed(dev.prestige.recovery.SourceSupport.asBoolean(var33));
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var6;
      label30: {
         label32: {
            long var2 = (Long)var1[0];
            long var4 = var2 ^ 134706232104131L;
            var6 = var2 ^ 120983561077181L;
            int var8 = Event.bReturningInt();
            int var30 = var8;
            MinecraftClient var29 = b;
            MinecraftClient var26 = var29;
            MinecraftClient var25 = var29;
            if (var30 == 0) {
               MinecraftClient var9 = var25;
               ClientPlayerEntity var31 = var9.player;
               if (var31 == null) {
                  break label32;
               }

               MinecraftClient var32 = b;
               var26 = var32;
            }

            int var34 = var8;
            MinecraftClient var33 = var26;
            MinecraftClient var28 = var33;
            MinecraftClient var27 = var33;
            if (var34 == 0) {
               MinecraftClient var12 = var27;
               ClientWorld var35 = var12.world;
               if (var35 == null) {
                  break label32;
               }

               MinecraftClient var36 = b;
               var28 = var36;
            }

            MinecraftClient var15 = var28;
            ClientPlayerEntity var16 = var15.player;
            boolean var37 = var16.isAlive();
            if (var37) {
               Object[] var18 = new Object[]{var4};
               InstantCrossbow var17 = this;
               var17.kReturningVoid(var18);
               int var38 = var8;
               if (var38 == 0) {
                  break label30;
               }
            }
         }

         Object[] var21 = new Object[0];
         InstantCrossbow var20 = this;
         var20.lReturningVoid(var21);
      }

      Object[] var24 = new Object[]{var6};
      InstantCrossbow var23 = this;
      var23.mReturningVoid(var24);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(23238734700282L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[4];
      String var6 = "RZ/cn*¿\u0016Ò\n\u0082%îù\u0016ý";
      int var7 = "RZ/cn*¿\u0016Ò\n\u0082%îù\u0016ý".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     l = var8;
                     m = new Integer[4];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "·\fZ~°\u0004P\u0096hYï¢r\u000b\u0081`";
                  var7 = "·\fZ~°\u0004P\u0096hYï¢r\u000b\u0081`".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27601;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eS", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eS_C0253",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 60;
            yield var15;
         }
         case 1 -> {
            byte var16 = 10;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 25;
            yield var18;
         }
         case 4 -> {
            byte var19 = 48;
            yield var19;
         }
         case 5 -> {
            byte var20 = 59;
            yield var20;
         }
         case 6 -> {
            byte var21 = 0;
            yield var21;
         }
         case 7 -> {
            byte var22 = 3;
            yield var22;
         }
         case 8 -> {
            byte var23 = 27;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 8;
            yield var25;
         }
         case 11 -> {
            byte var26 = 9;
            yield var26;
         }
         case 12 -> {
            byte var27 = 52;
            yield var27;
         }
         case 13 -> {
            byte var28 = 55;
            yield var28;
         }
         case 14 -> {
            byte var29 = 35;
            yield var29;
         }
         case 15 -> {
            byte var30 = 12;
            yield var30;
         }
         case 16 -> {
            byte var31 = 57;
            yield var31;
         }
         case 17 -> {
            byte var32 = 63;
            yield var32;
         }
         case 18 -> {
            byte var33 = 38;
            yield var33;
         }
         case 19 -> {
            byte var34 = 41;
            yield var34;
         }
         case 20 -> {
            byte var35 = 18;
            yield var35;
         }
         case 21 -> {
            byte var36 = 26;
            yield var36;
         }
         case 22 -> {
            byte var37 = 31;
            yield var37;
         }
         case 23 -> {
            byte var38 = 39;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 61;
            yield var40;
         }
         case 26 -> {
            byte var41 = 37;
            yield var41;
         }
         case 27 -> {
            byte var42 = 2;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 51;
            yield var44;
         }
         case 30 -> {
            byte var45 = 47;
            yield var45;
         }
         case 31 -> {
            byte var46 = 32;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 22;
            yield var49;
         }
         case 35 -> {
            byte var50 = 24;
            yield var50;
         }
         case 36 -> {
            byte var51 = 42;
            yield var51;
         }
         case 37 -> {
            byte var52 = 13;
            yield var52;
         }
         case 38 -> {
            byte var53 = 54;
            yield var53;
         }
         case 39 -> {
            byte var54 = 40;
            yield var54;
         }
         case 40 -> {
            byte var55 = 6;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 7;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 28;
            yield var59;
         }
         case 45 -> {
            byte var60 = 53;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 43;
            yield var62;
         }
         case 48 -> {
            byte var63 = 16;
            yield var63;
         }
         case 49 -> {
            byte var64 = 46;
            yield var64;
         }
         case 50 -> {
            byte var65 = 33;
            yield var65;
         }
         case 51 -> {
            byte var66 = 17;
            yield var66;
         }
         case 52 -> {
            byte var67 = 14;
            yield var67;
         }
         case 53 -> {
            byte var68 = 50;
            yield var68;
         }
         case 54 -> {
            byte var69 = 58;
            yield var69;
         }
         case 55 -> {
            byte var70 = 49;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 15;
            yield var73;
         }
         case 59 -> {
            byte var74 = 45;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 5;
            yield var76;
         }
         case 62 -> {
            byte var77 = 44;
            yield var77;
         }
         default -> 11;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "OJMs\u0000]YJH)\u0013JN\u0001K/\u001f^_F\\8THx";
      o[1] = "\u000b':\u000e-8\u0000(+AN5\u0015%$*{7\u000468\u0006l:";
      o[2] = "s\u0001\u00046K>s\u0001\u0013jG1iJ\u0013tG$n;A(\u0012f";
      o[3] = long.class;
      p[3] = "java/lang/Long";
      o[4] = "x/\u001a\u001ahJx/\rFdEbd\rXdPe\u0015]\u00055";
      o[5] = "\u0004\f~0a\u0017\u0004\film\u0018\u001eGirm\r\u001969/9";
      o[6] = "X\u0019\nL\u0001/N\u0019\u000f\u0016\u00128YR\f\u0010\u001e,H\u0015\u001b\u0007U\u0013";
      o[7] = "\r\u001b\u000e~/\\x;\u0005q>\u0013\u00195\u000ez:Im";
      o[8] = "6\u001a\u0006s*\u001d6\u001a\u0011/&\u0012,Q\u00111&\u0007+ AkpA|\u001c\u001e<4\u0007\u0007LBk";
      o[9] = int.class;
      p[9] = "java/lang/Integer";
      o[10] = "\u001cC%1X\u0019\u0019V.1S\u0002\u0015FlXx($";
      o[11] = "\u001e\u0012& \u0015m\b\u0012#z\u0006z\u001fY |\nn\u000e\u001e7kA|?";
      o[12] = "@qh\u001eH$@q\u007fBD+Z:\u007f\\D>]K/\u0000\u0011";
      o[13] = boolean.class;
      p[13] = "java/lang/Boolean";
      o[14] = void.class;
      p[14] = "java/lang/Void";
      o[15] = "uXj&\b:~W{ik7kQ";
      o[16] = "6z\u000f\u0001`L6z\u0018]lC,1\u0018ClV+@L\u001b;";
      o[17] = "bSd\bPGbSsT\\Hx\u0018sJ\\]\u007fi!\u0010\u000b\u001f";
      o[18] = "Y6!\u0018ztY66Dv{C}6ZvnD\fd\u0001.$";
      o[19] = "L\u001f*5`dL\u001f=ilkVT=wl~Q%o,4?";
      o[20] = "69LGQ\u000669[\u001b]\t,r[\u0005]\u001c+\u0003\fZ\u000b";
      o[21] = "M[Ul\u001b`8{^c\n/YuUh\u000eu-";
      o[22] = "-1kYKy-1|\u0005Gv7z|\u001bGc0\u000b.@\u0010$";
      o[23] = "F\u0011c@uKP\u0011f\u001af\\GZe\u001cjHV\u001dr\u000b!Yt";
      o[24] = "\u001fry\u007f\u0011/jRrp\u0000`\u000b\\y{\u0004:\u007f";
      o[25] = "S\u0003\u0011lH9S\u0003\u00060D6IH\u0006.D#N9Tz\u0015b";
      o[26] = "v[*8!av[=d-nl\u0010=z-{kao%|1";
      o[27] = "H_~F8\u001b^_{\u001c+\fI\u0014x\u001a'\u0018XSo\rl\b@Sm\u00066E|Hm\u001b6\u0002K_";
      o[28] = "u\b0S\u001fc\u0000(;\\\u000e,a&0W\nv\u0015";
      o[29] = "\u001b\u0001\tRD\"\r\u0001\f\bW5\u001aJ\u000f\u000e[!\u000b\r\u0018\u0019\u00106.";
      o[30] = "j\u001bNRsv\u001f;E]b9~5NVfc\n";
      o[31] = "_9D+\u000f\u0016_9Sw\u0003\u0019ErSi\u0003\fB\u0003\u00066Z";
      o[32] = "\u007f#Sd\u0003\u000ei#V>\u0010\u0019~hU8\u001c\ro/B/W\u001dt";
      o[33] = "t=}W.H\u0001\u001dvX?\u0007`\u0013}S;]\u0014";
      o[34] = "\u000f_\u007fc\u0013pz\u007ftl\u0002?\u001bq\u007fg\u0006eo";
      o[35] = "$>\"-\u000bq/13bgr!31-K";
      o[36] = ">b_MWX(bZ\u0017DO?)Y\u0011H[.nN\u0006\u0003L\u001c";
      o[37] = "\u0019\bEx%N\u0012\u0007T7D@\u0019\fPm";
      o[38] = "=!X\u00044YH\u0001S\u000b%\u0016)\u000fX\u0000!L]";
      o[39] = "&w2Rb\u001eSW9]sQ2Y2Vw\u000bF";
      o[40] = "+n},1\u000e^Nv# A?@}($\u001bK";
      o[41] = "\u000fQ*\u0012?q\u0011Y0]Ba\u0011";
      o[42] = "\u0010h\u0006$G}\u0018g\u001e!%i\u0010ho~Xi\u001et\u0017'\u0018b\u0002\u0018Q=@k\u0015`\b}Kwy&\u0012%B`\u0001\u007fR.^\f";
      o[43] = "\u0010D\u000e \n#G\u001f\f\"cr K\u000f<\u0004tX\u0012O7\u0018\u0018";
      o[44] = "P\u0006\u000e(>*A\u0001BkD!W\u0018\u0013=(\u0013\u0001]NftDP\u001a\t(=.V\u0000\u0015jD";
      o[45] = "9c}+?\n<' -\\\u00168%~#0$jh&u\\\u001f-e&8eNm$fD";
      o[46] = "kE\u0002 \u0006\u001b:D\u0003!9\u00141\u0014\u001b4nCoDBXTD/\u0018\u00152\b\u0004)\u0000";
      o[47] = "p1\t\u0005Qv//\u0000C?t\u0015(XTBcy+\u0005PV\u001d$-\u0018\u0001Cex)\rT?";
      o[48] = "NEn\r\u0004$\u000e\t?\u0017?'\u001d\t3\u000bS\u0015IIoP?|\r\u00104\u0000G%M\u001b(l";
      o[49] = "f\u0003\u001cGJQ [\u0013[$O=PSjI\\\u001aS]%\u001e\u00107O@^\u0015\u001e2U,\u001bYE>RTB\u0019N\">\u0012XAG5FK\u0018J[Y";
      o[50] = "2\u0017`ym\reLb{\u0004]\u0002\u0018aecZzA!n\u007f6";
      o[51] = "u\u001a\u0013/)^\u007fPN\u007f\u0017Du\u0007\u0010(~HL\t\u00108z.#XE>rKyX\u00199\u0017";
      o[52] = "d\u0000\u0000-_8o\u0004@M[\\zAT0G0y\u001cP$9m\u007f\u0001\u00011A1{\u0014TM";
      o[53] = "Z;\u0002\u0015d%\u001dj\u001a\u0016\u0005#\"/EJtwZ1\u001aMfJ";
      o[54] = "\u0017P0d|1\u001cTp\u0004\u007fU\t\u0011dyd9\nL`m\u001ad\fQ1xb8\bDd\u0004";
      o[55] = "]%+\u0019\u0000\u0005V!ky\u0005aCd\u007f\u0004\u0018\r@9{\u0010fPF$*\u0005\u001e\fB1\u007fy";
      o[56] = "\u0015RSKo)\u0004U\u001f\b\u0015\"\u0012LN^y\u0010B\u0000\u0016\u0004\u0015vG\u0001U\\p,G]R9";
      o[57] = "hEUY&;9DTX\u001942\u0014LMNclC\u0014!s8.\u000bROb?bH";
      o[58] = "VpY%E%\u00006\u0016v#.Uv\u0004/O\u001c\u00075Tq#'\u0002i\u000b+Z\"F4\rH\u0012s\tq\u0001-HsUvd";
      o[59] = "\u001d\u000bMB7\u0019B\u0015D\u0004Y\u001bx\u0012\u001c\u0013$\f\u0014\u0011A\u00170rF\u0014C\u001f5\n\u001fTH\u0003Y";
      o[60] = "@5a\u0014|GVcx\u000e\u001a\u0013/r:\u0001g\u0004Cqg\u0005sz\u001e11\u0011\u007f\u001fD1m\u0016\u001a";
      o[61] = "ub\u001c\bIV$c\u001d\tvR#\"\u0001\u0017\u001a`td_@M7w'\u001a\u0016O\u0006-#\u001f\u0000v";
      o[62] = "C:ot[DH>/\u0014T \u001fpo-VOJ*0x=\u0019\u0017~i\u007fRLM!<\u0014";
      o[63] = "P\b\u0015]\u0019|\n\f\u0010K (\u0004\r\u000e\\L\u001aUM_\u0003 wY\u001f\u001fW[|W\u001a\u0005;";
      o[64] = "3JP\u0006C\u0016)AG\u001f|D2JR\u0015+\u001ah\u0016\u0007y\u0010Ro\u001fJ@A\u0012._";
      o[65] = "U*i\u000bVt\u0003l&X0\u007fV,4\u0001\\M\u0004ok[0v\u00013;\u0005IsEn=fQsF3%\u0004@#X-TXM\u007f\\<,\u0001\rt@P";
      o[66] = "2$d/ h1/?~XwS0es&ln&3j<";
      o[67] = "\u0018\u001fZKG\u0017I\u001e[Jx\u0018BNC_/O\u001d\u0012\u001f3C\u0016\u001eIGH\n\u000f^]";
      o[68] = "[n\u001d]p4Pj]=rPE/I@h<FrMT\u0016a@o\u001cAn=DzI=";
      o[69] = "fH\u0003qz/wOO2\u0000$aV\u001edl\u00162\u0012B<\u0000-6I\u0011`y(r\u0014\u0017\u0003";
      o[70] = "~\u0013a]]\u0015>MhMa\u0019B\u000b#[\u001c\u000e.\b~_\bp|@$QZ\u0016<\fuKa";
      o[71] = "u425\u0007Qgi'5:R\u0016ro:GEzq2>S;'w/oFC{s:::";
      o[72] = "\u0011*&F\u0007\u000b\u00111x\u0010f\u001eL(vJ\n,\u001bo*\u001d_{\u0010l'V\u0003\u001eJl{QfJ_.(Q\u001e\u0016[;}-";
      o[73] = "vT\u0007.K\fpN\u001bl2\u0003qV\u001d;^1!\u0016Fl2XaO\u001a0J\u0001!D\u0006\\^\\\u007fE\u001e%[\u0018\"C}";
      o[74] = " y\u001a*\u0004#2$\u000f*9 CuE\u007fB,&/E#EI";
      o[75] = "ak9h\u0003X0j8i<W;: |k\u0000dg{\u0010XK8//,V\bk0";
      o[76] = "`\u001f\u0014ol1a\u0005R S?ucPm3)&\u001bN24;\u001b\u001a\u00140\"ec\u0004K70Xb^I!n |\u0001N3S#g^\u0016o:\"}\u0018YP";
      o[77] = "XY\u0006Cc\u0013I^J\u0000\u0019\u0018_G\u001bVu*\f\u0003G\u0001\u0019CO^\u001c]a\u001a\u000fU\u00001";
      o[78] = "\u000e\u0010G%=]G\t\u00071]HT\u001d\u001e#\n\u001f\u0004HFOmX\u0005\u001b\u001b?mC[M";
      o[79] = "=\u0010\u000en~>{H\u0001r\u0010 fCAC}3GJCw}\u0005\u007fQBkvO8\u001dP}|43\u0013Ug\u0010q\u007fHY`h(?CE\f.2gJRtwrlV>";
      o[80] = "g14SdLv6x\u0010\u001eG`/)Fru3jp\u001c\u001e\u00135b2D{I5>5!";
      o[81] = "^4*/(\u007f\u0001*#iFz;-{~;jW.&z/\u0014\nnpn#qPn,iF";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2656070969771684L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2656070969771684L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2656070969771684L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 226;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 212;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 225;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 255;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 207;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 87;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 226;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 212;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 225;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eS_C0253",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eS" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
