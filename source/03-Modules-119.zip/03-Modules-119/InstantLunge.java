package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.PacketUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.ObjectIterable;
import it.unimi.dsi.fastutil.objects.ObjectIterator;
import it.unimi.dsi.fastutil.objects.Object2IntMap.Entry;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.PiercingWeaponComponent;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class InstantLunge extends Module {
   private BooleanSetting d;
   private MinMaxSetting a;
   private int c;
   private ElapsedTimer e;
   private static final long k = 1759232831658L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[108];
   private static final String[] p = new String[108];

   public InstantLunge() {
      super();
      long var10001 = 94462216791141L ^ 58150322197324L;

      this.c = -1;
      this.e = new ElapsedTimer(106698256430889L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Spear;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @EventListener
   public void a(TickEvent var1) {
      int var20;
      int var21;
      int var84;
      label92: {
         long var10001 = 43925245842233L ^ 82566464190717L;
         var10001 = 43925245842233L ^ 93662405061473L;
         var10001 = 43925245842233L ^ 92602412510582L;
         var10001 = 43925245842233L ^ 1127161117497L;
         var10001 = 43925245842233L ^ 12030517597238L;
         var10001 = 43925245842233L ^ 112181494486607L;
         var10001 = 43925245842233L ^ 30072489545398L;
         var10001 = 43925245842233L ^ 88939103258946L;
         int var10000 = Event.cReturningInt();
         Object[] var25 = new Object[]{66704745061775L};
         InstantLunge var24 = this;
         var21 = var24.aReturningInt(var25);
         var20 = var10000;
         int var102 = var20;
         // int var100 = this.c;
         int var82 = var100;
         byte var83 = var101;
         int var76 = var100;
         byte var77 = var101;
         if (var102 != 0) {
            byte var104 = var77;
            int var103 = var76;
            if (var103 != var104) {
               ElapsedTimer var144 = this.e;
               Object[] var28 = new Object[]{this.a, 130913203968635L};
               ElapsedTimer var27 = var144;
               byte var145 = ((byte)((var27.bReturningBoolean(var28)) ? 1 : 0));
               int var106 = var20;
               byte var105 = var145;
               int var80 = var105;
               byte var78 = var105;
               if (var106 != 0) {
                  byte var107 = var78;
                  byte var79 = var107;
                  byte var108 = var79;
                  if (var108 == 0) {
                     return;
                  }

                  var80 = this.c;
               }

               Object[] var153 = new Object[]{null, 72518082610550L};
               var153[0] = var80;
               Object[] var31 = var153;
               InventoryUtil.aReturningVoid(var31);
               this.c = -1;
               Object[] var33 = new Object[]{126290808879192L};
               InstantLunge var32 = this;
               var32.aReturningVoid(var33);
               return;
            }

            int var110 = var20;
            int var109 = var21;
            var84 = var109;
            int var81 = var109;
            if (var110 == 0) {
               break label92;
            }

            // int var111 = var81;
            var82 = var111;
            var83 = var112;
         }

         byte var114 = var83;
         int var113 = var82;
         if (var113 == var114) {
            return;
         }

         MinecraftClient var35 = b;
         ClientPlayerEntity var36 = var35.player;
         var84 = (((var36.isUsingItem()) ? 1 : 0));
      }

      int var116 = var20;
      int var115 = var84;
      int var86 = var115;
      int var85 = var115;
      if (var116 != 0) {
         int var117 = var85;
         if (var117 != 0) {
            return;
         }

         MinecraftClient var38 = b;
         ClientPlayerEntity var39 = var38.player;
         HungerManager var40 = var39.getHungerManager();
         var86 = var40.getFoodLevel();
      }

      int var92;
      label94: {
         int var120 = var20;
         byte var119 = 6;
         int var118 = var86;
         int var90 = var118;
         int var91 = var119;
         int var87 = var118;
         byte var88 = var119;
         if (var120 != 0) {
            byte var122 = var88;
            int var121 = var87;
            if (var121 < var122) {
               return;
            }

            Object[] var42 = new Object[]{49487520630543L};
            int var140 = InventoryUtil.aReturningInt(var42);
            int var124 = var20;
            int var123 = var140;
            var92 = var123;
            int var89 = var123;
            if (var124 == 0) {
               break label94;
            }

            int var126 = var21;
            int var125 = var89;
            var90 = var125;
            var91 = var126;
         }

         int var128 = var91;
         int var127 = var90;
         if (var127 == var128) {
            Object[] var44 = new Object[]{new PlayerActionC2SPacket(Action.STAB, BlockPos.ORIGIN, Direction.DOWN), 119757183937476L};
            PacketUtil.aReturningVoid(var44);
            Object[] var46 = new Object[]{126290808879192L};
            InstantLunge var45 = this;
            var45.aReturningVoid(var46);
            return;
         }

         Object[] var48 = new Object[]{49487520630543L};
         this.c = InventoryUtil.aReturningInt(var48);
         var92 = var21;
      }

      InstantLunge var99;
      label96: {
         boolean var98;
         label73: {
            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var92;
            Object[] var49 = var10003;
            InventoryUtil.aReturningVoid(var49);
            MinecraftClient var50 = b;
            ClientPlayerEntity var51 = var50.player;
            ItemStack var22 = var51.getMainHandStack();
            ComponentType var53 = DataComponentTypes.PIERCING_WEAPON;
            ItemStack var52 = var22;
            PiercingWeaponComponent var23 = (PiercingWeaponComponent)var52.get(var53);
            int var130 = var20;
            PiercingWeaponComponent var129 = var23;
            Object var97 = var129;
            PiercingWeaponComponent var93 = var129;
            if (var130 != 0) {
               PiercingWeaponComponent var131 = var93;
               if (var131 != null) {
                  MinecraftClient var55 = b;
                  ClientPlayerInteractionManager var56 = var55.interactionManager;
                  boolean var141 = var56.isFlyingLocked();
                  int var133 = var20;
                  boolean var132 = var141;
                  var98 = var132;
                  boolean var94 = var132;
                  if (var133 == 0) {
                     break label73;
                  }

                  boolean var134 = var94;
                  boolean var95 = var134;
                  boolean var135 = var95;
                  if (!var135) {
                     MinecraftClient var59 = b;
                     PiercingWeaponComponent var61 = var23;
                     ClientPlayerInteractionManager var60 = var59.interactionManager;
                     var60.attackWithPiercingWeapon(var61);
                     MinecraftClient var62 = b;
                     Hand var64 = Hand.MAIN_HAND;
                     ClientPlayerEntity var63 = var62.player;
                     var63.swingHand(var64);
                  }
               }

               int var137 = var20;
               InstantLunge var136 = this;
               var99 = var136;
               InstantLunge var96 = var136;
               if (var137 == 0) {
                  break label96;
               }

               BooleanSetting var66 = var96.d;
               Object var138 = var66.aReturningObject();
               var97 = var138;
            }

            Boolean var68 = (Boolean)var97;
            var98 = var68;
         }

         boolean var139 = var98;
         if (!var139) {
            this.c = -1;
            Object[] var70 = new Object[]{126290808879192L};
            InstantLunge var69 = this;
            var69.aReturningVoid(var70);
            return;
         }

         ElapsedTimer var142 = this.e;
         Object[] var73 = new Object[]{42835128969216L};
         ElapsedTimer var72 = var142;
         var72.aReturningVoid(var73);
         var99 = this;
      }

      MinMaxSetting var143 = var99.a;
      Object[] var75 = new Object[]{127318019014223L};
      MinMaxSetting var74 = var143;
      var74.bReturningVoid(var75);
   }

   private int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 1759232831658L ^ var2;
      long var4 = var2 ^ 98961576490124L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var28;
      while (true) {
         short var10001 = 20141;
         long var10002 = 3154292705629887948L ^ var2;
         byte var30 = 9;
         int var29 = var7;
         if (var29 < var30) {
            MinecraftClient var10 = b;
            ClientPlayerEntity var11 = var10.player;
            PlayerInventory var46 = var11.getInventory();
            int var13 = var7;
            PlayerInventory var12 = var46;
            ItemStack var8 = var12.getStack(var13);
            TagKey var15 = ItemTags.SPEARS;
            ItemStack var14 = var8;
            byte var47 = ((byte)((var14.isIn(var15)) ? 1 : 0));
            int var32 = var6;
            byte var31 = var47;
            var28 = var31;
            byte var19 = var31;
            if (var32 == 0) {
               break;
            }

            label57: {
               int var34 = var6;
               byte var33 = var19;
               int var22 = var33;
               byte var20 = var33;
               if (var34 != 0) {
                  byte var35 = var20;
                  byte var21 = var35;
                  byte var36 = var21;
                  if (var36 == 0) {
                     break label57;
                  }

                  Object[] var18 = new Object[]{var8, Enchantments.LUNGE, var4};
                  var22 = cReturningInt(var18);
               }

               int var25;
               label44: {
                  int var38 = var6;
                  int var37 = var22;
                  int var24 = var37;
                  int var23 = var37;
                  if (var38 != 0) {
                     int var39 = var23;
                     if (var39 <= 0) {
                        var25 = 0;
                        break label44;
                     }

                     var24 = 1;
                  }

                  int var40 = var24;
                  var25 = var40;
               }

               int var9 = var25;
               int var42 = var6;
               int var41 = var9;
               int var27 = var41;
               int var26 = var41;
               if (var42 == 0) {
                  return var27;
               }

               int var43 = var26;
               if (var43 != 0) {
                  var27 = var7;
                  return var27;
               }
            }

            var7++;
            int var44 = var6;
            if (var44 != 0) {
               continue;
            }
         }

         var28 = -1;
         break;
      }

      return var28;
   }

   public static int cReturningInt(Object[] var0) {
      ItemStack var4 = (ItemStack)var0[0];
      RegistryKey var1 = (RegistryKey)var0[1];
      long var2 = (Long)var0[2];
      var2 = 1759232831658L ^ var2;
      long var5 = var2 ^ 67560257993960L;
      long var7 = var2 ^ 83214841881081L;
      int var9 = Event.cReturningInt();
      ItemStack var11 = var4;
      byte var10000 = ((byte)((var11.isEmpty()) ? 1 : 0));
      int var18 = var9;
      byte var17 = var10000;
      byte var16 = var17;
      byte var15 = var17;
      if (var18 != 0) {
         byte var19 = var15;
         if (var19 == 0) {
            Object2IntArrayMap var10 = new Object2IntArrayMap();
            Object[] var13 = new Object[]{var4, var10, var5};
            jReturningVoid(var13);
            Object[] var14 = new Object[]{var10, var1, var7};
            return dReturningInt(var14);
         }

         var16 = 0;
      }

      return var16;
   }

   public static int dReturningInt(Object[] var0) {
      Object2IntMap var2 = (Object2IntMap)var0[0];
      RegistryKey var1 = (RegistryKey)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 1759232831658L ^ var3;
      int var32 = Event.cReturningInt();
      Object2IntMap var8 = var2;
      ObjectIterable var9 = Object2IntMaps.fastIterable(var8);
      ObjectIterator var6 = var9.iterator();
      int var5 = var32;

      byte var22;
      while (true) {
         ObjectIterator var10 = var6;
         boolean var23 = ((Iterator)var10).hasNext();
         if (var23) {
            ObjectIterator var11 = var6;
            Entry var7 = (Entry)((Iterator)var11).next();
            Entry var12 = var7;
            RegistryEntry var33 = (RegistryEntry)var12.getKey();
            RegistryKey var14 = var1;
            RegistryEntry var13 = var33;
            byte var34 = ((byte)((var13.matchesKey(var14)) ? 1 : 0));
            int var25 = var5;
            byte var24 = var34;
            var22 = var24;
            byte var18 = var24;
            if (var25 == 0) {
               break;
            }

            int var27 = var5;
            byte var26 = var18;
            int var21 = var26;
            byte var19 = var26;
            if (var27 == 0) {
               return var21;
            }

            byte var28 = var19;
            byte var20 = var28;
            byte var29 = var20;
            if (var29 != 0) {
               Entry var17 = var7;
               int var30 = var17.getIntValue();
               var21 = var30;
               return var21;
            }

            int var31 = var5;
            if (var31 != 0) {
               continue;
            }
         }

         var22 = 0;
         break;
      }

      return var22;
   }

   public static void jReturningVoid(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      Object2IntMap var4 = (Object2IntMap)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 1759232831658L ^ var1;
      int var46 = Event.bReturningInt();
      Object2IntMap var9 = var4;
      var9.clear();
      int var5 = var46;
      int var36 = var5;
      ItemStack var35 = var3;
      ItemStack var31 = var35;
      ItemStack var30 = var35;
      if (var36 == 0) {
         ItemStack var10 = var30;
         boolean var37 = var10.isEmpty();
         if (var37) {
            return;
         }

         ItemStack var38 = var3;
         var31 = var38;
      }

      Set var34;
      label28: {
         int var40 = var5;
         ItemStack var39 = var31;
         ItemStack var33 = var39;
         ItemStack var32 = var39;
         if (var40 == 0) {
            ItemStack var13 = var32;
            Item var47 = var13.getItem();
            Item var42 = Items.ENCHANTED_BOOK;
            Item var41 = var47;
            if (var41 == var42) {
               ItemEnchantmentsComponent var17 = ItemEnchantmentsComponent.DEFAULT;
               ComponentType var16 = DataComponentTypes.STORED_ENCHANTMENTS;
               ItemStack var15 = var3;
               ItemEnchantmentsComponent var18 = (ItemEnchantmentsComponent)var15.getOrDefault(var16, var17);
               Set var43 = var18.getEnchantmentEntries();
               var34 = var43;
               break label28;
            }

            var33 = var3;
         }

         ItemStack var20 = var33;
         ItemEnchantmentsComponent var21 = var20.getEnchantments();
         var34 = var21.getEnchantmentEntries();
      }

      Set var6 = var34;
      Set var22 = var6;
      Iterator var7 = var22.iterator();

      int var45;
      do {
         Iterator var23 = var7;
         boolean var44 = var23.hasNext();
         if (!var44) {
            break;
         }

         Iterator var24 = var7;
         Entry var8 = (Entry)var24.next();
         Entry var25 = var8;
         RegistryEntry var10001 = (RegistryEntry)var25.getKey();
         Entry var26 = var8;
         int var29 = var26.getIntValue();
         RegistryEntry var28 = var10001;
         Object2IntMap var27 = var4;
         var27.put(var28, var29);
         var45 = var5;
      } while (var45 == 0);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(96827608545359L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = " u?Ö\u0087î-8'¿cz2áöÿ";
      int var7 = " u?Ö\u0087î-8'¿cz2áöÿ".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32324;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eT", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eT_C0255",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 46;
            yield var15;
         }
         case 1 -> {
            byte var16 = 34;
            yield var16;
         }
         case 2 -> {
            byte var17 = 39;
            yield var17;
         }
         case 3 -> {
            byte var18 = 54;
            yield var18;
         }
         case 4 -> {
            byte var19 = 32;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 3;
            yield var21;
         }
         case 7 -> {
            byte var22 = 58;
            yield var22;
         }
         case 8 -> {
            byte var23 = 23;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 59;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 63;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 47;
            yield var29;
         }
         case 15 -> {
            byte var30 = 51;
            yield var30;
         }
         case 16 -> {
            byte var31 = 8;
            yield var31;
         }
         case 17 -> {
            byte var32 = 50;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 12;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 37;
            yield var36;
         }
         case 22 -> {
            byte var37 = 7;
            yield var37;
         }
         case 23 -> {
            byte var38 = 53;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 57;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 55;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 31;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 9;
            yield var47;
         }
         case 33 -> {
            byte var48 = 33;
            yield var48;
         }
         case 34 -> {
            byte var49 = 60;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 6;
            yield var51;
         }
         case 37 -> {
            byte var52 = 24;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 56;
            yield var55;
         }
         case 41 -> {
            byte var56 = 11;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 25;
            yield var58;
         }
         case 44 -> {
            byte var59 = 29;
            yield var59;
         }
         case 45 -> {
            byte var60 = 14;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 15;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 5;
            yield var65;
         }
         case 51 -> {
            byte var66 = 41;
            yield var66;
         }
         case 52 -> {
            byte var67 = 35;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 13;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 61;
            yield var71;
         }
         case 57 -> {
            byte var72 = 20;
            yield var72;
         }
         case 58 -> {
            byte var73 = 28;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 16;
            yield var76;
         }
         case 62 -> {
            byte var77 = 4;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "7^\u0012,\u0017\n7^\u0005p\u001b\u0005-\u0015\u0005n\u001b\u0010*dQ6L";
      o[1] = "4\u001e'\u0006\\[4\u001e0ZPT.U0DPA)$b\u001e\u0007\u0003";
      o[2] = "3hgfH\u0006%hb<[\u00112#a:W\u0005#dv-\u001c\u0013\u0003";
      o[3] = "l?\u001bI>(\u0019\u001f\u0010F/gx\u0011\u001bM+=\f";
      o[4] = int.class;
      p[4] = "java/lang/Integer";
      o[5] = "8\\Zk=~.\\_1.i9\u0017\\7\"}(PK io\u0019";
      o[6] = "\u0017y6\u0002\u0010\u007f\u001cv'Msr\t{(&Fp\u0018h4\nQ}";
      o[7] = "z\b[\u0011&\u001cz\bLM*\u0013`CLS*\u0006g2\u001e\brL";
      o[8] = "'$\t\u0004%2'$\u001eX)==o\u001eF)(:\u001eN\u001epb";
      o[9] = "fO?\u001d\u000e\u0018fO(A\u0002\u0017|\u0004(_\u0002\u0002{u}\u000bUC";
      o[10] = "Jj50(BJj\"l$MP!\"r$XWPr/u";
      o[11] = "\u0001gI&~b\u0001g^zrm\u001b,^drx\u001c]\f0*8";
      o[12] = "\u0000m]0W\u0005\u0000mJl[\n\u001a&Jr[\u001f\u001dW\u001c-\b]";
      o[13] = boolean.class;
      p[13] = "java/lang/Boolean";
      o[14] = "Hg\u0007aaUHg\u0010=mZR,\u0010#mOU]J|?\r";
      o[15] = "76h+\rh<9ydlf72}>";
      o[16] = "\u0004!H<uL\u0012!Mff[\u0005jN`jO\u0014-Yw!X,";
      o[17] = "\u0011N+P`2dn _q}\u0005`+Tu'q";
      o[18] = void.class;
      p[18] = "java/lang/Void";
      o[19] = "(]\nA:\u0004(]\u001d\u001d6\u000b2\u0016\u001d\u00036\u001e5gL\\b]";
      o[20] = "\u0017\"#1{L\u0017\"4mwC\ri4swV\n\u0018a, ";
      o[21] = "G\u001a\u00007NUG\u001a\u0017kBZ]Q\u0017uBOZ F!\u0017\n\r\u001c\u0018xPOvML-\u0014";
      o[22] = "W>y\ndfA>|PwqVu\u007fV{eG2hA0u\\";
      o[23] = "dHCF-\u0001\u0011hHI<NpfCB8\u0014\u0004";
      o[24] = "\u0001n?\u0017L\u0011\na.X \u0012\u0004c,\u0017\f";
      o[25] = "kN\u007f5^S}NzoMDj\u0005yiAP{Bn~\nEV";
      o[26] = "L-\tqn\u001c9\r\u0002~\u007fSX\u0003\tu{\t,";
      o[27] = ")iP\\\u000b!)iG\u0000\u0007.3\"G\u001e\u0007;4S\u0016AUp";
      o[28] = "o+X\u0006Tly+]\\G{n`^ZKo\u007f'IM\u0000xM";
      o[29] = "Q\u000e\u0011o\b\u0019$.\u001a`\u0019VE \u0011k\u001d\f1";
      o[30] = "Vai<GEVa~`KJL*~~K_K[, \u001c\u0014";
      o[31] = ">A]^z\bKaVQkG*o]Zo\u001d^";
      o[32] = "7~^7a\u000e!~[mr\u001965Xk~\r'rO|5\u001dc";
      o[33] = ":+<#\u001fnO\u000b7,\u000e!.\u0005<'\n{Z";
      o[34] = "f3So{Rf3D3w]|xD-wH{\t\u0016v&\t";
      o[35] = "\u001e\f\"~6zk,)q'5\n\"\"z#o~";
      o[36] = "\u0000f:Y^\u001a\u0016f?\u0003M\r\u0001-<\u0005A\u0019\u0010j+\u0012\n\u000e5";
      o[37] = "WD;+o\u000b\"d0$~DCj;/z\u001e7";
      o[38] = "\\;cFb\u0017\\;t\u001an\u0018Fpt\u0004n\rA\u0001.[<J";
      o[39] = "S\u0014\\CB=S\u0014K\u001fN2I_K\u0001N'N.\u0019_\u001ef\b";
      o[40] = "b-A/\u0000a|%[`}q|";
      o[41] = "xmG/(s\rML 9<lCG+=f\u0018";
      o[42] = "3QY_j2FqRP{}'\u007fY[\u007f'S";
      o[43] = "z\u0002][~dd\nG\u0014\u0019eu\u0011JN?c";
      o[44] = "=SanQW=Sv2]X'\u0018v,]M i#x\u0004\u000e";
      o[45] = "\u0017\u000eCv\u000bj\u0013\u0013Cg\u0016jP\u001c\fp\u0011v\n\u0013\u0001-\na\u0014\u001f\u000ew\u0016-1\u0018\u0007f\u0006wL3\u0003w(b\u000e\t";
      o[46] = "h2=$*~l/=57~/ r\"0bu/\u007f\u007f+uk#p%79N$y4'c3\u000f}%\tvq";
      o[47] = "\u0011 >3\u0014\u0007\u0015=>\"\t\u0007V2q5\u000e\u001b\f=|h\u0015\f\u00121s2\t@76z#\u0019\u001a1 u4\u001b\f\u00141";
      o[48] = "wfE/\u001eHs{E>\u0003H0t\n)\u0004Tj{\u0007t\u001fCtw\b.\u0003\u000fQp\u0001?\u0013UWf\u000e(\u0011Uq`";
      o[49] = "0LIAy;4QIPd;w^\u0006Gc'-Q\u000b\u001ax03]\u0004@d|\u0016Z\rQt&kq\t@Z3)\u001c\"Zc  ";
      o[50] = "a9LRaGa9[\u000emH{r[\u0010m]|\u0003\tK5\u001c";
      o[51] = "S?2i\u0002#S?%5\u000e,It%+\u000e9N\u0005\u007ft_~";
      o[52] = ".m\u0007\u00017'.m\u0010];(4&\u0010C;=3WB\u0017j|";
      o[53] = "f\\]E\u0019\ng\u0016\tIpW7Q\u0004O\u001ceg\u001dZ\u0019L23\u0015\u001fM\u000fLk@XTp[;R\u0007E\u0011\\+B\b(";
      o[54] = "\u000fucg:|]w1*Jte7j#0s\u000bpw%v\u001e\u000e.65,~X 4hJ";
      o[55] = "9\"330\u0003;b:WdS)?8;V\u0005lbcg\u0001C+do'>Qje_";
      o[56] = "xrzAa\u000bh64I\u001e\u001aw#oKIJ-w5\u001a\u001e\u001a*?mXa\nnqe";
      o[57] = "K=\u007f@HY\b+jF6\u0019I*\u0001PW\u001eW;`WG\u000eXV:\u0007R[Z3;SU\u00104m?]\f\u000fQlkZGa";
      o[58] = "|\u0014<2RZ%W'.#\nFR>-Y\u000b(\u0015#+\u001ff}\u00109lM\u0003|D>'#";
      o[59] = "\u0000s\u001d,\u000e\u001d\u00019I g@Q~D&\u000br\u00033\u001ayg\u0014PiJ8^\u0014Q9\u001fA";
      o[60] = "$e\fNZa?yPQ;\u007f$sUYl(}/\u0001\r;p>#JTKk\"\u007fU";
      o[61] = "O\u0000O./3\rDH0O/^\f\bJ&(L\u001f\u0019+!8\\\u0010t";
      o[62] = ")\u0013e/\nt<Y>?vz6\u00158)\u001aHfVeuG\u001f X2.\u0012!eV\"(v";
      o[63] = "%o1g\u001fe`a!a{:\"3!n\u0007<$^'{@?>$e?G!^";
      o[64] = "U\u000bX\tW(\fHC\u0015&}oMZ\u0016\\y\u0001\nG\u0010\u001a\u0014T\u000f]WHqU[Z\u001c&";
      o[65] = "7\u0005\u0013\u0011(f4JDF\u0015uOGJ\u0003oq!\u0000W\u0005)\u001c$^\u0016\u0015s|rP\u0014H\u0015";
      o[66] = "\by\u000e_MK\u001a8\u000foX\u0019\tgR\u0003jII<\u0005o\u0006J\u0011=[\n\u0007\u001e\u0016v5SLM\u0018n\rR\u0006\u0019\u0014\u0007";
      o[67] = ",:a\u0016\u0001ln;nGpxp&eA'(*q<\u0012p(ntdR\r)z4=";
      o[68] = ";k\u0010*G\u0018 j\u0001*:\u000f(/\u001f-V=ykEp\u0007ju-\u001b!V\u00068>\u001at:[)8\u00113\u0003[(hDJ";
      o[69] = "\u000f\u0019G \".\u0005F\u0019!\u001a#\nK\u001e+Mp[\u001eJG~rVAB$t-\b@";
      o[70] = "p(;;U\u000f`6'm/Qg+?GSRt9)bB?q;=\u007fQ\u00072-(y/@v><dL\u0007al|\u0006";
      o[71] = "\tX54LF\b\u0012a8%\u001bXUl>I)\u000e\u00101f\u001e~\u000bV3<Z\u0003\nBse%OYBb \u001cOX\u00127Y";
      o[72] = "$W/\u0003c,6\bmD]&8KW\\!\u0017<SkW]rkS,T8s?Tg:";
      o[73] = "O\u0016\"^0DMV+:d\u0014_\u000b)VVG\u001aRs:0\u0015H\u00057\u00030\u0014\u0018PN";
      o[74] = "&g\u0010v2\u0001eq\u0005pLR=a\u0007uLR<3\u0003i,\u000421^\u000f";
      o[75] = "\u000b\u0019bej\bV\u0010t7PW\u0006\u0018}9\u0007\u0000^M\"nPU\u000b\u000e)oa\b\u0002\u0018{";
      o[76] = " }\u0006O\"\u0000yoR\u0002N\u0006\u001b7\u0003[t\u0002~6W\\?l";
      o[77] = "Fq\u00129W\u0013\u0007eE6lG\u0018vO<;\u0010F%\u0012P\u0001G\u0010&D<QP\u0004e";
      o[78] = "sLLo:gr\u0006\u0018cS:\"A\u0015e?\br\rK3n_&\u0005\u000eg,!~PI~S6.B\u0016o21>R\u0019\u0002:>0^\u0018c=. Qu";
      o[79] = "5\u000fBmY34E\u0016a0nd\u0002\u001bg\\\\6OC10zsA\u0001b\n7m\u001bA\u0000";
      o[80] = "i\u001f\t>0m0\\\u0012\"A:SY\u000b!;<=\u001e\u0016'}Qh\u001b\f`/4iO\u000b+A";
      o[81] = "aXe\u000f\u0018}k\u0001eG&/\u000fBeL\\+a\u0005xJ\u001aFd[9Z@&2U;\u0007&";
      o[82] = "(uz0\rZm{j6i\u0003=Dy1\u0016\u0007>%~!\u0006\bS?!:\t\u0000mz/*\u000fd";
      o[83] = "\u0016]~E\u0011E\u0003\u0017%Um@\u0005J'H:\u0012U\u001cs\u0019m\\\u001e\u001a\"X\u0006ITA2";
      o[84] = "JS!\u0011M-\u0013Au\\!*q\u0019$\u0005\u001b/\u0014\u0018p\u0002PA";
      o[85] = "r2b\u000byy\u007f)t\u0006I~u<k\u0004 rL2k\u0014$\u0014#7d\u00070-#64RI";
      o[86] = "\u0011CwsgKN^2f\u0001EqEiw{B\u001f\u0002tq=/@Uabx\u0016@T17\u0001";
      o[87] = "5*;Kg|> {J\u000b.W%+_h*6\";OgG";
      o[88] = "Y1Ufr&\u0018%\u0002iIr\u00076\bc\u001e%YaP\u000f%a\n?]2'!\u0003";
      o[89] = "}J]\u0003ww\"W\u0018\u0016\u0011z\u001dLC\u0007k~s\u000b^\u0001-\u0013vU\u001f\u0011ws [\u001dL\u0011";
      o[90] = "!{`\b\"S#;ilv\u00031fk\u0000DPt>0lwQpa4\u000f}\u000e.`\f\u0007vQ `lQxS}\u0006";
      o[91] = "H\rp3s\u001cBTp{MN&\u0017pp7JHPmvq'\u001dUw1#B\u001c\u0001pzM";
      o[92] = " \u0006\"Q7:g\u0011p\u0011U8#\u00136G)>%~<K8(.\u0017*\u001f+2_";
      o[93] = "\u0018\u0010_]/BZTXCOX\r\u0017\"T?Dd]\bR!A]]\t\u0002t8";
      o[94] = "\n\r\u0001tPL\u001e\u0016\u0001u\"To\u0018\u0010iXP\u0001_\ro\u001e=\u0004\u0001L\u007fD]R\u000fN\"\"";
      o[95] = "\u007f\u0011G\fu7hIY\u0000\u00179uR]\u0002{\u000b'\u0013\r[\u0017g&J\u0007\u000brfrMLe";
      o[96] = "\u0017\u0007p)\u000fiG\u0010dj``\u0017\u0015ys\fR@X#$`4\u0016\u0002wmY4\u0017R\"\u0014";
      o[97] = "o6\b[wzmv\u0001?#*\u007f+\u0003S\u0011y;w[?z6:&\r\u0007{|n*d";
      o[98] = "\u0002Z\u0007\u00148d[\u0019\u001c\bI18\\\t\t8'\u0003\u000b\u001b\u001b*X\u0004\u000f\u001f\u00016cS\u001d\r\u0013I";
      o[99] = "PBu\\|&R\u0002|8(v@_~T\u001a$\u0007\u0003%8*$FV{S=|XZ\u0019";
      o[100] = "\t:D\u0018MLO Y\u0019<^\u0011&_Nk\u000eKu\u0000\u001b<YH0^]B\u0001\u001dwG";
      o[101] = "y\u0002mn\u0006\u0006)\u0015y-i\u000fy\u0010d4\u0005=+Q8kVjnUzj\u0019T(\u0003:6i\u0001qSi5\tW\u007fQ4S";
      o[102] = "\u001b&wn0pBelrA.!`uq;!O'hw}LJy)g',\u001cw+:A";
      o[103] = "S!JnP.\ry\f-2y\u0002%\u0016|e)XtH(2'\u001d,\u0019|^j\u000e-L";
      o[104] = "Q\n\u001bZ(+\u0017\u0010\u0006[Y9I\u0016\u0000\f\u000ek\u0019EX[Y>\u0010\u0000\u0001\u001f'fEG\u0018";
      o[105] = "l\f\u0016N\u007fq~ST\tA{p\u0010l\u001a0\u0014t\rP\u0014,us\u001d@\u001bA";
      o[106] = "\u0000Z~pB\u0005\u0001\u0010*|+XQW'zGj\u0001\u001by \u0014=NQz|WV[\u001b!l+";
      o[107] = "HSS/2,\u001e\u0012\u0001b \u0012\u001f\n\u00057'EAVYcKc\u000bT\u00121q.\u0015\u000eR";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1068931611420205L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1068931611420205L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1068931611420205L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 75;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 103;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 116;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 115;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 223;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 242;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 75;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 103;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 116;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eT_C0255",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
