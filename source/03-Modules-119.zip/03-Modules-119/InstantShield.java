package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.KeyBindingAccessor;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.InputUtil.Key;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

public class InstantShield extends Module {
   private BindSetting f;
   private BooleanSetting d;
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private int a = -1;
   private int c = -1;
   private int e = -1;
   private static final long k = 97022718864636L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[82];
   private static final String[] p = new String[82];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 118200798181401L ^ 84871482890255L;
      var10001 = 118200798181401L ^ 105405825309751L;
      var10001 = 118200798181401L ^ 60438068678679L;
      var10001 = 118200798181401L ^ 25515460724885L;
      var10001 = 118200798181401L ^ 77528228232982L;
      var10001 = 118200798181401L ^ 4483721217589L;
      var10001 = 118200798181401L ^ 120219954649092L;
      var10001 = 118200798181401L ^ 7894053946418L;
      int var20 = Event.cReturningInt();
      int var195 = var20;
      MinecraftClient var194 = b;
      MinecraftClient var123 = var194;
      MinecraftClient var122 = var194;
      if (var195 != 0) {
         MinecraftClient var24 = var122;
         ClientPlayerEntity var196 = var24.player;
         if (var196 == null) {
            return;
         }

         MinecraftClient var197 = b;
         var123 = var197;
      }

      int var199 = var20;
      MinecraftClient var198 = var123;
      MinecraftClient var125 = var198;
      MinecraftClient var124 = var198;
      if (var199 != 0) {
         MinecraftClient var27 = var124;
         ClientWorld var200 = var27.world;
         if (var200 == null) {
            return;
         }

         var125 = b;
      }

      MinecraftClient var30 = var125;
      ClientPlayerEntity var31 = var30.player;
      int var10000 = (((var31.isAlive()) ? 1 : 0));
      int var202 = var20;
      byte var201 = (byte)var10000;
      int var127 = var201;
      byte var126 = var201;
      if (var202 != 0) {
         byte var203 = var126;
         if (var203 == 0) {
            Object[] var34 = new Object[0];
            InstantShield var33 = this;
            var33.lReturningVoid(var34);
            Object[] var36 = new Object[]{119491339910187L};
            InstantShield var35 = this;
            var35.mReturningVoid(var36);
            return;
         }

         var127 = this.c;
      }

      int var144;
      label268: {
         int var143;
         label267: {
            label282: {
               int var141;
               label283: {
                  int var206 = var20;
                  
                  int var139 = var204;
                  byte var140 = var205;
                  int var128 = var204;
                  byte var129 = var205;
                  if (var206 != 0) {
                     int var137;
                     label262: {
                        Object var136;
                        label261: {
                           byte var208 = var129;
                           int var207 = var128;
                           if (var207 != var208) {
                              MinecraftClient var39 = b;
                              ClientPlayerEntity var40 = var39.player;
                              PlayerInventory var322 = var40.getInventory();
                              int var42 = this.c;
                              PlayerInventory var41 = var322;
                              ItemStack var43 = var41.getStack(var42);
                              Item var323 = var43.getItem();
                              int var210 = var20;
                              Item var209 = var323;
                              var136 = var209;
                              Item var130 = var209;
                              if (var210 == 0) {
                                 break label261;
                              }

                              Item var211 = var130;
                              Item var131 = var211;
                              Item var213 = Items.SHIELD;
                              Item var212 = var131;
                              label258:
                              if (var212 != var213) {
                                 label285: {
                                    int var215 = var20;
                                    PacketQueueManager var214 = Prestige.u;
                                    PacketQueueManager var134 = var214;
                                    PacketQueueManager var132 = var214;
                                    if (var215 != 0) {
                                       PacketQueueManager var216 = var132;
                                       PacketQueueManager var133 = var216;
                                       PacketQueueManager var217 = var133;
                                       if (var217 == null) {
                                          break label285;
                                       }

                                       var134 = Prestige.u;
                                    }

                                    Object[] var49 = new Object[]{42539134525462L};
                                    PacketQueueManager var48 = var134;
                                    var10000 = (((var48.aReturningBoolean(var49)) ? 1 : 0));
                                    int var219 = var20;
                                    byte var218 = ((byte)(var10000));
                                    var137 = var218;
                                    byte var135 = var218;
                                    if (var219 == 0) {
                                       break label262;
                                    }

                                    byte var220 = var135;
                                    if (var220 != 0) {
                                       break label258;
                                    }
                                 }

                                 Object[] var52 = new Object[0];
                                 InstantShield var51 = this;
                                 var51.lReturningVoid(var52);
                              }
                           }

                           BindSetting var54 = this.f;
                           var136 = var54.aReturningObject();
                        }

                        Integer var55 = (Integer)var136;
                        var137 = var55;
                     }

                     int var222 = var20;
                     int var221 = var137;
                     var141 = var221;
                     int var138 = var221;
                     if (var222 == 0) {
                        break label283;
                     }

                     
                     var139 = var223;
                     var140 = var224;
                  }

                  byte var226 = var140;
                  int var225 = var139;
                  if (var225 == var226) {
                     break label282;
                  }

                  BindSetting var325 = this.f;
                  Object[] var58 = new Object[]{122678057516588L};
                  BindSetting var57 = var325;
                  byte var227 = ((byte)((var57.cReturningBoolean(var58)) ? 1 : 0));
                  var141 = var227;
               }

               int var229 = var20;
               int var228 = var141;
               var143 = var228;
               int var142 = var228;
               if (var229 == 0) {
                  break label267;
               }

               int var230 = var142;
               if (var230 != 0) {
                  var143 = 1;
                  break label267;
               }
            }

            var144 = 0;
            break label268;
         }

         int var231 = var143;
         var144 = var231;
      }

      int var21;
      int var149;
      label232: {
         int var148;
         label231: {
            label286: {
               var21 = var144;
               int var233 = var20;
               int var232 = var21;
               int var146 = var232;
               int var145 = var232;
               if (var233 != 0) {
                  int var234 = var145;
                  if (var234 == 0) {
                     break label286;
                  }

                  byte var235 = ((byte)((this.i) ? 1 : 0));
                  var146 = var235;
               }

               int var237 = var20;
               int var236 = var146;
               var148 = var236;
               int var147 = var236;
               if (var237 == 0) {
                  break label231;
               }

               int var238 = var147;
               if (var238 == 0) {
                  var148 = 1;
                  break label231;
               }
            }

            var149 = 0;
            break label232;
         }

         int var239 = var148;
         var149 = var239;
      }

      int var22;
      int var154;
      label219: {
         int var153;
         label218: {
            label287: {
               var22 = var149;
               int var241 = var20;
               int var240 = var21;
               int var151 = var240;
               int var150 = var240;
               if (var241 != 0) {
                  int var242 = var150;
                  if (var242 != 0) {
                     break label287;
                  }

                  byte var243 = ((byte)((this.i) ? 1 : 0));
                  var151 = var243;
               }

               int var245 = var20;
               int var244 = var151;
               var153 = var244;
               int var152 = var244;
               if (var245 == 0) {
                  break label218;
               }

               int var246 = var152;
               if (var246 != 0) {
                  var153 = 1;
                  break label218;
               }
            }

            var154 = 0;
            break label219;
         }

         int var247 = var153;
         var154 = var247;
      }

      int var23 = var154;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(var21);
      MinecraftClient var67 = b;
      int var249 = var20;
      Screen var248 = var67.currentScreen;
      Screen var174 = var248;
      Screen var155 = var248;
      if (var249 != 0) {
         Screen var250 = var155;
         label176:
         if (var250 == null) {
            BindSetting var69 = this.f;
            var10000 = (((var69.bReturningVoid()) ? 1 : 0));
            int var252 = var20;
            byte var251 = ((byte)(var10000));
            int var168 = var251;
            byte var156 = var251;
            if (var252 != 0) {
               byte var253 = var156;
               byte var157 = var253;
               byte var254 = var157;
               if (var254 != 0) {
                  int var162;
                  int var256 = var20;
                  int var255 = var22;
                  var162 = var255;
                  int var158 = var255;
                  label198:
                  if (var256 != 0) {
                     int var257 = var158;
                     int var159 = var257;
                     int var258 = var159;
                     if (var258 != 0) {
                        int var260 = var20;
                        int var259 = this.a;
                        var162 = var259;
                        int var160 = var259;
                        if (var260 == 0) {
                           break label198;
                        }

                        int var261 = var160;
                        int var161 = var261;
                        
                        if (var262 == var263) {
                           Object[] var77 = new Object[]{57575920903214L};
                           InstantShield var76 = this;
                           var76.jReturningVoid(var77);
                           int var264 = var20;
                           if (var264 != 0) {
                              break label176;
                           }
                        }
                     }

                     int var265 = var23;
                     var162 = var265;
                  }

                  InstantShield var167;
                  label290: {
                     int var267 = var20;
                     int var266 = var162;
                     int var166 = var266;
                     int var163 = var266;
                     if (var267 != 0) {
                        int var268 = var163;
                        if (var268 == 0) {
                           break label176;
                        }

                        int var270 = var20;
                        InstantShield var269 = this;
                        var167 = var269;
                        InstantShield var164 = var269;
                        if (var270 == 0) {
                           break label290;
                        }

                        InstantShield var271 = var164;
                        InstantShield var165 = var271;
                        int var272 = var165.a;
                        var166 = var272;
                     }

                     
                     if (var273 == var274) {
                        break label176;
                     }

                     InstantShield var275 = this;
                     var167 = var275;
                  }

                  Object[] var85 = new Object[]{102765968435214L};
                  InstantShield var84 = var167;
                  var84.kReturningVoid(var85);
                  int var276 = var20;
                  if (var276 != 0) {
                     break label176;
                  }
               }

               int var277 = var22;
               var168 = var277;
            }

            InstantShield var173;
            label292: {
               int var279 = var20;
               int var278 = var168;
               int var172 = var278;
               int var169 = var278;
               if (var279 != 0) {
                  int var280 = var169;
                  if (var280 == 0) {
                     break label176;
                  }

                  int var282 = var20;
                  InstantShield var281 = this;
                  var173 = var281;
                  InstantShield var170 = var281;
                  if (var282 == 0) {
                     break label292;
                  }

                  InstantShield var283 = var170;
                  InstantShield var171 = var283;
                  int var284 = var171.a;
                  var172 = var284;
               }

               
               if (var285 != var286) {
                  Object[] var91 = new Object[]{102765968435214L};
                  InstantShield var90 = this;
                  var90.kReturningVoid(var91);
                  int var287 = var20;
                  if (var287 != 0) {
                     break label176;
                  }
               }

               InstantShield var288 = this;
               var173 = var288;
            }

            Object[] var95 = new Object[]{57575920903214L};
            InstantShield var94 = var173;
            var94.jReturningVoid(var95);
         }

         MinecraftClient var96 = b;
         var174 = var96.currentScreen;
      }

      int var290 = var20;
      Screen var289 = var174;
      Screen var190 = var289;
      Screen var175 = var289;
      if (var290 != 0) {
         Screen var291 = var175;
         label160:
         if (var291 == null) {
            int var294 = var20;
            
            int var180 = var292;
            byte var181 = var293;
            int var176 = var292;
            byte var177 = var293;
            if (var294 != 0) {
               byte var296 = var177;
               int var295 = var176;
               int var178 = var295;
               byte var179 = var296;
               byte var298 = var179;
               int var297 = var178;
               if (var297 == var298) {
                  break label160;
               }

               
               var180 = var299;
               var181 = var300;
            }

            int var303 = var20;
            byte var302 = var181;
            int var301 = var180;
            int var184 = var301;
            int var185 = var302;
            int var182 = var301;
            byte var183 = var302;
            if (var303 != 0) {
               byte var305 = var183;
               int var304 = var182;
               if (var304 == var305) {
                  break label160;
               }

               Object[] var102 = new Object[]{49487520630543L};
               var10000 = InventoryUtil.aReturningInt(var102);
               int var307 = this.c;
               int var306 = var10000;
               var184 = var306;
               var185 = var307;
            }

            int var310 = var20;
            int var309 = var185;
            int var308 = var184;
            int var188 = var308;
            int var189 = var309;
            int var186 = var308;
            int var187 = var309;
            if (var310 != 0) {
               int var312 = var187;
               int var311 = var186;
               if (var311 == var312) {
                  break label160;
               }

               int var314 = this.c;
               int var313 = this.e;
               var188 = var313;
               var189 = var314;
            }

            Object[] var10004 = new Object[]{null, null, 7516849659933L};
            var10004[1] = var189;
            var10004[0] = var188;
            Object[] var106 = var10004;
            InventoryUtil.fReturningBoolean(var106);
            Object[] var108 = new Object[0];
            InstantShield var107 = this;
            var107.lReturningVoid(var108);
         }

         MinecraftClient var109 = b;
         var190 = var109.currentScreen;
      }

      InstantShield var193;
      label144: {
         Screen var315 = var190;
         if (var315 == null) {
            int var317 = var20;
            InstantShield var316 = this;
            var193 = var316;
            InstantShield var191 = var316;
            if (var317 == 0) {
               break label144;
            }

            InstantShield var318 = var191;
            InstantShield var192 = var318;
            Object[] var112 = new Object[]{137112593592460L};
            InstantShield var111 = var192;
            boolean var319 = var111.dReturningBoolean(var112);
            if (var319) {
               MinecraftClient var114 = b;
               GameOptions var115 = var114.options;
               KeyBinding var116 = var115.useKey;
               var116.setPressed(true);
               int var320 = var20;
               if (var320 != 0) {
                  return;
               }
            }
         }

         InstantShield var321 = this;
         var193 = var321;
      }

      Object[] var121 = new Object[]{119491339910187L};
      InstantShield var120 = var193;
      var120.mReturningVoid(var121);
   }

   
   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 97022718864636L ^ var2;
      long var4 = var2 ^ 71891762532317L;
      long var6 = var2 ^ 50116940303780L;
      long var8 = var2 ^ 117332261611727L;
      int var10 = Event.cReturningInt();
      MinecraftClient var13 = b;
      ClientPlayerEntity var14 = var13.player;
      ItemStack var15 = var14.getMainHandStack();
      Item var10000 = var15.getItem();
      Item var43 = Items.SHIELD;
      Item var42 = var10000;
      if (var42 != var43) {
         while (true) {
            short var10001 = 9180;
            long var10002 = 2598930052223886862L ^ var2;
            byte var45 = 9;
            int var44 = var11;
            if (var44 < var45) {
               MinecraftClient var17 = b;
               ClientPlayerEntity var18 = var17.player;
               PlayerInventory var77 = var18.getInventory();
               int var20 = var11;
               PlayerInventory var19 = var77;
               ItemStack var21 = var19.getStack(var20);
               var10000 = var21.getItem();
               int var48 = var10;
               Item var47 = Items.SHIELD;
               Item var46 = var10000;
               Item var40 = var46;
               Item var41 = var47;
               Item var36 = var46;
               Item var37 = var47;
               if (var48 != 0) {
                  Item var50 = var37;
                  Item var49 = var36;
                  if (var49 == var50) {
                     Object[] var23 = new Object[]{var4};
                     this.a = InventoryUtil.aReturningInt(var23);
                     this.c = var11;
                     this.e = -1;
                     Object[] var10003 = new Object[]{null, var6};
                     var10003[0] = var11;
                     Object[] var24 = var10003;
                     InventoryUtil.aReturningVoid(var24);
                     return;
                  }

                  var11++;
                  int var51 = var10;
                  if (var51 != 0) {
                     continue;
                  }

                  BooleanSetting var26 = this.d;
                  Boolean var27 = (Boolean)var26.aReturningObject();
                  byte var79 = ((byte)(((java.lang.Boolean)(var27)).booleanValue() ? 1 : 0));
                  int var53 = var10;
                  byte var52 = var79;
                  byte var39 = var52;
                  byte var38 = var52;
                  if (var53 != 0) {
                     byte var54 = var38;
                     if (var54 == 0) {
                        return;
                     }

                     short var80 = 3883;
                     long var85 = 7289330802159078136L ^ var2;
                     var39 = 9;
                  }

                  var11 = var39;
               } else {
                  Item var58 = var41;
                  Item var57 = var40;
                  if (var57 == var58) {
                     Object[] var34 = new Object[]{var4};
                     int var12 = InventoryUtil.aReturningInt(var34);
                     this.a = var12;
                     this.c = var12;
                     this.e = var11;
                     Object[] var10004 = new Object[]{null, null, var8};
                     var10004[1] = var12;
                     var10004[0] = var11;
                     Object[] var35 = var10004;
                     InventoryUtil.fReturningBoolean(var35);
                     return;
                  }

                  var11++;
                  int var59 = var10;
                  if (var59 == 0) {
                     return;
                  }
               }
            } else {
               BooleanSetting var63 = this.d;
               Boolean var64 = (Boolean)var63.aReturningObject();
               byte var81 = ((byte)(((java.lang.Boolean)(var64)).booleanValue() ? 1 : 0));
               int var72 = var10;
               byte var71 = var81;
               byte var68 = var71;
               byte var67 = var71;
               if (var72 != 0) {
                  byte var73 = var67;
                  if (var73 == 0) {
                     return;
                  }

                  short var82 = 3883;
                  long var86 = 7289330802159078136L ^ var2;
                  var68 = 9;
               }

               var11 = var68;
            }

            int var76;
            do {
               var10001 = 27795;
               var10002 = 3442304398737189187L ^ var2;
               byte var56 = 36;
               int var55 = var11;
               if (var55 >= var56) {
                  return;
               }

               MinecraftClient var29 = b;
               ClientPlayerEntity var30 = var29.player;
               PlayerInventory var83 = var30.getInventory();
               int var32 = var11;
               PlayerInventory var31 = var83;
               ItemStack var33 = var31.getStack(var32);
               var10000 = var33.getItem();
               Item var70 = Items.SHIELD;
               Item var69 = var10000;
               Item var75 = var70;
               Item var74 = var69;
               if (var74 == var75) {
                  Object[] var65 = new Object[]{var4};
                  int var62 = InventoryUtil.aReturningInt(var65);
                  this.a = var62;
                  this.c = var62;
                  this.e = var11;
                  Object[] var89 = new Object[]{null, null, var8};
                  var89[1] = var62;
                  var89[0] = var11;
                  Object[] var66 = var89;
                  InventoryUtil.fReturningBoolean(var66);
                  return;
               }

               var11++;
               var76 = var10;
            } while (var76 != 0);

            return;
         }
      }
   }

   private void kReturningVoid(Object[] var1) {
      label17: {
         long var2 = (Long)var1[0];
         var2 = 97022718864636L ^ var2;
         long var4 = var2 ^ 75585572798852L;
         long var6 = var2 ^ 3972485948655L;
         int var8 = Event.bReturningInt();
         int var19 = var8;
         int var18 = this.e;
         int var17 = var18;
         int var16 = var18;
         if (var19 == 0) {
            
            if (var20 != var21) {
               int var10000 = this.e;
               int var10001 = this.c;
               Object[] var10004 = new Object[]{null, null, var6};
               var10004[1] = var10001;
               var10004[0] = var10000;
               Object[] var10 = var10004;
               InventoryUtil.fReturningBoolean(var10);
               int var22 = var8;
               if (var22 == 0) {
                  break label17;
               }
            }

            int var23 = this.a;
            var17 = var23;
         }

         Object[] var10003 = new Object[]{null, var4};
         var10003[0] = var17;
         Object[] var13 = var10003;
         InventoryUtil.aReturningVoid(var13);
      }

      Object[] var15 = new Object[0];
      InstantShield var14 = this;
      var14.lReturningVoid(var15);
   }

   private void lReturningVoid(Object[] var1) {
      this.a = -1;
      this.c = -1;
      this.e = -1;
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 97022718864636L ^ var2;
      long var4 = var2 ^ 80946903914255L;
      int var6 = Event.cReturningInt();
      MinecraftClient var7 = b;
      ClientPlayerEntity var8 = var7.player;
      ItemStack var9 = var8.getMainHandStack();
      Item var10000 = var9.getItem();
      int var26 = var6;
      Item var25 = Items.SHIELD;
      Item var24 = var10000;
      Item var18 = var24;
      Item var19 = var25;
      Item var16 = var24;
      Item var17 = var25;
      if (var26 != 0) {
         Item var28 = var17;
         Item var27 = var16;
         if (var27 == var28) {
            return true;
         }

         MinecraftClient var12 = b;
         ClientPlayerEntity var13 = var12.player;
         ItemStack var14 = var13.getOffHandStack();
         var10000 = var14.getItem();
         var19 = Items.SHIELD;
         var18 = var10000;
      }

      Item var30 = var19;
      Item var29 = var18;
      if (var29 == var30) {
         Object[] var15 = new Object[]{var4};
         boolean var38 = ItemUseUtil.eReturningBoolean(var15);
         int var32 = var6;
         boolean var31 = var38;
         boolean var22 = var31;
         boolean var20 = var31;
         if (var32 == 0) {
            return var22;
         }

         boolean var33 = var20;
         boolean var21 = var33;
         boolean var34 = var21;
         if (!var34) {
            return true;
         }
      }

      return false;
   }

   private void mReturningVoid(Object[] var1) {
      int var8;
      label40: {
         int var45;
         label39: {
            int var44;
            label42: {
               long var2 = (Long)var1[0];
               var2 = 97022718864636L ^ var2;
               long var4 = var2 ^ 93447456527916L;
               int var10000 = Event.bReturningInt();
               MinecraftClient var9 = b;
               GameOptions var10 = var9.options;
               KeyBindingAccessor var10001 = new KeyBindingAccessor(var10.useKey);
               Object[] var12 = new Object[]{var4};
               KeyBindingAccessor var11 = var10001;
               Key var13 = var11.aReturningVoid(var12);
               int var7 = var13.getCode();
               int var6 = var10000;
               short var72 = 10314;
               long var10002 = 2628396603878290846L ^ var2;
               int var48 = var6;
               byte var47 = 8;
               int var46 = var7;
               int var42 = var46;
               byte var43 = var47;
               int var34 = var46;
               byte var35 = var47;
               if (var48 == 0) {
                  byte var50 = var35;
                  int var49 = var34;
                  if (var49 < var50) {
                     MinecraftClient var15 = b;
                     Window var16 = var15.getWindow();
                     long var68 = var16.getHandle();
                     int var19 = var7;
                     long var17 = var68;
                     var10000 = GLFW.glfwGetMouseButton(var17, var19);
                     int var52 = var6;
                     int var51 = var10000;
                     int var38 = var51;
                     int var36 = var51;
                     int var39;
                     if (var52 == 0) {
                        int var53 = var36;
                        int var37 = var53;
                        byte var55 = 1;
                        int var54 = var37;
                        if (var54 == var55) {
                           byte var56 = 1;
                           var39 = var56;
                        } else {
                           var39 = 0;
                        }
                     } else {
                        int var57 = var38;
                        var39 = var57;
                     }

                     var8 = var39;
                     int var58 = var6;
                     if (var58 == 0) {
                        break label40;
                     }
                  }

                  MinecraftClient var23 = b;
                  Window var24 = var23.getWindow();
                  long var70 = var24.getHandle();
                  int var27 = var7;
                  long var25 = var70;
                  var10000 = GLFW.glfwGetKey(var25, var27);
                  int var60 = var6;
                  int var59 = var10000;
                  var44 = var59;
                  int var40 = var59;
                  if (var60 != 0) {
                     break label42;
                  }

                  int var61 = var40;
                  int var41 = var61;
                  byte var63 = 1;
                  int var62 = var41;
                  var42 = var62;
                  var43 = var63;
               }

               byte var65 = var43;
               int var64 = var42;
               if (var64 != var65) {
                  var45 = 0;
                  break label39;
               }

               var44 = 1;
            }

            int var66 = var44;
            var45 = var66;
         }

         var8 = var45;
      }

      MinecraftClient var30 = b;
      GameOptions var31 = var30.options;
      int var33 = var8;
      KeyBinding var32 = var31.useKey;
      var32.setPressed(dev.prestige.recovery.SourceSupport.asBoolean(var33));
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 131829670618441L;
      Object[] var7 = new Object[]{var4};
      InstantShield var6 = this;
      var6.mReturningVoid(var7);
      Object[] var9 = new Object[0];
      InstantShield var8 = this;
      var8.lReturningVoid(var9);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(48769565333323L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[4];
      String var6 = "S\u0093\u0081\u0095ô\u0001a½a\u001f^Ñ\ndày";
      int var7 = "S\u0093\u0081\u0095ô\u0001a½a\u001f^Ñ\ndày".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     l = var8;
                     m = new Integer[4];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "cÅÒ\u009aÞAºî\u0081\bûnÒ*]Ë";
                  var7 = "cÅÒ\u009aÞAºî\u0081\bûnÒ*]Ë".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3329;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eU", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eU_C0257",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 31;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 16;
            yield var18;
         }
         case 4 -> {
            byte var19 = 27;
            yield var19;
         }
         case 5 -> {
            byte var20 = 34;
            yield var20;
         }
         case 6 -> {
            byte var21 = 22;
            yield var21;
         }
         case 7 -> {
            byte var22 = 58;
            yield var22;
         }
         case 8 -> {
            byte var23 = 46;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 8;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 29;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 9;
            yield var30;
         }
         case 16 -> {
            byte var31 = 17;
            yield var31;
         }
         case 17 -> {
            byte var32 = 55;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 33;
            yield var34;
         }
         case 20 -> {
            byte var35 = 49;
            yield var35;
         }
         case 21 -> {
            byte var36 = 3;
            yield var36;
         }
         case 22 -> {
            byte var37 = 12;
            yield var37;
         }
         case 23 -> {
            byte var38 = 13;
            yield var38;
         }
         case 24 -> {
            byte var39 = 25;
            yield var39;
         }
         case 25 -> {
            byte var40 = 38;
            yield var40;
         }
         case 26 -> {
            byte var41 = 14;
            yield var41;
         }
         case 27 -> {
            byte var42 = 23;
            yield var42;
         }
         case 28 -> {
            byte var43 = 42;
            yield var43;
         }
         case 29 -> {
            byte var44 = 35;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 40;
            yield var46;
         }
         case 32 -> {
            byte var47 = 30;
            yield var47;
         }
         case 33 -> {
            byte var48 = 4;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 32;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 5;
            yield var54;
         }
         case 40 -> {
            byte var55 = 52;
            yield var55;
         }
         case 41 -> {
            byte var56 = 21;
            yield var56;
         }
         case 42 -> {
            byte var57 = 57;
            yield var57;
         }
         case 43 -> {
            byte var58 = 11;
            yield var58;
         }
         case 44 -> {
            byte var59 = 60;
            yield var59;
         }
         case 45 -> {
            byte var60 = 44;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 10;
            yield var64;
         }
         case 50 -> {
            byte var65 = 45;
            yield var65;
         }
         case 51 -> {
            byte var66 = 15;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 24;
            yield var68;
         }
         case 54 -> {
            byte var69 = 41;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 37;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 61;
            yield var74;
         }
         case 60 -> {
            byte var75 = 62;
            yield var75;
         }
         case 61 -> {
            byte var76 = 6;
            yield var76;
         }
         case 62 -> {
            byte var77 = 36;
            yield var77;
         }
         default -> 2;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "|i|v\"\u001bbaf9_\u000bb";
      o[1] = "1\b0\n\u0000L:\u0007!EaB1\f%\u001f";
      o[2] = "\u0010r?/\t~\u0006r:u\u001ai\u001199s\u0016}\u0000~.d]o1";
      o[3] = int.class;
      p[3] = "java/lang/Integer";
      o[4] = "p\u0011\tz\u000eff\u0011\f \u001dqqZ\u000f&\u0011e`\u001d\u00181ZsA";
      o[5] = "ZTVV\u0007\n/t]Y\u0016ENzVR\u0012\u001f:";
      o[6] = void.class;
      p[6] = "java/lang/Void";
      o[7] = "\n\u000f\"|~\f\u001c\u000f'&m\u001b\u000bD$ a\u000f\u001a\u000337*\u001f\u0001";
      o[8] = "%I\u0013f\u000f\u0006Pi\u0018i\u001eI1g\u0013b\u001a\u0013E";
      o[9] = "_#Z\t\u000bJ*\u0003Q\u0006\u001a\u0005K\rZ\r\u001e_?";
      o[10] = boolean.class;
      p[10] = "java/lang/Boolean";
      o[11] = "Z_Ur4\u0006QPD=W\u000bD]KVb\tUNWzu\u0004";
      o[12] = "(.;/\u0000](.,s\fR2e,m\fG5\u0014~1Y\u0005";
      o[13] = long.class;
      p[13] = "java/lang/Long";
      o[14] = "jP^5h/jPIid p\u001bIwd5wj\u0019*5";
      o[15] = "-yX%8#-yOy4,72Og490C\u001f:`";
      o[16] = "&1k7tW01nmg@'zmkkT6=z| k";
      o[17] = "3.,\u0014h F\u000e'\u001byo'\u0000,\u0010}5S";
      o[18] = "E,d_qDE,s\u0003}K_gs\u001d}^X\u0016#G+\u0018\u000f*|\u0010o^tz G";
      o[19] = "5\u0019\u0011nIU0\f\u001anBN<\u001cX\u0007id\r";
      o[20] = "%(#&d %(4zh/?c4dh:8\u0012d8=";
      o[21] = "\u000b;Y*ZF\u000b;NvVI\u0011pNhV\\\u0016\u0001\u001a0\u0001";
      o[22] = "#\u0005dE1K#\u0005s\u0019=D9Ns\u0007=Q>?!]j\u0013";
      o[23] = "\u00156G{J?\u00156P'F0\u000f}P9F%\b\f\u0002b\u001eo";
      o[24] = "u}O\u0006\u0011>u}XZ\u001d1o6XD\u001d$hG\n\u001fEe";
      o[25] = "V!G:{+].Vu\u0017(S,T:;";
      o[26] = "|\u001eTO\u0001Sj\u001eQ\u0015\u0012D}UR\u0013\u001ePl\u0012E\u0004UG^";
      o[27] = "P\bp/\u007f\u0012P\bgss\u001dJCgms\bM259\"I";
      o[28] = "3(]Bn6F\bVM\u007fy'\u0006]F{#S";
      o[29] = "\riZj,\\xIQe=\u0013\u0019GZn9Im";
      o[30] = "-}\u0019@R|X]\u0012OC39S\u0019DGiM";
      o[31] = "\u001d\u0002\rKG\u0007\u001d\u0002\u001a\u0017K\b\u0007I\u001a\tK\u001d\u00008MV\u001d";
      o[32] = "h\u001c\t[MAc\u0013\u0018\u0014*Cv\u0018\u0018_\u0011";
      o[33] = "NKBx\u00055;kIw\u0014zZeB|\u0010 .";
      o[34] = "c8\u0001<\u000b9u8\u0004f\u0018.bs\u0007`\u0014:s4\u0010w_+Q";
      o[35] = "`\u007fnQ\te\u0015_e^\u0018*tQnU\u001cp\u0000";
      o[36] = "2\u00003|C\n$\u00006&P\u001d3K5 \\\t\"\f\"7\u0017\u0019:\f <MT\u0006\u0017 !M\u00131\u0000";
      o[37] = "$\u00167z~\t$\u0016 &r\u0006>] 8r\u00139,ug+";
      o[38] = "jV \u000bJ$\u001fv+\u0004[k~x \u000f_1\n";
      o[39] = "\n w\u001d)1\u001c rG:&\u000bkqA62\u001a,fV}%)";
      o[40] = "Om[z\u001d]:MPu\f\u0012[C[~\bH/";
      o[41] = "`\tkch\u0011v\tn9{\u0006aBm?w\u0012p\u0005z(<\u0002h";
      o[42] = "n-A\u0016\u0004l\u001b\rJ\u0019\u0015#z\u0003A\u0012\u0011y\u000e";
      o[43] = "4\t|Vw\u001ciTv\\L\u0015\u000e\n!I&\u0016w\u0000`K3\u007f";
      o[44] = "}\u0019,\u0003439\u0010%\u000eJ?FT|\u00103=;XmI#ZzRoN 9)\u0013rCJ";
      o[45] = "R&Z);\n\u0016/S$E\u0007ik\n:<\u0004\u0014g\u001bc,cUm\u0019d/\u0000\u0006,\u0004iE";
      o[46] = "{mW3%\u0011*)\u0019(^\u0010{n\u000b02\"-+Vknuxo\nmb\nu{\u001b>^";
      o[47] = "d\u0004(\u0013b*6\fi\u0017\u0004rf\u00110Jh@4\\h\u001c\u0004xr\u00153C`p:\r4-";
      o[48] = "!\u001c\u0011r We\u0015\u0018\u007f^R\u001aQAa'Yg]P87>%\u001cN?cYzH\\`^";
      o[49] = "BB\u0011(Py\u0005\r\\\u0013Lm\u007f\u0001\u0011jUrD@U\u007f+}C\u0006Sb\u0010<\u0007\u0013-.\u0016?D\u0004WiYr\u007f";
      o[50] = "l\u0004sA2a(\r&\u000fU6P\bwR,8-\u0004f\u000b<_l\u000ed\f?<?Oy\u0001U";
      o[51] = "Mbe<\u0015\u0005\u001dw<>lVEf;3;\u0001\u001b6b_\bIO4o<\u0002U\u001eg";
      o[52] = "ye\\\f\u007f\u001a,oW\u000e\u0015\u0014\u007fiG\by&+)\u001bS\u0015K#eM\u0006lAbgXo";
      o[53] = "-'_\u0004!](:Y\n]C%(A40P\u0002+O{lIz=A\u0003'B&*>Al\\+/GK-^>F\u0004J-F(?\u000e\u000b/SA";
      o[54] = "S\fl]%\u0013I\u0019.ZH\u001bT\u000ftM!\u0017m\u0001t]%q\fY~\u001du\u0016S\rlBH";
      o[55] = "n <J)|3}6@\u0012tT#aUxv-) Wm\u001f";
      o[56] = "\u0001th1h\u0016\u0007jo7X@`jhv&X[+,cX";
      o[57] = "\"\u001e%\u0003M[9\u0006dC\"S!\u001e\u0003\u0010FO*bgHRX.\u001bm\tPMG";
      o[58] = "\u0002Z%\u000eU\tS\u001ek\u0015.\b\u0002Yy\rB:R\u0015!W.R^K$WI\r\nY{j";
      o[59] = "  c\u00040.p5:\u0006I}($=\u000b\u001e*vseg$lu-\"\u0003u(;6";
      o[60] = "8#3408|*fzWo\u0004/7'.ay#&~>\u0006>b&.>\u007f4#$;W";
      o[61] = "n<8b)\u0015*51oW\u001fUqhq.\u001b(}y(>|iw{/=\u001f:6f\"W";
      o[62] = "j1en%\u001de0h7\u0015\u0012\f4x4l\u001cq8im|{3ywj(\u001cl-e5\u0015";
      o[63] = "YHWO\u0001m\t]\u000eMx5]]\rK\u0014\u0007\n\u001bS\u001cCP\u0000X\u001f\u0017\nk\u000eZ\u0011Rx";
      o[64] = "\fH\f<g\u0019HA\u00051\u0019\u00197IT ~NS\u001aQ-zp\u0007\u0010Q+'\u0014T\u0015\\/\u0019";
      o[65] = "\u0000}9!Qr\u000e\u007f7d#,]x+}O\u001e\f8z\"#xU?0e[3^c'\u001a";
      o[66] = "yA\f(G?nP\u0010n)2\u0001N\u0015.\u0010\u007fgA\u0014#I";
      o[67] = "_\u0015~W\nf\u000f\u0000'Us5W\u0011 X$b\bM|4\u001a4P\u001f;I\n \\L";
      o[68] = "#N5 eer\n{;\u001ed#Mi#rVp\t5{\u001en'I7\"#</\b3D";
      o[69] = "\r\u001b4ec\u0005V@4n\u001e]g\u0006-7gS\u001a\n<nw4\f\n77t_Y\u0000<5\u001e";
      o[70] = "]-\u001cq@\u0000B~\u0018d>\u001e]8\u0012lR,\n\u007fN;\u0007{\u000fu\u001c6\u0003\u001cP!\u000ei>GJ6Oa]\u0014\u000b+B\u000b";
      o[71] = "yF@oHxtRQ<tbzGA2\u0018P*\u0007\u001aet=&KK<\r7gI^U\u001bno\u0005GhIf.\u0001!";
      o[72] = "Z0{ZO\u0000\n%\"X6SR4%Ua\u0004\ri~9NFL0|Y\u0006\u0003L)";
      o[73] = "3D\u0003HA -G\u0017H$60\u0015\u001f_shkEF3K!)\u001b\u0015WCi1\u001c";
      o[74] = "X-\u0010\u00140e\ti^\u000fKdX.L\u0017'V\u000bj\u0013AKn\\*\u0012\u0016v<Tk\u0016p";
      o[75] = "Qy\u000eg\u000b9Am\u00024t*Y{\fh#}\t.T\u0004\u0019-Vl\u0016\u007f\u0006~Ry";
      o[76] = "|\u0015\u000e!\u0010\"y\b\b/l<t\u001a\u0010\u0011\u0001/U\u0013\u0012%\u0001\u0019m\b\u00139\nS!\u0011T%\u0013+j\u001a\b2li!\u0004\u00057\u0015c`\u0006\u0010^Vb`\u001e\u0006'\\#b\u000bo";
      o[77] = "\u000bE~H5sOLwEKx0\b.[2}M\u0004?\u0002\"\u001a\f\u000e=\u0005!y_O \bK";
      o[78] = "lIJo3%yYJ7\n1\u0017OJns;jC[7c\\(\u0002E07;wVWo\n";
      o[79] = "E~JO]&B'DX!r?~\u0012Q\u001c%X!FCC\u0018";
      o[80] = "#y>9sngpkw\u0014>\u001fu:*m7by+s}P 85t)7\u007fl'+\u0014";
      o[81] = "\u0005i:hUn\u000204\u007f);\u007f*2{P7\u0002&#\"@P@g=%\u00147\u001f3/z)";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(87826391836609L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(87826391836609L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(87826391836609L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 223;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 246;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 234;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 70;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 83;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 226;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 223;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 246;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 234;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eU_C0257",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
