package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.api.util.NamedItemStack;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class ItemESP extends Module {
   private FloatSetting a;
   private IntSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private ColorSetting f;
   private Frustum g;
   private Map h;
   private static final long k = 27926243495826L;
   private static final String l;
   private static final Object[] m = new Object[106];
   private static final String[] n = new String[106];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public ItemESP() {
      super();
      long var10001 = 80078960703618L ^ 120297065495490L;

      this.h = new LinkedHashMap();
      ColorSetting var10000 = this.f;
      Object[] var6 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var5 = var10000;
      var5.aReturningColorSetting(var6);
   }

   
   @EventListener
   public void a(TickEvent var1) {
      int var4 = Event.bReturningInt();
      int var75 = var4;
      MinecraftClient var74 = b;
      MinecraftClient var58 = var74;
      MinecraftClient var57 = var74;
      if (var75 == 0) {
         MinecraftClient var13 = var57;
         ClientWorld var76 = var13.world;
         if (var76 == null) {
            return;
         }

         MinecraftClient var77 = b;
         var58 = var77;
      }

      MinecraftClient var16 = var58;
      int var79 = var4;
      ClientPlayerEntity var78 = var16.player;
      Object var60 = var78;
      ClientPlayerEntity var59 = var78;
      if (var79 == 0) {
         ClientPlayerEntity var80 = var59;
         if (var80 == null) {
            return;
         }

         FloatSetting var18 = this.d;
         var60 = var18.aReturningObject();
      }

      Float var19 = (Float)var60;
      float var10000 = var19;
      FloatSetting var20 = this.d;
      Float var21 = (Float)var20.aReturningObject();
      float var5 = var10000 * var21;
      ArrayList var6 = new ArrayList();
      MinecraftClient var22 = b;
      ClientWorld var23 = var22.world;
      Iterable var24 = var23.getEntities();
      Iterator var7 = var24.iterator();

      boolean var73;
      while (true) {
         Iterator var25 = var7;
         boolean var81 = var25.hasNext();
         if (var81) {
            Iterator var26 = var7;
            Entity var8 = (Entity)var26.next();
            int var83 = var4;
            Entity var82 = var8;
            Entity var64 = var82;
            Entity var61 = var82;
            if (var83 == 0) {
               boolean var105 = var61 instanceof ItemEntity;
               int var85 = var4;
               boolean var84 = var105;
               var73 = var84;
               boolean var62 = var84;
               if (var85 != 0) {
                  break;
               }

               boolean var86 = var62;
               boolean var63 = var86;
               boolean var87 = var63;
               if (!var87) {
                  continue;
               }

               var64 = var8;
            }

            ItemEntity var9 = (ItemEntity)var64;
            int var89 = var4;
            ItemEntity var88 = var9;
            ItemEntity var66 = var88;
            ItemEntity var65 = var88;
            if (var89 == 0) {
               MinecraftClient var29 = b;
               ClientPlayerEntity var31 = var29.player;
               ItemEntity var30 = var65;
               double var108;
               int var90 = (var108 = var30.squaredDistanceTo((Entity)var31) - var5) == 0.0 ? 0 : (var108 < 0.0 ? -1 : 1);
               if (var90 > 0) {
                  continue;
               }

               var66 = var9;
            }

            ItemEntity var34 = var66;
            ItemStack var10 = var34.getStack();
            int var92 = var4;
            ItemStack var91 = var10;
            ItemStack var68 = var91;
            ItemStack var67 = var91;
            if (var92 == 0) {
               ItemStack var93 = var67;
               if (var93 == null) {
                  continue;
               }

               var68 = var10;
            }

            ItemStack var36 = var68;
            boolean var94 = var36.isEmpty();
            if (var94) {
               continue;
            }

            NamedItemStack var11 = new NamedItemStack();
            var11.b = var10;
            ItemStack var38 = var10;
            Text var39 = var38.getName();
            String var12 = var39.getString();
            ItemStack var40 = var10;
            int var10001 = var40.getCount();
            byte var97 = 1;
            int var96 = var10001;
            NamedItemStack var95 = var11;
            NamedItemStack var70 = var95;
            NamedItemStack var69 = var95;
            NamedItemStack var71;
            String var72;
            if (var96 > var97) {
               ItemStack var41 = var10;
               String var99 = var12 + l + var41.getCount();
               NamedItemStack var98 = var69;
               var71 = var98;
               var72 = var99;
            } else {
               var72 = var12;
               var71 = var70;
            }

            var71.a = var72;
            NamedItemStack var44 = var11;
            ItemEntity var43 = var9;
            Entry var46 = Map.entry(var43, var44);
            ArrayList var45 = var6;
            var45.add(var46);
            int var100 = var4;
            if (var100 == 0) {
               continue;
            }
         }

         Comparator var48 = invokeBinding2();
         ArrayList var47 = var6;
         var47.sort(var48);
         this.h = new LinkedHashMap();
         ArrayList var49 = var6;
         var7 = var49.iterator();
         Iterator var50 = var7;
         var73 = var50.hasNext();
         break;
      }

      while (true) {
         boolean var101 = var73;
         if (!var101) {
            break;
         }

         Iterator var51 = var7;
         Entry var103 = (Entry)var51.next();
         Map var106 = this.h;
         Entry var52 = var103;
         ItemEntity var107 = (ItemEntity)var52.getKey();
         Entry var53 = var103;
         NamedItemStack var56 = (NamedItemStack)var53.getValue();
         ItemEntity var55 = var107;
         Map var54 = var106;
         var54.put(var55, var56);
         int var102 = var4;
         if (var102 != 0) {
            break;
         }

         Iterator var104 = var7;
         var73 = var104.hasNext();
      }
   }

   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      long var10001 = 12853197019157L ^ 6136759652656L;
      var10001 = 12853197019157L ^ 4992068310760L;
      var10001 = 12853197019157L ^ 22251199579382L;
      var10001 = 12853197019157L ^ 106978769365544L;
      var10001 = 12853197019157L ^ 135327254913152L;
      var10001 = 12853197019157L ^ 40253922541930L;
      var10001 = 12853197019157L ^ 110358635952594L;
      var10001 = 12853197019157L ^ 55368866318180L;
      var10001 = 12853197019157L ^ 2790568750742L;
      int var22 = Event.cReturningInt();
      int var130 = var22;
      MinecraftClient var129 = b;
      MinecraftClient var119 = var129;
      MinecraftClient var118 = var129;
      if (var130 != 0) {
         MinecraftClient var51 = var118;
         ClientWorld var131 = var51.world;
         if (var131 == null) {
            return;
         }

         MinecraftClient var132 = b;
         var119 = var132;
      }

      MinecraftClient var54 = var119;
      ClientPlayerEntity var133 = var54.player;
      if (var133 != null) {
         Object[] var57 = new Object[]{34687714516195L};
         ItemESP var56 = this;
         boolean var134 = var56.dReturningBoolean(var57);
         if (var134) {
            float var23 = 10.0F;
            IntSetting var59 = this.c;
            Integer var60 = (Integer)var59.aReturningObject();
            int var24 = var60;
            BooleanSetting var61 = this.e;
            Boolean var62 = (Boolean)var61.aReturningObject();
            boolean var25 = var62;
            boolean var135 = var25;
            Color var120;
            if (var135) {
               ColorSetting var63 = this.f;
               Color var136 = (Color)var63.aReturningObject();
               var120 = var136;
            } else {
               var120 = null;
            }

            Color var26 = var120;
            MsdfFontManager var10000 = Prestige.c;
            Object[] var66 = new Object[]{51869363673471L};
            MsdfFontManager var65 = var10000;
            MsdfFont var27 = var65.aReturningcx_C0158(var66);
            Object[] var68 = new Object[]{15549079685413L};
            MsdfFont var67 = var27;
            float var28 = var67.cReturningFloat(var68);
            Map var69 = this.h;
            Set var70 = var69.entrySet();
            Iterator var30 = var70.iterator();

            while (true) {
               Iterator var71 = var30;
               boolean var137 = var71.hasNext();
               if (!var137) {
                  break;
               }

               Iterator var72 = var30;
               Entry var31 = (Entry)var72.next();
               int var139 = var24;
               int var138 = var29;
               if (var138 >= var139) {
                  break;
               }

               Entry var74 = var31;
               ItemEntity var32 = (ItemEntity)var74.getKey();
               Entry var75 = var31;
               NamedItemStack var33 = (NamedItemStack)var75.getValue();
               ItemEntity var76 = var32;
               boolean var140 = var76.isRemoved();
               if (!var140) {
                  label83: {
                     int var142 = var22;
                     Frustum var141 = this.g;
                     Frustum var122 = var141;
                     Frustum var121 = var141;
                     if (var142 != 0) {
                        Frustum var143 = var121;
                        if (var143 == null) {
                           break label83;
                        }

                        Frustum var144 = this.g;
                        var122 = var144;
                     }

                     ItemEntity var80 = var32;
                     Box var82 = var80.getBoundingBox();
                     Frustum var81 = var122;
                     boolean var145 = var81.isVisible(var82);
                     if (!var145) {
                        continue;
                     }
                  }

                  float var34;
                  Vec3d var36;
                  Object var126;
                  label98: {
                     MinecraftClient var84 = b;
                     ItemEntity var86 = var32;
                     ClientPlayerEntity var85 = var84.player;
                     var34 = var85.distanceTo((Entity)var86);
                     Object[] var87 = new Object[]{var32, 123069091094983L};
                     Vec3d var35 = GameRenderUtil.bReturningVec3d(var87);
                     ItemEntity var88 = var32;
                     double var10002 = var88.getHeight() + 0.4 * (1.0F + var34 / 12.0F);
                     double var92 = var10002;
                     Vec3d var89 = var35;
                     Object[] var96 = new Object[]{var89.add(var90, var92, var94), 123853079263381L};
                     var36 = GameRenderUtil.aReturningVec3d(var96);
                     Vec3d var97 = var36;
                     double var175;
                     int var159 = (var175 = var97.z - 0.0) == 0.0 ? 0 : (var175 < 0.0 ? -1 : 1);
                     int var147 = var22;
                     int var146 = var159;
                     int var125 = var146;
                     int var123 = var146;
                     if (var147 != 0) {
                        int var148 = var123;
                        if (var148 < 0) {
                           continue;
                        }

                        int var150 = var22;
                        Vec3d var149 = var36;
                        var126 = var149;
                        Vec3d var124 = var149;
                        if (var150 == 0) {
                           break label98;
                        }

                        Vec3d var99 = var124;
                        double var176;
                        int var151 = (var176 = var99.z - 1.0) == 0.0 ? 0 : (var176 < 0.0 ? -1 : 1);
                        var125 = var151;
                     }

                     int var152 = var125;
                     if (var152 >= 0) {
                        continue;
                     }

                     var29++;
                     FloatSetting var101 = this.a;
                     var126 = var101.aReturningObject();
                  }

                  Float var102 = (Float)var126;
                  float var37 = var102 - var34 / 500.0F;
                  int var154 = var22;
                  float var153 = var37;
                  float var128 = var153;
                  float var127 = var153;
                  if (var154 != 0) {
                     float var177;
                     int var155 = (var177 = var127 - 0.15F) == 0.0F ? 0 : (var177 < 0.0F ? -1 : 1);
                     if (var155 < 0) {
                        var37 = 0.15F;
                     }

                     Object[] var105 = new Object[]{var33.a, 117628177084989L};
                     MsdfFont var104 = var27;
                     var128 = var104.aReturningFloat(var105);
                  }

                  float var38;
                  float var42;
                  float var43;
                  Matrix4f var44;
                  label69: {
                     var38 = var128;
                     float var39 = 5.0F;
                     float var40 = 2.0F;
                     float var41 = 4.0F;
                     Vec3d var106 = var36;
                     var42 = (float)var106.x / var37;
                     Vec3d var107 = var36;
                     var43 = (float)var107.y / var37;
                     Matrix4f var160 = new Matrix4f();
                     float var111 = var37;
                     float var110 = var37;
                     float var109 = var37;
                     Matrix4f var108 = var160;
                     var44 = var108.scale(var109, var110, var111);
                     float var45 = var38 + 2.0F * var39;
                     float var46 = var23 + 2.0F * var40;
                     float var47 = var42 - var45 / 2.0F;
                     float var48 = var43 - var40;
                     int var156 = var22;
                     if (var156 != 0) {
                        boolean var157 = var25;
                        if (!var157) {
                           break label69;
                        }

                        MeshBufferManager var161 = var1.a;
                        RenderContext var171 = var1.b;
                        Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 16745277116157L};
                        var10011[8] = var41;
                        var10011[7] = 5;
                        var10011[6] = var46;
                        var10011[5] = var45;
                        var10011[4] = var48;
                        var10011[3] = var47;
                        var10011[2] = var44;
                        var10011[1] = var171;
                        var10011[0] = var161;
                        Object[] var113 = var10011;
                        BlurredRectangleRenderer.eReturningVoid(var113);
                     }

                     MeshBufferManager var162 = var1.a;
                     RenderContext var172 = var1.b;
                     Object[] var174 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
                     var174[8] = var41;
                     var174[7] = var26;
                     var174[6] = var46;
                     var174[5] = var45;
                     var174[4] = var48;
                     var174[3] = var47;
                     var174[2] = var44;
                     var174[1] = var172;
                     var174[0] = var162;
                     Object[] var115 = var174;
                     FilledRectangleRenderer.cReturningVoid(var115);
                  }

                  float var49 = var42 - var38 / 2.0F;
                  float var50 = var43 + (var23 - var28) / 2.0F;
                  String var173 = var33.a;
                  Object[] var10008 = new Object[]{null, null, null, null, Color.WHITE, 10141036836483L};
                  var10008[3] = var50;
                  var10008[2] = var49;
                  var10008[1] = var173;
                  var10008[0] = var44;
                  Object[] var117 = var10008;
                  MsdfFont var116 = var27;
                  var116.v(var117);
                  int var158 = var22;
                  if (var158 == 0) {
                     break;
                  }
               }
            }
         }
      }
   }

   @EventListener
   public void a(FrustumEvent var1) {
      Object[] var5 = new Object[0];
      FrustumEvent var4 = var1;
      this.g = var4.aReturningVoid(var5);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 27926243495826L ^ var2;
      int var4 = Event.bReturningInt();
      MinecraftClient var5 = b;
      int var14 = var4;
      Screen var13 = var5.currentScreen;
      Screen var9 = var13;
      Screen var8 = var13;
      if (var14 == 0) {
         Screen var15 = var8;
         if (var15 == null) {
            return true;
         }

         MinecraftClient var7 = b;
         Screen var16 = var7.currentScreen;
         var9 = var16;
      }

      byte var21 = ((byte)((var9 instanceof ChatScreen) ? 1 : 0));
      int var18 = var4;
      byte var17 = var21;
      byte var11 = var17;
      byte var10 = var17;
      if (var18 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var11);
      }

      byte var19 = var10;
      return var19 != 0;
   }

   private static int lambda$onTick$1(Entry var0, Entry var1) {
      MinecraftClient var4 = b;
      ClientPlayerEntity var10000 = var4.player;
      Entry var5 = var1;
      Entity var7 = (Entity)var5.getKey();
      ClientPlayerEntity var6 = var10000;
      float var14 = var6.distanceTo(var7);
      MinecraftClient var8 = b;
      ClientPlayerEntity var10001 = var8.player;
      Entry var9 = var0;
      Entity var11 = (Entity)var9.getKey();
      ClientPlayerEntity var10 = var10001;
      float var13 = var10.distanceTo(var11);
      float var12 = var14;
      return Float.compare(var12, var13);
   }

   private boolean lambda$new$0(Color var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(283794755092L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var4 = var2.doFinal("\\\u00ad>é\u0013Ü\u008bM".getBytes("ISO-8859-1"));
      String var5 = b(var4).intern();
      // l = var5;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 51;
            yield var15;
         }
         case 1 -> {
            byte var16 = 12;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 4;
            yield var18;
         }
         case 4 -> {
            byte var19 = 56;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 16;
            yield var21;
         }
         case 7 -> {
            byte var22 = 60;
            yield var22;
         }
         case 8 -> {
            byte var23 = 49;
            yield var23;
         }
         case 9 -> {
            byte var24 = 26;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 14;
            yield var27;
         }
         case 13 -> {
            byte var28 = 17;
            yield var28;
         }
         case 14 -> {
            byte var29 = 61;
            yield var29;
         }
         case 15 -> {
            byte var30 = 22;
            yield var30;
         }
         case 16 -> {
            byte var31 = 13;
            yield var31;
         }
         case 17 -> {
            byte var32 = 20;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 57;
            yield var34;
         }
         case 20 -> {
            byte var35 = 21;
            yield var35;
         }
         case 21 -> {
            byte var36 = 3;
            yield var36;
         }
         case 22 -> {
            byte var37 = 28;
            yield var37;
         }
         case 23 -> {
            byte var38 = 50;
            yield var38;
         }
         case 24 -> {
            byte var39 = 1;
            yield var39;
         }
         case 25 -> {
            byte var40 = 44;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 59;
            yield var42;
         }
         case 28 -> {
            byte var43 = 6;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 39;
            yield var45;
         }
         case 31 -> {
            byte var46 = 5;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 38;
            yield var48;
         }
         case 34 -> {
            byte var49 = 35;
            yield var49;
         }
         case 35 -> {
            byte var50 = 55;
            yield var50;
         }
         case 36 -> {
            byte var51 = 54;
            yield var51;
         }
         case 37 -> {
            byte var52 = 19;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 42;
            yield var54;
         }
         case 40 -> {
            byte var55 = 53;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 33;
            yield var58;
         }
         case 44 -> {
            byte var59 = 62;
            yield var59;
         }
         case 45 -> {
            byte var60 = 58;
            yield var60;
         }
         case 46 -> {
            byte var61 = 15;
            yield var61;
         }
         case 47 -> {
            byte var62 = 10;
            yield var62;
         }
         case 48 -> {
            byte var63 = 63;
            yield var63;
         }
         case 49 -> {
            byte var64 = 37;
            yield var64;
         }
         case 50 -> {
            byte var65 = 9;
            yield var65;
         }
         case 51 -> {
            byte var66 = 7;
            yield var66;
         }
         case 52 -> {
            byte var67 = 34;
            yield var67;
         }
         case 53 -> {
            byte var68 = 32;
            yield var68;
         }
         case 54 -> {
            byte var69 = 29;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 47;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 31;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 30;
            yield var77;
         }
         default -> 40;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "@a\"~.IVa'$=^A*$\"1JPm35zXa";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "][a>R^VTpq5FRHv=\u0010W";
      m[3] = "5m6\u0007\u0011^+e,Hv_:~!\u0012PY";
      m[4] = "k_t{\u0013}uWn4piq\u001aGtIzx";
      m[5] = "IC\u0018|\u0001iBL\t3`gIG\ri";
      m[6] = "vZBC\u0010\\vZU\u001f\u001cSl\u0011U\u0001\u001cFk`\u0007ZD\f";
      m[7] = boolean.class;
      n[7] = "java/lang/Boolean";
      m[8] = ":fTOo%$nN\u0000\r9#s";
      m[9] = "I\u0003TGg=W\u000bN\b\n'N\u0012CT(<L\u0010";
      m[10] = void.class;
      n[10] = "java/lang/Void";
      m[11] = "E+JN;NE+]\u00127A_`]\f7TX\u0011\rQf";
      m[12] = "Cn`G[\u0000Cnw\u001bW\u000fY%w\u0005W\u001a^T\"Z\u000e";
      m[13] = "g>ra\u001fsg>e=\u0013|}ue#\u0013iz\u00047zF(";
      m[14] = ".HSaH(.HD=D'4\u0003D#D23r\u0016}\u001cv";
      m[15] = double.class;
      n[15] = "java/lang/Double";
      m[16] = "XAG8*(NABb9?Y\nAd5+HMVs~<z";
      m[17] = "V\u0004\u0015v \u001aV\u0004\u0002*,\u0015LO\u00024,\u0000K>Vl{";
      m[18] = "\u0007$\u000f1\u0003j\f+\u001e~kj\u0002$\r";
      m[19] = float.class;
      n[19] = "java/lang/Float";
      m[20] = "PT~\tiNPTiUeAJ\u001fiKeTMn8\u00122\u0016";
      m[21] = "2ry\u00022\u00039}hMO\u001b*za\u0004";
      m[22] = "\u0019\u001e!,Y_\u000f\u001e$vJH\u0018U'pF\\\t\u00120g\rJ+";
      m[23] = "'k\u001fhY`,d\u000e':m9i\u0001L\u000fo(z\u001d`\u0018b";
      m[24] = "nc+\u0001//pk1NL;t";
      m[25] = "*\u0007{\u001c#\n!\bjSO\t/\nh\u001cc";
      m[26] = "lD\u0019nV zD\u001c4E7m\u000f\u001f2I#|H\b%\u00024A";
      m[27] = "<?A\u0010@OI\u001fJ\u001fQ\u0000(\u0011A\u0014UZ\\";
      m[28] = "o\b3c\f\u0002y\b69\u001f\u0015nC5?\u0013\u0001\u007f\u0004\"(X\u0010L";
      m[29] = "slEF|~\u0006LNIm1gBEBik\u0013";
      m[30] = "aB,u\u007f`aB;)so{\t;7sz|xlm\"=";
      m[31] = "3Fr\bl?.S**-26U";
      m[32] = ";?/pA\u001f-?**R\b:t),^\u001c+3>;\u0015\f33<0OA\u000f(<-O\u00068?";
      m[33] = "m<_] \u0018{<Z\u00073\u000flwY\u0001?\u001b}0N\u0016t\u000bs";
      m[34] = "eI\u0011\u000f!heI\u0006S-g\u007f\u0002\u0006M-rxsW\u0015\u007f";
      m[35] = ":\b9m|-1\u0007(\"\u001b/$\f(i ";
      m[36] = "`UyZ0\u0002bK09;\u0019}Nf@<";
      m[37] = "P _$N\u0004P HxB\u000bJkHfB\u001eM\u001a\u00199\u001b";
      m[38] = "<18kW~I\u00113dF1(\u001f8oBk\\";
      m[39] = "\u0011\u0005pjpm\u0007\u0005u0cz\u0010Nv6on\u0001\ta!$~\r";
      m[40] = "-qxJK\u000bXQsEZD9_xN^\u001eM";
      m[41] = "75a~\u0005P)={1x@)";
      m[42] = "\u000b\u001dp\u0019-}~={\u0016<2\u001f3p\u001d8hk";
      m[43] = "\u0011}J@5\u0003\u0007}O\u001a&\u0014\u00106L\u001c*\u0000\u0001q[\u000ba\u0017\u0002";
      m[44] = "\u001fg\u001am'\u0004jG\u0011b6K\u000bI\u001ai2\u0011\u007f";
      m[45] = "o}V\\_2\u001a]]SN}{SVXJ'\u000f";
      m[46] = "\u0013\u0001;\rM+f!0\u0002\\d\u0007/;\tX>s";
      m[47] = "K,l=GO],igTXJgjaXL[ }v\u0013[I";
      m[48] = "`@<R\u001dD\u0015`7]\f\u000btn<V\bQ\u0000";
      m[49] = "\foB\u0016o}\u001aoGL|j\r$DJp~\u001ccS];nQ";
      m[50] = "oT\u0013\u0015\u0011`\u001at\u0018\u001a\u0000/{z\u0013\u0011\u0004u\u000f";
      m[51] = "mn\\v\t,\u0018NWy\u0018cy@\\r\u001c9\r";
      m[52] = ")\u0013\nb\fY)\u0013\u001d>\u0000V3X\u001d \u0000C4)J\u007fV";
      m[53] = "\u0005K$HuE\u0000GyV\u0011FRK\u0007T`)\u0004K!@a\u0017DI)D\u0011";
      m[54] = "4;\u0007\u0017&=54\u001b\u001dE.Q5\u0001\u0001|(?4F\u001f|";
      m[55] = "PolO$\u0010Qpx\u0019X\u00122ma\u0018$\nX&c\u001c:{Vv:\rcBHp`\u000fX";
      m[56] = "-I%\u0014\u0001Hr\tx\u001be\u0018s^&I2O-\u000e\u007f%\\N/X<]\u0019\nmA>";
      m[57] = "s6s=MO-8h/&Q\"ua:Jcp8?e&\tp5\u007f>VW0q|]";
      m[58] = "y&=mo7)6cq\u0011<##x\u0001/=<;ym}|+$\u0004>s,!'99o?%Y";
      m[59] = "aBCN\u001bm1R\u001dRe| P\u0000K\u0019z&=@N\u001e,mL\u001fMTw\\";
      m[60] = "\u000fk0\u001d-\u0013Uf \u0007W\u0013Sq,\n;!\u0003=q]W\u001f\u00051s\u00113HOnrm>\u0014[q/\rh\u0010\u0006}L";
      m[61] = "A\tJ||WW\n\u001cwMV@\u0019$s)JKe\u000bpvK]\u000e\u000byq7";
      m[62] = "\u0006RA?\u00108YQ\u000bd!/QNF\u000e\u001a5YGJ0Z7QC:";
      m[63] = "\u0017YO\u0017\\R\u0017\n\u0015U2Z\u0017\u001fwSHT\u001c\f,BOH\u0004\u0002B\u0016_Q\u0016c";
      m[64] = "v\bx&\u001e\u0019i].>e\f\u0018\fw#\u001b\u0018z\u0001*/Uew]5!\u0018\u0007z\u00009oe";
      m[65] = "8x\n\nmk+,\u0002\bPk3$\u000b\u0006*mT-\u0019S6c, J\u00151\u00008+O\t3x5x\t\u000ePq>z\u000f\u0014;q7}s";
      m[66] = "=Zzx>\t#\\ z\u0005U4O#digc\b{2>0!M\"jk[iS$;\u0005\rf\u000f=`uS&K>\u0003";
      m[67] = "2\u001f,{/I\"\u0018zlFYH\u0003\u007fi:A\"H}m$0$\u001b!a%H)HgfF";
      m[68] = "$?(E#k!<)R^h-29Z^>7+:[`~5#>+ey.73\u0015%{&3C\u0011\"e:*/\u0014.8$N";
      m[69] = "'\tfu\u0000J&\u000bzj>O \u0002xai\u0018zR&\rWC$\u0013\u007fm\u0001Gy\u001f";
      m[70] = "O*COFXN(_Px]H!][/\n\u0012q\u00007\u0011QL0ZWGU\u0011<";
      m[71] = "wBE_v,-OUE\f,+XYH`\u001e\u007f\u001b\u0007\u001f6I*N\u0005Io1'\u001dCN\f";
      m[72] = "#S7oOh5\u0001%t+j#\u0006.~Wl%kn{P:n\u001a1x\u001aa_";
      m[73] = "\u00120/)c&Mpr&\u0007vL',tP!\u0013zw\u00187vD21wh\u007f@#";
      m[74] = ";VgLn\u0006#\u0000.\u0007\u0012ZJ\u001e}PnF U\u007fTp7u\u000et[l\nr\u0012g_\u0012";
      m[75] = "\u000b\u001e\u000bU|\f\u001b\u0019]B\u0015\u001eq\u0002XGi\u0004\u001bIZCwu\u001d\u001a\u0006Ov\r\u0010I@H\u0015";
      m[76] = "T@~}4M\u000eMngNM\bZbj\"\u007f^\u001f>=w(X\u0019>s-X\u0006YzpN";
      m[77] = "&8vRA|p\u007f ?[\u001el,vCJul%q?";
      m[78] = "\u0006x\u001czN\u0017\u001fq\u0012;/u\"@\"\u000f/N\u001bcF#\u0012W\u0012m\u0007";
      m[79] = "7g\u0000!a\u000f:rHt\u0010T0e^'yX\tk^7}>j=\u00064sN4}B7\u0010";
      m[80] = "b\u0000\rR\b\u00064G[?\u0013d(\u0014\rC\u0003\u000f(\u001d\n?";
      m[81] = "cut4~Gc`'%\fT\t\"d+uM7bf#q=";
      m[82] = "_\u0011\fZdlX\u0014SA\u00182YQ\\Bt\u0000\t\u0012\u0007\u0014\u0018>\u000f\u0011\u0003Y|iEN\u0002%t=\bK_]ynNL<";
      m[83] = "\u007fQ\u0011\u001fO*~S\r\u0000q/xZ\u000f\u000b&x\"\nSg\u0018#|K\b\u0007N'!G";
      m[84] = "Y\u0011{B|\u000f^^i\u0007\u001fHJIc\u0016\u001f_K\u001ca\u0018gR\u0018Zf{sY\u001dFd\u0003~\n[A\u0007\u0017u\u000fGC\u007f\u001a&I@ \u007fJc\nB\u001cx\u0005qO!";
      m[85] = "n:+\u0015|\u00071zv\u001a\u0018W0-(HO\u0000nzp$s\u0005a?0\u001ft\u0000>$";
      m[86] = "PF\u00130np\nK\u0003*\u0014p\f\\\u000f'xB\\\u0010Uq\u0014m\u001fA\u0006.\u007f%\u0001GW@";
      m[87] = "^\u0018=\u0004\u0007SAMk\u001c|C0\u0001n\u0013\u0000^ZJl\u0017\u001e/\rL0\u0003\u001f_S\ft\u0000|";
      m[88] = "Yh$TG\u001a\u0006kn\u000fv\u000b\n\u007f\u0019\b\u0006\u0017c9`Y\b\b\u0013g \u001d\u000bk";
      m[89] = ".]\u007f$Mu+^~30v'Pn;kv=,hrSc%O~ AxA";
      m[90] = "\u0014\u000ewh\f*F\t{%4(Q\u001c1>H.Wqq;Ox\u001c\u0000.8\u0005#-";
      m[91] = "DR\u001eZK|E\u0015\u0000Z&{!^\u0012\rZcK\u0015\u0010\tD\u0012[BA\u001fOkKE\u0017\b&";
      m[92] = "7}T\u0001u`+3\bZ\u0005dK\u007f\u0006\u0004y|!4\u0004\u0000g\r-k\u001e\u0012;f,i\u0002\r\u0005";
      m[93] = "u`*\u000ez{i.vU\n|\tbx\u000bvgc)z\u000fh\u0016ov`\u001d4}nt|\u0002\n";
      m[94] = "b/e1reldhp\t<\u0003d7eu$i/5akUb/e1reldhp\t";
      m[95] = "sX]b6m#H\u0003~Ht\"Kd54x7WZu6p3'Y1tc-W\u0007q0`N";
      m[96] = "\f7:\u00110v\u001c0l\u0006Yqv+i\u0003%~\u001c`k\u0007;\u000fI;`\b'2N's\fY";
      m[97] = "BE\u001b\u001eS'Q\u0011\u0013\u001cn\"J\u001b\u000b\u00070%J\u0001\u000f{\u0002&\u0012\u001a\u0001\u0003\u000fuT\u001db";
      m[98] = "\u0016CM\u001e\\\u001aHMV\f7\u0004G\u0000_\u0019[6\u0015M\u0001B7\f\u0010\u001f\u0007\u0010P\fCEE~";
      m[99] = ".i\u007f~;H+e\"`_KyiAf;Yy\u0015$s:]d+dq2Y\u0014";
      m[100] = ">\u0012\u007fav:d\u001fo{\f:b\bcv`\b1E3*\fc0\u0006czw=>\u001dq\u0011";
      m[101] = "}R\u0001R6%;A\b[X\u007f\u0002Z\u0007\u0004$eh\u0011\u0005\u0000:\u0014=J\u000e\u000f&):V\u001d\u000bX";
      m[102] = "y\u0019\blH6'\u0017\u0013~#((Z\u001akO\u001az\u0017F3#</\u001d\u0006wH<&\u001az";
      m[103] = "2:i\u0012SM38u\rmC9 s\r\u0001qmd(SmO69o\t\r\u00192dcj\u0004D1 p\nR@l,\u0013\u0003\u000fC(?sU\u000b\u001e$\\u\f\u0017^j7t\u000e\u000bAT";
      m[104] = ";D6{B@>G7l?V)I].CK-EcnAC)5fiZW$\u000b&kRST\u000e!pF^jN#xB.";
      m[105] = "sY;\t4\f,P?\u0018M\u0006.K2\u0016!4z\u0007kHwczHnNu\u0000(Ob\u0003M";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(388274672080902L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(388274672080902L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(388274672080902L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 236;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 228;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 244;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 186;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 251;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 206;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 236;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 228;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 244;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eV_C0259",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eV" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(ItemESP var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eV_C0259;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eV_C0259", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((ItemESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Comparator invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "compare",
                  SourceSupport.methodType("()Ljava/util/Comparator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eV_C0259", "lambda$onTick$1", "(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I"
                  ),
                  SourceSupport.methodType("(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Comparator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
