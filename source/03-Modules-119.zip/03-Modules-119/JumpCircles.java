package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.client.modules.state.PositionEffect;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.TrackedPosition;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class JumpCircles extends Module {
   private BooleanSetting d;
   private FloatSetting a;
   private IntSetting c;
   private FloatSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private ColorSetting h;
   private Map i;
   private Map j;
   private List k;
   private static final long l = 18588161604063L;
   private static final long m;
   private static final long[] n;
   private static final Long[] o;
   private static final Map p;
   private static final Object[] q = new Object[92];
   private static final String[] r = new String[92];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public JumpCircles() {
      super();
      long var10001 = 66597755771955L ^ 27685330476915L;

      this.i = new HashMap();
      this.j = new HashMap();
      this.k = new ArrayList();
      ColorSetting var10000 = this.h;
      Object[] var6 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var5 = var10000;
      var5.aReturningColorSetting(var6);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 52213760024386L ^ 127858201761580L;
      var10001 = 52213760024386L ^ 21692798027454L;
      int var8 = Event.bReturningInt();
      MinecraftClient var22 = b;
      ClientWorld var100 = var22.world;
      if (var100 != null) {
         HashSet var9 = new HashSet();
         MinecraftClient var24 = b;
         ClientWorld var25 = var24.world;
         List var26 = var25.getPlayers();
         Iterator var10 = var26.iterator();

         while (true) {
            Iterator var27 = var10;
            boolean var101 = var27.hasNext();
            if (var101) {
               Iterator var28 = var10;
               PlayerEntity var11 = (PlayerEntity)var28.next();
               PlayerEntity var29 = var11;
               int var12 = var29.getId();
               int var30 = var12;
               Integer var32 = var30;
               HashSet var31 = var9;
               var31.add(var32);
               Map var10000 = this.i;
               int var33 = var12;
               Integer var134 = var33;
               Boolean var37 = false;
               Integer var36 = var134;
               Map var35 = var10000;
               Boolean var38 = ((java.lang.Boolean)(Object)(var35.getOrDefault(var36, var37)));
               byte var13 = ((byte)(((java.lang.Boolean)(var38)).booleanValue() ? 1 : 0));
               PlayerEntity var39 = var11;
               byte var14 = ((byte)((var39.isOnGround()) ? 1 : 0));
               Object[] var41 = new Object[]{var11, 100286281336942L};
               JumpCircles var40 = this;
               Vec3d var15 = var40.aReturningVec3d(var41);
               Vec3d var42 = var15;
               double var16 = var42.y;
               var10000 = this.j;
               int var43 = var12;
               Integer var135 = var43;
               double var44 = var16;
               Double var48 = var44;
               Integer var47 = var135;
               Map var46 = var10000;
               Double var49 = ((java.lang.Double)(Object)(var46.getOrDefault(var47, var48)));
               double var18 = var49;
               double var20 = var16 - var18;
               BooleanSetting var50 = this.d;
               Boolean var51 = (Boolean)var50.aReturningObject();
               byte var127 = ((byte)(((java.lang.Boolean)(var51)).booleanValue() ? 1 : 0));
               int var103 = var8;
               byte var102 = var127;
               byte var86 = var102;
               if (var103 != 0) {
                  break;
               }

               label64: {
                  label74: {
                     int var105 = var8;
                     byte var104 = var86;
                     byte var91 = var104;
                     byte var87 = var104;
                     if (var105 == 0) {
                        byte var106 = var87;
                        byte var88 = var106;
                        byte var107 = var88;
                        if (var107 != 0) {
                           int var109 = var8;
                           PlayerEntity var108 = var11;
                           PlayerEntity var89 = var108;
                           if (var109 != 0) {
                              break label64;
                           }

                           PlayerEntity var110 = var89;
                           PlayerEntity var90 = var110;
                           MinecraftClient var55 = b;
                           ClientPlayerEntity var112 = var55.player;
                           PlayerEntity var111 = var90;
                           if (var111 != var112) {
                              break label74;
                           }
                        }

                        byte var113 = var13;
                        var91 = var113;
                     }

                     int var115 = var8;
                     byte var114 = var91;
                     byte var93 = var114;
                     byte var92 = var114;
                     if (var115 == 0) {
                        byte var116 = var92;
                        if (var116 == 0) {
                           break label74;
                        }

                        var93 = var14;
                     }

                     int var118 = var8;
                     byte var117 = var93;
                     int var95 = var117;
                     byte var94 = var117;
                     if (var118 == 0) {
                        byte var119 = var94;
                        if (var119 != 0) {
                           break label74;
                        }

                        double var138;
                        int var120 = (var138 = var20 - 0.05) == 0.0 ? 0 : (var138 < 0.0 ? -1 : 1);
                        var95 = var120;
                     }

                     int var122 = var8;
                     int var121 = var95;
                     int var96 = var121;
                     if (var122 == 0) {
                        int var123 = var96;
                        if (var123 > 0) {
                           List var128 = this.k;
                           Vec3d var62 = var15;
                           Vec3d var63 = var15;
                           Vec3d var10003 = new Vec3d(var62.x, var18, var63.z);
                           IntSetting var64 = this.c;
                           Integer var65 = (Integer)var64.aReturningObject();
                           PositionEffect var67 = new PositionEffect(var10003, var65, 66822327704060L);
                           List var66 = var128;
                           boolean var124 = var66.add(var67);
                        }
                     }
                  }

                  var10000 = this.i;
                  int var69 = var12;
                  Integer var136 = var69;
                  byte var70 = var14;
                  Boolean var73 = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var70));
                  Integer var72 = var136;
                  Map var71 = var10000;
                  var71.put(var72, var73);
                  var10000 = this.j;
                  int var74 = var12;
                  Integer var137 = var74;
                  double var75 = var16;
                  Double var79 = var75;
                  Integer var78 = var137;
                  Map var77 = var10000;
                  Object var98 = var77.put(var78, var79);
               }

               int var125 = var8;
               if (var125 == 0) {
                  continue;
               }
            }

            Map var80 = this.i;
            Set var131 = var80.keySet();
            HashSet var82 = var9;
            Set var81 = var131;
            var81.retainAll(var82);
            Map var83 = this.j;
            var131 = var83.keySet();
            HashSet var85 = var9;
            Set var84 = var131;
            boolean var99 = var84.retainAll(var85);
            break;
         }
      }
   }

   
   
   private Vec3d aReturningVec3d(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 18588161604063L ^ var2;
      int var5 = Event.bReturningInt();
      int var29 = var5;
      PlayerEntity var28 = var4;
      PlayerEntity var25 = var28;
      PlayerEntity var24 = var28;
      if (var29 == 0) {
         MinecraftClient var7 = b;
         ClientPlayerEntity var31 = var7.player;
         PlayerEntity var30 = var24;
         if (var30 == var31) {
            PlayerEntity var9 = var4;
            double var43 = var9.getX();
            PlayerEntity var10 = var4;
            double var47 = var10.getY();
            PlayerEntity var11 = var4;
            return new Vec3d(var43, var47, var11.getZ());
         }

         try {
            var25 = var4;
         } catch (Throwable var33) {
            PlayerEntity var21 = var4;
            double var10002 = var21.getX();
            PlayerEntity var22 = var4;
            double var10003 = var22.getY();
            PlayerEntity var23 = var4;
            return new Vec3d(var10002, var10003, var23.getZ());
         }
      }

      try {
         PlayerEntity var13 = var25;
         TrackedPosition var10000 = var13.getTrackedPosition();
         short var10001 = 4523;
         long var40 = 4562829239515973481L ^ var2;
         short var41 = 24997;
         long var45 = 3514248027038021478L ^ var2;
         var40 = 0L;
         short var46 = 24997;
         long var10004 = 3514248027038021478L ^ var2;
         TrackedPosition var14 = var10000;
         return var14.withDelta(0L, 0L, 0L);
      } catch (Throwable var32) {
         PlayerEntity var35 = var4;
         double var39 = var35.getX();
         PlayerEntity var36 = var4;
         double var44 = var36.getY();
         PlayerEntity var37 = var4;
         return new Vec3d(var39, var44, var37.getZ());
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      int var10;
      long var11;
      Color var64;
      label66: {
         Object var63;
         label69: {
            long var10001 = 133542657003685L ^ 65348594766476L;
            var10001 = 133542657003685L ^ 135331543970455L;
            var10001 = 133542657003685L ^ 79624656535290L;
            int var10000 = Event.cReturningInt();
            var11 = System.currentTimeMillis();
            var10 = var10000;
            List var101 = this.k;
            Predicate var26 = invokeBinding2(var11);
            List var25 = var101;
            var25.removeIf(var26);
            List var27 = this.k;
            boolean var102 = var27.isEmpty();
            int var76 = var10;
            boolean var75 = var102;
            boolean var62 = var75;
            boolean var60 = var75;
            if (var76 != 0) {
               boolean var77 = var60;
               if (var77) {
                  return;
               }

               BooleanSetting var29 = this.g;
               Boolean var103 = (Boolean)var29.aReturningObject();
               int var79 = var10;
               Boolean var78 = var103;
               var63 = var78;
               Boolean var61 = var78;
               if (var79 == 0) {
                  break label69;
               }

               Boolean var30 = var61;
               boolean var80 = var30;
               var62 = var80;
            }

            boolean var81 = var62;
            if (var81) {
               Object[] var32 = new Object[]{2617886958130L};
               Color var82 = ClientUiUtil.dReturningColor(var32);
               var64 = var82;
               break label66;
            }

            ColorSetting var34 = this.h;
            var63 = var34.aReturningObject();
         }

         var64 = (Color)var63;
      }

      Color var13 = var64;
      Color var35 = var13;
      Color var14 = var35.brighter();
      FloatSetting var36 = this.e;
      Float var37 = (Float)var36.aReturningObject();
      float var15 = var37;
      FloatSetting var38 = this.f;
      Float var39 = (Float)var38.aReturningObject();
      float var16 = var39;
      FloatSetting var40 = this.a;
      Float var41 = (Float)var40.aReturningObject();
      float var17 = var41;
      List var42 = this.k;
      Iterator var18 = var42.iterator();

      while (true) {
         Iterator var43 = var18;
         boolean var83 = var43.hasNext();
         if (!var83) {
            break;
         }

         PositionEffect var19;
         float var20;
         float var69;
         float var70;
         label72: {
            Iterator var44 = var18;
            var19 = (PositionEffect)var44.next();
            var20 = (float)(var11 - var19.b) / var19.c;
            float var112;
            int var104 = (var112 = var20 - 0.0F) == 0.0F ? 0 : (var112 < 0.0F ? -1 : 1);
            int var85 = var10;
            int var84 = var104;
            int var68 = var84;
            int var65 = var84;
            if (var85 != 0) {
               int var86 = var65;
               if (var86 < 0) {
                  continue;
               }

               int var89 = var10;
               float var88 = 1.0F;
               float var87 = var20;
               var69 = var87;
               var70 = var88;
               float var66 = var87;
               float var67 = var88;
               if (var89 == 0) {
                  break label72;
               }

               float var113;
               int var90 = (var113 = var66 - var67) == 0.0F ? 0 : (var113 < 0.0F ? -1 : 1);
               var68 = var90;
            }

            int var91 = var68;
            if (var91 > 0) {
               continue;
            }

            float var108 = var17 - 0.1F;
            Object[] var47 = new Object[]{var20};
            var70 = var108 * bReturningFloat(var47);
            var69 = 0.1F;
         }

         float var21;
         float var22;
         label44: {
            var21 = var69 + var70;
            int var94 = var10;
            float var93 = 0.2F;
            float var92 = var20;
            float var73 = var92;
            float var74 = var93;
            float var71 = var92;
            float var72 = var93;
            if (var94 != 0) {
               float var114;
               int var95 = (var114 = var71 - var72) == 0.0F ? 0 : (var114 < 0.0F ? -1 : 1);
               if (var95 < 0) {
                  var22 = var20 / 0.2F;
                  int var96 = var10;
                  if (var96 != 0) {
                     break label44;
                  }
               }

               float var98 = (var20 - 0.2F) / 0.8F;
               float var97 = 1.0F;
               var73 = var97;
               var74 = var98;
            }

            var22 = var73 - var74;
         }

         float var51 = var22;
         float var50 = 1.0F;
         float var53 = Math.min(var50, var51);
         float var52 = 0.0F;
         var22 = Math.max(var52, var53);
         Object[] var10004 = new Object[]{null, null, 54012938038879L};
         var10004[1] = var22;
         var10004[0] = var14;
         Object[] var54 = var10004;
         Color var23 = aReturningColor(var54);
         var10004 = new Object[]{null, null, 54012938038879L};
         var10004[1] = var22;
         var10004[0] = var13;
         Object[] var55 = var10004;
         Color var24 = aReturningColor(var55);
         RenderContext var105 = var1.b;
         MeshBufferManager var109 = var1.a;
         Vec3d var56 = var19.a;
         float var10002 = (float)var56.x;
         Vec3d var57 = var19.a;
         float var10003 = (float)var57.y;
         Vec3d var58 = var19.a;
         float var111 = (float)var58.z;
         Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, var23, var24, 72687848587817L};
         var10012[7] = var16;
         var10012[6] = var15;
         var10012[5] = var21;
         var10012[4] = var111;
         var10012[3] = var10003;
         var10012[2] = var10002;
         var10012[1] = var109;
         var10012[0] = var105;
         Object[] var59 = var10012;
         ShapeRenderer.fReturningVoid(var59);
         int var99 = var10;
         if (var99 == 0) {
            break;
         }
      }
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      List var4 = this.k;
      var4.clear();
      Map var5 = this.i;
      var5.clear();
      Map var6 = this.j;
      var6.clear();
   }

   private static float bReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      return 1.0F - (1.0F - var1) * (1.0F - var1);
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      long var10000 = 18588161604063L ^ var2;
      byte var14 = 0;
      int var10001 = (int)m;
      Color var6 = var1;
      int var8 = (int)(var6.getAlpha() * var4);
      int var7 = var10001;
      int var10 = Math.min(var7, var8);
      int var5 = Math.max(0, var10);
      Color var11 = var1;
      int var10002 = var11.getRed();
      Color var12 = var1;
      int var10003 = var12.getGreen();
      Color var13 = var1;
      return new Color(var10002, var10003, var13.getBlue(), var5);
   }

   private static boolean lambda$onRenderWorld$1(long var0, PositionEffect var2) {
      int var5 = Event.cReturningInt();
      long var13;
      int var10000 = (var13 = var0 - var2.b - var2.c) == 0L ? 0 : (var13 < 0L ? -1 : 1);
      int var10 = var5;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      if (var10 != 0) {
         int var11 = var6;
         if (var11 < 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$0(Color var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.g;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(80309093885432L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 7953975986856177131L;
      byte[] var17 = var13.doFinal(
         new byte[]{
            (byte)110L,
            (byte)28258L,
            (byte)7234099L,
            (byte)1851929348L,
            (byte)474093913248L,
            (byte)121368041791628L,
            (byte)31070218698656941L,
            (byte)7953975986856177131L
         }
      );
      long var22 = (var17[0] & 255L) << 56
         | (var17[1] & 255L) << 48
         | (var17[2] & 255L) << 40
         | (var17[3] & 255L) << 32
         | (var17[4] & 255L) << 24
         | (var17[5] & 255L) << 16
         | (var17[6] & 255L) << 8
         | var17[7] & 255L;
      // m = var22;
      p = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(80309093885432L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      String var4 = "\u0091ºð\u009fê\u0095ÐÄ\f÷Æy¶þ\u0014Ü";
      int var5 = "\u0091ºð\u009fê\u0095ÐÄ\f÷Æy¶þ\u0014Ü".length();
      do {
         int var20 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var20, var2).getBytes("ISO-8859-1");
         int var21 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         // var6[var21] = var10004;
      } while (var2 < var5);

      n = var6;
      o = new Long[2];
   
      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10098;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])p.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eW", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eW_C0261",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eW" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = r[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 33;
            yield var15;
         }
         case 1 -> {
            byte var16 = 38;
            yield var16;
         }
         case 2 -> {
            byte var17 = 44;
            yield var17;
         }
         case 3 -> {
            byte var18 = 47;
            yield var18;
         }
         case 4 -> {
            byte var19 = 10;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 17;
            yield var23;
         }
         case 9 -> {
            byte var24 = 62;
            yield var24;
         }
         case 10 -> {
            byte var25 = 57;
            yield var25;
         }
         case 11 -> {
            byte var26 = 40;
            yield var26;
         }
         case 12 -> {
            byte var27 = 35;
            yield var27;
         }
         case 13 -> {
            byte var28 = 58;
            yield var28;
         }
         case 14 -> {
            byte var29 = 9;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 13;
            yield var31;
         }
         case 17 -> {
            byte var32 = 7;
            yield var32;
         }
         case 18 -> {
            byte var33 = 55;
            yield var33;
         }
         case 19 -> {
            byte var34 = 42;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 32;
            yield var37;
         }
         case 23 -> {
            byte var38 = 59;
            yield var38;
         }
         case 24 -> {
            byte var39 = 22;
            yield var39;
         }
         case 25 -> {
            byte var40 = 60;
            yield var40;
         }
         case 26 -> {
            byte var41 = 26;
            yield var41;
         }
         case 27 -> {
            byte var42 = 16;
            yield var42;
         }
         case 28 -> {
            byte var43 = 19;
            yield var43;
         }
         case 29 -> {
            byte var44 = 15;
            yield var44;
         }
         case 30 -> {
            byte var45 = 6;
            yield var45;
         }
         case 31 -> {
            byte var46 = 56;
            yield var46;
         }
         case 32 -> {
            byte var47 = 5;
            yield var47;
         }
         case 33 -> {
            byte var48 = 36;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 29;
            yield var51;
         }
         case 37 -> {
            byte var52 = 4;
            yield var52;
         }
         case 38 -> {
            byte var53 = 46;
            yield var53;
         }
         case 39 -> {
            byte var54 = 50;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 28;
            yield var56;
         }
         case 42 -> {
            byte var57 = 53;
            yield var57;
         }
         case 43 -> {
            byte var58 = 25;
            yield var58;
         }
         case 44 -> {
            byte var59 = 49;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 24;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 61;
            yield var65;
         }
         case 51 -> {
            byte var66 = 11;
            yield var66;
         }
         case 52 -> {
            byte var67 = 37;
            yield var67;
         }
         case 53 -> {
            byte var68 = 45;
            yield var68;
         }
         case 54 -> {
            byte var69 = 20;
            yield var69;
         }
         case 55 -> {
            byte var70 = 52;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 12;
            yield var74;
         }
         case 60 -> {
            byte var75 = 51;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 14;
            yield var77;
         }
         default -> 30;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            r[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      q[0] = "\u0016\u0000+\u001d\u007f{\u0000\u0000.Gll\u0017K-A`x\u0006\f:V+o;";
      q[1] = "/Ca%jvZcj*{9;ma!\u007fcO";
      q[2] = "\u0018:]6Yl\u00062Gy;p\u0001/";
      q[3] = "$v>\b6+:~$G~+ t<\u0000w0`G:\f|7-v<\f";
      q[4] = boolean.class;
      r[4] = "java/lang/Boolean";
      q[5] = "\f\brc_x\f\be?Sw\u0016Ce!Sb\u001124y\u0001";
      q[6] = double.class;
      r[6] = "java/lang/Double";
      q[7] = "-3QR\tV;3T\b\u001aA,xW\u000e\u0016U=?@\u0019]G\u000b";
      q[8] = "2Yd\u0007)\u0018Gyo\b8W&wd\u0003<\rR";
      q[9] = "NO.P\u0001LSZvr@AK\\";
      q[10] = "g{$\u0015#\u0006q{!O0\u0011f0\"I<\u0005ww5^w\u0013T";
      q[11] = "\u001c_\u0002iS\u001fi\u007f\tfBP\bq\u0002mF\n|";
      q[12] = "\\\u0014\u0016T#xW\u001b\u0007\u001b@uB\u001d";
      q[13] = float.class;
      r[13] = "java/lang/Float";
      q[14] = "\u001fZN`j\u001ejzEo{Q\u000btNd\u007f\u000b\u007f";
      q[15] = "hiOm9dcf^\"C`pgNmudg";
      q[16] = "\u007f[\u0014(\u001ddtT\u0005g`qfN\u0007$";
      q[17] = long.class;
      r[17] = "java/lang/Long";
      q[18] = "\u0005U17\u0006^\u001b]+xa_\nF&\"GY";
      q[19] = "Wo~\u0016a.\\`oY\r-Rbm\u0016!";
      q[20] = "\u000eXB[7B\u0018XG\u0001$U\u000f\u0013D\u0007(A\u001eTS\u0010cS/";
      q[21] = int.class;
      r[21] = "java/lang/Integer";
      q[22] = "4\u0015B-\u0018;\"\u0015Gw\u000b,5^Dq\u00078$\u0019SfL/&";
      q[23] = "T)$l\u0006Z!\t/c\u0017\u0015@\u0007$h\u0013O4";
      q[24] = void.class;
      r[24] = "java/lang/Void";
      q[25] = "\r|\u001er[m\u001b|\u001b(Hz\f7\u0018.Dn\u001dp\u000f9\u000fy/";
      q[26] = "\u001bEZCa>\u0010JK\f\u00000\u001bAOV";
      q[27] = "nL\u0019[\u007f\u0012eC\b\u0014\u0017\u0012kL\u001b";
      q[28] = "\u0003\u0018\u0003Y?(\u001d\u0010\u0019\u0016\\<\u0019";
      q[29] = "\\%\u0011\u001c|_)\u0005\u001a\u0013m\u0010H\u000b\u0011\u0018iJ<";
      q[30] = "\u0002%M\u0002EP\u001c-WM8@\u001c";
      q[31] = "~6\u0019D>\fu9\b\u000bY\u000e`2\b@b";
      q[32] = "[\u0015\u001e\u0003Eg[\u0015\t_IhA^\tAI}F/Y\u001c\u0018";
      q[33] = "=\u001c2q.7=\u001c%-\"8'W%3\"- &qku";
      q[34] = "\u0004oM2fv\u0004oZnjy\u001e$Zpjl\u0019U\u000f/3";
      q[35] = "S\u001f\"B8TS\u001f5\u001e4[IT5\u00004NN%gZ`\n";
      q[36] = "\u001dBT:84\u0016MEuR7\u0002AN>";
      q[37] = "\u0003MZ\u00177l\u001dE@XZv\u0005@I\u0015mp\u0006B";
      q[38] = "\u0005\u001e\u0019!;\u0010\u0005\u001e\u000e}7\u001f\u001fU\u000ec7\n\u0018$Z;dK";
      q[39] = "c\u001cb+#-i\u0010g<\u001d%:\r\t#&z5\u0016v3m&+}gv'&8\u0002w={8S\u00132w{+,\u0003y+e@";
      q[40] = "gm\u0018\u001fdX<-\u0019\u001b\u0003S3vA\u0000nh0\u0013\u001c\u001f9J,+Y\u0001=S^(\u001f\u0010}KfmE\u0019})";
      q[41] = "z1 q \n 7xrI\u0004),\u000ev1\u000b-P))s\r//9b/\u0013D";
      q[42] = "OD[2N:\u0015B\u00031'1\u000bDS1[6\u000b%\u00020@8\u0018DX6\u0018;q";
      q[43] = "a)\u0019u1+0)\u0001xJ#v*\u001er,4W1\u0001r\u000f)o4\u0005dJ#;1\rz-p5l\u001d\u001f";
      q[44] = "wJ%\u0018't}F \u000f\u0019|&MNO#fy\u001b.\u000ev$)+\u007fDf'wK>\u0011$wG\u001at\u0001')'[!Cw\u0019";
      q[45] = ",][N\u0010rw\u001dZJwbiN\u001fF\u000bdo#\u000e_O~hA\u000f\u0015\u0005`\u0015";
      q[46] = "S\":\r;.@$m\tJq=.1U0dPt(V3\u001f]u7\u001aweL\"7\u0004J";
      q[47] = " i\u0007Fv\u001f6*]D\r\u0011\"obVi\r)\u0013R\u00047\u0016/lBOk\bD";
      q[48] = "\u0013\u0010iC(r\u0012Z#]Uv\u0015\u0010->4!\u0002\t*\u0002l.H\u0005Q";
      q[49] = ",\u007f?L2dvygO[j\u007fb\u0002B7\u0005|%bI0zln>W[";
      q[50] = "\u0019\u001e\u0015+\u00051F\u001eU\"5.\u0013YI.Y\u001cG\u0015\u0015t\u000bKG[\u0017(R:\u001c\u001b\u0016,5";
      q[51] = "S\\\u001c\u001a;\u0016\b\u001c\u001d\u001e\\\f\u000eOK\u0001\\\u0007RERF&\u0016\u0005EL{";
      q[52] = "nvl\u0010<\u001bk4-\u0004V\u0017dp6\u001b:%30fFfr258\u00024Jwo1\u0002V";
      q[53] = "C$mTKFI;#\\ F\u001975\tw\u0011Cgke\u001c\u0019\u0004fm^N\u0010\u001f3";
      q[54] = "\u0001h+\u001eAK\u000bwe\u0016*K[{sC}\u001c\u0001+./\u0016\u0014F*+\u0014D\u001d]\u007f";
      q[55] = "q+\u0007\f\"}wb\u0007\u000f_)O:\u0006\u000e%;\"`\u001f\r&@q8\u0000R6!+>XQ_";
      q[56] = "O6<Rd>I\u007f<Q\u0019jq-?\u0011sj\u000f+#_u\u0003\u0018'\"\u0005p}\u001e;l\u0003\u0019";
      q[57] = "g}\u0005\u0015a\f\u007fo\n\u0016PMnnRO6~gv;W`Qh}E\u0016l\tl\u0012\u0000\u0017>Ia*EM7I\u0003";
      q[58] = "`wiK3C4k+M\rDdb\u007f\u0018Z\u0013;?$tj\u00119m+\u000e5\u0011yd";
      q[59] = "r7\u0006\u00067#(1^\u0005^-!*.\u001f3/*V\u000f^d$')\u001f\u00158:L";
      q[60] = "7:KM\u0000\u001a2x\nYj\u0016=<\u0011F\u0006$m~K\u0011j\u001dkz\u0017J\u0015\r &\t!";
      q[61] = "\fr1\u0018\u0003>\n;1\u001b~j2c0\u001a\u0004x_9)\u0019\u0007\u0003\t~m\u0014\u0015m\u0003a#\u001c~";
      q[62] = "oj\u001d:=\f~gHuQ\u0001\u0003{C\u007f7\u0000|k\b#)k";
      q[63] = "\u0010AXpq\u0000\u0004WLx\u0010\u000f\u0015XKvW\u001f|\u0007\u000fun\u0013DBU|nq\u0010AXpq\u0000\u0004WLx\u0010";
      q[64] = ")\u0002\u0003\r*M,@B\u0019@A#\u0004Y\u0006,stC\u0002[y$rIE]|\u001f @^\b@";
      q[65] = "pqt^-\u0019dg`VL\u0002{k~X%\u000eBe~H!h'5tK.Pbo}KL";
      q[66] = "x!u\u0002%Ei, MII\u00140+G/Ik `\u001b1\"";
      q[67] = "Q3\u000bJvfI!\u0004IG4Y05\u0010v'\\'\tHymP\\\u000eH)#WdK\u0012 #5";
      q[68] = "9J1DGL<\bpP-@3LkOArb\u000b0\u0018\u001c%'BqC\\L,\nqC-";
      q[69] = "o'9Y^pe8wQ5p54a\u0004b'od=h\t/(e9S[&30";
      q[70] = "ur  'Dg{ qK\u0015\u0015|pe\"\u0007)$\u007f/.|";
      q[71] = "|\u001dUpU#wUUp$/h\u0013O|H\u001d9T\u0013+\u0015Jn_NrA-=Q\u0013b$!5\u000eF~Cr;SV\u001bOzd\u0006J|\u001ct9\u0016/ Zv4\u0004A*E8<o";
      q[72] = "fd \u0004|_2xb\u0002BXbq6W\u0015\u000f<&n;$\b3##\u0005?U9|";
      q[73] = "\\\u001dpm.d]W:sSf^\u0016\u000e}#z7Vq~-d\u000f\u0013+w-\u0006";
      q[74] = "As\u0010|\u0019\u001f\u001a3\u0011x~\u000f\u0003@Ke\u0002\u001fx6\u0017s\u0000\f@sMz\u0000n";
      q[75] = "\u0018\u000f!J_p\u0012\u0003$]axI\bJBZ'N\u00055R\u0011{Pn$\u0017[{C\u00114\\\u0007e(\u0000q\u0016\u0007vW\u0010:J\u0019\u001d";
      q[76] = "`\u001bw\u001bM\u0001vX-\u00196\u0010m\u00051\u000fq\u0000\u0004\u000fwXP\u0005{\u001f<\u0004Nn`\u001bw\u001bM\u0001vX-\u00196";
      q[77] = "\u001d/SG^v\u001d9\u0012[%u\u0012<)Oiw\u0011)\u0013QY\u001a\u001eq\u0014\\^&F~^P%{N:\u0007N\u0019#Ap\u000b5D+\u0005)\u0015\t\u001c$O%n";
      q[78] = "oFH\u0006M\u0001/\u0017F\f'\\ROCP]K?\u0015ZS^0lME\fNQ6K\u001d\u000f'";
      q[79] = "jA~ ^nu\u0019-.9fu\u0007(uTT{\u001e?|96#\u0006~-\u0002d*\u001d+\u0011";
      q[80] = "'ynP%\u001d-ukG\u001b\u0015~h\u0005\u0007!\u000f)(eFtMy\u00184\fdN'xuY&\u001e\u0017)?I%@whj\u000bup";
      q[81] = "kJA.6Rm\u0003A-K\u0005U[@,1\u00148\u0001Y/2od\u0002^-{\u000f%W\u001c}K";
      q[82] = ":|~G[4`z&D2:iaS@O8\u0004s\"\u001eT>{ciBJU";
      q[83] = "\u000b\rm\u0004B \u000eO,\u0010(,\u0001\u000b7\u000fD\u001eVLlQ\u0018IPF+T\u0014r\u0002O0\u0001(";
      q[84] = "W5y]7\r\u000eyb8<i\r)!B.\u0004W0\"AUP\u0013/{Z1\t_4\u001e";
      q[85] = "\u00184[RbwCtZV\u0005oM&eR4|H1Y\n;6DJ^\nkxCr\u001bPbx!";
      q[86] = "^j\u0018Twz^|YH\fuQt~Kp\u0016Xj\u001b\u001d=-@x\u0014\u001e\f";
      q[87] = "_3aj>xZq ~TtU5;a8F\u0002r`?k\u0011\u0004x':h*Vq<oT";
      q[88] = "RW!\u0007\u0000([\u0018=B1&T\u000e4\u0000o!T\u00140|\u0000rOWm\u001cA'\r\u0007]";
      q[89] = "I\tdQ'*I\u001f%M\\-O\u000b0Y\\&\u0013\u0001)\u001e&7D\u00017#";
      q[90] = "~._\\pTav\fR\u0017Noq\u001e\u0000P^\u0006)R\u0011+\f={[\n~0~._\\pTav\fR\u0017";
      q[91] = "q^ 7\u0000\u000eqHa+{\u001anM\u001d$J\u0018zJ!|ERv1|t\u0001\u000bh\r${K\u0007\u0013P,?\u0012\u0019/\b#u\u001eb";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(r[var4]);
            q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1855608509278678L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1855608509278678L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1855608509278678L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 105;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 113;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 79;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 107;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 225;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 105;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 113;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 79;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eW_C0261",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eW" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(JumpCircles var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/eW_C0261;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/eW_C0261", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((JumpCircles)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(long var0) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(J)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/eW_C0261", "lambda$onRenderWorld$1", "(JLdev/zprestige/prestige/cq_C0144;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/cq_C0144;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var3.invokeExact((long)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
