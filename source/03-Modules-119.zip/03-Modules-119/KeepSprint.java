package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.entity.player.HungerManager;
import org.lwjgl.glfw.GLFW;

public class KeepSprint extends Module {
   private MinMaxSetting a;
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private int c = -1;
   private static final long k = 2862335443365L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[68];
   private static final String[] p = new String[68];

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 2862335443365L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var5 = b;
      Window var6 = var5.getWindow();
      long var10000 = var6.getHandle();
      short var10001 = 29749;
      long var10002 = 5572421988675318314L ^ var2;
      long var7 = var10000;
      int var19 = GLFW.glfwGetKey(var7, 87);
      int var13 = var4;
      int var12 = var19;
      int var10 = var12;
      int var9 = var12;
      int var11;
      if (var13 != 0) {
         byte var15 = 1;
         int var14 = var9;
         if (var14 == var15) {
            byte var16 = 1;
            var11 = var16;
         } else {
            var11 = 0;
         }
      } else {
         int var17 = var10;
         var11 = var17;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var11);
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 109839837174644L ^ 24877054092289L;
      int var6 = Event.cReturningInt();
      MinecraftClient var8 = b;
      int var27 = var6;
      ClientPlayerEntity var26 = var8.player;
      Object var20 = var26;
      ClientPlayerEntity var19 = var26;
      if (var27 != 0) {
         ClientPlayerEntity var28 = var19;
         if (var28 == null) {
            return;
         }

         Object[] var11 = new Object[0];
         AttackEntityEvent var10 = var1;
         var20 = var10.aReturningEntity(var11);
      }

      Object var7 = var20;
      Object var29 = var7;
      if (var29 != null) {
         KeepSprint var25;
         label40: {
            MinecraftClient var13 = b;
            ClientPlayerEntity var14 = var13.player;
            boolean var10000 = var14.isSprinting();
            int var31 = var6;
            boolean var30 = var10000;
            boolean var24 = var30;
            boolean var21 = var30;
            if (var31 != 0) {
               boolean var32 = var21;
               if (!var32) {
                  return;
               }

               int var34 = var6;
               KeepSprint var33 = this;
               var25 = var33;
               KeepSprint var22 = var33;
               if (var34 == 0) {
                  break label40;
               }

               KeepSprint var35 = var22;
               KeepSprint var23 = var35;
               Object[] var18 = new Object[]{128944439492469L};
               KeepSprint var17 = var23;
               boolean var36 = var17.dReturningBoolean(var18);
               var24 = var36;
            }

            boolean var37 = var24;
            if (!var37) {
               return;
            }

            var25 = this;
         }

         var25.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
      }
   }

   private boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 2862335443365L ^ var2;
      int var59 = Event.bReturningInt();
      ModuleManager var8 = Prestige.d;
      List var9 = var8.aReturningVoid();
      Iterator var5 = var9.iterator();
      int var4 = var59;

      Module var31;
      label73: {
         while (true) {
            Iterator var10 = var5;
            boolean var38 = var10.hasNext();
            if (!var38) {
               break;
            }

            Iterator var11 = var5;
            Module var6 = (Module)var11.next();
            Class var60 = var6.getClass();
            Class<WTap> var13 = WTap.class;
            Class var12 = var60;
            byte var61 = ((byte)((var12.equals(var13)) ? 1 : 0));
            int var40 = var4;
            byte var39 = var61;
            byte var37 = var39;
            byte var25 = var39;
            if (var40 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var37);
            }

            int var42 = var4;
            byte var41 = var25;
            byte var30 = var41;
            byte var26 = var41;
            if (var42 == 0) {
               byte var43 = var26;
               byte var27 = var43;
               byte var44 = var27;
               if (var44 == 0) {
                  int var58 = var4;
                  if (var58 == 0) {
                     continue;
                  }
                  break;
               }

               int var46 = var4;
               Module var45 = var6;
               var31 = var45;
               Module var28 = var45;
               if (var46 != 0) {
                  break label73;
               }

               Module var47 = var28;
               Module var29 = var47;
               Module var17 = var29;
               byte var48 = ((byte)((var17.aReturningBoolean()) ? 1 : 0));
               var30 = var48;
            }

            byte var49 = var30;
            if (var49 == 0) {
               return false;
            }

            var31 = var6;
            break label73;
         }

         return false;
      }

      WTap var7 = (WTap)var31;
      Object[] var21 = new Object[0];
      WTap var20 = var7;
      byte var62 = ((byte)((var20.dReturningBoolean(var21)) ? 1 : 0));
      int var51 = var4;
      byte var50 = var62;
      byte var35 = var50;
      byte var32 = var50;
      if (var51 == 0) {
         byte var52 = var32;
         if (var52 == 0) {
            Object[] var24 = new Object[0];
            WTap var23 = var7;
            byte var63 = ((byte)((var23.eReturningBoolean(var24)) ? 1 : 0));
            int var54 = var4;
            byte var53 = var63;
            var35 = var53;
            byte var33 = var53;
            if (var54 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var35);
            }

            byte var55 = var33;
            byte var34 = var55;
            byte var56 = var34;
            if (var56 == 0) {
               return false;
            }
         }

         var35 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var35);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 132012456627952L ^ 14666174017925L;
      var10001 = 132012456627952L ^ 10923971000865L;
      var10001 = 132012456627952L ^ 100958331242216L;
      int var10 = Event.cReturningInt();
      Object[] var14 = new Object[]{39319266773016L};
      KeepSprint var13 = this;
      byte var10000 = ((byte)((var13.eReturningBoolean(var14)) ? 1 : 0));
      int var111 = var10;
      byte var110 = var10000;
      int var73 = var110;
      byte var72 = var110;
      if (var111 != 0) {
         byte var112 = var72;
         if (var112 != 0) {
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.c = -1;
            return;
         }

         var73 = this.c;
      }

      int var114 = var10;
      int var113 = var73;
      int var75 = var113;
      int var74 = var113;
      if (var114 != 0) {
         int var115 = var74;
         if (var115 > 0) {
            this.c--;
            return;
         }

         var75 = this.c;
      }

      KeepSprint var84;
      label138: {
         int var83;
         int var117 = var10;
         int var116 = var75;
         var83 = var116;
         int var76 = var116;
         label131:
         if (var117 != 0) {
            KeepSprint var81;
            label129: {
               int var118 = var76;
               if (var118 == 0) {
                  int var120 = var10;
                  KeepSprint var119 = this;
                  var81 = var119;
                  KeepSprint var77 = var119;
                  if (var120 == 0) {
                     break label129;
                  }

                  KeepSprint var121 = var77;
                  KeepSprint var78 = var121;
                  var78.c = -1;
                  MinecraftClient var21 = b;
                  ClientPlayerEntity var122 = var21.player;
                  if (var122 != null) {
                     Object[] var24 = new Object[]{128944439492469L};
                     KeepSprint var23 = this;
                     var10000 = ((byte)((var23.dReturningBoolean(var24)) ? 1 : 0));
                     int var124 = var10;
                     byte var123 = var10000;
                     var83 = var123;
                     byte var79 = var123;
                     if (var124 == 0) {
                        break label131;
                     }

                     byte var125 = var79;
                     byte var80 = var125;
                     byte var126 = var80;
                     if (var126 != 0) {
                        MinecraftClient var27 = b;
                        GameOptions var28 = var27.options;
                        KeyBinding var29 = var28.forwardKey;
                        var29.setPressed(true);
                        MinecraftClient var31 = b;
                        ClientPlayerEntity var32 = var31.player;
                        var32.setSprinting(true);
                     }
                  }
               }

               var81 = this;
            }

            int var128 = var10;
            KeepSprint var127 = var81;
            var84 = var127;
            KeepSprint var82 = var127;
            if (var128 == 0) {
               break label138;
            }

            byte var129 = ((byte)((var82.i) ? 1 : 0));
            var83 = var129;
         }

         int var130 = var83;
         if (var130 == 0) {
            return;
         }

         var84 = this;
      }

      var84.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      int var132 = var10;
      MinecraftClient var131 = b;
      MinecraftClient var86 = var131;
      MinecraftClient var85 = var131;
      if (var132 != 0) {
         MinecraftClient var36 = var85;
         ClientPlayerEntity var133 = var36.player;
         if (var133 == null) {
            return;
         }

         var86 = b;
      }

      MinecraftClient var39 = var86;
      GameOptions var40 = var39.options;
      KeyBinding var41 = var40.sneakKey;
      var10000 = ((byte)((var41.isPressed()) ? 1 : 0));
      int var135 = var10;
      byte var134 = var10000;
      byte var88 = var134;
      byte var87 = var134;
      if (var135 != 0) {
         byte var136 = var87;
         if (var136 != 0) {
            return;
         }

         MinecraftClient var43 = b;
         ClientPlayerEntity var44 = var43.player;
         byte var137 = ((byte)((var44.isSneaking()) ? 1 : 0));
         var88 = var137;
      }

      int var139 = var10;
      byte var138 = var88;
      byte var90 = var138;
      byte var89 = var138;
      if (var139 != 0) {
         byte var140 = var89;
         if (var140 != 0) {
            return;
         }

         Object[] var48 = new Object[]{128944439492469L};
         KeepSprint var47 = this;
         var90 = ((byte)((var47.dReturningBoolean(var48)) ? 1 : 0));
      }

      int var142 = var10;
      byte var141 = var90;
      byte var92 = var141;
      byte var91 = var141;
      if (var142 != 0) {
         byte var143 = var91;
         if (var143 == 0) {
            return;
         }

         MinecraftClient var50 = b;
         ClientPlayerEntity var51 = var50.player;
         var92 = ((byte)((var51.horizontalCollision) ? 1 : 0));
      }

      int var145 = var10;
      byte var144 = var92;
      byte var94 = var144;
      byte var93 = var144;
      if (var145 != 0) {
         byte var146 = var93;
         if (var146 != 0) {
            return;
         }

         MinecraftClient var53 = b;
         ClientPlayerEntity var54 = var53.player;
         var94 = ((byte)((var54.isUsingItem()) ? 1 : 0));
      }

      int var148 = var10;
      byte var147 = var94;
      int var96 = var147;
      byte var95 = var147;
      if (var148 != 0) {
         byte var149 = var95;
         if (var149 != 0) {
            return;
         }

         MinecraftClient var56 = b;
         ClientPlayerEntity var57 = var56.player;
         HungerManager var58 = var57.getHungerManager();
         var96 = var58.getFoodLevel();
      }

      int var151 = var10;
      int var150 = var96;
      int var98 = var150;
      int var97 = var150;
      if (var151 != 0) {
         byte var153 = 6;
         int var152 = var97;
         if (var152 <= var153) {
            return;
         }

         MinecraftClient var61 = b;
         GameOptions var62 = var61.options;
         KeyBinding var63 = var62.forwardKey;
         var63.setPressed(false);
         MinMaxSetting var65 = this.a;
         float var66 = var65.aReturningVoid();
         var98 = Math.round(var66);
      }

      KeepSprint var108;
      int var109;
      label98: {
         int var11 = var98;
         MinMaxSetting var67 = this.a;
         float var68 = var67.bReturningVoid();
         int var12 = Math.round(var68);
         int var157 = var10;
         int var156 = var12;
         int var155 = var11;
         KeepSprint var154 = this;
         KeepSprint var105 = var154;
         int var106 = var155;
         int var107 = var156;
         KeepSprint var99 = var154;
         int var100 = var155;
         int var101 = var156;
         if (var157 != 0) {
            int var160 = var101;
            int var159 = var100;
            KeepSprint var158 = var99;
            KeepSprint var104 = var158;
            KeepSprint var102 = var158;
            if (var159 == var160) {
               KeepSprint var161 = var102;
               KeepSprint var103 = var161;
               int var163 = var11;
               KeepSprint var162 = var103;
               var108 = var162;
               var109 = var163;
               break label98;
            }

            var107 = var12;
            var106 = var11;
            var105 = var104;
         }

         Object[] var10005 = new Object[]{null, null, 125343872349393L};
         var10005[1] = var107;
         var10005[0] = var106;
         Object[] var71 = var10005;
         var109 = RandomUtil.aReturningInt(var71);
         var108 = var105;
      }

      var108.c = var109;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(13229474479079L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "\u0089\u008f5U\u0083÷íÖ1éµ2\u0018\u0084õ,";
      int var7 = "\u0089\u008f5U\u0083÷íÖ1éµ2\u0018\u0084õ,".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14543;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/eX", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eX_C0263",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 40;
            yield var15;
         }
         case 1 -> {
            byte var16 = 52;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 32;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 14;
            yield var20;
         }
         case 6 -> {
            byte var21 = 50;
            yield var21;
         }
         case 7 -> {
            byte var22 = 58;
            yield var22;
         }
         case 8 -> {
            byte var23 = 57;
            yield var23;
         }
         case 9 -> {
            byte var24 = 18;
            yield var24;
         }
         case 10 -> {
            byte var25 = 37;
            yield var25;
         }
         case 11 -> {
            byte var26 = 60;
            yield var26;
         }
         case 12 -> {
            byte var27 = 1;
            yield var27;
         }
         case 13 -> {
            byte var28 = 56;
            yield var28;
         }
         case 14 -> {
            byte var29 = 13;
            yield var29;
         }
         case 15 -> {
            byte var30 = 25;
            yield var30;
         }
         case 16 -> {
            byte var31 = 31;
            yield var31;
         }
         case 17 -> {
            byte var32 = 16;
            yield var32;
         }
         case 18 -> {
            byte var33 = 39;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 27;
            yield var37;
         }
         case 23 -> {
            byte var38 = 12;
            yield var38;
         }
         case 24 -> {
            byte var39 = 41;
            yield var39;
         }
         case 25 -> {
            byte var40 = 35;
            yield var40;
         }
         case 26 -> {
            byte var41 = 10;
            yield var41;
         }
         case 27 -> {
            byte var42 = 44;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 26;
            yield var44;
         }
         case 30 -> {
            byte var45 = 45;
            yield var45;
         }
         case 31 -> {
            byte var46 = 54;
            yield var46;
         }
         case 32 -> {
            byte var47 = 47;
            yield var47;
         }
         case 33 -> {
            byte var48 = 30;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 22;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 36;
            yield var55;
         }
         case 41 -> {
            byte var56 = 42;
            yield var56;
         }
         case 42 -> {
            byte var57 = 5;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 20;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 48;
            yield var61;
         }
         case 47 -> {
            byte var62 = 51;
            yield var62;
         }
         case 48 -> {
            byte var63 = 55;
            yield var63;
         }
         case 49 -> {
            byte var64 = 6;
            yield var64;
         }
         case 50 -> {
            byte var65 = 28;
            yield var65;
         }
         case 51 -> {
            byte var66 = 24;
            yield var66;
         }
         case 52 -> {
            byte var67 = 8;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 21;
            yield var69;
         }
         case 55 -> {
            byte var70 = 61;
            yield var70;
         }
         case 56 -> {
            byte var71 = 3;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 17;
            yield var73;
         }
         case 59 -> {
            byte var74 = 7;
            yield var74;
         }
         case 60 -> {
            byte var75 = 46;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 62;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "UqC^\u0016\u000eUqT\u0002\u001a\u0001O:T\u001c\u001a\u0014HK\u0006@OV";
      o[1] = long.class;
      p[1] = "java/lang/Long";
      o[2] = "i\u0015\u0014X_o\u007f\u0015\u0011\u0002Lxh^\u0012\u0004@ly\u0019\u0005\u0013\u000bzU";
      o[3] = "CE)\u007f'}HJ80Dp]G7[qrLT+wf\u007f";
      o[4] = "B\u000f\f$69G\u001a\u0007$=\"K\nEM\u0016\bz";
      o[5] = int.class;
      p[5] = "java/lang/Integer";
      o[6] = "V*\t[E\u001a@*\f\u0001V\rWa\u000f\u0007Z\u0019F&\u0018\u0010\u0011\u000bw";
      o[7] = "^(U/1B^(Bs=MDcBm=XC\u0012\u00120l";
      o[8] = "\u000b\u0003\u000f\u0006dh~#\u0004\tu'\u001f-\u000f\u0002q}k";
      o[9] = boolean.class;
      p[9] = "java/lang/Boolean";
      o[10] = "76\u001b\u0000Yh!6\u001eZJ\u007f6}\u001d\\Fk':\nK\ry\u001b";
      o[11] = "\u0001;N|+\u0018t\u001bEs:W\u0015\u0015Nx>\ra";
      o[12] = "\u0016{\bD\r~\u0016{\u001f\u0018\u0001q\f0\u001f\u0006\u0001d\u000bAMXY ";
      o[13] = "\u0003_>\u001c6t\u0003_)@:{\u0019\u0014)^:n\u001ee}\u0006m";
      o[14] = "6(\u007f^.2C\btQ?}\"\u0006\u007fZ;'V";
      o[15] = "/\u001e*PXL9\u001e/\nK[.U,\fGO?\u0012;\u001b\fX\u0007";
      o[16] = float.class;
      p[16] = "java/lang/Float";
      o[17] = "[-X9$\u0019P\"IvG\u0014E$";
      o[18] = "\u001c\u0012\u0016y6\u001f\u001c\u0012\u0001%:\u0010\u0006Y\u0001;:\u0005\u0001(Qfn";
      o[19] = "g{d(l|g{st`s}0sj`fzA#65";
      o[20] = "I3\u0003b\u0012qI3\u0014>\u001e~Sx\u0014 \u001ekT\tF{O*";
      o[21] = void.class;
      p[21] = "java/lang/Void";
      o[22] = "RV\u0001\u0007Q'DV\u0004]B0S\u001d\u0007[N$BZ\u0010L\u00053_";
      o[23] = "z\u0011.\"DT\u000f1%-U\u001bn?.&QA\u001a";
      o[24] = "]\u0010F\f{FK\u0010CVhQ\\[@PdEM\u001cWG/P~";
      o[25] = "A\" ZGI4\u0002+UV\u0006U\f ^R\\!";
      o[26] = "\u0018BM:\u007f\u001f\u0006JWu\u001d\u0003\u0001W";
      o[27] = "y'.\u0014fmg/4[\u0001lv49\u0001'j";
      o[28] = "!k[\u0004I\tTKP\u000bXF5E[\u0000\\\u001cA";
      o[29] = "7!Z(\"V!!_r1A6j\\t=U'-KcvB\u0002";
      o[30] = "lOS\u0016X\bzOVLK\u001fm\u0004UJG\u000b|CB]\f\u001bO";
      o[31] = "\u001e\u0007rELn\u0015\bc\n-`\u001e\u0003gP";
      o[32] = "=)h5{<+)moh+<bnid?-%y~//5%{uub\t>{hu%>)";
      o[33] = "mCr\u00172F;]i\u001aWPTYjLnS1PiF,=j\nfMn\u0001*\u0003$KW";
      o[34] = "e.[[?\u001507_\u001fZ\u0006\f>\u0000^%P|)Y\u000f l";
      o[35] = "G\u0001\u001e*=u\u001b\\Q7Yr{YW#+hAT\u0012te\u0018";
      o[36] = "r\u007f\u0005Rk~{9EB\u0013z\u001da\rT*yxh\u000e^h\u0017#2\u0001U*+c;CS\u0013";
      o[37] = "\b`x#@\\^~c.%N1\"x~\u001c\u001f[g\u007foN'\u000br~+\u001dMNuoy%";
      o[38] = "T\u0018G/=n\u0002\u0006\\\"Xym\u0002_ta{\b\u000b\\~#\u0015SQSua)\u0013X\u0011sX";
      o[39] = "\u001c\u001fE[R>\u0015PEC;j@]LBWX\u0010\u001e\u0015\u0018;1\u001c_G\u001c\u0007q\u0015\u001dA%";
      o[40] = "\t#c\fu I'x\\\u0015>Vvmxx-quc7,o\tcj\u0006q+W%\u0012\u000b,7@h(\u0006i`\u000e\u0018.\u000es#B\"#K$m2";
      o[41] = "\u001d9LvDP\u00111G+)L\u00008_#UJ\u0006UD8CQG0\u001e G]|";
      o[42] = "vr%-a\u0016*/j0\u0005\u0010J*l$w\u000bp')s9{";
      o[43] = "($m3b\"za;$\u0006'\u0017~s#? rwp)}N'b` esr-~y\u0006";
      o[44] = ">\u0002<Mt\\?X7R\u0016YZX7K*]'T?@w0";
      o[45] = "\u007f\\VE)\u0001%DRI\u0012\u0002s^@9v\u001dg\u0011S]w\u0000|T<";
      o[46] = "\f@'3BTWUwjz\u0001PBsc-V\u000e\u0015+\u000fKQXQ~>B\u001eXI";
      o[47] = "x^\nw(3p\u0018\u0014vU1rJ\u0012t\u0002f#\u0016J\u001891uF\u0013#e4z\u001d";
      o[48] = "\u001c\u000f!\u00044\u0016\u001d\u0012:A[\u001f\u0001\u000b1_ r\u001c\u000f!\u00044\u0016\u001d\u0012:A[LI\b3\u0002g\f@J5;";
      o[49] = "d8&\u00022]qhyBUI\u00012,X:Gm3vS%";
      o[50] = "vu2~C#\u007f:2f*w*7;gFEzta0*,v509\u0016l\u007fw6\u0000Gn<\"cbAw<r[";
      o[51] = "|\u000eEXZ)'\u001b\u0015\u0001bw,\u001d\u0015\u0003\u000eE{[KTY\u0012&\f\b^[w!\bEd";
      o[52] = "mp\u0016*\u0014'7h\u0012&/\"ey:;_>\f<M(D{0|DjBB";
      o[53] = "\u001f\nlefx\u001dYo%We\u001fH}|;WM\t-%W<KRokm1\u000e\u0005!\u001b";
      o[54] = "w9\u0005\u0014E p=H.\u0019(l4\u001fB+y,e@.E{+/\u0000\u001f\u0018?uix";
      o[55] = "J;\u0015T!PSe\u001cYC\u0017Fv\u0018GC\u0007\u001e0\u0001\u00173\u0010Ga\u0004+\u007fTGy\u000e\u0011r\u0011\u00107~";
      o[56] = "vY%Jfm-Lu\u0013^8*[q\u001a\tou\u0007-v5/7Yh\u001a=i)X";
      o[57] = "d\u0000H\u0003sflFV\u0002\u000edn\u0014P\u0000Y3?B\u000elbdi\u0018QW>afC";
      o[58] = "Ak8\nJD\u0014r<N/T({c\u000fP\u0001Xl:^U=";
      o[59] = "_\t!{!\u001bVF!cHO\u0003K(b$}Q\ft9HGPF640E\u0003Ev\u0005";
      o[60] = "\u0014\u0016mpt\u000f\u001dP-`\f\n{\bev5\b\u001e\u0001f|wfE[iw5Z\u0005R+q\f";
      o[61] = ">4{N!mb1t\u0015D3?&}H(\u0001ha!\u001f}VlkcD}j,b!BD;.!t\u0017&=7!$/";
      o[62] = "-\u0017\u0015G\u0017\u0018p\u0010UHz\nNPZU\u0011Zr\u0010S\u0017\u0017c";
      o[63] = "uF\u0016l\u000ea)C\u00197k?tT\u0010j\u0007\r \u0014K1kd(V\u001b4W$!\u0014\u001d\r";
      o[64] = "\u0005\u001f~x>\u001c\u0012\u0011l!C\tk\u0018g)z\u000e\u000e\u0011d#8`WCs13ZZ\u0006$\u007fC";
      o[65] = ".`h.\n-'/h6cyr\"a7\u000fK\"`;lc\". ji_b'blP";
      o[66] = "0PU6I.9\u001fU. zl\u0012\\/LH?W\u0005u !0\u0010Wq\u001ca9RQH";
      o[67] = "q*'q\\pxe'i5/!y*cb|q+p\u000f\u000bp>\u007fw3Ky|y";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(2208161657158551L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(2208161657158551L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(2208161657158551L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 194;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 99;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 214;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 104;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 200;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 194;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 99;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 214;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eX_C0263",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
