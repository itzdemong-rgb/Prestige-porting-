package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class KeyPearl extends Module {
   private ModeSetting a;
   private MinMaxSetting c;
   private ElapsedTimer d;
   private int e;
   private boolean i;
   private static final long k = 59985622787740L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[61];
   private static final String[] q = new String[61];
   private static volatile MethodHandle bindingCache1;

   public KeyPearl() {
      super();
      long var10001 = 44561864335884L ^ 80873189020965L;

      this.d = new ElapsedTimer(106698256430889L);
      this.e = 0;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 125891390456893L;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      Object[] var7 = new Object[]{var4};
      KeyPearl var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 29185196035500L ^ 114724682544628L;
      var10001 = 29185196035500L ^ 109991868029880L;
      var10001 = 29185196035500L ^ 44910018603844L;
      var10001 = 29185196035500L ^ 99278848607479L;
      var10001 = 29185196035500L ^ 61061603035811L;
      var10001 = 29185196035500L ^ 73347497450734L;
      var10001 = 29185196035500L ^ 100602557483226L;
      var10001 = 29185196035500L ^ 45775386064673L;
      int var20 = Event.bReturningInt();
      int var92 = var20;
      MinecraftClient var91 = b;
      MinecraftClient var74 = var91;
      MinecraftClient var73 = var91;
      if (var92 == 0) {
         MinecraftClient var24 = var73;
         Screen var93 = var24.currentScreen;
         if (var93 != null) {
            return;
         }

         MinecraftClient var94 = b;
         var74 = var94;
      }

      int var96 = var20;
      MinecraftClient var95 = var74;
      Object var76 = var95;
      MinecraftClient var75 = var95;
      if (var96 == 0) {
         MinecraftClient var27 = var75;
         boolean var97 = var27.isWindowFocused();
         if (!var97) {
            return;
         }

         ModeSetting var30 = this.a;
         var76 = var30.aReturningObject();
      }

      int var82;
      String var31 = (String)var76;
      String var21 = var31.toString();
      // String var32 = var21;
      int var10000 = var32.hashCode();
      int var99 = var20;
      int var98 = var10000;
      var82 = var98;
      int var77 = var98;
      label89:
      if (var99 == 0) {
         int var100 = var77;
         switch (var100) {
            case -1955878649:
               String var35 = "Normal";
               String var34 = var21;
               byte var128 = ((byte)((var34.equals(var35)) ? 1 : 0));
               int var102 = var20;
               byte var101 = var128;
               var82 = var101;
               byte var78 = var101;
               if (var102 != 0) {
                  break label89;
               }

               byte var103 = var78;
               byte var79 = var103;
               byte var104 = var79;
               if (var104 == 0) {
                  break;
               }

               var22 = 0;
               int var105 = var20;
               if (var105 == 0) {
                  break;
               }
            case -1818460043:
               String var39 = "Silent";
               String var38 = var21;
               byte var129 = ((byte)((var38.equals(var39)) ? 1 : 0));
               int var107 = var20;
               byte var106 = var129;
               var82 = var106;
               byte var80 = var106;
               if (var107 != 0) {
                  break label89;
               }

               byte var108 = var80;
               byte var81 = var108;
               byte var109 = var81;
               if (var109 != 0) {
                  var22 = 1;
               }
         }

         var82 = var22;
      }

      int var88;
      label110: {
         label103: {
            int var111 = var20;
            int var110 = var82;
            int var84 = var110;
            int var83 = var110;
            if (var111 == 0) {
               int var112 = var83;
               switch (var112) {
                  case 0:
                     ElapsedTimer var130 = this.d;
                     MinMaxSetting var43 = this.c;
                     Float var44 = (Float)var43.aReturningObject();
                     float var140 = var44;
                     Object[] var10004 = new Object[]{null, 139098136696340L};
                     var10004[0] = var140;
                     Object[] var46 = var10004;
                     ElapsedTimer var45 = var130;
                     byte var113 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
                     var84 = var113;
                     break;
                  case 1:
                     break label103;
                  default:
                     return;
               }
            }

            int var115 = var20;
            int var114 = var84;
            int var86 = var114;
            int var85 = var114;
            if (var115 == 0) {
               int var116 = var85;
               if (var116 == 0) {
                  return;
               }

               var86 = (((this.i) ? 1 : 0));
            }

            int var118 = var20;
            int var117 = var86;
            var88 = var117;
            int var87 = var117;
            if (var118 != 0) {
               break label110;
            }

            int var119 = var87;
            if (var119 != 0) {
               int var120 = this.e;
               var88 = var120;
               break label110;
            }

            MinecraftClient var54 = b;
            ClientPlayerEntity var55 = var54.player;
            ItemStack var56 = var55.getMainHandStack();
            Item var131 = var56.getItem();
            Item var122 = Items.ENDER_PEARL;
            Item var121 = var131;
            if (var121 != var122) {
               Object[] var58 = new Object[]{55333549156072L};
               KeyPearl var57 = this;
               int var23 = var57.aReturningInt(var58);
               int var124 = var20;
               int var123 = var23;
               int var90 = var123;
               int var89 = var123;
               if (var124 == 0) {
                  // int var125 = var89;
                  if (var125 == var126) {
                     Object[] var61 = new Object[]{126290808879192L};
                     KeyPearl var60 = this;
                     var60.aReturningVoid(var61);
                     return;
                  }

                  Object[] var63 = new Object[]{49487520630543L};
                  this.e = InventoryUtil.aReturningInt(var63);
                  var90 = var23;
               }

               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var90;
               Object[] var64 = var10003;
               InventoryUtil.aReturningVoid(var64);
               Object[] var66 = new Object[]{97026511065410L};
               KeyPearl var65 = this;
               var65.jReturningVoid(var66);
               return;
            }

            Object[] var67 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
            ItemUseUtil.cReturningBoolean(var67);
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
            Object[] var69 = new Object[]{97026511065410L};
            KeyPearl var68 = this;
            var68.jReturningVoid(var69);
            int var127 = var20;
            if (var127 == 0) {
               return;
            }
         }

         Item var132 = Items.ENDER_PEARL;
         Runnable var141 = invokeBinding1();
         Object[] var10005 = new Object[]{null, null, null, 71193876973915L};
         var10005[2] = true;
         var10005[1] = var141;
         var10005[0] = var132;
         Object[] var70 = var10005;
         InventoryUtil.jReturningBoolean(var70);
         Object[] var72 = new Object[]{126290808879192L};
         KeyPearl var71 = this;
         var71.aReturningVoid(var72);
         return;
      }

      Object[] var142 = new Object[]{null, 72518082610550L};
      var142[0] = var88;
      Object[] var51 = var142;
      InventoryUtil.aReturningVoid(var51);
      Object[] var53 = new Object[]{126290808879192L};
      KeyPearl var52 = this;
      var52.aReturningVoid(var53);
   }

   private int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 59985622787740L ^ var2;
      int var16 = Event.cReturningInt();
      int var4 = var16;

      int var15;
      do {
         int var12 = (int)o;
         int var11 = var5;
         if (var11 > var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.ENDER_PEARL;
         Item var13 = var18;
         if (var13 == var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 != 0);

      return -1;
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 59985622787740L ^ var2;
      long var4 = var2 ^ 32415364860305L;
      long var6 = var2 ^ 79463733813214L;
      MinMaxSetting var10000 = this.c;
      Object[] var9 = new Object[]{var4};
      MinMaxSetting var8 = var10000;
      var8.bReturningVoid(var9);
      ElapsedTimer var13 = this.d;
      Object[] var11 = new Object[]{var6};
      ElapsedTimer var10 = var13;
      var10.aReturningVoid(var11);
   }

   private static void lambda$onTick$1() {
      long var10001 = 105654696224102L ^ 91523508936683L;
      Object[] var4 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var4);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Normal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(7017626022849L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[3];
      String var11 = "µ§ß²\u009f=äþV\n:æÞMz:\u0010=\u0096\u0013ëÏ¶w\u009duïP)Ø\u000e\u0082¸\u0010|?\u0000\u007f\u0097\u0081\u0097l\u008a\u0019.\u0092#<v(";
      int var13 = "µ§ß²\u009f=äþV\n:æÞMz:\u0010=\u0096\u0013ëÏ¶w\u009duïP)Ø\u000e\u0082¸\u0010|?\u0000\u007f\u0097\u0081\u0097l\u008a\u0019.\u0092#<v("
         .length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = b(var15).intern();
         // var14[var12++] = var21;
         if ((var9 += var10) >= var13) {
            l = var14;
            m = new String[3];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(7017626022849L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = -5601134892553763618L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)178L,
                  (byte)45636L,
                  (byte)11683013L,
                  (byte)2990851453L,
                  (byte)765657972166L,
                  (byte)196008440874569L,
                  (byte)50178160863889796L,
                  (byte)-5601134892553763618L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            o = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16788;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eY", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eY_C0265",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 9;
            yield var15;
         }
         case 1 -> {
            byte var16 = 29;
            yield var16;
         }
         case 2 -> {
            byte var17 = 47;
            yield var17;
         }
         case 3 -> {
            byte var18 = 56;
            yield var18;
         }
         case 4 -> {
            byte var19 = 20;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 19;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 59;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 62;
            yield var25;
         }
         case 11 -> {
            byte var26 = 23;
            yield var26;
         }
         case 12 -> {
            byte var27 = 1;
            yield var27;
         }
         case 13 -> {
            byte var28 = 63;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 7;
            yield var30;
         }
         case 16 -> {
            byte var31 = 31;
            yield var31;
         }
         case 17 -> {
            byte var32 = 43;
            yield var32;
         }
         case 18 -> {
            byte var33 = 49;
            yield var33;
         }
         case 19 -> {
            byte var34 = 24;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 34;
            yield var36;
         }
         case 22 -> {
            byte var37 = 22;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 48;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 40;
            yield var42;
         }
         case 28 -> {
            byte var43 = 0;
            yield var43;
         }
         case 29 -> {
            byte var44 = 21;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 46;
            yield var47;
         }
         case 33 -> {
            byte var48 = 15;
            yield var48;
         }
         case 34 -> {
            byte var49 = 25;
            yield var49;
         }
         case 35 -> {
            byte var50 = 3;
            yield var50;
         }
         case 36 -> {
            byte var51 = 5;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 52;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 41;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 6;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 35;
            yield var61;
         }
         case 47 -> {
            byte var62 = 51;
            yield var62;
         }
         case 48 -> {
            byte var63 = 10;
            yield var63;
         }
         case 49 -> {
            byte var64 = 61;
            yield var64;
         }
         case 50 -> {
            byte var65 = 18;
            yield var65;
         }
         case 51 -> {
            byte var66 = 28;
            yield var66;
         }
         case 52 -> {
            byte var67 = 13;
            yield var67;
         }
         case 53 -> {
            byte var68 = 27;
            yield var68;
         }
         case 54 -> {
            byte var69 = 58;
            yield var69;
         }
         case 55 -> {
            byte var70 = 32;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 57;
            yield var72;
         }
         case 58 -> {
            byte var73 = 54;
            yield var73;
         }
         case 59 -> {
            byte var74 = 42;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 39;
            yield var77;
         }
         default -> 53;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "qCle\u0018\u0005gCi?\u000b\u0012p\bj9\u0007\u0006aO}.L\u0010L";
      p[1] = "@W\u0003,?\u00045w\b#.KTy\u0003(*\u0011 ";
      p[2] = void.class;
      q[2] = "java/lang/Void";
      p[3] = "\n\u0011s\u0019\u001ea\u0001\u001ebVcy\u0012\u0019k\u001f";
      p[4] = "iJ\u001b\u001e0MbE\nQQCiN\u000e\u000b";
      p[5] = boolean.class;
      q[5] = "java/lang/Boolean";
      p[6] = "zp\tw\u0016\u0005lp\f-\u0005\u0012{;\u000f+\t\u0006j|\u0018<B\u0014[";
      p[7] = int.class;
      q[7] = "java/lang/Integer";
      p[8] = "b5Q8MKt5Tb^\\c~WdRHr9@s\u0019]_";
      p[9] = "t\n\u001c\u0004'\u001d\u0001*\u0017\u000b6R`$\u001c\u00002\b\u0014";
      p[10] = "R'>\u0005Q\u0019R')Y]\u0016Hl)G]\u0003O\u001d{\u001c\u0005I";
      p[11] = "\u001aD?\u001e]^\u001aD(BQQ\u0000\u000f(\\QD\u0007~z\u0007\t\u0005";
      p[12] = "N$\u0004\\Y\rE+\u0015\u0013:\u0000P&\u001ax\u000f\u0002A5\u0006T\u0018\u000f";
      p[13] = "\u0015V\u0002t3\u000f`v\t{\"@\u0001x\u0002p&\u001au";
      p[14] = "!1\u001bi+\u0007!1\f5'\b;z\f+'\u001d<\u000bXsp";
      p[15] = "[F\u0014J\u000f\u0003[F\u0003\u0016\u0003\fA\r\u0003\b\u0003\u0019F|SUR";
      p[16] = "\u0000$mG.\t\u0000$z\u001b\"\u0006\u001aoz\u0005\"\u0013\u001d\u001e-Zt";
      p[17] = ";a\u0004\u001c\u0018\u000f-a\u0001F\u000b\u0018:*\u0002@\u0007\f+m\u0015WL\u001c0";
      p[18] = "\u0011n7d\"$dN<k3k\u0005@7`71q";
      p[19] = "Kb\u001be*\u001c]b\u001e?9\u000bJ)\u001d95\u001f[n\n.~\b~";
      p[20] = "\u0014XOQ\u001c=axD^\rr\u0000vOU\t(t";
      p[21] = "{32y7em37#$rzx4%(fk?#2cvs";
      p[22] = ":<(\u0000\u0011UO\u001c#\u000f\u0000\u001a.\u0012(\u0004\u0004@Z";
      p[23] = "pbPF\u0003ffbU\u001c\u0010qq)V\u001a\u001ce`nA\rWrR";
      p[24] = "l9\u0003P-Eg6\u0012\u001fEEi9\u0001";
      p[25] = float.class;
      q[25] = "java/lang/Float";
      p[26] = "'R u\r\fRr+z\u001cC3| q\u0018\u0019G";
      p[27] = ";I\u001a\u0019HH;I\rEDG!\u0002\r[DR&s_\u0005\u0013\u0019";
      p[28] = "s;i&D^\u0006\u001bb)U\u0011g\u0015i\"QK\u0013";
      p[29] = "$)\u0013l6D$)\u00040:K>b\u0004.:^9\u0013Vzk\u001f";
      p[30] = "\u000e4\u0018\r1y\u00184\u001dW\"n\u000f\u007f\u001eQ.z\u001e8\tFem&";
      p[31] = "Bm0\u0007G%7M;\bVjVC0\u0003R0\"";
      p[32] = "@&\u001e+\u0019\u00145\u0006\u0015$\b[T\b\u001e/\f\u0001 ";
      p[33] = "xb pa\u0016xb7,m\u0019b)72m\feXeh:N";
      p[34] = "^\u0011kH]}_\u001enI/f:\u001f\u007f\u0000KtFDcC\u001e\f\u0003\u000bh\\@vD\u0011.]/";
      p[35] = "Ew>[-:\u001c,jP\u0010jy!4Y(;\u0016{+Pa\u0000";
      p[36] = "UZ\u0006k\u0017a\u0004\u0017_,~j\tZ\u0002p\u0012X_\u001f_+N\u000f\u0002L\u0000k\u0003?\u000bV\bx~";
      p[37] = "(yiH{-,.+T\u0004?{np\u007fc3\u007f\u0015-T|g)zwKu.\u0012";
      p[38] = "u\u0000`]\u0014\u0007uNeGr\t&\ryY\u001e;t@!\u000frS9Os\u000e\u000f\u0011u\u0016e>";
      p[39] = "]uaHI~[qc!B\u001e\u0001h<D\u0014pLg3J+.C*i\u001eEcL%g!";
      p[40] = "\u0014S^\u0012\u000em\u0012W\\{\u0005\r\u001dP\u000b\u001f\u0014qFLHJl0\u0018D\u000b@\u0003j\u0007MB{";
      p[41] = "i\"I\b\u0013vj*_\u0004~~a\"]\u000f))?r\u0004c\u0014!lp\u0002\u0011\u0001(r\u007f";
      p[42] = "*4dI`F#o}P\u001dQAkt\u0014y@=0hW,8x\u007fcHrB?e%I\u001d";
      p[43] = "4\u0016Q,{\u000e7\u001eG \u0016\r0\u0007A z?dF\u001fv\u0016S-\u0011_\"fV=ABG";
      p[44] = "y,U:l3 w\u00011QbEz_8i2* @1 \t";
      p[45] = "ZX=DB\u007fWJzS$z7A-\u0005@iK\u001a1F\u0015\u0011\fT+CAa\tD{^$";
      p[46] = "\u0017\u00053\u001b-:\u0015_d\u000b\u001c-xU=\u0017-<\u0015\u00170HaD";
      p[47] = "\u0014.jz\u0016f\u0017&|v{n\u001c.~},9By&\u0011J|\u0019?s\u007f\u001b1@x";
      p[48] = "e@N\u001d,\u00171SY\u001c\u0014\u001bXXZ\\p\n$\u0003F\u001f%raLM\u0000{\b&V\u000b\u0001\u0014";
      p[49] = "\u0013k0g\u001fu\u001a0)~bix4 :\u0006s\u0004o<yS\u000bC!&|\u0007{F1vab";
      p[50] = "\t#l^\u000b\t\u0000xuGv\u001eb||\u0003\u0012\u000f\u001e'`@Gw_yh\u0003M\u0018\u0005faJv";
      p[51] = "'*9d\u0012\u0002xa|at\f%=!0#Rzky\\K\u0010z:u!\t\\#,";
      p[52] = "H\n\u0017&VLL]U:)B\u0015=\u0012 HX\u001dfT6PB\r\u0014Pa\u0012^r";
      p[53] = "{riE\u0000R\u007f%+Y\u007fM8cy]\u0004 zwr\b\u0007M8z-D\u007f\u001b1tn\\\u000f\u001e!$s9";
      p[54] = "\u0015\f![\\\u001eA\u001f6Zd\u0012(\u00145\u001a\u0000\u0003TO)YU{\u0013\u00013\\\u0001\u000b\u0016\u0011cAd";
      p[55] = "+!|!~@-%~H~ \"\"),d\\y>jy\u001c\u001965u'f^,stH";
      p[56] = "3HdVR\u0005b\u0005=\u0011;\u000eoH`MW<<\f<\u0015;UsMcLPU=Hy*";
      p[57] = "W &\u007fp\u0013\u0007<rh\u0013\u0004;(/\"w\u0015Gs3a\"m\u0002<8~|\u0017E&~\u007f\u0013";
      p[58] = "sdtEf\u001fz~|V\u001bJxrv^wx(2-\t\u001b\u0012uv.\u0002tHj\u007fg9%^lmpR%\u0010iw\u0016";
      p[59] = "\bG)\u0003\u0002B^B\"\u00143T\u0003Y-\u0003mS\u0003C)\u007fSC\u001a\u0006>\u0005\u000fP\u0005XD";
      p[60] = "\\G]78F@\u0010\u0005lFL_\u0017\u0006?\u0011\u001f\u000eBRS$\u001f\u0001\u001e\u001c78HYE";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(334401015648162L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(334401015648162L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(334401015648162L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 118;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 203;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 228;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 85;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 90;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 111;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 118;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 203;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 228;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eY_C0265",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eY" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("()Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eY_C0265", "lambda$onTick$1", "()V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
