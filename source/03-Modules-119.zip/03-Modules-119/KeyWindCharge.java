package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class KeyWindCharge extends Module {
   private ModeSetting a;
   private MinMaxSetting c;
   private ElapsedTimer d;
   private int e;
   private boolean i;
   private static final long k = 73692856250572L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[65];
   private static final String[] q = new String[65];
   private static volatile MethodHandle bindingCache1;

   public KeyWindCharge() {
      super();
      long var10001 = 106715916876924L ^ 17783655253L;

      this.d = new ElapsedTimer(106698256430889L);
      this.e = 0;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 7376905432682L;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      Object[] var7 = new Object[]{var4};
      KeyWindCharge var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 67975248358493L ^ 86925411423237L;
      var10001 = 67975248358493L ^ 96050857766096L;
      var10001 = 67975248358493L ^ 74015029787209L;
      var10001 = 67975248358493L ^ 127210307342161L;
      var10001 = 67975248358493L ^ 117089239655150L;
      var10001 = 67975248358493L ^ 18487932005202L;
      var10001 = 67975248358493L ^ 136506241313067L;
      var10001 = 67975248358493L ^ 18858269857608L;
      var10001 = 67975248358493L ^ 16459993847504L;
      int var22 = Event.cReturningInt();
      int var98 = var22;
      MinecraftClient var97 = b;
      MinecraftClient var78 = var97;
      MinecraftClient var77 = var97;
      if (var98 != 0) {
         MinecraftClient var26 = var77;
         Screen var99 = var26.currentScreen;
         if (var99 != null) {
            return;
         }

         MinecraftClient var100 = b;
         var78 = var100;
      }

      int var102 = var22;
      MinecraftClient var101 = var78;
      Object var80 = var101;
      MinecraftClient var79 = var101;
      if (var102 != 0) {
         MinecraftClient var29 = var79;
         boolean var103 = var29.isWindowFocused();
         if (!var103) {
            return;
         }

         ModeSetting var32 = this.a;
         var80 = var32.aReturningObject();
      }

      int var86;
      String var23 = (String)var80;
      // String var33 = var23;
      int var10000 = var33.hashCode();
      int var105 = var22;
      int var104 = var10000;
      var86 = var104;
      int var81 = var104;
      label91:
      if (var105 != 0) {
         int var106 = var81;
         switch (var106) {
            case -1955878649:
               String var36 = "Normal";
               String var35 = var23;
               byte var134 = ((byte)((var35.equals(var36)) ? 1 : 0));
               int var108 = var22;
               byte var107 = var134;
               var86 = var107;
               byte var82 = var107;
               if (var108 == 0) {
                  break label91;
               }

               byte var109 = var82;
               byte var83 = var109;
               byte var110 = var83;
               if (var110 == 0) {
                  break;
               }

               var24 = 0;
               int var111 = var22;
               if (var111 != 0) {
                  break;
               }
            case -1818460043:
               String var40 = "Silent";
               String var39 = var23;
               byte var135 = ((byte)((var39.equals(var40)) ? 1 : 0));
               int var113 = var22;
               byte var112 = var135;
               var86 = var112;
               byte var84 = var112;
               if (var113 == 0) {
                  break label91;
               }

               byte var114 = var84;
               byte var85 = var114;
               byte var115 = var85;
               if (var115 != 0) {
                  var24 = 1;
               }
         }

         var86 = var24;
      }

      label105: {
         int var117 = var22;
         int var116 = var86;
         int var88 = var116;
         int var87 = var116;
         if (var117 != 0) {
            int var118 = var87;
            switch (var118) {
               case 0:
                  ElapsedTimer var136 = this.d;
                  MinMaxSetting var44 = this.c;
                  Float var45 = (Float)var44.aReturningObject();
                  float var147 = var45;
                  Object[] var10004 = new Object[]{null, 139098136696340L};
                  var10004[0] = var147;
                  Object[] var47 = var10004;
                  ElapsedTimer var46 = var136;
                  byte var119 = ((byte)((var46.aReturningBoolean(var47)) ? 1 : 0));
                  var88 = var119;
                  break;
               case 1:
                  break label105;
               default:
                  return;
            }
         }

         int var121 = var22;
         int var120 = var88;
         int var90 = var120;
         int var89 = var120;
         if (var121 != 0) {
            int var122 = var89;
            if (var122 == 0) {
               return;
            }

            var90 = (((this.i) ? 1 : 0));
         }

         int var124 = var22;
         int var123 = var90;
         int var92 = var123;
         int var91 = var123;
         if (var124 != 0) {
            int var125 = var91;
            if (var125 != 0) {
               var10000 = this.e;
               Object[] var149 = new Object[]{null, 72518082610550L};
               var149[0] = var10000;
               Object[] var51 = var149;
               InventoryUtil.aReturningVoid(var51);
               Object[] var53 = new Object[]{126290808879192L};
               KeyWindCharge var52 = this;
               var52.aReturningVoid(var53);
               return;
            }

            MinecraftClient var55 = b;
            ClientPlayerEntity var56 = var55.player;
            Object[] var57 = new Object[]{var56.getMainHandStack(), 96410439601843L};
            var92 = (((aReturningBoolean(var57)) ? 1 : 0));
         }

         int var127 = var22;
         int var126 = var92;
         int var93 = var126;
         if (var127 != 0) {
            int var128 = var93;
            if (var128 == 0) {
               Object[] var60 = new Object[]{117137411260557L};
               KeyWindCharge var59 = this;
               int var25 = var59.aReturningInt(var60);
               int var130 = var22;
               int var129 = var25;
               int var95 = var129;
               int var94 = var129;
               if (var130 != 0) {
                  // int var131 = var94;
                  if (var131 == var132) {
                     Object[] var63 = new Object[]{126290808879192L};
                     KeyWindCharge var62 = this;
                     var62.aReturningVoid(var63);
                     return;
                  }

                  Object[] var65 = new Object[]{49487520630543L};
                  this.e = InventoryUtil.aReturningInt(var65);
                  var95 = var25;
               }

               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var95;
               Object[] var66 = var10003;
               InventoryUtil.aReturningVoid(var66);
               Object[] var68 = new Object[]{49428378549013L};
               KeyWindCharge var67 = this;
               var67.jReturningVoid(var68);
               return;
            }

            Object[] var69 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
            boolean var96 = ItemUseUtil.cReturningBoolean(var69);
         }

         this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
         Object[] var71 = new Object[]{49428378549013L};
         KeyWindCharge var70 = this;
         var70.jReturningVoid(var71);
         int var133 = var22;
         if (var133 != 0) {
            return;
         }
      }

      Object[] var73 = new Object[]{117137411260557L};
      KeyWindCharge var72 = this;
      var10000 = var72.aReturningInt(var73);
      Runnable var148 = invokeBinding1();
      Object[] var10005 = new Object[]{null, null, null, 86177674060556L};
      var10005[2] = true;
      var10005[1] = var148;
      var10005[0] = var10000;
      Object[] var74 = var10005;
      InventoryUtil.bReturningVoid(var74);
      Object[] var76 = new Object[]{126290808879192L};
      KeyWindCharge var75 = this;
      var75.aReturningVoid(var76);
   }

   private int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 73692856250572L ^ var2;
      long var4 = var2 ^ 138691327327986L;
      int var10000 = Event.bReturningInt();
      int var6 = var10000;

      byte var17;
      while (true) {
         int var19 = (int)o;
         int var18 = var7;
         if (var18 <= var19) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var28 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var28;
            Object[] var12 = new Object[]{var10.getStack(var11), var4};
            byte var29 = ((byte)((aReturningBoolean(var12)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var29;
            var17 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               break;
            }

            int var23 = var6;
            byte var22 = var13;
            int var16 = var22;
            byte var14 = var22;
            if (var23 != 0) {
               return var16;
            }

            byte var24 = var14;
            byte var15 = var24;
            byte var25 = var15;
            if (var25 != 0) {
               var16 = var7;
               return var16;
            }

            var7++;
            int var26 = var6;
            if (var26 == 0) {
               continue;
            }
         }

         var17 = -1;
         break;
      }

      return var17;
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 73692856250572L ^ var2;
      long var4 = var2 ^ 31035655910806L;
      long var6 = var2 ^ 80285032014809L;
      MinMaxSetting var10000 = this.c;
      Object[] var9 = new Object[]{var4};
      MinMaxSetting var8 = var10000;
      var8.bReturningVoid(var9);
      ElapsedTimer var13 = this.d;
      Object[] var11 = new Object[]{var6};
      ElapsedTimer var10 = var13;
      var10.aReturningVoid(var11);
   }

   public static boolean aReturningBoolean(Object[] var0) {
      ItemStack var1 = (ItemStack)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 73692856250572L ^ var2;
      ItemStack var4 = var1;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   private static void lambda$onTick$1() {
      long var10001 = 136794834270664L ^ 87139972727621L;
      Object[] var4 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var4);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Normal";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(27697507380527L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[3];
      String var11 = "µF7s\u001f)Ô0ý\u008f_A<$r\u0007\u0010n[í$/kÙÐ\u00948Ø\u009d\u0006\u0087 \u0083\u00104Ãµv©-§£~ºd§O\u001dÉÃ";
      int var13 = "µF7s\u001f)Ô0ý\u008f_A<$r\u0007\u0010n[í$/kÙÐ\u00948Ø\u009d\u0006\u0087 \u0083\u00104Ãµv©-§£~ºd§O\u001dÉÃ".length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = b(var15).intern();
         // var14[var12++] = var21;
         if ((var9 += var10) >= var13) {
            l = var14;
            m = new String[3];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(27697507380527L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = -930043812513376649L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)243L,
                  (byte)62231L,
                  (byte)15931346L,
                  (byte)4078424596L,
                  (byte)1044076696705L,
                  (byte)267283634356631L,
                  (byte)68424610395297558L,
                  (byte)-930043812513376649L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            o = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10051;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/eZ", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eZ_C0267",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 45;
            yield var15;
         }
         case 1 -> {
            byte var16 = 7;
            yield var16;
         }
         case 2 -> {
            byte var17 = 11;
            yield var17;
         }
         case 3 -> {
            byte var18 = 39;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 60;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 57;
            yield var22;
         }
         case 8 -> {
            byte var23 = 22;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 56;
            yield var25;
         }
         case 11 -> {
            byte var26 = 24;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 23;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 8;
            yield var32;
         }
         case 18 -> {
            byte var33 = 36;
            yield var33;
         }
         case 19 -> {
            byte var34 = 5;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 50;
            yield var36;
         }
         case 22 -> {
            byte var37 = 31;
            yield var37;
         }
         case 23 -> {
            byte var38 = 26;
            yield var38;
         }
         case 24 -> {
            byte var39 = 61;
            yield var39;
         }
         case 25 -> {
            byte var40 = 28;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 12;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 51;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 59;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 37;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 0;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 18;
            yield var54;
         }
         case 40 -> {
            byte var55 = 13;
            yield var55;
         }
         case 41 -> {
            byte var56 = 40;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 34;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 49;
            yield var62;
         }
         case 48 -> {
            byte var63 = 2;
            yield var63;
         }
         case 49 -> {
            byte var64 = 17;
            yield var64;
         }
         case 50 -> {
            byte var65 = 21;
            yield var65;
         }
         case 51 -> {
            byte var66 = 4;
            yield var66;
         }
         case 52 -> {
            byte var67 = 38;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 1;
            yield var69;
         }
         case 55 -> {
            byte var70 = 32;
            yield var70;
         }
         case 56 -> {
            byte var71 = 3;
            yield var71;
         }
         case 57 -> {
            byte var72 = 43;
            yield var72;
         }
         case 58 -> {
            byte var73 = 54;
            yield var73;
         }
         case 59 -> {
            byte var74 = 58;
            yield var74;
         }
         case 60 -> {
            byte var75 = 15;
            yield var75;
         }
         case 61 -> {
            byte var76 = 35;
            yield var76;
         }
         case 62 -> {
            byte var77 = 55;
            yield var77;
         }
         default -> 14;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "\u001e}FY\u001b\u0005\u0015rW\u0016f\u001d\u0006u^_";
      p[1] = "WfRl\u001aj\\iC#{dWbGy";
      p[2] = boolean.class;
      q[2] = "java/lang/Boolean";
      p[3] = "a9\n\u0006\u0019bw9\u000f\\\nu`r\fZ\u0006aq5\u001bMMt\\";
      p[4] = "edx\u0014VP\u0010Ds\u001bG\u001fqJx\u0010CE\u0005";
      p[5] = int.class;
      q[5] = "java/lang/Integer";
      p[6] = "xjZb'#nj_844y!\\>8 hfK)s6F";
      p[7] = "\bq\nVh*}Q\u0001Yye\u001c_\nR}?h";
      p[8] = void.class;
      q[8] = "java/lang/Void";
      p[9] = "iV\"bweiV5>{js\u001d5 {\u007ftlax,";
      p[10] = "BP1\u0005\u00071BP&Y\u000b>X\u001b&G\u000b+_jt\u001cSa";
      p[11] = "d\u000fDT#xd\u000fS\b/w~DS\u0016/by5\u0003K~";
      p[12] = "\u0003afC% \u0003aq\u001f)/\u0019*q\u0001):\u001e[&^\u007f";
      p[13] = "Q\u000fsP}NG\u000fv\nnYPDu\fbMA\u0003b\u001b)]Z";
      p[14] = "vb\t@I\u0010\u0003B\u0002OX_bL\tD\\\u0005\u0016";
      p[15] = "h$#=$_\u001d\u0004(25\u0010|\n#91J\b";
      p[16] = "@W!\u0018\u0013\u0001VW$B\u0000\u0016A\u001c'D\f\u0002P[0SG\u0010a";
      p[17] = "ff\u0004'8<pf\u0001}++g-\u0002{'?vj\u0015ll(S";
      p[18] = ";ikqOSNI`~^\u001c/GkuZF[";
      p[19] = "grQ\u001434qrTN #f9WH,7w~@_g'o";
      p[20] = "&t\u0006GrCST\rHc\f2Z\u0006CgVF";
      p[21] = "S\u0003\u0018\f@DE\u0003\u001dVSSRH\u001eP_GC\u000f\tG\u0014Pq";
      p[22] = "\fZ0h87\u0007U!'P7\tZ2";
      p[23] = float.class;
      q[23] = "java/lang/Float";
      p[24] = ";h%\nv\u0004;h2Vz\u000b!#2Hz\u001e&R`\u0016-U";
      p[25] = "f#K~./\u0013\u0003@q?`r\rKz;:\u0006";
      p[26] = "\u0011Fp0n\u0018\u001aIa\u007f\r\u0015\u000fDn\u00148\u0017\u001eWr8/\u001a";
      p[27] = "whtAk(\u0002H\u007fNzgcFtE~=\u0017";
      p[28] = "524)\"\u0012@\u0012?&3]!\u001c4-7\u0007U";
      p[29] = "~\u0001l\"e-~\u0001{~i\"dJ{`i7c;);1v";
      p[30] = "y!-;=,y!:g1#cj:y16d\u001bh-`w";
      p[31] = "\\OB`KfBGX/6vB";
      p[32] = "\u007fX|\b3)iXyR >~\u0013zT,*oTmCg=W";
      p[33] = "0\u0013X^\u0012\u007fE3SQ\u00030$=XZ\u0007jP";
      p[34] = "\u001d\u001fu-\u0003\rh?~\"\u0012B\t1u)\u0016\u0018}";
      p[35] = "6\u0015K\u000fw.6\u0015\\S{!,^\\M{4+/\u000e\u0017,v";
      p[36] = "od`\n9\u0007d '\u0013E\u0016\nx&\u0014&\u0011:n'\f{|4 4\u0010>\u001a;!=EE";
      p[37] = "\u001c_\u0000^|p\u000bX\\K\u0017kv\b\u0003I&?\tSD\u0007)\u0001";
      p[38] = "[D\u001a<bg\u001cFL1\u0002h\bG\u001d$nZ^\u0002@\u007f2\r\u0002Y\u001d\u007f\u007fq\u0003QL \u0002";
      p[39] = "uz\u0014$>Q;\u007f\t_=\u0001>v.81\u0005E*\\-lV:q\u001bcch";
      p[40] = "Za#l9SXs bBS\b}xl.aZ0 :BU\u000fpce'\u0007\u001dq\"\u000b";
      p[41] = ".L\u001d\u0000*\u001a%\u000e\u001d]\u0017E\u007f\u001eFV@\u0012!N\u001f:'[#\u001cOJlGe\b";
      p[42] = "{H5C\u000e\u00145Lz\\a\u0002JL7A\u0002\u0006zZ6Y_kt\u0014%E\u001a\r{\u0015,\u0010a";
      p[43] = "u\u001bsuDak\u001as>>a~'doSh/Ktj\u0004\u0006u\u001bsuDak\u001as>>";
      p[44] = "\u0006Vf9$2\r\u0014fd\u0019f[\u00159duT\u000fTg2\u0019:J\u0013'mz~]\u0011&\u0003";
      p[45] = "p g.\u0002Jg';;iP\u001awd9X\u0005e,#wW;";
      p[46] = "\u000b-B\u0012\u0016@Wv\u0002\u0013hBg-B\u000e\u000bDW;C\u0016V)^7D\u0010\u0006J\u001a F\u0011h";
      p[47] = "@Li\u001b[I\u0010\t8\u000b)E.\u000bn\u0014G\u0013B\u001bkC)";
      p[48] = "3\b\\Vf[8J\\\u000b[\u0004bZ\u0007\u0000\fS<\r_le\u0015dH\u0003\u0006\"\u00172E";
      p[49] = "7>&\u0014tdvas\u0007O6\rfk\u0005,2=pj\u001dq_3>y\u000149<?pTO";
      p[50] = "E@(\u000f\u00023UE\u007faP&BB!\u001a=%TF+^Q5Q\u0011EXA%AE&\u001cV'@+";
      p[51] = "CbZ\tmREdQ\u001e\u0007\u0000\u007fhT\u0014d\u0004O~U\f9iC7ZE9\u0016\u0018p\u0014J\u0007";
      p[52] = " /\u0000L\u0014#&)\u000b[~q\u001c\"\u0017I\u001ecd&HJC\u0018}&\nQ\u0005`yy\t\f~";
      p[53] = "|ay[a\u00132e6D\u000e\u0005Me{Ym\u0001}szA0lq:u\b0\u0013*};\u0007\u000e";
      p[54] = "\u0016\u0001\u0012B{&X\u0004\u000f9uf[\u0004\u0007B\u0018eM\u0000\r\u0006tuHWc\u0000deX\u0003\u0000DsgYm";
      p[55] = "rC62c\u00073\u001cc!XUH\u001b{#;Qx\rz;f<q\u0001}=6_5\u0016\u007f<X";
      p[56] = "\u0007\"\u0002enU\u0001$\tr\u0004\f;(\fxg\u0003\u000b>\r`:n\u0005p\u001e|\u007f\b\nq\u0017)\u0004";
      p[57] = "\u0003\u0000xC5\u001dD\u0002.NU\u0012P\u0003\u007f[9 \u0003G#\u0003UH]DxG0JOGv<";
      p[58] = "{Djt?C5@%kPVJ@hv3QzVinn<t\u0018zr+Z{\u0019s'P";
      p[59] = "q&F4]=~s\u0017v'&\u001axZoD\"*n[w\u0019O$ Hk\\)+!A>'";
      p[60] = "\u001b\u0001~+\u000ew\u0019O(\"d\"\u001eS&w3pN\u0006s+d/\u0015O9u\u0001}\u0007Nx";
      p[61] = "\u0015\u0012]}\u0013U\u0014\u001a\f\"nL\u001f\f]&\u0002~OL\u0006qn\u0015K\u0002\f\u007f\u0011N\fL\u0003AQII\u0017F$S[J\u0019=";
      p[62] = "\u000e\r\t\u0018(sQ\n\u0011\u0014\u0013~\u0004\n\u0012\u0016My\u0004\u0010\u0016j|(\u000bR\u0018\u0013ku\u001e\r{";
      p[63] = "W-0V_\u0003U%kA3\u0007V)mAdT\u0007|9-S\u0000\u000e?eGQ\bU(";
      p[64] = "+\u0001$J\u001bg-\u0007/]q5\u0017\u000b*W\u00121'\u001d+OO\\.\u0011,I\u001f?j\u0006.Hq";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(77141731794446L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(77141731794446L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(77141731794446L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 213;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 105;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 84;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 226;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 86;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 210;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 213;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 105;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 84;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/eZ_C0267",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/eZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("()Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/eZ_C0267", "lambda$onTick$1", "()V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
