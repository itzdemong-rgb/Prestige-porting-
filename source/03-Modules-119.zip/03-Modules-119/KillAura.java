package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PostAttackEvent;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.client.management.SelectedSlotTracker;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket.Action;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class KillAura extends Module implements RotationSource {
   public static KillAura a;
   private FloatSetting c;
   private BooleanSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private ModeSetting h;
   private MinMaxSetting i;
   private FloatSetting j;
   private FloatSetting k;
   private FloatSetting l;
   private ModeSetting m;
   private MultiModeSetting n;
   private BooleanSetting o;
   private FloatSetting p;
   private ColorSetting q;
   private ElapsedTimer r;
   private ElapsedTimer s;
   private Entity t;
   private static final String[] u;
   private static final double[] v;
   private static final long w = 30414666635747L;
   private static final String[] x;
   private static final String[] y;
   private static final Map z = new HashMap(13);
   private static final long[] A;
   private static final Integer[] B;
   private static final Map C;
   private static final Object[] D = new Object[183];
   private static final String[] E = new String[183];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public KillAura() {
      super();
      long var10001 = 91330706062610L ^ 55087416642107L;
      var10001 = 91330706062610L ^ 130483649265234L;
      var10001 = 91330706062610L ^ 60451011191933L;
      var10001 = 91330706062610L ^ 84002127482821L;

      this.r = new ElapsedTimer(106698256430889L);
      this.s = new ElapsedTimer(106698256430889L);
      a = this;
      MinMaxSetting var10000 = this.i;
      Object[] var12 = new Object[]{invokeBinding1(this), 112057026795887L};
      MinMaxSetting var11 = var10000;
      var11.aReturningMinMaxSetting(var12);
      ColorSetting var17 = this.q;
      Object[] var14 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var13 = var17;
      var13.aReturningColorSetting(var14);
      FloatSetting var18 = this.p;
      Object[] var16 = new Object[]{invokeBinding3(this), 34595201528535L};
      FloatSetting var15 = var18;
      var15.aReturningFloatSetting(var16);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      int var434;

      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64472539066513L;
      long var6 = var2 ^ 113431327531997L;
      long var8 = var2 ^ 19256669677348L;
      long var10 = var2 ^ 55505956538536L;
      long var12 = var2 ^ 64813883264283L;
      long var14 = var2 ^ 73608466808436L;
      long var16 = var2 ^ 30352829501857L;
      long var18 = var2 ^ 131509882785148L;
      long var20 = var2 ^ 16060586437481L;
      long var22 = var2 ^ 136327255761257L;
      long var24 = var2 ^ 97219249999501L;
      long var26 = var2 ^ 129629229612813L;
      long var28 = var2 ^ 29159961624672L;
      long var30 = var2 ^ 77379818547405L;
      long var32 = var2 ^ 101783648619701L;
      long var34 = var2 ^ 100729554575240L;
      long var36 = var2 ^ 50331604023260L;
      long var38 = var2 ^ 80806474706077L;
      int var40 = Event.bReturningInt();
      MinecraftClient var48 = b;
      ClientPlayerEntity var49 = var48.player;
      int var10000 = (((var49.isUsingItem()) ? 1 : 0));
      int var304 = var40;
      boolean var303 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var232 = var303;
      boolean var231 = var303;
      if (var304 == 0) {
         boolean var305 = var231;
         if (var305) {
            return null;
         }

         var232 = AutoObbyCrystal.R;
      }

      int var307 = var40;
      boolean var306 = var232;
      boolean var234 = var306;
      boolean var233 = var306;
      if (var307 == 0) {
         boolean var308 = var233;
         if (var308) {
            return null;
         }

         RotationManager var439 = Prestige.o;
         Object[] var55 = new Object[0];
         RotationManager var54 = var439;
         var234 = var54.fReturningBoolean(var55);
      }

      Object var242;
      label349: {
         int var310 = var40;
         boolean var309 = var234;
         boolean var237 = var309;
         boolean var235 = var309;
         if (var310 == 0) {
            boolean var311 = var235;
            if (var311) {
               return null;
            }

            MinecraftClient var58 = b;
            ClientPlayerEntity var59 = var58.player;
            ItemStack var440 = var59.getMainHandStack();
            int var313 = var40;
            ItemStack var312 = var440;
            var242 = var312;
            ItemStack var236 = var312;
            if (var313 != 0) {
               break label349;
            }

            Object[] var60 = new Object[]{var236, var36};
            boolean var314 = InventoryUtil.aReturningBoolean(var60);
            var237 = var314;
         }

         boolean var315 = var237;
         if (!var315) {
            MinecraftClient var62 = b;
            ClientPlayerEntity var63 = var62.player;
            ItemStack var64 = var63.getMainHandStack();
            Item var441 = var64.getItem();
            int var317 = var40;
            Item var316 = var441;
            var242 = var316;
            Item var238 = var316;
            if (var317 != 0) {
               break label349;
            }

            Item var318 = var238;
            Item var239 = var318;
            boolean var319 = var239 instanceof AxeItem;
            if (!var319) {
               BooleanSetting var67 = this.g;
               Boolean var442 = (Boolean)var67.aReturningObject();
               int var321 = var40;
               Boolean var320 = var442;
               var242 = var320;
               Boolean var240 = var320;
               if (var321 != 0) {
                  break label349;
               }

               Boolean var322 = var240;
               Boolean var241 = var322;
               Boolean var69 = var241;
               boolean var323 = var69;
               if (var323) {
                  return null;
               }
            }
         }

         ModeSetting var72 = this.h;
         var242 = var72.aReturningObject();
      }

      int var248;
      String var42 = (String)var242;
      // String var73 = var42;
      var10000 = var73.hashCode();
      int var325 = var40;
      int var324 = var10000;
      var248 = var324;
      int var243 = var324;
      label328:
      if (var325 == 0) {
         int var326 = var243;
         switch (var326) {
            case 1897755483:
               short var10001 = 2869;
               long var10002 = 4287389749198357474L ^ var2;
               String var76 = "Vanilla";
               String var75 = var42;
               byte var444 = ((byte)((var75.equals(var76)) ? 1 : 0));
               int var328 = var40;
               byte var327 = var444;
               var248 = var327;
               byte var244 = var327;
               if (var328 != 0) {
                  break label328;
               }

               byte var329 = var244;
               byte var245 = var329;
               byte var330 = var245;
               if (var330 == 0) {
                  break;
               }

               var43 = 0;
               int var331 = var40;
               if (var331 == 0) {
                  break;
               }
            case 78727453:
               short var468 = 6321;
               long var471 = 5962532147430887530L ^ var2;
               String var80 = "Range";
               String var79 = var42;
               byte var445 = ((byte)((var79.equals(var80)) ? 1 : 0));
               int var333 = var40;
               byte var332 = var445;
               var248 = var332;
               byte var246 = var332;
               if (var333 != 0) {
                  break label328;
               }

               byte var334 = var246;
               byte var247 = var334;
               byte var335 = var247;
               if (var335 != 0) {
                  var43 = 1;
               }
         }

         var248 = var43;
      }

      int var336 = var248;
      float var41;
      switch (var336) {
         case 0:
            var41 = 1.0F;
            int var337 = var40;
            if (var337 == 0) {
               break;
            }
         case 1:
            MinMaxSetting var446 = this.i;
            Object[] var84 = new Object[]{var4};
            MinMaxSetting var83 = var446;
            var41 = var83.fReturningFloat(var84) / 100.0F;
            int var338 = var40;
            if (var338 == 0) {
               break;
            }
         default:
            MinMaxSetting var85 = this.i;
            var41 = var85.aReturningVoid() / 100.0F;
      }

      int var257;
      label366: {
         int var256;
         ElapsedTimer var447 = this.r;
         Object[] var10004 = new Object[]{null, var14};
         var10004[0] = 100.0F;
         Object[] var87 = var10004;
         ElapsedTimer var86 = var447;
         int var448 = (((var86.aReturningBoolean(var87)) ? 1 : 0));
         int var340 = var40;
         byte var339 = (byte)var448;
         var256 = var339;
         byte var249 = var339;
         label291:
         if (var340 == 0) {
            byte var341 = var249;
            if (var341 != 0) {
               MinecraftClient var89 = b;
               float var91 = 0.0F;
               ClientPlayerEntity var90 = var89.player;
               float var479;
               var448 = (var479 = var90.getAttackCooldownProgress(var91) - var41) == 0.0F ? 0 : (var479 < 0.0F ? -1 : 1);
               int var343 = var40;
               int var342 = var448;
               var256 = var342;
               int var250 = var342;
               if (var343 != 0) {
                  break label291;
               }

               int var344 = var250;
               int var251 = var344;
               int var345 = var251;
               label296:
               if (var345 >= 0) {
                  label354: {
                     MinecraftClient var94 = b;
                     ClientPlayerEntity var95 = var94.player;
                     byte var450 = ((byte)((var95.isOnGround()) ? 1 : 0));
                     int var347 = var40;
                     byte var346 = var450;
                     int var254 = var346;
                     byte var252 = var346;
                     if (var347 == 0) {
                        byte var348 = var252;
                        byte var253 = var348;
                        byte var349 = var253;
                        if (var349 != 0) {
                           break label354;
                        }

                        MinecraftClient var98 = b;
                        ClientPlayerEntity var99 = var98.player;
                        double var480;
                        int var350 = (var480 = var99.fallDistance - 0.0) == 0.0 ? 0 : (var480 < 0.0 ? -1 : 1);
                        var254 = var350;
                     }

                     int var352 = var40;
                     int var351 = var254;
                     var256 = var351;
                     int var255 = var351;
                     if (var352 != 0) {
                        break label291;
                     }

                     int var353 = var255;
                     if (var353 <= 0) {
                        break label296;
                     }
                  }

                  var257 = 0;
                  break label366;
               }
            }

            var256 = 1;
         }

         int var354 = var256;
         var257 = var354;
      }

      KillAura var271;
      label355: {
         Entity var270;
         label356: {
            label283: {
               KillAura var268;
               label357: {
                  boolean var265;
                  label281: {
                     var434 = var257;
                     int var356 = var40;
                     Entity var355 = this.t;
                     Object var264 = var355;
                     Entity var258 = var355;
                     if (var356 == 0) {
                        Entity var357 = var258;
                        if (var357 != null) {
                           int var359 = var40;
                           Entity var358 = this.t;
                           Entity var261 = var358;
                           Entity var259 = var358;
                           if (var359 == 0) {
                              Entity var360 = var259;
                              Entity var260 = var360;
                              Entity var104 = var260;
                              boolean var361 = var104.isAlive();
                              if (!var361) {
                                 this.t = null;
                                 return null;
                              }

                              var261 = this.t;
                           }

                           Entity var107 = var261;
                           Vec3d var435 = var107.getEyePos();
                           MinecraftClient var108 = b;
                           Vec3d var109 = var435;
                           Vec3d var110 = var435;
                           Vec3d var111 = var435;
                           double var117 = var111.z;
                           double var115 = var110.y;
                           double var113 = var109.x;
                           ClientPlayerEntity var112 = var108.player;
                           double var119 = var112.squaredDistanceTo(var113, var115, var117);
                           double var481;
                           int var362 = (var481 = Math.sqrt(var119) - 5.0) == 0.0 ? 0 : (var481 < 0.0 ? -1 : 1);
                           if (var362 > 0) {
                              this.t = null;
                           }

                           Object[] var122 = new Object[]{var435, var16};
                           Rotation var44 = RotationUtil.aReturningdx_C0210(var122);
                           MinecraftClient var123 = b;
                           ClientPlayerEntity var124 = var123.player;
                           float var472 = var124.getYaw();
                           MinecraftClient var125 = b;
                           ClientPlayerEntity var126 = var125.player;
                           Rotation var451 = new Rotation(var472, var126.getPitch());
                           FloatSetting var127 = this.k;
                           Float var128 = (Float)var127.aReturningObject();
                           var472 = var128 * 2.0F;
                           Object[] var10005 = new Object[]{null, null, null, var24};
                           var10005[2] = var472;
                           var10005[1] = var44;
                           var10005[0] = var451;
                           Object[] var129 = var10005;
                           boolean var452 = RotationUtil.fReturningBoolean(var129);
                           int var364 = var40;
                           boolean var363 = var452;
                           var265 = var363;
                           boolean var262 = var363;
                           if (var364 != 0) {
                              break label281;
                           }

                           boolean var365 = var262;
                           if (!var365) {
                              this.t = null;
                           }
                        }

                        int var367 = var40;
                        KillAura var366 = this;
                        var268 = var366;
                        KillAura var263 = var366;
                        if (var367 != 0) {
                           break label357;
                        }

                        BooleanSetting var132 = var263.d;
                        Object var368 = var132.aReturningObject();
                        var264 = var368;
                     }

                     Boolean var134 = (Boolean)var264;
                     var265 = var134;
                  }

                  boolean var369 = var265;
                  if (var369) {
                     int var371 = var40;
                     Entity var370 = this.t;
                     var270 = var370;
                     Entity var266 = var370;
                     if (var371 != 0) {
                        break label356;
                     }

                     Entity var372 = var266;
                     Entity var267 = var372;
                     Entity var373 = var267;
                     if (var373 != null) {
                        break label283;
                     }
                  }

                  var268 = this;
               }

               BooleanSetting var137 = this.f;
               Boolean var138 = (Boolean)var137.aReturningObject();
               boolean var474 = var138;
               FloatSetting var139 = this.l;
               Float var140 = (Float)var139.aReturningObject();
               float var10003 = var140;
               Object[] var10006 = new Object[]{null, null, var10};
               var10006[1] = var10003;
               var10006[0] = var474;
               Object[] var142 = var10006;
               KillAura var141 = this;
               var268.t = var141.aReturningEntity(var142);
            }

            int var375 = var40;
            KillAura var374 = this;
            var271 = var374;
            KillAura var269 = var374;
            if (var375 != 0) {
               break label355;
            }

            Entity var376 = var269.t;
            var270 = var376;
         }

         Entity var377 = var270;
         if (var377 == null) {
            return null;
         }

         var271 = this;
      }

      int var275;
      Rotation var437;
      Object[] var146 = new Object[]{this.t, var20};
      KillAura var145 = var271;
      Vec3d var436 = var145.aReturningVec3d(var146);
      RotationManager var453 = Prestige.o;
      Object[] var148 = new Object[]{var436, var30};
      RotationManager var147 = var453;
      var437 = var147.aReturningdx_C0210(var148);
      BooleanSetting var149 = this.e;
      Boolean var150 = (Boolean)var149.aReturningObject();
      int var454 = ((((java.lang.Boolean)(var150)).booleanValue() ? 1 : 0));
      int var379 = var40;
      byte var378 = (byte)var454;
      var275 = var378;
      byte var272 = var378;
      label257:
      if (var379 == 0) {
         byte var380 = var272;
         if (var380 != 0) {
            Object[] var153 = new Object[0];
            Rotation var152 = var437;
            var454 = (((var152.aReturningBoolean(var153)) ? 1 : 0));
            int var382 = var40;
            byte var381 = ((byte)(var454));
            var275 = var381;
            byte var273 = var381;
            if (var382 != 0) {
               break label257;
            }

            byte var383 = var273;
            byte var274 = var383;
            byte var384 = var274;
            if (var384 == 0) {
               Object[] var156 = new Object[]{var437, var436, var32};
               var437 = RotationUtil.dReturningdx_C0210(var156);
            }
         }

         Object[] var158 = new Object[0];
         Rotation var157 = var437;
         float var456 = var157.aReturningFloat(var158);
         MinecraftClient var159 = b;
         ClientPlayerEntity var160 = var159.player;
         float var457 = var456 - var160.getYaw();
         FloatSetting var161 = this.k;
         Float var162 = (Float)var161.aReturningObject();
         float var482;
         var275 = (var482 = var457 - var162 * 2.0F) == 0.0F ? 0 : (var482 < 0.0F ? -1 : 1);
      }

      int var386 = var40;
      int var385 = var275;
      int var277 = var385;
      int var276 = var385;
      if (var386 == 0) {
         int var387 = var276;
         if (var387 > 0) {
            return null;
         }

         Object[] var165 = new Object[0];
         Rotation var164 = var437;
         float var458 = var164.aReturningFloat(var165);
         MinecraftClient var166 = b;
         ClientPlayerEntity var167 = var166.player;
         float var459 = var458 - var167.getYaw();
         FloatSetting var168 = this.k;
         Float var169 = (Float)var168.aReturningObject();
         float var483;
         int var388 = (var483 = var459 - -var169 * 2.0F) == 0.0F ? 0 : (var483 < 0.0F ? -1 : 1);
         var277 = var388;
      }

      int var390 = var40;
      int var389 = var277;
      int var279 = var389;
      int var278 = var389;
      if (var390 == 0) {
         int var391 = var278;
         if (var391 < 0) {
            return null;
         }

         MinecraftClient var173 = b;
         Entity var175 = this.t;
         ClientPlayerEntity var174 = var173.player;
         var279 = (((var174.canSee(var175)) ? 1 : 0));
      }

      int var393 = var40;
      int var392 = var279;
      int var281 = var392;
      int var280 = var392;
      if (var393 == 0) {
         int var394 = var280;
         if (var394 == 0) {
            return null;
         }

         Object[] var178 = new Object[]{this.t, var22};
         var281 = (((BlockUtil.aReturningBoolean(var178)) ? 1 : 0));
      }

      int var396 = var40;
      int var395 = var281;
      int var283 = var395;
      int var282 = var395;
      if (var396 == 0) {
         int var397 = var282;
         if (var397 != 0) {
            return null;
         }

         Object[] var182 = new Object[]{this.t, var26};
         KillAura var181 = this;
         double var460 = var181.aReturningDouble(var182);
         FloatSetting var183 = this.c;
         Float var184 = (Float)var183.aReturningObject();
         double var484;
         var283 = (var484 = var460 - var184.floatValue()) == 0.0 ? 0 : (var484 < 0.0 ? -1 : 1);
      }

      int var399 = var40;
      int var398 = var283;
      int var285 = var398;
      int var284 = var398;
      if (var399 == 0) {
         int var400 = var284;
         if (var400 > 0) {
            return null;
         }

         var285 = var434;
      }

      int var402 = var40;
      int var401 = var285;
      int var287 = var401;
      int var286 = var401;
      if (var402 == 0) {
         int var403 = var286;
         if (var403 != 0) {
            return null;
         }

         Object[] var190 = new Object[0];
         Rotation var189 = var437;
         var287 = (((var189.aReturningBoolean(var190)) ? 1 : 0));
      }

      int var405 = var40;
      int var404 = var287;
      int var289 = var404;
      int var288 = var404;
      if (var405 == 0) {
         int var406 = var288;
         if (var406 != 0) {
            return var437;
         }

         FloatSetting var193 = this.j;
         Float var194 = (Float)var193.aReturningObject();
         float var485;
         var289 = (var485 = var194 - 0.0F) == 0.0F ? 0 : (var485 < 0.0F ? -1 : 1);
      }

      int var408 = var40;
      int var407 = var289;
      int var290 = var407;
      label232:
      if (var408 == 0) {
         int var409 = var290;
         if (var409 > 0) {
            Object[] var477 = new Object[]{null, null, var38};
            var477[1] = 100.0F;
            var477[0] = 0.0F;
            Object[] var196 = var477;
            float var461 = RandomUtil.aReturningFloat(var196);
            FloatSetting var197 = this.j;
            Float var198 = (Float)var197.aReturningObject();
            float var486;
            var454 = (var486 = var461 - var198) == 0.0F ? 0 : (var486 < 0.0F ? -1 : 1);
            int var411 = var40;
            int var410 = var454;
            int var291 = var410;
            if (var411 != 0) {
               break label232;
            }

            int var412 = var291;
            int var292 = var412;
            int var413 = var292;
            if (var413 < 0) {
               ElapsedTimer var464 = this.r;
               Object[] var202 = new Object[]{var28};
               ElapsedTimer var201 = var464;
               var201.aReturningVoid(var202);
               return null;
            }
         }

         PostAttackEvent var463 = new PostAttackEvent();
         Object[] var205 = new Object[]{var8};
         PostAttackEvent var204 = var463;
         boolean var293 = var204.bReturningBoolean(var205);
      }

      Object var302;
      Entity var46 = this.t;
      int var415 = var40;
      Entity var414 = var46;
      var302 = var414;
      Entity var294 = var414;
      label224:
      if (var415 == 0) {
         boolean var416 = var294 instanceof PlayerEntity;
         if (var416) {
            PlayerEntity var45 = (PlayerEntity)var46;
            int var418 = var40;
            PlayerEntity var417 = var45;
            var302 = var417;
            PlayerEntity var295 = var417;
            if (var418 != 0) {
               break label224;
            }

            Object[] var207 = new Object[]{var295, var6};
            boolean var419 = EntityUtil.aReturningBoolean(var207);
            label220:
            if (var419) {
               ModeSetting var209 = this.m;
               String var438 = (String)var209.aReturningObject();
               short var469 = 21644;
               long var475 = 7513313202637659217L ^ var2;
               String var211 = "Skip";
               String var210 = var438;
               boolean var465 = var210.equals(var211);
               int var421 = var40;
               boolean var420 = var465;
               boolean var297 = var420;
               boolean var296 = var420;
               if (var421 == 0) {
                  boolean var422 = var296;
                  if (var422) {
                     return null;
                  }

                  var469 = 4261;
                  var475 = 7506243062899153020L ^ var2;
                  String var215 = "Prefer Axe";
                  String var214 = var438;
                  var297 = var214.equals(var215);
               }

               int var424 = var40;
               boolean var423 = var297;
               boolean var301 = var423;
               boolean var298 = var423;
               if (var424 == 0) {
                  boolean var425 = var298;
                  if (!var425) {
                     break label220;
                  }

                  MinecraftClient var217 = b;
                  int var427 = var40;
                  ClientPlayerEntity var426 = var217.player;
                  var302 = var426;
                  ClientPlayerEntity var299 = var426;
                  if (var427 != 0) {
                     break label224;
                  }

                  ClientPlayerEntity var428 = var299;
                  ClientPlayerEntity var300 = var428;
                  ClientPlayerEntity var219 = var300;
                  ItemStack var220 = var219.getMainHandStack();
                  boolean var429 = var220.getItem() instanceof AxeItem;
                  var301 = var429;
               }

               boolean var430 = var301;
               if (!var430) {
                  Object[] var223 = new Object[]{var12};
                  KillAura var222 = this;
                  int var47 = var222.dReturningInt(var223);
                  int var431 = var40;
                  if (var431 != 0) {
                     return var437;
                  }

                  // int var432 = var47;
                  if (var432 != var433) {
                     SelectedSlotTracker var466 = Prestige.t;
                     Object[] var478 = new Object[]{null, var18};
                     var478[0] = var47;
                     Object[] var226 = var478;
                     SelectedSlotTracker var225 = var466;
                     var225.aReturningVoid(var226);
                  }
               }
            }
         }

         var302 = this.t;
      }

      Object[] var228 = new Object[]{var302, var34};
      ItemUseUtil.aReturningVoid(var228);
      ElapsedTimer var467 = this.r;
      Object[] var230 = new Object[]{var28};
      ElapsedTimer var229 = var467;
      var229.aReturningVoid(var230);
      return var437;
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 30414666635747L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      byte var15;
      while (true) {
         short var10001 = 5337;
         long var10002 = 2643972470194059330L ^ var2;
         byte var17 = 8;
         int var16 = var5;
         if (var16 <= var17) {
            MinecraftClient var6 = b;
            ClientPlayerEntity var7 = var6.player;
            PlayerInventory var26 = var7.getInventory();
            int var9 = var5;
            PlayerInventory var8 = var26;
            ItemStack var10 = var8.getStack(var9);
            byte var27 = ((byte)((var10.getItem() instanceof AxeItem) ? 1 : 0));
            int var19 = var4;
            byte var18 = var27;
            var15 = var18;
            byte var11 = var18;
            if (var19 == 0) {
               break;
            }

            int var21 = var4;
            byte var20 = var11;
            int var14 = var20;
            byte var12 = var20;
            if (var21 == 0) {
               return var14;
            }

            byte var22 = var12;
            byte var13 = var22;
            byte var23 = var13;
            if (var23 != 0) {
               var14 = var5;
               return var14;
            }

            var5++;
            int var24 = var4;
            if (var24 != 0) {
               continue;
            }
         }

         var15 = -1;
         break;
      }

      return var15;
   }

   private Entity aReturningEntity(Object[] var1) {
      boolean var5 = (Boolean)var1[0];
      float var4 = (Float)var1[1];
      long var2 = (Long)var1[2];
      var2 = 30414666635747L ^ var2;
      long var6 = var2 ^ 87326520638447L;
      long var8 = var2 ^ 55870132087514L;
      long var10 = var2 ^ 53924182574330L;
      long var12 = var2 ^ 125041889550278L;
      int var10000 = Event.cReturningInt();
      Entity var15 = null;
      double var16 = Double.MAX_VALUE;
      MinecraftClient var25 = b;
      ClientPlayerEntity var26 = var25.player;
      float var10003 = var26.getYaw();
      MinecraftClient var27 = b;
      ClientPlayerEntity var28 = var27.player;
      Rotation var18 = new Rotation(var10003, var28.getPitch());
      MinecraftClient var29 = b;
      ClientWorld var30 = var29.world;
      Iterable var31 = var30.getEntities();
      Iterator var19 = var31.iterator();
      int var14 = var10000;

      Entity var97;
      while (true) {
         Iterator var32 = var19;
         boolean var98 = var32.hasNext();
         if (var98) {
            Iterator var33 = var19;
            Entity var20 = (Entity)var33.next();
            int var100 = var14;
            Entity var99 = var20;
            var97 = var99;
            Entity var74 = var99;
            if (var100 == 0) {
               break;
            }

            int var102 = var14;
            Entity var101 = var74;
            Entity var77 = var101;
            Entity var75 = var101;
            if (var102 != 0) {
               Entity var103 = var75;
               Entity var76 = var103;
               MinecraftClient var35 = b;
               ClientPlayerEntity var105 = var35.player;
               Entity var104 = var76;
               if (var104 == var105) {
                  continue;
               }

               var77 = var20;
            }

            Entity var38 = var77;
            int var140 = (((var38.isAlive()) ? 1 : 0));
            int var107 = var14;
            boolean var106 = dev.prestige.recovery.SourceSupport.asBoolean(var140);
            boolean var79 = var106;
            boolean var78 = var106;
            if (var107 != 0) {
               boolean var108 = var78;
               if (!var108) {
                  continue;
               }

               var79 = var5;
            }

            boolean var83;
            int var110 = var14;
            boolean var109 = var79;
            var83 = var109;
            boolean var80 = var109;
            label103:
            if (var110 != 0) {
               boolean var111 = var80;
               if (var111) {
                  var140 = (((var20 instanceof PlayerEntity) ? 1 : 0));
                  int var113 = var14;
                  boolean var112 = ((((int)(var140) & 1) != 0));
                  var83 = var112;
                  boolean var81 = var112;
                  if (var113 == 0) {
                     break label103;
                  }

                  boolean var114 = var81;
                  boolean var82 = var114;
                  boolean var115 = var82;
                  if (!var115) {
                     continue;
                  }
               }

               PlayerValidationTracker var142 = Prestige.i;
               Object[] var44 = new Object[]{var20, var6};
               PlayerValidationTracker var43 = var142;
               var83 = var43.aReturningBoolean(var44);
            }

            Entity var87;
            label118: {
               int var117 = var14;
               boolean var116 = var83;
               boolean var86 = var116;
               boolean var84 = var116;
               if (var117 != 0) {
                  boolean var118 = var84;
                  if (!var118) {
                     continue;
                  }

                  int var120 = var14;
                  Entity var119 = var20;
                  var87 = var119;
                  Entity var85 = var119;
                  if (var120 == 0) {
                     break label118;
                  }

                  boolean var121 = var85 instanceof PlayerEntity;
                  var86 = var121;
               }

               boolean var122 = var86;
               if (var122) {
                  SocialsManager var143 = Prestige.g;
                  Entity var47 = var20;
                  Text var48 = var47.getName();
                  Object[] var50 = new Object[]{var48.getString(), var10};
                  SocialsManager var49 = var143;
                  boolean var123 = var49.aReturningBoolean(var50);
                  if (var123) {
                     continue;
                  }
               }

               var87 = var20;
            }

            Entity var53 = var87;
            Vec3d var21 = var53.getEyePos();
            MinecraftClient var54 = b;
            Vec3d var55 = var21;
            Vec3d var56 = var21;
            Vec3d var57 = var21;
            double var63 = var57.z;
            double var61 = var56.y;
            double var59 = var55.x;
            ClientPlayerEntity var58 = var54.player;
            double var22 = var58.squaredDistanceTo(var59, var61, var63);
            double var65 = var22;
            double var148;
            var140 = (var148 = Math.sqrt(var65) - 5.0) == 0.0 ? 0 : (var148 < 0.0 ? -1 : 1);
            int var125 = var14;
            int var124 = var140;
            int var89 = var124;
            int var88 = var124;
            if (var125 != 0) {
               int var126 = var88;
               if (var126 > 0) {
                  continue;
               }

               float var149;
               var89 = (var149 = var4 - 360.0F) == 0.0F ? 0 : (var149 < 0.0F ? -1 : 1);
            }

            label88: {
               double var95;
               label120: {
                  int var94;
                  int var128 = var14;
                  int var127 = var89;
                  var94 = var127;
                  int var90 = var127;
                  label86:
                  if (var128 != 0) {
                     int var129 = var90;
                     if (var129 < 0) {
                        Vec3d var69 = var21;
                        float var145 = (float)var69.x;
                        Vec3d var70 = var21;
                        float var10001 = (float)var70.y;
                        Vec3d var71 = var21;
                        float var10002 = (float)var71.z;
                        Object[] var10005 = new Object[]{null, null, null, var8};
                        var10005[2] = var10002;
                        var10005[1] = var10001;
                        var10005[0] = var145;
                        Object[] var72 = var10005;
                        Rotation var24 = RotationUtil.bReturningdx_C0210(var72);
                        var10005 = new Object[]{null, null, null, var12};
                        var10005[2] = var4;
                        var10005[1] = var24;
                        var10005[0] = var18;
                        Object[] var73 = var10005;
                        byte var146 = ((byte)((RotationUtil.fReturningBoolean(var73)) ? 1 : 0));
                        int var131 = var14;
                        byte var130 = var146;
                        var94 = var130;
                        byte var91 = var130;
                        if (var131 == 0) {
                           break label86;
                        }

                        byte var132 = var91;
                        if (var132 == 0) {
                           continue;
                        }
                     }

                     int var135 = var14;
                     double var133 = var22;
                     var95 = var133;
                     double var92 = var133;
                     if (var135 == 0) {
                        break label120;
                     }

                     double var150;
                     int var136 = (var150 = var92 - var16) == 0.0 ? 0 : (var150 < 0.0 ? -1 : 1);
                     var94 = var136;
                  }

                  int var137 = var94;
                  if (var137 >= 0) {
                     break label88;
                  }

                  var15 = var20;
                  var95 = var22;
               }

               var16 = var95;
            }

            int var138 = var14;
            if (var138 != 0) {
               continue;
            }
         }

         var97 = var15;
         break;
      }

      return var97;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private double aReturningDouble(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 30414666635747L ^ var2;
      MinecraftClient var19 = b;
      ClientPlayerEntity var20 = var19.player;
      Vec3d var5 = var20.getEyePos();
      Entity var21 = var4;
      Box var6 = var21.getBoundingBox();
      Vec3d var22 = var5;
      Box var23 = var6;
      Box var24 = var6;
      double var29 = var24.maxX;
      double var27 = var23.minX;
      double var25 = var22.x;
      double var7 = MathHelper.clamp(var25, var27, var29);
      Vec3d var31 = var5;
      Box var32 = var6;
      Box var33 = var6;
      double var38 = var33.maxY;
      double var36 = var32.minY;
      double var34 = var31.y;
      double var9 = MathHelper.clamp(var34, var36, var38);
      Vec3d var40 = var5;
      Box var41 = var6;
      Box var42 = var6;
      double var47 = var42.maxZ;
      double var45 = var41.minZ;
      double var43 = var40.z;
      double var11 = MathHelper.clamp(var43, var45, var47);
      Vec3d var49 = var5;
      double var13 = var49.x - var7;
      Vec3d var50 = var5;
      double var15 = var50.y - var9;
      Vec3d var51 = var5;
      double var17 = var51.z - var11;
      double var52 = var13 * var13 + var15 * var15 + var17 * var17;
      return Math.sqrt(var52);
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 30414666635747L ^ var2;
      long var5 = var2 ^ 116240701358212L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var28 = b;
      ClientPlayerEntity var29 = var28.player;
      Vec3d var8 = var29.getEyePos();
      Entity var30 = var4;
      Box var9 = var30.getBoundingBox();
      int var7 = var10000;
      Box var31 = var9;
      Box var32 = var9;
      double var10 = var31.maxY - var32.minY;
      int var82 = var7;
      double var78 = var10;
      double var71 = var78;
      double var73 = var80;
      double var67 = var78;
      double var69 = var80;
      if (var82 == 0) {
         double var99;
         int var83 = (var99 = var67 - var69) == 0.0 ? 0 : (var99 < 0.0 ? -1 : 1);
         if (var83 <= 0) {
            Entity var34 = var4;
            return var34.getEyePos();
         }

         Vec3d var36 = var8;
         Box var37 = var9;
         var73 = var37.minX;
         var71 = var36.x;
      }

      Box var38 = var9;
      double var43 = var38.maxX;
      double var41 = var73;
      double var39 = var71;
      double var12 = MathHelper.clamp(var39, var41, var43);
      Vec3d var45 = var8;
      Box var46 = var9;
      Box var47 = var9;
      double var52 = var47.maxZ;
      double var50 = var46.minZ;
      double var48 = var45.z;
      double var14 = MathHelper.clamp(var48, var50, var52);
      Vec3d var54 = var8;
      double var96 = var54.x - var12;
      Vec3d var55 = var8;
      double var97 = var96 * (var55.x - var12);
      Vec3d var56 = var8;
      double var10001 = var56.z - var14;
      Vec3d var57 = var8;
      double var16 = var97 + var10001 * (var57.z - var14);
      double var18 = Double.POSITIVE_INFINITY;
      Vec3d var20 = null;
      while (true) {
         int var85 = u.length;
         int var84 = var21;
         if (var84 < var85) {
            int var86 = var7;
            if (var86 != 0) {
               break;
            }

            label45: {
               MultiModeSetting var98 = this.n;
               Object[] var59 = new Object[]{u[var21], var5};
               MultiModeSetting var58 = var98;
               boolean var87 = var58.aReturningBoolean(var59);
               if (var87) {
                  Box var62 = var9;
                  double var22 = var62.minY + v[var21] * var10;
                  Vec3d var63 = var8;
                  double var24 = var63.y - var22;
                  double var26 = var16 + var24 * var24;
                  int var88 = var7;
                  if (var88 != 0) {
                     break label45;
                  }

                  double var100;
                  int var89 = (var100 = var26 - var18) == 0.0 ? 0 : (var100 < 0.0 ? -1 : 1);
                  if (var89 < 0) {
                     var18 = var26;
                     var20 = new Vec3d(var12, var22, var14);
                  }
               }

               var21++;
            }

            int var90 = var7;
            if (var90 == 0) {
               continue;
            }
         }

         int var92 = var7;
         Vec3d var91 = var20;
         Vec3d var76 = var91;
         Vec3d var75 = var91;
         if (var92 != 0) {
            return var76;
         }

         Vec3d var93 = var75;
         if (var93 != null) {
            var76 = var20;
            return var76;
         }
         break;
      }

      Entity var66 = var4;
      return var66.getEyePos();
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 138034205669940L ^ 100604297794100L;
      int var10000 = Event.cReturningInt();
      Object[] var10 = new Object[0];
      PacketSendEvent var9 = var1;
      Packet var8 = var9.aReturningVoid(var10);
      int var6 = var10000;
      int var19 = var6;
      Packet var18 = var8;
      Packet var17 = var18;
      Packet var16 = var18;
      if (var19 != 0) {
         boolean var20 = var16 instanceof PlayerActionC2SPacket;
         if (!var20) {
            return;
         }

         Packet var21 = var8;
         var17 = var21;
      }

      PlayerActionC2SPacket var7 = (PlayerActionC2SPacket)var17;
      PlayerActionC2SPacket var13 = var7;
      Action var24 = var13.getAction();
      Action var23 = Action.RELEASE_USE_ITEM;
      Action var22 = var24;
      if (var22 == var23) {
         ElapsedTimer var25 = this.s;
         Object[] var15 = new Object[]{42835128969216L};
         ElapsedTimer var14 = var25;
         var14.aReturningVoid(var15);
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 73940074785240L ^ 16218006299689L;
      var10001 = 73940074785240L ^ 38742525833197L;
      var10001 = 73940074785240L ^ 70129483521560L;
      var10001 = 73940074785240L ^ 38768636721628L;
      int var12 = Event.cReturningInt();
      int var72 = var12;
      KillAura var71 = this;
      KillAura var66 = var71;
      KillAura var65 = var71;
      if (var72 != 0) {
         BooleanSetting var33 = var65.o;
         Boolean var34 = (Boolean)var33.aReturningObject();
         boolean var73 = var34;
         if (!var73) {
            return;
         }

         var66 = this;
      }

      Entity var13 = var66.t;
      int var75 = var12;
      Entity var74 = var13;
      Entity var68 = var74;
      Entity var67 = var74;
      if (var75 != 0) {
         Entity var76 = var67;
         if (var76 == null) {
            return;
         }

         var68 = var13;
      }

      int var78 = var12;
      Entity var77 = var68;
      Entity var70 = var77;
      Entity var69 = var77;
      if (var78 != 0) {
         Entity var38 = var69;
         boolean var79 = var38.isAlive();
         if (!var79) {
            return;
         }

         var70 = var13;
      }

      Object[] var41 = new Object[]{var70, 85760017780209L};
      Vec3d var14 = RaycastUtil.cReturningVec3d(var41);
      Object[] var42 = new Object[]{105570054506037L};
      float var15 = GameRenderUtil.aReturningFloat(var42);
      Entity var43 = var13;
      double var10000 = var43.getEyeY();
      Entity var44 = var13;
      double var16 = var10000 - var44.getY();
      Vec3d var45 = var14;
      var10000 = var45.x;
      Entity var46 = var13;
      double var88 = var46.getX();
      Vec3d var47 = var14;
      double var18 = var10000 + (var88 - var47.x) * var15;
      Vec3d var48 = var14;
      var10000 = var48.y;
      Entity var49 = var13;
      double var89 = var49.getY();
      Vec3d var50 = var14;
      double var20 = var10000 + (var89 - var50.y) * var15 + var16;
      Vec3d var51 = var14;
      var10000 = var51.z;
      Entity var52 = var13;
      double var90 = var52.getZ();
      Vec3d var53 = var14;
      double var22 = var10000 + (var90 - var53.z) * var15;
      FloatSetting var54 = this.p;
      Float var55 = (Float)var54.aReturningObject();
      float var24 = var55;
      float var25 = (float)(var18 - var24);
      float var26 = (float)(var20 - var24);
      float var27 = (float)(var22 - var24);
      float var28 = (float)(var18 + var24);
      float var29 = (float)(var20 + var24);
      float var30 = (float)(var22 + var24);
      ColorSetting var56 = this.q;
      Color var31 = (Color)var56.aReturningObject();
      Color var57 = var31;
      int var10002 = var57.getRed();
      Color var58 = var31;
      int var10003 = var58.getGreen();
      Color var59 = var31;
      int var10004 = var59.getBlue();
      short var10005 = 255;
      Color var60 = var31;
      int var62 = var60.getAlpha() + 55;
      Color var32 = new Color(var10002, var10003, var10004, Math.min(255, var62));
      RenderContext var83 = var1.b;
      MeshBufferManager var91 = var1.a;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var31, 137403672065984L};
      var10011[7] = var30;
      var10011[6] = var29;
      var10011[5] = var28;
      var10011[4] = var27;
      var10011[3] = var26;
      var10011[2] = var25;
      var10011[1] = var91;
      var10011[0] = var83;
      Object[] var63 = var10011;
      ShapeRenderer.hReturningVoid(var63);
      RenderContext var84 = var1.b;
      MeshBufferManager var92 = var1.a;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, var32, 106090074574852L};
      var10011[7] = var30;
      var10011[6] = var29;
      var10011[5] = var28;
      var10011[4] = var27;
      var10011[3] = var26;
      var10011[2] = var25;
      var10011[1] = var92;
      var10011[0] = var84;
      Object[] var64 = var10011;
      ShapeRenderer.gReturningVoid(var64);
   }

   private boolean lambda$new$2(Color var1) {
      BooleanSetting var4 = this.o;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Float var1) {
      BooleanSetting var4 = this.o;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.h;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Range";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(82829287894670L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[11];
      String var15 = "\u000bÔ¹!ô\u0084èù¶¥!$Ó\u000b\n\u001a\u0010`xß\u0019^Þ\u0004OÒª{\u0019)d\u0005¡\u0010©Qï\u00adfQ=ÿéµß\u001bUX¢*\u0010\u0097\u009fzjR(ºK\u0015vÍ¾}P\u0002»\u0010á½÷ìÂ;á\u000e,Ø\u008f\u009b`\u009e\tv\u0010ÙO &F\u0000~¶å,×ëö~+» j\u0080Îø\u0015ø\n\u0018Åîÿ<\u0006;\u0002 þ\u008bm\u0004\u009aÌÚA\u00826µ\u000f2+xæ\u0010ó\u0099\u0096<p\u0086V\u008bYâ\u0099\u0097y£å\u001e\u0010\u0011\u0014#Yÿß \u0082\u0088éjÎç\u0015\u0093U";
      int var17 = "\u000bÔ¹!ô\u0084èù¶¥!$Ó\u000b\n\u001a\u0010`xß\u0019^Þ\u0004OÒª{\u0019)d\u0005¡\u0010©Qï\u00adfQ=ÿéµß\u001bUX¢*\u0010\u0097\u009fzjR(ºK\u0015vÍ¾}P\u0002»\u0010á½÷ìÂ;á\u000e,Ø\u008f\u009b`\u009e\tv\u0010ÙO &F\u0000~¶å,×ëö~+» j\u0080Îø\u0015ø\n\u0018Åîÿ<\u0006;\u0002 þ\u008bm\u0004\u009aÌÚA\u00826µ\u000f2+xæ\u0010ó\u0099\u0096<p\u0086V\u008bYâ\u0099\u0097y£å\u001e\u0010\u0011\u0014#Yÿß \u0082\u0088éjÎç\u0015\u0093U"
         .length();
      char var14 = 16;
      int var22 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var22, var22 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var23.getBytes("ISO-8859-1"));
            String var36 = b(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var36;
                  if ((var22 += var14) >= var17) {
                     x = var18;
                     y = new String[11];
                     C = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(82829287894670L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     String var4 = "êkÎ+\u007f\u001eoFØû`\u0084J\t{vo\u0001\u0088(Û\u0086L\t";
                     int var5 = "êkÎ+\u007f\u001eoFØû`\u0084J\t{vo\u0001\u0088(Û\u0086L\t".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var26[var10001] = var45;
                                 if (var2 >= var5) {
                                    A = var6;
                                    B = new Integer[5];
                                    u = new String[]{"Head", "Neck", "Chest", "Waist", "Thighs", "Legs"};
                                    short var27 = 3208;
                                    long var34 = 846601693876640911L;
                                    v = new double[]{0.95, 0.85, 0.7, 0.55, 0.35, 0.1};
                                    break;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u009eð&zÅ\u0002ÀÖ¾a\u0082\u0090¸ã\u007f\u008a";
                                 var5 = "\u009eð&zÅ\u0002ÀÖ¾a\u0082\u0090¸ã\u007f\u008a".length();
                                 var2 = 0;
                           }

                           int var33 = var2;
                           var2 += 8;
                           var7 = var4.substring(var33, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var22);
                  break;
               default:
                  var18[var16++] = var36;
                  if ((var22 += var14) < var17) {
                     var14 = var15.charAt(var22);
                     continue label54;
                  }

                  var15 = "dà\u001bb\u0012\u0013\u0096f'e\u0084ßÄ\u0087°æ\u0010\u0086¶0\u001fc\u0088\u0005Ê\\\u001c\bC}?y¢";
                  var17 = "dà\u001bb\u0012\u0013\u0096f'e\u0084ßÄ\u0087°æ\u0010\u0086¶0\u001fc\u0088\u0005Ê\\\u001c\bC}?y¢".length();
                  var14 = 16;
                  var22 = -1;
            }

            var23 = var15.substring(++var22, var22 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 24767;
      if (y[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])z.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               z.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e0", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = x[var5].getBytes("ISO-8859-1");
         y[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return y[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e0",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20487;
      if (B[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = A[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])C.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               C.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/e0", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         B[var3] = var15;
      }

      return B[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e0",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = E[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = D[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 15;
            yield var15;
         }
         case 1 -> {
            byte var16 = 60;
            yield var16;
         }
         case 2 -> {
            byte var17 = 55;
            yield var17;
         }
         case 3 -> {
            byte var18 = 37;
            yield var18;
         }
         case 4 -> {
            byte var19 = 58;
            yield var19;
         }
         case 5 -> {
            byte var20 = 63;
            yield var20;
         }
         case 6 -> {
            byte var21 = 5;
            yield var21;
         }
         case 7 -> {
            byte var22 = 32;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 10;
            yield var25;
         }
         case 11 -> {
            byte var26 = 33;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 38;
            yield var28;
         }
         case 14 -> {
            byte var29 = 1;
            yield var29;
         }
         case 15 -> {
            byte var30 = 51;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 14;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 29;
            yield var36;
         }
         case 22 -> {
            byte var37 = 13;
            yield var37;
         }
         case 23 -> {
            byte var38 = 47;
            yield var38;
         }
         case 24 -> {
            byte var39 = 39;
            yield var39;
         }
         case 25 -> {
            byte var40 = 0;
            yield var40;
         }
         case 26 -> {
            byte var41 = 21;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 43;
            yield var43;
         }
         case 29 -> {
            byte var44 = 35;
            yield var44;
         }
         case 30 -> {
            byte var45 = 7;
            yield var45;
         }
         case 31 -> {
            byte var46 = 4;
            yield var46;
         }
         case 32 -> {
            byte var47 = 40;
            yield var47;
         }
         case 33 -> {
            byte var48 = 42;
            yield var48;
         }
         case 34 -> {
            byte var49 = 30;
            yield var49;
         }
         case 35 -> {
            byte var50 = 61;
            yield var50;
         }
         case 36 -> {
            byte var51 = 16;
            yield var51;
         }
         case 37 -> {
            byte var52 = 44;
            yield var52;
         }
         case 38 -> {
            byte var53 = 18;
            yield var53;
         }
         case 39 -> {
            byte var54 = 23;
            yield var54;
         }
         case 40 -> {
            byte var55 = 62;
            yield var55;
         }
         case 41 -> {
            byte var56 = 45;
            yield var56;
         }
         case 42 -> {
            byte var57 = 54;
            yield var57;
         }
         case 43 -> {
            byte var58 = 25;
            yield var58;
         }
         case 44 -> {
            byte var59 = 56;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 22;
            yield var61;
         }
         case 47 -> {
            byte var62 = 11;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 41;
            yield var64;
         }
         case 50 -> {
            byte var65 = 52;
            yield var65;
         }
         case 51 -> {
            byte var66 = 20;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 49;
            yield var68;
         }
         case 54 -> {
            byte var69 = 6;
            yield var69;
         }
         case 55 -> {
            byte var70 = 27;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 46;
            yield var72;
         }
         case 58 -> {
            byte var73 = 9;
            yield var73;
         }
         case 59 -> {
            byte var74 = 36;
            yield var74;
         }
         case 60 -> {
            byte var75 = 53;
            yield var75;
         }
         case 61 -> {
            byte var76 = 8;
            yield var76;
         }
         case 62 -> {
            byte var77 = 26;
            yield var77;
         }
         default -> 19;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            E[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      D[0] = "jxAa.HjxV=\"Gp3V#\"RwB\u0002{u";
      D[1] = "H\u0002o\u001diYH\u0002xAeVRIx_eCU8*\u00052\u0001";
      D[2] = "B3Sm&@B3D1*OXxD/*Z_\t\u0016tr\u0010";
      D[3] = "by\f-\u0007[by\u001bq\u000bTx2\u001bo\u000bA\u007fCI4S\u0000";
      D[4] = "\u0018\u00169:!P\u000e\u0016<`2G\u0019]?f>S\b\u001a(quA9";
      D[5] = int.class;
      E[5] = "java/lang/Integer";
      D[6] = "\u001d~\r\u0016\u0007o\u001d~\u001aJ\u000b`\u00075\u001aT\u000bu\u0000DJ\tZ";
      D[7] = "\u00168RN\u000bx\u00008W\u0014\u0018o\u0017sT\u0012\u0014{\u00064C\u0005_mB";
      D[8] = ";#Bz\u0004$0,S5g)%!\\^R+42@rE&";
      D[9] = "Zcj#qbZc}\u007f}m@(}a}xGY,9/";
      D[10] = double.class;
      E[10] = "java/lang/Double";
      D[11] = "\u0003Zab:v\u001eO9@{{\u0006I";
      D[12] = "Hb\"GL\tHb5\u001b@\u0006R)5\u0005@\u0013UXg[\u0018W";
      D[13] = ".\u0017||a18\u0017y&r&/\\z ~2>\u001bm75%<";
      D[14] = "\u001f!\r\u0004Rkj\u0001\u0006\u000bC$\u000b\u000f\r\u0000G~\u007f";
      D[15] = void.class;
      E[15] = "java/lang/Void";
      D[16] = "}7#bO;k7&8\\,||%>P8m;2)\u001b/n";
      D[17] = "Jwhkj ?Wcd{o^Yho\u007f5*";
      D[18] = float.class;
      E[18] = "java/lang/Float";
      D[19] = "YZ\u007f:4^OZz`'IX\u0011yf+]IVnq`M\u000e";
      D[20] = "<<[\\$-I\u001cPS5b(\u0012[X18\\";
      D[21] = "Z\u0000jD7BQ\u000f{\u000b[A_\ryDw";
      D[22] = boolean.class;
      E[22] = "java/lang/Boolean";
      D[23] = "\u001a\u0007\u0003c\n\u0000\f\u0007\u00069\u0019\u0017\u001bL\u0005?\u0015\u0003\n\u000b\u0012(^\u00148";
      D[24] = "p2LhI\u001d{=]'(\u0013p6Y}";
      D[25] = "A\n\u0019\u001cs`J\u0005\bS\u001b`D\n\u001b";
      D[26] = "@i1\"595I:-$vTG1& , ";
      D[27] = "?N685X4A'wVU!G";
      D[28] = "2\u0014\u00188 h$\u0014\u001db3\u007f3_\u001ed?k\"\u0018\tst|\u001f";
      D[29] = "\u0013|\u001bI)%f\\\u0010F8j\u0007R\u001bM<0s";
      D[30] = "r<1 \u0006\u0002d<4z\u0015\u0015sw7|\u0019\u0001b0 kR\u0016\\";
      D[31] = "T}(\u001e1%!]#\u0011 j@S(\u001a$04";
      D[32] = ">)OB\"\u0006()J\u00181\u0011?bI\u001e=\u0005.%^\tv\u0012\u0016";
      D[33] = "P&i\f, %\u0006b\u0003=oD\bi\b950";
      D[34] = "\u0011_D\u0013Q\u0016\u0011_SO]\u0019\u000b\u0014SQ]\f\fe\u0002\u000e\u0004";
      D[35] = "H6[\\P\u0015H6L\u0000\\\u001aR}L\u001e\\\u000fU\f\u001cG\u000eN";
      D[36] = "k\u0002{\u000b+\u007f\u001e\"p\u0004:0\u007f,{\u000f>j\u000b";
      D[37] = "b|*\u0016&,t|/L5;c7,J9/rp;]r8D";
      D[38] = "D>B6\u007fv1\u001eI9n9P\u0010B2jc$";
      D[39] = "\u0004rd\u0003\u001dm\u0012raY\u000ez\u00059b_\u0002n\u0014~uHIy\u0018";
      D[40] = "L\u0002\n^ciG\r\u001b\u0011\u001eqT\n\u0012X";
      D[41] = "\u0017\u001a\t!E\u000b\u0001\u001a\f{V\u001c\u0016Q\u000f}Z\b\u0007\u0016\u0018j\u0011\u001a\u001f";
      D[42] = "6\u0001\n\u0010^vC!\u0001\u001fO9\"/\n\u0014KcV";
      D[43] = "\u000fVfO\u001d:\u0019Vc\u0015\u000e-\u000e\u001d`\u0013\u00029\u001fZw\u0004I)\u0007";
      D[44] = "8s8xsIMS3wb\u0006,]8|f\\X";
      D[45] = "3\u00157'i8%\u00152}z/2^1{v;#\u0019&l=,.";
      D[46] = "b5|Zc-\u0017\u0015wUrbv\u001b|^v8\u0002";
      D[47] = "au\u0013`\u0011gwu\u0016:\u0002p`>\u0015<\u000edqy\u0002+Eq\\";
      D[48] = "&s?5!RSS4:0\u001d2]?14GF";
      D[49] = "pi\u00041\u00171\u0005I\u000f>\u0006~dG\u00045\u0002$\u0010";
      D[50] = "-u<\u0010*\u0019XU7\u001f;V9[<\u0014?\fM";
      D[51] = "\u0007xia\u00051\u0011xl;\u0016&\u00063o=\u001a2\u0017tx*Q\"\u000ftz!\u000bo3oz<\u000b(\u0004x";
      D[52] = "@\u0014*_\t8V\u0014/\u0005\u001a/A_,\u0003\u0016;P\u0018;\u0014]+J";
      D[53] = "?\u0005s$`yJ%x+q6++s ul_";
      D[54] = "\u0012M$u9lgm/z(#\u0006c$q,yr";
      D[55] = "&BUi}+0BP3n<'\tS5b(6ND\")?+";
      D[56] = "lR<\u007fFe\u0019r7pW*x|<{Sp\f";
      D[57] = "ir\u000bl i\u001cR\u0000c1&}\\\u000bh5|\t";
      D[58] = "]\u00054cj\n(%?l{EI+4g\u007f\u001f=";
      D[59] = "1r~v[\u0019DRuyJV%\\~rN\fQ";
      D[60] = "\f2ati\u0019y\u0012j{xV\u0018\u001cap|\fl";
      D[61] = "MZ-]F98z&RWvYt-YS,-";
      D[62] = "\u000e($\b\\J\u0018(!RO]\u000fc\"TCI\u001e$5C\b\\?";
      D[63] = "\u0015\u0000NX\u000f\u0007` EW\u001eH\u0001.N\\\u001a\u0012u";
      D[64] = "#eBsWKVEI|F\u00047KBwB^C";
      D[65] = "\fmR &\u0014yMY/7[\u0018CR$3\u0001l";
      D[66] = "WSms\u0013\u000f\"sf|\u0002@C}mw\u0006\u001a7";
      D[67] = "WS;JL\u0019AS>\u0010_\u000eV\u0018=\u0016S\u001aG_*\u0001\u0018\n\\";
      D[68] = "G8\u0013c\u0014#2\u0018\u0018l\u0005lS\u0016\u0013g\u00016'";
      D[69] = "f'\u001b6\rg\u0013\u0007\u00109\u001c(r\t\u001b2\u0018r\u0006";
      D[70] = "p72y9Un?(6DEn";
      D[71] = "f]\u0015T\bT\u0013}\u001e[\u0019\u001brs\u0015P\u001dA\u0006";
      D[72] = "2}fz\u0015#2}q&\u0019,(6q8\u00199/G lL|x{~5\u000b9\u0003**`O";
      D[73] = "\u0003_`jUc\u0003_w6Yl\u0019\u0014w(Yy\u001ee&|\f<";
      D[74] = "p\u0011\u0014veOf\u0011\u0011,vXqZ\u0012*zL`\u001d\u0005=1]q";
      D[75] = "`4\u000b]GN\u0015\u0014\u0000RV\u0001t\u001a\u000bYR[\u0000";
      D[76] = "\u0002\b\u0011\b\u000f-\u0002\b\u0006T\u0003\"\u0018C\u0006J\u00037\u001f2W\u0013[r";
      D[77] = "b\u0017\u001a\u0019i:t\u0017\u001fCz-c\\\u001cEv9r\u001b\u000bR=.H";
      D[78] = "?\u0017_PcNJ7T_r\u0001+9_Tv[_";
      D[79] = "3~&_\n\f%~#\u0005\u0019\u001b25 \u0003\u0015\u000f#r7\u0014^\u001d1";
      D[80] = "\\O]\u0003A\r)oV\fPBHa]\u0007T\u0018<";
      D[81] = "\u00059^E\u001e!\u00139[\u001f\r6\u0004rX\u0019\u0001\"\u00155O\u000eJ7.";
      D[82] = "Zy\u0007!#\u0018Dq\u001dnD\u0019Uj\u00104b\u001f";
      D[83] = "-\bJ=\r`X(A2\u001c/9&J9\u0018uM";
      D[84] = "fPLk=#fP[71,|\u001b[)19{j\npf{";
      D[85] = "x5\u0014T\u0001Hs:\u0005\u001bfPw&\u0003WCA";
      D[86] = "#ksIJWVKxF[\u00187EsM_BC";
      D[87] = "\f\u0007q \u0018N\f\u0007f|\u0014A\u0016Lfb\u0014T\u0011=3=M";
      D[88] = "*?0o17$26+\u0001)Xj/ngy4\"2j1!";
      D[89] = "E\"\u0005o&t\r?\u00019~\u0018\u0015@\u0000n'{\u0001~C1&}\u0004@W`l!L;Gi}z|";
      D[90] = "V\u0018\b\f_b]YYvW6N\u0007W\u001ae`\u000bZ\fF2!\u000f\u000eV\u000fX<@\u00060";
      D[91] = "|!^\u0013\u0004+\u007fa\u0006Cm:.!.\u0017\u00155*]\\\u0010\u00009:6\u001a\u001f]3C";
      D[92] = "-j?\u0011\u000b5t\u007fj\u001bw\"*yj\u0006 up.4jHv&m?R\u0018'2$";
      D[93] = "zS\u001en}|6H\u001fb\u0016{'IEbzIp\u000e\u001e<)\u001eu\u000fH|'&%^\\5\u0016";
      D[94] = "*CC\u0003cTmGM\r\u0000M8\u0004G\"gA<\u007f\u001c\nmA(\u0014Z\u00050KQ";
      D[95] = ";E\u000em\rD5H\b)=TI\u0010\u0010:CE$\u0010\u000f)TQ";
      D[96] = "\u0007\bU(JQ\fI\u0004RB\u0005\u001f\u0017\n>pS]KPn'\u0003\u001f\u001b\u00020LQ\u0001\u000b]R";
      D[97] = "_RBtY\\JRL'$W!\u0005B{GF\u001fF\u001dzAC!UHu\u0018\u0002SQTu\u001a;";
      D[98] = "1{'u\u0002z2<\u007fdr)Ux}?\u0011=k;\">\u00178U% 2\b0o&gj\u0019@";
      D[99] = "\u0012?4e\u001f(\u0019~e\u001f\u0017|\n ks%+Jp6/r\u007f\u001f;5/\to\u0016*n\u001f";
      D[100] = "3kvC\u001fE~>i\u0018bCNcuJ\u0001Wp *K\u0007RN3\u007fD^\u0013<7cD\\*";
      D[101] = "\u0004g g2#\u000f&q\u001d:w\u001cx\u007fq\b!^$% _q\u001ctw\u007f4#\u0002d(\u001d";
      D[102] = "w/d\u001c\u007f'# $B1^(&+_C16zeX b!2f#";
      D[103] = "[4-\u001cbw\u001auwY\u0018|#q{\u0014{k\u001d2$\u0015}n#2vIvv\u0013%c\u0014#\u0016";
      D[104] = "}z\u000fnsqts\u0014(s\u0010+r\u0015\u000fpj%y\u0006Tw, u\n-0(.{i";
      D[105] = "IS \u0001ff\fEx\u001aZ?u\u0015'J9+KVxK?.u\u001c&A1=\u0017P=@=V";
      D[106] = "zV]}\u0001:$F\n;e>b\\J\u0006Z\u007fv_\u0007>\n.b\u001669_(b\u0017\u000ei\u000e<+&";
      D[107] = "\u0003B,\u001de=ZWy\u0017\u0019*\u0004Qy\nN}^\u0006$f&~\bE,^v/\u001c\f";
      D[108] = "$U\ra\u00112aCUz-k\u0018\u0013\n*N\u007f&PU+Hz\u0018\u0014\u0013#Ag RPaL\u0002";
      D[109] = "K,~<Q?L> 6BU\u0017/:lD9%{|7\u001dnr{+0\u00193\r9#3B5r";
      D[110] = "\u00044*VGQH/+Z,VY.qZ@d\u000ei*\u0007\u00143\u000bh|D\u001d\u000b[9h\r,";
      D[111] = "T.\u0006\u0010y\b\u00185\u0007\u001c\u0012\u000f\t4]\u001c~=^s\u0006B\"j[rP\u0002#R\u000b#DK\u0012";
      D[112] = "r2/uz'/? n\u0004~x\"\u007fjhL,c$0<\u001b*drt5#z5f=\u0004$/3f<<t~'/\r;!x'.5kpln\u001f2>vlo'bob%^";
      D[113] = ".\u0007^_q+-G\u0006\u000f\u0018:|\u0007=RtU*\u0018\nSa>l\u0017WY\u0018";
      D[114] = "0GAL\u001aHrOB\u0017\u001c7gK\u0010\u0012\u0010`0\u0010LI@70GAL\u001aHrOB\u0017\u001c";
      D[115] = "\u00066#j)w\rwr\u0010!#\u001e)||\u0013uYt$)Dp\u001cpwu|6_2z\u0010";
      D[116] = "`\t%(5\u007f&Jg%P)?\u001ax(\u0007~eJ&Do}3\u000e-|?,'G";
      D[117] = "_\bu\u000b\u0018]\u0019K7\u0006}\u000b\u0000\u001b(\u000b*\\ZKugB_\f\u000f}_\u0012\u000e\u0018F";
      D[118] = "&PG\\=\u007faTIR^k$\u0011JR%\u00062\u0014\u0012\b%ea\u0003Z\u000b^h4\u0017\u001a\u0006%x=\u0006A6";
      D[119] = "3f{\u001cT 7y;\u000254Y= BV g~\u007fCP%Yo;\u001eZ?2=%\u000e\u0005]";
      D[120] = "V\u00197yr6\u000f\fbs\u000e!Q\nbnYv\u000b]>\u00021u]\u001e7:a$IW";
      D[121] = "\u0013R~\u000f7\tR\u0013$JM\u0006k\u0017(\u0007.\u0015UTw\u0006(\u0010k@&LtX\u0010P/]/h";
      D[122] = "\"\\\u0007u\u0004N)\u001dV\u000f\f\u001a:CXc>Jx\u001f\u000e\u000fVM+Z\u000e7\u0006\u001c?\u0013?0S\u001a?\u0012\u0007`\u0002\u000ev#\u00005\u0004\u000ew\u001bPd\u0010GF\u001c\u0005b\u0010F~LTvYw";
      D[123] = "21Ux5\u001b2.Fo!vbR\u0006a{\u0015vlE>z\u0013sRQo0O;)Af!\u0014\u000b";
      D[124] = "\u0004\u001f\u0015Q+H\u0011\u0004EEI@a\rPY&K\n_NIy)";
      D[125] = "O\\\u000e(P\f\u0005BM>+\ru\u001f\u0016`H\u001aK\\IaN\u001fuH\u0018+\u0012W\u000eX\u0011:Ig";
      D[126] = "u=I\u0003jUhrAevRs`G\tD\u00023;\u0010e(\\blY\u000enS?f \\mA\u007fcQ\u0004r@~\u0000";
      D[127] = "{\u001e\u001eb\u0017B7\u0005\u001fn|E&\u0004En\u0010wqC\u001e3E tBHpM\u0018$\u0013\\9|";
      D[128] = "ZHf\u0002F`\\^h\u001670\u0007\\n\u0011`gX\u00015}\u000e9\u001fCx\u001eI0]W6";
      D[129] = "\u000fYPw\n\b\u0018L\r\"jQu\nZ)\tEKI\u0005(\u000f@u]TbS\b\u000eM]s\b8";
      D[130] = "w|\u0019c\u001f$.iLic3poLt4d*8\u0013\u0018\\g|{\u0019 \f6h2";
      D[131] = "a\u001b\u0016\u001eL*$\rN\u0005ps]Y\u0006\bO#1\u0002\u000f^\n\u001a`\u0014\u001bZIv;\u001dM\u001fp";
      D[132] = "\u001d/`SH\u001bO.s\u0003xM,ryX\u001b_\u00121&Y\u001dZ,\"sVD\u001b^&oVF\"";
      D[133] = ":Hir\f%\u007f^1i0y\u0006\u000en9Sh8M18Um\u0006\fjd\\lmJe9V\u0015";
      D[134] = ",)K#\\092\u001b7>?Ii\u0015w],w*Jv[)I;\u000e+Q3\"i\u0010;\u000eQ";
      D[135] = "%\u0006=p\u001ed&Fe wuw\u0006Kj\u001aw|z?s\u001avc\u0011y|G|\u001a";
      D[136] = "\bf\u0003\u000b\u0019:LaE\u0006^TX\f\u0003\u001eU7L2@AT1I\fT\u0010\u001em\u0001wD\u0019\u000f61";
      D[137] = "\\ZJaS+W\u001b\u001b\u001b[\u007fDE\u0015wi,\u0001\u001cO\u001bP{C\u001cB`@rRGr";
      D[138] = "\u0013Y*9Z VOr\"fy/\u001f-r\u0005m\u0011\\rs\u0003h/\u0019p/\u001f!\u0017I!;V\u0010";
      D[139] = "\u0010h-'\u0012 Zvn1i!*)12\u00052Ao>o\u000fK";
      D[140] = "\b\u0003\u0010\u000bMIIBJN7ApFF\u0003TUN\u0005\u0019\u0002RPp\u0005K^YH@\u0012^\u0003\f(";
      D[141] = "Ot[\u0012(1\u0004t\\\f3N\u001f\u0014\u0019\u0016e-\u000b*ZId+\u000e\u0014N\u0018.wFo^\u0011?,v";
      D[142] = "^pgl:.\u0006ofmY:\nry{5\bX?!-Ye\n>#ve\"\u0001mu\u001c";
      D[143] = "\u001fV\"\b\u0019G\u0014\u0017sr\u001a\u001f\u0016Mv%JFB\u0016\u001aMN\u0013\u0002\u0018\"\u001d\u001f\u0007K";
      D[144] = ">fl,Z\u001dlg\u007f|jD\u000f;u'\tY1x*&\u000f\\\u000fk\u007f)V\u001d}oc)T$";
      D[145] = "\f=H<A-J(Y$LQR867]`\u000b-UdJ(\bVY \u0014oN5\n7\\l5o]&A5I)H7Y85";
      D[146] = ":)`{Q}(/aco(Vi>!\f>h*a \n;Vn'(\u0003&n(dj\u000eC";
      D[147] = "hp\u0015\u0012J%\"nV\u00041%R1\t\u0007]79w\u0006ZWN";
      D[148] = "5A5v\u0013M6\u001cd#.I<\u0018;\u007fGE\u0005\u0016;oC#5\u0016$+\u001eX%\u001f5p.";
      D[149] = "\u0019!\u000e~#`U:\u000frHgD;Ur$U\u0014w\r(Hl@<\f%3|I-W\u0015";
      D[150] = "6Vo7LX'Ud<5AM\u0015hmVUsV7lPPMBf&\f\u00186Ro7W(";
      D[151] = "iJ\n\tHL%Q\u000b\u0005#K4PQ\u0005Oyd\u001c\u000bS#H'\u001dJ\u001eZ\u00112H@b";
      D[152] = "8.Eqs{-5\u0015e\u0011s]n\u001b%rgc-D$tb]2\u0005,ux<'\u001e|a\u001a";
      D[153] = "\u00013+J\u001cgGpiGy1^ vJ.f\u0004p*&FeR4#\u001e\u00164F}";
      D[154] = "q\u0003\"g\u0001xw\u0007#a?t\u001e\u000e'n\u0001f}]0&\u0002\u001d";
      D[155] = "\u0013K}T\u0001/\u0006Ks\u0007|&m\u001c}[\u001f5S_\"Z\u00190mKs\u0010Ex\u0016[z\u0001\u001eH";
      D[156] = "?uN\u0018BX44\u001fbJ\f'j\u0011\u000ex^a4ObD\u001d7e\u0014\t\u0016\u0003':v\tS\r4h\u001d[M\u001dk\n";
      D[157] = "\u0015\u0005\u0018\u0003\u0002\u001a\u001eDIy\nN\r\u001aG\u00158\u001dIG\u001fy_EJ\u0011K\u001b\u0013^K\u001d \u0017\u0006XHJ[\u0007\u000fI\u0013z";
      D[158] = "\u001c\u0001\u000e\u00148Q\t\u0001\u0000GE[bV\u000e\u001b&K\\\u0015Q\u001a Nb\u0006\u0004\u0015y\u000f\u0010\u0002\u0018\u0015{6";
      D[159] = "\u0017qjqj\rNd?{\u0016\u001a\u0010b?fAMJ5f\n)N\u001cvj2y\u001f\b?";
      D[160] = "U4b1v\u007fS\"l%\u0007/\b j\"PxVw2Nc>Q7cwh\u007f\u0000";
      D[161] = "3_;-H\u0018rYnq%\u0018C^`&F\f}\u001d?'@\tC\u000ej(\u0019H1\nv(\u001bq";
      D[162] = "Wq~\u000b\n+@d#^jr-\"tU\tf\u0013a+T\u000fc-po\t\u0005yF\"q\u0019Z\u001b";
      D[163] = "V\u0010m\u0010k;X\u001dkT[8$E(\u0014<9^\u0004/\u00135>";
      D[164] = "2M\u001fC0b<@\u0019\u0007\u0000z@_\f\u0019?`'J\f\u0017l";
      D[165] = "\u0011d\u007f\u000f\n\u001fHq*\u0005v\b\u0016w*\u0018!_L rtI\\\u001ac\u007fL\u0019\r\u000e*";
      D[166] = "j4e\u0013.b&/d\u001fEe7.>\u001f)WgnaGE9?4d\u0007$06/\"\u0007E";
      D[167] = ")&I|*`})\t\"d\u0019p+\r\u0005{ilB\u0018*m  9\b#|{\u0010";
      D[168] = "G-{8Y\u001a\u0006l!}#\u0017?h-0@\u0006\u0001+r1F\u0003?+ mM\u001b\u000f<50\u0018{";
      D[169] = "\u0015\u000b\u0003\u0019{}K\u001bT_\u001fg\u0015\u001dhY|o\u0018\u0002\u0003\u001fs2\u0012{S\u0001rn\r\u0010\u0015\u000e/dt@\u000b\u000fs{\u001f\u0006\u0004Ry\u0002";
      D[170] = "f*3*-?`q#)eF6\u0010d<,%\".'c-#'\u00106'p)={d9`v_";
      D[171] = "~EN{p\u0016%U\u0012vxf.+\u0015zq\u0005:\u0015V%p\u0003?+\u0015}|^8B\u0015d(\u001f;+";
      D[172] = "aI-\u0000Q3 Ox\\<3\u0011Hv\u000b_'/\u000b)\nY\"\u0011\u001fx@\u0005jj\u000fqQ^Z";
      D[173] = "De=<v}G%el\u001fl\u0016eN8bn{\"g1sz\u0010dhly\u0003";
      D[174] = "\" ws\u0000nn;v\u007fki\u007f:,\u007f\u0007[)}q'R\f,8ut\u000e4j{7yk";
      D[175] = "\rR\u001bW'\tTQ^S}`UHLUu\u001cSN!\u0016x_\u000b\bXBw\u001fUF!";
      D[176] = "&gks.\u001fg`lz)ev_ksc\u0006ba(,b\u0000g_;ymY&-?em[\u001f";
      D[177] = "\u0015fPG?\u001b\u001e'\u0001=7O\ry\u000fQ\u0005\u001cI%W=k\\\u000fi\u000bL3C\u000ehh";
      D[178] = "O[i\u001es\u001bHW1XO\u001c-\u00126U,\b\u0013QiT*\r-I!]4ICN-\u0005ru";
      D[179] = "\u000bL\"]g\u001e\u0004Ce@]\u0013\u000fG6]\u0003\u0014\u000f]2!6\u0001\u0007O=Jd\u001f\u0017\u0010_";
      D[180] = "(\nR^@|o\rS\nI\u0004x5\u000b\\\u0014gl\u000bH\u0003\u0015ai5\\R_=!NL[Nf\u0011";
      D[181] = "\u0019'\u0016>$\u000f\f'\u0018mY\u0001gp\u00161:\u0015Y3I0<\u0010g3\u001bl7\bW$\u000e1bh";
      D[182] = "I/\u0002:Jl\u000e&@.\u0004\u000f\u0015%\u0007(_c'qKq\u00015pq\u001dr@4\u0019(\u001e7Dnp";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = D[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(E[var4]);
            D[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = D[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            D[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  D[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1696207119405485L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = D[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  D[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1696207119405485L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        D[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1696207119405485L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 221;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 249;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 228;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 79;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 86;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 235;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 221;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 249;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 228;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e0",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e0" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(KillAura var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e0;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e0", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((KillAura)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(KillAura var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e0;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e0", "lambda$new$2", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((KillAura)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(KillAura var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e0;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e0", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((KillAura)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
