package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;

public class MacePot extends Module implements RotationSource {
   private FloatSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private ElapsedTimer e;
   private ElapsedTimer f;
   private ElapsedTimer g;
   private ElapsedTimer h;
   private Integer i;
   private Integer j;
   private static final long k = 54287098587801L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[75];
   private static final String[] p = new String[75];
   private static volatile MethodHandle bindingCache1;

   public MacePot() {
      super();
      long var10001 = 70425346874676L ^ 36316941429277L;

      this.e = new ElapsedTimer(106698256430889L);
      this.f = new ElapsedTimer(106698256430889L);
      this.g = new ElapsedTimer(106698256430889L);
      this.h = new ElapsedTimer(106698256430889L);
      this.i = null;
      this.j = null;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Boolean var10000 = Boolean.FALSE;
      BooleanSetting var4 = this.d;
      Object var6 = var4.aReturningObject();
      Boolean var5 = var10000;
      return var5.equals(var6);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 86502240407608L;
      long var6 = var2 ^ 98643120019534L;
      long var8 = var2 ^ 88473827854968L;
      long var10 = var2 ^ 121114674420043L;
      long var12 = var2 ^ 73608466808436L;
      long var14 = var2 ^ 29159961624672L;
      long var16 = var2 ^ 64485287364733L;
      int var18 = Event.cReturningInt();
      int var139 = var18;
      MinecraftClient var138 = b;
      MinecraftClient var107 = var138;
      MinecraftClient var106 = var138;
      if (var139 != 0) {
         MinecraftClient var23 = var106;
         Screen var140 = var23.currentScreen;
         if (var140 != null) {
            return null;
         }

         MinecraftClient var141 = b;
         var107 = var141;
      }

      MinecraftClient var26 = var107;
      int var10000 = (((var26.isWindowFocused()) ? 1 : 0));
      int var143 = var18;
      byte var142 = (byte)var10000;
      byte var109 = var142;
      byte var108 = var142;
      if (var143 != 0) {
         byte var144 = var108;
         if (var144 == 0) {
            return null;
         }

         ElapsedTimer var200 = this.e;
         FloatSetting var29 = this.a;
         Float var30 = (Float)var29.aReturningObject();
         float var10001 = var30;
         Object[] var10004 = new Object[]{null, var12};
         var10004[0] = var10001;
         Object[] var32 = var10004;
         ElapsedTimer var31 = var200;
         var109 = ((byte)((var31.aReturningBoolean(var32)) ? 1 : 0));
      }

      int var146 = var18;
      byte var145 = var109;
      byte var111 = var145;
      byte var110 = var145;
      if (var146 != 0) {
         byte var147 = var110;
         if (var147 == 0) {
            return null;
         }

         MinecraftClient var35 = b;
         RegistryEntry var37 = StatusEffects.SPEED;
         ClientPlayerEntity var36 = var35.player;
         var111 = ((byte)((var36.hasStatusEffect(var37)) ? 1 : 0));
      }

      byte var20;
      byte var127;
      byte var19 = var111;
      MinecraftClient var38 = b;
      RegistryEntry var40 = StatusEffects.STRENGTH;
      ClientPlayerEntity var39 = var38.player;
      var20 = ((byte)((var39.hasStatusEffect(var40)) ? 1 : 0));
      MinecraftClient var41 = b;
      ClientPlayerEntity var42 = var41.player;
      var10000 = (((var42.isOnGround()) ? 1 : 0));
      int var149 = var18;
      byte var148 = ((byte)(var10000));
      var127 = var148;
      byte var112 = var148;
      label136:
      if (var149 != 0) {
         byte var150 = var112;
         if (var150 != 0) {
            byte var120;
            int var152 = var18;
            byte var151 = var19;
            var120 = var151;
            byte var113 = var151;
            label131:
            if (var152 != 0) {
               byte var153 = var113;
               byte var114 = var153;
               byte var154 = var114;
               if (var154 == 0) {
                  ElapsedTimer var202 = this.g;
                  Object[] var225 = new Object[]{null, var12};
                  var225[0] = 300.0F;
                  Object[] var47 = var225;
                  ElapsedTimer var46 = var202;
                  var10000 = (((var46.aReturningBoolean(var47)) ? 1 : 0));
                  int var156 = var18;
                  byte var155 = ((byte)(var10000));
                  var120 = var155;
                  byte var115 = var155;
                  if (var156 == 0) {
                     break label131;
                  }

                  byte var157 = var115;
                  byte var116 = var157;
                  byte var158 = var116;
                  if (var158 != 0) {
                     int var213 = 21926;
                     long var10002 = 7879487334323716109L ^ var2;
                     Object[] var10005 = new Object[]{null, null, StatusEffects.SPEED, var6};
                     var10005[1] = 9;
                     var10005[0] = 0;
                     Object[] var50 = var10005;
                     Integer var21 = InventoryUtil.eReturningBoxedInteger(var50);
                     int var160 = var18;
                     Integer var159 = var21;
                     Integer var119 = var159;
                     Integer var117 = var159;
                     if (var160 != 0) {
                        Integer var161 = var117;
                        if (var161 != null) {
                           ElapsedTimer var205 = this.e;
                           Object[] var53 = new Object[]{var14};
                           ElapsedTimer var52 = var205;
                           var52.aReturningVoid(var53);
                           ElapsedTimer var206 = this.g;
                           Object[] var55 = new Object[]{var14};
                           ElapsedTimer var54 = var206;
                           var54.aReturningVoid(var55);
                           Integer var56 = var21;
                           var213 = var56;
                           var225 = new Object[]{null, var10};
                           var225[0] = var213;
                           Object[] var58 = var225;
                           MacePot var57 = this;
                           return var57.bReturningdx_C0210(var58);
                        }

                        int var163 = var18;
                        byte var162 = 0;
                        var120 = var162;
                        byte var118 = var162;
                        if (var163 == 0) {
                           break label131;
                        }

                        short var214 = 10705;
                        var10002 = 6942652084002356344L ^ var2;
                        var10005 = new Object[]{null, null, StatusEffects.SPEED, var6};
                        var10005[1] = 36;
                        var10005[0] = Integer.valueOf(var118);
                        Object[] var60 = var10005;
                        Integer var164 = InventoryUtil.eReturningBoxedInteger(var60);
                        var119 = var164;
                     }

                     Integer var22 = var119;
                     Integer var165 = var22;
                     if (var165 != null) {
                        Integer var62 = var22;
                        var213 = var62;
                        var225 = new Object[]{null, var8};
                        var225[0] = var213;
                        Object[] var64 = var225;
                        MacePot var63 = this;
                        var63.jReturningVoid(var64);
                        ElapsedTimer var204 = this.e;
                        Object[] var66 = new Object[]{var14};
                        ElapsedTimer var65 = var204;
                        var65.aReturningVoid(var66);
                        return null;
                     }
                  }
               }

               var120 = var20;
            }

            int var167 = var18;
            byte var166 = var120;
            var127 = var166;
            byte var121 = var166;
            if (var167 == 0) {
               break label136;
            }

            byte var168 = var121;
            if (var168 == 0) {
               ElapsedTimer var207 = this.h;
               Object[] var228 = new Object[]{null, var12};
               var228[0] = 300.0F;
               Object[] var70 = var228;
               ElapsedTimer var69 = var207;
               var10000 = (((var69.aReturningBoolean(var70)) ? 1 : 0));
               int var170 = var18;
               byte var169 = ((byte)(var10000));
               var127 = var169;
               byte var122 = var169;
               if (var170 == 0) {
                  break label136;
               }

               byte var171 = var122;
               byte var123 = var171;
               byte var172 = var123;
               if (var172 != 0) {
                  int var217 = 24902;
                  long var223 = 3351011651187160300L ^ var2;
                  Object[] var233 = new Object[]{null, null, StatusEffects.STRENGTH, var6};
                  var233[1] = 9;
                  var233[0] = 0;
                  Object[] var73 = var233;
                  Integer var198 = InventoryUtil.eReturningBoxedInteger(var73);
                  int var174 = var18;
                  Integer var173 = var198;
                  Integer var126 = var173;
                  Integer var124 = var173;
                  if (var174 != 0) {
                     Integer var175 = var124;
                     if (var175 != null) {
                        ElapsedTimer var210 = this.e;
                        Object[] var76 = new Object[]{var14};
                        ElapsedTimer var75 = var210;
                        var75.aReturningVoid(var76);
                        ElapsedTimer var211 = this.h;
                        Object[] var78 = new Object[]{var14};
                        ElapsedTimer var77 = var211;
                        var77.aReturningVoid(var78);
                        Integer var79 = var198;
                        var217 = var79;
                        var228 = new Object[]{null, var10};
                        var228[0] = var217;
                        Object[] var81 = var228;
                        MacePot var80 = this;
                        return var80.bReturningdx_C0210(var81);
                     }

                     int var177 = var18;
                     byte var176 = 0;
                     var127 = var176;
                     byte var125 = var176;
                     if (var177 == 0) {
                        break label136;
                     }

                     short var218 = 18672;
                     var223 = 293991752585649496L ^ var2;
                     var233 = new Object[]{null, null, StatusEffects.STRENGTH, var6};
                     var233[1] = 36;
                     var233[0] = Integer.valueOf(var125);
                     Object[] var83 = var233;
                     Integer var178 = InventoryUtil.eReturningBoxedInteger(var83);
                     var126 = var178;
                  }

                  Integer var199 = var126;
                  Integer var179 = var199;
                  if (var179 != null) {
                     Integer var85 = var199;
                     var217 = var85;
                     var228 = new Object[]{null, var8};
                     var228[0] = var217;
                     Object[] var87 = var228;
                     MacePot var86 = this;
                     var86.jReturningVoid(var87);
                     ElapsedTimer var209 = this.e;
                     Object[] var89 = new Object[]{var14};
                     ElapsedTimer var88 = var209;
                     var88.aReturningVoid(var89);
                     return null;
                  }
               }
            }
         }

         var127 = var19;
      }

      int var181 = var18;
      byte var180 = var127;
      byte var129 = var180;
      byte var128 = var180;
      if (var181 != 0) {
         byte var182 = var128;
         if (var182 == 0) {
            return null;
         }

         var129 = var20;
      }

      byte var183 = var129;
      if (var183 != 0) {
         int var185 = var18;
         Integer var184 = this.i;
         Integer var132 = var184;
         Integer var130 = var184;
         if (var185 != 0) {
            Integer var186 = var130;
            Integer var131 = var186;
            Integer var187 = var131;
            if (var187 == null) {
               return null;
            }

            Integer var188 = this.j;
            var132 = var188;
         }

         MacePot var137;
         label155: {
            int var190 = var18;
            Integer var189 = var132;
            Object var136 = var189;
            Integer var133 = var189;
            if (var190 != 0) {
               Integer var191 = var133;
               if (var191 == null) {
                  return null;
               }

               Integer var96 = this.i;
               var10000 = var96;
               Integer var97 = this.j;
               int var221 = var97;
               Object[] var231 = new Object[]{null, null, var16};
               var231[1] = var221;
               var231[0] = var10000;
               Object[] var98 = var231;
               InventoryUtil.fReturningBoolean(var98);
               this.i = null;
               int var193 = var18;
               MacePot var192 = this;
               var137 = var192;
               MacePot var134 = var192;
               if (var193 == 0) {
                  break label155;
               }

               MacePot var194 = var134;
               MacePot var135 = var194;
               BooleanSetting var100 = var135.d;
               Object var195 = var100.aReturningObject();
               var136 = var195;
            }

            Boolean var102 = (Boolean)var136;
            boolean var196 = var102;
            if (!var196) {
               return null;
            }

            MacePot var197 = this;
            var137 = var197;
         }

         Object[] var105 = new Object[]{var4};
         MacePot var104 = var137;
         var104.aReturningVoid(var105);
         return null;
      } else {
         return null;
      }
   }

   private void jReturningVoid(Object[] var1) {
      int var2;
      long var5;
      long var7;
      long var9;
      MacePot var26;
      var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 54287098587801L ^ var3;
      var5 = var3 ^ 135985325760641L;
      var7 = var3 ^ 123535871348622L;
      var9 = var3 ^ 100669714032796L;
      int var11 = Event.bReturningInt();
      int var28 = var11;
      MacePot var27 = this;
      var26 = var27;
      MacePot var23 = var27;
      label20:
      if (var28 == 0) {
         Integer var29 = var23.i;
         if (var29 == null) {
            int var31 = var11;
            MacePot var30 = this;
            var26 = var30;
            MacePot var24 = var30;
            if (var31 != 0) {
               break label20;
            }

            MacePot var32 = var24;
            MacePot var25 = var32;
            Integer var33 = var25.j;
            if (var33 == null) {
               int var15 = var2;
               this.i = var15;
               Object[] var16 = new Object[]{var7};
               int var17 = InventoryUtil.aReturningInt(var16);
               this.j = var17;
            }
         }

         var26 = this;
      }

      ElapsedTimer var10000 = var26.f;
      Object[] var20 = new Object[]{var5};
      ElapsedTimer var19 = var10000;
      var19.aReturningVoid(var20);
      Object[] var21 = new Object[]{var7};
      int var10001 = InventoryUtil.aReturningInt(var21);
      Object[] var10004 = new Object[]{null, null, var9};
      var10004[1] = var10001;
      var10004[0] = var2;
      Object[] var22 = var10004;
      InventoryUtil.fReturningBoolean(var22);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 54287098587801L ^ var3;
      long var5 = var3 ^ 49925945292990L;
      FloatSetting var8 = this.c;
      Float var9 = (Float)var8.aReturningObject();
      float var10000 = var9 - 1.0F;
      Random var10 = RandomUtil.a;
      float var7 = var10000 + var10.nextFloat();
      Runnable var10001 = invokeBinding1(this);
      Object[] var10005 = new Object[]{null, null, null, var5};
      var10005[2] = true;
      var10005[1] = var10001;
      var10005[0] = var2;
      Object[] var11 = var10005;
      InventoryUtil.bReturningVoid(var11);
      MinecraftClient var12 = b;
      ClientPlayerEntity var13 = var12.player;
      return new Rotation(var13.getYaw(), var7);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      this.i = null;
   }

   private void lambda$throwPotion$0() {
      long var10001 = 61196170757206L ^ 4958617026267L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      ClientPlayerEntity var10000 = var8.player;
      FloatSetting var9 = this.c;
      Float var10 = (Float)var9.aReturningObject();
      float var18 = var10 - 1.0F;
      Random var11 = RandomUtil.a;
      float var13 = var18 + var11.nextFloat();
      ClientPlayerEntity var12 = var10000;
      var12.setPitch(var13);
      Object[] var14 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var14);
      MinecraftClient var15 = b;
      float var17 = var5;
      ClientPlayerEntity var16 = var15.player;
      var16.setPitch(var17);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(126512622281199L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[4];
      String var6 = "\u0007\u0005Jú|u¼Ì\u0006úA>\u0004\u0013c*";
      int var7 = "\u0007\u0005Jú|u¼Ì\u0006úA>\u0004\u0013c*".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     l = var8;
                     m = new Integer[4];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "ó\u0016@¤\u0019s\u0098\u0088i:\u001f¦¨\u0019Ô°";
                  var7 = "ó\u0016@¤\u0019s\u0098\u0088i:\u001f¦¨\u0019Ô°".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15818;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/e1", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e1",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 31;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 49;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 24;
            yield var21;
         }
         case 7 -> {
            byte var22 = 25;
            yield var22;
         }
         case 8 -> {
            byte var23 = 45;
            yield var23;
         }
         case 9 -> {
            byte var24 = 7;
            yield var24;
         }
         case 10 -> {
            byte var25 = 48;
            yield var25;
         }
         case 11 -> {
            byte var26 = 1;
            yield var26;
         }
         case 12 -> {
            byte var27 = 56;
            yield var27;
         }
         case 13 -> {
            byte var28 = 6;
            yield var28;
         }
         case 14 -> {
            byte var29 = 63;
            yield var29;
         }
         case 15 -> {
            byte var30 = 20;
            yield var30;
         }
         case 16 -> {
            byte var31 = 38;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 21;
            yield var33;
         }
         case 19 -> {
            byte var34 = 33;
            yield var34;
         }
         case 20 -> {
            byte var35 = 60;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 47;
            yield var37;
         }
         case 23 -> {
            byte var38 = 26;
            yield var38;
         }
         case 24 -> {
            byte var39 = 59;
            yield var39;
         }
         case 25 -> {
            byte var40 = 9;
            yield var40;
         }
         case 26 -> {
            byte var41 = 8;
            yield var41;
         }
         case 27 -> {
            byte var42 = 52;
            yield var42;
         }
         case 28 -> {
            byte var43 = 4;
            yield var43;
         }
         case 29 -> {
            byte var44 = 32;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 29;
            yield var46;
         }
         case 32 -> {
            byte var47 = 44;
            yield var47;
         }
         case 33 -> {
            byte var48 = 16;
            yield var48;
         }
         case 34 -> {
            byte var49 = 23;
            yield var49;
         }
         case 35 -> {
            byte var50 = 27;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 18;
            yield var52;
         }
         case 38 -> {
            byte var53 = 22;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 46;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 2;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 42;
            yield var59;
         }
         case 45 -> {
            byte var60 = 30;
            yield var60;
         }
         case 46 -> {
            byte var61 = 14;
            yield var61;
         }
         case 47 -> {
            byte var62 = 11;
            yield var62;
         }
         case 48 -> {
            byte var63 = 5;
            yield var63;
         }
         case 49 -> {
            byte var64 = 13;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 61;
            yield var66;
         }
         case 52 -> {
            byte var67 = 53;
            yield var67;
         }
         case 53 -> {
            byte var68 = 28;
            yield var68;
         }
         case 54 -> {
            byte var69 = 3;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 17;
            yield var71;
         }
         case 57 -> {
            byte var72 = 34;
            yield var72;
         }
         case 58 -> {
            byte var73 = 37;
            yield var73;
         }
         case 59 -> {
            byte var74 = 50;
            yield var74;
         }
         case 60 -> {
            byte var75 = 39;
            yield var75;
         }
         case 61 -> {
            byte var76 = 57;
            yield var76;
         }
         case 62 -> {
            byte var77 = 36;
            yield var77;
         }
         default -> 35;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "[Z[\u001eY\u001ePUJQ5\u001d^WH\u001e\u0019";
      o[1] = "\r!i\u001fMd\u0006.xP,j\r%|\n";
      o[2] = boolean.class;
      p[2] = "java/lang/Boolean";
      o[3] = "&tK)Z90tNsI.'?MuE:6xZb\u000e-\u0004";
      o[4] = "\u0012\u0002u+BS\u0004\u0002pqQD\u0013Isw]P\u0002\u000ed`\u0016G\u000f";
      o[5] = " %:S3dU\u00051\\\"+4\u000b:W&q@";
      o[6] = void.class;
      p[6] = "java/lang/Void";
      o[7] = " tNyjH6tK#y_!?H%uK0x_2>[(x]9d\u0016\u0014c]$dQ#t";
      o[8] = "R\u0003'lI\tR\u000300E\u0006HH0.E\u0013O9dv\u0012";
      o[9] = float.class;
      p[9] = "java/lang/Float";
      o[10] = "%\b(tar3\b-.re$C.(~q5\u00049?5a.";
      o[11] = "k#o!=\u007f\u001e\u0003d.,0\u007f\ro%(j\u000b";
      o[12] = "[{\u0007\u0013\u001dZ[{\u0010O\u0011UA0\u0010Q\u0011@FA@\f@";
      o[13] = "\u0016\u0014&\r=!\u001d\u001b7BU!\u0013\u0014$";
      o[14] = "\u0010fR8H:\u000enHw4.\u0014cK4";
      o[15] = "yI\u00058<0\fi\u000e7-\u007fmg\u0005<)%\u0019";
      o[16] = "\n\u0016:=;0\u0014\u001e rF \u0014";
      o[17] = "O`(C<YY`-\u0019/NN+.\u001f#Z_l9\bhJG";
      o[18] = "\u001f<]\u001dM1j\u001cV\u0012\\~\u000b\u0012]\u0019X$\u007f";
      o[19] = "c\u001c3n\\+c\u001c$2P$yW$,P1~&vr\u0007z";
      o[20] = "\u0010BgD<4eblK-{\u0004lg@)!p";
      o[21] = "\u001ce\u0011\u0016i\r\u0017j\u0000Y\u000e\u000f\u0002a\u0000\u00125";
      o[22] = "YH>\u000e\n\u001bOH;T\u0019\fX\u00038R\u0015\u0018ID/E^\rd";
      o[23] = "(EK\u0017M\u001d]e@\u0018\\R<kK\u0013X\bH";
      o[24] = "`?G\\QJ`?P\u0000]EztP\u001e]P}\u0005\u0005J\u0004\u0013";
      o[25] = "\u0012\f;Y\u001c\u000e\u0004\f>\u0003\u000f\u0019\u0013G=\u0005\u0003\r\u0002\u0000*\u0012H\u001bG";
      o[26] = "W)qM\u0018o\"\tzB\t C\u0007qI\rz7";
      o[27] = "]6S\u001f3\r]6DC?\u0002G}D]?\u0017@\f\u0013\u0002i";
      o[28] = "D\u001e#^<iR\u001e&\u0004/~EU%\u0002#jT\u00122\u0015hxe";
      o[29] = int.class;
      p[29] = "java/lang/Integer";
      o[30] = "b\u001aWJQ't\u001aR\u0010B0cQQ\u0016N$r\u0016F\u0001\u00053W";
      o[31] = "C\"g-P\u00196\u0002l\"AVW\fg)E\f#";
      o[32] = "b\\\u001cGu@b\\\u000b\u001byOx\u0017\u000b\u0005yZ\u007ffY[!\u001d";
      o[33] = "\u0006r\bt4dsR\u0003{%+\u0012\\\bp!qf";
      o[34] = ".l\\\u0017kr%cMX\b\u007f0nB3=}!}^\u001f*p";
      o[35] = "ZG;/p~/g0 a1Ni;+ek:";
      o[36] = "6\u0017kW>\u0012C7`X/]\"9kS+\u0007V";
      o[37] = "019D3f&1<\u001e q1z?\u0018,e =(\u000fgr,";
      o[38] = "}Wq*\u001dw\bwz%\f8iyq.\bb\u001d";
      o[39] = "i}20\\};:?7''\u000b`~?Mpt3?8JM";
      o[40] = "n+v(\u0018\u00152u(&x\u0019=ks(\u0014+n/.~x\u0013)u,(D\u001a(h/OA\u0002hgpw\u0011M+'\u0013";
      o[41] = "5<~0M?30=0v%1]|#\b$?9p1KB5<~0M?30=0v";
      o[42] = "m\u0004yf\u001a&fYblwz\r\u001fie\u0006qq\\rtN\u00181\u001ah0\u000b{2\u0017sfw";
      o[43] = "\ryt&@pW}xfqr\\w}w&%\u0002'$\u001b\u0013 _hge\tlV$";
      o[44] = "!vh\u001eJ }(6\u0010*,r6m\u001eF\u001e$t1D\u0016I!3d\u0001I6'vb\u0003*";
      o[45] = "\u0002\u000bK\t{\u0003E\u000f\r\u0018\u001d\u00179HU\tl\u0012E\u000bN\u0018${\u0005MT\\a\u0018\u0006@O\n\u001d";
      o[46] = " k`\u0006pBmn?8\u000faXZI8}Bx?5R0G'";
      o[47] = "C\u0004d\u0003! \u001fZ:\rA,\u0010Da\u0003-\u001eF\u0006=Y~ICAh\u001c\"6E\u0004n\u001eAu\u0001Y>\u0018\"v\fBhd";
      o[48] = "To\u001e\t\u0015}\u000ek\u0012I$t\tp\u0013SHF]1M\u0005$(\u001a4\u0003W\u001cxUwC4";
      o[49] = "\\&Ye.p\u0011#\u0006[u}\u0007(P2yD\t(@6\u001f#\u001etM8'sQ7\r[";
      o[50] = "\n\u0011B8i\\XVO?\u0012\u0007h\f\u000e7xQ\u0017_O0\u007fl";
      o[51] = "n@ccOe2\u001e=m/i=\u0000fcC[j@6>\u001f\fi\u0002>tL49M}4/";
      o[52] = "GJJwVM\u0003^Dq3\u001e}NVkU\u0017\u0019BD(3";
      o[53] = "[JC\\\u007fwS\u001c\u0002\u001d\u0016d0\u0003\u0012\u000bgfL@\t\u001a/\u000f\t\u0004J\u0011u7YK\tQ\u0016";
      o[54] = "o\u0012\u000f\u0018\u0005I<]\u0015\u001e~\u0010d\u0011.K\u001a\fom\u0013\u001c\u001f\u001b?\u0012@]\u0018\u001c\u0002";
      o[55] = "eq\u0014*\u0013R\"uR;uG^2\n*\u0004C\"q\u0011;L*b7\u000b\u007f\tIa:\u0010)u";
      o[56] = "g<'\u0000\u0016\u001f;by\u000ev\u00134|\"\u0000\u001a!b>~ZKvgy+\u001f\u0015\ta<-\u001dv";
      o[57] = ".:g\u0003uWt>kCDU\u007f4nR\u0013\u0002!c6>z\u0007{>jW&Y%0";
      o[58] = "zu7 |^v&6}\u0000T\u0014c8&qTh #79=(f9s|^+k\"%\u0000";
      o[59] = "\f\t+\u0015\u0007E\u0007T0\u001fj\u0012l\fg@\u0015\u0006\u0015\u000f)M\t{\u000bWg\u0003\u0017\u0002\b\u0019j\u001fj";
      o[60] = "u\nC^@\u0019t\u0019JH=\u0005H\\\u001cLW\u00040\u001b\u0018\nF";
      o[61] = "GP!/R\u0018\u0013Kj9hOy[3>\u0019O\u0005\u0018(/Q&\u001a\u001c2>UYI]59h";
      o[62] = "/T<\u0002#o$\t'\bN;OO,\u0001?83\f7\u0010wQ6\\+\u0013,,3D.\rN";
      o[63] = "o>\u0014*\u0017\u000f;%_<-\\Q5\u0006;\\X-v\u001d*\u00141<3\u0019kV\to|\u0003m-";
      o[64] = "G\u0002aKS\u0000\u0014M{M(FC\u0019c\u001coV*\u001e \u0010B\u0005UMa\u0017E8G\u0002aKS\u0000\u0014M{M(";
      o[65] = ",y\u0001\u0011?\u001da|^/c\u000emz\u0001T\u000e\u000bsm\u0003Oj\u0007a.e\u0016pO`p]F?\f \u0013";
      o[66] = "c\u00061\u000fH[oU0R4Q\r\u0010>\tEQqS%\u0018\r84\u0017f\u0013W\u0000dX%S4";
      o[67] = "m:s:Hd9!8,r0S1a+\u00033/rz:KZo4`~\u000e9l9{(r";
      o[68] = "?o\u001c~Gd1dLp7w[-\u001c$Fw'n\u00075\u000e\u001eg(\u001dqK}d%\u0006'7";
      o[69] = "\u0015BaKx\\H\u0002h\u000bGY\u0011Vb\\\u0010\nA\u0002>0(N\u0012\u0004a\f!O\u000f\u0007";
      o[70] = "y!2I.}(6oSP~,+7^\u000ey,13\"ni!4=]h,'6^";
      o[71] = "1D\u00143\u000f9<F\u000f<oj<H\n:89m\u001d^V\u0003e'@\u000ek\u000eg<O";
      o[72] = "y\u0003\u0004\"-woUP+\\-}C\u0014T8,yOh$%\"hP\u0017\"`$j3";
      o[73] = "E\u0012A\u0010Y\u0013\u0018RHPf\u0016A\u0006B\u00071E\u0011S\u001ak\t\u0001BTAW\u0000\u0000_W";
      o[74] = ".xpv@Uzc;`z\u0005\u0010sbg\u000b\u0002l0yvCk)t:}\u0019Sy;y=z";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(83448371149853L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(83448371149853L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(83448371149853L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 121;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 227;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 80;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 254;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 222;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 101;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 121;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 227;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 80;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e1",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(MacePot var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e1;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e1", "lambda$throwPotion$0", "()V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((MacePot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
