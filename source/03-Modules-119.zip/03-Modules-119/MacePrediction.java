package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class MacePrediction extends Module {
   private static final double a = 0.08;
   private static final double b = 0.98;
   private static final double c = 0.999;
   private ModeSetting d;
   private BooleanSetting e;
   private IntSetting f;
   private ColorSetting g;
   private ColorSetting h;
   private BooleanSetting i;
   private IntSetting j;
   private ColorSetting k;
   private BooleanSetting l;
   private ColorSetting m;
   private ColorSetting n;
   private FloatSetting o;
   private static final long p = 91919782420863L;
   private static final String[] q;
   private static final String[] r;
   private static final Map s = new HashMap(13);
   private static final Object[] t = new Object[88];
   private static final String[] u = new String[88];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public MacePrediction() {
      super();
      long var10001 = 40468903752945L ^ 1590874044337L;
      var10001 = 40468903752945L ^ 65664481183270L;
      var10001 = 40468903752945L ^ 3611041632019L;

      ColorSetting var10000 = this.k;
      Object[] var10 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var9 = var10000;
      var9.aReturningColorSetting(var10);
      var10000 = this.m;
      Object[] var12 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var11 = var10000;
      var11.aReturningColorSetting(var12);
      var10000 = this.h;
      Object[] var14 = new Object[]{invokeBinding3(this), 41489415177024L};
      ColorSetting var13 = var10000;
      var13.aReturningColorSetting(var14);
      IntSetting var27 = this.f;
      Object[] var16 = new Object[]{invokeBinding4(this), 43459238656994L};
      IntSetting var15 = var27;
      var15.aReturningIntSetting(var16);
      FloatSetting var28 = this.o;
      Object[] var18 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var17 = var28;
      var17.aReturningFloatSetting(var18);
      var10000 = this.g;
      Object[] var20 = new Object[]{invokeBinding6(this), 41489415177024L};
      ColorSetting var19 = var10000;
      var19.aReturningColorSetting(var20);
      var10000 = this.n;
      Object[] var22 = new Object[]{invokeBinding7(this), 41489415177024L};
      ColorSetting var21 = var10000;
      var21.aReturningColorSetting(var22);
      IntSetting var31 = this.j;
      Object[] var24 = new Object[]{invokeBinding8(this), 43459238656994L};
      IntSetting var23 = var31;
      var23.aReturningIntSetting(var24);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 68499856241428L ^ 69406333602135L;
      var10001 = 68499856241428L ^ 81299709436281L;
      var10001 = 68499856241428L ^ 111826614017692L;
      var10001 = 68499856241428L ^ 418121577178L;
      var10001 = 68499856241428L ^ 139626157090327L;
      var10001 = 68499856241428L ^ 131977082700293L;
      var10001 = 68499856241428L ^ 123267934454109L;
      int var10000 = Event.bReturningInt();
      Object[] var21 = new Object[]{77260333461777L};
      PlayerEntity var19 = EntityUtil.aReturningPlayerEntity(var21);
      int var18 = var10000;
      int var78 = var18;
      PlayerEntity var77 = var19;
      PlayerEntity var67 = var77;
      PlayerEntity var66 = var77;
      if (var78 == 0) {
         PlayerEntity var79 = var66;
         if (var79 == null) {
            return;
         }

         var67 = var19;
      }

      MacePrediction var74;
      label68: {
         Object[] var23 = new Object[]{var67, 86106861941321L};
         double var122;
         var10000 = (var122 = RaycastUtil.aReturningDouble(var23) - 0.3F) == 0.0 ? 0 : (var122 < 0.0 ? -1 : 1);
         int var81 = var18;
         int var80 = var10000;
         int var73 = var80;
         int var68 = var80;
         if (var81 == 0) {
            int var82 = var68;
            if (var82 < 0) {
               BooleanSetting var25 = this.i;
               Boolean var26 = (Boolean)var25.aReturningObject();
               boolean var83 = var26;
               if (!var83) {
                  return;
               }

               Object[] var29 = new Object[]{var19, 131657085751917L};
               Vec3d var20 = RaycastUtil.aReturningVec3d(var29);
               int var85 = var18;
               MacePrediction var84 = this;
               MacePrediction var70 = var84;
               MacePrediction var69 = var84;
               if (var85 == 0) {
                  BooleanSetting var30 = var69.l;
                  Boolean var31 = (Boolean)var30.aReturningObject();
                  boolean var86 = var31;
                  if (var86) {
                     RenderContext var100 = var1.b;
                     MeshBufferManager var108 = var1.a;
                     Vec3d var33 = var20;
                     float var10002 = (float)var33.x;
                     Vec3d var34 = var20;
                     float var10003 = (float)var34.y;
                     Vec3d var35 = var20;
                     float var10004 = (float)var35.z;
                     ColorSetting var36 = this.m;
                     Color var10006 = (Color)var36.aReturningObject();
                     Object[] var10010 = new Object[]{null, null, 1456904419907L};
                     var10010[1] = 0.8F;
                     var10010[0] = var10006;
                     Object[] var37 = var10010;
                     var10006 = ClientUiUtil.bReturningColor(var37);
                     ColorSetting var38 = this.n;
                     Color var10007 = (Color)var38.aReturningObject();
                     FloatSetting var39 = this.o;
                     Float var40 = (Float)var39.aReturningObject();
                     float var10008 = 0.2F * (var40 / 255.0F);
                     Object[] var10011 = new Object[]{null, null, 1456904419907L};
                     var10011[1] = var10008;
                     var10011[0] = var10007;
                     Object[] var41 = var10011;
                     var10010 = new Object[]{null, null, null, null, null, null, var10006, ClientUiUtil.bReturningColor(var41), 68365215711694L};
                     var10010[5] = 3.0F;
                     var10010[4] = var10004;
                     var10010[3] = var10003;
                     var10010[2] = var10002;
                     var10010[1] = var108;
                     var10010[0] = var100;
                     Object[] var42 = var10010;
                     ShapeRenderer.dReturningVoid(var42);
                  }

                  var70 = this;
               }

               Object[] var45 = new Object[]{var19, var1, 71132760216835L};
               MacePrediction var44 = var70;
               var44.jReturningVoid(var45);
               int var87 = var18;
               if (var87 == 0) {
                  return;
               }
            }

            int var89 = var18;
            MacePrediction var88 = this;
            var74 = var88;
            MacePrediction var71 = var88;
            if (var89 != 0) {
               break label68;
            }

            MacePrediction var90 = var71;
            MacePrediction var72 = var90;
            BooleanSetting var47 = var72.e;
            Boolean var48 = (Boolean)var47.aReturningObject();
            byte var91 = ((byte)(((java.lang.Boolean)(var48)).booleanValue() ? 1 : 0));
            var73 = var91;
         }

         int var92 = var73;
         if (var92 == 0) {
            return;
         }

         var74 = this;
      }

      Object[] var51 = new Object[]{var19, var1, 101122656431496L};
      MacePrediction var50 = var74;
      Vec3d var98 = var50.aReturningVec3d(var51);
      int var94 = var18;
      Vec3d var93 = var98;
      Object var76 = var93;
      Vec3d var75 = var93;
      if (var94 == 0) {
         Vec3d var95 = var75;
         if (var95 == null) {
            return;
         }

         BooleanSetting var53 = this.l;
         Object var96 = var53.aReturningObject();
         var76 = var96;
      }

      Boolean var55 = (Boolean)var76;
      boolean var97 = var55;
      if (var97) {
         RenderContext var101 = var1.b;
         MeshBufferManager var109 = var1.a;
         Vec3d var56 = var98;
         float var110 = (float)var56.x;
         Vec3d var57 = var98;
         float var111 = (float)var57.y;
         Vec3d var58 = var98;
         float var112 = (float)var58.z;
         ColorSetting var59 = this.m;
         Color var114 = (Color)var59.aReturningObject();
         Object[] var119 = new Object[]{null, null, 1456904419907L};
         var119[1] = 0.8F;
         var119[0] = var114;
         Object[] var60 = var119;
         var114 = ClientUiUtil.bReturningColor(var60);
         ColorSetting var61 = this.n;
         Color var116 = (Color)var61.aReturningObject();
         FloatSetting var62 = this.o;
         Float var63 = (Float)var62.aReturningObject();
         float var117 = 0.2F * (var63 / 255.0F);
         Object[] var121 = new Object[]{null, null, 1456904419907L};
         var121[1] = var117;
         var121[0] = var116;
         Object[] var64 = var121;
         var119 = new Object[]{null, null, null, null, null, null, var114, ClientUiUtil.bReturningColor(var64), 68365215711694L};
         var119[5] = 3.0F;
         var119[4] = var112;
         var119[3] = var111;
         var119[2] = var110;
         var119[1] = var109;
         var119[0] = var101;
         Object[] var65 = var119;
         ShapeRenderer.dReturningVoid(var65);
      }
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      Entity var5 = (Entity)var1[0];
      Render3DEvent var2 = (Render3DEvent)var1[1];
      long var3 = (Long)var1[2];
      var3 = 91919782420863L ^ var3;
      long var6 = var3 ^ 140582939614874L;
      long var8 = var3 ^ 95504004417144L;
      int var10000 = Event.bReturningInt();
      Object[] var17 = new Object[]{var5, var6};
      Vec3d var11 = RaycastUtil.aReturningVec3d(var17);
      int var10 = var10000;
      Entity var18 = var5;
      Vec3d var12 = var18.getVelocity();
      Vec3d var13 = var11;
      Vec3d var14 = null;
      BlockPos var16;
      label59: {
         while (true) {
            IntSetting var19 = this.f;
            Integer var20 = (Integer)var19.aReturningObject();
            int var83 = var20;
            int var82 = var15;
            if (var82 < var83) {
               var13 = var11;
               Vec3d var22 = var12;
               Vec3d var21 = var11;
               Vec3d var103 = var21.add(var22);
               int var85 = var10;
               Vec3d var84 = var103;
               Vec3d var81 = var84;
               Vec3d var72 = var84;
               if (var85 != 0) {
                  return var81;
               }

               var11 = var72;
               Vec3d var23 = var11;
               double var24 = var23.x;
               int var10002 = (int)Math.floor(var24);
               Vec3d var26 = var11;
               double var27 = var26.y - 0.1;
               int var10003 = (int)Math.floor(var27);
               Vec3d var29 = var11;
               double var30 = var29.z;
               var16 = new BlockPos(var10002, var10003, (int)Math.floor(var30));
               int var86 = var10;
               if (var86 != 0) {
                  break label59;
               }

               Entity var32 = var5;
               World var104 = var32.getEntityWorld();
               BlockPos var34 = var16;
               World var33 = var104;
               BlockState var35 = var33.getBlockState(var34);
               boolean var87 = var35.isAir();
               if (!var87) {
                  break;
               }

               int var89 = var10;
               Vec3d var88 = var11;
               Vec3d var75 = var88;
               Vec3d var73 = var88;
               if (var89 == 0) {
                  Vec3d var90 = var73;
                  Vec3d var74 = var90;
                  Vec3d var38 = var74;
                  double var105 = var38.y;
                  Entity var39 = var5;
                  World var40 = var39.getEntityWorld();
                  double var108;
                  int var91 = (var108 = var105 - var40.getBottomY()) == 0.0 ? 0 : (var108 < 0.0 ? -1 : 1);
                  if (var91 <= 0) {
                     break;
                  }

                  var75 = var14;
               }

               Vec3d var80;
               label46: {
                  label45: {
                     int var93 = var10;
                     Vec3d var92 = var75;
                     Vec3d var79 = var92;
                     Vec3d var76 = var92;
                     if (var93 == 0) {
                        Vec3d var94 = var76;
                        if (var94 != null) {
                           int var96 = var10;
                           Vec3d var95 = var14;
                           var80 = var95;
                           Vec3d var77 = var95;
                           if (var96 != 0) {
                              break label46;
                           }

                           Vec3d var97 = var77;
                           Vec3d var78 = var97;
                           Vec3d var52 = var11;
                           Vec3d var51 = var78;
                           double var109;
                           int var98 = (var109 = var51.squaredDistanceTo(var52) - 0.1) == 0.0 ? 0 : (var109 < 0.0 ? -1 : 1);
                           if (var98 < 0) {
                              break label45;
                           }
                        }

                        ColorSetting var54 = this.g;
                        Object[] var56 = new Object[]{var11, (Color)var54.aReturningObject(), var2, var8};
                        MacePrediction var55 = this;
                        var55.lReturningVoid(var56);
                        Vec3d var99 = var11;
                        var79 = var99;
                     }

                     var14 = var79;
                  }

                  double var61 = 0.08;
                  Vec3d var58 = var12;
                  var12 = var58.subtract(var59, var61, var63);
                  double var70 = 0.98;
                  double var68 = 0.98;
                  double var66 = 0.98;
                  Vec3d var65 = var12;
                  var80 = var65.multiply(var66, var68, var70);
               }

               var12 = var80;
               var15++;
               int var100 = var10;
               if (var100 == 0) {
                  continue;
               }
            }

            Vec3d var110 = var13;
            return var110;
         }

         ColorSetting var42 = this.h;
         Object[] var44 = new Object[]{var13, (Color)var42.aReturningObject(), var2, var8};
         MacePrediction var43 = this;
         var43.lReturningVoid(var44);
      }

      Vec3d var46 = var13;
      double var106 = var46.x;
      BlockPos var47 = var16;
      double var107 = var47.getY() + 1;
      Vec3d var48 = var13;
      return new Vec3d(var106, var107, var48.z);
   }

   private void jReturningVoid(Object[] var1) {
      PlayerEntity var3 = (PlayerEntity)var1[0];
      Render3DEvent var2 = (Render3DEvent)var1[1];
      long var4 = (Long)var1[2];
      var4 = 91919782420863L ^ var4;
      long var6 = var4 ^ 104281008535949L;
      long var8 = var4 ^ 75975957221167L;
      long var10 = var4 ^ 110593575560721L;
      Object[] var15 = new Object[]{var3, var10};
      Vec3d var12 = RaycastUtil.aReturningVec3d(var15);
      Object[] var16 = new Object[]{var3, var6};
      Vec3d var13 = RaycastUtil.cReturningVec3d(var16);
      Vec3d var17 = var12;
      Vec3d var18 = var13;
      double var10002 = var17.x - var18.x;
      Vec3d var19 = var12;
      Vec3d var20 = var12;
      Vec3d var21 = var13;
      Vec3d var14 = new Vec3d(var10002, var19.y, var20.z - var21.z);
      Object[] var23 = new Object[]{var3, var12, var14, var2, var8};
      MacePrediction var22 = this;
      var22.kReturningVoid(var23);
   }

   private void kReturningVoid(Object[] var1) {
      PlayerEntity var3 = (PlayerEntity)var1[0];
      Vec3d var4 = (Vec3d)var1[1];
      Vec3d var5 = (Vec3d)var1[2];
      Render3DEvent var2 = (Render3DEvent)var1[3];
      long var6 = (Long)var1[4];
      var6 = 91919782420863L ^ var6;
      long var8 = var6 ^ 100149756809379L;
      int var10000 = Event.bReturningInt();
      Vec3d var11 = var4;
      Vec3d var12 = var5;
      int var10 = var10000;
      Vec3d var13 = null;
      int var109;
      do {
         IntSetting var16 = this.j;
         Integer var17 = (Integer)var16.aReturningObject();
         int var83 = var17;
         int var82 = var14;
         if (var82 >= var83) {
            break;
         }

         Vec3d var77;
         label77: {
            int var74;
            label78: {
               Vec3d var18 = var12;
               Vec3d var19 = var12;
               double var25 = var19.z;
               double var21 = var18.x;
               Vec3d var20 = var11;
               var11 = var20.add(var21, var23, var25);
               Vec3d var27 = var11;
               double var28 = var27.x;
               int var10002 = (int)Math.floor(var28);
               Vec3d var30 = var11;
               double var31 = var30.y - 0.1;
               int var10003 = (int)Math.floor(var31);
               Vec3d var33 = var11;
               double var34 = var33.z;
               BlockPos var15 = new BlockPos(var10002, var10003, (int)Math.floor(var34));
               int var84 = var10;
               if (var84 == 0) {
                  PlayerEntity var36 = var3;
                  World var85 = var36.getEntityWorld();
                  if (var85 != null) {
                     PlayerEntity var38 = var3;
                     World var111 = var38.getEntityWorld();
                     BlockPos var40 = var15;
                     World var39 = var111;
                     BlockState var41 = var39.getBlockState(var40);
                     byte var112 = ((byte)((var41.isAir()) ? 1 : 0));
                     int var87 = var10;
                     byte var86 = var112;
                     var74 = var86;
                     byte var71 = var86;
                     if (var87 != 0) {
                        break label78;
                     }

                     byte var88 = var71;
                     byte var72 = var88;
                     byte var89 = var72;
                     if (var89 != 0) {
                        int var90 = var10;
                        if (var90 == 0) {
                           break;
                        }
                     }
                  }

                  double var50 = 0.999;
                  double var48 = 1.0;
                  double var46 = 0.999;
                  Vec3d var45 = var12;
                  var12 = var45.multiply(var46, var48, var50);
               }

               int var92 = var10;
               Vec3d var91 = var12;
               var77 = var91;
               Vec3d var73 = var91;
               if (var92 != 0) {
                  break label77;
               }

               Vec3d var52 = var73;
               double var53 = var52.x;
               double var113;
               int var93 = (var113 = Math.abs(var53) - 0.005) == 0.0 ? 0 : (var113 < 0.0 ? -1 : 1);
               var74 = var93;
            }

            int var94 = var74;
            if (var94 < 0) {
               int var96 = var10;
               Vec3d var95 = var12;
               var77 = var95;
               Vec3d var75 = var95;
               if (var96 != 0) {
                  break label77;
               }

               Vec3d var97 = var75;
               Vec3d var76 = var97;
               Vec3d var57 = var76;
               double var58 = var57.z;
               double var114;
               int var98 = (var114 = Math.abs(var58) - 0.005) == 0.0 ? 0 : (var114 < 0.0 ? -1 : 1);
               if (var98 < 0) {
                  int var99 = var10;
                  if (var99 == 0) {
                     break;
                  }
               }
            }

            Vec3d var100 = var13;
            var77 = var100;
         }

         label52: {
            Vec3d var81;
            int var102 = var10;
            Vec3d var101 = var77;
            var81 = var101;
            Vec3d var78 = var101;
            label51:
            if (var102 == 0) {
               Vec3d var103 = var78;
               if (var103 != null) {
                  int var105 = var10;
                  Vec3d var104 = var13;
                  var81 = var104;
                  Vec3d var79 = var104;
                  if (var105 != 0) {
                     break label51;
                  }

                  Vec3d var106 = var79;
                  Vec3d var80 = var106;
                  Vec3d var66 = var11;
                  Vec3d var65 = var80;
                  double var115;
                  int var107 = (var115 = var65.squaredDistanceTo(var66) - 0.1) == 0.0 ? 0 : (var115 < 0.0 ? -1 : 1);
                  if (var107 < 0) {
                     break label52;
                  }
               }

               ColorSetting var68 = this.k;
               Object[] var70 = new Object[]{var11, (Color)var68.aReturningObject(), var2, var8};
               MacePrediction var69 = this;
               var69.lReturningVoid(var70);
               Vec3d var108 = var11;
               var81 = var108;
            }

            var13 = var81;
         }

         var14++;
         var109 = var10;
      } while (var109 == 0);
   }

   public void lReturningVoid(Object[] var1) {
      Color var2;
      Render3DEvent var3;
      Vec3d var4;
      long var7;
      long var9;
      long var11;
      int var13;
      int var70;
      var4 = (Vec3d)var1[0];
      var2 = (Color)var1[1];
      var3 = (Render3DEvent)var1[2];
      long var5 = (Long)var1[3];
      var5 = 91919782420863L ^ var5;
      var7 = var5 ^ 13705240957363L;
      var9 = var5 ^ 125155335576624L;
      var11 = var5 ^ 120229882788852L;
      int var10000 = Event.cReturningInt();
      ModeSetting var16 = this.d;
      String var14 = (String)var16.aReturningObject();
      var13 = var10000;
      // String var17 = var14;
      var10000 = var17.hashCode();
      int var72 = var13;
      int var71 = var10000;
      var70 = var71;
      int var63 = var71;
      label53:
      if (var72 != 0) {
         int var73 = var63;
         switch (var73) {
            case 66987:
               short var10001 = 3762;
               long var10002 = 6316633653002347433L ^ var5;
               String var20 = "Box";
               String var19 = var14;
               byte var93 = ((byte)((var19.equals(var20)) ? 1 : 0));
               int var75 = var13;
               byte var74 = var93;
               var70 = var74;
               byte var64 = var74;
               if (var75 == 0) {
                  break label53;
               }

               byte var76 = var64;
               byte var65 = var76;
               byte var77 = var65;
               if (var77 == 0) {
                  break;
               }

               var15 = 0;
               int var78 = var13;
               if (var78 != 0) {
                  break;
               }
            case 558407714:
               short var100 = 32589;
               long var106 = 4155094395833307735L ^ var5;
               String var24 = "Outline";
               String var23 = var14;
               byte var94 = ((byte)((var23.equals(var24)) ? 1 : 0));
               int var80 = var13;
               byte var79 = var94;
               var70 = var79;
               byte var66 = var79;
               if (var80 == 0) {
                  break label53;
               }

               byte var81 = var66;
               byte var67 = var81;
               byte var82 = var67;
               if (var82 == 0) {
                  break;
               }

               var15 = 1;
               int var83 = var13;
               if (var83 != 0) {
                  break;
               }
            case 2076577:
               short var101 = 23302;
               long var107 = 4444114397636785694L ^ var5;
               String var28 = "Both";
               String var27 = var14;
               byte var95 = ((byte)((var27.equals(var28)) ? 1 : 0));
               int var85 = var13;
               byte var84 = var95;
               var70 = var84;
               byte var68 = var84;
               if (var85 == 0) {
                  break label53;
               }

               byte var86 = var68;
               byte var69 = var86;
               byte var87 = var69;
               if (var87 != 0) {
                  var15 = 2;
               }
         }

         var70 = var15;
      }

      int var88 = var70;
      switch (var88) {
         case 0:
            RenderContext var96 = var3.b;
            MeshBufferManager var102 = var3.a;
            Vec3d var31 = var4;
            float var108 = (float)var31.x - 0.25F;
            Vec3d var32 = var4;
            float var10003 = (float)var32.y;
            Vec3d var33 = var4;
            float var10004 = (float)var33.z - 0.25F;
            Vec3d var34 = var4;
            float var10005 = (float)var34.x + 0.25F;
            Vec3d var35 = var4;
            float var10006 = (float)var35.y + 2.0F;
            Vec3d var36 = var4;
            float var10007 = (float)var36.z + 0.25F;
            Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var2, var9};
            var10011[7] = var10007;
            var10011[6] = var10006;
            var10011[5] = var10005;
            var10011[4] = var10004;
            var10011[3] = var10003;
            var10011[2] = var108;
            var10011[1] = var102;
            var10011[0] = var96;
            Object[] var37 = var10011;
            ShapeRenderer.hReturningVoid(var37);
            int var89 = var13;
            if (var89 != 0) {
               break;
            }
         case 1:
            RenderContext var97 = var3.b;
            MeshBufferManager var103 = var3.a;
            Vec3d var39 = var4;
            float var109 = (float)var39.x - 0.25F;
            Vec3d var40 = var4;
            float var112 = (float)var40.y;
            Vec3d var41 = var4;
            float var115 = (float)var41.z - 0.25F;
            Vec3d var42 = var4;
            float var118 = (float)var42.x + 0.25F;
            Vec3d var43 = var4;
            float var121 = (float)var43.y + 2.0F;
            Vec3d var44 = var4;
            float var124 = (float)var44.z + 0.25F;
            Object[] var127 = new Object[]{null, null, null, null, null, null, null, null, var2, var11};
            var127[7] = var124;
            var127[6] = var121;
            var127[5] = var118;
            var127[4] = var115;
            var127[3] = var112;
            var127[2] = var109;
            var127[1] = var103;
            var127[0] = var97;
            Object[] var45 = var127;
            ShapeRenderer.gReturningVoid(var45);
            int var90 = var13;
            if (var90 != 0) {
               break;
            }
         case 2:
            RenderContext var98 = var3.b;
            MeshBufferManager var104 = var3.a;
            Vec3d var47 = var4;
            float var110 = (float)var47.x - 0.25F;
            Vec3d var48 = var4;
            float var113 = (float)var48.y;
            Vec3d var49 = var4;
            float var116 = (float)var49.z - 0.25F;
            Vec3d var50 = var4;
            float var119 = (float)var50.x + 0.25F;
            Vec3d var51 = var4;
            float var122 = (float)var51.y + 2.0F;
            Vec3d var52 = var4;
            float var125 = (float)var52.z + 0.25F;
            Color var53 = var2;
            float var10009 = var53.getAlpha() / 255.0F * 0.5F;
            Object[] var10012 = new Object[]{null, null, var7};
            var10012[1] = var10009;
            var10012[0] = var2;
            Object[] var54 = var10012;
            Object[] var128 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.bReturningColor(var54), var9};
            var128[7] = var125;
            var128[6] = var122;
            var128[5] = var119;
            var128[4] = var116;
            var128[3] = var113;
            var128[2] = var110;
            var128[1] = var104;
            var128[0] = var98;
            Object[] var55 = var128;
            ShapeRenderer.hReturningVoid(var55);
            RenderContext var99 = var3.b;
            var104 = var3.a;
            Vec3d var56 = var4;
            var110 = (float)var56.x - 0.25F;
            Vec3d var57 = var4;
            var113 = (float)var57.y;
            Vec3d var58 = var4;
            var116 = (float)var58.z - 0.25F;
            Vec3d var59 = var4;
            var119 = (float)var59.x + 0.25F;
            Vec3d var60 = var4;
            var122 = (float)var60.y + 2.0F;
            Vec3d var61 = var4;
            var125 = (float)var61.z + 0.25F;
            var128 = new Object[]{null, null, null, null, null, null, null, null, var2, var11};
            var128[7] = var125;
            var128[6] = var122;
            var128[5] = var119;
            var128[4] = var116;
            var128[3] = var113;
            var128[2] = var110;
            var128[1] = var104;
            var128[0] = var99;
            Object[] var62 = var128;
            ShapeRenderer.gReturningVoid(var62);
      }
   }

   private boolean lambda$new$7(Float var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$6(Color var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$5(Color var1) {
      BooleanSetting var4 = this.l;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$4(Color var1) {
      BooleanSetting var4 = this.i;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$3(Integer var1) {
      BooleanSetting var4 = this.i;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Color var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Color var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Integer var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(37894167399482L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      String var6 = "i\u0007Ãx\u0081À?\u0093\u009eq\u008d0=çI?\u0010\u0006ÊÙîü\u0006ù!\u001d¯\u008e\fû\u0012°e\u0010½ðÔÿ.³àrÖ]Toi%\u009aW";
      int var8 = "i\u0007Ãx\u0081À?\u0093\u009eq\u008d0=çI?\u0010\u0006ÊÙîü\u0006ù!\u001d¯\u008e\fû\u0012°e\u0010½ðÔÿ.³àrÖ]Toi%\u009aW".length();
      char var5 = 16;
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            q = var9;
            r = new String[3];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18154;
      if (r[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])s.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e2", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = q[var5].getBytes("ISO-8859-1");
         r[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return r[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e2",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = u[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = t[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 60;
            yield var16;
         }
         case 2 -> {
            byte var17 = 21;
            yield var17;
         }
         case 3 -> {
            byte var18 = 27;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 2;
            yield var20;
         }
         case 6 -> {
            byte var21 = 40;
            yield var21;
         }
         case 7 -> {
            byte var22 = 35;
            yield var22;
         }
         case 8 -> {
            byte var23 = 58;
            yield var23;
         }
         case 9 -> {
            byte var24 = 11;
            yield var24;
         }
         case 10 -> {
            byte var25 = 3;
            yield var25;
         }
         case 11 -> {
            byte var26 = 63;
            yield var26;
         }
         case 12 -> {
            byte var27 = 26;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 47;
            yield var29;
         }
         case 15 -> {
            byte var30 = 36;
            yield var30;
         }
         case 16 -> {
            byte var31 = 37;
            yield var31;
         }
         case 17 -> {
            byte var32 = 25;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 50;
            yield var35;
         }
         case 21 -> {
            byte var36 = 16;
            yield var36;
         }
         case 22 -> {
            byte var37 = 7;
            yield var37;
         }
         case 23 -> {
            byte var38 = 34;
            yield var38;
         }
         case 24 -> {
            byte var39 = 32;
            yield var39;
         }
         case 25 -> {
            byte var40 = 57;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 51;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 29;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 17;
            yield var48;
         }
         case 34 -> {
            byte var49 = 1;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 31;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 6;
            yield var54;
         }
         case 40 -> {
            byte var55 = 13;
            yield var55;
         }
         case 41 -> {
            byte var56 = 30;
            yield var56;
         }
         case 42 -> {
            byte var57 = 14;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 55;
            yield var59;
         }
         case 45 -> {
            byte var60 = 18;
            yield var60;
         }
         case 46 -> {
            byte var61 = 45;
            yield var61;
         }
         case 47 -> {
            byte var62 = 54;
            yield var62;
         }
         case 48 -> {
            byte var63 = 28;
            yield var63;
         }
         case 49 -> {
            byte var64 = 48;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 5;
            yield var66;
         }
         case 52 -> {
            byte var67 = 33;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 56;
            yield var69;
         }
         case 55 -> {
            byte var70 = 61;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 22;
            yield var72;
         }
         case 58 -> {
            byte var73 = 24;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 59;
            yield var75;
         }
         case 61 -> {
            byte var76 = 44;
            yield var76;
         }
         case 62 -> {
            byte var77 = 9;
            yield var77;
         }
         default -> 39;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            u[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      t[0] = "\u00195(T|9\u000f5-\u000eo.\u0018~.\bc:\t99\u001f(,O";
      t[1] = ">'1|S!5( 30, %/X\u0005.163t\u0012#";
      t[2] = "\u001c\u0006\u0010\n5i\n\u0006\u0015P&~\u001dM\u0016V*j\f\n\u0001AazK";
      t[3] = "\u00105G\u0002:+e\u0015L\r+d\u0004\u001bG\u0006/>p";
      t[4] = "y ceh y t9d/ckt'd:d\u001a%\u007f6";
      t[5] = double.class;
      u[5] = "java/lang/Double";
      t[6] = "C\u001ebJdnU\u001eg\u0010wyBUd\u0016{mS\u0012s\u00010\u007fb";
      t[7] = int.class;
      u[7] = "java/lang/Integer";
      t[8] = "\u0007o[\u0014uk\f`J[\u0016f\u0019f";
      t[9] = "T\"2(&*T\"%t*%Ni%j*0I\u0018t5x{";
      t[10] = "&:'\u0012F?S\u001a,\u001dWp2\u0014'\u0016S*F";
      t[11] = void.class;
      u[11] = "java/lang/Void";
      t[12] = "\u0007G)Ly\t\u0007G>\u0010u\u0006\u001d\f>\u000eu\u0013\u001a}lP-W";
      t[13] = "G\u0000\u001d}\u0018UQ\u0000\u0018'\u000bBFK\u001b!\u0007VW\f\f6LAe";
      t[14] = "2\u0017$S\u0015k9\u00185\u001cte2\u00131F";
      t[15] = "o3\"4\u0011\u0012d<3{v\u0010q730M";
      t[16] = "z)vn\u000eMz)a2\u0002B`ba,\u0002Wg\u00133yP\u0013";
      t[17] = "!:\tQo-!:\u001e\rc\";q\u001e\u0013c7<\u0000OI:t";
      t[18] = boolean.class;
      u[18] = "java/lang/Boolean";
      t[19] = "QU\u0011\\N9ZZ\u0000\u0013\":TX\u0002\\\u000e";
      t[20] = "58?p#K58(,/D/s(2/Q(\u0002zh{\u0015";
      t[21] = "~@-)6f\u000b`&&')jn--#s\u001e";
      t[22] = "\u0012MvE+'gm}J:h\u0006cvA>2r";
      t[23] = "X/5p~\u000fF'/?\u0003\u001fF";
      t[24] = "\u0010\t60[\u000e\u001b\u0006'\u007f&\u0016\b\u0001.6";
      t[25] = ":\u0018JVhR'\r\u0012t)_?\u000b";
      t[26] = "yzh2Q|ozmhBkx1nnN\u007fivyy\u0005hk";
      t[27] = "\u0010(P .\u000ee\b[/?A\u0004\u0006P$;\u001bp";
      t[28] = "\u0003{eHUr\u0015{`\u0012Fe\u00020c\u0014Jq\u0013wt\u0003\u0001c%";
      t[29] = "\u001f\u001dD{6\u001dj=Ot'R\u000b3D\u007f#\b\u007f";
      t[30] = "=\u001c\u001b\b\u001c-H<\u0010\u0007\rb)2\u001b\f\t8]";
      t[31] = ",9\u0011')KY\u0019\u001a(8\u00048\u0017\u0011#<^L";
      t[32] = "c],!P\n\u0016}'.AEws,%E\u001f\u0003";
      t[33] = "\u001e\u000bFyK\u0012\b\u000bC#X\u0005\u001f@@%T\u0011\u000e\u0007W2\u001f\u0004/";
      t[34] = "EX#Sa<0x(\\psQv#Wt)%";
      t[35] = "kzFn(6\u001eZMa9y\u007fTFj=#\u000b";
      t[36] = "\\I_ByJWFN\r\u0011JYI]";
      t[37] = float.class;
      u[37] = "java/lang/Float";
      t[38] = ":\u000b|I\u001eIO+wF\u000f\u0006.%|M\u000b\\Z";
      t[39] = "{\u0017q\b/+m\u0017tR<<z\\wT0(k\u001b`C{?V";
      t[40] = ":\u0017\u000fbe\u0014O7\u0004mt[.9\u000ffp\u0001Z";
      t[41] = "vo\u0003F~>`o\u0006\u001cm)w$\u0005\u001aa=fc\u0012\r**X";
      t[42] = "3Bl\u0019;1Fbg\u0016*~'ll\u001d.$S";
      t[43] = "mEa\u000e\u0003a{EdT\u0010vl\u000egR\u001cb}IpEWuB";
      t[44] = "~;\u0013~\u000fs\u000b\u001b\u0018q\u001e<j\u0015\u0013z\u001af\u001e";
      t[45] = "jeiWah'{?M\u000f<V>kE\u007f5myn\nsV";
      t[46] = "\u0011nrQp1\u0013n{_N!\u001cc^Z6.\u0018\u001f*R?>\u0012$mWp2q";
      t[47] = "\u0001 QaD0\u0013,E1%m\u0007)K\u0015Ba\u0003R\u00162T}\riQ7\u001bqn";
      t[48] = "Wv~5)^M0vvBR67'v<DI\"`89>\t2a4$\u0004\u000ewn=B";
      t[49] = ">\u0016|\u0018(P$Pt[CP_W%[=J Bb\u001580`Rc\u0019%\ng\u0017l\u0010C";
      t[50] = "\u000bg8w;wU0`l\u0000*Xqbtl\u0018\f58-<O\bascctOd<o\u0000";
      t[51] = "f2Es;L;rD0^[\\u\u00008 J#`Gv%0fyF23\begA(^";
      t[52] = "}-%\u001e\f(#-hL5$|@sL\f yxeBIz\u0012/wMYzyqw\u0000\u000bC";
      t[53] = "\u0015k1n\nO\u001fv hj\u001e\u001en/|\u0003\u0012'`/l\u0007t\u001545 \u001b\u0016\u001dftaj";
      t[54] = "\u0003CA\u0005-\bN]\u0017\u001fC]?\u0018C\u00173U\u0004_FX?6";
      t[55] = "ZC\u0017\u0002@\u0018\u001f\u0005N\u001f%\u0016!BH\u0015[\u0005^W\u000f[^\u007fZC\u0017\u0002@\u0018\u001f\u0005N\u001f%";
      t[56] = "Ek\u001d\u000f8/\u000e7\u0019]V#\u0018r\u0010P:\u0011L>O\u0006fFO|\u000eO;~Lb\tUV";
      t[57] = "H,:)^3K2=33e\u00133 =d2Ic|Q\bzJ1)1\fwL/";
      t[58] = "@/]jaZI;]0\fPq/^noRI9P+59";
      t[59] = "i)\u0019v%_a$\u0013vIPf%!\"-LmYB'8Acb\u0005\"wM\u0000";
      t[60] = "\u0001GgyWc\t\u0012pmiz\u0006\u000bl`\u0005H[L6?i!\u0001Mh<Q\u007fV\u0015s\u0007\u0003`\u0015\u0010`n\u0014 \u000f\n\f";
      t[61] = "}\u001dA\u0016UXuHV\u0002kAzQJ\u000f\u0007s,\u0014\u0014PT$*A[\u0018\b\u001fmD\u0014\u0014k";
      t[62] = "gI/ev1,\u0015+7\u0018=:P\":t\u000fh\u0017{m#X=\u001c)#&$5I>7\u0018";
      t[63] = "lH\u0012-\u0010}3WC_BBk\u001fUa\u0017$=\u001dR/+{hX\u0016cM-j_X_";
      t[64] = "+\u001aR\u0004D-vZSG!8\u0011]\u0017O_+nHP\u0001ZQ+QQELi(OV_!";
      t[65] = "0GR|}k3YUf\u0010=kXHhGj1\b\u0016\u0004+\"2ZAd//4D";
      t[66] = "}T\u0011mhX~J\u0016w\u0005\u000e&K\u000byRY|\u001bV\u0015>\u0011\u007fI\u0002u:\u001cyW";
      t[67] = "uSeu%e&J7(\\guDn#0U'\u00037tg\u0002r\be:b~z]r.\\";
      t[68] = "NE\tx\u0010t\\I\u001d(q$XJ\u001a#\nIH\tJ$\u001aq^\u0007\u000f~q%\u001cIB6\u0013-N\b\u0003G";
      t[69] = "\u0014A=\u00025,\u0018\u0004;\u0000M{MY;CM.X\u00063T-*U\u0000-9vd\u0011Q1Yri\u0017O\\";
      t[70] = "<f\u0003hx<a&\u0002+\u001d)\u0006!F#c:y4\u0001mf@=.F>p 9#@ \u001d";
      t[71] = "CTE49&_X[9C/%A\u0000v=<ZTG88FHTS5:!\u001bM\u0001hC";
      t[72] = "pY\r=+^/F\\Ota0\fE1j\u001e%K\u000b4\u0010^5J\u0007)*YpE\u000eO";
      t[73] = "\fQo\u0018t&SN>j-\u0019L\u0004'\u00145fYCi\u0011O&IBe\fu!\fMlj";
      t[74] = "*C\u001c2SbaJN`,7P[\u0018\"R$/N_lW^*C\u001c2SbaJN`,";
      t[75] = "hH )nV7Wq[6i(\u001dh%/\u0016=Z& UV-[*=oQhT#[";
      t[76] = "&er\u007fyU%{ue\u0014\bqkl`x:%/56\u0014Wnitj,Tpnn\u0007.\u001fboa?-\u0001eu\f";
      t[77] = "H}b1\u001crD8d3d\"\u001fy\u00031\u0015s\u001aoc5\u0018u\u0004\u00028{\\$\u0018b<vZ:u";
      t[78] = "fuq]\u007fq?k+\u0001\u0014u\u0004u#\u0017je{`dYo\u001fdz~\n*`fzw\u0004\u0014";
      t[79] = "\u000fk\u007f\u000fI<\u000f's\n07r(;BN$\r=|\fK^\u000fk\u007f\u000fI<\u000f's\n0";
      t[80] = "~A#\u001cN\u0012oH2\u0000?\u001cbC%\u0001a\u001bbY!}FLaY/\u001fMBl\u001cL";
      t[81] = "\u0016\u0014 *lV\fR(i\u0007YwUyiyL\b@>'|6HP?+a\fO\u00150\"\u0007";
      t[82] = "(#O\u0016+$+=H\fFy\u007f-Q\t*K+i\u000bUF'ci^\u0003&#no@n}m*>\\\u000ey`, 1U7$}<QQ:\"cQ\u000b\u001c8d\u007fi\b\u0002?~\u0012";
      t[83] = "<29\u0010:,+r#\nV ;1'\u0010:\u0012ls}NkE:p9F''2\"x\u0007V";
      t[84] = "`[\u00013h&cE\u0006)\u0005{7U\u001f,iIc\u0011Ev\u0005$(W\u0007&='6P\u001dK>obF\u0012+:bdX\u007f";
      t[85] = "v\u001f 7\u00141u\u0001'-yl!\u0011>(\u0015^uUevy2=U1\"\u001960S/OBxt\u00023/Fur\u001c^t\b1#\u0000>p\u00057=md=\u0007q!Ug#\u0000kL";
      t[86] = "\u0014r$\bQ\u0011Kmuz\u0003.T'l\u0004\u0010QA`\"\u0001j\u0014Xaf\u0017R\u0017Ff|z";
      t[87] = "d\u001c7\u0000fng\u00020\u001a\u000b33\u0012)\u001fg\u0001g^y@6Ve\u001fq\u0017f6a\u0012w\t\u000bm/V&\u0015ki\"P8x0'f\u0001$\u00184*`\u001fIBy(&\u0003qAg/<n";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = t[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(u[var4]);
            t[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            t[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  t[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1032648853038229L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  t[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1032648853038229L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        t[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1032648853038229L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 250;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 80;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 224;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 207;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 81;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 89;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 250;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 80;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 224;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e2",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(MacePrediction var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$4", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(MacePrediction var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$5", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(MacePrediction var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$2", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(MacePrediction var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$0", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(MacePrediction var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(MacePrediction var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$1", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(MacePrediction var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$6", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(MacePrediction var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e2;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e2", "lambda$new$3", "(Ljava/lang/Integer;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((MacePrediction)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
