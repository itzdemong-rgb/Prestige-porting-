package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class MiddleClickFriend extends Module {
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private static final long k = 108701936226144L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[35];
   private static final String[] p = new String[35];

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 52274037979811L ^ 12248290379634L;
      var10001 = 52274037979811L ^ 70465553925120L;
      int var8 = Event.bReturningInt();
      int var63 = var8;
      MinecraftClient var62 = b;
      MinecraftClient var46 = var62;
      MinecraftClient var45 = var62;
      if (var63 == 0) {
         MinecraftClient var12 = var45;
         Screen var64 = var12.currentScreen;
         if (var64 != null) {
            return;
         }

         var46 = b;
      }

      MinecraftClient var15 = var46;
      Mouse var16 = var15.mouse;
      boolean var10000 = var16.wasMiddleButtonClicked();
      int var66 = var8;
      boolean var65 = var10000;
      boolean var48 = var65;
      boolean var47 = var65;
      if (var66 == 0) {
         boolean var67 = var47;
         if (!var67) {
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         var48 = this.i;
      }

      int var69 = var8;
      boolean var68 = var48;
      boolean var50 = var68;
      boolean var49 = var68;
      if (var69 == 0) {
         boolean var70 = var49;
         if (var70) {
            return;
         }

         MinecraftClient var20 = b;
         Mouse var21 = var20.mouse;
         var50 = var21.wasMiddleButtonClicked();
      }

      HitResult var55;
      label77: {
         int var72 = var8;
         boolean var71 = var50;
         boolean var54 = var71;
         boolean var51 = var71;
         if (var72 == 0) {
            boolean var73 = var51;
            if (!var73) {
               return;
            }

            MinecraftClient var23 = b;
            int var75 = var8;
            HitResult var74 = var23.crosshairTarget;
            var55 = var74;
            HitResult var52 = var74;
            if (var75 != 0) {
               break label77;
            }

            HitResult var76 = var52;
            HitResult var53 = var76;
            boolean var77 = var53 instanceof EntityHitResult;
            var54 = var77;
         }

         boolean var78 = var54;
         if (!var78) {
            return;
         }

         MinecraftClient var26 = b;
         HitResult var79 = var26.crosshairTarget;
         var55 = var79;
      }

      label79: {
         EntityHitResult var9 = (EntityHitResult)var55;
         EntityHitResult var28 = var9;
         Entity var91 = var28.getEntity();
         int var81 = var8;
         Entity var80 = var91;
         Entity var57 = var80;
         Entity var56 = var80;
         if (var81 == 0) {
            boolean var82 = var56 instanceof PlayerEntity;
            if (!var82) {
               break label79;
            }

            EntityHitResult var30 = var9;
            Entity var83 = var30.getEntity();
            var57 = var83;
         }

         PlayerEntity var10 = (PlayerEntity)var57;
         PlayerEntity var32 = var10;
         Text var33 = var32.getName();
         String var11 = var33.getString();
         int var86 = var8;
         String var85 = var11;
         SocialsManager var84 = Prestige.g;
         SocialsManager var60 = var84;
         String var61 = var85;
         SocialsManager var58 = var84;
         String var59 = var85;
         if (var86 == 0) {
            Object[] var35 = new Object[]{var59, 40309233401297L};
            SocialsManager var34 = var58;
            boolean var87 = var34.aReturningBoolean(var35);
            if (var87) {
               String var38 = var11;
               SocialsManager var37 = Prestige.g;
               var37.bReturningVoid(var38);
               Object[] var39 = new Object[]{this, "Removed friend: " + var11, NotificationType.INFO, 122717772283555L};
               ModuleNotificationsWidget.s(var39);
               int var88 = var8;
               if (var88 == 0) {
                  break label79;
               }
            }

            String var90 = var11;
            SocialsManager var89 = Prestige.g;
            var60 = var89;
            var61 = var90;
         }

         String var43 = var61;
         SocialsManager var42 = var60;
         var42.aReturningVoid(var43);
         Object[] var44 = new Object[]{this, "Added friend: " + var11, NotificationType.INFO, 122717772283555L};
         ModuleNotificationsWidget.s(var44);
      }

      this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(135442192318549L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[2];
      String var6 = "8^yi\u0017\u00ad2u·p\u009aÛ\u0014Á¥é\u0098çz\u001c\u0014ª:4\u008d?µ\u001b\u0092i=\u008c0Ò¾H\u009c\u001b\u0099\u0087\u0014\u008cþ\u007fÅ\u008bÃ\u0016Õ\u0094\u0084r \u0003TJt¾\u0086s+öqTØn\u001eO±_r%Õ\u009c®^\fb\u0006\u0012,";
      int var8 = "8^yi\u0017\u00ad2u·p\u009aÛ\u0014Á¥é\u0098çz\u001c\u0014ª:4\u008d?µ\u001b\u0092i=\u008c0Ò¾H\u009c\u001b\u0099\u0087\u0014\u008cþ\u007fÅ\u008bÃ\u0016Õ\u0094\u0084r \u0003TJt¾\u0086s+öqTØn\u001eO±_r%Õ\u009c®^\fb\u0006\u0012,"
         .length();
      char var5 = ' ';
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[2];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16321;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e4", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e4",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 3;
            yield var15;
         }
         case 1 -> {
            byte var16 = 15;
            yield var16;
         }
         case 2 -> {
            byte var17 = 63;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 13;
            yield var19;
         }
         case 5 -> {
            byte var20 = 43;
            yield var20;
         }
         case 6 -> {
            byte var21 = 56;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 12;
            yield var23;
         }
         case 9 -> {
            byte var24 = 34;
            yield var24;
         }
         case 10 -> {
            byte var25 = 47;
            yield var25;
         }
         case 11 -> {
            byte var26 = 57;
            yield var26;
         }
         case 12 -> {
            byte var27 = 2;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 10;
            yield var29;
         }
         case 15 -> {
            byte var30 = 28;
            yield var30;
         }
         case 16 -> {
            byte var31 = 60;
            yield var31;
         }
         case 17 -> {
            byte var32 = 49;
            yield var32;
         }
         case 18 -> {
            byte var33 = 16;
            yield var33;
         }
         case 19 -> {
            byte var34 = 9;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 26;
            yield var37;
         }
         case 23 -> {
            byte var38 = 29;
            yield var38;
         }
         case 24 -> {
            byte var39 = 8;
            yield var39;
         }
         case 25 -> {
            byte var40 = 51;
            yield var40;
         }
         case 26 -> {
            byte var41 = 42;
            yield var41;
         }
         case 27 -> {
            byte var42 = 7;
            yield var42;
         }
         case 28 -> {
            byte var43 = 4;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 5;
            yield var45;
         }
         case 31 -> {
            byte var46 = 32;
            yield var46;
         }
         case 32 -> {
            byte var47 = 52;
            yield var47;
         }
         case 33 -> {
            byte var48 = 30;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 25;
            yield var50;
         }
         case 36 -> {
            byte var51 = 35;
            yield var51;
         }
         case 37 -> {
            byte var52 = 44;
            yield var52;
         }
         case 38 -> {
            byte var53 = 17;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 38;
            yield var55;
         }
         case 41 -> {
            byte var56 = 21;
            yield var56;
         }
         case 42 -> {
            byte var57 = 11;
            yield var57;
         }
         case 43 -> {
            byte var58 = 6;
            yield var58;
         }
         case 44 -> {
            byte var59 = 20;
            yield var59;
         }
         case 45 -> {
            byte var60 = 40;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 36;
            yield var62;
         }
         case 48 -> {
            byte var63 = 31;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 27;
            yield var65;
         }
         case 51 -> {
            byte var66 = 62;
            yield var66;
         }
         case 52 -> {
            byte var67 = 54;
            yield var67;
         }
         case 53 -> {
            byte var68 = 24;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 53;
            yield var71;
         }
         case 57 -> {
            byte var72 = 19;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 14;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 0;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "7w\u001a/\u000bh!w\u001fu\u0018\u007f6<\u001cs\u0014k'{\u000bd_~\u001c";
      o[1] = "9\u007fe,\"-2ptc_5!w}*";
      o[2] = void.class;
      p[2] = "java/lang/Void";
      o[3] = "\f|'Vsj\u001a|\"\f`}\r7!\nli\u001cp6\u001d'{-";
      o[4] = int.class;
      p[4] = "java/lang/Integer";
      o[5] = "\u0002@\u001dVI0\u0014@\u0018\fZ'\u0003\u000b\u001b\nV3\u0012L\f\u001d\u001d\"_";
      o[6] = "\u007f\u001b\u0003]}~\n;\bRl1k5\u0003Yhk\u001f";
      o[7] = "\b@}+b{\u001e@xqql\t\u000b{w}x\u0018Ll`6h\u0000Lnkl%<Wnvlb\u000b@";
      o[8] = "\u001d&\u0010\u001dbn\u001d&\u0007Ana\u0007m\u0007_nt\u0000\u001cW\u0002=";
      o[9] = boolean.class;
      p[9] = "java/lang/Boolean";
      o[10] = "Io_8\u0012IIoHd\u001eFS$Hz\u001eSTU\u0018'O";
      o[11] = "\u0014\u007fa\fD\u0003\u0014\u007fvPH\f\u000e4vNH\u0019\tE!\u0011\u001e";
      o[12] = "r;\u001e2\u0001i\u0007\u001b\u0015=\u0010&f\u0015\u001e6\u0014|\u0012";
      o[13] = "9\u0016eS\u007fM9\u0016r\u000fsB#]r\u0011sW$,#N+";
      o[14] = "\u0000!l~s\u0010\u0000!{\"\u007f\u001f\u001aj{<\u007f\n\u001d\u001b+i(O";
      o[15] = "4ts\rxq4tdQt~.?dOtk)N6\u0011,/";
      o[16] = "S*|>?\\S*kb3SIak|3FN\u0010:%d\u0004";
      o[17] = "i@)V`K\u007f@,\fs\\h\u000b/\n\u007fHyL8\u001d4^9";
      o[18] = " `>&\u0003J+o/i`G>b \u0002UE/q<.BH";
      o[19] = "-y\u0011:{\u0007-y\u0006fw\b72\u0006xw\u001d0CT\"#Y";
      o[20] = "kQB;\u0004\f`^Ste\u0002kUW.";
      o[21] = "EN3c$BAFv\u0002+,F\n63(N\u0005H29B\u0015\u0010Qs;yH\u0000Hk\u0002";
      o[22] = "3G?\f\u0015\u001f6\\<L$\u000b\t\u001b)\tB\n`Ct\u0016@a";
      o[23] = ".gzo\t\\+'/z4B\u0015.<t\t\u0002uy|,\t9,q%l\r\u0002qa<t4";
      o[24] = "\u00169\u0001\r\u0019\u0015\u0010;Z\u001d#\u001d+?JIB\u0014E;B\f";
      o[25] = "X\u007fP$$d\u001bc\u000f%\u001b>\b~R\u007fw\f^?\r $[[gJe{d\t<\f)\u001b";
      o[26] = "8c\u0001\u0011IglxR\u0012.rg\u007f\u0007\u0001y%9/^m\u001e'cu\u0001UAf`y";
      o[27] = "KY:[>\u001fOQ\u007f:1qA_b\u0007c\u0011\u0016\u001f:\u0007XO\u0014[xZg\u001dO\u001d4:";
      o[28] = "fn`w!92u3tF,9rfg\u0011{g!?\u000bwz9#<u<~?'";
      o[29] = "\u0007?06\nb\t{&1lg\u0003x9;\u0000UW;flV\u0002\u0007e!m\u0003i\u0001yc6l";
      o[30] = "xI\u001f}\u000bCmQ[pzB\u007fV|c\u0000LtE'&D\u0017#@Ee\u0006\u0013)*";
      o[31] = "9\u0000P{l\u0012m\u001b\u0003x\u000b\u0007f\u001cVk\\P8K\u0003\u00076\u0014eM\r8u\b:L";
      o[32] = "\n\u0006b<\u001d\u0007Y\r8fw\u001fa\u0001,:O\r\r\u0013;:\u000fv\n\u001a9g\f\u001a\u0018\r9'w";
      o[33] = "'\u0018\u0018^Bh1\u000f\u0018\f}r&\u001f\n\t\u0011@v_UQ}}([\b\u001f\u0013h0\u001f\u0005n";
      o[34] = "x&5[vp|.p:z\u001e{b0\u000bz|8 4\u0001\u0010'-9u\u0003+z= m:";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1460268057433698L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1460268057433698L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1460268057433698L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 81;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 233;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 242;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 74;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 200;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 111;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 81;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 233;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 242;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e4",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
