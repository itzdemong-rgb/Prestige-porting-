package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PlayerNameEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.StringSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.session.Session;
import net.minecraft.text.Text;

public class NameHider extends Module {
   private ModeSetting a;
   private StringSetting c;
   private BooleanSetting d;
   private FloatSetting e;
   private ElapsedTimer f;
   private String h;
   private static final long k = 42910511182153L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[68];
   private static final String[] p = new String[68];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;

   public NameHider() {
      super();
      long var10001 = 134317769193832L ^ 29840716025409L;
      var10001 = 134317769193832L ^ 123714158823832L;
      var10001 = 134317769193832L ^ 111461252320191L;
      var10001 = 134317769193832L ^ 47175961817796L;

      this.f = new ElapsedTimer(106698256430889L);
      this.h = "";
      FloatSetting var10000 = this.e;
      Object[] var12 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var11 = var10000;
      var11.aReturningFloatSetting(var12);
      BooleanSetting var17 = this.d;
      Object[] var14 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var13 = var17;
      var13.aReturningBooleanSetting(var14);
      StringSetting var18 = this.c;
      Object[] var16 = new Object[]{invokeBinding3(this), 11739095036144L};
      StringSetting var15 = var18;
      var15.aReturningStringSetting(var16);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      NameHider var36;
      label34: {
         boolean var35;
         long var10001 = 96663174580930L ^ 45528417688790L;
         var10001 = 96663174580930L ^ 124379879596738L;
         var10001 = 96663174580930L ^ 24154117656120L;
         int var10 = Event.bReturningInt();
         BooleanSetting var11 = this.d;
         Boolean var12 = (Boolean)var11.aReturningObject();
         boolean var10000 = var12;
         int var38 = var10;
         boolean var37 = var10000;
         var35 = var37;
         boolean var31 = var37;
         label30:
         if (var38 == 0) {
            boolean var39 = var31;
            if (var39) {
               ElapsedTimer var48 = this.f;
               FloatSetting var14 = this.e;
               Float var15 = (Float)var14.aReturningObject();
               float var54 = var15;
               Object[] var10004 = new Object[]{null, 139098136696340L};
               var10004[0] = var54;
               Object[] var17 = var10004;
               ElapsedTimer var16 = var48;
               var10000 = var16.aReturningBoolean(var17);
               int var41 = var10;
               boolean var40 = var10000;
               var35 = var40;
               boolean var32 = var40;
               if (var41 != 0) {
                  break label30;
               }

               boolean var42 = var32;
               boolean var33 = var42;
               boolean var43 = var33;
               if (var43) {
                  Object[] var21 = new Object[]{72696477336826L};
                  NameHider var20 = this;
                  this.h = var20.dReturningString(var21);
                  ElapsedTimer var50 = this.f;
                  Object[] var23 = new Object[]{42835128969216L};
                  ElapsedTimer var22 = var50;
                  var22.aReturningVoid(var23);
               }
            }

            int var45 = var10;
            NameHider var44 = this;
            var36 = var44;
            NameHider var34 = var44;
            if (var45 != 0) {
               break label34;
            }

            ModeSetting var25 = var34.a;
            String var51 = (String)var25.aReturningObject();
            String var27 = "Custom";
            String var26 = var51;
            boolean var46 = var26.equals(var27);
            var35 = var46;
         }

         boolean var47 = var35;
         if (!var47) {
            return;
         }

         var36 = this;
      }

      Object[] var30 = new Object[]{72696477336826L};
      NameHider var29 = this;
      var36.h = var29.dReturningString(var30);
   }

   @EventListener
   public void a(PlayerNameEvent var1) {
      int var10000 = Event.cReturningInt();
      MinecraftClient var6 = b;
      Session var7 = var6.getSession();
      String var5 = var7.getUsername();
      int var4 = var10000;
      int var25 = var4;
      PlayerNameEvent var24 = var1;
      PlayerNameEvent var23 = var24;
      PlayerNameEvent var22 = var24;
      if (var25 != 0) {
         Object[] var9 = new Object[0];
         PlayerNameEvent var8 = var22;
         String var28 = var8.bReturningString(var9);
         String var11 = var5;
         String var10 = var28;
         boolean var26 = var10.contains(var11);
         if (!var26) {
            return;
         }

         MinecraftClient var13 = b;
         Session var14 = var13.getSession();
         Object[] var16 = new Object[]{var14.getUsername()};
         PlayerNameEvent var15 = var1;
         var15.bReturningVoid(var16);
         Object[] var18 = new Object[]{this.h};
         PlayerNameEvent var17 = var1;
         var17.cReturningVoid(var18);
         PlayerNameEvent var27 = var1;
         var23 = var27;
      }

      Object[] var21 = new Object[0];
      PlayerNameEvent var20 = var23;
      var20.aReturningVoid(var21);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 114744725295493L;
      Object[] var7 = new Object[]{var4};
      NameHider var6 = this;
      this.h = var6.dReturningString(var7);
   }

   private String dReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 42910511182153L ^ var2;
      int var4 = Event.bReturningInt();
      ModeSetting var9 = this.a;
      String var10000 = (String)var9.aReturningObject();
      int var43 = var4;
      String var42 = var10000;
      String var36 = var42;
      String var35 = var42;
      if (var43 == 0) {
         short var10001 = 25359;
         long var10002 = 154164555146109799L ^ var2;
         String var11 = "Custom";
         String var10 = var35;
         boolean var44 = var10.equals(var11);
         if (!var44) {
            StringBuilder var5 = new StringBuilder();
            short var59 = 131;
            long var61 = 7073223294373937389L ^ var2;
            String var6 = "abcdefghijklmnopqrstuvwxyz0123456789";
            String var41;
            while (true) {
               MinecraftClient var16 = b;
               ClientPlayerEntity var17 = var16.player;
               Text var18 = var17.getDisplayName();
               String var19 = var18.getString();
               int var47 = var19.length();
               int var46 = var7;
               if (var46 < var47) {
                  int var49 = var4;
                  String var48 = var6;
                  var41 = var48;
                  String var37 = var48;
                  if (var49 != 0) {
                     break;
                  }

                  Random var62 = RandomUtil.a;
                  String var20 = var6;
                  int var22 = var20.length();
                  Random var21 = var62;
                  int var24 = var21.nextInt(var22);
                  String var23 = var37;
                  int var8 = var23.charAt(var24);
                  int var50 = var4;
                  if (var50 == 0) {
                     int var25 = var8;
                     boolean var51 = Character.isAlphabetic(var25);
                     label35:
                     if (var51) {
                        Random var27 = RandomUtil.a;
                        float var63;
                        int var60 = (var63 = var27.nextFloat() - 0.5F) == 0.0F ? 0 : (var63 < 0.0F ? -1 : 1);
                        int var53 = var4;
                        int var52 = var60;
                        int var40 = var52;
                        int var38 = var52;
                        if (var53 == 0) {
                           int var54 = var38;
                           int var39 = var54;
                           int var55 = var39;
                           if (var55 <= 0) {
                              break label35;
                           }

                           int var30 = var8;
                           char var56 = Character.toUpperCase((char)var30);
                           var40 = var56;
                        }

                        var8 = var40;
                     }

                     int var33 = var8;
                     StringBuilder var32 = var5;
                     var32.append((char)var33);
                     var7++;
                  }

                  int var57 = var4;
                  if (var57 == 0) {
                     continue;
                  }
               }

               StringBuilder var34 = var5;
               var41 = var34.toString();
               break;
            }

            return var41;
         }

         StringSetting var13 = this.c;
         String var14 = (String)var13.aReturningObject();
         String var45 = var14.toString();
         var36 = var45;
      }

      return var36;
   }

   @Override
   public String aReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      return invokeBinding5((String)invokeBinding4(this.a, -4961332139424414285L, var2), -4961896490432438513L, var2);
   }

   private boolean lambda$new$2(Float var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var17 = var4;
      byte var16 = var10000;
      byte var12 = var16;
      byte var11 = var16;
      if (var17 != 0) {
         byte var18 = var11;
         if (var18 == 0) {
            return false;
         }

         ModeSetting var8 = this.a;
         String var24 = (String)var8.aReturningObject();
         String var10 = "Random";
         String var9 = var24;
         byte var19 = ((byte)((var9.equals(var10)) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var4;
      byte var20 = var12;
      byte var14 = var20;
      byte var13 = var20;
      if (var21 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         byte var22 = var13;
         if (var22 != 0) {
            var14 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var14);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Random";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(String var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Custom";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(40150065944809L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[5];
      String var6 = ">À\u0018ûF}daZUÔlQë; \u0010¼c¼ÙIè\n\u0017a:ô ú\u001f?d\u0010×;üüº¯Ä\u000bjG]þS\u0012i¢";
      int var8 = ">À\u0018ûF}daZUÔlQë; \u0010¼c¼ÙIè\n\u0017a:ô ú\u001f?d\u0010×;üüº¯Ä\u000bjG]þS\u0012i¢".length();
      char var5 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = b(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     l = var9;
                     m = new String[5];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "ävÉ\u0094î¤\u0001á4\u0081\u0089×X²\u0083 @&×ÿîj\u001f\u009aÛàÈ\u000eer\u0091\u0011üäÌ9·\u001e\u0091\fè¨\u0016Ô\u0000\u0088\u0098P:Æ¿®ÕÜã\u0002 \u008fW\u001f\u001fD\u0084nøFþ£)GLÆe½\u001dW)\u0081\u009fb©";
                  var8 = "ävÉ\u0094î¤\u0001á4\u0081\u0089×X²\u0083 @&×ÿîj\u001f\u009aÛàÈ\u000eer\u0091\u0011üäÌ9·\u001e\u0091\fè¨\u0016Ô\u0000\u0088\u0098P:Æ¿®ÕÜã\u0002 \u008fW\u001f\u001fD\u0084nøFþ£)GLÆe½\u001dW)\u0081\u009fb©"
                     .length();
                  var5 = 16;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 13785;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e5", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e5",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 35;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 0;
            yield var17;
         }
         case 3 -> {
            byte var18 = 4;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 8;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 36;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 10;
            yield var25;
         }
         case 11 -> {
            byte var26 = 57;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 44;
            yield var28;
         }
         case 14 -> {
            byte var29 = 31;
            yield var29;
         }
         case 15 -> {
            byte var30 = 41;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 53;
            yield var32;
         }
         case 18 -> {
            byte var33 = 6;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 56;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 51;
            yield var37;
         }
         case 23 -> {
            byte var38 = 5;
            yield var38;
         }
         case 24 -> {
            byte var39 = 11;
            yield var39;
         }
         case 25 -> {
            byte var40 = 62;
            yield var40;
         }
         case 26 -> {
            byte var41 = 63;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 13;
            yield var43;
         }
         case 29 -> {
            byte var44 = 61;
            yield var44;
         }
         case 30 -> {
            byte var45 = 49;
            yield var45;
         }
         case 31 -> {
            byte var46 = 29;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 52;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 14;
            yield var50;
         }
         case 36 -> {
            byte var51 = 40;
            yield var51;
         }
         case 37 -> {
            byte var52 = 27;
            yield var52;
         }
         case 38 -> {
            byte var53 = 50;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 26;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 60;
            yield var60;
         }
         case 46 -> {
            byte var61 = 15;
            yield var61;
         }
         case 47 -> {
            byte var62 = 58;
            yield var62;
         }
         case 48 -> {
            byte var63 = 38;
            yield var63;
         }
         case 49 -> {
            byte var64 = 20;
            yield var64;
         }
         case 50 -> {
            byte var65 = 24;
            yield var65;
         }
         case 51 -> {
            byte var66 = 3;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 42;
            yield var69;
         }
         case 55 -> {
            byte var70 = 25;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 7;
            yield var73;
         }
         case 59 -> {
            byte var74 = 16;
            yield var74;
         }
         case 60 -> {
            byte var75 = 32;
            yield var75;
         }
         case 61 -> {
            byte var76 = 46;
            yield var76;
         }
         case 62 -> {
            byte var77 = 22;
            yield var77;
         }
         default -> 39;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "(7\\M$'#8M\u0002Y?0?DK";
      o[1] = "\u0002e\u0014@\u007f\u001e\tj\u0005\u000f\u001e\u0010\u0002a\u0001U";
      o[2] = boolean.class;
      p[2] = "java/lang/Boolean";
      o[3] = "\u001a\u0001^o\u001am\f\u0001[5\tz\u001bJX3\u0005n\n\rO$Ny8";
      o[4] = "K{BDNV]{G\u001e]AJ0D\u0018QU[wS\u000f\u001aC\u001a";
      o[5] = "/\u0010\u0006|-kZ0\rs<$;>\u0006x8~O";
      o[6] = "*\u0004{G\u0017~<\u0004~\u001d\u0004i+O}\u001b\b}:\bj\fCo\u0011";
      o[7] = "\u001ar@BO'oRKM^h\u000e\\@FZ2z";
      o[8] = "MI\u000bP\u001cVFF\u001a\u001fqRFZ.TCOBF\u001eT";
      o[9] = "N7\u000f\u00199(;\u0017\u0004\u0016(gZ\u0019\u000f\u001d,=.";
      o[10] = void.class;
      p[10] = "java/lang/Void";
      o[11] = "~\u001d0\u0006Eyu\u0012!I&t`\u001f.\"\u0013vq\f2\u000e\u0004{";
      o[12] = "%z1\rIP3z4WZG$17QVS5v F\u001dA\u0004";
      o[13] = int.class;
      p[13] = "java/lang/Integer";
      o[14] = "s\u0005e\u0005brs\u0005rYn}iNrGnhn?\"\u001a?";
      o[15] = "3BFp_-3BQ,S\")\tQ2S7.x\u0001l\u0002";
      o[16] = "%&l;\u000eYP\u0006g4\u001f\u00161\bl?\u001bLE";
      o[17] = "\u0002=4y\u0012Mw\u001d?v\u0003\u0002\u0016\u00134}\u0007Xb";
      o[18] = "^\u007fB4L&H\u007fGn_1_4DhS%NsS\u007f\u00182r";
      o[19] = "\\,F\u000e\u0015\u0015)\fM\u0001\u0004ZH\u0002F\n\u0000\u0000<";
      o[20] = "5\u0002]k!f#\u0002X12q4I[7>e%\u000eL ur\u001e";
      o[21] = "l_(bge\u0019\u007f#mv*xq(frp\f";
      o[22] = "\u0005\u007fA;x\f\u0013\u007fDak\u001b\u00044Ggg\u000f\u0015sPp,\u0018+";
      o[23] = "\u0018:e\u007f\u0019\u0002m\u001anp\bM\f\u0014e{\f\u0017x";
      o[24] = "lET53\u0001rMNzO\u0015h@M9";
      o[25] = char.class;
      p[25] = "java/lang/Character";
      o[26] = "d\u0007\u0018nvYd\u0007\u000f2zV~L\u000f,zCy=[t-";
      o[27] = "\\K\u0006\rA3\\K\u0011QM<F\u0000\u0011OM)Aq@\u0016\u001ak";
      o[28] = "f*!`]tm%0/ l~\"9f1me'3d\u0001";
      o[29] = "b\u007f\u0010^\u00158ip\u0001\u0011x<il\u0007\\O1z";
      o[30] = float.class;
      p[30] = "java/lang/Float";
      o[31] = "Lx]@oUGwL\u000f\u0003VIuN@/";
      o[32] = "}\u0019}[Byk\u0019x\u0001Qn|R{\u0007]zm\u0015l\u0010\u0016o@";
      o[33] = "\u0018;\u0003O{\u001dm\u001b\b@jR\f\u0015\u0003Kn\bx";
      o[34] = "KA+|\rZ@N:3eZNA)";
      o[35] = "\u0019<m-y$l\u001cf\"hk\r\u0012m)l1y";
      o[36] = "~\u0007\u0007\u0006;\u0017+YK\u0014W\u0003B_L\t7\u000b-CJ\u000b/i!\u0003\u000e\u001do\u001b3UFy";
      o[37] = "[j\tnf\u0019TwW#\u0003Jk8]=|^\u0000g\u000bmc ";
      o[38] = "\r\u0011=3}e\u001fGuW.p\bVm6#ln\u0014:g+y\r\u0010y)9\u0017WSh;<kR\u0013v'E";
      o[39] = "\t2'cw!\\lkq\u001b55jll{=Zvjnc_\n=)s 1Zfp!\u001b";
      o[40] = "}CtqT0-\r*9$;\u0016TkyD0yHm{\\R}CtqT0-\r*9$";
      o[41] = "R\u001fL#\u000fWXYL}i\u000fi\u001d\u0007(\n\u0002RFM>\u0016fVX\u0016 \r]\r\u0012\u0000<i";
      o[42] = "=Y\u0006]7\t2DX\u0010R[\r\u000bR\u000e-NfT\u0004^20";
      o[43] = "\u001fpxL\u000e}C(mSs}\u001d/`N\u001aq$!`^\u001e\u0017C1hO\nkFqvSs";
      o[44] = "\u0000\u000f,KcL\u0007]$E\u001bR\f\u001c/Kw`\\\\p\u0012\u001bV\u0018\u0003t\u0013\u007f\r\\\u000e,,";
      o[45] = "Mo%aB>G)1t)-#p#iI&Ll%kQDMo%aB>G)1t)";
      o[46] = "W>\nt'\n]e\u0003wK\u0002m/Q|6\u0007\r:\u0018wK";
      o[47] = "=\u000f5\u0019\u0001\u00110\\mHxN9I<F\u0014|m\b`\u0011xB5M6\\CIoK3!";
      o[48] = "<9H\t\u0011\u0001ig\u0004\u001b}\u0014\u0000a\u0003\u0006\u001d\u001do}\u0005\u0004\u0005\u007f?6F\u0019F\u0011om\u001fK}";
      o[49] = "D\f\u0018\t\u001a-VZPmF2AX]\r\"nMY^\u0013I1\u001b\tAm";
      o[50] = "stKM'\u0014~'\u0013\u001c^@{#F\u0019\t\u0017%t\u001eu?Ay)Z\u000e8\u0013q'";
      o[51] = "Cjjm&D\u0018.g5\u0019OOoR*cAD|\t5\"\u0019F+{'tQ\"";
      o[52] = "$~\u001b\u0010Y\u0006/9\r\\9VAd\f\u0012Y].x\n\u0010A?~3I\r\u0002Q.h\u0010_9";
      o[53] = "]5\u0005(g\u0018R([e\u0002Hm1@ebC\u0002-Fgz!Rf\u0005z9O\u0002=\\(\u0002";
      o[54] = "A7<\u001d>\u001dSatyz\byp\u007f\u0018`\u0000\"o>@bWP}h\b\u0006";
      o[55] = "t\u0012\u0019V\u0017\u001c'B@\u001f|\u0012n\n\u0013A\u0010{v\u0000\u0005E\u0016Ft\u0003\u0011\u0019|\u0019v\u0015\u000fL\u001bJ&LF'";
      o[56] = "}e%@#\u001bv?#E^Eyx=M2w-:b\u0014^C/=9\u0012,Qyu]";
      o[57] = "a{|4\u001c(9jp5w.y_v1\u0017&h{n(\u001cO3||6\t$l*,)wv{z~0\u000bs;dbI";
      o[58] = "k~`%#\f8.9lH\u0017nE{.)\rf\u001edoq\u000f1lv99k";
      o[59] = "7k$z\u001dX%=l\u001eHS)9ye%Zo `rEO&+\u001d'\\F8)a\"\u001cX$P";
      o[60] = "\u0005\"f\b6$\u000eepDVt`8q\n6\u007f\u000f$w\b.\u001dY&f\u0016/a\\fx\nV";
      o[61] = "o8# 7\u001bic/!Q\u0014\u0002d(n1\u001fmx.l)}o8# 7\u001bic/!Q";
      o[62] = "\u0000\u0003T\u0019\u001fWV\u0016\u0018\fm\r\u0002\f\u00162\u000b\u0017oM\u0000\u001d\u0012\u0015\u0004\u0012VM\rk^\u0016\u0004\f\u0013\u0000\u0001@T\u0013m";
      o[63] = "c\u0019t\bC\u0005qO<l\u0010\u0017iX\u0004\u0010{FjL2\u0012\u0010\u0019<\u001c-l\u001b\u0005{@'Q\u0019\u0006o\u001cM";
      o[64] = "#\r\r\t3\u001e)K\rWUC\u0018WG\u00195MwKA\u001b-/{\u000b\u0005\rm]i]Mi";
      o[65] = "4\u001dPM-\u001e8Z\u0000\\A\u001c7BT[\u001f\u001b7XP'\"\rk\u0015D\\3\u0002)A=";
      o[66] = "bF\"b\u0001f:W.cj}fv4g\u0007{JB7rjasP.uWcpDr\u001f\nszI&\"\bpn\u0015L";
      o[67] = ">\u0011q^\bzh\u0004=Kz <\u001e3z\u001e!8\u0012OW\u0005~a\u00174F\n<5n";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(93405389898664L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(93405389898664L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(93405389898664L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 115;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 229;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 67;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 181;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 240;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 87;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 115;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 229;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 67;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e5",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(NameHider var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e5;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e5", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((NameHider)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(NameHider var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e5;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e5", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((NameHider)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(NameHider var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e5;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e5", "lambda$new$0", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((NameHider)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Object invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = c(MethodHandles.lookup(), "ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
