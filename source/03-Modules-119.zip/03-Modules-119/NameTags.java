package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.EntityNameEvent;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.api.events.EntityLabelEvent;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.client.ui.hud.PlayerNameTagData;
import dev.zprestige.prestige.client.ui.hud.ItemLabelData;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.client.management.TotemPopTracker;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.management.SocialsManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class NameTags extends Module {
   private FloatSetting a;
   private IntSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private static final float k = 0.15F;
   private static final Color l;
   private static final Color m;
   private static final Color n;
   private static final Color o;
   private static final Color p;
   private static final Color q;
   private Frustum r;
   private Map s;
   private List t;
   private Map u;
   private static final long v = 70264684068239L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final Object[] z = new Object[188];
   private static final String[] A = new String[188];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public NameTags() {
      super();
      long var10001 = 101621293589720L ^ 13940482535284L;

      this.s = new HashMap();
      this.t = new ArrayList();
      this.u = new LinkedHashMap();
      BooleanSetting var10000 = this.j;
      Object[] var6 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var5 = var10000;
      var5.aReturningBooleanSetting(var6);
   }

   
   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 31542349857568L ^ 117965967845354L;
      var10001 = 31542349857568L ^ 77508162879972L;
      var10001 = 31542349857568L ^ 130066494976285L;
      var10001 = 31542349857568L ^ 128602216787102L;
      var10001 = 31542349857568L ^ 56748336487007L;
      var10001 = 31542349857568L ^ 61681082744561L;
      var10001 = 31542349857568L ^ 137929121993100L;
      int var18 = Event.cReturningInt();
      int var229 = var18;
      MinecraftClient var228 = b;
      MinecraftClient var165 = var228;
      MinecraftClient var164 = var228;
      if (var229 != 0) {
         MinecraftClient var32 = var164;
         ClientWorld var230 = var32.world;
         if (var230 == null) {
            return;
         }

         MinecraftClient var231 = b;
         var165 = var231;
      }

      MinecraftClient var35 = var165;
      ClientPlayerEntity var232 = var35.player;
      if (var232 != null) {
         MsdfFontManager var10000 = Prestige.c;
         Object[] var38 = new Object[]{51869363673471L};
         MsdfFontManager var37 = var10000;
         MsdfFont var19 = var37.aReturningcx_C0158(var38);
         ModuleManager var347 = Prestige.d;
         Object[] var40 = new Object[0];
         ModuleManager var39 = var347;
         MenuSettings var348 = var39.aReturningMenuSettings(var40);
         Object[] var42 = new Object[0];
         MenuSettings var41 = var348;
         ColorSetting var43 = var41.bReturningColorSetting(var42);
         Color var20 = (Color)var43.aReturningObject();
         Map var44 = this.s;
         var44.clear();
         MinecraftClient var45 = b;
         ClientWorld var46 = var45.world;
         List var47 = var46.getPlayers();
         Iterator var21 = var47.iterator();

         label236:
         while (true) {
            Iterator var166 = var21;

            label234:
            while (true) {
               Iterator var48 = var166;
               boolean var167 = var48.hasNext();

               Object var227;
               label231:
               while (true) {
                  boolean var233 = var167;
                  if (var233) {
                     int var235 = var18;
                     Iterator var234 = var21;
                     var166 = var234;
                     Iterator var168 = var234;
                     if (var235 == 0) {
                        continue label234;
                     }

                     Iterator var49 = var168;
                     PlayerEntity var22 = (PlayerEntity)var49.next();
                     int var237 = var18;
                     PlayerEntity var236 = var22;
                     var227 = var236;
                     PlayerEntity var169 = var236;
                     if (var237 == 0) {
                        break;
                     }

                     MinecraftClient var50 = b;
                     ClientPlayerEntity var239 = var50.player;
                     PlayerEntity var238 = var169;
                     if (var238 == var239) {
                        continue label236;
                     }

                     int var241 = var18;
                     PlayerValidationTracker var240 = Prestige.i;
                     Object var171 = var240;
                     PlayerValidationTracker var170 = var240;
                     if (var241 != 0) {
                        Object[] var53 = new Object[]{var22, 99841884226244L};
                        PlayerValidationTracker var52 = var170;
                        boolean var242 = var52.aReturningBoolean(var53);
                        if (!var242) {
                           int var243 = var18;
                           if (var243 != 0) {
                              continue label236;
                           }
                        }

                        PlayerEntity var57 = var22;
                        Map var56 = this.u;
                        var171 = var56.get(var57);
                     }

                     PlayerNameTagData var24 = (PlayerNameTagData)var171;
                     PlayerNameTagData var23 = new PlayerNameTagData();
                     PlayerEntity var58 = var22;
                     Text var59 = var58.getName();
                     var23.a = var59.getString();
                     SocialsManager var367 = Prestige.g;
                     Object[] var61 = new Object[]{var23.a, 40309233401297L};
                     SocialsManager var60 = var367;
                     boolean var245 = var60.aReturningBoolean(var61);
                     PlayerNameTagData var244 = var23;
                     PlayerNameTagData var173 = var244;
                     PlayerNameTagData var172 = var244;
                     PlayerNameTagData var174;
                     Color var175;
                     if (var245) {
                        Color var247 = q;
                        PlayerNameTagData var246 = var172;
                        var174 = var246;
                        var175 = var247;
                     } else {
                        var175 = UiMetrics.s;
                        var174 = var173;
                     }

                     var174.b = var175;
                     PlayerEntity var63 = var22;
                     float var349 = var63.getHealth();
                     PlayerEntity var64 = var22;
                     float var25 = var349 + var64.getAbsorptionAmount();
                     PlayerEntity var65 = var22;
                     float var350 = var65.getMaxHealth();
                     PlayerEntity var66 = var22;
                     float var26 = var350 + var66.getAbsorptionAmount();
                     float var68 = var26;
                     float var67 = 1.0F;
                     float var368 = var25 / Math.max(var67, var68);
                     Object[] var10006 = new Object[]{null, null, null, 107486503572140L};
                     var10006[2] = 1.0F;
                     var10006[1] = 0.0F;
                     var10006[0] = var368;
                     Object[] var69 = var10006;
                     var23.e = ClientUiUtil.aReturningFloat(var69);
                     int var249 = var18;
                     PlayerNameTagData var248 = var24;
                     PlayerNameTagData var177 = var248;
                     PlayerNameTagData var176 = var248;
                     float var178;
                     if (var249 != 0) {
                        PlayerNameTagData var250 = var176;
                        if (var250 == null) {
                           float var251 = var23.e;
                           var178 = var251;
                        } else {
                           var177 = var24;
                           var178 = var177.f;
                        }
                     } else {
                        var178 = var177.f;
                     }

                     float var27 = var178;
                     float var73 = var27 + (var23.e - var27) * 0.15F;
                     float var72 = var23.e;
                     var23.f = Math.max(var72, var73);
                     float var373;
                     int var351 = (var373 = var23.e - var27) == 0.0F ? 0 : (var373 < 0.0F ? -1 : 1);
                     int var253 = var18;
                     int var252 = var351;
                     int var180 = var252;
                     int var179 = var252;
                     if (var253 != 0) {
                        int var254 = var179;
                        if (var254 > 0) {
                           var23.f = var23.e;
                        }

                        float var374;
                        var180 = (var374 = var23.e - 0.6F) == 0.0F ? 0 : (var374 < 0.0F ? -1 : 1);
                     }

                     label223: {
                        int var256 = var18;
                        int var255 = var180;
                        int var184 = var255;
                        int var181 = var255;
                        if (var256 != 0) {
                           int var257 = var181;
                           if (var257 > 0) {
                              var23.g = var20;
                              int var258 = var18;
                              if (var258 != 0) {
                                 break label223;
                              }
                           }

                           int var260 = var18;
                           PlayerNameTagData var259 = var23;
                           PlayerNameTagData var185 = var259;
                           PlayerNameTagData var182 = var259;
                           if (var260 == 0) {
                              var185.g = m;
                              break label223;
                           }

                           PlayerNameTagData var261 = var182;
                           PlayerNameTagData var183 = var261;
                           float var375;
                           int var262 = (var375 = var183.e - 0.3F) == 0.0F ? 0 : (var375 < 0.0F ? -1 : 1);
                           var184 = var262;
                        }

                        int var263 = var184;
                        if (var263 > 0) {
                           var23.g = l;
                           int var264 = var18;
                           if (var264 == 0) {
                              PlayerNameTagData var265 = var23;
                              PlayerNameTagData var334 = var265;
                              var334.g = m;
                           }
                        } else {
                           PlayerNameTagData var342 = var23;
                           PlayerNameTagData var335 = var342;
                           var335.g = m;
                        }
                     }

                     PlayerNameTagData var199;
                     String var200;
                     label214: {
                        TotemPopTracker var369 = Prestige.r;
                        Object[] var83 = new Object[]{var22, 131915912111306L};
                        TotemPopTracker var82 = var369;
                        var23.c = var82.aReturningInt(var83);
                        BooleanSetting var84 = this.g;
                        Boolean var85 = (Boolean)var84.aReturningObject();
                        byte var370 = ((byte)(((java.lang.Boolean)(var85)).booleanValue() ? 1 : 0));
                        int var268 = var18;
                        byte var267 = var370;
                        PlayerNameTagData var266 = var23;
                        PlayerNameTagData var190 = var266;
                        int var191 = var267;
                        PlayerNameTagData var186 = var266;
                        byte var187 = var267;
                        if (var268 != 0) {
                           byte var270 = var187;
                           PlayerNameTagData var269 = var186;
                           PlayerNameTagData var198 = var269;
                           PlayerNameTagData var188 = var269;
                           if (var270 == 0) {
                              var200 = "";
                              var199 = var198;
                              break label214;
                           }

                           PlayerNameTagData var271 = var188;
                           PlayerNameTagData var189 = var271;
                           int var273 = var23.c;
                           PlayerNameTagData var272 = var189;
                           var190 = var272;
                           var191 = var273;
                        }

                        int var276 = var18;
                        int var275 = var191;
                        PlayerNameTagData var274 = var190;
                        PlayerNameTagData var196 = var274;
                        int var197 = var275;
                        PlayerNameTagData var192 = var274;
                        int var193 = var275;
                        if (var276 != 0) {
                           int var278 = var193;
                           PlayerNameTagData var277 = var192;
                           PlayerNameTagData var338 = var277;
                           PlayerNameTagData var194 = var277;
                           if (var278 > 0) {
                              PlayerNameTagData var279 = var194;
                              PlayerNameTagData var195 = var279;
                              int var281 = var23.c;
                              PlayerNameTagData var280 = var195;
                              var196 = var280;
                              var197 = var281;
                              String var283 = "-" + var197;
                              PlayerNameTagData var282 = var196;
                              var199 = var282;
                              var200 = var283;
                           } else {
                              var200 = "";
                              var199 = var338;
                           }
                        } else {
                           String var344 = "-" + var197;
                           PlayerNameTagData var343 = var196;
                           var199 = var343;
                           var200 = var344;
                        }
                     }

                     var199.d = var200;
                     int var284 = var18;
                     if (var284 != 0) {
                        BooleanSetting var90 = this.f;
                        Boolean var91 = (Boolean)var90.aReturningObject();
                        boolean var285 = var91;
                        if (var285) {
                           float var93 = var25;
                           var23.h = Math.round(var93) + "hp";
                           int var286 = var18;
                           if (var286 == 0) {
                              var23.h = "";
                           }
                        } else {
                           var23.h = "";
                        }
                     } else {
                        int var345 = var18;
                        if (var345 == 0) {
                           var23.h = "";
                        }
                     }

                     BooleanSetting var96 = this.h;
                     Boolean var97 = (Boolean)var96.aReturningObject();
                     boolean var352 = var97;
                     int var288 = var18;
                     boolean var287 = var352;
                     boolean var206 = var287;
                     boolean var201 = var287;
                     if (var288 != 0) {
                        boolean var289 = var201;
                        if (var289) {
                           PlayerEntity var99 = var22;
                           ItemStack var100 = var99.getMainHandStack();
                           boolean var353 = var100.isEmpty();
                           int var291 = var18;
                           boolean var290 = var353;
                           boolean var204 = var290;
                           boolean var202 = var290;
                           if (var291 != 0) {
                              boolean var292 = var202;
                              boolean var203 = var292;
                              boolean var293 = var203;
                              if (!var293) {
                                 List var354 = var23.l;
                                 PlayerEntity var103 = var22;
                                 ItemStack var105 = var103.getMainHandStack();
                                 List var104 = var354;
                                 var104.add(var105);
                              }

                              PlayerEntity var107 = var22;
                              ItemStack var108 = var107.getOffHandStack();
                              var204 = var108.isEmpty();
                           }

                           int var295 = var18;
                           boolean var294 = var204;
                           var206 = var294;
                           boolean var205 = var294;
                           if (var295 != 0) {
                              boolean var296 = var205;
                              if (!var296) {
                                 List var355 = var23.l;
                                 PlayerEntity var110 = var22;
                                 ItemStack var112 = var110.getOffHandStack();
                                 List var111 = var355;
                                 var111.add(var112);
                              }

                              BooleanSetting var114 = this.i;
                              Boolean var115 = (Boolean)var114.aReturningObject();
                              var206 = var115;
                           }
                        } else {
                           BooleanSetting var328 = this.i;
                           Boolean var329 = (Boolean)var328.aReturningObject();
                           var206 = var329;
                        }
                     }

                     label207: {
                        int var298 = var18;
                        boolean var297 = var206;
                        boolean var208 = var297;
                        boolean var207 = var297;
                        boolean var28;
                        Iterator var29;
                        if (var298 != 0) {
                           boolean var299 = var207;
                           if (!var299) {
                              break label207;
                           }

                           BooleanSetting var117 = this.j;
                           Boolean var118 = (Boolean)var117.aReturningObject();
                           boolean var300 = var118;
                           var208 = var300;
                           var28 = var208;
                           AttributeModifierSlot var120 = AttributeModifierSlot.ARMOR;
                           var29 = var120.iterator();
                        } else {
                           var28 = var208;
                           AttributeModifierSlot var330 = AttributeModifierSlot.ARMOR;
                           var29 = var330.iterator();
                        }

                        while (true) {
                           Iterator var121 = var29;
                           boolean var301 = var121.hasNext();
                           if (!var301) {
                              break;
                           }

                           Iterator var122 = var29;
                           EquipmentSlot var30 = (EquipmentSlot)var122.next();
                           EquipmentSlot var124 = var30;
                           PlayerEntity var123 = var22;
                           ItemStack var31 = var123.getEquippedStack(var124);
                           ItemStack var125 = var31;
                           boolean var356 = var125.isEmpty();
                           int var303 = var18;
                           boolean var302 = var356;
                           var167 = var302;
                           boolean var209 = var302;
                           if (var303 == 0) {
                              continue label231;
                           }

                           int var305 = var18;
                           boolean var304 = var209;
                           boolean var211 = var304;
                           boolean var210 = var304;
                           if (var305 != 0) {
                              boolean var306 = var210;
                              if (var306) {
                                 continue;
                              }

                              ItemStack var128 = var31;
                              List var127 = var23.l;
                              var127.add(var128);
                              var211 = var28;
                           }

                           int var308 = var18;
                           boolean var307 = var211;
                           boolean var212 = var307;
                           if (var308 != 0) {
                              boolean var309 = var212;
                              if (var309) {
                                 List var357 = var23.m;
                                 Object[] var131 = new Object[]{var31, 114652272783294L};
                                 NameTags var130 = this;
                                 List var133 = var130.bReturningList(var131);
                                 List var132 = var357;
                                 boolean var310 = var132.addAll(var133);
                              }
                           }

                           int var311 = var18;
                           if (var311 == 0) {
                              break;
                           }
                        }
                     }

                     Object[] var136 = new Object[]{var23.a, 117628177084989L};
                     MsdfFont var135 = var19;
                     float var371 = var135.aReturningFloat(var136);
                     int var314 = var18;
                     float var313 = var371;
                     PlayerNameTagData var312 = var23;
                     PlayerNameTagData var219 = var312;
                     float var220 = var313;
                     PlayerNameTagData var214 = var312;
                     float var215 = var313;
                     PlayerNameTagData var221;
                     float var222;
                     if (var314 != 0) {
                        var214.i = var215;
                        String var137 = var23.d;
                        boolean var316 = var137.isEmpty();
                        PlayerNameTagData var315 = var23;
                        PlayerNameTagData var218 = var315;
                        PlayerNameTagData var216 = var315;
                        if (var316) {
                           PlayerNameTagData var317 = var216;
                           PlayerNameTagData var217 = var317;
                           float var319 = 0.0F;
                           PlayerNameTagData var318 = var217;
                           var221 = var318;
                           var222 = var319;
                        } else {
                           Object[] var141 = new Object[]{var23.d, 117628177084989L};
                           MsdfFont var140 = var19;
                           var220 = var140.aReturningFloat(var141);
                           var219 = var218;
                           var222 = var220 * 0.75F;
                           var221 = var219;
                        }
                     } else {
                        var222 = var220 * 0.75F;
                        var221 = var219;
                     }

                     var221.j = var222;
                     String var142 = var23.h;
                     boolean var321 = var142.isEmpty();
                     PlayerNameTagData var320 = var23;
                     PlayerNameTagData var224 = var320;
                     PlayerNameTagData var223 = var320;
                     PlayerNameTagData var225;
                     float var226;
                     if (var321) {
                        float var323 = 0.0F;
                        PlayerNameTagData var322 = var223;
                        var225 = var322;
                        var226 = var323;
                     } else {
                        Object[] var145 = new Object[]{var23.h, 117628177084989L};
                        MsdfFont var144 = var19;
                        var226 = var144.aReturningFloat(var145) * 0.75F;
                        var225 = var224;
                     }

                     var225.k = var226;
                     PlayerNameTagData var148 = var23;
                     PlayerEntity var147 = var22;
                     Map var146 = this.s;
                     var146.put(var147, var148);
                     int var324 = var18;
                     if (var324 != 0) {
                        continue label236;
                     }
                  }

                  List var149 = this.t;
                  var149.clear();
                  List var358 = this.t;
                  Map var150 = this.s;
                  Set var152 = var150.entrySet();
                  List var151 = var358;
                  var151.addAll(var152);
                  List var359 = this.t;
                  Comparator var154 = invokeBinding2();
                  List var153 = var359;
                  var153.sort(var154);
                  Map var155 = this.u;
                  var155.clear();
                  List var156 = this.t;
                  var21 = var156.iterator();
                  Iterator var157 = var21;
                  boolean var325 = var157.hasNext();
                  if (!var325) {
                     return;
                  }

                  Iterator var158 = var21;
                  var227 = var158.next();
                  break;
               }

               while (true) {
                  Entry var327 = (Entry)var227;
                  Map var360 = this.u;
                  Entry var159 = var327;
                  PlayerEntity var372 = (PlayerEntity)var159.getKey();
                  Entry var160 = var327;
                  PlayerNameTagData var163 = (PlayerNameTagData)var160.getValue();
                  PlayerEntity var162 = var372;
                  Map var161 = var360;
                  var161.put(var162, var163);
                  int var326 = var18;
                  if (var326 == 0) {
                     return;
                  }

                  Iterator var331 = var21;
                  boolean var346 = var331.hasNext();
                  if (!var346) {
                     return;
                  }

                  Iterator var332 = var21;
                  var227 = var332.next();
               }
            }
         }
      }
   }

   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      long var10001 = 1632691010579L ^ 15697899746030L;
      var10001 = 1632691010579L ^ 134396719957078L;
      var10001 = 1632691010579L ^ 125176439932038L;
      var10001 = 1632691010579L ^ 50924974810476L;
      var10001 = 1632691010579L ^ 121574997007828L;
      var10001 = 1632691010579L ^ 62221934814050L;
      var10001 = 1632691010579L ^ 75952599383978L;
      var10001 = 1632691010579L ^ 28935993791960L;
      var10001 = 1632691010579L ^ 23455878694535L;
      var10001 = 1632691010579L ^ 106369246736063L;
      var10001 = 1632691010579L ^ 16872488088886L;
      var10001 = 1632691010579L ^ 118228944834094L;
      var10001 = 1632691010579L ^ 9092564404880L;
      int var30 = Event.bReturningInt();
      MinecraftClient var85 = b;
      ClientPlayerEntity var324 = var85.player;
      if (var324 != null) {
         MsdfFont var31;
         float var32;
         float var33;
         float var34;
         byte var35;
         byte var36;
         byte var246;
         label353: {
            byte var245;
            MsdfFontManager var10000 = Prestige.c;
            Object[] var88 = new Object[]{51869363673471L};
            MsdfFontManager var87 = var10000;
            var31 = var87.aReturningcx_C0158(var88);
            Object[] var90 = new Object[]{15549079685413L};
            MsdfFont var89 = var31;
            var32 = var89.cReturningFloat(var90);
            Object[] var91 = new Object[]{var32};
            var33 = UiMetrics.bReturningFloat(var91);
            FloatSetting var92 = this.d;
            Float var93 = (Float)var92.aReturningObject();
            var34 = var93;
            BooleanSetting var94 = this.e;
            Boolean var95 = (Boolean)var94.aReturningObject();
            var35 = ((byte)(((java.lang.Boolean)(var95)).booleanValue() ? 1 : 0));
            BooleanSetting var96 = this.f;
            Boolean var97 = (Boolean)var96.aReturningObject();
            var36 = ((byte)(((java.lang.Boolean)(var97)).booleanValue() ? 1 : 0));
            BooleanSetting var98 = this.h;
            Boolean var99 = (Boolean)var98.aReturningObject();
            byte var470 = ((byte)(((java.lang.Boolean)(var99)).booleanValue() ? 1 : 0));
            int var326 = var30;
            byte var325 = var470;
            var245 = var325;
            byte var242 = var325;
            label352:
            if (var326 == 0) {
               byte var327 = var242;
               if (var327 == 0) {
                  BooleanSetting var101 = this.i;
                  Boolean var102 = (Boolean)var101.aReturningObject();
                  byte var471 = ((byte)(((java.lang.Boolean)(var102)).booleanValue() ? 1 : 0));
                  int var329 = var30;
                  byte var328 = var471;
                  var245 = var328;
                  byte var243 = var328;
                  if (var329 != 0) {
                     break label352;
                  }

                  byte var330 = var243;
                  byte var244 = var330;
                  byte var331 = var244;
                  if (var331 == 0) {
                     var246 = 0;
                     break label353;
                  }
               }

               var245 = 1;
            }

            byte var332 = var245;
            var246 = var332;
         }

         byte var37;
         byte var251;
         label343: {
            byte var250;
            label342: {
               label357: {
                  var37 = var246;
                  BooleanSetting var105 = this.j;
                  Boolean var106 = (Boolean)var105.aReturningObject();
                  byte var472 = ((byte)(((java.lang.Boolean)(var106)).booleanValue() ? 1 : 0));
                  int var334 = var30;
                  byte var333 = var472;
                  byte var248 = var333;
                  byte var247 = var333;
                  if (var334 == 0) {
                     byte var335 = var247;
                     if (var335 == 0) {
                        break label357;
                     }

                     BooleanSetting var108 = this.i;
                     Boolean var109 = (Boolean)var108.aReturningObject();
                     byte var336 = ((byte)(((java.lang.Boolean)(var109)).booleanValue() ? 1 : 0));
                     var248 = var336;
                  }

                  int var338 = var30;
                  byte var337 = var248;
                  var250 = var337;
                  byte var249 = var337;
                  if (var338 != 0) {
                     break label342;
                  }

                  byte var339 = var249;
                  if (var339 != 0) {
                     var250 = 1;
                     break label342;
                  }
               }

               var251 = 0;
               break label343;
            }

            byte var340 = var250;
            var251 = var340;
         }

         byte var38 = var251;
         IntSetting var112 = this.c;
         Integer var113 = (Integer)var112.aReturningObject();
         int var39 = var113;
         Map var114 = this.u;
         Set var115 = var114.entrySet();
         Iterator var41 = var115.iterator();

         label329:
         while (true) {
            Iterator var252 = var41;

            label327:
            while (true) {
               Iterator var116 = var252;
               boolean var341 = var116.hasNext();
               if (!var341) {
                  return;
               }

               Iterator var117 = var41;
               Object var253 = var117.next();

               label324:
               while (true) {
                  Entry var42 = (Entry)var253;
                  int var343 = var39;
                  int var342 = var40;
                  if (var342 >= var343) {
                     return;
                  }

                  PlayerEntity var43;
                  PlayerNameTagData var44;
                  label201: {
                     Entry var118 = var42;
                     var43 = (PlayerEntity)var118.getKey();
                     Entry var119 = var42;
                     var44 = (PlayerNameTagData)var119.getValue();
                     int var345 = var30;
                     Frustum var344 = this.r;
                     Frustum var255 = var344;
                     Frustum var254 = var344;
                     if (var345 == 0) {
                        Frustum var346 = var254;
                        if (var346 == null) {
                           break label201;
                        }

                        Frustum var347 = this.r;
                        var255 = var347;
                     }

                     PlayerEntity var122 = var43;
                     Box var124 = var122.getBoundingBox();
                     Frustum var123 = var255;
                     boolean var348 = var123.isVisible(var124);
                     if (!var348) {
                        continue label329;
                     }
                  }

                  MinecraftClient var126 = b;
                  PlayerEntity var128 = var43;
                  ClientPlayerEntity var127 = var126.player;
                  float var45 = var127.distanceTo((Entity)var128);
                  float var537;
                  int var349 = (var537 = var45 - var34) == 0.0F ? 0 : (var537 < 0.0F ? -1 : 1);
                  if (var349 > 0) {
                     continue label329;
                  }

                  Vec3d var47;
                  Object var259;
                  label360: {
                     Object[] var130 = new Object[]{var43, 123069091094983L};
                     Vec3d var46 = GameRenderUtil.bReturningVec3d(var130);
                     PlayerEntity var131 = var43;
                     double var10002 = var131.getHeight() + 0.5 * (var45 / 10.0F);
                     double var135 = var10002;
                     Vec3d var132 = var46;
                     Object[] var139 = new Object[]{var132.add(var133, var135, var137), 123853079263381L};
                     var47 = GameRenderUtil.aReturningVec3d(var139);
                     Vec3d var140 = var47;
                     double var538;
                     int var473 = (var538 = var140.z - 0.0) == 0.0 ? 0 : (var538 < 0.0 ? -1 : 1);
                     int var351 = var30;
                     int var350 = var473;
                     int var258 = var350;
                     int var256 = var350;
                     if (var351 == 0) {
                        int var352 = var256;
                        if (var352 < 0) {
                           continue label329;
                        }

                        int var354 = var30;
                        Vec3d var353 = var47;
                        var259 = var353;
                        Vec3d var257 = var353;
                        if (var354 != 0) {
                           break label360;
                        }

                        Vec3d var142 = var257;
                        double var539;
                        int var355 = (var539 = var142.z - 1.0) == 0.0 ? 0 : (var539 < 0.0 ? -1 : 1);
                        var258 = var355;
                     }

                     int var356 = var258;
                     if (var356 >= 0) {
                        continue label329;
                     }

                     var40++;
                     FloatSetting var144 = this.a;
                     var259 = var144.aReturningObject();
                  }

                  float var48;
                  float var266;
                  label220: {
                     float var264;
                     float var265;
                     label362: {
                        Float var145 = (Float)var259;
                        var48 = var145 * 0.8F - var45 / 300.0F;
                        float var540;
                        int var474 = (var540 = var48 - 0.15F) == 0.0F ? 0 : (var540 < 0.0F ? -1 : 1);
                        int var358 = var30;
                        int var357 = var474;
                        int var263 = var357;
                        int var260 = var357;
                        if (var358 == 0) {
                           int var359 = var260;
                           if (var359 < 0) {
                              var48 = 0.15F;
                           }

                           float var497 = var34 - 10.0F;
                           int var362 = var30;
                           float var361 = var497;
                           float var360 = var45;
                           var264 = var360;
                           var265 = var361;
                           float var261 = var360;
                           float var262 = var361;
                           if (var362 != 0) {
                              break label362;
                           }

                           float var541;
                           int var363 = (var541 = var261 - var262) == 0.0F ? 0 : (var541 < 0.0F ? -1 : 1);
                           var263 = var363;
                        }

                        int var364 = var263;
                        if (var364 <= 0) {
                           var266 = 1.0F;
                           break label220;
                        }

                        float var475 = (var34 - var45) / 10.0F;
                        float var366 = 0.0F;
                        float var365 = var475;
                        var264 = var365;
                        var265 = var366;
                     }

                     Object[] var10005 = new Object[]{null, null, null, 107486503572140L};
                     var10005[2] = 1.0F;
                     var10005[1] = var265;
                     var10005[0] = var264;
                     Object[] var149 = var10005;
                     float var367 = ClientUiUtil.aReturningFloat(var149);
                     var266 = var367;
                  }

                  float var49;
                  float var50;
                  float var51;
                  Matrix4f var52;
                  String var269;
                  label226: {
                     var49 = var266;
                     Vec3d var150 = var47;
                     var50 = (float)var150.x / var48;
                     Vec3d var151 = var47;
                     var51 = (float)var151.y / var48;
                     Matrix4f var476 = new Matrix4f();
                     float var155 = var48;
                     float var154 = var48;
                     float var153 = var48;
                     Matrix4f var152 = var476;
                     var52 = var152.scale(var153, var154, var155);
                     int var369 = var30;
                     byte var368 = var35;
                     int var268 = var368;
                     byte var267 = var368;
                     if (var369 == 0) {
                        byte var370 = var267;
                        if (var370 == 0) {
                           var269 = "";
                           break label226;
                        }

                        float var157 = var45;
                        int var371 = Math.round(var157);
                        var268 = var371;
                     }

                     String var372 = var268 + "m";
                     var269 = var372;
                  }

                  String var53 = var269;
                  String var159 = var53;
                  boolean var373 = var159.isEmpty();
                  float var270;
                  if (var373) {
                     float var374 = 0.0F;
                     var270 = var374;
                  } else {
                     Object[] var162 = new Object[]{var53, 117628177084989L};
                     MsdfFont var161 = var31;
                     var270 = var161.aReturningFloat(var162) * 0.65F;
                  }

                  float var54 = var270;
                  float var477 = var44.i;
                  String var163 = var44.d;
                  boolean var376 = var163.isEmpty();
                  float var375 = var477;
                  float var272 = var375;
                  float var271 = var375;
                  float var273;
                  float var274;
                  if (var376) {
                     float var378 = 0.0F;
                     float var377 = var271;
                     var273 = var377;
                     var274 = var378;
                  } else {
                     var274 = 3.0F + var44.j;
                     var273 = var272;
                  }

                  float var55 = var273 + var274;
                  float var56 = 0.0F;
                  String var165 = var53;
                  boolean var379 = var165.isEmpty();
                  if (!var379) {
                     var56 = var54;
                  }

                  float var284;
                  float var285;
                  label233: {
                     int var383 = var30;
                     float var382 = 0.0F;
                     float var381 = var56;
                     float var380 = var55;
                     float var280 = var380;
                     float var281 = var381;
                     float var282 = var382;
                     float var275 = var380;
                     float var276 = var381;
                     float var277 = var382;
                     if (var383 == 0) {
                        float var542;
                        int var385 = (var542 = var276 - var277) == 0.0F ? 0 : (var542 < 0.0F ? -1 : 1);
                        float var384 = var275;
                        float var283 = var384;
                        float var278 = var384;
                        if (var385 <= 0) {
                           var285 = 0.0F;
                           var284 = var283;
                           break label233;
                        }

                        float var386 = var278;
                        float var279 = var386;
                        float var389 = var56;
                        float var388 = 6.0F;
                        float var387 = var279;
                        var280 = var387;
                        var281 = var388;
                        var282 = var389;
                     }

                     float var391 = var281 + var282;
                     float var390 = var280;
                     var284 = var390;
                     var285 = var391;
                  }

                  float var57 = var284 + var285;
                  float var58 = 60.0F;
                  float var169 = var58;
                  float var168 = var57;
                  float var59 = Math.max(var168, var169);
                  byte var392 = var36;
                  if (var392 != 0) {
                     float var171 = var55 + 6.0F + var44.k;
                     float var170 = var59;
                     var59 = Math.max(var170, var171);
                  }

                  float var60 = var59 + 11.0F;
                  float var61 = var50 - var60 / 2.0F;
                  float var62 = var51 - var33 / 2.0F;
                  MeshBufferManager var478 = var1.a;
                  RenderContext var498 = var1.b;
                  Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 16745277116157L};
                  var10011[8] = 4.0F;
                  var10011[7] = 5;
                  var10011[6] = var33;
                  var10011[5] = var60;
                  var10011[4] = var62;
                  var10011[3] = var61;
                  var10011[2] = var52;
                  var10011[1] = var498;
                  var10011[0] = var478;
                  Object[] var172 = var10011;
                  BlurredRectangleRenderer.eReturningVoid(var172);
                  MeshBufferManager var479 = var1.a;
                  RenderContext var499 = var1.b;
                  Color var10007 = UiMetrics.r;
                  var10011 = new Object[]{null, null, 135547275655237L};
                  var10011[1] = var49;
                  var10011[0] = var10007;
                  Object[] var173 = var10011;
                  var10007 = aReturningColor(var173);
                  var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
                  var10011[8] = 4.0F;
                  var10011[7] = var10007;
                  var10011[6] = var33;
                  var10011[5] = var60;
                  var10011[4] = var62;
                  var10011[3] = var61;
                  var10011[2] = var52;
                  var10011[1] = var499;
                  var10011[0] = var479;
                  Object[] var174 = var10011;
                  FilledRectangleRenderer.cReturningVoid(var174);
                  float var63 = var62 + 3.0F;
                  float var64 = var61 + 5.5F;
                  float var65 = var61 + var60 - 5.5F;
                  String var502 = var44.a;
                  Color var513 = var44.b;
                  Object[] var10009 = new Object[]{null, null, 135547275655237L};
                  var10009[1] = var49;
                  var10009[0] = var513;
                  Object[] var175 = var10009;
                  Object[] var10008 = new Object[]{null, null, null, null, aReturningColor(var175), 10141036836483L};
                  var10008[3] = var63;
                  var10008[2] = var64;
                  var10008[1] = var502;
                  var10008[0] = var52;
                  Object[] var177 = var10008;
                  MsdfFont var176 = var31;
                  var176.v(var177);
                  float var66 = var64 + var44.i + 3.0F;
                  String var178 = var44.d;
                  boolean var480 = var178.isEmpty();
                  int var394 = var30;
                  boolean var393 = var480;
                  boolean var287 = var393;
                  boolean var286 = var393;
                  if (var394 == 0) {
                     boolean var395 = var286;
                     if (!var395) {
                        float var67 = var32 - var32 * 0.75F;
                        var502 = var44.d;
                        float var10004 = var63 + var67;
                        Color var10006 = p;
                        Object[] var10010 = new Object[]{null, null, 135547275655237L};
                        var10010[1] = var49;
                        var10010[0] = var10006;
                        Object[] var180 = var10010;
                        var10009 = new Object[]{null, null, null, null, null, aReturningColor(var180), 75214344094649L};
                        var10009[4] = 0.75F;
                        var10009[3] = var10004;
                        var10009[2] = var66;
                        var10009[1] = var502;
                        var10009[0] = var52;
                        Object[] var182 = var10009;
                        MsdfFont var181 = var31;
                        var181.w(var182);
                     }

                     String var183 = var53;
                     var287 = var183.isEmpty();
                  }

                  boolean var396 = var287;
                  if (!var396) {
                     float var466 = var32 - var32 * 0.65F;
                     float var10003 = var65 - var54;
                     float var508 = var63 + var466;
                     Color var517 = UiMetrics.u;
                     Object[] var532 = new Object[]{null, null, 135547275655237L};
                     var532[1] = var49;
                     var532[0] = var517;
                     Object[] var184 = var532;
                     var10009 = new Object[]{null, null, null, null, null, aReturningColor(var184), 75214344094649L};
                     var10009[4] = 0.65F;
                     var10009[3] = var508;
                     var10009[2] = var10003;
                     var10009[1] = var53;
                     var10009[0] = var52;
                     Object[] var186 = var10009;
                     MsdfFont var185 = var31;
                     var185.w(var186);
                  }

                  float var68;
                  float var69;
                  float var467;
                  label245: {
                     var467 = var63 + var32 + 1.0F;
                     var68 = var64;
                     var69 = var65;
                     int var398 = var30;
                     byte var397 = var36;
                     byte var289 = var397;
                     byte var288 = var397;
                     if (var398 == 0) {
                        byte var399 = var288;
                        if (var399 == 0) {
                           break label245;
                        }

                        String var188 = var44.h;
                        byte var400 = ((byte)((var188.isEmpty()) ? 1 : 0));
                        var289 = var400;
                     }

                     byte var401 = var289;
                     if (var401 == 0) {
                        var69 -= var44.k + 3.0F;
                     }
                  }

                  float var70 = var69 - var68;
                  Vector4f var71 = new Vector4f(1.5F, 1.5F, 1.5F, 1.5F);
                  float var506 = var68 + var70;
                  float var509 = var467 + 4.0F;
                  var513 = n;
                  var10009 = new Object[]{null, null, 135547275655237L};
                  var10009[1] = var49;
                  var10009[0] = var513;
                  Object[] var190 = var10009;
                  var10009 = new Object[]{null, null, null, null, null, aReturningColor(var190), var71, 22166806919828L};
                  var10009[4] = var509;
                  var10009[3] = var506;
                  var10009[2] = var467;
                  var10009[1] = var68;
                  var10009[0] = var52;
                  Object[] var191 = var10009;
                  ShapeRenderer.u(var191);
                  float var72 = var68 + var70 * var44.f;
                  float var73 = var68 + var70 * var44.e;
                  float var543;
                  int var481 = (var543 = var44.f - (var44.e + 0.001F)) == 0.0F ? 0 : (var543 < 0.0F ? -1 : 1);
                  int var403 = var30;
                  int var402 = var481;
                  int var291 = var402;
                  int var290 = var402;
                  if (var403 == 0) {
                     int var404 = var290;
                     if (var404 > 0) {
                        var509 = var467 + 4.0F;
                        var513 = o;
                        var10009 = new Object[]{null, null, 135547275655237L};
                        var10009[1] = var49;
                        var10009[0] = var513;
                        Object[] var193 = var10009;
                        var10009 = new Object[]{null, null, null, null, null, aReturningColor(var193), var71, 22166806919828L};
                        var10009[4] = var509;
                        var10009[3] = var72;
                        var10009[2] = var467;
                        var10009[1] = var73;
                        var10009[0] = var52;
                        Object[] var194 = var10009;
                        ShapeRenderer.u(var194);
                     }

                     float var544;
                     var291 = (var544 = var44.e - 0.001F) == 0.0F ? 0 : (var544 < 0.0F ? -1 : 1);
                  }

                  int var406 = var30;
                  int var405 = var291;
                  int var293 = var405;
                  int var292 = var405;
                  if (var406 == 0) {
                     int var407 = var292;
                     if (var407 > 0) {
                        var509 = var467 + 4.0F;
                        var513 = var44.g;
                        var10009 = new Object[]{null, null, 135547275655237L};
                        var10009[1] = var49;
                        var10009[0] = var513;
                        Object[] var197 = var10009;
                        var10009 = new Object[]{null, null, null, null, null, aReturningColor(var197), var71, 22166806919828L};
                        var10009[4] = var509;
                        var10009[3] = var73;
                        var10009[2] = var467;
                        var10009[1] = var68;
                        var10009[0] = var52;
                        Object[] var198 = var10009;
                        ShapeRenderer.u(var198);
                     }

                     var293 = var36;
                  }

                  int var297;
                  int var409 = var30;
                  int var408 = var293;
                  var297 = var408;
                  int var294 = var408;
                  label257:
                  if (var409 == 0) {
                     int var410 = var294;
                     if (var410 != 0) {
                        String var201 = var44.h;
                        byte var482 = ((byte)((var201.isEmpty()) ? 1 : 0));
                        int var412 = var30;
                        byte var411 = var482;
                        var297 = var411;
                        byte var295 = var411;
                        if (var412 != 0) {
                           break label257;
                        }

                        byte var413 = var295;
                        byte var296 = var413;
                        byte var414 = var296;
                        if (var414 == 0) {
                           float var74 = var467 + 2.0F - var32 * 0.75F / 2.0F;
                           var502 = var44.h;
                           var506 = var69 + 3.0F;
                           Color var518 = var44.g;
                           Object[] var533 = new Object[]{null, null, 135547275655237L};
                           var533[1] = var49;
                           var533[0] = var518;
                           Object[] var204 = var533;
                           var10009 = new Object[]{null, null, null, null, null, aReturningColor(var204), 75214344094649L};
                           var10009[4] = 0.75F;
                           var10009[3] = var74;
                           var10009[2] = var506;
                           var10009[1] = var502;
                           var10009[0] = var52;
                           Object[] var206 = var10009;
                           MsdfFont var205 = var31;
                           var205.w(var206);
                        }
                     }

                     var297 = var37;
                  }

                  int var416 = var30;
                  int var415 = var297;
                  int var299 = var415;
                  int var298 = var415;
                  if (var416 == 0) {
                     int var417 = var298;
                     if (var417 == 0) {
                        break;
                     }

                     List var208 = var44.l;
                     byte var418 = ((byte)((var208.isEmpty()) ? 1 : 0));
                     var299 = var418;
                  }

                  int var420 = var30;
                  int var419 = var299;
                  int var301 = var419;
                  int var300 = var419;
                  if (var420 == 0) {
                     int var421 = var300;
                     if (var421 != 0) {
                        break;
                     }

                     List var211 = var44.l;
                     int var422 = var211.size();
                     var301 = var422;
                  }

                  int var468 = var301;
                  float var75 = 9.6F;
                  float var76 = var62 - var75 - 2.0F;
                  float var77 = var50 - var468 * 12.0F / 2.0F + 1.0F;
                  int var426;
                  do {
                     int var424 = var468;
                     int var423 = var78;
                     if (var423 >= var424) {
                        break;
                     }

                     int var214 = var78;
                     List var213 = var44.l;
                     ItemStack var483 = (ItemStack)var213.get(var214);
                     float var500 = var77 + var78 * 12.0F;
                     Object[] var521 = new Object[]{null, null, null, null, var52, 29880294451659L};
                     var521[3] = 0.6F;
                     var521[2] = var76;
                     var521[1] = var500;
                     var521[0] = var483;
                     Object[] var215 = var521;
                     GameRenderUtil.aReturningBoolean(var215);
                     var78++;
                     int var425 = var30;
                     if (var425 != 0) {
                        break label324;
                     }

                     var426 = var30;
                  } while (var426 == 0);

                  int var428 = var30;
                  byte var427 = var38;
                  byte var303 = var427;
                  byte var302 = var427;
                  if (var428 == 0) {
                     byte var429 = var302;
                     if (var429 == 0) {
                        break;
                     }

                     List var218 = var44.m;
                     byte var430 = ((byte)((var218.isEmpty()) ? 1 : 0));
                     var303 = var430;
                  }

                  int var432 = var30;
                  byte var431 = var303;
                  byte var305 = var431;
                  byte var304 = var431;
                  if (var432 == 0) {
                     byte var433 = var304;
                     if (var433 != 0) {
                        break;
                     }

                     BooleanSetting var221 = this.h;
                     Boolean var222 = (Boolean)var221.aReturningObject();
                     byte var434 = ((byte)(((java.lang.Boolean)(var222)).booleanValue() ? 1 : 0));
                     var305 = var434;
                  }

                  int var320;
                  label368: {
                     int var436 = var30;
                     byte var435 = var305;
                     byte var307 = var435;
                     byte var306 = var435;
                     if (var436 == 0) {
                        byte var437 = var306;
                        if (var437 == 0) {
                           var320 = 0;
                           break label368;
                        }

                        PlayerEntity var225 = var43;
                        ItemStack var226 = var225.getMainHandStack();
                        byte var438 = ((byte)((var226.isEmpty()) ? 1 : 0));
                        var307 = var438;
                     }

                     byte var310;
                     label305: {
                        int var440 = var30;
                        byte var439 = var307;
                        byte var309 = var439;
                        byte var308 = var439;
                        if (var440 == 0) {
                           byte var441 = var308;
                           if (var441 == 0) {
                              var310 = 1;
                              break label305;
                           }

                           var309 = 0;
                        }

                        byte var442 = var309;
                        var310 = var442;
                     }

                     byte var318;
                     byte var319;
                     label299: {
                        PlayerEntity var229 = var43;
                        ItemStack var230 = var229.getOffHandStack();
                        byte var501 = ((byte)((var230.isEmpty()) ? 1 : 0));
                        int var445 = var30;
                        byte var444 = var501;
                        byte var443 = var310;
                        byte var315 = var443;
                        byte var316 = var444;
                        byte var311 = var443;
                        byte var312 = var444;
                        if (var445 == 0) {
                           byte var447 = var312;
                           byte var446 = var311;
                           byte var317 = var446;
                           byte var313 = var446;
                           if (var447 == 0) {
                              var319 = 1;
                              var318 = var317;
                              break label299;
                           }

                           byte var448 = var313;
                           byte var314 = var448;
                           var316 = 0;
                           var315 = var314;
                        }

                        byte var450 = var316;
                        byte var449 = var315;
                        var318 = var449;
                        var319 = var450;
                     }

                     int var451 = var318 + var319;
                     var320 = var451;
                  }

                  var78 = var320;
                  int var79 = var78;

                  while (true) {
                     int var453 = var468;
                     int var452 = var79;
                     if (var452 >= var453) {
                        break label324;
                     }

                     float var80 = var77 + var79 * 12.0F;
                     float var81 = 0.0F;
                     int var233 = var79;
                     List var232 = var44.l;
                     ItemStack var82 = (ItemStack)var232.get(var233);
                     List var234 = var44.m;
                     Iterator var484 = var234.iterator();
                     int var455 = var30;
                     Iterator var454 = var484;
                     var252 = var454;
                     Iterator var321 = var454;
                     if (var455 != 0) {
                        continue label327;
                     }

                     Iterator var83 = var321;

                     while (true) {
                        Iterator var235 = var83;
                        boolean var456 = var235.hasNext();
                        if (!var456) {
                           break;
                        }

                        Iterator var236 = var83;
                        ItemLabelData var84 = (ItemLabelData)var236.next();
                        int var457 = var30;
                        if (var457 == 0) {
                           int var459 = var30;
                           ItemStack var458 = var84.a;
                           var253 = var458;
                           ItemStack var322 = var458;
                           if (var459 != 0) {
                              continue label324;
                           }

                           ItemStack var460 = var322;
                           ItemStack var323 = var460;
                           ItemStack var462 = var82;
                           ItemStack var461 = var323;
                           if (var461 != var462) {
                              continue;
                           }

                           var502 = var84.b;
                           var509 = var76 - var32 * 0.5F - var81;
                           Color var519 = UiMetrics.t;
                           Object[] var534 = new Object[]{null, null, 135547275655237L};
                           var534[1] = var49;
                           var534[0] = var519;
                           Object[] var239 = var534;
                           var10009 = new Object[]{null, null, null, null, null, aReturningColor(var239), 75214344094649L};
                           var10009[4] = 0.5F;
                           var10009[3] = var509;
                           var10009[2] = var80;
                           var10009[1] = var502;
                           var10009[0] = var52;
                           Object[] var241 = var10009;
                           MsdfFont var240 = var31;
                           var240.w(var241);
                           var81 += var32 * 0.5F;
                        }

                        int var463 = var30;
                        if (var463 != 0) {
                           break;
                        }
                     }

                     var79++;
                     int var464 = var30;
                     if (var464 != 0) {
                        break label324;
                     }
                  }
               }

               int var465 = var30;
               if (var465 != 0) {
                  return;
               }
               break;
            }
         }
      }
   }

   @EventListener
   public void a(FrustumEvent var1) {
      Object[] var5 = new Object[0];
      FrustumEvent var4 = var1;
      this.r = var4.aReturningVoid(var5);
   }

   @EventListener
   public void a(EntityNameEvent var1) {
      long var10001 = 67370752380427L ^ 113849815043279L;
      int var6 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      EntityNameEvent var7 = var1;
      Entity var10000 = var7.aReturningEntity(var8);
      int var26 = var6;
      Entity var25 = var10000;
      Entity var24 = var25;
      Entity var23 = var25;
      if (var26 == 0) {
         Entity var27 = var23;
         if (var27 == null) {
            return;
         }

         Object[] var11 = new Object[0];
         EntityNameEvent var10 = var1;
         Entity var28 = var10.aReturningEntity(var11);
         var24 = var28;
      }

      MinecraftClient var13 = b;
      ClientPlayerEntity var30 = var13.player;
      Entity var29 = var24;
      if (var29 != var30) {
         PlayerValidationTracker var32 = Prestige.i;
         Object[] var15 = new Object[0];
         EntityNameEvent var14 = var1;
         Object[] var17 = new Object[]{var14.aReturningEntity(var15), 99841884226244L};
         PlayerValidationTracker var16 = var32;
         boolean var31 = var16.aReturningBoolean(var17);
         if (var31) {
            Object[] var20 = new Object[]{Text.empty()};
            EntityNameEvent var19 = var1;
            var19.bReturningVoid(var20);
            Object[] var22 = new Object[0];
            EntityNameEvent var21 = var1;
            var21.aReturningVoid(var22);
         }
      }
   }

   @EventListener
   public void a(EntityLabelEvent var1) {
      long var10001 = 27917987186446L ^ 74399197595082L;
      Object[] var8 = new Object[0];
      EntityLabelEvent var7 = var1;
      Entity var6 = var7.aReturningEntity(var8);
      Entity var14 = var6;
      if (var14 != null) {
         PlayerValidationTracker var10000 = Prestige.i;
         Object[] var11 = new Object[]{var6, 99841884226244L};
         PlayerValidationTracker var10 = var10000;
         boolean var15 = var10.aReturningBoolean(var11);
         if (var15) {
            Object[] var13 = new Object[0];
            EntityLabelEvent var12 = var1;
            var12.aReturningVoid(var13);
         }
      }
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var2 = (Float)var0[1];
      long var3 = (Long)var0[2];
      var3 = 70264684068239L ^ var3;
      long var5 = var3 ^ 41104655423334L;
      Color var8 = var1;
      float var10000 = var8.getAlpha();
      Object[] var10006 = new Object[]{null, null, null, var5};
      var10006[2] = 1.0F;
      var10006[1] = 0.0F;
      var10006[0] = var2;
      Object[] var9 = var10006;
      float var10 = var10000 * ClientUiUtil.aReturningFloat(var9);
      int var7 = Math.round(var10);
      Color var11 = var1;
      int var10002 = var11.getRed();
      Color var12 = var1;
      int var10003 = var12.getGreen();
      Color var13 = var1;
      return new Color(var10002, var10003, var13.getBlue(), var7);
   }

   private List bReturningList(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      long var3 = (Long)var1[1];
      var3 = 70264684068239L ^ var3;
      ArrayList var6 = new ArrayList();
      int var10000 = Event.bReturningInt();
      ItemStack var11 = var2;
      ItemEnchantmentsComponent var7 = EnchantmentHelper.getEnchantments(var11);
      int var5 = var10000;
      int var46 = var5;
      ItemEnchantmentsComponent var45 = var7;
      ItemEnchantmentsComponent var39 = var45;
      ItemEnchantmentsComponent var38 = var45;
      if (var46 == 0) {
         ItemEnchantmentsComponent var12 = var38;
         boolean var47 = var12.isEmpty();
         if (var47) {
            return var6;
         }

         var39 = var7;
      }

      ItemEnchantmentsComponent var15 = var39;
      Set var16 = var15.getEnchantments();
      Iterator var8 = var16.iterator();

      while (true) {
         Iterator var17 = var8;
         boolean var48 = var17.hasNext();
         if (!var48) {
            break;
         }

         Iterator var18 = var8;
         RegistryEntry var9 = (RegistryEntry)var18.next();
         RegistryEntry var19 = var9;
         Optional var62 = var19.getKey();
         int var50 = var5;
         Optional var49 = var62;
         Object var41 = var49;
         Optional var40 = var49;
         if (var50 == 0) {
            Optional var20 = var40;
            boolean var51 = var20.isEmpty();
            if (var51) {
               continue;
            }

            RegistryEntry var23 = var9;
            Optional var63 = var23.getKey();
            Function var25 = invokeBinding3();
            Optional var24 = var63;
            Optional var64 = var24.map(var25);
            short var10001 = 24436;
            long var10002 = 3012716337607441846L ^ var3;
            String var27 = "Unknown";
            Optional var26 = var64;
            var41 = var26.orElse(var27);
         }

         String var10 = (String)var41;
         int var53 = var5;
         String var52 = var10;
         String var43 = var52;
         String var42 = var52;
         String var44;
         if (var53 == 0) {
            String var28 = var42;
            var10000 = var28.length();
            byte var55 = 3;
            int var54 = var10000;
            if (var54 > var55) {
               String var30 = var10;
               String var56 = var30.substring(0, 3);
               var44 = var56;
            } else {
               var44 = var10;
            }
         } else {
            String var57 = var43;
            var44 = var57;
         }

         var10 = var44;
         RegistryEntry var35 = var9;
         ItemEnchantmentsComponent var34 = var7;
         var10 = var10 + " " + var34.getLevel(var35);
         ItemLabelData var37 = new ItemLabelData(var2, var10);
         ArrayList var36 = var6;
         var36.add(var37);
         int var58 = var5;
         if (var58 != 0) {
            break;
         }
      }

      return var6;
   }

   private static String lambda$getEnchantmentData$2(RegistryKey var0) {
      RegistryKey var3 = var0;
      Identifier var4 = var3.getValue();
      return var4.getPath();
   }

   private static int lambda$onTick$1(Entry var0, Entry var1) {
      MinecraftClient var4 = b;
      ClientPlayerEntity var10000 = var4.player;
      Entry var5 = var1;
      Entity var7 = (Entity)var5.getKey();
      ClientPlayerEntity var6 = var10000;
      float var14 = var6.distanceTo(var7);
      MinecraftClient var8 = b;
      ClientPlayerEntity var10001 = var8.player;
      Entry var9 = var0;
      Entity var11 = (Entity)var9.getKey();
      ClientPlayerEntity var10 = var10001;
      float var13 = var10.distanceTo(var11);
      float var12 = var14;
      return Float.compare(var12, var13);
   }

   private boolean lambda$new$0(Boolean var1) {
      BooleanSetting var4 = this.i;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(5181411504651L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[2];
      String var15 = "\u001dpfB\u000f$?Ì\u009b\u001fT¤JP}\u0094\u0010¬ X`ä\u001fCÛ\u0000\u0018fZíì\u0080U";
      int var17 = "\u001dpfB\u000f$?Ì\u009b\u001fT¤JP}\u0094\u0010¬ X`ä\u001fCÛ\u0000\u0018fZíì\u0080U".length();
      char var14 = 16;
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var28 = b(var19).intern();
         int var10001 = -1;
         var18[var16++] = var28;
         if ((var13 += var14) >= var17) {
            w = var18;
            x = new String[2];
            Cipher var1;
            var10000 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var2 = 1; var2 < 8; var2++) {
               var10003[var2] = (byte)(5181411504651L << var2 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var0 = new long[16];
            String var5 = "4\u0086\u0095+\u0007w?\u008bU-iHÄs?Ä\u009a\b¦\u0013\u008f~\u00ad\rð\u000b\u0099/\u001eN\u0092\u0016\u009d3\u0018z+\u0094ñf?Úøà\u0000\u000f\u009c³\u001a»'Î<?\u001f»\u0093Ò4sâ\u0015¡\f3ä\u00922R\u001f!\u0004\u0088^\u0012Å^3J´·\u001dèÃÜµ\u0087\u0019\u0089å\u0099\u0013km\u0096É\u0094\u001c®s,2ûwrÏ¸{A/?Õ";
            int var6 = "4\u0086\u0095+\u0007w?\u008bU-iHÄs?Ä\u009a\b¦\u0013\u008f~\u00ad\rð\u000b\u0099/\u001eN\u0092\u0016\u009d3\u0018z+\u0094ñf?Úøà\u0000\u000f\u009c³\u001a»'Î<?\u001f»\u0093Ò4sâ\u0015¡\f3ä\u00922R\u001f!\u0004\u0088^\u0012Å^3J´·\u001dèÃÜµ\u0087\u0019\u0089å\u0099\u0013km\u0096É\u0094\u001c®s,2ûwrÏ¸{A/?Õ"
               .length();
            label33:
            while (true) {
               var10001 = var3;
               var3 += 8;
               byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
               long[] var23 = var0;
               var10001 = var4++;
               long var31 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               // while (true) {
                  long var8 = var31;
                  byte[] var10 = var1.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var36 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var34) {
                     case 0:
                        var23[var10001] = var36;
                        if (var3 >= var6) {
                           l = new Color((int)var0[14], (int)var0[7], (int)var0[6]);
                           m = new Color((int)var0[1], (int)var0[4], (int)var0[5]);
                           n = new Color((int)var0[12], (int)var0[15], (int)var0[15], (int)var0[2]);
                           o = new Color((int)var0[8], (int)var0[13], (int)var0[10], (int)var0[0]);
                           p = new Color((int)var0[8], (int)var0[5], (int)var0[5]);
                           q = new Color((int)var0[9], (int)var0[3], (int)var0[11]);
                           break;
                        }
                        break;
                     default:
                        var23[var10001] = var36;
                        if (var3 < var6) {
                           continue label33;
                        }

                        var5 = "E»\n\u0015¡<\u0017<lÚ\u009f#§Õ1\u0094";
                        var6 = "E»\n\u0015¡<\u0017<lÚ\u009f#§Õ1\u0094".length();
                        var3 = 0;
                  }

                  int var27 = var3;
                  var3 += 8;
                  var7 = var5.substring(var27, var3).getBytes("ISO-8859-1");
                  var23 = var0;
                  var10001 = var4++;
                  var31 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var34 = 0;
               }
            }
         }

         var14 = var15.charAt(var13);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28914;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e6", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e6",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = A[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = z[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 62;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 3;
            yield var18;
         }
         case 4 -> {
            byte var19 = 39;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 7;
            yield var22;
         }
         case 8 -> {
            byte var23 = 6;
            yield var23;
         }
         case 9 -> {
            byte var24 = 43;
            yield var24;
         }
         case 10 -> {
            byte var25 = 20;
            yield var25;
         }
         case 11 -> {
            byte var26 = 27;
            yield var26;
         }
         case 12 -> {
            byte var27 = 4;
            yield var27;
         }
         case 13 -> {
            byte var28 = 25;
            yield var28;
         }
         case 14 -> {
            byte var29 = 47;
            yield var29;
         }
         case 15 -> {
            byte var30 = 2;
            yield var30;
         }
         case 16 -> {
            byte var31 = 32;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 51;
            yield var35;
         }
         case 21 -> {
            byte var36 = 13;
            yield var36;
         }
         case 22 -> {
            byte var37 = 42;
            yield var37;
         }
         case 23 -> {
            byte var38 = 58;
            yield var38;
         }
         case 24 -> {
            byte var39 = 36;
            yield var39;
         }
         case 25 -> {
            byte var40 = 45;
            yield var40;
         }
         case 26 -> {
            byte var41 = 38;
            yield var41;
         }
         case 27 -> {
            byte var42 = 1;
            yield var42;
         }
         case 28 -> {
            byte var43 = 49;
            yield var43;
         }
         case 29 -> {
            byte var44 = 19;
            yield var44;
         }
         case 30 -> {
            byte var45 = 10;
            yield var45;
         }
         case 31 -> {
            byte var46 = 30;
            yield var46;
         }
         case 32 -> {
            byte var47 = 60;
            yield var47;
         }
         case 33 -> {
            byte var48 = 28;
            yield var48;
         }
         case 34 -> {
            byte var49 = 55;
            yield var49;
         }
         case 35 -> {
            byte var50 = 24;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 56;
            yield var53;
         }
         case 39 -> {
            byte var54 = 37;
            yield var54;
         }
         case 40 -> {
            byte var55 = 33;
            yield var55;
         }
         case 41 -> {
            byte var56 = 35;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 59;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 18;
            yield var60;
         }
         case 46 -> {
            byte var61 = 53;
            yield var61;
         }
         case 47 -> {
            byte var62 = 23;
            yield var62;
         }
         case 48 -> {
            byte var63 = 9;
            yield var63;
         }
         case 49 -> {
            byte var64 = 52;
            yield var64;
         }
         case 50 -> {
            byte var65 = 12;
            yield var65;
         }
         case 51 -> {
            byte var66 = 17;
            yield var66;
         }
         case 52 -> {
            byte var67 = 26;
            yield var67;
         }
         case 53 -> {
            byte var68 = 5;
            yield var68;
         }
         case 54 -> {
            byte var69 = 22;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 50;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 41;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 34;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 61;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            A[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      z[0] = "\u0002\u0007I)p\t\u0014\u0007Lsc\u001e\u0003LOuo\n\u0012\u000bXb$\u001a\n\u000bZi~W6\u0010Zt~\u0010\u0001\u0007";
      z[1] = "Ui(\f<kCi-V/|T\".P#hEe9GhzW";
      z[2] = "\u0015']\u000eXG`\u0007V\u0001I\b\u0001\t]\nMRu";
      z[3] = boolean.class;
      A[3] = "java/lang/Boolean";
      z[4] = "p0xGSof0}\u001d@xq{~\u001bLl`<i\f\u0007}z";
      z[5] = " W\u0001ef%Uw\njwj4y\u0001as0@";
      z[6] = "\u0015v\u0015\r~n\u0015v\u0002Qra\u000f=\u0002Ort\bLP\u0011*0";
      z[7] = "\u0019q?\"$_\u000fq:x7H\u0018:9~;\\\t}.ipJK";
      z[8] = "nG^'8!eHOh[,pE@\u0003n.aV\\/y#";
      z[9] = "IlI\b\fz_lLR\u001fmH'OT\u0013yY`XCXkh";
      z[10] = "B~\t\nsm7^\u0002\u0005b\"VP\t\u000efx\"";
      z[11] = void.class;
      A[11] = "java/lang/Void";
      z[12] = "%L=L\u007fi3L8\u0016l~$\u0007;\u0010`j5@,\u0007+{\u0006";
      z[13] = "J\u0003*Ar\u0002?#!NcM^-*Eg\u0017*";
      z[14] = "\u000eQW\u0004z\\\u000eQ@XvS\u0014\u001a@FvF\u0013k\u0017\u001c'\u0001";
      z[15] = "~\u00195z0\u0015`\u0011/5S\u0001d\\\u0006uj\u0012m";
      z[16] = "1vHwp\b:yY8\u0011\u00061r]b";
      z[17] = "%EW\u001eTg%E@BXh?\u000e@\\X}8\u007f\u0014\u0004\u000f";
      z[18] = float.class;
      A[18] = "java/lang/Float";
      z[19] = "2[gsWB2[p/[M(\u0010p1[X/a l\n";
      z[20] = "BR_Q\u0012\\I]N\u001ez\\GR]";
      z[21] = int.class;
      A[21] = "java/lang/Integer";
      z[22] = "1\u000f##fl'\u000f&yu{0D%\u007fyo!\u00032h2}l";
      z[23] = "u;|\u001f]}\u0000\u001bw\u0010L2a\u0015|\u001bHh\u0015";
      z[24] = "\u001c6N\u007f,^i\u0016Ep=\u0011\b\u0018N{9K|";
      z[25] = "T\u0014IjT_T\u0014^6XPN_^(XEI.\u000fq\u000f\u0007";
      z[26] = "0B$-Bm0B3qNb*\t3oNw-xe1\u001a4";
      z[27] = "T\u0011$\u001e !J\u0019>QA$J\u0019=\u0011o8";
      z[28] = "\u0000q@/\u000et\u0000qWs\u0002{\u001a:Wm\u0002n\u001dK\r2S)";
      z[29] = "\u0001j\u001c\u0013a$\u001fb\u0006\\\u001c4\u001f";
      z[30] = "\u000b;\u0002{1\u0007\u000b;\u0015'=\b\u0011p\u00159=\u001d\u0016\u0001@md^";
      z[31] = "\u001cQ\u0002=51\u001cQ\u0015a9>\u0006\u001a\u0015\u007f9+\u0001kG+ah";
      z[32] = "X:+LW\u0012X:<\u0010[\u001dBq<\u000e[\bE\u0000nU\u0003B";
      z[33] = "T]zk\b:JU`$o;[Nm~I=";
      z[34] = "5\u0017\"}'\u001f+\u001f82E\u0003,\u0002";
      z[35] = "-7\u0018vX9&8\t9%!5?\u0000p";
      z[36] = "0|Wp8?.tM?p?4~Uxy$t[T\u007fu>3rO";
      z[37] = "`HT-S\u0010vHQw@\u0007a\u0003RqL\u0013pDEf\u0007\u0004L";
      z[38] = " vgm\u0017GUVlb\u0006\b4Xgi\u0002R@";
      z[39] = "XBx$\u001b+XBox\u0017$B\tof\u00171Ex=<Cu";
      z[40] = "\u001bqa\u0001oS\rqd[|D\u001a:g]pP\u000b}pJ;@\u0005";
      z[41] = " V7\u001d\u0012X6V2G\u0001O!\u001d1A\r[0Z&VFK<";
      z[42] = "bq\u000b~d[\u0017Q\u0000qu\u0014v_\u000bzqN\u0002";
      z[43] = "Z1HrD\u0001Q>Y=(\u0002_<[r\u0004";
      z[44] = "\u000eJoc\u000e\u0010\u000eJx?\u0002\u001f\u0014\u0001x!\u0002\n\u0013p)yP";
      z[45] = double.class;
      A[45] = "java/lang/Double";
      z[46] = "\u007ft^]g@it[\u0007tW~?X\u0001xCoxO\u00163T]";
      z[47] = "qb\u0000\u0006\u000eizm\u0011Iikof\u0011\u0002R";
      z[48] = "Q\u0007\u0017r\"NS\u0019^\u0011)UL\u001c\bh.";
      z[49] = "}H\f\u0004v>}H\u001bXz1g\u0003\u001bFz$`rJ\u0019#";
      z[50] = "5D\u0007\u00166h@d\f\u0019''!j\u0007\u0012#}U";
      z[51] = "Zom\u0004@\u0005DgwK#\u0011@";
      z[52] = "!b\u00195l\u00197b\u001co\u007f\u000e )\u001fis\u001a1n\b~8\r2";
      z[53] = "\u00182U`R\u0013m\u0012^oC\\\f\u001cUdG\u0006x";
      z[54] = "gF\u0005|$klI\u00143GfyO";
      z[55] = "^zH\u007f\u0005\u0003+ZCp\u0014LJTH{\u0010\u0016>";
      z[56] = "`\b2\u001aHv\u0015(9\u0015Y9t&2\u001e]c\u0000";
      z[57] = "\u0002\u00142\u007f\u0015\u0011\u0014\u00147%\u0006\u0006\u0003_4#\n\u0012\u0012\u0018#4A\u0000$";
      z[58] = "BUJV1y7uAY 6V{JR$l\"";
      z[59] = "U~p2T~ ^{=E1APp6Ak5";
      z[60] = "a'l\u00151~w'iO\"i`ljI.}q+}^emn";
      z[61] = "r$%'\u0005^\u0007\u0004.(\u0014\u0011f\n%#\u0010K\u0012";
      z[62] = "\u007fi\u0004`Q/ii\u0001:B8~\"\u0002<N,oe\u0015+\u0005;m";
      z[63] = "\u0015g\u0015.Zo`G\u001e!K \u0001I\u0015*Ozu";
      z[64] = "Zi\u0012\u0005iV/I\u0019\nx\u0019NG\u0012\u0001|C:";
      z[65] = "(qtBS\u0014>qq\u0018@\u0003):r\u001eL\u00178}e\t\u0007\u0000*";
      z[66] = "\rw}F/*xWvI>e\u0019Y}B:?m";
      z[67] = "`au?(\u001fvape;\ba*sc7\u001cpmdt|\f=";
      z[68] = ",p'(X.YP,'Ia8^',M;L";
      z[69] = "\u0001\u001e\u0002h\u0018Wt>\tg\t\u0018\u00150\u0002l\rBa";
      z[70] = "T9Y\u0014[!!\u0019R\u001bJn@\u0017Y\u0010N44";
      z[71] = "J(\"\">(W=z\u0000\u007f%O;";
      z[72] = "\u0007#/\u007fg\u0002\u0007#8#k\r\u001dh8=k\u0018\u001a\u0019ih<[";
      z[73] = "L\u001b1p\u0017 L\u001b&,\u001b/VP&2\u001b:Q!pmHx";
      z[74] = "mm#\u0015xrse9Z\u0015hk`0\u0017\"nhb";
      z[75] = ",|~CS#:|{\u0019@4-7x\u001fL <po\b\u00075\u0007";
      z[76] = "lEu\bCsrMoG.ikTb\u001b\friV";
      z[77] = "_\u0006|D!F_\u0006k\u0018-IEMk\u0006-\\B<1X{\u001b";
      z[78] = "?~\r}4\u001a)~\b''\r>5\u000b!+\u0019/r\u001c6`\f\u0001";
      z[79] = "?G2@|d)G7\u001aos>\f4\u001ccg/K#\u000b(w\u001c";
      z[80] = "uS\b\u0018\u0013]\u0000s\u0003\u0017\u0002\u0012a}\b\u001c\u0006H\u0015";
      z[81] = "UdI\u001bJiCdLAY~T/OGUjEhXP\u001e|\u0002";
      z[82] = "\u0016\u0001H\u0000-\nc!C\u000f<E\u0002/H\u00048\u001fv";
      z[83] = "\u0011L.\u0007d\u0011\u0011L9[h\u001e\u000b\u00079Eh\u000b\fvl\u001a1";
      z[84] = "U8mUi= \u0018fZxrA\u0016mQ|(5";
      z[85] = "\u0016`\u0007t\u000bK\u0000`\u0002.\u0018\\\u0017+\u0001(\u0014H\u0006l\u0016?__;";
      z[86] = "\fI\u0015T|=yi\u001e[mr\u0018g\u0015Pi(l";
      z[87] = "PPiW~p%pbXo?D~iSke0";
      z[88] = "\u0011/\u001b\n8l\u0011/\fV4c\u000bd\fH4v\f\u0015^\u0017e1";
      z[89] = "\u001d\u000bqs\u000e\u0013E[\u007f|5J\u0005/jzX-\u0015^wpVM@\u0001jz5GC\u001b\u007fbU\u0012\u001c\u0006u\u0001";
      z[90] = ";\u001f\u001e'\u0018\u0019.\u0006\u001fE\tef_Z%\u000e\u001a2_\u000b*";
      z[91] = "F=C\u0017wuT.XM\u0018.I?D\u0016t\u001c\u0019|\u0019J&KG2E\t|&Ir@K\u0018&A.\u001b\u0018czY3Hq";
      z[92] = "q -Z\u0001\u0014z6<\u00019\u0010f7.XU\"5sq\u000e9\u0010k5w\u0003I\u0010w.7?";
      z[93] = "{qlMOe()fW1`\u007fmI]@\u000fx-sARo-rnK1";
      z[94] = "j\u007f\u001el4N)|\u0007zIM\u0012!\u0007k9\u001cjzY)6\u001f\u0012`\u0007h3Yx#\u0004q%$";
      z[95] = "V&'HMNC?&*V2H \"\u0013WTK7!H";
      z[96] = "\"&\u0018 \u001di<$\u0001p`x#%\u0001\u001eYct3B%^s;aB\u001eP;~-\u001a~\u0001d% }";
      z[97] = "H\u001d]a,\u0012\t\u0000@&]S3AV`-\u0014K\u001a\b\"\"\u00173H\t'/KS\u0019V|\",";
      z[98] = "j\u000el\u0016_wo\u0005.M]\u000b:o'\u0010@{k\u0017|N\u0002tho'\u0014\u0000e:U'H\u00023bo";
      z[99] = "@21\u001cb\u0016\u001f5#D!z\u001c2!F4\u0016.fg\u0016h@y84\u001e>B\u00012,@iz";
      z[100] = "{\t\u0012iqI`\u0015Cm\u0011\u001dv\u000e\"rk\u0013}\u001dyixJvJ\u0001c`\u0014!r";
      z[101] = "rp\u0014vvv`$I6\u001cyv1JmpK!v\u0012;'\u001cj#Ot%fp$A:\u001c&x/\u0017i!m~ \u0016\n";
      z[102] = "$\ryy%Z\"\u0005sf6!r\ffC!M\u001d\f\u007ftsHfPgi !";
      z[103] = "KU\u0011Cr=\u0012KSS!\u0000\u0017\\\u0012A,l%\b^\u001dv>rW\u0017Du}\u0018I\u0015]%\u0000";
      z[104] = "u\u001d1kO\u0001>\u001ce5L9%!5<\nItYnbHFw!g+\u0010P<^mgO\u0007L";
      z[105] = "-}Of#t%yL\"\u0013.$eP}\u007f\u001ct&\r!)K,yN#/;,eUc\u0013)7~Vu-;$e\f\u001a";
      z[106] = "yI%~sWs\u0010bs\u0018\u0007f\u0019ggd\u0001`t{>d\f`\u0017a?y\u001c\u001a";
      z[107] = "2?z\u000b^v;35\u001cfg\\g,\u0006\u00166$<rD\u00195\\b7J\u001eie;vJ\u000f\u000e";
      z[108] = "=?UF\u0018<ccV\u0010@_y\u0000\u0000H\u0003/<x[\u0016A ?\u0000\t\u0017D-c`XH\u001f \u0004";
      z[109] = "\u0013;2\u000f\\l\u0018-#Tdh\u0004,1\r\bZWhoQdf\u001978\u001a\u001blUhoj";
      z[110] = "\u0015gW+DH\u001eqFp|L\u0002pT)\u0010~R<\u000e\u007f|X\u0001iJw\u0006B\u0006g\u0004N";
      z[111] = "0|T\\\u0013\u000evl\u0014\\\u00130d\u0015\u0014W\u0014@1mO\tVO2\u0015\u001d\bSBnuLW\bO\t";
      z[112] = "lLC\bJ=-Q^O;h\u0017\u0010H\tK;oK\u0016KD8\u0017B_\u0013RshH\u0013L\u0005\u0003";
      z[113] = "\u00033fmbe\u0005;lrq\u001eU2yBqsW9\u0005`ns\u00056~<vnV_";
      z[114] = "HN\u0010}X;Z]\u000b'7`GL\u0017|[R\u0017\u000fJ'\f\u0005\u0010S\u0015&T8[U\u001a'7";
      z[115] = "\t k@=JV*sO8uQ<|Gi\tW:\u0011[0\tZ:rA1\u0014J@";
      z[116] = "\u000fj}O}lMje@\u0001~\u0015mpLhr,cp\\l\u0014Hiv\u001cb)\u0003oy\u001d\u0001";
      z[117] = "_NJ)\u0006\u007f\u0007N^z7oaG^)\bm\u001a\u001bF4[\u0004";
      z[118] = "05h\u000e/Zo?p\u0001*eg4\u007f\u0017~25d(I.e05h\u000e/Zo?p\u0001*";
      z[119] = "I$\u0005\bt\u0007R8T\f\u0014YD#\u000e\bxk\u0015dRP/<H:PRt\rG0\u001f\u0002\u0014";
      z[120] = "1\\R\u0013H/p\u0000A\u0007*z.\nT\u0014}-tZ\bxThtXY\u001c\u0015z/\u001a";
      z[121] = "F=\f\u00115rC1]^VaK1U\r\u00016\u0015f\ra<sA:\fP:qC9";
      z[122] = "R\u0004%<MjH\u00058,7i]O\u001f;Gu4\u000e:4\nj\tE<;\u000b\t";
      z[123] = "^\u00072\u0005B@@\u0005+U?KC32CC[8D4Y\u0002I\u0005\u000f2V\u0003*";
      z[124] = "S\u007f$\u0014}A\fl)Z\u0013\u0016n(rWcD\u0016s,\u0015lGnwlO-\u0001\u0004inV}|";
      z[125] = "QBP\u0006\u0017m\u0003A\u0019^\u000bW\r\u0012X;\u0006'\u000f\u0012XD\fkPE(P\u001d0\u0001\u000bWZQoV{CK\n>\u0018\u0004I\u0007Uih";
      z[126] = "8n\u0003\u0013\u0012{;y\u0000HxtB-\u0019W\b%:vG\u0015\u0007&Bo\u001bF\u0004l|.\u0006[C\u001d";
      z[127] = "\u00179\rG^<Ps\u001fJ\b[G\u0001YON+\u0016y\u0002\u0011\f$\u0015\u0001\u001e\u0013Q0L:_OB$.";
      z[128] = "n\u0001~\fy()Kl\u0001/O=9*\u0004i?oAqZ+0l9mXv$5\u0002,\u0004e0W";
      z[129] = "}\u001c\u0013\n7Dc\u001e\nZJGw\tv^vWj\u0006\u0016\u000b)J`eLW(\u0013xX\u0007Q'\u0012\u001b";
      z[130] = "[\u0004QW3=E\u0006H\u0007N,\\\u000fYi#2PB]\u0012\u007f*M\u00114";
      z[131] = "|Z\u001a|U\u0010+D\r>6\u0003F\u0018\u0007~FR>CY<IQF\u001d\u001c2N\r\u007fD]2_j";
      z[132] = "oro=\u000ffy~<:d3f\u007f9~:4fe=\u0002\u000f-eq }\u0005a:&P";
      z[133] = "$u\u000ew1\u001fw-\u0004mO\u001a i6c+\b \u0015\u000266\u0004.uWi+\u000eM";
      z[134] = "m^!2\u0012/pD>g{${X4,{\u007f'\u000f/1\u001b.xT\"V";
      z[135] = "0\u000ffWc4sBbG|\rb>>Z|}1Fe\u0004>r2>7\u0005;\u007fn^fZ`r\t";
      z[136] = "\u0015;(\u0003\u007frTg;\u0017\u001d,\u0006|*\u000fq\u001eR8qQ\u001d7\u0017;u\u0001yv\u0005`7hc5P?#\f\"'\u000b}J\u0016arTi.Ws)\u0016\u00004S\u007f\"\t;u\u000fl6k";
      z[137] = "a\u00072[/\u0017>\u0014?\u0015AC\\Pd\u00181\u0012$\u000b:Z>\u0011\\Po\u0006!C'Vg\f>P\\";
      z[138] = ">6Ep&e#,Z%O}1!9~s|=>Y+,a7]S(6t/=\u0006w+~L7\u0005m>f,bZp4\u0005";
      z[139] = "_.\u0015CT^\u000b.DL2Hf+N^B\u0019\u001ep\u0010\u001cM\u001af(JA\u000fB[cLN\u000e!";
      z[140] = "\b\u0012\u0015\u0012kz\u001a\u0001\u000eH\u0004!\u0007\u0010\u0012\u0013h\u0013WSOO8D\tQJ\u0004ou\u0003\b\r\t\u0004";
      z[141] = "@b\u00102\u001cMFj\u001a-\u000f6\u0016c\u000f\u001b\u0011N\u0019gs?\u0010[Fg\bc\bF\u0015\u000e";
      z[142] = "eyr!Bzp`sC]\u00068j03\nt9?fx@";
      z[143] = "\u0003%!\u0010\u0012JU#&\u0002v\u001b3e!\u0000\u0006JK>\u007fB\tI35{C\n\u0018Y'/\u001eJr";
      z[144] = "\u0005.aeE\f\u00052z%y\u0019\r2\u007f;\u0015+_\u007f!dyF\u0003,\"?D\r\u0005##\\";
      z[145] = "~\u0010G+c2`\u0012^{\u001e9d\u0004X|b?biD%b2b\n^$\u007f\"\u0018";
      z[146] = "\u001c=\f_\u001fl\u00151CH'~reZRW,\n>\u0004\u0010X/rl\u0005\u0015Us\u0012=ZNX\u0014";
      z[147] = "@b\u001d]O\u0010M;XX=\nV%=QY\u0016]Y\u000e]PTY\"REM\u00070";
      z[148] = "!]SL|T+E\r\u001bDH+R\u0004]$,+Q\u0006\u001e-WwI\u001bMD";
      z[149] = "\u001ab\u000f\u0006\"`\u0000c\u0012\u0016Xe\u0011\"\u000fl2?\u0005#\u0010\fg`\u0018)s";
      z[150] = "o:\rT`|y6^S\u000b,e5J\u0002q*\u0002;B\fb7}1\u000eS5Gi U\u0002{8cl\nU\u000b*g=\r\u0002pv\u007f ^k";
      z[151] = "]J\u0003@9\u001dV\\\u0012\u001b\u0001\u0019J]\u0000Bm+\u0019\u0019[\u001f\u0001\u0017WF\tU~\u001d\u001b\u0019^%";
      z[152] = "\u0017)IB~0O)]\u0011O\")t_R?sQ/\u0001\u00100p)}\u0000\u0015=,I,_N0K";
      z[153] = "\u0000'k90\tA:v~A^{{`81\u000f\u0003 >z>\f{)w\"(G\u0004#;}\u007f7";
      z[154] = "c\u0001\u0005t5\u0016i\u0019[#\r\u000f\u007f%Xaq\u001f\u0004R^{0\r9\u0019Xt1n";
      z[155] = "#\u0014pO=$=\u0016i\u001f@%!\u0000|\u000b@~}Wg\u0016 /\"\fjq";
      z[156] = "\u000fC7__\u0011N\u001f$K=D\u0010\u00151Xj\u0013JEo4CVJG<P\u0002D\u0011\u0005";
      z[157] = "p\u001br\u0010]\u00121Ga\u0004?GoMt\u0017h\u00105\u001d){AU5\u001fy\u001f\u0000Gn]";
      z[158] = "DJ\u007fto\u0001\u0016I6,s;\u0007\u0014z/y;\u0016\u0003` eD\u001cO?w\u0015V\u0018\u001e8 n\n\u0000\u0003kI";
      z[159] = ":\u001al1\u000f];O:zE/juo&J_;\r4x\bP8ul\"U\u0012`H'$Z\u0013\u0003";
      z[160] = "\u0006Tg\u001e=^[OpO8;V5'\u00159K\u0007M|K{D\u00045s\u0017)\u0004VN/\u000f4W?";
      z[161] = "\u000f*Po2\u000fDt\n9gv\\\u0014T9%\u0006\u000el\u000fgg\t\r\u0014\u0006.?\u001fFk\fb`H6";
      z[162] = "px\u0003w#6nz\u001a'^3{}f$;1)h\u001dx#,z\u0001\fu'-uaY*:'\u0016";
      z[163] = "*%p=%\\/)!rFO'))!\u0011\u0018xtrM\u007fE9&tp&[{6'";
      z[164] = "J\u0016<<g_\u0012\u0016(oVNt\u001f(<iM\u000fC0!:$";
      z[165] = "{\u001c@=7o#LN2\f0b8Z7p \u0019O\\-12$\u0004Z\"0Q";
      z[166] = "{\tAss\u0012e\u000bX#\u000e\u0011q\u001cm)jx$\u001eK0hDa\u0019@!ux'\u0013FpmEl\u0015Iq\u000e";
      z[167] = "\nN\u0018\u0014\u001a-\u0001X\tO\")\u001dY\u001b\u0016N\u001bN\u001dEN\"'\u0000B\u0012\u0001]-L\u001dEq";
      z[168] = "Mzn\\i$Fl\u007f\u0007Q Zmm^=\u0012\u000e.3\tkE\\ajP!:V-5\u0007Q";
      z[169] = "\u001a*%7%D\u0014j uAL\u0014'$(-~Ec~ty)\u001b2;=z\u0017Cb52A";
      z[170] = "\u001d-7RCM\b460I1@06\\JT\u001d+!\rO";
      z[171] = "\u0001\u0001\u0007E{\u000b\u0007\u0003\u0005FF_\u0006\u0001\fD*mVBW\u0012F\u0006\u0017L\u0014D\u007f_VL\u0005#-J\f\u0014\u001c\\'\u0006SCl";
      z[172] = "\u00142:&`\u007f\u0002;j-\u001dsk3=:ly\u000bfb'f\u001a";
      z[173] = "\t?~/g(\u00064vy\t<\u0012,x{\t,\t\"ufv&E}\"\u0016b7\u001e,lih{A{\u001c}y \u00105cw5\u007fGEllk~\u0017*cgc(y";
      z[174] = "dr\u0019%_Dyh\u0006p6K{ee+\n]gz\u0005~U@m\u0019\u000f}OUuyZ\"R_\u0016";
      z[175] = "djx&oiqsyDs\u00159wr%}i<|0~\u007f";
      z[176] = "^\u0004\u001e8 pU\u0012\u000fc\u0018tI\u0013\u001d:tF\u001aWAb\u0018tD\u0011DahtX\n\u0004]";
      z[177] = "M\nf\u0010\u0011\bF\u001cwK)\fZ\u001de\u0012E>\n]:J)\tL\nb\u0015\u0012\u0012P[fu";
      z[178] = "Gk0\u0017\u000eQZq/Bg\\S|6\u0002<\\I\u0000/N_A^1%\u0017\u0018L5";
      z[179] = "X\u0010\u0001-Q5\u001fZ\u0013 \u0007R\b(U%A\"YP\u000e{\u0003-Z(V!^o\u0002\u0015\u001d'Qna";
      z[180] = "uAf\u0006i~u\u001ddP1D&\"b\u000f}4tZ9Q?;w\"b\u000e?\"3@j\u00188&}\"";
      z[181] = "\u00105!`O}\u0016=+\u007f\\\u0006F4>JB{DY/eK9@\"s}Vj)";
      z[182] = ":ue\u0007v/efhI\u0018{\u0007%nRgy~|0]t\u00129!?Fsk`\u007f0U\u0018";
      z[183] = "eHzv8\u0011$Ug1IQ\u001e\u0014qw9\u0017fO/56\u0014\u001e\u001d.0;H~Lqk6/";
      z[184] = "E|n:\bP\u001d,`53\u000bNm\u0011/A\nVq{!JTJ\u0015s!L\u001c\u001c++qB\u0013'";
      z[185] = "l>=-e\u001bf&cz]\u0018v=~<'\u0002m8\u0005-8\u000e4>~q \u0013gWh%0\\b,4=-\u000f\u000b0lx0[s:t&gc";
      z[186] = "\u001d\u0005\u0002\u0002S\u0011\u0015QU\u000bQvA\u0006D\u0002\f\u001asQ\t[TI$RU\u000eQGH\rR\u001c\t\u0004$";
      z[187] = "\teIDM\u000e\u0002sX\u001fu\n\u001erJF\u00198M7\u0013\u0011uV\u000bnQ@\u001f\u000b\u001a\u007f\u0014Au\n\u0013p\u0013\u001d\u0005\n\u000fkS!";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = z[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(A[var4]);
            z[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = z[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            z[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  z[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1130556680078608L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = z[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  z[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1130556680078608L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        z[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1130556680078608L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 122;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 235;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 197;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 165;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 78;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 114;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 122;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 235;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 197;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e6",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(NameTags var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e6;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e6", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((NameTags)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Comparator invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "compare",
                  SourceSupport.methodType("()Ljava/util/Comparator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/e6", "lambda$onTick$1", "(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I"
                  ),
                  SourceSupport.methodType("(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Comparator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/e6",
                     "lambda$getEnchantmentData$2",
                     "(Lnet/minecraft/registry/RegistryKey;)Ljava/lang/String;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/registry/RegistryKey;)Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
