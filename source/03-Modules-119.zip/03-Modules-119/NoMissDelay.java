package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.AttackCooldownEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;

public class NoMissDelay extends Module {
   private IntSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private boolean i;
   private static final long k = 71278715777015L;
   private static final long l;
   private static final Object[] m = new Object[76];
   private static final String[] n = new String[76];
   private static volatile MethodHandle bindingCache1;

   public NoMissDelay() {
      super();
      long var10001 = 23746568385687L ^ 12018383275584L;

      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      FloatSetting var10000 = this.c;
      Object[] var6 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var5 = var10000;
      var5.aReturningFloatSetting(var6);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(AttackCooldownEvent var1) {
      long var10001 = 49103385783448L ^ 102628799387721L;
      var10001 = 49103385783448L ^ 139969050297672L;
      var10001 = 49103385783448L ^ 67201092547364L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var12 = b;
      HitResult var11 = var12.crosshairTarget;
      int var10 = var10000;
      HitResult var60 = var11;
      if (var60 != null) {
         label60: {
            MinecraftClient var14 = b;
            ClientPlayerEntity var15 = var14.player;
            Object[] var16 = new Object[]{var15.getMainHandStack(), 19476550655932L};
            boolean var92 = InventoryUtil.aReturningBoolean(var16);
            int var62 = var10;
            boolean var61 = var92;
            boolean var42 = var61;
            boolean var41 = var61;
            if (var62 == 0) {
               boolean var63 = var41;
               if (var63) {
                  break label60;
               }

               MinecraftClient var18 = b;
               ClientPlayerEntity var19 = var18.player;
               ItemStack var20 = var19.getMainHandStack();
               boolean var64 = var20.getItem() instanceof AxeItem;
               var42 = var64;
            }

            boolean var65 = var42;
            if (!var65) {
               return;
            }
         }

         NoMissDelay var50;
         label66: {
            HitResult var22 = var11;
            Type var93 = var22.getType();
            int var67 = var10;
            Type var66 = var93;
            Object var47 = var66;
            Type var43 = var66;
            if (var67 == 0) {
               Type var68 = var43;
               Type var44 = var68;
               Type var70 = Type.MISS;
               Type var69 = var44;
               if (var69 != var70) {
                  return;
               }

               int var72 = var10;
               NoMissDelay var71 = this;
               var50 = var71;
               NoMissDelay var45 = var71;
               if (var72 != 0) {
                  break label66;
               }

               NoMissDelay var73 = var45;
               NoMissDelay var46 = var73;
               BooleanSetting var26 = var46.d;
               Object var74 = var26.aReturningObject();
               var47 = var74;
            }

            Boolean var28 = (Boolean)var47;
            boolean var75 = var28;
            if (var75) {
               int var77 = var10;
               NoMissDelay var76 = this;
               var50 = var76;
               NoMissDelay var48 = var76;
               if (var77 != 0) {
                  break label66;
               }

               NoMissDelay var78 = var48;
               NoMissDelay var49 = var78;
               Object[] var31 = new Object[]{92246508054992L};
               NoMissDelay var30 = var49;
               boolean var79 = var30.dReturningBoolean(var31);
               if (!var79) {
                  this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
                  return;
               }
            }

            var50 = this;
         }

         int var10002 = (int)l;
         Object[] var10005 = new Object[]{null, null, 125343872349393L};
         var10005[1] = var10002;
         var10005[0] = 1;
         Object[] var34 = var10005;
         int var96 = RandomUtil.aReturningInt(var34);
         int var82 = var10;
         int var81 = var96;
         NoMissDelay var80 = var50;
         NoMissDelay var55 = var80;
         int var56 = var81;
         NoMissDelay var51 = var80;
         int var52 = var81;
         NoMissDelay var58;
         int var59;
         if (var82 == 0) {
            IntSetting var35 = this.a;
            Integer var36 = (Integer)var35.aReturningObject();
            int var85 = var36;
            int var84 = var52;
            NoMissDelay var83 = var51;
            NoMissDelay var57 = var83;
            NoMissDelay var53 = var83;
            if (var84 <= var85) {
               NoMissDelay var86 = var53;
               NoMissDelay var54 = var86;
               byte var88 = 1;
               NoMissDelay var87 = var54;
               var58 = var87;
               var59 = var88;
            } else {
               var59 = 0;
               var58 = var57;
            }
         } else {
            int var90 = var56;
            NoMissDelay var89 = var55;
            var58 = var89;
            var59 = var90;
         }

         var58.i = dev.prestige.recovery.SourceSupport.asBoolean(var59);
         boolean var91 = this.i;
         if (!var91) {
            Object[] var40 = new Object[0];
            AttackCooldownEvent var39 = var1;
            var39.aReturningVoid(var40);
         }
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 71278715777015L ^ var2;
      long var4 = var2 ^ 81330823726307L;
      long var6 = var2 ^ 61156967922678L;
      FloatSetting var13 = this.c;
      Float var14 = (Float)var13.aReturningObject();
      float var9 = var14;
      int var10000 = Event.cReturningInt();
      float var10 = var9 * var9;
      int var8 = var10000;
      MinecraftClient var15 = b;
      ClientWorld var16 = var15.world;
      List var17 = var16.getPlayers();
      Iterator var11 = var17.iterator();

      int var45;
      while (true) {
         Iterator var18 = var11;
         boolean var46 = var18.hasNext();
         if (var46) {
            Iterator var19 = var11;
            PlayerEntity var12 = (PlayerEntity)var19.next();
            int var48 = var8;
            PlayerEntity var47 = var12;
            PlayerEntity var37 = var47;
            PlayerEntity var36 = var47;
            if (var48 != 0) {
               MinecraftClient var20 = b;
               ClientPlayerEntity var50 = var20.player;
               PlayerEntity var49 = var36;
               if (var49 == var50) {
                  continue;
               }

               var37 = var12;
            }

            PlayerEntity var23 = var37;
            byte var65 = ((byte)((var23.isAlive()) ? 1 : 0));
            int var52 = var8;
            byte var51 = var65;
            byte var39 = var51;
            byte var38 = var51;
            if (var52 != 0) {
               byte var53 = var38;
               if (var53 == 0) {
                  continue;
               }

               PlayerValidationTracker var66 = Prestige.i;
               Object[] var26 = new Object[]{var12, var4};
               PlayerValidationTracker var25 = var66;
               var39 = ((byte)((var25.aReturningBoolean(var26)) ? 1 : 0));
            }

            int var55 = var8;
            byte var54 = var39;
            byte var41 = var54;
            byte var40 = var54;
            if (var55 != 0) {
               byte var56 = var40;
               if (var56 == 0) {
                  continue;
               }

               SocialsManager var67 = Prestige.g;
               PlayerEntity var28 = var12;
               Text var29 = var28.getName();
               Object[] var31 = new Object[]{var29.getString(), var6};
               SocialsManager var30 = var67;
               var41 = ((byte)((var30.aReturningBoolean(var31)) ? 1 : 0));
            }

            int var58 = var8;
            byte var57 = var41;
            int var43 = var57;
            byte var42 = var57;
            if (var58 != 0) {
               byte var59 = var42;
               if (var59 != 0) {
                  continue;
               }

               MinecraftClient var33 = b;
               PlayerEntity var35 = var12;
               ClientPlayerEntity var34 = var33.player;
               double var68;
               var43 = (var68 = var34.squaredDistanceTo((Entity)var35) - var10) == 0.0 ? 0 : (var68 < 0.0 ? -1 : 1);
            }

            int var61 = var8;
            int var60 = var43;
            var45 = var60;
            int var44 = var60;
            if (var61 == 0) {
               break;
            }

            int var62 = var44;
            if (var62 <= 0) {
               var45 = 1;
               break;
            }

            int var63 = var8;
            if (var63 != 0) {
               continue;
            }
         }

         return false;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var45);
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      long var10001 = 42144704080974L ^ 61444489982962L;
      int var6 = Event.cReturningInt();
      Object[] var9 = new Object[0];
      AttackAttemptEvent var8 = var1;
      EventPhase var10000 = var8.aReturningEventPhase(var9);
      EventPhase var32 = EventPhase.POST;
      EventPhase var31 = var10000;
      if (var31 == var32) {
         MinecraftClient var11 = b;
         HitResult var7 = var11.crosshairTarget;
         HitResult var33 = var7;
         if (var33 != null) {
            label28: {
               MinecraftClient var13 = b;
               ClientPlayerEntity var14 = var13.player;
               Object[] var15 = new Object[]{var14.getMainHandStack(), 19476550655932L};
               boolean var42 = InventoryUtil.aReturningBoolean(var15);
               int var35 = var6;
               boolean var34 = var42;
               boolean var30 = var34;
               boolean var29 = var34;
               if (var35 != 0) {
                  boolean var36 = var29;
                  if (var36) {
                     break label28;
                  }

                  MinecraftClient var17 = b;
                  ClientPlayerEntity var18 = var17.player;
                  ItemStack var19 = var18.getMainHandStack();
                  boolean var37 = var19.getItem() instanceof AxeItem;
                  var30 = var37;
               }

               boolean var38 = var30;
               if (!var38) {
                  return;
               }
            }

            HitResult var21 = var7;
            Type var43 = var21.getType();
            Type var40 = Type.MISS;
            Type var39 = var43;
            if (var39 == var40) {
               boolean var41 = this.i;
               if (!var41) {
                  MinecraftClient var24 = b;
                  ClientPlayerEntity var25 = var24.player;
                  var25.handSwinging = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  Object[] var28 = new Object[0];
                  AttackAttemptEvent var27 = var1;
                  var27.aReturningVoid(var28);
               }
            }
         }
      }
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(53523389808985L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -5518731223821214923L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)179L,
            (byte)45929L,
            (byte)11757959L,
            (byte)3010037553L,
            (byte)770569613569L,
            (byte)197265821073735L,
            (byte)50500050194876315L,
            (byte)-5518731223821214923L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 57;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 15;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 50;
            yield var20;
         }
         case 6 -> {
            byte var21 = 61;
            yield var21;
         }
         case 7 -> {
            byte var22 = 63;
            yield var22;
         }
         case 8 -> {
            byte var23 = 42;
            yield var23;
         }
         case 9 -> {
            byte var24 = 19;
            yield var24;
         }
         case 10 -> {
            byte var25 = 0;
            yield var25;
         }
         case 11 -> {
            byte var26 = 18;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 4;
            yield var28;
         }
         case 14 -> {
            byte var29 = 34;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 60;
            yield var31;
         }
         case 17 -> {
            byte var32 = 13;
            yield var32;
         }
         case 18 -> {
            byte var33 = 16;
            yield var33;
         }
         case 19 -> {
            byte var34 = 58;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 8;
            yield var36;
         }
         case 22 -> {
            byte var37 = 10;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 45;
            yield var39;
         }
         case 25 -> {
            byte var40 = 52;
            yield var40;
         }
         case 26 -> {
            byte var41 = 29;
            yield var41;
         }
         case 27 -> {
            byte var42 = 35;
            yield var42;
         }
         case 28 -> {
            byte var43 = 56;
            yield var43;
         }
         case 29 -> {
            byte var44 = 38;
            yield var44;
         }
         case 30 -> {
            byte var45 = 40;
            yield var45;
         }
         case 31 -> {
            byte var46 = 7;
            yield var46;
         }
         case 32 -> {
            byte var47 = 20;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 27;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 24;
            yield var53;
         }
         case 39 -> {
            byte var54 = 53;
            yield var54;
         }
         case 40 -> {
            byte var55 = 30;
            yield var55;
         }
         case 41 -> {
            byte var56 = 6;
            yield var56;
         }
         case 42 -> {
            byte var57 = 3;
            yield var57;
         }
         case 43 -> {
            byte var58 = 22;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 37;
            yield var60;
         }
         case 46 -> {
            byte var61 = 1;
            yield var61;
         }
         case 47 -> {
            byte var62 = 28;
            yield var62;
         }
         case 48 -> {
            byte var63 = 47;
            yield var63;
         }
         case 49 -> {
            byte var64 = 51;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 32;
            yield var66;
         }
         case 52 -> {
            byte var67 = 48;
            yield var67;
         }
         case 53 -> {
            byte var68 = 12;
            yield var68;
         }
         case 54 -> {
            byte var69 = 54;
            yield var69;
         }
         case 55 -> {
            byte var70 = 23;
            yield var70;
         }
         case 56 -> {
            byte var71 = 21;
            yield var71;
         }
         case 57 -> {
            byte var72 = 17;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 41;
            yield var74;
         }
         case 60 -> {
            byte var75 = 25;
            yield var75;
         }
         case 61 -> {
            byte var76 = 5;
            yield var76;
         }
         case 62 -> {
            byte var77 = 43;
            yield var77;
         }
         default -> 26;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = ")\u0000\u0013Xt7)\u0000\u0004\u0004x83K\u0004\u001ax-4:QE!";
      m[1] = "]<V*<\u0013C4Le^\u000fD)";
      m[2] = "]\u0012#\"\u00130]\u00124~\u001f?GY4`\u001f*@(f:Kn";
      m[3] = boolean.class;
      n[3] = "java/lang/Boolean";
      m[4] = "\n\"!\b#\u0014\u001c\"$R0\u0003\u000bi'T<\u0017\u001a.0Cw\u0007\u0002.2H-J>52U-\r\t\"";
      m[5] = "7Mp=7\u001d!Mug$\n6\u0006va(\u001e'Aavc\f5";
      m[6] = "Z\bf}\u001a\u007f/(mr\u000b0N&fy\u000fj:";
      m[7] = "$TZ;M>2T_a^)%\u001f\\gR=4XKp\u0019(\u000f";
      m[8] = "1\u0017)N%mD7\"A4\"%9)J0xQ";
      m[9] = "*$\u0018\"<\u0002*$\u000f~0\r0o\u000f`0\u00187\u001e[8g";
      m[10] = "P\u0013_ YmP\u0013H|UbJXHbUwM)\u001a<\r3";
      m[11] = double.class;
      n[11] = "java/lang/Double";
      m[12] = "r\u00074qv\u0013l\u000f.>\u0011\u0012}\u0014#d7\u0014";
      m[13] = "HhHN\u0012D^hM\u0014\u0001SI#N\u0012\rGXdY\u0005FUi";
      m[14] = int.class;
      n[14] = "java/lang/Integer";
      m[15] = "8/M [S8/Z|W\\\"dZbWI%\u0015\n?\u0006";
      m[16] = ":\u001e4;\u0015;,\u001e1a\u0006,;U2g\n8*\u0012%pA/\u0018";
      m[17] = "\u00175h#\u001c\u001e\u001c:yl}\u0010\u00171}6";
      m[18] = "#2m`Lb(=|/$b&2o";
      m[19] = float.class;
      n[19] = "java/lang/Float";
      m[20] = "~\\e2(q~\\rn$~d\u0017rp$kcf#)s)";
      m[21] = "-\n\u000e*\"k&\u0005\u001fe_s5\u0002\u0016,";
      m[22] = "0LA\u0004\u000b0&LD^\u0018'1\u0007GX\u00143 @PO_%m";
      m[23] = "\u0011M\f`v.\u001aB\u001d/\u0015#\u000fO\u0012D !\u001e\\\u000eh7,";
      m[24] = "o\u0017T7\u0011>o\u0017Ck\u001d1u\\Cu\u001d$r-\u0011.En";
      m[25] = "JA'y\u0016sJA0%\u001a|P\n0;\u001aiW{b`B(";
      m[26] = "\u0019\u000e\u0010b>F\u0019\u000e\u0007>2I\u0003E\u0007 2\\\u00044V\u007fj\u000b\u0014\u0007\u0005? pE_T";
      m[27] = "EW\u00153 90w\u001e<1vQy\u001575,%";
      m[28] = "FA(!_MPA-{LZG\n.}@NVM9j\u000bJ";
      m[29] = "Wxf(4UWxqt8ZM3qj8OJB 5`";
      m[30] = "\u00107e0\u000f\u001ae\u0017n?\u001eU\u0004\u0019e4\u001a\u000fp";
      m[31] = void.class;
      n[31] = "java/lang/Void";
      m[32] = "\"\u0010\u000fiYY4\u0010\n3JN#[\t5FZ2\u001c\u001e\"\rJ)";
      m[33] = "M]+.U98} !DvYs+*@,-";
      m[34] = "|x>w\u0000(jx;-\u0013?}38+\u001f+lt/<T<R";
      m[35] = "A%^/Vo4\u0005U G U\u000b^+Cz!";
      m[36] = "3\u00111PM\u001e8\u001e \u001f!\u001d6\u001c\"P\r";
      m[37] = "n/\u0010[\u0018Ie \u0001\u0014\u007fKp+\u0001_D";
      m[38] = "\u0019CBiSXlcIfB\u0017\rmBmFMy";
      m[39] = "4\u000f&\u0001{\u0004\"\u000f#[h\u00135D ]d\u0007$\u00037J/\u00109";
      m[40] = "cd\u00047M\u0003\u0016D\u000f8\\LwJ\u00043X\u0016\u0003";
      m[41] = "]I0\ty\u0000CA*F\u0004\u0010C";
      m[42] = "cIQ*X#>\n\\s?\"XKO/]*f\rEsO";
      m[43] = "+-hk^%m'4y7r\u0010.2rJ%m1s4X\u001b*?10Xc|?ht7";
      m[44] = "M}(|\u00000\u0011=xj85|(\u007ftW5\u001e<lmA_";
      m[45] = "GP\u00151E\n\u0016\t\u001d0{\u0017J\u0014\u0005i\u0017%\u0018Y]?{\u0012Y\u0006\bk\u001d\u0014J\u0014\u0018\u000e";
      m[46] = "jJi8NDp\u001655r\u0015j@0;%B0\u0016oW\u0013\u001c6Bhh\t@jO";
      m[47] = "9sGx\u00042d0J!c=\u0002w\u001ar\u0012ho ]e\u0002";
      m[48] = "4Z\r\u001f9\u0001-GH\u001e\u0006V!9\u001dTcVq[O[:QOS\u0006@a\u000f-\u0001\t\u0019f14Z\r\u001f9\u0001-GH\u001e\u0006";
      m[49] = ">\u0019w\na9{\u0010'\u0018\u00007a\u0014,\u0016Wg:Drz:3<@'\u0002l3e\u0004";
      m[50] = "{^\u001c\u0001\u0018,'\u001eL\u0017 *J\u0019\u001f\u0013]}7\u0006^UOC(\u0018\\\u0012O1 \u0003R\u0012 ";
      m[51] = "i+\u0014^P0,\"DL15:7KI]\u0007j{\u0016\u001e1n&%S\u0010U`+$\u001b.\u000e+*2JNM6g,+";
      m[52] = "\u0000J]^W]@\f\bQhPE\u001dBJ\u0014VCp\bO\u0018UE@\u0003I\u0018^9";
      m[53] = "`:@J<q<z\u0010\\\u0004uQo\u0017Bkt3{\u0004[}\u001e";
      m[54] = "\u0013fHPDENlLA&\u0011\u0013sPWO\u001d*}PGK{N~\b\u0003I\u0003\u0018~QG&";
      m[55] = "O\u0015jV^\u0001S[)\u0013!\u0013(^nP\\DUA/\u0016NzO\u0015jV^\u0001S[)\u0013!";
      m[56] = ",3{!\u000b=y&s%n:F=o}\tm$o`$\u000eS";
      m[57] = "06t\u0000OHre/\u0004 @/sO\rD\\$\u000fx\u000fAN#ml\u001cXXI";
      m[58] = "\u000b]\u0012[^=\u0000[\u0012P\"kVA\u001e?H|^V\\]\u001as\u0007Qb";
      m[59] = "Ai?\nf\u0016\u0015!aN\u001e\u0004J<cZIS\u0014k;6 \n\u0014!fVe\u0003D3";
      m[60] = "\u0002h\u0010iu\u0013\u001c}\r5\u0015\u0012\u0003d&(o\u001c\bw}:+\u000f\u0013|\u0000iu\u001e\u0000\u0018";
      m[61] = "\u000b\\LK#5\\\tJX\u0019!eKKSds\u0018T\n\u0015vM_ZH\u0011v5\tZ\u0011U\u0019";
      m[62] = "V@F\u000e<>\n\u0000\u0016\u0018\u00048g\u0007E\u001cyo\u001a\u0018\u0004ZkQ\u0002G\u0004Yd+\bD\u0001Y\u0004";
      m[63] = "O$SK\u0011WD\"S@m\u0007\u00163eB\u001d\u001b\u007frI\u0013T\b\u0007$IJ\u0010g";
      m[64] = "\u001eEwn74I\u0010q}\r%pF&ant\u000bYrkgL\u001f@#n57\u0000\u0014)g\r";
      m[65] = "9B\u0013!rQ{\fZtLVmLCv d=\f\u001c.L_p]\u001eq\"Ae@B\u0011";
      m[66] = "\u0003qE15\u000e\\0\u0015O9\u001b\u0018jH#\u000bOT6\u0012q\\O^oRp0\u000f\u0018:]O";
      m[67] = "dO\u0002h0\r&\u0001K=\u000e\n0AR?b8`\r\ne\u000eU7\u0001\u000b7v\u00037XOX";
      m[68] = "r\r:I[V7\u0004j[:S!\u0011e^VarU9\u0006:Vt\u001d:\u0007B\u0007-\u0015;9";
      m[69] = "XU:<!{\u000f\u0012-,\u001b\u007fe\u0015o6f(\u0018\n.pt\u0016_\u0004lttn\t\u000450\u001b";
      m[70] = "AMP?\rz\u0015\u0005\u000e{uhJ\u0018\fo\"?\u0014KU\u0003\u0016aP\u0013W?\u001ejO\b";
      m[71] = "4^Vutl`\u0016\b1\f~?\u000b\n%[)`VQIkk4\u0018\u000714*d";
      m[72] = "\u0004\u001fj\u001d\u001c4\u0006\\n\u001b}d\u000b\nj\u001c#c\u000b\u0010n`\u0011`\u0004\u0004oQ\u00041SP\u0003";
      m[73] = "\u001d#K(V%\u0015(T3i|\u00138P)\u0005NG{\u000f~R\u0019\u001f#\r!U&\u0005\u007fQ,i";
      m[74] = "'<aU!\u0017c~sP@\u000e]?>\u0011=Y  \u007fW/g4/`\u0005*\u0005 <y\u0013@";
      m[75] = "RxK\u0003\u0006d\nd\u0018\r|j7`MI\u0001=J\u007f\f\u000f\u0013\u0003\rqN\u000b\u0013{[q\u0017O|";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1214853909342353L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1214853909342353L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1214853909342353L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 211;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 236;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 198;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 79;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 119;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 204;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 211;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 236;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 198;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e9",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(NoMissDelay var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e9;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/e9", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((NoMissDelay)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
