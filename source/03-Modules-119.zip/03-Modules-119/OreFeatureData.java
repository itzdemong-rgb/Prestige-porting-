package dev.zprestige.prestige.client.modules.state;
import dev.zprestige.prestige.api.accessor.CountPlacementModifierAccessor;
import dev.zprestige.prestige.api.accessor.HeightRangePlacementModifierAccessor;
import dev.zprestige.prestige.api.accessor.RarityFilterPlacementModifierAccessor;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.ToIntFunction;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.BuiltinRegistries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper.Impl;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntry.Reference;
import net.minecraft.util.math.intprovider.ConstantIntProvider;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.GenerationSettings;
import net.minecraft.world.biome.source.BiomeSource;
import net.minecraft.world.dimension.DimensionOptions;
import net.minecraft.world.dimension.DimensionOptionsRegistryHolder;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.gen.HeightContext;
import net.minecraft.world.gen.WorldPreset;
import net.minecraft.world.gen.WorldPresets;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.FeatureConfig;
import net.minecraft.world.gen.feature.OreFeatureConfig;
import net.minecraft.world.gen.feature.OrePlacedFeatures;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.feature.ScatteredOreFeature;
import net.minecraft.world.gen.feature.util.PlacedFeatureIndexer;
import net.minecraft.world.gen.feature.util.PlacedFeatureIndexer.IndexedFeatures;
import net.minecraft.world.gen.heightprovider.HeightProvider;
import net.minecraft.world.gen.placementmodifier.CountPlacementModifier;
import net.minecraft.world.gen.placementmodifier.HeightRangePlacementModifier;
import net.minecraft.world.gen.placementmodifier.PlacementModifier;
import net.minecraft.world.gen.placementmodifier.RarityFilterPlacementModifier;

public class OreFeatureData {
   public int a;
   public int b;
   public String c;
   public IntProvider d;
   public HeightProvider e;
   public HeightContext f;
   public float g;
   public float h;
   public int i;
   public List j;
   public Color k;
   public boolean l;
   private static final long m = 7844814043829L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final Object[] t = new Object[147];
   private static final String[] u = new String[147];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public static Map aReturningMap(Object[] var0) {
      long var4;
      Impl var8;
      Map var9;
      int var82;
      long var99;
      String var1 = (String)var0[0];
      long var2 = (Long)var0[1];
      var99 = 7844814043829L ^ var2;
      var4 = var99 ^ 34647969554579L;
      WrapperLookup var7 = BuiltinRegistries.createWrapperLookup();
      int var10000 = Event.bReturningInt();
      RegistryKey var17 = RegistryKeys.PLACED_FEATURE;
      WrapperLookup var16 = var7;
      var8 = var16.getOrThrow(var17);
      RegistryKey var19 = RegistryKeys.WORLD_PRESET;
      WrapperLookup var18 = var7;
      Impl var10001 = var18.getOrThrow(var19);
      RegistryKey var21 = WorldPresets.DEFAULT;
      Impl var20 = var10001;
      Reference var22 = var20.getOrThrow(var21);
      WorldPreset var23 = (WorldPreset)var22.value();
      DimensionOptionsRegistryHolder var24 = var23.createDimensionsRegistryHolder();
      var9 = var24.dimensions();
      String var11 = var1;
      int var6 = var10000;
      // String var25 = var11;
      var10000 = var25.hashCode();
      int var85 = var6;
      int var84 = var10000;
      var82 = var84;
      int var77 = var84;
      label37:
      if (var85 == 0) {
         int var86 = var77;
         switch (var86) {
            case 1272296422:
               short var105 = 5879;
               long var10002 = 6238942390934851775L ^ var99;
               String var28 = "the_nether";
               String var27 = var11;
               byte var103 = ((byte)((var27.equals(var28)) ? 1 : 0));
               int var88 = var6;
               byte var87 = var103;
               var82 = var87;
               byte var78 = var87;
               if (var88 != 0) {
                  break label37;
               }

               byte var89 = var78;
               byte var79 = var89;
               byte var90 = var79;
               if (var90 == 0) {
                  break;
               }

               var12 = 0;
               int var91 = var6;
               if (var91 == 0) {
                  break;
               }
            case -1350117363:
               short var106 = 2721;
               long var107 = 6374446352927902973L ^ var99;
               String var32 = "the_end";
               String var31 = var11;
               byte var104 = ((byte)((var31.equals(var32)) ? 1 : 0));
               int var93 = var6;
               byte var92 = var104;
               var82 = var92;
               byte var80 = var92;
               if (var93 != 0) {
                  break label37;
               }

               byte var94 = var80;
               byte var81 = var94;
               byte var95 = var81;
               if (var95 != 0) {
                  var12 = 1;
               }
         }

         var82 = var12;
      }

      int var96 = var82;
      DimensionOptions var83;
      switch (var96) {
         case 0:
            RegistryKey var36 = DimensionOptions.NETHER;
            Map var35 = var9;
            DimensionOptions var97 = (DimensionOptions)var35.get(var36);
            var83 = var97;
            break;
         case 1:
            RegistryKey var39 = DimensionOptions.END;
            Map var38 = var9;
            DimensionOptions var98 = (DimensionOptions)var38.get(var39);
            var83 = var98;
            break;
         default:
            RegistryKey var41 = DimensionOptions.OVERWORLD;
            Map var40 = var9;
            var83 = (DimensionOptions)var40.get(var41);
      }

      DimensionOptions var10 = var83;
      DimensionOptions var42 = var10;
      ChunkGenerator var43 = var42.chunkGenerator();
      BiomeSource var44 = var43.getBiomeSource();
      Set var100 = var44.getBiomes();
      Set var45 = var100;
      Stream var46 = var45.stream();
      List var101 = var46.toList();
      Function var48 = invokeBinding1();
      List var47 = var101;
      List var13 = PlacedFeatureIndexer.collectIndexedFeatures(var47, var48, true);
      HashMap var14 = new HashMap();
      RegistryKey var10003 = OrePlacedFeatures.ORE_COAL_LOWER;
      short var10004 = 4224;
      long var10005 = 7627229090248365106L ^ var99;
      short var156 = 2197;
      long var10006 = 574207975255396035L ^ var99;
      short var10008 = 21858;
      long var10009 = 1560601621862928855L ^ var99;
      short var246 = 9512;
      long var10010 = 8861589713160970654L ^ var99;
      short var309 = 9512;
      long var10011 = 8861589713160970654L ^ var99;
      Object[] var247 = new Object[]{null, null, null, null, null, "Coal", new Color(15, 15, 15), var4};
      var247[4] = 6;
      var247[3] = var10003;
      var247[2] = var8;
      var247[1] = var13;
      var247[0] = var14;
      Object[] var50 = var247;
      aReturningVoid(var50);
      var10003 = OrePlacedFeatures.ORE_COAL_UPPER;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var158 = 25043;
      var10006 = 4363565788650547073L ^ var99;
      var10008 = 9512;
      var10009 = 8861589713160970654L ^ var99;
      short var249 = 9512;
      var10010 = 8861589713160970654L ^ var99;
      short var311 = 9512;
      var10011 = 8861589713160970654L ^ var99;
      Object[] var250 = new Object[]{null, null, null, null, null, "Coal", new Color(15, 15, 15), var4};
      var250[4] = 6;
      var250[3] = var10003;
      var250[2] = var8;
      var250[1] = var13;
      var250[0] = var14;
      Object[] var51 = var250;
      aReturningVoid(var51);
      var10003 = OrePlacedFeatures.ORE_IRON_MIDDLE;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var160 = 9820;
      var10006 = 8137673208681127959L ^ var99;
      var10008 = 10885;
      var10009 = 6951045983694007869L ^ var99;
      short var252 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var313 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var253 = new Object[]{null, null, null, null, null, "Iron", new Color(255, 255, 255), var4};
      var253[4] = 6;
      var253[3] = var10003;
      var253[2] = var8;
      var253[1] = var13;
      var253[0] = var14;
      Object[] var52 = var253;
      aReturningVoid(var52);
      var10003 = OrePlacedFeatures.ORE_IRON_SMALL;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var162 = 7702;
      var10006 = 2739249688039315523L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var255 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var315 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var256 = new Object[]{null, null, null, null, null, "Iron", new Color(255, 255, 255), var4};
      var256[4] = 6;
      var256[3] = var10003;
      var256[2] = var8;
      var256[1] = var13;
      var256[0] = var14;
      Object[] var53 = var256;
      aReturningVoid(var53);
      var10003 = OrePlacedFeatures.ORE_IRON_UPPER;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var164 = 7702;
      var10006 = 2739249688039315523L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var258 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var317 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var259 = new Object[]{null, null, null, null, null, "Iron", new Color(255, 255, 255), var4};
      var259[4] = 6;
      var259[3] = var10003;
      var259[2] = var8;
      var259[1] = var13;
      var259[0] = var14;
      Object[] var54 = var259;
      aReturningVoid(var54);
      var10003 = OrePlacedFeatures.ORE_GOLD;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var166 = 21781;
      var10006 = 7034747533214520139L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var261 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var262 = new Object[]{null, null, null, null, null, "Gold", new Color(255, 255, 0), var4};
      var262[4] = 6;
      var262[3] = var10003;
      var262[2] = var8;
      var262[1] = var13;
      var262[0] = var14;
      Object[] var55 = var262;
      aReturningVoid(var55);
      var10003 = OrePlacedFeatures.ORE_GOLD_LOWER;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var168 = 25162;
      var10006 = 4536237296567952391L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var264 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var265 = new Object[]{null, null, null, null, null, "Gold", new Color(255, 255, 0), var4};
      var265[4] = 6;
      var265[3] = var10003;
      var265[2] = var8;
      var265[1] = var13;
      var265[0] = var14;
      Object[] var56 = var265;
      aReturningVoid(var56);
      var10003 = OrePlacedFeatures.ORE_GOLD_EXTRA;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var170 = 25162;
      var10006 = 4536237296567952391L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var267 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var268 = new Object[]{null, null, null, null, null, "Gold", new Color(255, 255, 0), var4};
      var268[4] = 6;
      var268[3] = var10003;
      var268[2] = var8;
      var268[1] = var13;
      var268[0] = var14;
      Object[] var57 = var268;
      aReturningVoid(var57);
      var10003 = OrePlacedFeatures.ORE_GOLD_NETHER;
      var10004 = 22831;
      var10005 = 6856763549656178079L ^ var99;
      short var172 = 25162;
      var10006 = 4536237296567952391L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var270 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var271 = new Object[]{null, null, null, null, null, "Gold", new Color(255, 255, 0), var4};
      var271[4] = 7;
      var271[3] = var10003;
      var271[2] = var8;
      var271[1] = var13;
      var271[0] = var14;
      Object[] var58 = var271;
      aReturningVoid(var58);
      var10003 = OrePlacedFeatures.ORE_GOLD_DELTAS;
      var10004 = 11776;
      var10005 = 1154588173457009331L ^ var99;
      short var174 = 25162;
      var10006 = 4536237296567952391L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var273 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var274 = new Object[]{null, null, null, null, null, "Gold", new Color(255, 255, 0), var4};
      var274[4] = 7;
      var274[3] = var10003;
      var274[2] = var8;
      var274[1] = var13;
      var274[0] = var14;
      Object[] var59 = var274;
      aReturningVoid(var59);
      var10003 = OrePlacedFeatures.ORE_REDSTONE;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var176 = 1744;
      var10006 = 4127396432092086410L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      Object[] var276 = new Object[]{null, null, null, null, null, "Redstone", new Color(255, 0, 0), var4};
      var276[4] = 6;
      var276[3] = var10003;
      var276[2] = var8;
      var276[1] = var13;
      var276[0] = var14;
      Object[] var60 = var276;
      aReturningVoid(var60);
      var10003 = OrePlacedFeatures.ORE_REDSTONE_LOWER;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var178 = 472;
      var10006 = 7189897950928455560L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      Object[] var278 = new Object[]{null, null, null, null, null, "Redstone", new Color(255, 0, 0), var4};
      var278[4] = 6;
      var278[3] = var10003;
      var278[2] = var8;
      var278[1] = var13;
      var278[0] = var14;
      Object[] var61 = var278;
      aReturningVoid(var61);
      var10003 = OrePlacedFeatures.ORE_DIAMOND;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var180 = 14200;
      var10006 = 8585753043238416689L ^ var99;
      short var279 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var324 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var280 = new Object[]{null, null, null, null, null, "Diamond", new Color(0, 255, 255), var4};
      var280[4] = 6;
      var280[3] = var10003;
      var280[2] = var8;
      var280[1] = var13;
      var280[0] = var14;
      Object[] var62 = var280;
      aReturningVoid(var62);
      var10003 = OrePlacedFeatures.ORE_DIAMOND_BURIED;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var182 = 18188;
      var10006 = 1982131217241768283L ^ var99;
      short var281 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var326 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var282 = new Object[]{null, null, null, null, null, "Diamond", new Color(0, 255, 255), var4};
      var282[4] = 6;
      var282[3] = var10003;
      var282[2] = var8;
      var282[1] = var13;
      var282[0] = var14;
      Object[] var63 = var282;
      aReturningVoid(var63);
      var10003 = OrePlacedFeatures.ORE_DIAMOND_LARGE;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var184 = 18188;
      var10006 = 1982131217241768283L ^ var99;
      short var283 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var328 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var284 = new Object[]{null, null, null, null, null, "Diamond", new Color(0, 255, 255), var4};
      var284[4] = 6;
      var284[3] = var10003;
      var284[2] = var8;
      var284[1] = var13;
      var284[0] = var14;
      Object[] var64 = var284;
      aReturningVoid(var64);
      var10003 = OrePlacedFeatures.ORE_DIAMOND_MEDIUM;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var186 = 18188;
      var10006 = 1982131217241768283L ^ var99;
      short var285 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      short var330 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var286 = new Object[]{null, null, null, null, null, "Diamond", new Color(0, 255, 255), var4};
      var286[4] = 6;
      var286[3] = var10003;
      var286[2] = var8;
      var286[1] = var13;
      var286[0] = var14;
      Object[] var65 = var286;
      aReturningVoid(var65);
      var10003 = OrePlacedFeatures.ORE_LAPIS;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var188 = 31863;
      var10006 = 7871137842123717160L ^ var99;
      short var331 = 13392;
      var10011 = 3721227499808633060L ^ var99;
      Object[] var287 = new Object[]{null, null, null, null, null, "Lapis", new Color(0, 0, 200), var4};
      var287[4] = 6;
      var287[3] = var10003;
      var287[2] = var8;
      var287[1] = var13;
      var287[0] = var14;
      Object[] var66 = var287;
      aReturningVoid(var66);
      var10003 = OrePlacedFeatures.ORE_LAPIS_BURIED;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var190 = 13782;
      var10006 = 478464361147495303L ^ var99;
      short var332 = 6540;
      var10011 = 1973941754656726333L ^ var99;
      Object[] var288 = new Object[]{null, null, null, null, null, "Lapis", new Color(0, 0, 200), var4};
      var288[4] = 6;
      var288[3] = var10003;
      var288[2] = var8;
      var288[1] = var13;
      var288[0] = var14;
      Object[] var67 = var288;
      aReturningVoid(var67);
      var10003 = OrePlacedFeatures.ORE_COPPER;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var192 = 18296;
      var10006 = 4598069051142701366L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var290 = 8645;
      var10010 = 2127511481155724665L ^ var99;
      Object[] var291 = new Object[]{null, null, null, null, null, "Copper", new Color(255, 120, 0), var4};
      var291[4] = 6;
      var291[3] = var10003;
      var291[2] = var8;
      var291[1] = var13;
      var291[0] = var14;
      Object[] var68 = var291;
      aReturningVoid(var68);
      var10003 = OrePlacedFeatures.ORE_COPPER_LARGE;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var194 = 5466;
      var10006 = 8192061195687056130L ^ var99;
      var10008 = 2346;
      var10009 = 5171087943355043221L ^ var99;
      short var293 = 9000;
      var10010 = 4324409048280147871L ^ var99;
      Object[] var294 = new Object[]{null, null, null, null, null, "Copper", new Color(255, 120, 0), var4};
      var294[4] = 6;
      var294[3] = var10003;
      var294[2] = var8;
      var294[1] = var13;
      var294[0] = var14;
      Object[] var69 = var294;
      aReturningVoid(var69);
      var10003 = OrePlacedFeatures.ORE_EMERALD;
      var10004 = 19795;
      var10005 = 1595435403522984430L ^ var99;
      short var196 = 22891;
      var10006 = 7020035596709470000L ^ var99;
      short var295 = 2346;
      var10010 = 5171087943355043221L ^ var99;
      Object[] var296 = new Object[]{null, null, null, null, null, "Emerald", new Color(0, 255, 0), var4};
      var296[4] = 6;
      var296[3] = var10003;
      var296[2] = var8;
      var296[1] = var13;
      var296[0] = var14;
      Object[] var70 = var296;
      aReturningVoid(var70);
      var10003 = OrePlacedFeatures.ORE_QUARTZ_NETHER;
      var10004 = 11776;
      var10005 = 1154588173457009331L ^ var99;
      short var198 = 31054;
      var10006 = 1108523596255411987L ^ var99;
      var10008 = 6540;
      var10009 = 1973941754656726333L ^ var99;
      short var298 = 6540;
      var10010 = 1973941754656726333L ^ var99;
      short var337 = 6540;
      var10011 = 1973941754656726333L ^ var99;
      Object[] var299 = new Object[]{null, null, null, null, null, "Quartz", new Color(200, 200, 200), var4};
      var299[4] = 7;
      var299[3] = var10003;
      var299[2] = var8;
      var299[1] = var13;
      var299[0] = var14;
      Object[] var71 = var299;
      aReturningVoid(var71);
      var10003 = OrePlacedFeatures.ORE_QUARTZ_DELTAS;
      var10004 = 11776;
      var10005 = 1154588173457009331L ^ var99;
      short var200 = 11321;
      var10006 = 6064354833323420278L ^ var99;
      var10008 = 6540;
      var10009 = 1973941754656726333L ^ var99;
      short var301 = 6540;
      var10010 = 1973941754656726333L ^ var99;
      short var339 = 6540;
      var10011 = 1973941754656726333L ^ var99;
      Object[] var302 = new Object[]{null, null, null, null, null, "Quartz", new Color(200, 200, 200), var4};
      var302[4] = 7;
      var302[3] = var10003;
      var302[2] = var8;
      var302[1] = var13;
      var302[0] = var14;
      Object[] var72 = var302;
      aReturningVoid(var72);
      var10003 = OrePlacedFeatures.ORE_DEBRIS_SMALL;
      var10004 = 11776;
      var10005 = 1154588173457009331L ^ var99;
      short var202 = 1100;
      var10006 = 1995061277098263071L ^ var99;
      var10008 = 6540;
      var10009 = 1973941754656726333L ^ var99;
      short var304 = 31836;
      var10010 = 6589684581581977829L ^ var99;
      short var341 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var305 = new Object[]{null, null, null, null, null, "Ancient Debris", new Color(200, 30, 255), var4};
      var305[4] = 7;
      var305[3] = var10003;
      var305[2] = var8;
      var305[1] = var13;
      var305[0] = var14;
      Object[] var73 = var305;
      aReturningVoid(var73);
      var10003 = OrePlacedFeatures.ORE_ANCIENT_DEBRIS_LARGE;
      var10004 = 11776;
      var10005 = 1154588173457009331L ^ var99;
      short var204 = 22920;
      var10006 = 2122347319142621124L ^ var99;
      var10008 = 6540;
      var10009 = 1973941754656726333L ^ var99;
      short var307 = 18515;
      var10010 = 9173171225065082093L ^ var99;
      short var343 = 2346;
      var10011 = 5171087943355043221L ^ var99;
      Object[] var308 = new Object[]{null, null, null, null, null, "Ancient Debris", new Color(200, 30, 255), var4};
      var308[4] = 7;
      var308[3] = var10003;
      var308[2] = var8;
      var308[1] = var13;
      var308[0] = var14;
      Object[] var74 = var308;
      aReturningVoid(var74);
      HashMap var15 = new HashMap();
      Consumer var76 = invokeBinding2(var15, var14);
      List var75 = var101;
      var75.forEach(var76);
      return var15;
   }

   private static void aReturningVoid(Object[] var0) {
      Map var2 = (Map)var0[0];
      List var5 = (List)var0[1];
      Impl var6 = (Impl)var0[2];
      RegistryKey var7 = (RegistryKey)var0[3];
      int var1 = (Integer)var0[4];
      String var8 = (String)var0[5];
      Color var9 = (Color)var0[6];
      long var3 = (Long)var0[7];
      var3 = 7844814043829L ^ var3;
      long var10 = var3 ^ 16377352519869L;
      RegistryKey var16 = var7;
      Impl var15 = var6;
      Reference var17 = var15.getOrThrow(var16);
      PlacedFeature var12 = (PlacedFeature)var17.value();
      int var19 = var1;
      List var18 = var5;
      IndexedFeatures var20 = (IndexedFeatures)var18.get(var19);
      ToIntFunction var10000 = var20.indexMapping();
      PlacedFeature var22 = var12;
      ToIntFunction var21 = var10000;
      int var13 = var21.applyAsInt(var22);
      OreFeatureData var14 = new OreFeatureData(var12, var1, var13, var8, var9, var10);
      OreFeatureData var25 = var14;
      PlacedFeature var24 = var12;
      Map var23 = var2;
      var23.put(var24, var25);
   }

   private OreFeatureData(PlacedFeature var1, int var2, int var3, String var4, Color var5, long var6) {
      super();
      var6 = 7844814043829L ^ var6;
      long var8 = var6 ^ 135904898135632L;
      long var10 = var6 ^ 99630147209916L;
      long var12 = var6 ^ 94029833757217L;

      this.d = ConstantIntProvider.create(1);
      this.g = 1.0F;
      this.j = List.of();
      this.a = var2;
      this.b = var3;
      this.c = var4;
      this.k = var5;
      int var10000 = Event.bReturningInt();
      MinecraftClient var20 = MinecraftClient.getInstance();
      ClientWorld var21 = var20.world;
      int var15 = var21.getBottomY();
      MinecraftClient var22 = MinecraftClient.getInstance();
      ClientWorld var23 = var22.world;
      DimensionType var24 = var23.getDimension();
      int var16 = var24.logicalHeight();
      int var26 = var16;
      int var25 = var15;
      this.f = new HeightContext(null, HeightLimitView.create(var25, var26));
      PlacedFeature var27 = var1;
      List var28 = var27.placementModifiers();
      Iterator var17 = var28.iterator();
      int var14 = var10000;

      Object var65;
      while (true) {
         Iterator var29 = var17;
         boolean var68 = var29.hasNext();
         if (var68) {
            Iterator var30 = var17;
            PlacementModifier var18 = (PlacementModifier)var30.next();
            int var70 = var14;
            PlacementModifier var69 = var18;
            var65 = var69;
            PlacementModifier var59 = var69;
            if (var70 != 0) {
               break;
            }

            label66: {
               boolean var93 = var59 instanceof CountPlacementModifier;
               int var72 = var14;
               boolean var71 = var93;
               boolean var62 = var71;
               boolean var60 = var71;
               if (var72 == 0) {
                  boolean var73 = var60;
                  boolean var61 = var73;
                  boolean var74 = var61;
                  if (var74) {
                     CountPlacementModifierAccessor var10001 = new CountPlacementModifierAccessor((CountPlacementModifier)var18);
                     Object[] var34 = new Object[]{var8};
                     CountPlacementModifierAccessor var33 = var10001;
                     this.d = var33.aReturningVoid(var34);
                     int var75 = var14;
                     if (var75 == 0) {
                        break label66;
                     }
                  }

                  boolean var76 = var18 instanceof HeightRangePlacementModifier;
                  var62 = var76;
               }

               int var78 = var14;
               boolean var77 = var62;
               boolean var64 = var77;
               boolean var63 = var77;
               if (var78 == 0) {
                  boolean var79 = var63;
                  if (var79) {
                     HeightRangePlacementModifierAccessor var94 = new HeightRangePlacementModifierAccessor((HeightRangePlacementModifier)var18);
                     Object[] var39 = new Object[]{var12};
                     HeightRangePlacementModifierAccessor var38 = var94;
                     this.e = var38.aReturningVoid(var39);
                     int var80 = var14;
                     if (var80 == 0) {
                        break label66;
                     }
                  }

                  boolean var81 = var18 instanceof RarityFilterPlacementModifier;
                  var64 = var81;
               }

               boolean var82 = var64;
               if (var82) {
                  RarityFilterPlacementModifierAccessor var95 = new RarityFilterPlacementModifierAccessor((RarityFilterPlacementModifier)var18);
                  Object[] var43 = new Object[]{var10};
                  RarityFilterPlacementModifierAccessor var42 = var95;
                  this.g = var42.aReturningInt(var43);
               }
            }

            int var83 = var14;
            if (var83 == 0) {
               continue;
            }
         }

         PlacedFeature var45 = var1;
         RegistryEntry var46 = var45.feature();
         var65 = var46.value();
         break;
      }

      label41: {
         ConfiguredFeature var47 = (ConfiguredFeature)var65;
         FeatureConfig var91 = var47.config();
         int var85 = var14;
         FeatureConfig var84 = var91;
         FeatureConfig var67 = var84;
         FeatureConfig var66 = var84;
         if (var85 == 0) {
            boolean var86 = var66 instanceof OreFeatureConfig;
            if (!var86) {
               break label41;
            }

            FeatureConfig var87 = var91;
            var67 = var87;
         }

         OreFeatureConfig var92 = (OreFeatureConfig)var67;
         OreFeatureConfig var50 = var92;
         this.h = var50.discardOnAirChance;
         OreFeatureConfig var51 = var92;
         this.i = var51.size;
         OreFeatureConfig var52 = var92;
         List var53 = var52.targets;
         this.j = List.copyOf(var53);
         int var88 = var14;
         if (var88 == 0) {
            PlacedFeature var56 = var1;
            RegistryEntry var57 = var56.feature();
            ConfiguredFeature var58 = (ConfiguredFeature)var57.value();
            boolean var89 = var58.feature() instanceof ScatteredOreFeature;
            if (var89) {
               this.l = dev.prestige.recovery.SourceSupport.asBoolean(1);
            }

            return;
         }
      }

      PlacedFeature var54 = var1;
      String var10002 = String.valueOf(var54);
      short var10003 = 7212;
      long var10004 = 830284451059350102L ^ var6;
      short var96 = 22964;
      long var10005 = 569586623795396547L ^ var6;
      throw new IllegalStateException("config for " + var10002 + "is not OreFeatureConfig.class");
   }

   private static void lambda$getRegistry$2(Map var0, Map var1, RegistryEntry var2) {
      RegistryEntry var5 = var2;
      Optional var6 = var5.getKey();
      RegistryKey var10001 = (RegistryKey)var6.get();
      ArrayList var9 = new ArrayList();
      RegistryKey var8 = var10001;
      Map var7 = var0;
      var7.put(var8, var9);
      RegistryEntry var10 = var2;
      Biome var11 = (Biome)var10.value();
      GenerationSettings var12 = var11.getGenerationSettings();
      List var13 = var12.getFeatures();
      Stream var10000 = var13.stream();
      Function var15 = invokeBinding3();
      Stream var14 = var10000;
      var10000 = var14.flatMap(var15);
      Function var17 = invokeBinding4();
      Stream var16 = var10000;
      var10000 = var16.map(var17);
      Map var18 = var1;
      Objects.requireNonNull(var18);
      Predicate var20 = invokeBinding5(var1);
      Stream var19 = var10000;
      var10000 = var19.filter(var20);
      Consumer var22 = invokeBinding6(var0, var2, var1);
      Stream var21 = var10000;
      var21.forEach(var22);
   }

   private static void lambda$getRegistry$1(Map var0, RegistryEntry var1, Map var2, PlacedFeature var3) {
      RegistryEntry var6 = var1;
      Optional var7 = var6.getKey();
      Object var9 = var7.get();
      Map var8 = var0;
      List var10000 = (List)var8.get(var9);
      PlacedFeature var11 = var3;
      Map var10 = var2;
      OreFeatureData var13 = (OreFeatureData)var10.get(var11);
      List var12 = var10000;
      var12.add(var13);
   }

   private static List lambda$getRegistry$0(RegistryEntry var0) {
      RegistryEntry var3 = var0;
      Biome var4 = (Biome)var3.value();
      GenerationSettings var5 = var4.getGenerationSettings();
      return var5.getFeatures();
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(29624097687063L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[23];
      String var17 = " \n\u0084\u001eoÎ\u0088ZÔ£\u0001a¿\u009b2¢\u0010\u0018`h²ö¿¶FW;+\u009dõå,Ì\u0010Ý\u0093¾ª--\u008dÇªß\u008e.È²\u008e\b\u0010ÿá\u00997\u0092ïóN\u0005©]Ëñ¸\u0003ë8?ÚÞ\u0087y\u009cî\u0093>Ý6®*¨ç\u0081ÿ\u001fszÎ\u0082ü\u008cïKY ¼Ñ!\u0098\u0005Q\u00ad¹T\u00862Ãf\u008aS\u0091$RT\u0002gI§w\u0094¸I%\u0010N}=·ÔÊ\u0004ò{p\u001b\u000ee\\uÑ\u0010\u0083(\u008c\u008b\u00adQ+Uå\u008f.\u001f\u008b\fA¥\u0018þe\u0005o&úýlåÎÕ\u001a,öÝ\t\u0089ûL¢5L\rô\u0010Ã\u007fò\u0093Í\u0089}ï\u008aJ\nË\u0091QÑu\u0018\u0012\u008cËá¼\u008c«\u0088cbêèfç\u0095Ý\u001fõrì Á\u009d\"\u00103Ýq\u0006.W\u008dDNkõ\u0081-\u0012#V\u0010\"t$3n¡¤m«ä\u0005\u0014ùçzë\u0010\u009e\u008cð\u0000Q$ø£\u0093Q\u0013Ðä½\u0014\u0085\u0018ÃZ\u008c[£æ\f\"ÏÖkOh\u0006£+ü\u0003.\u0011=áðÖ .ø\u0081f\u008d@(eÜåìg)Ì\u00156\u000fjÀ+\u0089U7ëàøÎ\u009e³j»É\u0010ÔÜSÜæ¢\u0084\b\nú¯\fÍ\u009b\u001fP\u0010ëçî\u0086áø»\u0015ÏA@ÒcÐö\u001f R\u0004zdaf\"Å`I¢lFyöÑwcàw¨b'ÑXKÙ;´Xãm\u0010\u0004\u008aF½ç¥+ªMø¢½Ç5?Î\u0010egy\u008b\u0088Ä3Gd\tÃ.®1û1\u0010µVl1þ¹1;\u0083~p.ÀÖæ½";
      int var19 = " \n\u0084\u001eoÎ\u0088ZÔ£\u0001a¿\u009b2¢\u0010\u0018`h²ö¿¶FW;+\u009dõå,Ì\u0010Ý\u0093¾ª--\u008dÇªß\u008e.È²\u008e\b\u0010ÿá\u00997\u0092ïóN\u0005©]Ëñ¸\u0003ë8?ÚÞ\u0087y\u009cî\u0093>Ý6®*¨ç\u0081ÿ\u001fszÎ\u0082ü\u008cïKY ¼Ñ!\u0098\u0005Q\u00ad¹T\u00862Ãf\u008aS\u0091$RT\u0002gI§w\u0094¸I%\u0010N}=·ÔÊ\u0004ò{p\u001b\u000ee\\uÑ\u0010\u0083(\u008c\u008b\u00adQ+Uå\u008f.\u001f\u008b\fA¥\u0018þe\u0005o&úýlåÎÕ\u001a,öÝ\t\u0089ûL¢5L\rô\u0010Ã\u007fò\u0093Í\u0089}ï\u008aJ\nË\u0091QÑu\u0018\u0012\u008cËá¼\u008c«\u0088cbêèfç\u0095Ý\u001fõrì Á\u009d\"\u00103Ýq\u0006.W\u008dDNkõ\u0081-\u0012#V\u0010\"t$3n¡¤m«ä\u0005\u0014ùçzë\u0010\u009e\u008cð\u0000Q$ø£\u0093Q\u0013Ðä½\u0014\u0085\u0018ÃZ\u008c[£æ\f\"ÏÖkOh\u0006£+ü\u0003.\u0011=áðÖ .ø\u0081f\u008d@(eÜåìg)Ì\u00156\u000fjÀ+\u0089U7ëàøÎ\u009e³j»É\u0010ÔÜSÜæ¢\u0084\b\nú¯\fÍ\u009b\u001fP\u0010ëçî\u0086áø»\u0015ÏA@ÒcÐö\u001f R\u0004zdaf\"Å`I¢lFyöÑwcàw¨b'ÑXKÙ;´Xãm\u0010\u0004\u008aF½ç¥+ªMø¢½Ç5?Î\u0010egy\u008b\u0088Ä3Gd\tÃ.®1û1\u0010µVl1þ¹1;\u0083~p.ÀÖæ½"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = a(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     n = var20;
                     o = new String[23];
                     s = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(29624097687063L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[14];
                     String var4 = "ìÏ('\u0012ÔWÿ°s÷+Ä³Ék\u0007V4{\u0096|´\t\tî]%gãlN?A\u0094¾u1ã\u0096Þh³Ò&ÔÏÄ5\f!\u0085\u009e\"ò\u000eÅË¿~ß\u008añ½êM/-¬½Õ\u0096c!)\u009f\u001f+}Zßàe<b[\u0011\u001dx\u0014×z>\u000eóM";
                     int var5 = "ìÏ('\u0012ÔWÿ°s÷+Ä³Ék\u0007V4{\u0096|´\t\tî]%gãlN?A\u0094¾u1ã\u0096Þh³Ò&ÔÏÄ5\f!\u0085\u009e\"ò\u000eÅË¿~ß\u008añ½êM/-¬½Õ\u0096c!)\u009f\u001f+}Zßàe<b[\u0011\u001dx\u0014×z>\u000eóM"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    q = var6;
                                    r = new Integer[14];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "-\u0093í-\u0087·\u0081«\u0015â\u0003¥ù\u0097H$";
                                 var5 = "-\u0093í-\u0087·\u0081«\u0015â\u0003¥ù\u0097H$".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "a:dµ\u001d@\u008aÙ|,¥Ø§,\u0093n\u0018Òë\u0017v\u009eÀu\u0010úü_\u0013\"¿\u0005\u0002gWjn« ou";
                  var19 = "a:dµ\u001d@\u008aÙ|,¥Ø§,\u0093n\u0018Òë\u0017v\u009eÀu\u0010úü_\u0013\"¿\u0005\u0002gWjn« ou".length();
                  var16 = 24;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static IllegalStateException a(IllegalStateException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8431;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cX", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cX_C0157",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25094;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cX", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cX_C0157",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = u[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = t[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 31;
            yield var15;
         }
         case 1 -> {
            byte var16 = 5;
            yield var16;
         }
         case 2 -> {
            byte var17 = 41;
            yield var17;
         }
         case 3 -> {
            byte var18 = 6;
            yield var18;
         }
         case 4 -> {
            byte var19 = 38;
            yield var19;
         }
         case 5 -> {
            byte var20 = 49;
            yield var20;
         }
         case 6 -> {
            byte var21 = 62;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 20;
            yield var23;
         }
         case 9 -> {
            byte var24 = 39;
            yield var24;
         }
         case 10 -> {
            byte var25 = 40;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 43;
            yield var27;
         }
         case 13 -> {
            byte var28 = 8;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 28;
            yield var30;
         }
         case 16 -> {
            byte var31 = 15;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 58;
            yield var35;
         }
         case 21 -> {
            byte var36 = 22;
            yield var36;
         }
         case 22 -> {
            byte var37 = 23;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 34;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 9;
            yield var42;
         }
         case 28 -> {
            byte var43 = 55;
            yield var43;
         }
         case 29 -> {
            byte var44 = 54;
            yield var44;
         }
         case 30 -> {
            byte var45 = 63;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 50;
            yield var47;
         }
         case 33 -> {
            byte var48 = 37;
            yield var48;
         }
         case 34 -> {
            byte var49 = 46;
            yield var49;
         }
         case 35 -> {
            byte var50 = 16;
            yield var50;
         }
         case 36 -> {
            byte var51 = 10;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 24;
            yield var53;
         }
         case 39 -> {
            byte var54 = 12;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 53;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 32;
            yield var58;
         }
         case 44 -> {
            byte var59 = 26;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 27;
            yield var61;
         }
         case 47 -> {
            byte var62 = 7;
            yield var62;
         }
         case 48 -> {
            byte var63 = 19;
            yield var63;
         }
         case 49 -> {
            byte var64 = 61;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 52;
            yield var66;
         }
         case 52 -> {
            byte var67 = 60;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 29;
            yield var69;
         }
         case 55 -> {
            byte var70 = 30;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 25;
            yield var72;
         }
         case 58 -> {
            byte var73 = 51;
            yield var73;
         }
         case 59 -> {
            byte var74 = 0;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 35;
            yield var76;
         }
         case 62 -> {
            byte var77 = 42;
            yield var77;
         }
         default -> 59;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            u[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      t[0] = "D|oZa*R|j\u0000r=E7i\u0006~)Tp~\u001159x";
      t[1] = "r?\u001fi\u0000xy0\u000e&gxt;\u000eiBGl?\u001dmkl{;\u0019|G{v";
      t[2] = "+EX|vM JI3\u000bU3M@z";
      t[3] = int.class;
      u[3] = "java/lang/Integer";
      t[4] = "5\nO+UQ5\nXwY^/AXiYK(0\f=\u0000\u000f";
      t[5] = "\u0017\u0017dX})\u0017\u0017s\u0004q&\r\\s\u001aq3\n-'D\"u]\u0011|\u0017c3&E(A$";
      t[6] = "\u0015Y\u0000#~\u0011\u0015Y\u0017\u007fr\u001e\u000f\u0012\u0017ar\u000b\bcB5\"N";
      t[7] = ";6r6<S;6ej0\\!}et0I&\f3+c\u000b";
      t[8] = "\u001f{\u0014GF\n\u001f{\u0003\u001bJ\u0005\u00050\u0003\u0005J\u0010\u0002AW[\u0019VU}\f\bX\u0010.)R[\u001d";
      t[9] = "V\u0000\u001131_V\u0000\u0006o=PLK\u0006q=EK:S%d\u0006\u001c\u0006\t|/EgS]%o";
      t[10] = "m\bEt#\u001cf\u0007T;B\u0012m\fPa";
      t[11] = "\u0003\u001a+ac\t\u0003\u001a<=o\u0006\u0019Q<#o\u0013\u001e hv<T";
      t[12] = boolean.class;
      u[12] = "java/lang/Boolean";
      t[13] = "E\u0002Z4zcE\u0002Mhvl_IMvvyX8\u001b)!9";
      t[14] = "\u0010T\u001d)R\u001d\u0010T\nu^\u0012\n\u001f\nk^\u0007\rn[0\u0006@";
      t[15] = "0xa-.\u00150xvq\"\u001a*3vo\"\u000f-B\"2wI";
      t[16] = "SqdM7\rSqs\u0011;\u0002I:s\u000f;\u0017NK'ThW";
      t[17] = "'SW}K\u00119[M2\u0016\u0010?W@qK79@D}\b";
      t[18] = "'\u00110\u001bHc9\u0019*T*\u007f>\u0004";
      t[19] = "\\q\u001bAGqJq\u001e\u001bTf]:\u001d\u001dXrL}\n\n\u0013`}";
      t[20] = "'\tD^O\n'\tS\u0002C\u0005=BS\u001cC\u0010:3\u0005C\u0013T";
      t[21] = "\\%_=AjB-Er\"~F";
      t[22] = "\u0018Fid,3mfbk=|\fhi`9&x";
      t[23] = void.class;
      u[23] = "java/lang/Void";
      t[24] = ")]QjQV)]F6]Y3\u0016F(]L4g\u0014}\n\t";
      t[25] = "Cty\u0010wQ]|c_\nA]";
      t[26] = "aM((traM?tx}{\u0006?jxh|wk3(+";
      t[27] = "7\u000e)\u000182)\u00063Np23\f+\ty)s)*\u000eu34\u00001";
      t[28] = "CrU8S1]zOw\u001b1GpW0\u0012*\u0007PL7\u000e1DvQ";
      t[29] = "\\[7av7\\[ =z8F\u0010 #z-Aauw#n";
      t[30] = "?{\u0006C\u0019^?{\u0011\u001f\u0015Q%0\u0011\u0001\u0015D\"AGYL\u0002";
      t[31] = "\u0003r&$\u00043\u0003r1x\b<\u001991f\b)\u001eHc3\\c";
      t[32] = "p\u0015K(VGn\u001dQg7Bn\u001dR'\u0019^";
      t[33] = "V^qK?\u0016V^f\u00173\u0019L\u0015f\t3\fKd7\\eJ";
      t[34] = " x&4J_ x1hFP:31vFE=Ba*\u0014\u0007";
      t[35] = "1w\u0017F\u0004\u00001w\u0000\u001a\b\u000f+<\u0000\u0004\b\u001a,MPY[]";
      t[36] = float.class;
      u[36] = "java/lang/Float";
      t[37] = "/\u0004\u0012h\u0014s/\u0004\u00054\u0018|5O\u0005*\u0018i2>Pq@,";
      t[38] = "@\u0017G8SxV\u0017Bb@oA\\AdL{P\u001bVs\u0007B";
      t[39] = "\u0002\nAf9Aw*Ji(\u000e\u0016$Ab,Tb";
      t[40] = "\b\u000e\u0001/|\u007f\b\u000e\u0016spp\u0012E\u0016mpe\u00154C0#$";
      t[41] = "\u0006GIFa\u0003\u0018OS\t\u0006\u0002\tT^S \u0004";
      t[42] = "Iva(B`IvvtNoS=vjNzTL&7\u001f";
      t[43] = "\u000b0\u0013pK0\u000b0\u0004,G?\u0011{\u00042G*\u0016\nQm\u001e";
      t[44] = "aYi\u0011'\u0006aY~M+\t{\u0012~S+\u001c|c/\u0007}[";
      t[45] = "!*ek\u001517*`1\u0006& ac7\n21&t A\u0005";
      t[46] = "<&*2+VI\u0006!=:\u0019(\b*6>C\\";
      t[47] = "J'\"I/\u001aJ'5\u0015#\u0015Pl5\u000b#\u0000W\u001d`WsD";
      t[48] = "\u0010x/0\u0014<\u0010x8l\u00183\n38r\u0018&\rBh.Jb";
      t[49] = "O\b\u0011?\u000fhO\b\u0006c\u0003gUC\u0006}\u0003rR2S!S7";
      t[50] = "=[\u0004^f\u0019=[\u0013\u0002j\u0016'\u0010\u0013\u001cj\u0003 aEE8I";
      t[51] = "\u0003p\u0017\u000edz\u001dx\rA\t`\u0005}\u0004\f>f\u0006\u007f";
      t[52] = "f \u00104\u001e\u0018p \u0015n\r\u000fgk\u0016h\u0001\u001bv,\u0001\u007fJ>";
      t[53] = "h}\",M^\u001d])#\\\u0011|S\"(XK\b";
      t[54] = "0bw8\u0002X.jmwcO0fb-_";
      t[55] = "\u0006207Tn\u0018:*x\u001cn\u000202?\u0015uB\u000343\u001er\u000f223";
      t[56] = "#.\u0013k\u0007`=&\t$O`',\u0011cF{g\u001b\nCGa\u000f:\u000bi]|&!";
      t[57] = "ENC9ouENTecz_\u0005T{coXt\u0000\"3,\u000fH[vqot\u001d\u000f%5";
      t[58] = "y3.y\u0018#|k(%!uxn0\u0017\u001a%%\u000b.#\u001aw i-2Da\u001f";
      t[59] = "E)uPqXU2, #)\u0013 p]#XVw=\u001eJ\u0010Ct0I;U\u00149s ";
      t[60] = "\u001dg+an7C\u007f{o\u000e'MnvMi+I\u0015,d~.]iskb*$";
      t[61] = "\u0003q;B\u0013t\u001ce3Kce\u001ci%{X5G\f>\u001c\u0018o\u000bj`A\f?{";
      t[62] = "PIV$?\u0004\b\u001eG9l~\u0000\nE2r7\u00123[*\u0003A\u0005\u0015E<b\u0001\n\u0011SV9\u001c\u0019\u001bD*f\u0013\u0005\u001f=";
      t[63] = "_kP\u0005h\u007f@\u007fX\f\u0018n@sN<#>\u001a\u0016]\u0015!aLuN[j{'";
      t[64] = "v:HKdn2t\u000e\u0016\u0005p w\u0010AiBq5@\u001f:\u0015vq\u0001\u0018ak0{\u0016B\u0005";
      t[65] = "\u0003|jo\tq\u0011w{`i&z4<9\u0016%\u00024i<\u0005,zwuz\f0\u0015|n>VO";
      t[66] = "6$\u001b\tk8tuEZZ?kv\u001a\u000f\rj4#ERZl4k\u0011\u0013;i2wB";
      t[67] = "\u000f/\u0005P\f^\u001caNJg\\\u0018<F]\u001bZ\u001eQGDVX\u00000\u0007K\fSd";
      t[68] = "+\u0006^\u0011qPiW\u0000B@WvT_\u0017\u0017\u0002)\u0001\u0007D@\u0004)IT\u000b!\u0001/U\u0007";
      t[69] = "\u0000pqG_iFzf\u001d;rVv`\u001eW@\u00074?G\u0001\u0017\u00064p\u0016Kv\u00032lE;*Gjn\u0019JfVl=y";
      t[70] = "\u001b\b_9j\rYY\u0001j[\nFZ^?\f_\u0019\u000f\u0007m[Y\u0019GU#:\\\u001f[\u0006";
      t[71] = "|\u0018]hvf<\u0017\u0007c\u0012aj\u0018\u0010\r-k`\u0010\u0006lmdd\u0006l";
      t[72] = "\u0001\u0016hF\t\n\u0005Nn\u000fq\u0011XB| JF\u000e';\u001b\u0016\u0002UF{\u0014\u0012\u0014?";
      t[73] = "{@OYeq0R@S\u0001$*D\u001a\u0004Vvr\u0013CP\u0001wuY\u0011\u0018`rsEB";
      t[74] = "XIk\u000b\u001fx\u001a\u00185X.\u007f\u0005\u001bj\ry*ZN1].,Z\u0006a\u0011O)\\\u001a2";
      t[75] = "O$-@ \u001f\rus\u0013\u0011\u0018\u0012v,FFMM#u\u0012\u0011KMk'ZpNKwt";
      t[76] = "b\u000b\u0000_]\\ Z^\fl[?Y\u0001Y;\u000e`\fZ\rl\b`D\nE\r\rfXY";
      t[77] = "K?i\u007fZ?\tn7,k8\u0016mhy<mI80)kkIpce\nnOl0";
      t[78] = "w\u001aE(<\u001e5K\u001b{\r\u0019*HD.ZLu\u001d\u001es\rJuUO2lOsI\u001c";
      t[79] = "\u001eP9\u0007Y=\\\u0001gTh:C\u00028\u0001?o\u001cWaRhi\u001c\u001f3\u001d\tl\u001a\u0003`";
      t[80] = "\u00003\u000e\u0014T3^+^\u001a4.@<Z\u0017OC\u0006-T\u000b^\"F\"P\u001d4s_1\f\u0017\n/Gq\u0003s";
      t[81] = "7-R(oJu|\f{^Mj\u007fS.\t\u00185*\u000b|^\u001e5bX2?\u001b3~\u000b";
      t[82] = "j:\u007f?D\u0018~=~!%\fz~f;I>'?7c%\u0014jll\"\u0019U{~x\\";
      t[83] = "o\u001b+LlB-Ju\u001f]E2I*J\n\u0010m\u001cs\u001b]\u0016mT!V<\u0013kHr";
      t[84] = "t!7A4'50%UJpn9!|t&2\\cI:rp <F&v\t";
      t[85] = "RW+|\u0010'\u0010\u0006u/! \u000f\u0005*zvuPPr'!sP\u0018!f@vV\u0004r";
      t[86] = "c/\u001b(O'=r\u000fx?*gz\u0018\u001e\u0004}1\u001f_%X9j~\u001f*\\/\u0000";
      t[87] = "\u007f^\u000eE9EwY\rB\u0004D/XQTS\u0010s\t\f\u0003\u0004\u0017pEZHe\u0012vY\t";
      t[88] = "\byW}\u0015b\u0000~Tz(f^w\u0014W\u00115\u0000)li\u0011jC\"\u000e8V2P\u0012";
      t[89] = "\u001bkb\u0005\u001d!\u001c2k\u000eb+e3>\\\u001d(\u001d3kY\u000e!euxY\u0018$\u0006x>Z\u001eB";
      t[90] = "\u0016a$\u0001\u00002\u001d0?^a1\u001f\";\u0003\r\u0003IfjTZT\u0019 b\u0000\n7\nn)\u001aa";
      t[91] = "x3\u0011lkv`=\u0016 S{e0K<\u0004,:m\u0010P.-}>N!:*| ";
      t[92] = "<\u0019\u001d;\u0003>/WV!h2:\u001b$e\n->\u001eX:\u00051:g\u001b3\u000f%=\u0006[<\u000b3W";
      t[93] = "[<\u000bE%u\u00012\u001c\u001dG~]8\u0001\u0012\u0010)\u0007j_EG*^%\f\u0007;uQ9\b";
      t[94] = "R_I\u0013\u0005\u0005YLNSy\\VA\u0013O\u0015n\u0007\u0000N\u0014G9Q[IT\t\u0007ET\u000fRy";
      t[95] = "\u001e\u0012\u0000\u001c;\u0000\u0016\u0015\u0003\u001b\u0006\u0001N\u0014_\rQU\u0012E\u0002[\u0006R\u0011\tT\u0011gW\u0017\u0015\u0007";
      t[96] = "8f$D+[+(o^@S4`lg.8!jlM>\u0000>v{]@S-!yK#@cjc ";
      t[97] = "3Gjg&8q\u001644\u0017?n\u0015ka@j1@03\u0017l1\b`}vi7\u00143";
      t[98] = "\u0000O'\u001bo#\u0004Kh\r\u0013c\fbv\u001ao\u001f\u0000X.\u0005x|\u0013\u0016e\u001f\u0013";
      t[99] = "B\u007fGk-yN8\u0007dL+J~w2 #_h\u0016r/'I\u0002";
      t[100] = "\fSFV6#VGSYJ\"\u0005]_[&\u0010S\u0019\u000e\u0003rG\f\u001e@Y+!\u0007O[\u0006J";
      t[101] = "Md\u007f;uj\u0017jhc\u0017aK`ul@5\u001b5/<\u0017wGt}>.eRl+";
      t[102] = "\u007f\"5O+-=sk\u001c\u001a*\"p4IM\u007f}%o\u001a\u001ay}m?U{|{ql";
      t[103] = "\u0018\u001bPp)7\u0004L^<D%t\u0011B=-6\bNM!)O";
      t[104] = "\u0007\u00130;\\p\u0003\u0017\u007f- \"\u000b\u0000M(K,l\u0018q|X/\u001c\u001co#\u001bL\u0003@<<\\+\u0015\u0011~1 ";
      t[105] = "D\u0018*)P\u0007\u0006Itza\u0000\u0019J+/6UF\u001fp~aSFW 3\u0000V@Ks";
      t[106] = "@\u0002>}\f\u0003\u0014C<{<\u0000LU5wkT\u0010\u0000l#<S\u0013H>k]V\u0015Tm";
      t[107] = "\u0006\u001eA#\u001d)DO\u001fp,.[L@%{{\u0004\u0019\u001br,}\u0004QK9Mx\u0002M\u0018";
      t[108] = "N:(+f\u0005\u0010g<{\u0016\u0006@v3-z4\u00112iq.cHwc,w^D0##\u0016";
      t[109] = "hvK$\t\blr\u00042uQjg{<H\u0005``A=\u0016\t=\u001f\u00107EN\u007f#\u00143\nX\u0003";
      t[110] = "1n\u000f?9+)`\bs\u0001- |Qdm\u001ft=\f:\u00014#>\r;b,-9A\u0003";
      t[111] = "qUOd?(3\u0004\u00117\u000e/,\u0007NbYzsR\u0016>\u000e|s\u001aE~oyu\u0006\u0016";
      t[112] = "\u0013q\u0003g\u0011\bFd\u0017d,\n\u0013uj:@\u0002\u0006c\u000bzO\u0006\u0010\tUiK\u001d\u0014h\u0015fO\u000b~";
      t[113] = "\u000b\u0018l&F\u0001\u001b\u00035V\u0014p]Ak)\u0017\b]\u0014n:\u001ep\u000bBh+\u0001\u0017\u001d\u0013*&}";
      t[114] = "b\u001f\b0t6\"\u0010R;\u00107p\u0014\u007f8`+\u0019__%/3'\u0003Ge W";
      t[115] = "\b'\u001e8*\u007f\u0000 \u001d?\u0017~X!A)@*\u0004p\u001cy\u0017-\u0007<J5v(\u0001 \u0019";
      t[116] = "f_\u0005\\1\u000erX\u0004BP\u001av\u001b\u001cX<( ^B\u0007o\u007f!\u0005\fV)\u0003~\n\u0010RP";
      t[117] = "[274}2\u0019cigL5\u0006`62\u001b`Y5obLfY}=.-c_an";
      t[118] = "(Rg\u0006~{/Te\u00065Bz\u000ex\u000f\u0018y)U\u001dNt)cUg\u0016#8~\u0006\u001d";
      t[119] = "] #|U7\u001fq}/d0\u0000r\"z3e_'y/dc_o)f\u0005fYsz";
      t[120] = "N\u0000\u0012;E\u0006\fQLht\u0001\u0013R\u0013=#TL\u0007KktRLO\u0018!\u0015WJSK";
      t[121] = "an\r\u007f>\u0016ejBiBDnnA@+R\ne\u00004!U0d^8|*an\r\u007f>\u0016ejBiB";
      t[122] = "[`^\u00128C\u000e|Q\u0011A]YzA\u001f-o\u000e6\u001dDz8TtD\u00073S\u000bmCEA";
      t[123] = "(\u000e\u0016FOsc\u001c\u0019L+&y\nC\u001b|t!]\u001bJ+u&\u0017H\u0007Jp \u000b\u001b";
      t[124] = "%T\rK;\u00035PZ\u0010\u0005Y)\u0014\u0000NikxTZ\u0010=</\u0016YMn_<X\u0012W\u0005^yY\u0003V?_'U^)5Z4W\u0004\u0017iBtX`B{\u0005 \u0003\u0003Q5N:h";
      t[125] = "N\\U\\-b\f\r\u000b\u000f\u001ce\u0013\u000eTZK0L[\f\u000f\u001c6L\u0013_F}3J\u000f\f";
      t[126] = "&-w\u0019B\u0001\"u0\u001eE>eyrZIDrRlAnC{p\u000b\u0018DYg~jXK]q\u00144KOFuutDKP\u001f";
      t[127] = "rFClR*fI\u0005j\"\u007f\u007fE\u0001G\u001b,!\u001cy}Z}z\u001d\u0014(Oiy ";
      t[128] = "\u0005\u001dCB2\u0002_\u0013T\u001aP\t\u0003\u0019I\u0015\u0007]SL\u0013BP\f\u001cMI\u00123\u001fR\u0006S";
      t[129] = "PS\u00008x\u0016\u0012\u0002^kI\u0011\r\u0001\u0001>\u001eDRTYjIBR\u001c\n\"(GT\u0000Y";
      t[130] = "hiISc\\$xO\u0000\u0003H8iIZozi+\u0016\u0001<-h+YRsLm-E\u0001\u0003\u0013dy\u0018Es\u0017<\u007fQ=";
      t[131] = ".}L\u001a\u0001\u001a=3\u0007\u0000j\u0010)ouA\u0006\u001e=i\u0014\u0001\t\u001a+\u0003E\u0018\u001aF!=\u0019\u0000ZIE";
      t[132] = "d.uM*Mw`>WAIaP'WxJd34\u00193P\u000f";
      t[133] = "^la\u0016&\u0019\u0000t1\u0018F\u0017\u000ez!\u001c\u0001\u0007g!0\u0016>\u0003\u0006a?\u0012(i^la\u0016&\u0019\u0000t1\u0018F";
      t[134] = "\u0006Vw6a\u0016\u0015\u0018<,\n\u000e\u0011R#;ou\u0006A~(vI\u0002E1>\n";
      t[135] = "+\u0001\u001dpEh.Y\u001b,|>*\\\u0003\u001eGnv9\u000b+\u0010$7Y\u00010\u00123M";
      t[136] = "\u001d[%\f\u000e._\n{_?)@\t$\nh|\u001f\\\u007f\\?z\u001f\u0014/\u0016^\u007f\u0019\b|";
      t[137] = "y])|\u0000|&D.>rleU!j\u0017\u0017rF|y\u000e+vB3or";
      t[138] = "Jb7O\u0007o\u0002l!\u001c85Vs>FT\u0007\u00003o\u0010\bP\u0001m.HA,^b2L8!Vf0\u001e\u0007iXpc!";
      t[139] = "=;;H+\u0007wa3\rT\u0013\"\u007f#\u00178!t2{Khvua3\u0019-\n*n/\u001dTL-s*\t(\u0013\"o.p&N7;<\u0001l\u0014?~C";
      t[140] = "P.\u0011OVwT*^Y*%Z#]XPK\u0002}GDW*\u0001'KW\u0010KP.\u0011OVwT*^Y*";
      t[141] = "gs{-4V%\"%~\u0005Q:!z+R\u0004et\"|\u0005\u0002e<q7d\u0007c \"";
      t[142] = "kB3Y\u001c\u000f\"\u00078\b\u0002v;zn\u000fZ\t8\u0002nZ_\u001a1zmT\u0015\u001f+\u00062[\t\u001bR";
      t[143] = "#8C\u0003u\u001a0v\b\u0019\u001e\u0017/<7\u000eu\u0019H$\u000bZf\u001a8 \u0015\u0005%y'|F\u001ab\u001e1-\u0004\u0017\u001e";
      t[144] = "#?\\.Owv*H-rb3;5s\u001e}6-T3\u0011y G\n \u0015b$&J/\u0011tNxY+\np/8V/\u001c\u001a";
      t[145] = "5#\t\u0014dxddQ\u0007T\u007f1f\u000e\t8Me V_d\u001a3|\u0011\u0004-af`\u001e\u0007T";
      t[146] = "]\u0012Oj\u0015E\u001fC\u00119$B\u0000@Nls\u0010\\\u0013\u0014<$\u0011_]EpE\u0014YA\u0016";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = t[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(u[var4]);
            t[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = t[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            t[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  t[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(749529981853215L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = t[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  t[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(749529981853215L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        t[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(749529981853215L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 36;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 122;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 230;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 194;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 108;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 241;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 36;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 122;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 230;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cX_C0157",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cX_C0157",
                     "lambda$getRegistry$0",
                     "(Lnet/minecraft/registry/entry/RegistryEntry;)Ljava/util/List;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/registry/entry/RegistryEntry;)Ljava/util/List;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding2(Map var0, Map var1) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/util/Map;Ljava/util/Map;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cX_C0157",
                     "lambda$getRegistry$2",
                     "(Ljava/util/Map;Ljava/util/Map;Lnet/minecraft/registry/entry/RegistryEntry;)V"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/registry/entry/RegistryEntry;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var3.invokeExact((Map)var0, (Map)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Function invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 9, "net/minecraft/registry/entry/RegistryEntryList", "stream", "()Ljava/util/stream/Stream;"),
                  SourceSupport.methodType("(Lnet/minecraft/registry/entry/RegistryEntryList;)Ljava/util/stream/Stream;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 9, "net/minecraft/registry/entry/RegistryEntry", "value", "()Ljava/lang/Object;"),
                  SourceSupport.methodType(
                     "(Lnet/minecraft/registry/entry/RegistryEntry;)Lnet/minecraft/world/gen/feature/PlacedFeature;", MethodHandles.lookup()
                  )
               )
               .dynamicInvoker();
         }

         return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding5(Map var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ljava/util/Map;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 9, "java/util/Map", "containsKey", "(Ljava/lang/Object;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/world/gen/feature/PlacedFeature;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Map)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Consumer invokeBinding6(Map var0, RegistryEntry var1, Map var2) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ljava/util/Map;Lnet/minecraft/registry/entry/RegistryEntry;Ljava/util/Map;)Ljava/util/function/Consumer;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cX_C0157",
                     "lambda$getRegistry$1",
                     "(Ljava/util/Map;Lnet/minecraft/registry/entry/RegistryEntry;Ljava/util/Map;Lnet/minecraft/world/gen/feature/PlacedFeature;)V"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/world/gen/feature/PlacedFeature;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var4.invokeExact((Map)var0, (RegistryEntry)var1, (Map)var2);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
