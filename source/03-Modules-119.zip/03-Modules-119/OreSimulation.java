package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.BlockStateUpdateEvent;
import dev.zprestige.prestige.api.events.WorldChunkEvent;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.util.LoadedChunkIterator;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.client.modules.state.OreFeatureData;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.client.modules.state.DimensionChunkKey;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.api.setting.StringSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.structure.rule.RuleTest;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.BlockPos.Mutable;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.util.math.random.ChunkRandom;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.math.random.ChunkRandom.RandomProvider;
import net.minecraft.world.Heightmap.Type;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.ReadableContainer;
import net.minecraft.world.gen.HeightContext;
import net.minecraft.world.gen.feature.OreFeatureConfig.Target;
import net.minecraft.world.gen.heightprovider.HeightProvider;

public class OreSimulation extends Module {
   private MultiModeSetting a;
   private StringSetting c;
   private IntSetting d;
   public Map e = new ConcurrentHashMap();
   private long f;
   private boolean i;
   private Map g;
   private RegistryKey h;
   private ClientWorld j;
   private Frustum k;
   private static final long l = 131118579493320L;
   private static final String[] m;
   private static final String[] n;
   private static final Map o = new HashMap(13);
   private static final long[] p;
   private static final Integer[] q;
   private static final Map r;
   private static final long[] s;
   private static final Long[] t;
   private static final Map u;
   private static final Object[] v = new Object[228];
   private static final String[] w = new String[228];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 99840653408854L ^ 6199080688598L;
      var10001 = 99840653408854L ^ 81305300543076L;
      int var8 = Event.bReturningInt();
      MinecraftClient var14 = b;
      ClientPlayerEntity var39 = var14.player;
      if (var39 != null) {
         int var41 = var8;
         byte var40 = ((byte)((this.i) ? 1 : 0));
         byte var36 = var40;
         byte var34 = var40;
         if (var41 == 0) {
            byte var42 = var34;
            byte var35 = var42;
            byte var43 = var35;
            if (var43 == 0) {
               return;
            }

            Object[] var18 = new Object[]{21164174908466L};
            OreSimulation var17 = this;
            byte var44 = ((byte)((var17.dReturningBoolean(var18)) ? 1 : 0));
            var36 = var44;
         }

         int var46 = var8;
         byte var45 = var36;
         int var38 = var45;
         byte var37 = var45;
         if (var46 == 0) {
            byte var47 = var37;
            if (var47 == 0) {
               return;
            }

            MinecraftClient var21 = b;
            ClientPlayerEntity var22 = var21.player;
            ChunkPos var23 = var22.getChunkPos();
            var38 = var23.x;
         }

         int var9 = var38;
         MinecraftClient var24 = b;
         ClientPlayerEntity var25 = var24.player;
         ChunkPos var26 = var25.getChunkPos();
         int var10 = var26.z;
         IntSetting var27 = this.d;
         Integer var28 = (Integer)var27.aReturningObject();
         int var11 = var28;
         int var58;
         do {
            int var49 = var11;
            int var48 = var12;
            if (var48 > var49) {
               break;
            }

            int var13 = -var12 + var9;

            while (true) {
               int var51 = var12 + var9;
               int var50 = var13;
               if (var50 <= var51) {
                  int var10003 = var10 + var12 - var11;
                  Object[] var10006 = new Object[]{null, null, null, 104928746840448L};
                  var10006[2] = var10003;
                  var10006[1] = var13;
                  var10006[0] = var1;
                  Object[] var30 = var10006;
                  OreSimulation var29 = this;
                  var29.jReturningVoid(var30);
                  var13++;
                  int var52 = var8;
                  if (var52 != 0) {
                     break;
                  }

                  int var53 = var8;
                  if (var53 == 0) {
                     continue;
                  }
               }

               var13 = -var12 + 1 + var9;
               break;
            }

            while (true) {
               int var55 = var12 + var9;
               int var54 = var13;
               if (var54 < var55) {
                  int var60 = var10 - var12 + var11 + 1;
                  Object[] var61 = new Object[]{null, null, null, 104928746840448L};
                  var61[2] = var60;
                  var61[1] = var13;
                  var61[0] = var1;
                  Object[] var33 = var61;
                  OreSimulation var32 = this;
                  var32.jReturningVoid(var33);
                  var13++;
                  int var56 = var8;
                  if (var56 != 0) {
                     break;
                  }

                  int var57 = var8;
                  if (var57 == 0) {
                     continue;
                  }
               }

               var12++;
               break;
            }

            var58 = var8;
         } while (var58 == 0);
      }
   }

   private void jReturningVoid(Object[] var1) {
      Render3DEvent var2;
      int var3;
      int var6;
      long var7;
      long var9;
      int var11;
      label61: {
         var2 = (Render3DEvent)var1[0];
         var6 = (Integer)var1[1];
         var3 = (Integer)var1[2];
         long var4 = (Long)var1[3];
         var4 = 131118579493320L ^ var4;
         var7 = var4 ^ 79524704393292L;
         var9 = var4 ^ 115262865691174L;
         var11 = Event.bReturningInt();
         int var65 = var11;
         Frustum var64 = this.k;
         Frustum var57 = var64;
         Frustum var56 = var64;
         if (var65 == 0) {
            Frustum var66 = var56;
            if (var66 == null) {
               break label61;
            }

            Frustum var67 = this.k;
            var57 = var67;
         }

         double var10003 = var6 << 4;
         double var10005 = var3 << 4;
         int var10006 = var6 << 4;
         short var10007 = 7628;
         long var10008 = 7364235979714704901L ^ var4;
         double var89 = var10006 + 16;
         int var92 = var3 << 4;
         short var10009 = 7628;
         long var10010 = 7364235979714704901L ^ var4;
         Box var22 = new Box(var10003, -64.0, var10005, var89, 320.0, var92 + 16);
         Frustum var21 = var57;
         boolean var68 = var21.isVisible(var22);
         if (!var68) {
            return;
         }
      }

      MinecraftClient var24 = b;
      ClientWorld var12 = var24.world;
      ClientWorld var69 = var12;
      if (var69 != null) {
         ClientWorld var26 = var12;
         RegistryKey var10002 = var26.getRegistryKey();
         int var28 = var3;
         int var27 = var6;
         DimensionChunkKey var13 = new DimensionChunkKey(var10002, ChunkPos.toLong(var27, var28));
         int var72 = var11;
         DimensionChunkKey var71 = var13;
         Map var70 = this.e;
         Map var60 = var70;
         DimensionChunkKey var61 = var71;
         Map var58 = var70;
         DimensionChunkKey var59 = var71;
         if (var72 == 0) {
            DimensionChunkKey var30 = var59;
            Map var29 = var58;
            boolean var73 = var29.containsKey(var30);
            if (!var73) {
               return;
            }

            DimensionChunkKey var75 = var13;
            Map var74 = this.e;
            var60 = var74;
            var61 = var75;
         }

         DimensionChunkKey var34 = var61;
         Map var33 = var60;
         Map var14 = (Map)var33.get(var34);
         Map var35 = var14;
         Set var36 = var35.entrySet();
         Iterator var15 = var36.iterator();

         label48:
         while (true) {
            label65: {
               Iterator var37 = var15;
               boolean var76 = var37.hasNext();
               if (!var76) {
                  break;
               }

               Iterator var38 = var15;
               Entry var16 = (Entry)var38.next();
               int var78 = var11;
               MultiModeSetting var77 = this.a;
               Object var63 = var77;
               MultiModeSetting var62 = var77;
               if (var78 == 0) {
                  Entry var39 = var16;
                  Object[] var41 = new Object[]{((OreFeatureData)var39.getKey()).c, var9};
                  MultiModeSetting var40 = var62;
                  boolean var79 = var40.aReturningBoolean(var41);
                  if (!var79) {
                     break label65;
                  }

                  Entry var43 = var16;
                  Object var80 = var43.getValue();
                  var63 = var80;
               }

               Set var45 = (Set)var63;
               Iterator var17 = var45.iterator();

               int var83;
               do {
                  Iterator var46 = var17;
                  boolean var81 = var46.hasNext();
                  if (!var81) {
                     break;
                  }

                  Iterator var47 = var17;
                  Vec3d var18 = (Vec3d)var47.next();
                  RenderContext var10000 = var2.b;
                  MeshBufferManager var10001 = var2.a;
                  Vec3d var48 = var18;
                  float var86 = (float)var48.x;
                  Vec3d var49 = var18;
                  float var87 = (float)var49.y;
                  Vec3d var50 = var18;
                  float var10004 = (float)var50.z;
                  Vec3d var51 = var18;
                  float var88 = (float)(var51.x + 1.0);
                  Vec3d var52 = var18;
                  float var90 = (float)(var52.y + 1.0);
                  Vec3d var53 = var18;
                  float var91 = (float)(var53.z + 1.0);
                  Entry var54 = var16;
                  Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, ((OreFeatureData)var54.getKey()).k, var7};
                  var10011[7] = var91;
                  var10011[6] = var90;
                  var10011[5] = var88;
                  var10011[4] = var10004;
                  var10011[3] = var87;
                  var10011[2] = var86;
                  var10011[1] = var10001;
                  var10011[0] = var10000;
                  Object[] var55 = var10011;
                  ShapeRenderer.gReturningVoid(var55);
                  int var82 = var11;
                  if (var82 != 0) {
                     continue label48;
                  }

                  var83 = var11;
               } while (var83 == 0);
            }

            int var84 = var11;
            if (var84 != 0) {
               break;
            }
         }
      }
   }

   @EventListener
   public void a(FrustumEvent var1) {
      Object[] var5 = new Object[0];
      FrustumEvent var4 = var1;
      this.k = var4.aReturningVoid(var5);
   }

   @EventListener
   public void a(BlockStateUpdateEvent var1) {
      int var4 = Event.bReturningInt();
      Object[] var10 = new Object[0];
      BlockStateUpdateEvent var9 = var1;
      BlockState var11 = var9.aReturningBlockState(var10);
      boolean var33 = var11.isOpaque();
      if (!var33) {
         MinecraftClient var13 = b;
         ClientWorld var34 = var13.world;
         if (var34 != null) {
            MinecraftClient var15 = b;
            ClientWorld var16 = var15.world;
            RegistryKey var10002 = var16.getRegistryKey();
            Object[] var18 = new Object[0];
            BlockStateUpdateEvent var17 = var1;
            BlockPos var19 = var17.aReturningBlockPos(var18);
            DimensionChunkKey var5 = new DimensionChunkKey(var10002, ChunkPos.toLong(var19));
            DimensionChunkKey var21 = var5;
            Map var20 = this.e;
            boolean var35 = var20.containsKey(var21);
            if (var35) {
               Object[] var23 = new Object[0];
               BlockStateUpdateEvent var22 = var1;
               BlockPos var24 = var22.aReturningBlockPos(var23);
               Vec3d var6 = Vec3d.of((Vec3i)var24);
               DimensionChunkKey var26 = var5;
               Map var25 = this.e;
               Map var27 = (Map)var25.get(var26);
               Collection var28 = var27.values();
               Iterator var7 = var28.iterator();

               int var37;
               do {
                  Iterator var29 = var7;
                  boolean var36 = var29.hasNext();
                  if (!var36) {
                     break;
                  }

                  Iterator var30 = var7;
                  Set var8 = (Set)var30.next();
                  Vec3d var32 = var6;
                  Set var31 = var8;
                  var31.remove(var32);
                  var37 = var4;
               } while (var37 == 0);
            }
         }
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 97434553232679L;
      long var6 = var2 ^ 105724631269693L;
      int var8 = Event.bReturningInt();
      int var25 = var8;
      OreSimulation var24 = this;
      OreSimulation var23 = var24;
      OreSimulation var22 = var24;
      if (var25 == 0) {
         StringSetting var9 = var22.c;
         String var10 = (String)var9.aReturningObject();
         boolean var26 = var10.isEmpty();
         if (var26) {
            MinecraftClient var12 = b;
            ClientPlayerEntity var10000 = var12.player;
            short var10001 = 24460;
            long var10002 = 7947032269748703556L ^ var2;
            String var13 = "Please set a seed";
            Text var15 = Text.of(var13);
            ClientPlayerEntity var14 = var10000;
            var14.sendMessage(var15, false);
            Object[] var18 = new Object[]{var4};
            OreSimulation var17 = this;
            var17.aReturningVoid(var18);
            return;
         }

         var23 = this;
      }

      Object[] var21 = new Object[]{var6};
      OreSimulation var20 = var23;
      var20.lReturningVoid(var21);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Map var4 = this.e;
      var4.clear();
      this.g = null;
      this.h = null;
      this.j = null;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 131118579493320L ^ var2;
      long var4 = var2 ^ 22140349551105L;
      int var6 = Event.cReturningInt();
      MinecraftClient var9 = b;
      ClientPlayerEntity var17 = var9.player;
      if (var17 != null) {
         Object[] var11 = new Object[]{false};
         Iterable var12 = aReturningIterable(var11);
         Iterator var7 = var12.iterator();

         int var19;
         do {
            Iterator var13 = var7;
            boolean var18 = var13.hasNext();
            if (!var18) {
               break;
            }

            Iterator var14 = var7;
            Chunk var8 = (Chunk)var14.next();
            Object[] var16 = new Object[]{var8, var4};
            OreSimulation var15 = this;
            var15.mReturningVoid(var16);
            var19 = var6;
         } while (var19 != 0);
      }
   }

   public static Iterable aReturningIterable(Object[] var0) {
      boolean var1 = (Boolean)var0[0];
      return invokeBinding1(var1);
   }

   private void lReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 131118579493320L ^ var2;
      long var4 = var2 ^ 101215439417054L;
      long var6 = var2 ^ 50688286482872L;

      long var8;
      try {
         StringSetting var11 = this.c;
         String var12 = (String)var11.aReturningObject();
         String var13 = var12.toString();
         var8 = Long.parseLong(var13);
      } catch (NumberFormatException var20) {
         this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
         Map var14 = this.e;
         var14.clear();
         this.g = null;
         this.h = null;
         this.j = null;
         NotificationManager var10000 = Prestige.v;
         short var10001 = 30063;
         long var10002 = 5093432693124551504L ^ var2;
         short var22 = 4576;
         long var10003 = 2795895948749453274L ^ var2;
         short var23 = 32422;
         long var10004 = 4319939320597295839L ^ var2;
         Object[] var10007 = new Object[]{null, null, null, NotificationType.ERROR, var4};
         var10007[2] = 6000L;
         var10007[1] = "Invalid seed!";
         var10007[0] = "Ore Simulation";
         Object[] var16 = var10007;
         NotificationManager var15 = var10000;
         var15.aReturningVoid(var16);
         return;
      }

      this.f = var8;
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
      this.h = null;
      this.j = null;
      Object[] var18 = new Object[]{var6};
      OreSimulation var17 = this;
      var17.dReturningBoolean(var18);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 131118579493320L ^ var2;
      long var4 = var2 ^ 24891914390946L;
      long var6 = var2 ^ 5874095105710L;
      long var8 = var2 ^ 11527212263933L;
      long var10 = var2 ^ 31731422643119L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var16 = b;
      ClientWorld var13 = var16.world;
      int var12 = var10000;
      int var58 = var12;
      byte var57 = ((byte)((this.i) ? 1 : 0));
      byte var46 = var57;
      byte var43 = var57;
      if (var58 == 0) {
         byte var59 = var43;
         label71:
         if (var59 != 0) {
            int var61 = var12;
            ClientWorld var60 = var13;
            ClientWorld var47 = var60;
            ClientWorld var44 = var60;
            if (var61 == 0) {
               ClientWorld var62 = var44;
               ClientWorld var45 = var62;
               ClientWorld var63 = var45;
               if (var63 == null) {
                  break label71;
               }

               var47 = var13;
            }

            RegistryKey var14;
            Map var53;
            label61: {
               RegistryKey var52;
               label60: {
                  ClientWorld var20 = var47;
                  var14 = var20.getRegistryKey();
                  ClientWorld var65 = this.j;
                  ClientWorld var64 = var13;
                  if (var64 == var65) {
                     int var67 = var12;
                     RegistryKey var66 = var14;
                     var52 = var66;
                     RegistryKey var48 = var66;
                     if (var67 != 0) {
                        break label60;
                     }

                     RegistryKey var68 = var48;
                     RegistryKey var49 = var68;
                     RegistryKey var23 = this.h;
                     RegistryKey var22 = var49;
                     boolean var69 = var22.equals(var23);
                     if (var69) {
                        int var71 = var12;
                        Map var70 = this.g;
                        var53 = var70;
                        Map var50 = var70;
                        if (var71 != 0) {
                           break label61;
                        }

                        Map var72 = var50;
                        Map var51 = var72;
                        Map var73 = var51;
                        if (var73 != null) {
                           return true;
                        }
                     }
                  }

                  var52 = var14;
               }

               RegistryKey var28 = var52;
               Identifier var29 = var28.getValue();
               Object[] var30 = new Object[]{var29.getPath(), var8};
               var53 = OreFeatureData.aReturningMap(var30);
            }

            Map var15 = var53;
            int var74 = var12;
            if (var74 == 0) {
               Map var75 = var15;
               label47:
               if (var75 != null) {
                  Map var32 = var15;
                  byte var81 = ((byte)((var32.isEmpty()) ? 1 : 0));
                  int var77 = var12;
                  byte var76 = var81;
                  byte var56 = var76;
                  byte var54 = var76;
                  if (var77 == 0) {
                     byte var78 = var54;
                     byte var55 = var78;
                     byte var79 = var55;
                     if (var79 != 0) {
                        break label47;
                     }

                     this.g = var15;
                     this.h = var14;
                     this.j = var13;
                     Map var40 = this.e;
                     var40.clear();
                     Object[] var42 = new Object[]{var10};
                     OreSimulation var41 = this;
                     var41.kReturningVoid(var42);
                     var56 = 1;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var56);
               }

               NotificationManager var82 = Prestige.v;
               short var10001 = 15116;
               long var10002 = 6713638266130715970L ^ var2;
               short var83 = 11874;
               long var10003 = 916256553032564782L ^ var2;
               short var84 = 17755;
               long var10004 = 8812196476138963281L ^ var2;
               Object[] var10007 = new Object[]{null, null, null, NotificationType.ERROR, var6};
               var10007[2] = 6000L;
               var10007[1] = "No ores registered for this dimension";
               var10007[0] = "Ore Simulation";
               Object[] var36 = var10007;
               NotificationManager var35 = var82;
               var35.aReturningVoid(var36);
               Object[] var38 = new Object[]{var4};
               OreSimulation var37 = this;
               var37.aReturningVoid(var38);
            }

            return false;
         }

         var46 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var46);
   }

   @EventListener
   public void a(WorldChunkEvent var1) {
      long var10001 = 65793074483572L ^ 35287190379752L;
      var10001 = 65793074483572L ^ 44981460258118L;
      int var8 = Event.bReturningInt();
      int var20 = var8;
      OreSimulation var19 = this;
      OreSimulation var18 = var19;
      OreSimulation var17 = var19;
      if (var20 == 0) {
         Object[] var10 = new Object[]{21164174908466L};
         OreSimulation var9 = var17;
         boolean var21 = var9.dReturningBoolean(var10);
         if (!var21) {
            return;
         }

         var18 = this;
      }

      Object[] var14 = new Object[0];
      WorldChunkEvent var13 = var1;
      Object[] var16 = new Object[]{var13.aReturningVoid(var14), 30517162921372L};
      OreSimulation var15 = var18;
      var15.mReturningVoid(var16);
   }

   private void mReturningVoid(Object[] var1) {
      Chunk var2 = (Chunk)var1[0];
      long var3 = (Long)var1[1];
      var3 = 131118579493320L ^ var3;
      long var5 = var3 ^ 128883155554992L;
      long var7 = var3 ^ 27818126097724L;
      long var9 = var3 ^ 169131183961L;
      int var10000 = Event.cReturningInt();
      MinecraftClient var33 = b;
      ClientWorld var12 = var33.world;
      int var11 = var10000;
      int var147 = var11;
      ClientWorld var146 = var12;
      ClientWorld var129 = var146;
      ClientWorld var128 = var146;
      if (var147 != 0) {
         ClientWorld var148 = var128;
         if (var148 == null) {
            return;
         }

         var129 = var12;
      }

      ClientWorld var150 = this.j;
      ClientWorld var149 = var129;
      if (var149 == var150) {
         int var152 = var11;
         OreSimulation var151 = this;
         OreSimulation var132 = var151;
         OreSimulation var130 = var151;
         if (var152 != 0) {
            OreSimulation var153 = var130;
            OreSimulation var131 = var153;
            boolean var154 = var131.i;
            if (!var154) {
               return;
            }

            OreSimulation var155 = this;
            var132 = var155;
         }

         Map var156 = var132.g;
         if (var156 != null) {
            ClientWorld var38 = var12;
            RegistryKey var193 = var38.getRegistryKey();
            RegistryKey var40 = this.h;
            RegistryKey var39 = var193;
            boolean var157 = var39.equals(var40);
            if (var157) {
               Chunk var43 = var2;
               ChunkPos var13 = var43.getPos();
               ClientWorld var44 = var12;
               RegistryKey var10002 = var44.getRegistryKey();
               ChunkPos var45 = var13;
               DimensionChunkKey var14 = new DimensionChunkKey(var10002, var45.toLong());
               DimensionChunkKey var47 = var14;
               Map var46 = this.e;
               boolean var158 = var46.containsKey(var47);
               if (var158) {
                  return;
               }

               HashSet var15 = new HashSet();
               ChunkPos var49 = var13;
               Stream var194 = ChunkPos.stream(var49, 1);
               Consumer var52 = invokeBinding2(var12, var15);
               Stream var51 = var194;
               var51.forEach(var52);
               HashSet var53 = var15;
               Stream var195 = var53.stream();
               Function var55 = invokeBinding3(this);
               Stream var54 = var195;
               Stream var196 = var54.flatMap(var55);
               Collector var57 = Collectors.toSet();
               Stream var56 = var196;
               Set var16 = ((java.util.Set)(Object)(var56.collect(var57)));
               ChunkPos var58 = var13;
               int var17 = var58.x << 4;
               ChunkPos var59 = var13;
               int var18 = var59.z << 4;
               short var10003 = 10983;
               long var10004 = 3222651955446546241L ^ var3;
               RandomProvider var60 = RandomProvider.XOROSHIRO;
               ChunkRandom var19 = new ChunkRandom(var60.create(0L));
               int var67 = var18;
               int var66 = var17;
               long var64 = this.f;
               ChunkRandom var63 = var19;
               long var20 = var63.setPopulationSeed(var64, var66, var67);
               HashMap var22 = new HashMap();
               Set var68 = var16;
               Iterator var23 = var68.iterator();

               while (true) {
                  Iterator var69 = var23;
                  boolean var159 = var69.hasNext();
                  if (var159) {
                     Iterator var70 = var23;
                     OreFeatureData var24 = (OreFeatureData)var70.next();
                     HashSet var25 = new HashSet();
                     int var75 = var24.a;
                     int var74 = var24.b;
                     long var72 = var20;
                     ChunkRandom var71 = var19;
                     var71.setDecoratorSeed(var72, var74, var75);
                     ChunkRandom var77 = var19;
                     IntProvider var76 = var24.d;
                     int var26 = var76.get((Random)var77);
                     int var160 = var11;
                     if (var160 == 0) {
                        break;
                     }

                     label124: {
                        int var144;
                        while (true) {
                           int var162 = var26;
                           int var161 = var27;
                           if (var161 < var162) {
                              float var206;
                              var10000 = (var206 = var24.g - 1.0F) == 0.0F ? 0 : (var206 < 0.0F ? -1 : 1);
                              int var164 = var11;
                              int var163 = var10000;
                              var144 = var163;
                              int var133 = var163;
                              if (var164 == 0) {
                                 break;
                              }

                              label127: {
                                 int var138;
                                 int var166 = var11;
                                 int var165 = var133;
                                 var138 = var165;
                                 int var134 = var165;
                                 label92:
                                 if (var166 != 0) {
                                    int var167 = var134;
                                    int var135 = var167;
                                    int var168 = var135;
                                    if (var168 != 0) {
                                       ChunkRandom var80 = var19;
                                       float var207;
                                       var10000 = (var207 = var80.nextFloat() - 1.0F / var24.g) == 0.0F ? 0 : (var207 < 0.0F ? -1 : 1);
                                       int var170 = var11;
                                       int var169 = var10000;
                                       var138 = var169;
                                       int var136 = var169;
                                       if (var170 == 0) {
                                          break label92;
                                       }

                                       int var171 = var136;
                                       int var137 = var171;
                                       int var172 = var137;
                                       if (var172 >= 0) {
                                          int var173 = var11;
                                          if (var173 != 0) {
                                             break label127;
                                          }
                                       }
                                    }

                                    short var10001 = 14462;
                                    long var203 = 6717492994216755112L ^ var3;
                                    ChunkRandom var84 = var19;
                                    int var174 = var84.nextInt(16) + var17;
                                    var138 = var174;
                                 }

                                 int var28 = var138;
                                 int var201 = 7628;
                                 long var204 = 7364301510915840537L ^ var3;
                                 ChunkRandom var87 = var19;
                                 int var29 = var87.nextInt(16) + var18;
                                 HeightContext var91 = var24.f;
                                 ChunkRandom var90 = var19;
                                 HeightProvider var89 = var24.e;
                                 int var30 = var89.get((Random)var90, var91);
                                 BlockPos var31 = new BlockPos(var28, var30, var29);
                                 int var92 = var28;
                                 var201 = BiomeCoords.fromBlock(var92);
                                 int var93 = var30;
                                 int var205 = BiomeCoords.fromBlock(var93);
                                 int var94 = var29;
                                 int var98 = BiomeCoords.fromBlock(var94);
                                 int var97 = var205;
                                 int var96 = var201;
                                 Chunk var95 = var2;
                                 RegistryEntry var99 = var95.getBiomeForNoiseGen(var96, var97, var98);
                                 Optional var100 = var99.getKey();
                                 RegistryKey var32 = (RegistryKey)var100.get();
                                 Object[] var102 = new Object[]{var32, var9};
                                 OreSimulation var101 = this;
                                 List var199 = var101.bReturningList(var102);
                                 OreFeatureData var104 = var24;
                                 List var103 = var199;
                                 boolean var200 = var103.contains(var104);
                                 int var176 = var11;
                                 boolean var175 = var200;
                                 boolean var140 = var175;
                                 boolean var139 = var175;
                                 if (var176 != 0) {
                                    boolean var177 = var139;
                                    if (!var177) {
                                       int var178 = var11;
                                       if (var178 != 0) {
                                          break label127;
                                       }
                                    }

                                    boolean var179 = var24.l;
                                    var140 = var179;
                                 }

                                 int var181 = var11;
                                 boolean var180 = var140;
                                 boolean var141 = var180;
                                 label78:
                                 if (var181 != 0) {
                                    boolean var182 = var141;
                                    if (var182) {
                                       Object[] var110 = new Object[]{var12, var19, var31, var24, var7};
                                       OreSimulation var109 = this;
                                       ArrayList var112 = var109.cReturningVoid(var110);
                                       HashSet var111 = var25;
                                       var111.addAll(var112);
                                       int var183 = var11;
                                       if (var183 != 0) {
                                          break label78;
                                       }
                                    }

                                    Object[] var115 = new Object[]{var12, var19, var31, var24, var5};
                                    OreSimulation var114 = this;
                                    ArrayList var117 = var114.aReturningArrayList(var115);
                                    HashSet var116 = var25;
                                    boolean var184 = var116.addAll(var117);
                                 }
                              }

                              var27++;
                              int var185 = var11;
                              if (var185 != 0) {
                                 continue;
                              }
                           }

                           int var187 = var11;
                           HashSet var186 = var25;
                           HashSet var143 = var186;
                           if (var187 == 0) {
                              break label124;
                           }

                           HashSet var119 = var143;
                           byte var188 = ((byte)((var119.isEmpty()) ? 1 : 0));
                           var144 = var188;
                           break;
                        }

                        int var189 = var144;
                        if (var189 == 0) {
                           HashSet var123 = var25;
                           OreFeatureData var122 = var24;
                           HashMap var121 = var22;
                           Object var190 = var121.put(var122, var123);
                        }
                     }

                     int var191 = var11;
                     if (var191 != 0) {
                        continue;
                     }
                  }

                  HashMap var127 = var22;
                  DimensionChunkKey var126 = var14;
                  Map var125 = this.e;
                  var125.put(var126, var127);
                  break;
               }

               return;
            }
         }
      }
   }

   private List bReturningList(Object[] var1) {
      RegistryKey var4 = (RegistryKey)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 131118579493320L ^ var2;
      int var5 = Event.bReturningInt();
      int var14 = var5;
      Map var13 = this.g;
      Object var12 = var13;
      Map var11 = var13;
      if (var14 == 0) {
         Map var15 = var11;
         if (var15 == null) {
            return Collections.emptyList();
         }

         Map var16 = this.g;
         List var10 = Collections.emptyList();
         RegistryKey var9 = var4;
         Map var8 = var16;
         var12 = var8.getOrDefault(var9, var10);
      }

      return (List)var12;
   }

   private ArrayList aReturningArrayList(Object[] var1) {
      ClientWorld var4 = (ClientWorld)var1[0];
      ChunkRandom var7 = (ChunkRandom)var1[1];
      BlockPos var5 = (BlockPos)var1[2];
      OreFeatureData var6 = (OreFeatureData)var1[3];
      long var2 = (Long)var1[4];
      var2 = 131118579493320L ^ var2;
      long var8 = var2 ^ 108142687773172L;
      int var11 = var6.i;
      ChunkRandom var34 = var7;
      float var12 = var34.nextFloat() * (float) Math.PI;
      float var13 = var11 / 8.0F;
      int var10000 = Event.cReturningInt();
      float var35 = (var11 / 16.0F * 2.0F + 1.0F) / 2.0F;
      int var14 = MathHelper.ceil(var35);
      BlockPos var36 = var5;
      double var10001 = var36.getX();
      double var37 = var12;
      double var15 = var10001 + Math.sin(var37) * var13;
      BlockPos var39 = var5;
      var10001 = var39.getX();
      double var40 = var12;
      double var17 = var10001 - Math.sin(var40) * var13;
      int var10 = var10000;
      BlockPos var42 = var5;
      double var82 = var42.getZ();
      double var43 = var12;
      double var19 = var82 + Math.cos(var43) * var13;
      BlockPos var45 = var5;
      double var83 = var45.getZ();
      double var46 = var12;
      double var21 = var83 - Math.cos(var46) * var13;
      BlockPos var48 = var5;
      var10000 = var48.getY();
      ChunkRandom var49 = var7;
      double var23 = var10000 + var49.nextInt(3) - 2;
      BlockPos var51 = var5;
      var10000 = var51.getY();
      ChunkRandom var52 = var7;
      double var25 = var10000 + var52.nextInt(3) - 2;
      BlockPos var54 = var5;
      var10000 = var54.getX();
      float var55 = var13;
      int var27 = var10000 - MathHelper.ceil(var55) - var14;
      BlockPos var56 = var5;
      int var28 = var56.getY() - 2 - var14;
      BlockPos var57 = var5;
      var10000 = var57.getZ();
      float var58 = var13;
      int var29 = var10000 - MathHelper.ceil(var58) - var14;
      float var59 = var13;
      int var30 = 2 * (MathHelper.ceil(var59) + var14);
      int var31 = 2 * (2 + var14);
      int var32 = var27;

      while (true) {
         int var67 = var27 + var30;
         int var66 = var32;

         label31:
         while (true) {
            int var71 = var67;
            int var70 = var66;
            if (var70 > var71) {
               return new ArrayList();
            }

            int var33 = var29;

            int var79;
            do {
               int var73 = var29 + var30;
               int var72 = var33;
               if (var72 > var73) {
                  break;
               }

               int var63 = var33;
               int var62 = var32;
               Type var61 = Type.MOTION_BLOCKING;
               ClientWorld var60 = var4;
               int var89 = var60.getTopY(var61, var62, var63);
               int var76 = var10;
               int var75 = var89;
               int var74 = var28;
               var66 = var74;
               var67 = var75;
               int var68 = var74;
               int var69 = var75;
               if (var76 == 0) {
                  continue label31;
               }

               int var78 = var69;
               int var77 = var68;
               if (var77 <= var78) {
                  Object[] var10018 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, var6, var8};
                  var10018[13] = var31;
                  var10018[12] = var30;
                  var10018[11] = var29;
                  var10018[10] = var28;
                  var10018[9] = var27;
                  var10018[8] = var25;
                  var10018[7] = var23;
                  var10018[6] = var21;
                  var10018[5] = var19;
                  var10018[4] = var17;
                  var10018[3] = var15;
                  var10018[2] = var11;
                  var10018[1] = var7;
                  var10018[0] = var4;
                  Object[] var65 = var10018;
                  OreSimulation var64 = this;
                  return var64.bReturningArrayList(var65);
               }

               var33++;
               var79 = var10;
            } while (var79 != 0);

            var32++;
            int var80 = var10;
            if (var80 == 0) {
               return new ArrayList();
            }
            break;
         }
      }
   }

   private ArrayList bReturningArrayList(Object[] var1) {
      ClientWorld var18 = (ClientWorld)var1[0];
      ChunkRandom var23 = (ChunkRandom)var1[1];
      int var3 = (Integer)var1[2];
      double var4 = (Double)var1[3];
      double var6 = (Double)var1[4];
      double var8 = (Double)var1[5];
      double var10 = (Double)var1[6];
      double var12 = (Double)var1[7];
      double var14 = (Double)var1[8];
      int var16 = (Integer)var1[9];
      int var21 = (Integer)var1[10];
      int var24 = (Integer)var1[11];
      int var17 = (Integer)var1[12];
      int var22 = (Integer)var1[13];
      OreFeatureData var2 = (OreFeatureData)var1[14];
      long var19 = (Long)var1[15];
      var19 = 131118579493320L ^ var19;
      long var25 = var19 ^ 85113499523178L;
      BitSet var28 = new BitSet(var17 * var22 * var17);
      int var10000 = Event.cReturningInt();
      Mutable var29 = new Mutable();
      int var27 = var10000;
      double[] var30 = new double[var3 * 4];
      ArrayList var31 = new ArrayList();
      while (true) {
         int var174 = var3;
         int var173 = var32;
         if (var173 < var174) {
            float var41 = (float)var32 / var3;
            double var259 = var41;
            double var69 = var6;
            double var67 = var4;
            double var65 = var259;
            double var33 = MathHelper.lerp(var65, var67, var69);
            double var260 = var41;
            double var75 = var14;
            double var73 = var12;
            double var71 = var260;
            double var35 = MathHelper.lerp(var71, var73, var75);
            double var261 = var41;
            double var81 = var10;
            double var79 = var8;
            double var77 = var261;
            double var37 = MathHelper.lerp(var77, var79, var81);
            ChunkRandom var83 = var23;
            double var39 = var83.nextDouble() * var3 / 16.0;
            double var84 = (float) Math.PI * var41;
            double var42 = ((MathHelper.sin(var84) + 1.0F) * var39 + 1.0) / 2.0;
            var30[var32 * 4] = var33;
            var30[var32 * 4 + 1] = var35;
            var30[var32 * 4 + 2] = var37;
            var30[var32 * 4 + 3] = var42;
            var32++;
            int var175 = var27;
            if (var175 == 0) {
               break;
            }

            int var176 = var27;
            if (var176 != 0) {
               continue;
            }
         }

         var32 = 0;
         break;
      }

      int var158;
      label208:
      while (true) {
         int var143 = var32;

         label205:
         while (true) {
            int var178 = var3 - 1;
            int var177 = var143;
            if (var177 >= var178) {
               break;
            }

            double var277;
            var10000 = (var277 = var30[var32 * 4 + 3] - 0.0) == 0.0 ? 0 : (var277 < 0.0 ? -1 : 1);
            int var180 = var27;
            int var179 = var10000;
            var158 = var179;
            int var144 = var179;
            if (var180 == 0) {
               break label208;
            }

            label222: {
               int var182 = var27;
               int var181 = var144;
               int var147 = var181;
               int var145 = var181;
               if (var182 != 0) {
                  int var183 = var145;
                  int var146 = var183;
                  int var184 = var146;
                  if (var184 <= 0) {
                     break label222;
                  }

                  int var185 = var32 + 1;
                  var147 = var185;
               }

               int var257 = var147;

               int var205;
               do {
                  int var187 = var3;
                  int var186 = var257;
                  if (var186 >= var187) {
                     break;
                  }

                  label193: {
                     label224: {
                        double var263 = var30[var257 * 4 + 3];
                        int var192 = var27;
                        double var188 = var263;
                        double var154 = var188;
                        double var156 = var190;
                        double var148 = var188;
                        double var150 = var190;
                        if (var192 != 0) {
                           double var278;
                           var10000 = (var278 = var148 - var150) == 0.0 ? 0 : (var278 < 0.0 ? -1 : 1);
                           int var194 = var27;
                           int var193 = var10000;
                           var143 = var193;
                           int var152 = var193;
                           if (var194 == 0) {
                              continue label205;
                           }

                           int var195 = var152;
                           int var153 = var195;
                           int var196 = var153;
                           if (var196 <= 0) {
                              break label224;
                           }

                           double var265 = var30[var32 * 4];
                           double var199 = var30[var257 * 4];
                           double var197 = var265;
                           var154 = var197;
                           var156 = var199;
                        }

                        double var253 = var154 - var156;
                        double var254 = var30[var32 * 4 + 1] - var30[var257 * 4 + 1];
                        double var255 = var30[var32 * 4 + 2] - var30[var257 * 4 + 2];
                        double var256 = var30[var32 * 4 + 3] - var30[var257 * 4 + 3];
                        int var201 = var27;
                        if (var201 == 0) {
                           break label193;
                        }

                        double var279;
                        int var202 = (var279 = var256 * var256 - (var253 * var253 + var254 * var254 + var255 * var255)) == 0.0 ? 0 : (var279 < 0.0 ? -1 : 1);
                        label185:
                        if (var202 > 0) {
                           double var280;
                           int var203 = (var280 = var256 - 0.0) == 0.0 ? 0 : (var280 < 0.0 ? -1 : 1);
                           if (var203 > 0) {
                              var30[var257 * 4 + 3] = -1.0;
                              int var204 = var27;
                              if (var204 != 0) {
                                 break label185;
                              }
                           }

                           var30[var32 * 4 + 3] = -1.0;
                        }
                     }

                     var257++;
                  }

                  var205 = var27;
               } while (var205 != 0);
            }

            var32++;
            int var206 = var27;
            if (var206 != 0) {
               continue label208;
            }
            break;
         }

         var158 = 0;
         break;
      }

      var32 = var158;

      while (true) {
         int var159 = var32;

         label163:
         while (true) {
            int var208 = var3;
            int var207 = var159;
            if (var207 >= var208) {
               return var31;
            }

            double var258 = var30[var32 * 4 + 3];
            int var209 = var27;
            if (var209 != 0) {
               double var281;
               int var210 = (var281 = var258 - 0.0) == 0.0 ? 0 : (var281 < 0.0 ? -1 : 1);
               if (var210 >= 0) {
                  double var43 = var30[var32 * 4];
                  double var45 = var30[var32 * 4 + 1];
                  double var47 = var30[var32 * 4 + 2];
                  double var97 = var43 - var258;
                  var10000 = MathHelper.floor(var97);
                  int var100 = var16;
                  int var99 = var10000;
                  int var49 = Math.max(var99, var100);
                  double var101 = var45 - var258;
                  var10000 = MathHelper.floor(var101);
                  int var104 = var21;
                  int var103 = var10000;
                  int var50 = Math.max(var103, var104);
                  double var105 = var47 - var258;
                  var10000 = MathHelper.floor(var105);
                  int var108 = var24;
                  int var107 = var10000;
                  int var51 = Math.max(var107, var108);
                  double var109 = var43 + var258;
                  var10000 = MathHelper.floor(var109);
                  int var112 = var49;
                  int var111 = var10000;
                  int var52 = Math.max(var111, var112);
                  double var113 = var45 + var258;
                  var10000 = MathHelper.floor(var113);
                  int var116 = var50;
                  int var115 = var10000;
                  int var53 = Math.max(var115, var116);
                  double var117 = var47 + var258;
                  var10000 = MathHelper.floor(var117);
                  int var120 = var51;
                  int var119 = var10000;
                  int var54 = Math.max(var119, var120);
                  int var55 = var49;

                  int var249;
                  label157:
                  do {
                     int var160 = var55;

                     label154: {
                        label153:
                        while (true) {
                           int var212 = var52;
                           int var211 = var160;
                           if (var211 > var212) {
                              break label157;
                           }

                           double var56 = (var55 + 0.5 - var43) / var258;
                           int var213 = var27;
                           if (var213 == 0) {
                              break label154;
                           }

                           double var282;
                           var10000 = (var282 = var56 * var56 - 1.0) == 0.0 ? 0 : (var282 < 0.0 ? -1 : 1);
                           int var215 = var27;
                           int var214 = var10000;
                           var159 = var214;
                           int var161 = var214;
                           if (var215 == 0) {
                              continue label163;
                           }

                           int var216 = var161;
                           int var162 = var216;
                           int var217 = var162;
                           if (var217 >= 0) {
                              break;
                           }

                           int var58 = var50;

                           while (true) {
                              int var163 = var58;

                              label148: {
                                 label147:
                                 while (true) {
                                    int var219 = var53;
                                    int var218 = var163;
                                    if (var218 > var219) {
                                       break label153;
                                    }

                                    double var59 = (var58 + 0.5 - var45) / var258;
                                    int var220 = var27;
                                    if (var220 == 0) {
                                       break label148;
                                    }

                                    double var283;
                                    var10000 = (var283 = var56 * var56 + var59 * var59 - 1.0) == 0.0 ? 0 : (var283 < 0.0 ? -1 : 1);
                                    int var222 = var27;
                                    int var221 = var10000;
                                    var160 = var221;
                                    int var164 = var221;
                                    if (var222 == 0) {
                                       continue label153;
                                    }

                                    int var223 = var164;
                                    int var165 = var223;
                                    int var224 = var165;
                                    if (var224 >= 0) {
                                       break;
                                    }

                                    int var61 = var51;

                                    while (true) {
                                       int var226 = var54;
                                       int var225 = var61;
                                       if (var225 > var226) {
                                          break label147;
                                       }

                                       double var62 = (var61 + 0.5 - var47) / var258;
                                       int var227 = var27;
                                       label142:
                                       if (var227 != 0) {
                                          double var284;
                                          var10000 = (var284 = var56 * var56 + var59 * var59 + var62 * var62 - 1.0) == 0.0 ? 0 : (var284 < 0.0 ? -1 : 1);
                                          int var229 = var27;
                                          int var228 = var10000;
                                          var163 = var228;
                                          int var166 = var228;
                                          if (var229 == 0) {
                                             break;
                                          }

                                          int var230 = var166;
                                          int var167 = var230;
                                          int var231 = var167;
                                          if (var231 < 0) {
                                             int var64 = var55 - var16 + (var58 - var21) * var17 + (var61 - var24) * var17 * var22;
                                             int var232 = var27;
                                             if (var232 == 0) {
                                                break label142;
                                             }

                                             int var125 = var64;
                                             BitSet var124 = var28;
                                             boolean var233 = var124.get(var125);
                                             if (!var233) {
                                                int var128 = var64;
                                                BitSet var127 = var28;
                                                var127.set(var128);
                                                int var132 = var61;
                                                int var131 = var58;
                                                int var130 = var55;
                                                Mutable var129 = var29;
                                                var129.set(var130, var131, var132);
                                                int var234 = var27;
                                                if (var234 == 0) {
                                                   break label142;
                                                }

                                                short var10001 = 430;
                                                long var10002 = 4332815499007653182L ^ var19;
                                                byte var236 = -64;
                                                int var235 = var58;
                                                label135:
                                                if (var235 >= var236) {
                                                   int var238 = var27;
                                                   int var237 = var58;
                                                   int var170 = var237;
                                                   int var168 = var237;
                                                   if (var238 != 0) {
                                                      int var239 = var168;
                                                      int var169 = var239;
                                                      var10001 = 27226;
                                                      var10002 = 3101062057664913101L ^ var19;
                                                      short var241 = 320;
                                                      int var240 = var169;
                                                      if (var240 >= var241) {
                                                         break label135;
                                                      }

                                                      Object[] var138 = new Object[]{var18, var29, var2, var23, var25};
                                                      OreSimulation var137 = this;
                                                      byte var242 = ((byte)((var137.aReturningBoolean(var138)) ? 1 : 0));
                                                      var170 = var242;
                                                   }

                                                   int var244 = var27;
                                                   int var243 = var170;
                                                   int var171 = var243;
                                                   if (var244 != 0) {
                                                      int var245 = var171;
                                                      if (var245 != 0) {
                                                         Vec3d var142 = new Vec3d(var55, var58, var61);
                                                         ArrayList var141 = var31;
                                                         boolean var246 = var141.add(var142);
                                                      }
                                                   }
                                                }
                                             }
                                          }

                                          var61++;
                                       }

                                       int var247 = var27;
                                       if (var247 == 0) {
                                          break label147;
                                       }
                                    }
                                 }

                                 var58++;
                              }

                              int var248 = var27;
                              if (var248 == 0) {
                                 break label153;
                              }
                           }
                        }

                        var55++;
                     }

                     var249 = var27;
                  } while (var249 != 0);
               }

               var32++;
            }

            int var250 = var27;
            if (var250 == 0) {
               return var31;
            }
            break;
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      ClientWorld var2 = (ClientWorld)var1[0];
      BlockPos var3 = (BlockPos)var1[1];
      OreFeatureData var4 = (OreFeatureData)var1[2];
      ChunkRandom var7 = (ChunkRandom)var1[3];
      long var5 = (Long)var1[4];
      var5 = 131118579493320L ^ var5;
      long var8 = var5 ^ 102720433865174L;
      long var10 = var5 ^ 25868751220368L;
      int var10000 = Event.cReturningInt();
      BlockPos var18 = var3;
      ClientWorld var17 = var2;
      BlockState var13 = var17.getBlockState(var18);
      int var12 = var10000;
      List var19 = var4.j;
      Iterator var14 = var19.iterator();

      while (true) {
         Iterator var20 = var14;
         boolean var54 = var20.hasNext();
         if (!var54) {
            break;
         }

         Iterator var21 = var14;
         Target var15 = (Target)var21.next();
         Target var22 = var15;
         BlockState var23 = var22.state;
         Block var25 = var23.getBlock();
         BlockState var24 = var13;
         byte var78 = ((byte)((var24.isOf(var25)) ? 1 : 0));
         int var56 = var12;
         byte var55 = var78;
         byte var53 = var55;
         byte var40 = var55;
         if (var56 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var53);
         }

         byte var46;
         label65: {
            byte var45;
            int var58 = var12;
            byte var57 = var40;
            var45 = var57;
            byte var41 = var57;
            label64:
            if (var58 != 0) {
               byte var59 = var41;
               byte var42 = var59;
               byte var60 = var42;
               if (var60 == 0) {
                  Target var28 = var15;
                  ChunkRandom var31 = var7;
                  BlockState var30 = var13;
                  RuleTest var29 = var28.target;
                  var78 = ((byte)((var29.test(var30, (Random)var31)) ? 1 : 0));
                  int var62 = var12;
                  byte var61 = var78;
                  var45 = var61;
                  byte var43 = var61;
                  if (var62 == 0) {
                     break label64;
                  }

                  byte var63 = var43;
                  byte var44 = var63;
                  byte var64 = var44;
                  if (var64 == 0) {
                     var46 = 0;
                     break label65;
                  }
               }

               var45 = 1;
            }

            byte var65 = var45;
            var46 = var65;
         }

         byte var16 = var46;
         int var67 = var12;
         byte var66 = var16;
         byte var48 = var66;
         byte var47 = var66;
         if (var67 != 0) {
            byte var68 = var47;
            if (var68 == 0) {
               continue;
            }

            float var10002 = var4.h;
            Object[] var10005 = new Object[]{null, null, var8};
            var10005[1] = var10002;
            var10005[0] = var7;
            Object[] var36 = var10005;
            OreSimulation var35 = this;
            var48 = ((byte)((var35.eReturningBoolean(var36)) ? 1 : 0));
         }

         int var70 = var12;
         byte var69 = var48;
         byte var52 = var69;
         byte var49 = var69;
         if (var70 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var52);
         }

         byte var71 = var49;
         if (var71 != 0) {
            return true;
         }

         Object[] var39 = new Object[]{var2, var3, var10};
         OreSimulation var38 = this;
         boolean var80 = var38.fReturningBoolean(var39);
         int var73 = var12;
         boolean var72 = var80;
         boolean var81 = var72;
         boolean var50 = var72;
         if (var73 == 0) {
            return var81;
         }

         boolean var74 = var50;
         boolean var51 = var74;
         boolean var75 = var51;
         if (!var75) {
            return true;
         }

         int var76 = var12;
         if (var76 == 0) {
            break;
         }
      }

      return false;
   }

   private boolean eReturningBoolean(Object[] var1) {
      ChunkRandom var3 = (ChunkRandom)var1[0];
      float var2 = (Float)var1[1];
      long var4 = (Long)var1[2];
      long var10000 = 131118579493320L ^ var4;
      int var6 = Event.cReturningInt();
      float var30;
      int var29 = (var30 = var2 - 0.0F) == 0.0F ? 0 : (var30 < 0.0F ? -1 : 1);
      int var20 = var6;
      int var19 = var29;
      int var13 = var19;
      int var12 = var19;
      if (var20 != 0) {
         int var21 = var12;
         if (var21 <= 0) {
            return true;
         }

         float var31;
         var13 = (var31 = var2 - 1.0F) == 0.0F ? 0 : (var31 < 0.0F ? -1 : 1);
      }

      int var23 = var6;
      int var22 = var13;
      int var15 = var22;
      int var14 = var22;
      if (var23 != 0) {
         int var24 = var14;
         if (var24 >= 0) {
            return false;
         }

         ChunkRandom var11 = var3;
         float var32;
         var15 = (var32 = var11.nextFloat() - var2) == 0.0F ? 0 : (var32 < 0.0F ? -1 : 1);
      }

      int var26 = var6;
      int var25 = var15;
      int var17 = var25;
      int var16 = var25;
      if (var26 != 0) {
         int var27 = var16;
         if (var27 < 0) {
            return false;
         }

         var17 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var17);
   }

   private boolean fReturningBoolean(Object[] var1) {
      ClientWorld var5 = (ClientWorld)var1[0];
      BlockPos var4 = (BlockPos)var1[1];
      long var2 = (Long)var1[2];
      long var10000 = 131118579493320L ^ var2;
      Direction[] var7 = Direction.values();
      int var27 = Event.cReturningInt();
      int var8 = var7.length;
      int var6 = var27;

      byte var18;
      while (true) {
         int var20 = var8;
         int var19 = var9;
         if (var19 < var20) {
            Direction var10 = var7[var9];
            int var21 = var6;
            if (var21 != 0) {
               Direction var12 = var10;
               BlockPos var11 = var4;
               BlockPos var14 = var11.offset(var12);
               ClientWorld var13 = var5;
               BlockState var15 = var13.getBlockState(var14);
               byte var28 = ((byte)((var15.isAir()) ? 1 : 0));
               int var23 = var6;
               byte var22 = var28;
               var18 = var22;
               byte var16 = var22;
               if (var23 == 0) {
                  break;
               }

               byte var24 = var16;
               byte var17 = var24;
               byte var25 = var17;
               if (var25 != 0) {
                  return true;
               }

               var9++;
            }

            int var26 = var6;
            if (var26 != 0) {
               continue;
            }
         }

         var18 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   private ArrayList c(Object[] var1) {
      ClientWorld var4 = (ClientWorld)var1[0];
      ChunkRandom var3 = (ChunkRandom)var1[1];
      BlockPos var2 = (BlockPos)var1[2];
      OreFeatureData var5 = (OreFeatureData)var1[3];
      long var6 = (Long)var1[4];
      var6 = 131118579493320L ^ var6;
      long var8 = var6 ^ 91661109539850L;
      long var10 = var6 ^ 57211631058906L;
      ArrayList var13 = new ArrayList();
      int var10000 = Event.bReturningInt();
      int var22 = var5.i + 1;
      ChunkRandom var21 = var3;
      int var14 = var21.nextInt(var22);
      int var12 = var10000;
      int var43;
      do {
         int var40 = var14;
         int var39 = var15;
         if (var39 >= var40) {
            break;
         }

         short var10001 = 15351;
         long var10002 = 689558613956552916L ^ var6;
         int var23 = var15;
         int var16 = Math.min(var23, 7);
         Object[] var10005 = new Object[]{null, null, var8};
         var10005[1] = var16;
         var10005[0] = var3;
         Object[] var26 = var10005;
         OreSimulation var25 = this;
         var10000 = var25.aReturningInt(var26);
         BlockPos var27 = var2;
         int var17 = var10000 + var27.getX();
         var10005 = new Object[]{null, null, var8};
         var10005[1] = var16;
         var10005[0] = var3;
         Object[] var29 = var10005;
         OreSimulation var28 = this;
         var10000 = var28.aReturningInt(var29);
         BlockPos var30 = var2;
         int var18 = var10000 + var30.getY();
         var10005 = new Object[]{null, null, var8};
         var10005[1] = var16;
         var10005[0] = var3;
         Object[] var32 = var10005;
         OreSimulation var31 = this;
         var10000 = var31.aReturningInt(var32);
         BlockPos var33 = var2;
         int var19 = var10000 + var33.getZ();
         BlockPos var20 = new BlockPos(var17, var18, var19);
         int var41 = var12;
         if (var41 == 0) {
            Object[] var35 = new Object[]{var4, var20, var5, var3, var10};
            OreSimulation var34 = this;
            boolean var42 = var34.aReturningBoolean(var35);
            if (var42) {
               Vec3d var38 = new Vec3d(var17, var18, var19);
               ArrayList var37 = var13;
               var37.add(var38);
            }

            var15++;
         }

         var43 = var12;
      } while (var43 == 0);

      return var13;
   }

   private int aReturningInt(Object[] var1) {
      ChunkRandom var3 = (ChunkRandom)var1[0];
      int var2 = (Integer)var1[1];
      long var4 = (Long)var1[2];
      long var10000 = 131118579493320L ^ var4;
      ChunkRandom var6 = var3;
      float var9 = var6.nextFloat();
      ChunkRandom var7 = var3;
      float var8 = (var9 - var7.nextFloat()) * var2;
      return Math.round(var8);
   }

   private Stream lambda$doMathOnChunk$3(RegistryKey var1) {
      long var10001 = 93569812736165L ^ 63495497270184L;
      Object[] var7 = new Object[]{var1, 119461730085645L};
      OreSimulation var6 = this;
      List var8 = var6.bReturningList(var7);
      return var8.stream();
   }

   private static void lambda$doMathOnChunk$2(ClientWorld var0, Set var1, ChunkPos var2) {
      int var10000 = Event.cReturningInt();
      ChunkPos var11 = var2;
      ChunkPos var12 = var2;
      ChunkStatus var16 = ChunkStatus.BIOMES;
      int var15 = var12.z;
      int var14 = var11.x;
      ClientWorld var13 = var0;
      Chunk var6 = var13.getChunk(var14, var15, var16, false);
      int var5 = var10000;
      int var26 = var5;
      Chunk var25 = var6;
      Chunk var24 = var25;
      Chunk var23 = var25;
      if (var26 != 0) {
         Chunk var27 = var23;
         if (var27 == null) {
            return;
         }

         var24 = var6;
      }

      Chunk var19 = var24;
      ChunkSection[] var7 = var19.getSectionArray();
      int var8 = var7.length;
      int var30;
      do {
         int var29 = var8;
         int var28 = var9;
         if (var28 >= var29) {
            break;
         }

         ChunkSection var10 = var7[var9];
         ChunkSection var20 = var10;
         ReadableContainer var31 = var20.getBiomeContainer();
         Consumer var22 = invokeBinding4(var1);
         ReadableContainer var21 = var31;
         var21.forEachValue(var22);
         var9++;
         var30 = var5;
      } while (var30 != 0);
   }

   private static void lambda$doMathOnChunk$1(Set var0, RegistryEntry var1) {
      RegistryEntry var4 = var1;
      Optional var5 = var4.getKey();
      RegistryKey var7 = (RegistryKey)var5.get();
      Set var6 = var0;
      var6.add(var7);
   }

   private static Iterator lambda$chunks$0(boolean var0) {
      long var10001 = 29524168205596L ^ 87294242122803L;
      return new LoadedChunkIterator(var0, 94278420531503L);
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(68915910077388L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[5];
      String var28 = "\u0083ñÄE\u0004]WIYÊ\u0089³xÁÃGn\u0091Ã°\u0090õû£\u007ft¤éø<\f& ×\b\u0083$R\u001cÝîê.ì\u0084k\u0010\u001a<\\ì+9\u008ea\n\u0007\u0005\u0098ýè3×<\u0091@ø®\u0096°ûü§\u009bT}dC·¡ÆÞD²âlÂ¿ºÏÈÃKW\u0090\u0017Ä\u000b\u009dxlÛ{0¡6Q{Ç\tFb\u0015\u008c÷o[¥ö\u001f\u0084\u000b×Å+B/¯\u008c\u008a";
      int var30 = "\u0083ñÄE\u0004]WIYÊ\u0089³xÁÃGn\u0091Ã°\u0090õû£\u007ft¤éø<\f& ×\b\u0083$R\u001cÝîê.ì\u0084k\u0010\u001a<\\ì+9\u008ea\n\u0007\u0005\u0098ýè3×<\u0091@ø®\u0096°ûü§\u009bT}dC·¡ÆÞD²âlÂ¿ºÏÈÃKW\u0090\u0017Ä\u000b\u009dxlÛ{0¡6Q{Ç\tFb\u0015\u008c÷o[¥ö\u001f\u0084\u000b×Å+B/¯\u008c\u008a"
         .length();
      char var27 = ' ';
      int var35 = -1;

      label72:
      while (true) {
         String var36 = var28.substring(++var35, var35 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var36.getBytes("ISO-8859-1"));
            String var50 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var50;
                  if ((var35 += var27) >= var30) {
                     m = var31;
                     n = new String[5];
                     r = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(68915910077388L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[5];
                     String var15 = "\u0093\u0092ÅÖ\u0017D\u008b¨\u0094@\u0087Ì¿ìä¹\u0013£ Ó.<>\u009c";
                     int var16 = "\u0093\u0092ÅÖ\u0017D\u008b¨\u0094@\u0087Ì¿ìä¹\u0013£ Ó.<>\u009c".length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var39 = var17;
                        var10001 = var14++;
                        long var54 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var54;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var62 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var58) {
                              case 0:
                                 var39[var10001] = var62;
                                 if (var13 >= var16) {
                                    p = var17;
                                    q = new Integer[5];
                                    u = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(68915910077388L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[3];
                                    String var4 = "4\u009c\u008fü\u0089·¥\u0087Xèà¨ÅgT\u0082\u001b\u0086¹\u0000åÅéq";
                                    int var5 = "4\u009c\u008fü\u0089·¥\u0087Xèà¨ÅgT\u0082\u001b\u0086¹\u0000åÅéq".length();
                                    do {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       var47 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var62 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       
                                    } while (var2 < var5);

                                    s = var6;
                                    t = new Long[3];
                                    break;
                                 }
                                 break;
                              default:
                                 var39[var10001] = var62;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "n\u00adQÔ4\u0004«v0dO2ê:¸\u0013";
                                 var16 = "n\u00adQÔ4\u0004«v0dO2ê:¸\u0013".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var39 = var17;
                           var10001 = var14++;
                           var54 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var58 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var35);
                  break;
               default:
                  var31[var29++] = var50;
                  if ((var35 += var27) < var30) {
                     var27 = var28.charAt(var35);
                     continue label72;
                  }

                  var28 = "fÅnb\u0083¼\u0007ÔGàåD\b\u001c\u008aà\rK»3dô=Ü\nV\u000eZ\u001f µ\u0080\u0013JeïU\u000b\bÇ\u0018¦Gdmã\u0081/[@ \u009e\u0095\u0098\u00add\n2&eêi±½«";
                  var30 = "fÅnb\u0083¼\u0007ÔGàåD\b\u001c\u008aà\rK»3dô=Ü\nV\u000eZ\u001f µ\u0080\u0013JeïU\u000b\bÇ\u0018¦Gdmã\u0081/[@ \u009e\u0095\u0098\u00add\n2&eêi±½«"
                     .length();
                  var27 = '(';
                  var35 = -1;
            }

            var36 = var28.substring(++var35, var35 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static NumberFormatException a(NumberFormatException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23476;
      if (n[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])o.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               o.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e_", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = m[var5].getBytes("ISO-8859-1");
         n[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return n[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e_",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9091;
      if (q[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = p[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])r.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/e_", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         q[var3] = var15;
      }

      return q[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e_",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12786;
      if (t[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = s[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])u.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               u.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/e_", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         t[var3] = var15;
      }

      return t[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e_",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = w[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = v[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 5;
            yield var15;
         }
         case 1 -> {
            byte var16 = 22;
            yield var16;
         }
         case 2 -> {
            byte var17 = 29;
            yield var17;
         }
         case 3 -> {
            byte var18 = 51;
            yield var18;
         }
         case 4 -> {
            byte var19 = 0;
            yield var19;
         }
         case 5 -> {
            byte var20 = 6;
            yield var20;
         }
         case 6 -> {
            byte var21 = 21;
            yield var21;
         }
         case 7 -> {
            byte var22 = 17;
            yield var22;
         }
         case 8 -> {
            byte var23 = 62;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 7;
            yield var25;
         }
         case 11 -> {
            byte var26 = 53;
            yield var26;
         }
         case 12 -> {
            byte var27 = 12;
            yield var27;
         }
         case 13 -> {
            byte var28 = 56;
            yield var28;
         }
         case 14 -> {
            byte var29 = 27;
            yield var29;
         }
         case 15 -> {
            byte var30 = 9;
            yield var30;
         }
         case 16 -> {
            byte var31 = 60;
            yield var31;
         }
         case 17 -> {
            byte var32 = 15;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 14;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 33;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 18;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 8;
            yield var41;
         }
         case 27 -> {
            byte var42 = 59;
            yield var42;
         }
         case 28 -> {
            byte var43 = 34;
            yield var43;
         }
         case 29 -> {
            byte var44 = 11;
            yield var44;
         }
         case 30 -> {
            byte var45 = 16;
            yield var45;
         }
         case 31 -> {
            byte var46 = 26;
            yield var46;
         }
         case 32 -> {
            byte var47 = 55;
            yield var47;
         }
         case 33 -> {
            byte var48 = 45;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 54;
            yield var50;
         }
         case 36 -> {
            byte var51 = 28;
            yield var51;
         }
         case 37 -> {
            byte var52 = 19;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 48;
            yield var54;
         }
         case 40 -> {
            byte var55 = 25;
            yield var55;
         }
         case 41 -> {
            byte var56 = 20;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 32;
            yield var58;
         }
         case 44 -> {
            byte var59 = 41;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 44;
            yield var61;
         }
         case 47 -> {
            byte var62 = 24;
            yield var62;
         }
         case 48 -> {
            byte var63 = 31;
            yield var63;
         }
         case 49 -> {
            byte var64 = 46;
            yield var64;
         }
         case 50 -> {
            byte var65 = 58;
            yield var65;
         }
         case 51 -> {
            byte var66 = 61;
            yield var66;
         }
         case 52 -> {
            byte var67 = 35;
            yield var67;
         }
         case 53 -> {
            byte var68 = 1;
            yield var68;
         }
         case 54 -> {
            byte var69 = 37;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 10;
            yield var72;
         }
         case 58 -> {
            byte var73 = 47;
            yield var73;
         }
         case 59 -> {
            byte var74 = 40;
            yield var74;
         }
         case 60 -> {
            byte var75 = 36;
            yield var75;
         }
         case 61 -> {
            byte var76 = 50;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            w[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      v[0] = "!o\u001cm\u001aQ?g\u0006\"yE;";
      v[1] = "\u0000=]#0-\u001e5GlM=\u001e";
      v[2] = "iqF\u00037\u0019iqQ_;\u0016s:QA;\u0003tK\u0000\u0019i";
      v[3] = double.class;
      w[3] = "java/lang/Double";
      v[4] = ")\u001f\u0001\u0019Ow?\u001f\u0004C\\`(T\u0007EPt9\u0013\u0010R\u001bf\b";
      v[5] = int.class;
      w[5] = "java/lang/Integer";
      v[6] = ",@X\u0005\u0000q:@]_\u0013f-\u000b^Y\u001fr<LINTe\u0006";
      v[7] = "\f@\u0005[D|y`\u000eTU3\u0018n\u0005_Qil";
      v[8] = boolean.class;
      w[8] = "java/lang/Boolean";
      v[9] = "\f?.\\_r\f?9\u0000S}\u0016t9\u001eSh\u0011\u0005kK\u0000(";
      v[10] = long.class;
      w[10] = "java/lang/Long";
      v[11] = "\r[5,\\\u0007\u001b[0vO\u0010\f\u00103pC\u0004\u001dW$g\b\u00126";
      v[12] = ")\u0010mM-+\"\u001f|\u0002M2.\u0013~^E(1\u001czXF? \u0014kXj(-";
      v[13] = "xf\u0007k\u0001\u0006fn\u001d$b\u0012b#4d[\u0001k";
      v[14] = "(qX\u0001Fa#~IN'o(uM\u0014";
      v[15] = "x\u0016aNN*f\u001e{\u0001)+w\u0005v[\u000f-";
      v[16] = "\r\u001b)fB\u007f\r\u001b>:Np\u0017P>$Ne\u0010!ny\u001f";
      v[17] = "\u001f\u001c-'>=\u001f\u001c:{22\u0005W:e2'\u0002&o:k";
      v[18] = "f4\u0013n\\^f4\u00042PQ|\u007f\u0004,PD{\u000eSv\u0001\u0003";
      v[19] = "X+Q\u0019I\rX+FEE\u0002B`F[E\u0017E\u0011\u0017\u0004\u001c";
      v[20] = "b\u001f0\u0013Ict\u001f5IZtcT6OV`r\u0013!X\u001dwp";
      v[21] = "\u0018kX`\u0001tmKSo\u0010;\fEXd\u0014ax";
      v[22] = void.class;
      w[22] = "java/lang/Void";
      v[23] = "\u0002({\u000fJO\u0002(lSF@\u0018clMFU\u001f\u0012:\u0012\u0015\u0017";
      v[24] = "c$\u000ep6\u0017c$\u0019,:\u0018yo\u00192:\r~\u001eHmnN";
      v[25] = "1FOS(q\u0007cOS?-\u000blU\u0018?3\u000byRinl_:\u001a";
      v[26] = "g0>y\u000f2g0)%\u0003=}{);\u0003(z\nxdQc";
      v[27] = "\\\u0016Tz\u0007\u0019\\\u0016C&\u000b\u0016F]C8\u000b\u0003A,\u0012bR@";
      v[28] = "\u001d\neGLE\u001d\nr\u001b@J\u0007Ar\u0005@_\u00000#[\u0015\u0014";
      v[29] = "@pp\u0004PR@pgX\\]Z;gF\\H]J7\u0012\u000f\u000e";
      v[30] = "r|Sk\u0016>r|D7\u001a1h7D)\u001a$oF\u0012}Jn";
      v[31] = "O41%\u0013SQ<+jqOV!";
      v[32] = "oIH\n{noI_Vwau\u0002_Hwtrs\u000f\u0015$3%OPEet^\u0019\u0004\u0013 ";
      v[33] = "z\u0004+>MG\u000f$ 1\\\bn*+:XR\u001a";
      v[34] = "iGNG#d\u001cgEH2+}iNC6q\t";
      v[35] = "5rsVw_+zi\u0019\u001aE3\u007f`T-C0}v";
      v[36] = "^~Y\u001c5>UqHSV3@w";
      v[37] = "\u0017Ikb:^\tAq-VB\t{xw";
      v[38] = "6^\u0003\f\u0012\n6^\u0014P\u001e\u0005,\u0015\u0014N\u001e\u0010+dE\u001bNZ";
      v[39] = "\u0002\rQ\u001c:\u0015\u0002\rF@6\u001a\u0018FF^6\u000f\u001f7\u0016\u0007dN";
      v[40] = float.class;
      w[40] = "java/lang/Float";
      v[41] = "t~\u0002\u0013TBjv\u0018\\;El~\r>\u0013Dj";
      v[42] = "Dh@\u0002o\u0000DhW^c\u000f^#W@c\u001aYR\u0006\u001f1Q\u000enXMq\u001au?\u0007\u001f;";
      v[43] = "?E\b\u00058tJe\u0003\n);+k\b\u0001-a_";
      v[44] = "'\u000e*$,|'\u000e=x s=E=f f:4h2y%";
      v[45] = "?#W3\u00056!+M|d3!+N<J/";
      v[46] = "\u001bWt\u001e\n~nw\u007f\u0011\u001b1\u000fyt\u001a\u001fk{";
      v[47] = "KU,Jq>KU;\u0016}1Q\u001e;\b}$VojW$e";
      v[48] = "8J*XY\u0014.J/\u0002J\u00039\u0001,\u0004F\u0017(F;\u0013\r\u0005\u0011";
      v[49] = ",&\u0018b\u0012dY\u0006\u0013m\u0003+8\b\u0018f\u0007qL";
      v[50] = "Of<x\u0011\"Qn&7|8Ik/zK>Ji";
      v[51] = "qf>A^\u0011\u0004F5NO^eH>EK\u0004\u0011";
      v[52] = ".\u0013eB\u001e{8\u0013`\u0018\rl/Xc\u001e\u0001x>\u001ft\tJh&\u001fv\u0002\u0010%\u001a\u0004v\u001f\u0010b-\u0013";
      v[53] = "\"c\u0010/\u0018i4c\u0015u\u000b~#(\u0016s\u0007j2o\u0001dLz\t";
      v[54] = "%+/&\u0015=P\u000b$)\u0004r1\u0005/\"\u0000(E";
      v[55] = "\u0015Y)@\u0005X\u0003Y,\u001a\u0016O\u0014\u0012/\u001c\u001a[\u0005U8\u000bQL ";
      v[56] = "\"|%\u000b\u0017cW\\.\u0004\u0006,6R%\u000f\u0002vB";
      v[57] = "\u0002\t4YV\"\u0002\t#\u0005Z-\u0018B#\u001bZ8\u001f3rN\r{";
      v[58] = "\u0000\u0015\u001aW\u007f\u0018\u000b\u001a\u000b\u0018\u0002\u0000\u0018\u001d\u0002Q";
      v[59] = "`z\u0010t{+\u0015Z\u001b{jdtT\u0010pn>\u0000";
      v[60] = "v\u001f\f\u001eX\t`\u001f\tDK\u001ewT\nBG\nf\u0013\u001dU\f\u001aJ";
      v[61] = ",:1''4Y\u001a:(6{8\u00141#2!L";
      v[62] = "J@*-c\u0004?`!\"rK^n*)v\u0011*";
      v[63] = ",=A\u0013\n\u000625[\\W\u000749V\u001f\n 2.R\u0013I";
      v[64] = "2fk8e\u00152f|di\u001a(-|zi\u000f/\\-!1M";
      v[65] = "2Uy'\u0006\t\u0004py'\u0011U\b\u007fcl\u0011K\bjd\u001d@\u001f[/,";
      v[66] = "y=by\u0004Gy=u%\bHcvu;\b]d\u0007$oY\u0018";
      v[67] = "qk.4p\u001bqk9h|\u0014k 9v|\u0001lQm
      v[68] = "B\fI\rJf\\\u0004SB\u0002fF\u000eK\u0005\u000b}\u0006.P\u0002\u0017fE\bM";
      v[69] = "oGq3\u0015`oGfo\u0019ou\ffq\u0019zr}7%J?";
      v[70] = "YPUl\u0018\u0003,p^c\tLM~Uh\r\u00169";
      v[71] = "\u0001\u0003[v\f\b\u0001\u0003L*\u0000\u0007\u001bHL4\u0000\u0012\u001c9\u001daQSK\u0005C9\u0012\u00120T\u0016hR";
      v[72] = "N\u0015 b-8N\u00157>!7T^7 !\"S/b}rc";
      v[73] = "y\u0014 q]#y\u00147-Q,c_73Q9d.ag\u0006r";
      v[74] = "W\u0003J\u000494W\u0003]X5;MH]F5.J9\f\u0013ed\u001d\u0005RK'.fP\b\u001da";
      v[75] = "EI95\u000ff[A#zRg]M.9\u000fP@D#1Bg@Z";
      v[76] = "<(%TvQ\" ?\u001b\u0010E%!\u0000P,";
      v[77] = "\u001djXJbP\u0003bB\u0005*P\u0019hZB#KYM[E/Q\u001ed@";
      v[78] = "3vSB'&FVXM6i'XSF23S";
      v[79] = "e{6xi\u0014{s,74\u0015}\u007f!ti\"`v,|$\u0015`h3";
      v[80] = "~x[v\u00128\u000bXPy\u0003wjV[r\u0007-\u001e";
      v[81] = "1CG%u81CPyy7+\bPgy\",y\u0005;)f";
      v[82] = "YJY,7?GBCcQ+@Cb,i";
      v[83] = ">\u0007&UC_>\u00071\tOP$L1\u0017OE#=gL\u001a\u0004";
      v[84] = "WK[\u00079\u0012WKL[5\u001dM\u0000LE5\bJq\u0018\u001db";
      v[85] = "HuR<\u0013\u001c^uWf\u0000\u000bI>T`\f\u001fXyCwG\bj";
      v[86] = "m\u0015\n\u0015ovf\u001a\u001bZ\bts\u0011\u001b\u00113";
      v[87] = "F\u0006k[s\u00103&`Tb_R(k_f\u0005&";
      v[88] = "O\u0014\"t\fF:4){\u001d\t[:\"p\u0019S/";
      v[89] = "\u0006=/\u0006'd\u0010=*\\4s\u0007v)Z8g\u00161>Msu0";
      v[90] = "oi;;_l\u001aI04N#{G;?Jy\u000f";
      v[91] = "\u0001|;X\u001b\u0016\u0001|,\u0004\u0017\u0019\u001b7,\u001a\u0017\f\u001cF}NGG";
      v[92] = "O2C\u0001D9:\u0012H\u000eUv[\u001cC\u0005Q,/";
      v[93] = "!'D\u000be+*(UD\u00023.4S\b'\"";
      v[94] = "7h\n'>1BH\u0001(/~#F\n#+$W";
      v[95] = "59S\fr\u0011>6BC\u0010\u00121?";
      v[96] = "\"5b\u000fU^\"5uSYQ8~uMYD?\u000f$\u0014\u000e\u0006";
      v[97] = "4\u001a\r/N0A:\u0006 _\u007f 4\r+[%T";
      v[98] = "zRDq5@lRA+&W{\u0019B-*Cj^U:aRY";
      v[99] = "mI^!2\u001d\u0018iU.#Ryg^%'\b\r";
      v[100] = "^mH\b<&I#JO[xO#(\u000f&%\u001d1\u0014\u00044f\u0016S\u0013Ic&Do\u0018[ -&hU\f`\u007f\u001acGOk\u001d";
      v[101] = ";=\u0017V\u0000w-8\u0007_q\u007f.;n\u0004\f(x%R\u000f\u001eksGSE\u000bo}{\u0005\u0006\u001clC";
      v[102] = "tH&\u00137\fvNw\u000b\n\u0013vTk\bN\u001fhP\u0017\u001dr\u001ft\u001dw\u00064\u0007m,";
      v[103] = " ;8X8H>(2J\u0006W,99Qje{{c\f;2|?#I8\u000e*|4J\u0006";
      v[104] = "'mAJ_\t|p\u0001J2\u0003\u0018#O\\W\u0016i~\u0006Y_j(bWPN\u001bu+RX2";
      v[105] = "\t\u0001O\u0011\u001c<B\u001f\rD 1U\u00122\u0016Q^Q\u0005\u001d\u0001\u0010,S\n\u001d\u001f ";
      v[106] = "\u000bCEah\u0010\u0015POsV\u000f\u0007ADh:=P\u0003\u001e7jj\bCEe:\u0011\u0013XKmV";
      v[107] = "0;FTp5{6\\\u0016v[l8XKk7^n\u0015\u00134e\tjJNgb5)G@=[m<\u001aYh<l6AU\f";
      v[108] = ")4v=afq<m'p\t~9y;\u007f^)c-n,\t)4v=afq<m'p";
      v[109] = "on.m/Km?<.|;332<yW\u0001gpg#\nVe3d%Yjn!'.;m#vg|\u0007f15l\u001e\u0000+fu>\"\u000b9%~\\`\u0003i0+2#R6`N";
      v[110] = "Y/8P`\u0001\\$$\u000bw<\u0005y!\u0001aP7-gQ=\u0006`-a\u0001k@\fkf\r7M`";
      v[111] = "5\"*qP> v$km1!; |\u0001\u0003p|x&RT6>:{\u001771x#cm";
      v[112] = "\"\u001f\u0012\u000exu9\u0013\u0018O\u001e,$\u001d\u001eVr\u001esZF\u0000%I%\u0003\u0015S|2&\rG\u000e\u001et3\u001b\u0001\u000f\"\"p\f\u00021";
      v[113] = "#\u001e^ BB!\u0011^>r]3\b[>\t0#\u001e^ BB!\u0011^>r\r0\u000fMdN[s\u0018NZ";
      v[114] = "\tJ`G\u0001\u0003RW Gl\f6\r`@\u0013\u0018\u000bYmTP\u00056\teB\u0013^\n_&U\u0010`";
      v[115] = "&_\u0011yK`*\u0001Z{,u/\u0004\u0016wW\u000b&\u0011\u0014y\\swQ\u0013`,";
      v[116] = ".H\rk-\u001az\u001e\u0006~F\u0014zR\u0006t*&-\u0012W.zqhJXj}O(\u0015YzFHqE\u001ex-\u001c'N\u000b\u0013";
      v[117] = ">\b+c\u000f&hRrv\u0012Vy0) \b.~]y%\u001bn8";
      v[118] = "{\u0016rZ49~Btdt2tRu\u001f\n).RuZq\"q@gd";
      v[119] = "\f_*s@CHK%ppRXQ!\u007f\u001d(\\_*{@Z^P*ep\u0015ON9?LC\fY:\u0001";
      v[120] = "OF)L\u0019wN\u001a;\u0003\r\u001d\u0013N9\u001d\u001bq!\u001c~@G\u001dO^\"\u0001\u0015$\u0004^*\u001dB\u001dKY?\u0002B!\u001d\u001a(\u0001|s\u0017F&\u001aCl\f\u001c?}";
      v[121] = "\u0001v%I-<Eb*J\u001d6Dp3Ra0B\u001d Z\">I$0\u0003w;8";
      v[122] = "zT\u0010Nw5lQ\u0000G\u0006)oRi\u001c{j9LU\u0017i)2.\u0007Fc1e\u0011\u0018]9(\u0002";
      v[123] = "!!\u001f|)\u00029n\ntY^-`\r*5ly$Wsa;{aUv;\u0007ps\u0016}Y";
      v[124] = "E\u0012\u001elZ9\u0001JFsSR\u0015(\u001anB-\u0004\u0015NcVn\u0019(Mp_1\u001b\u0017Rk\u0005(|";
      v[125] = "<thdBJgi(d/D\u00033hcPQ>gew\u0013L\u00037maP\u0017?a.vS)";
      v[126] = "BZ*\u0010{\u0015\u0005\u0005j\u0013\u0005O\u0011\u00167\u0006i}GUmZ?*\u001dW%Pu\u0013\u0005\u00180X\u0005\u0015\u0012\u000f<X9V\u001f\u0001fa";
      v[127] = "SXk[o2J@fN\u0017*D@eD{\u0018\u0010\u0001>\u001e(O\u0013\u0003wZzqLQyS\u0017tT\u0004>A+\u007fFG5#";
      v[128] = "V\u0011~s*{CEpi\u0017tB\bt~{F\u0016N*'+\u0011\u0010\u001aqr.-S\u0017\u007f(\u0017*RL/{+!@\u000f$\u0019,l\u0017Ov%'~TD\u0014wvtL\u0013+hm.Ut";
      v[129] = "Q!Is\u000e1\n<\tsc6nfIt\u001c*S2D`_7n1Wi\u00005Q.L3\u0019R";
      v[130] = ">2t\u00011_k=3\u001e#9\u007f,uf6Rk+9\u00144]k5\t\u000f4U}a{\r;UcQ`\r3C7#b\u00023]\u0007";
      v[131] = "m6xp\u001dhxbvj gy/r}LU(h*'\u0010\u0002.l`cM<q>nj ";
      v[132] = "/!N\u0012\bit<\u000e\u0012e`\u0010fN\u0015\u001ar-2C\u0001Yo\u0010$L\u0014\u0018:u8\rR^\n";
      v[133] = "Ch{XoW\u0018u;X\u0002^|/{_}LA{vK>Q|r|Fe\u0005\u001ci:^|4";
      v[134] = "_^Z%3J\u000eW[z\r]d\n\u0018r6TX\u0001\n1=6";
      v[135] = "xj\u00009g\u000ey?U4st*=\u000f`f\u001f=ZRko\u000e1(\u0015kf\u0013}Z\u0002og\u000eq(\u0000`g\u0010A";
      v[136] = "\u0007|@W|u\u0002(Fi)p\n9C\b$l/([i+|\u0000?\u001a\u001b)s\u0000!*T8m\u0013{\u0016\u0002{z\u0010E";
      v[137] = "T{Vm6|\u0000-]x]y\fpYy\n.V \u0005\u0015g(\u001fdP+8z\u0011m";
      v[138] = "*n!H=X=h6ZS\f!c([\u0004[\u007f4p7j\u0007,?)]k[>p=";
      v[139] = "SNNlU\u000f\u0016@\u0018g^j\u0004F\u0012r\\=S\u001d@'\fjSNNlU\u000f\u0016@\u0018g^";
      v[140] = "g'\u0001x
      v[141] = "1,;90\u0012!un<AK16B=1WXp~*>\u0015d&===+";
      v[142] = "*\u0014f71i=ZdpV73L\u00060+jiH:;9)b*=vni0\u00166d-bR\u0011{3m0n\u001aipfR";
      v[143] = "-~\u001d_w\u0000vc]_\u001a\n\u00129\u001dXe\u001b/m\u0010L&\u0006\u0012=\u0018Ze].k[Mfc";
      v[144] = "A\u0012~;J(K\u0010&g. 1H8\u007fQ1\f\u001c5k\u0012,1\u00109f@wK\u000e*lRI";
      v[145] = "k\"}\u001c.u,}=\u001fP/8n`\n<\u001dl#:]hJk\"}\u001c.u,}=\u001fPq(*;\u000flz:i0miz>/l\u0017h/k\"xm";
      v[146] = "\bF@{'+O\u0019\u0000xYq[\n]m5C\u0006M\u00063Y/KN\u0006he$Y\r\r\nbi\u000eM_6i{MF=57q]O\u0001v:\u007f\u0007v";
      v[147] = "|\u0018z\u0004\u001aq;G:\u0007d+/Tg\u0012\b\u0019r\u0013=Idq,MlLX2!C6u";
      v[148] = "imX^,o2p\u0018^AgV*XY>tk~UM}iVhZX<<3t\u001b\u001ez\f";
      v[149] = "\u0010Mm\u0019l9Q\u0019x\u001e,YLIj\u0012v5~\u001f'M b)\u001d|\u0017~h[Jk\u000bp&)Jw\u0017r>\u0016UlMkY";
      v[150] = "TG.RvIH\u0006h\u0014FECVWF-@U\n%D\"@K:jU<S\u0011\u0006<\u0016+P/";
      v[151] = "qp\n\u0012Xl:nHGda-cj\u0011\u0000s-\u001f]\u0013\btpm_\u001c\bj@";
      v[152] = "BrN\u0006\\UG&H8\tSD\"^8\fVL(C\u0007\u0013M\u00161$";
      v[153] = "@9\u001d\u0006h\u0011J;EZ\f\u00190c[Bs\b\r7VV0\u00150;\u0019H=\u0000\t#V]5p";
      v[154] = "e<=\u0014,I>!}\u0014ACZ{=\u0013>Rg/0\u0007}OZ9?\u0012<\u001a?%~Tz*";
      v[155] = "Xv\u0014E\\A\\#\u0010\r6\u0015^f\nZZ'\t%[\r\rp\\ \u0014EO\bQ}Z\u00066";
      v[156] = "!k!h\u0012q$?'VTn6R\"=@iz  2@wJ; :V#89/:H\u0013#9',\u001ca!6'2,";
      v[157] = ":}-q\u0014{$n'c*d6\u007f,xFVa<|\"\u0010\u00019}-uFz\"f#}*<!y3!\u0016jbn0\u001f";
      v[158] = "d-\u001bR!\u0004%+\u0004\b2d8+\t\u000f-\b\n}EU{X]\u007f\u001c\u0014!\u0019=>H\u0001&Y]";
      v[159] = "u\u000e\u0007\u00079r ZB\u0019,\u0010)\u0006C\u0017:|\u001bP\u0004Ne(LPBOfrp[P\fm\u0010w\u0016\u0007L?,|\u0004DG]";
      v[160] = "7R\u0013H\u0000Il\u0000\u001b\u0003KqkR\u0006Z\u0015\u001dY\u0004G\u0001CH\u000e[\u0013\u0004\u0000\u0015iZ\u0019_\fq7QBDN\u001dwF\nJ\u000fq5BB\u0001\u0010M>P\u0001\nr";
      v[161] = "E\f~B\u0014']CkJd{IMl\u0014\bI\u001d\t4B_\u001eD\u000ev\u0010\u0003uHP=\u0012d\u007f\u0019C=\u0003]gVV5s";
      v[162] = "g\u007f\u001dBL\b$>\u001cA\\57\u0007T]JJ&:\u0000P^\t;\u0007TXP_fz\u0003B\bL \u0007";
      v[163] = "gN\u0017JS>8M\u000b\u0005\u0004\u000671L\nLy&\f\u0018\u0007X:;1\u001e\u000bX98\r\u0005\u0007Rx^";
      v[164] = "\u001c4X\b\u0001F[k\u0018\u000b\u007f\u0017CiA\u0015(H\u001b4\u001dyD\u0004\u001a?GEO\u0016Y4";
      v[165] = "/;3\t I4}+\u0010\u0011H7.(\u0007mN1C;\u000f.@:z+V{EK";
      v[166] = "\b\u0018QU\n\u0010\u001dL_O7\u001f\u001c\u0001[X[-MF\u0003\u0003\u0007zJ\u0000\u0003\u0004UFA\u0012@\u000f7A\fE\u0000]\u000bJ\u001e\u0006\u000b?";
      v[167] = "Cu\u001c~\u001eEH*\u000el _M&\u001bz\\YKK\br\u001fW@r\u0018+JR1";
      v[168] = "\t7xj}VR*8j\u0010V6pxmoM\u000b$uy,P6'fpsR\t8}*j5";
      v[169] = "{\u001b,LbA \u0006lL\u000fKD\\,KpZy\b!_3GD^.\u000b4@xU<H?\"";
      v[170] = "\u0007R\u0017Ck\u0017\u0003\u0007\u0013\u000b\u0001C\u0001B\t\\mq\\\u0000S\u0007\u0001\u001f\u0000\\\u000bInG\bG\u0011X\u0001\u001d\u0011\u0006RY=\u0016\u0003EY;:[T\u0005\u000b\u00071I\u0017\u000ei\u0000|\u001eW\\U\u000bn]\\>";
      v[171] = "_r`\u0014?mY\"w\u0011Un[\u007foA\u0002:\u000b*5\u001cUaDse\u0013/\u007fWyw";
      v[172] = "XZ3\u0003M{\u0003]>\u0006\u0017\u0000\u0000Z0$@d\u001cQLAT8Z^pJF{Q<";
      v[173] = "5\u0001k`&/3Q|eL,1\fd5\u001bxaY>iL!1\u0018k;1<n\u001cq";
      v[174] = "\u0017Bt@\u0012Z\u0007\u001b!Ec\u0005\u0013S7)\n\b\u0012Y{[\b\u0007\u0012GK";
      v[175] = "\u000e%w\r6Q\u0019kuJQ\u0001\u0011`\u0017\u000bn\u0018\u000fv)T<\u0016\u0006\u001b-\u000e#\u0013\u001b%r\\-\u001av";
      v[176] = "I!W\u0007P~\u0012<\u0017\u0007=tvfW\u0000BeK2Z\u0014\u0001xvfS\u0007Q#\u0006-C\u0018Vsv";
      v[177] = "c5!Yw\u0019f=3P&c;!\u0013Z7\u001f+ZcE5\u001cdf5\u0006\"\u001fZ";
      v[178] = "\u000e/-Z;\u0002\u0015i5C\n\t\r10Tk\u0004\u0011W%Vf\u0018Z%'Yf\u0006jj6Gu\\V<uPvb";
      v[179] = "\f\r>Z5\"J\n2\u00068NTJ\u0013R12D1cM31\u000b\r5\u000e$25";
      v[180] = "m\u000f/^\u007f 9Y$K\u0014%5\u0004 JCroT~&.t&\u0010)\u0018q&(\u0019";
      v[181] = "@\u0011\u0003\u0004 1\u0014G\b\u0011K4\u0018\u001a\f\u0010\u001ccBJQ|qe\u000b\u000e\u0005B.7\u0005\u0007";
      v[182] = "\\\u001cIjL9^M[)\u001fI\u0000AU;\u001a%2\u0015\u0013cEwe\u0015\u0018:\u0017q[\u001cP&\u001f;e";
      v[183] = "\u00031?z:%\u0014\u007f==]d\u001cr9*]d\u0002u?<>cDl'FfcC4=zmq\u0000?_";
      v[184] = "\u000e:(\u00133z\u000ff:\\'\u0010R28B1|`d}\u001ei.7at_'n\b&+\u001f$\u0010";
      v[185] = "\u0019.bi_\u0011\u0004qfs=\t\u00173{eQ;Cq$<\rl\u001b1zl\u0003\u0016\u0005\"p~=\b\u0013qifZ\t\u0019*e\u0002\u0000\u0016\u00000%>VU\u00173\u001b";
      v[186] = "\u001f\u001clKi!\u0006\u0004a^\u00119\b\u0004bT}\u000b\\E9\f-\\_GpJ|b\u0000\u0015~C\u0011&\u001c\u0002bIr!Z\u001bz3";
      v[187] = "rVhXL^eP\u007fJ\"\ny[aKu]&\u0006:'I\bfNo\u0016M]b\u0006";
      v[188] = "\u0001/\u007f>=V\u00187r+EN\u00167q!)|Bv*v{+\u00012k&?H\u0006tr>E\u0010\u0006s*$y\u001b\u00140!F";
      v[189] = "3\u001f_2 \u00111NMqsaoBCcv\r]\u0016\u0005;)]\n\u0011\u000f~`\u001f5VP>ca";
      v[190] = "8-l\"\u000e\u000b by*~W4l~t\u0012e`($-E2bm&(\u001c\u000ei\u007fe#~";
      v[191] = "j|mfC\u0018{9+d&\u0015\u0007{(sY\u0002:/%g\u001a\u001f\u0007,6nE\u001d83-4\\z";
      v[192] = "\u0000\u000f\u0014=f1\u001e\u001c\u001e/X.\f\r\u001544\u001c[OOjeK\\\u000b\u000f,fw\nH\u0018/X";
      v[193] = "V\u001dG^\fm\u0004_Y^K\u0017\u0017\t]\u001e\u0019S\b\u0006HeM+\u000f\r[\t\u000b,\u0003QVeKy\n\u000b\u001eY\bt\u0004Q'";
      v[194] = "O|\u000bij`\u0014`\u001b%v\u000b\u0013r\u001c9lg!$]a3;v{\tgyo\u0011z\u0003<u\u000bMbXbi7Fp\u001bi\u000b";
      v[195] = "\u000boG\u001bx/Je\n\u001eCp\u0018};\u000e(s\u000f1I\f's\u0011\u0001";
      v[196] = "\u00129j[H\u000e\u00171xR\u0019tB:yt\u0014\u0010+$+@\u001dJP/tR\u000ft\u0016,oBNH@oxAp";
      v[197] = "\u001d0H\u0005biF-\b\u0005\u000fd\"wH\u0002pr\u001f#E\u00163o\"sM\u0000p4\u001e%\u000e\u0017s\n";
      v[198] = "t$=\u0015PO?)'WV!#+2\u000e@vvwfV\u0017!t$=\u0015PO?)'WV";
      v[199] = "\u001eIg\u0016d\rO@fIZ\u001b%\u001d%Aa\u0013\u0019\u00167\u0002jq";
      v[200] = "*Y\u0013z<BzHUeCR\u0016\u001b\u0013e<C+O\u001eq\u007f^\u0016\u001f\u0016g<\u0005*IUp?;";
      v[201] = "A*(v\u000eeVd*1i%XrHpV,@yv/\u0004\"I\u0014ru\u001b'T*-'\u0015.9";
      v[202] = "DI@!|gA\u001dF\u001f#~b\u0015Rc3\u0005\u0012\nP`|9DIGcB";
      v[203] = "}X(mCU|\r}`W/*\u000f9\u001dFD$hz:J@u\u001a--VN;h-1JL#W2*\u0010UD";
      v[204] = "\u001a\b\u0017+\u0015\u0014\u0002G\u0002#eH\u0016I\u0005}\tzB\r_$Y-@H]!\u0007\u0011KZ\u001e*e";
      v[205] = "n\u000b\r(\u001a\u000fw\u0013\u0000=b\u0017y\u0013\u00037\u000e%-Q_k\\r.P\u0011)\u000fLq\u0002\u001f bH+\u001d\u001a=\\\u0017y\u0013\u0013PXMf\u0016\u000en\u0007\u001fh\u001fcj]\u0000m\u0002]5\u000f\u000edo";
      v[206] = "x\u000f/<s:|Z+t\u0019n~\u001f1#u\\#_i~\u00190n[j&%;|\u0018aD\"v+X3x)dhSQ}p:i\u000648~lb\rQycql]m/ fochty:\"\u0013j%kyqc";
      v[207] = "\u0005p\u00019}'^mA9\u0010!:7\u0001>o<\u0007c\f*,!:`\u001f#s#\u0005\u007f\u0004yjD";
      v[208] = "gvF0}K$'\u0019`\u0018@t2\u00199tr%vCe %g \u0005\"#\u0015&*H'\u0018";
      v[209] = "\b~+\b{aLj$\u000bKc]yG\u0013 fK%5\u0011/fU\u0015z\u00001u\u000f),C&v1";
      v[210] = "?MU=\u000fU&\\\ts2Q.Z\u000bk^cz\u001eR4\t4x[S7P\bsI\u0010<2\u000f>\u001ePn\u000e\u0004,][\f\tI{\u001d\t0\u0002[8\u0016kpY\nr\u001b\niHV<&";
      v[211] = "\u001a'>>i\n]x~=\u0017[Ez'#@\u0004\u001d'zO,H\u001c,!s'Z_'";
      v[212] = "/_q0k|tC&lsG\u007f9u>m=&Kw1m#\u0016";
      v[213] = "{=8 AL~i>\u001e\u0010Cl\u0004;u\u0013T v9z\u0013J\u0010m9r\u0005\u001ebo6r\u001b.";
      v[214] = "\fH>o\u0010\u0010WU~o}\u00113\u000f>h\u0002\u000b\u000e[3|A\u00163X u\u001e\u0014\fG;/\u0007s";
      v[215] = ")\u000f\u0000\u0003IPy\n\u0013C\u000f=y7G\u0004HBh\n\u0013\t\\\u0001u7\u0010\u001aU^w\b\u000f\u0001\u000fG\u0010";
      v[216] = "-\u001el2FZ)Khz,\u000e+\u000er-@<vI(r,\n{\u0000#:\u0015\u00124\u0015+JM\u0015'\u001c,0S\u0006-\u000e\u0012";
      v[217] = ">$F3e\u0006?q\u0013>q|ipDrL\u0015\u007f\u0014\u0014o1M8,@ej\u000ee\u0014\u0014>bAkn\u0015k7L\u007f\u0014";
      v[218] = "@\u0004;|\u001c|EP=BOxWG \u0019Ob+\u0004:.P.@@.!S\u001e";
      v[219] = "\u0012E#sE\u0011\u0017\u0011%M\u0014\u001e\u0005;3\u0001\u0016\u001d\u0010\u0001-1{\u001a\u0012\u00103}\t\u0018\u001d\u0010-M\u0012\u0018\u0015\u0006y?\u0010\u0017\u0015\u0018I$\u0010\u001f\u0003L;&\u001f\u001f\u001d|";
      v[220] = "_X\u001ck`i\u0014H\u0003l0\u0019\u0007_\u000e}7e\u0001Ycn?&\u000fRZ~fs\n#";
      v[221] = "RH%\u007fk\u0002\u0010P/c;f\u0017MN~zfREqiv\u0014\u0015Ext:f";
      v[222] = "2\u00136\u001a\f\u0003)U.\u0003=\u0018*\u0011:\u0014Xco[<@Q\u0019n\u000eiMEc";
      v[223] = "!@};\u0001Dj@u'V}}Pf'\u000f\u0011O\u0006\"~VF\u0018\u0004&'\u0005\u0001tB!+Y\f\u0018\u0004g \u0014\u0014!Og(\bC\u0018";
      v[224] = ".,x-x\u0017;xv7E\u0018:5r )*ns,y|}h'w,|A+*yvEF*q)%yM82\"G~\u0000orp{u\u0012,y\u0012x+\u0018<p.;&\u0016fI";
      v[225] = "\tiB\r\u0006-M}M\u000e6=LxC\u0016SF\t2EBZ<\bg\u0010ONF";
      v[226] = "&*r-o\u000b+w<n\u0016\u0016$ll2z$s!5j)sp+idpNu u?gs";
      v[227] = "\r;K=)^Z?\u001d*o%]\u0005I%.ZL8\u001d(:\u0019Q\u0005\u001bc<\u001b\ng\u001e7:%";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = v[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(w[var4]);
            v[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            v[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  v[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1050530935933497L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  v[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1050530935933497L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        v[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1050530935933497L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 240;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 228;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 106;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 223;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 75;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 199;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 240;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 228;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 106;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e_",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Iterable invokeBinding1(boolean var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "iterator",
                  SourceSupport.methodType("(Z)Ljava/lang/Iterable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/util/Iterator;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/e_", "lambda$chunks$0", "(Z)Ljava/util/Iterator;"),
                  SourceSupport.methodType("()Ljava/util/Iterator;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Iterable)var2.invokeExact((boolean)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Consumer invokeBinding2(ClientWorld var0, Set var1) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Lnet/minecraft/client/world/ClientWorld;Ljava/util/Set;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/e_",
                     "lambda$doMathOnChunk$2",
                     "(Lnet/minecraft/client/world/ClientWorld;Ljava/util/Set;Lnet/minecraft/util/math/ChunkPos;)V"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/ChunkPos;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var3.invokeExact((ClientWorld)var0, (Set)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Function invokeBinding3(OreSimulation var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/e_;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/e_",
                     "lambda$doMathOnChunk$3",
                     "(Lnet/minecraft/registry/RegistryKey;)Ljava/util/stream/Stream;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/registry/RegistryKey;)Ljava/util/stream/Stream;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((OreSimulation)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Consumer invokeBinding4(Set var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/util/Set;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/e_",
                     "lambda$doMathOnChunk$1",
                     "(Ljava/util/Set;Lnet/minecraft/registry/entry/RegistryEntry;)V"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/registry/entry/RegistryEntry;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((Set)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
