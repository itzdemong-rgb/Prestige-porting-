package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;

public class Parkour extends Module {
   private MinMaxSetting a;
   private static final long k = 115885295580491L;
   private static final Object[] l = new Object[40];
   private static final String[] m = new String[40];

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 71340533356204L ^ 77178086428253L;
      var10001 = 71340533356204L ^ 66723953288048L;
      int var8 = Event.bReturningInt();
      MinecraftClient var11 = b;
      ClientPlayerEntity var12 = var11.player;
      boolean var10000 = var12.isOnGround();
      int var67 = var8;
      boolean var66 = var10000;
      boolean var58 = var66;
      boolean var57 = var66;
      if (var67 == 0) {
         boolean var68 = var57;
         if (!var68) {
            return;
         }

         MinecraftClient var14 = b;
         GameOptions var15 = var14.options;
         KeyBinding var16 = var15.jumpKey;
         boolean var69 = var16.isPressed();
         var58 = var69;
      }

      int var71 = var8;
      boolean var70 = var58;
      boolean var60 = var70;
      boolean var59 = var70;
      if (var71 == 0) {
         boolean var72 = var59;
         if (var72) {
            return;
         }

         MinecraftClient var19 = b;
         ClientPlayerEntity var20 = var19.player;
         var60 = var20.isSneaking();
      }

      MinecraftClient var65;
      label57: {
         int var74 = var8;
         boolean var73 = var60;
         boolean var64 = var73;
         boolean var61 = var73;
         if (var74 == 0) {
            boolean var75 = var61;
            if (var75) {
               return;
            }

            int var77 = var8;
            MinecraftClient var76 = b;
            var65 = var76;
            MinecraftClient var62 = var76;
            if (var77 != 0) {
               break label57;
            }

            MinecraftClient var78 = var62;
            MinecraftClient var63 = var78;
            MinecraftClient var23 = var63;
            GameOptions var24 = var23.options;
            KeyBinding var25 = var24.sneakKey;
            boolean var79 = var25.isPressed();
            var64 = var79;
         }

         boolean var80 = var64;
         if (var80) {
            return;
         }

         var65 = b;
      }

      MinecraftClient var27 = var65;
      ClientPlayerEntity var28 = var27.player;
      Box var9 = var28.getBoundingBox();
      double var32 = -0.5;
      Box var29 = var9;
      Box var83 = var29.offset(var30, var32, var34);
      MinMaxSetting var85 = this.a;
      Object[] var37 = new Object[]{7504101316849L};
      MinMaxSetting var36 = var85;
      double var86 = -var36.fReturningFloat(var37) / 100.0;
      MinMaxSetting var10003 = this.a;
      Object[] var39 = new Object[]{7504101316849L};
      MinMaxSetting var38 = var10003;
      double var45 = -var38.fReturningFloat(var39) / 100.0;
      double var41 = var86;
      Box var40 = var83;
      Box var10 = var40.expand(var41, var43, var45);
      int var81 = var8;
      if (var81 == 0) {
         MinecraftClient var47 = b;
         MinecraftClient var48 = b;
         Box var51 = var10;
         ClientPlayerEntity var50 = var48.player;
         ClientWorld var49 = var47.world;
         Iterable var52 = var49.getBlockCollisions((Entity)var50, var51);
         Iterator var53 = var52.iterator();
         boolean var82 = var53.hasNext();
         if (var82) {
            return;
         }

         Object[] var56 = new Object[]{136670736201180L};
         KeyBindingUtil.aReturningVoid(var56);
      }
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 61;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 34;
            yield var17;
         }
         case 3 -> {
            byte var18 = 12;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 49;
            yield var20;
         }
         case 6 -> {
            byte var21 = 14;
            yield var21;
         }
         case 7 -> {
            byte var22 = 3;
            yield var22;
         }
         case 8 -> {
            byte var23 = 37;
            yield var23;
         }
         case 9 -> {
            byte var24 = 22;
            yield var24;
         }
         case 10 -> {
            byte var25 = 0;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 42;
            yield var27;
         }
         case 13 -> {
            byte var28 = 62;
            yield var28;
         }
         case 14 -> {
            byte var29 = 35;
            yield var29;
         }
         case 15 -> {
            byte var30 = 31;
            yield var30;
         }
         case 16 -> {
            byte var31 = 46;
            yield var31;
         }
         case 17 -> {
            byte var32 = 21;
            yield var32;
         }
         case 18 -> {
            byte var33 = 26;
            yield var33;
         }
         case 19 -> {
            byte var34 = 19;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 25;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 6;
            yield var38;
         }
         case 24 -> {
            byte var39 = 11;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 47;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 51;
            yield var44;
         }
         case 30 -> {
            byte var45 = 57;
            yield var45;
         }
         case 31 -> {
            byte var46 = 38;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 30;
            yield var48;
         }
         case 34 -> {
            byte var49 = 53;
            yield var49;
         }
         case 35 -> {
            byte var50 = 55;
            yield var50;
         }
         case 36 -> {
            byte var51 = 24;
            yield var51;
         }
         case 37 -> {
            byte var52 = 63;
            yield var52;
         }
         case 38 -> {
            byte var53 = 9;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 60;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 27;
            yield var58;
         }
         case 44 -> {
            byte var59 = 5;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 32;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 4;
            yield var63;
         }
         case 49 -> {
            byte var64 = 28;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 16;
            yield var66;
         }
         case 52 -> {
            byte var67 = 7;
            yield var67;
         }
         case 53 -> {
            byte var68 = 2;
            yield var68;
         }
         case 54 -> {
            byte var69 = 18;
            yield var69;
         }
         case 55 -> {
            byte var70 = 1;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 59;
            yield var73;
         }
         case 59 -> {
            byte var74 = 43;
            yield var74;
         }
         case 60 -> {
            byte var75 = 36;
            yield var75;
         }
         case 61 -> {
            byte var76 = 41;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 45;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "6BJ\u001c2\u00176B]@>\u0018,\t]^>\r+x\f\u0001g";
      l[1] = double.class;
      m[1] = "java/lang/Double";
      l[2] = "'&\r0|t1&\bjoc&m\u000blcw7*\u001c{(e\u0006";
      l[3] = int.class;
      m[3] = "java/lang/Integer";
      l[4] = "G\u0007ne\u0012\u001eL\b\u007f*u\u0006H\u0014yfP\u0017";
      l[5] = "&U!\u001coD8];S\bE)F6\t.C";
      l[6] = "{\u0006:\u001bZ@{\u0006-GVOaM-YVZf<}\u0004\u0007";
      l[7] = "M8-U\u000bWM8:\t\u0007XWs:\u0017\u0007MP\u0002jJS";
      l[8] = "r\n g6*d\n%=%=sA&;))b\u00061,b<w";
      l[9] = "))%'*U\"&4hIX7+;\u0003|Z&8'/kW";
      l[10] = "$ \u001e0d\u0005$ \tlh\n>k\trh\u001f9\u001aY.=";
      l[11] = "h\u0004\u007fp2vh\u0004h,>yrOh2>lu><ji";
      l[12] = boolean.class;
      m[12] = "java/lang/Boolean";
      l[13] = "CFCud\u0016CFT)h\u0019Y\rT7h\f^|\u0001h1";
      l[14] = "k9\\xT\u007fk9K$XpqrK:Xev\u0003\u0019d\u0000!";
      l[15] = "t\u001d\u0002t%2b\u001d\u0007.6%uV\u0004(:1d\u0011\u0013?q&\\";
      l[16] = "<Hip3qIhb\u007f\">(fit&d\\";
      l[17] = float.class;
      m[17] = "java/lang/Float";
      l[18] = "gT/skTqT*)xCf\u001f)/tWwX>8?Gq";
      l[19] = "W\u0004\"\\\u0013D\"$)S\u0002\u000bC*\"X\u0006Q7";
      l[20] = void.class;
      m[20] = "java/lang/Void";
      l[21] = "\nW\u0014>]!\u0001X\u0005q</\nS\u0001+";
      l[22] = "|6\u0016W<Se3\u00150#Qkn\u000e\\\u0011\u0005/6X0!M+n\u0017\u0000)Rm\u000e\u000eAz\\i>\u0006^<<p\u007fUP8\fx`\u00130-\u0004hi\u0013_4\u0001k\u000e";
      l[23] = "52bI\r2u~\"Sn`\ft?\b\tsi'9G\u0003\n";
      l[24] = "(N\n\u0012XMp\u0006NR>Io\u001b\b\u0000BOivNS\\Hh\u001c\u001b\fWS\u0013";
      l[25] = "A\u0007pA/D\u0017\u0001cM\u0016I\u001c\u0001{MA\u001eC]'!+JC\u0001bX+K\u0012\r";
      l[26] = "}<r\u0012{B?(\u007f\u000bET@f`RyE|b1\u0006\"=~5=^=\u0001zdi\u0005E";
      l[27] = "P3;54\u0015P2j9I\u0002\f3a4\u001eU\\f>Xv\fQdw5;\u0014\u00112";
      l[28] = "l*So\fJ`uM0`B1lIi\fpa/\u00103`\u00179*@d\u001f\u0018\")\u0010\u000e";
      l[29] = "i8\u0001/=\u0011eg\u001fpQ\u00194~\u001b)=+d2A\u007fQ\u0017a}\u001c4>\u000ed~{";
      l[30] = "8\u001dJ\u0017Hi8\u001c\u001b\u001b5~d\u001d\u0010\u0016b)5KNz\np9J\u0006\u0017Ghy\u001c";
      l[31] = "xPd(13&\u0007/>Uk$F\u007f=9Ys\u0002/co\u000e \u0007&`(3,]z0UeqEx :|tF\u001famv2\\z9%2r:";
      l[32] = "W\"hdNWN'k\u0003QU@zpoc\t\f+\u0017dE\u0004\\d'lZB<}f?TF\fuyy4_M&w}\u0004WR`\u0017h\fG[`xq\tD<";
      l[33] = "[9\"wf:\r?1{_7\u0006?){\b`Ybr\u0017n3\u001c )*0dW6";
      l[34] = "*CKC\u000f\b&\u001cU\u001cc\u0000w\u0005QE\u000f2 E\u0001\u0018Se*\u001c\u000bK\t\u001a%\u0007\b\u001bc";
      l[35] = "F\u007f-u~l\u0010y>yGa\u001by&y\u00106E.~\u0015w5\u0000u.x{j\u001e*";
      l[36] = "J\u00061$gN@\u00045\"\u0006I#\u00164q\u007f\u001a\u0018G;s?'I\u0004{.h@M\u001ei \u0006";
      l[37] = "D\u0004qo1\u0005\t\u001c19C\r\u0016\u0018-2/?BXviCX\u001e^$?<W\u0005]tU";
      l[38] = "r}\u0007\u0007\u0014^)4\r\u0010{W\u0019hY\\\u0002\u0003\"9V^B>td_PK\u0005!o\u001a[{";
      l[39] = "?oF%B>j0M>94j.bReturningVoid(I(\u0003eA\u007fP>|jZ|\u0000T";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1535599297467136L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1535599297467136L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1535599297467136L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 229;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 203;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 79;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 207;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 223;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 219;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 229;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 203;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 79;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fa_C0272",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fa" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
