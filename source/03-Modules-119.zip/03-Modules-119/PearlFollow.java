package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.client.management.TargetManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.util.projectile.PearlFollowProjectile;
import dev.zprestige.prestige.client.modules.state.PearlPathSample;
import dev.zprestige.prestige.client.modules.state.PearlFollowSolution;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class PearlFollow extends Module implements RotationSource {
   public static boolean a;
   private FloatSetting c;
   private FloatSetting d;
   private FloatSetting e;
   private FloatSetting f;
   private MinMaxSetting g;
   private MinMaxSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private Set k;
   private ElapsedTimer l;
   private ElapsedTimer m;
   private int n;
   private Vec3d o;
   private static final int p;
   private static final float q = 1.5F;
   private static final float r = -85.0F;
   private static final float s = 85.0F;
   private static final float t = 2.0F;
   private static final float u = 0.2F;
   private static final float v = 2.2F;
   private static final float w = 6.0F;
   private static final int x;
   private static final double y = 0.25;
   private static final long z = 52293612455223L;
   private static final long[] A;
   private static final Integer[] B;
   private static final Map C = new HashMap(13);
   private static final Object[] D = new Object[178];
   private static final String[] E = new String[178];

   public PearlFollow() {
      super();
      long var10001 = 104647827594762L ^ 68340030318883L;

      this.k = new HashSet();
      this.l = new ElapsedTimer(106698256430889L);
      this.m = new ElapsedTimer(106698256430889L);
      this.n = -1;
      this.o = null;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var7 = CombatProfile.Mace;
      CombatProfile var6 = CombatProfile.UHC;
      CombatProfile var5 = CombatProfile.Sword;
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4, var5, var6, var7);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
      Set var8 = this.k;
      var8.clear();
      this.o = null;
      this.n = -1;
      a = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      long var6 = var2 ^ 99766400949268L;
      int var10000 = Event.bReturningInt();
      RotationManager var10001 = Prestige.o;
      Object[] var10 = new Object[]{this, var4};
      RotationManager var9 = var10001;
      var9.eReturningVoid(var10);
      int var8 = var10000;
      int var20 = var8;
      int var19 = this.n;
      int var18 = var19;
      int var17 = var19;
      if (var20 == 0) {
         // int var21 = var17;
         if (var21 != var22) {
            MinecraftClient var12 = b;
            ClientPlayerEntity var23 = var12.player;
            if (var23 != null) {
               var10000 = this.n;
               Object[] var10003 = new Object[]{null, var6};
               var10003[0] = var10000;
               Object[] var14 = var10003;
               InventoryUtil.aReturningVoid(var14);
            }
         }

         Set var16 = this.k;
         var16.clear();
         this.o = null;
         this.n = -1;
         var18 = 0;
      }

      a = dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 71883416830846L ^ 55710571134257L;
      var10001 = 71883416830846L ^ 113893894777726L;
      var10001 = 71883416830846L ^ 60810705195266L;
      var10001 = 71883416830846L ^ 111916379750063L;
      var10001 = 71883416830846L ^ 638994564616L;
      var10001 = 71883416830846L ^ 59855511640325L;
      int var16 = Event.bReturningInt();
      int var142 = var16;
      MinecraftClient var141 = b;
      MinecraftClient var109 = var141;
      MinecraftClient var108 = var141;
      if (var142 == 0) {
         MinecraftClient var26 = var108;
         ClientWorld var143 = var26.world;
         if (var143 == null) {
            return;
         }

         MinecraftClient var144 = b;
         var109 = var144;
      }

      MinecraftClient var29 = var109;
      ClientPlayerEntity var145 = var29.player;
      if (var145 != null) {
         int var119;
         label161: {
            int var148 = var16;
            // int var146 = this.n;
            int var116 = var146;
            byte var117 = var147;
            int var110 = var146;
            byte var111 = var147;
            if (var148 == 0) {
               int var114;
               label148: {
                  byte var150 = var111;
                  int var149 = var110;
                  if (var149 != var150) {
                     ElapsedTimer var10000 = this.m;
                     Object[] var33 = new Object[]{this.h, 130913203968635L};
                     ElapsedTimer var32 = var10000;
                     byte var202 = ((byte)((var32.bReturningBoolean(var33)) ? 1 : 0));
                     int var152 = var16;
                     byte var151 = var202;
                     var114 = var151;
                     byte var112 = var151;
                     if (var152 != 0) {
                        break label148;
                     }

                     byte var153 = var112;
                     byte var113 = var153;
                     byte var154 = var113;
                     if (var154 != 0) {
                        int var203 = this.n;
                        Object[] var10003 = new Object[]{null, 72518082610550L};
                        var10003[0] = var203;
                        Object[] var36 = var10003;
                        InventoryUtil.aReturningVoid(var36);
                        this.n = -1;
                     }
                  }

                  var114 = this.n;
               }

               int var156 = var16;
               int var155 = var114;
               int var118 = var155;
               int var115 = var155;
               if (var156 != 0) {
                  int var163 = var118;
                  var119 = var163;
                  break label161;
               }

               // int var157 = var115;
               var116 = var157;
               var117 = var158;
            }

            byte var160 = var117;
            int var159 = var116;
            if (var159 == var160) {
               Vec3d var161 = this.o;
               if (var161 == null) {
                  var119 = 0;
                  break label161;
               }
            }

            byte var162 = 1;
            var119 = var162;
         }

         a = dev.prestige.recovery.SourceSupport.asBoolean(var119);
         HashSet var17 = new HashSet();
         MinecraftClient var41 = b;
         ClientWorld var42 = var41.world;
         Iterable var43 = var42.getEntities();
         Iterator var18 = var43.iterator();

         while (true) {
            Iterator var44 = var18;
            boolean var164 = var44.hasNext();
            if (var164) {
               Iterator var45 = var18;
               Entity var19 = (Entity)var45.next();
               int var166 = var16;
               Entity var165 = var19;
               Entity var123 = var165;
               Entity var120 = var165;
               if (var166 == 0) {
                  boolean var204 = var120 instanceof EnderPearlEntity;
                  int var168 = var16;
                  boolean var167 = var204;
                  boolean var121 = var167;
                  if (var168 != 0) {
                     break;
                  }

                  boolean var169 = var121;
                  boolean var122 = var169;
                  boolean var170 = var122;
                  if (!var170) {
                     continue;
                  }

                  var123 = var19;
               }

               EnderPearlEntity var20 = (EnderPearlEntity)var123;
               EnderPearlEntity var48 = var20;
               int var49 = var48.getId();
               Integer var51 = var49;
               HashSet var50 = var17;
               var50.add(var51);
               Set var205 = this.k;
               EnderPearlEntity var52 = var20;
               int var53 = var52.getId();
               Integer var55 = var53;
               Set var54 = var205;
               boolean var206 = var54.contains(var55);
               int var172 = var16;
               boolean var171 = var206;
               boolean var124 = var171;
               if (var172 == 0) {
                  boolean var173 = var124;
                  if (var173) {
                     continue;
                  }

                  var205 = this.k;
                  EnderPearlEntity var57 = var20;
                  int var58 = var57.getId();
                  Integer var60 = var58;
                  Set var59 = var205;
                  boolean var125 = var59.add(var60);
               }

               EnderPearlEntity var61 = var20;
               Entity var21 = var61.getOwner();
               int var175 = var16;
               Entity var174 = var21;
               Entity var127 = var174;
               Entity var126 = var174;
               if (var175 == 0) {
                  boolean var176 = var126 instanceof PlayerEntity;
                  if (!var176) {
                     continue;
                  }

                  var127 = var21;
               }

               PlayerEntity var22 = (PlayerEntity)var127;
               MinecraftClient var63 = b;
               ClientPlayerEntity var65 = var63.player;
               PlayerEntity var64 = var22;
               byte var208 = ((byte)((var64.equals(var65)) ? 1 : 0));
               int var178 = var16;
               byte var177 = var208;
               byte var129 = var177;
               byte var128 = var177;
               if (var178 == 0) {
                  byte var179 = var128;
                  if (var179 != 0) {
                     continue;
                  }

                  SocialsManager var209 = Prestige.g;
                  PlayerEntity var67 = var22;
                  Text var68 = var67.getName();
                  Object[] var70 = new Object[]{var68.getString(), 40309233401297L};
                  SocialsManager var69 = var209;
                  var129 = ((byte)((var69.aReturningBoolean(var70)) ? 1 : 0));
               }

               int var181 = var16;
               byte var180 = var129;
               byte var131 = var180;
               byte var130 = var180;
               if (var181 == 0) {
                  byte var182 = var130;
                  if (var182 != 0) {
                     continue;
                  }

                  BooleanSetting var72 = this.j;
                  Boolean var73 = (Boolean)var72.aReturningObject();
                  var131 = ((byte)(((java.lang.Boolean)(var73)).booleanValue() ? 1 : 0));
               }

               label123: {
                  int var184 = var16;
                  byte var183 = var131;
                  int var135 = var183;
                  byte var132 = var183;
                  if (var184 == 0) {
                     byte var185 = var132;
                     if (var185 != 0) {
                        TargetManager var210 = Prestige.n;
                        Object[] var76 = new Object[0];
                        TargetManager var75 = var210;
                        PlayerEntity var23 = var75.aReturningPlayerEntity(var76);
                        int var187 = var16;
                        PlayerEntity var186 = var23;
                        PlayerEntity var134 = var186;
                        PlayerEntity var133 = var186;
                        if (var187 == 0) {
                           PlayerEntity var188 = var133;
                           if (var188 == null) {
                              continue;
                           }

                           var134 = var22;
                        }

                        PlayerEntity var78 = var134;
                        UUID var211 = var78.getUuid();
                        PlayerEntity var79 = var23;
                        UUID var81 = var79.getUuid();
                        UUID var80 = var211;
                        boolean var189 = var80.equals(var81);
                        if (!var189) {
                           continue;
                        }

                        int var190 = var16;
                        if (var190 == 0) {
                           break label123;
                        }
                     }

                     MinecraftClient var83 = b;
                     PlayerEntity var85 = var22;
                     ClientPlayerEntity var84 = var83.player;
                     float var212 = var84.distanceTo((Entity)var85);
                     FloatSetting var86 = this.c;
                     Float var87 = (Float)var86.aReturningObject();
                     float var221;
                     int var191 = (var221 = var212 - var87) == 0.0F ? 0 : (var221 < 0.0F ? -1 : 1);
                     var135 = var191;
                  }

                  int var192 = var135;
                  if (var192 > 0) {
                     int var193 = var16;
                     if (var193 == 0) {
                        continue;
                     }
                  }
               }

               Object[] var91 = new Object[]{var20, 129940779291260L};
               PearlFollow var90 = this;
               Vec3d var201 = var90.aReturningVec3d(var91);
               int var195 = var16;
               Vec3d var194 = var201;
               Vec3d var137 = var194;
               Vec3d var136 = var194;
               if (var195 == 0) {
                  Vec3d var196 = var136;
                  if (var196 == null) {
                     continue;
                  }

                  MinecraftClient var93 = b;
                  ClientPlayerEntity var94 = var93.player;
                  var137 = var94.getEyePos();
               }

               Vec3d var96 = var201;
               Vec3d var95 = var137;
               double var24 = var95.distanceTo(var96);
               FloatSetting var97 = this.d;
               Float var98 = (Float)var97.aReturningObject();
               double var222;
               int var213 = (var222 = var24 - var98.floatValue()) == 0.0 ? 0 : (var222 < 0.0 ? -1 : 1);
               int var198 = var16;
               int var197 = var213;
               int var139 = var197;
               int var138 = var197;
               if (var198 == 0) {
                  int var199 = var138;
                  if (var199 < 0) {
                     continue;
                  }

                  FloatSetting var100 = this.e;
                  Float var101 = (Float)var100.aReturningObject();
                  double var223;
                  var139 = (var223 = var24 - var101.floatValue()) == 0.0 ? 0 : (var223 < 0.0 ? -1 : 1);
               }

               int var200 = var139;
               if (var200 > 0) {
                  continue;
               }

               this.o = var201;
               ElapsedTimer var214 = this.l;
               Object[] var103 = new Object[]{42835128969216L};
               ElapsedTimer var102 = var214;
               var102.aReturningVoid(var103);
               MinMaxSetting var215 = this.g;
               Object[] var105 = new Object[]{127318019014223L};
               MinMaxSetting var104 = var215;
               var104.bReturningVoid(var105);
            }

            HashSet var107 = var17;
            Set var106 = this.k;
            boolean var140 = var106.retainAll(var107);
            break;
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 87666872358447L;
      long var6 = var2 ^ 29159961624672L;
      long var8 = var2 ^ 117380820149222L;
      long var10 = var2 ^ 19182256418671L;
      long var12 = var2 ^ 138007752420630L;
      long var14 = var2 ^ 12826104216269L;
      long var16 = var2 ^ 82878281429531L;
      long var18 = var2 ^ 16882931127021L;
      int var20 = Event.bReturningInt();
      Vec3d var131 = this.o;
      if (var131 == null) {
         return null;
      }

      int var133 = var20;
      MinecraftClient var132 = b;
      MinecraftClient var103 = var132;
      MinecraftClient var102 = var132;
      if (var133 == 0) {
         MinecraftClient var30 = var102;
         ClientPlayerEntity var134 = var30.player;
         if (var134 == null) {
            return null;
         }

         MinecraftClient var135 = b;
         var103 = var135;
      }

      int var137 = var20;
      MinecraftClient var136 = var103;
      MinecraftClient var105 = var136;
      MinecraftClient var104 = var136;
      if (var137 == 0) {
         MinecraftClient var33 = var104;
         ClientWorld var138 = var33.world;
         if (var138 == null) {
            return null;
         }

         var105 = b;
      }

      int var140 = var20;
      MinecraftClient var139 = var105;
      MinecraftClient var107 = var139;
      MinecraftClient var106 = var139;
      if (var140 == 0) {
         MinecraftClient var36 = var106;
         Screen var141 = var36.currentScreen;
         if (var141 != null) {
            return null;
         }

         MinecraftClient var142 = b;
         var107 = var142;
      }

      MinecraftClient var39 = var107;
      boolean var10000 = var39.isWindowFocused();
      int var144 = var20;
      boolean var143 = var10000;
      boolean var109 = var143;
      boolean var108 = var143;
      if (var144 == 0) {
         boolean var145 = var108;
         if (!var145) {
            return null;
         }

         BooleanSetting var42 = this.i;
         Boolean var43 = (Boolean)var42.aReturningObject();
         var109 = var43;
      }

      boolean var113;
      int var147 = var20;
      boolean var146 = var109;
      var113 = var146;
      boolean var110 = var146;
      label116:
      if (var147 == 0) {
         boolean var148 = var110;
         if (var148) {
            MinecraftClient var45 = b;
            ClientPlayerEntity var46 = var45.player;
            var10000 = var46.isOnGround();
            int var150 = var20;
            boolean var149 = var10000;
            var113 = var149;
            boolean var111 = var149;
            if (var150 != 0) {
               break label116;
            }

            boolean var151 = var111;
            boolean var112 = var151;
            boolean var152 = var112;
            if (!var152) {
               return null;
            }
         }

         ElapsedTimer var186 = this.l;
         Object[] var51 = new Object[]{this.g, var16};
         ElapsedTimer var50 = var186;
         var113 = var50.bReturningBoolean(var51);
      }

      boolean var153 = var113;
      if (!var153) {
         return null;
      }

      Object[] var53 = new Object[]{Items.ENDER_PEARL, var8};
      Integer var154 = InventoryUtil.aReturningBoxedInteger(var53);
      if (var154 == null) {
         this.o = null;
         return null;
      }

      MinecraftClient var55 = b;
      ClientPlayerEntity var56 = var55.player;
      Object[] var58 = new Object[]{var56.getEyePos(), this.o, var14};
      PearlFollow var57 = this;
      Rotation var21 = var57.bReturningdx_C0210(var58);
      int var156 = var20;
      Rotation var155 = var21;
      Rotation var115 = var155;
      Rotation var114 = var155;
      if (var156 == 0) {
         Rotation var157 = var114;
         if (var157 == null) {
            this.o = null;
            return null;
         }

         var115 = var21;
      }

      Object[] var62 = new Object[0];
      Rotation var61 = var115;
      float var22 = var61.aReturningFloat(var62);
      Object[] var64 = new Object[0];
      Rotation var63 = var21;
      float var23 = var63.bReturningFloat(var64);
      Object[] var65 = new Object[]{Items.ENDER_PEARL, var8};
      Integer var24 = InventoryUtil.aReturningBoxedInteger(var65);
      int var158 = var20;
      if (var158 == 0) {
         Integer var159 = var24;
         if (var159 != null) {
            Object[] var68 = new Object[]{var10};
            int var25 = InventoryUtil.aReturningInt(var68);
            int var161 = var20;
            int var160 = var25;
            int var117 = var160;
            int var116 = var160;
            int var118;
            if (var161 == 0) {
               Integer var69 = var24;
               int var163 = var69;
               int var162 = var116;
               if (var162 != var163) {
                  byte var164 = 1;
                  var118 = var164;
               } else {
                  var118 = 0;
               }
            } else {
               int var165 = var117;
               var118 = var165;
            }

            int var26;
            label100: {
               var26 = var118;
               int var167 = var20;
               int var166 = var26;
               int var120 = var166;
               int var119 = var166;
               if (var167 == 0) {
                  int var168 = var119;
                  if (var168 == 0) {
                     break label100;
                  }

                  Integer var73 = var24;
                  int var169 = var73;
                  var120 = var169;
               }

               Object[] var10003 = new Object[]{null, var12};
               var10003[0] = var120;
               Object[] var75 = var10003;
               InventoryUtil.aReturningVoid(var75);
            }

            PearlFollow var130;
            label145: {
               int var128;
               byte var129;
               label93: {
                  MinecraftClient var76 = b;
                  ClientPlayerEntity var77 = var76.player;
                  float var27 = var77.getYaw();
                  MinecraftClient var78 = b;
                  ClientPlayerEntity var79 = var78.player;
                  float var28 = var79.getPitch();
                  MinecraftClient var80 = b;
                  float var82 = var22;
                  ClientPlayerEntity var81 = var80.player;
                  var81.setYaw(var82);
                  MinecraftClient var83 = b;
                  float var85 = var23;
                  ClientPlayerEntity var84 = var83.player;
                  var84.setPitch(var85);
                  Object[] var86 = new Object[]{Hand.MAIN_HAND, var18};
                  ItemUseUtil.cReturningBoolean(var86);
                  MinecraftClient var87 = b;
                  float var89 = var27;
                  ClientPlayerEntity var88 = var87.player;
                  var88.setYaw(var89);
                  MinecraftClient var90 = b;
                  float var92 = var28;
                  ClientPlayerEntity var91 = var90.player;
                  var91.setPitch(var92);
                  int var171 = var20;
                  int var170 = var26;
                  int var127 = var170;
                  int var121 = var170;
                  if (var171 == 0) {
                     int var172 = var121;
                     if (var172 != 0) {
                        int var175 = var20;
                        // int var173 = this.n;
                        var128 = var173;
                        var129 = var174;
                        int var122 = var173;
                        byte var123 = var174;
                        if (var175 != 0) {
                           break label93;
                        }

                        byte var177 = var123;
                        int var176 = var122;
                        int var124 = var176;
                        byte var125 = var177;
                        byte var179 = var125;
                        int var178 = var124;
                        if (var178 == var179) {
                           this.n = var25;
                        }
                     }

                     int var181 = var20;
                     PearlFollow var180 = this;
                     var130 = var180;
                     PearlFollow var126 = var180;
                     if (var181 != 0) {
                        break label145;
                     }

                     int var182 = var126.n;
                     var127 = var182;
                  }

                  var129 = -1;
                  var128 = var127;
               }

               byte var184 = var129;
               int var183 = var128;
               if (var183 != var184) {
                  ElapsedTimer var187 = this.m;
                  Object[] var99 = new Object[]{var6};
                  ElapsedTimer var98 = var187;
                  var98.aReturningVoid(var99);
                  MinMaxSetting var188 = this.h;
                  Object[] var101 = new Object[]{var4};
                  MinMaxSetting var100 = var188;
                  var100.bReturningVoid(var101);
               }

               var130 = this;
            }

            var130.o = null;
            return new Rotation(var22, var23);
         }

         this.o = null;
      }

      return null;
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      EnderPearlEntity var4 = (EnderPearlEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 52293612455223L ^ var2;
      long var5 = var2 ^ 91211748729025L;
      int var10000 = Event.bReturningInt();
      MinecraftClient var10 = b;
      MinecraftClient var11 = b;
      Item var12 = Items.ENDER_PEARL;
      PearlFollowProjectile var8 = new PearlFollowProjectile(var10.world, var11.player, var12.getDefaultStack(), var5);
      int var7 = var10000;
      EnderPearlEntity var13 = var4;
      double var10001 = var13.getX();
      EnderPearlEntity var14 = var4;
      double var10002 = var14.getY();
      EnderPearlEntity var15 = var4;
      double var21 = var15.getZ();
      double var19 = var10002;
      double var17 = var10001;
      PearlFollowProjectile var16 = var8;
      var16.setPosition(var17, var19, var21);
      EnderPearlEntity var23 = var4;
      Vec3d var25 = var23.getVelocity();
      PearlFollowProjectile var24 = var8;
      var24.setVelocity(var25);
      int var36;
      while (true) {
         boolean var38 = var8.a;
         if (!var38) {
            var10000 = var9++;
            int var40 = var7;
            int var39 = var10000;
            var36 = var39;
            int var33 = var39;
            if (var40 != 0) {
               break;
            }

            int var42 = var7;
            int var41 = var33;
            var36 = var41;
            int var34 = var41;
            if (var42 != 0) {
               break;
            }

            int var43 = var34;
            int var35 = var43;
            short var51 = 12244;
            long var52 = 4311237166204524206L ^ var2;
            short var45 = 400;
            int var44 = var35;
            if (var44 < var45) {
               PearlFollowProjectile var28 = var8;
               var28.tick();
               int var46 = var7;
               if (var46 == 0) {
                  continue;
               }
            }
         }

         var36 = (((var8.a) ? 1 : 0));
         break;
      }

      int var47 = var36;
      Vec3d var37;
      if (var47 != 0) {
         PearlFollowProjectile var30 = var8;
         var10002 = var30.getX();
         PearlFollowProjectile var31 = var8;
         double var10003 = var31.getY();
         PearlFollowProjectile var32 = var8;
         Vec3d var48 = new Vec3d(var10002, var10003, var32.getZ());
         var37 = var48;
      } else {
         var37 = null;
      }

      return var37;
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Vec3d var5 = (Vec3d)var1[0];
      Vec3d var2 = (Vec3d)var1[1];
      long var3 = (Long)var1[2];
      var3 = 52293612455223L ^ var3;
      long var6 = var3 ^ 24704511173053L;
      long var8 = var3 ^ 99960447267707L;
      long var10 = var3 ^ 4573514798062L;
      long var12 = var3 ^ 128169013186756L;
      long var14 = var3 ^ 70152096931203L;
      long var16 = var3 ^ 94896698385850L;
      Vec3d var32 = var2;
      Vec3d var33 = var5;
      double var19 = var32.x - var33.x;
      Vec3d var34 = var2;
      Vec3d var35 = var5;
      double var21 = var34.z - var35.z;
      int var10000 = Event.bReturningInt();
      double var10001 = -var19;
      double var38 = var21;
      double var36 = var10001;
      double var40 = Math.atan2(var36, var38);
      float var23 = (float)Math.toDegrees(var40);
      ArrayList var24 = new ArrayList();
      ArrayList var25 = new ArrayList();
      int var18 = var10000;
      float var26 = -85.0F;

      Object var81;
      while (true) {
         float var115;
         int var88 = (var115 = var26 - 85.0F) == 0.0F ? 0 : (var115 < 0.0F ? -1 : 1);
         if (var88 <= 0) {
            Object[] var10007 = new Object[]{null, null, null, null, var6};
            var10007[3] = var26;
            var10007[2] = var23;
            var10007[1] = var2;
            var10007[0] = var5;
            Object[] var43 = var10007;
            PearlFollow var42 = this;
            PearlFollowSolution var27 = var42.aReturninggw_C0370(var43);
            PearlFollowSolution var45 = var27;
            ArrayList var44 = var24;
            var44.add(var45);
            int var89 = var18;
            if (var89 == 0) {
               int var91 = var18;
               PearlFollowSolution var90 = var27;
               var81 = var90;
               PearlFollowSolution var78 = var90;
               if (var91 != 0) {
                  break;
               }

               PearlFollowSolution var92 = var78;
               PearlFollowSolution var79 = var92;
               PearlFollowSolution var93 = var79;
               if (var93 != null) {
                  PearlFollowSolution var49 = var27;
                  ArrayList var48 = var25;
                  var48.add(var49);
               }

               var26 += 2.0F;
            }

            int var94 = var18;
            if (var94 == 0) {
               continue;
            }
         }

         int var96 = var18;
         ArrayList var95 = var25;
         var81 = var95;
         ArrayList var80 = var95;
         if (var96 == 0) {
            ArrayList var51 = var80;
            boolean var97 = var51.isEmpty();
            if (var97) {
               return null;
            }

            FloatSetting var54 = this.f;
            var81 = var54.aReturningObject();
         }
         break;
      }

      Float var55 = (Float)var81;
      double var111 = var55.floatValue();
      Object[] var57 = new Object[]{var24, var14};
      PearlFollow var56 = this;
      List var28 = var56.bReturningList(var57);
      Object[] var10005 = new Object[]{null, null, var12};
      var10005[1] = var111;
      var10005[0] = var25;
      Object[] var59 = var10005;
      PearlFollow var58 = this;
      PearlFollowSolution var29 = var58.cReturningVoid(var59);
      List var60 = var28;
      Iterator var30 = var60.iterator();

      PearlFollowSolution var86;
      label61: {
         PearlFollow var85;
         label60: {
            while (true) {
               Iterator var61 = var30;
               boolean var98 = var61.hasNext();
               if (var98) {
                  Iterator var62 = var30;
                  PearlFollowSolution var31 = (PearlFollowSolution)var62.next();
                  Object[] var10008 = new Object[]{null, null, null, var31, var25, var8};
                  var10008[2] = var23;
                  var10008[1] = var2;
                  var10008[0] = var5;
                  Object[] var64 = var10008;
                  PearlFollow var63 = this;
                  var63.jReturningVoid(var64);
                  int var99 = var18;
                  if (var99 != 0) {
                     break;
                  }

                  int var100 = var18;
                  if (var100 == 0) {
                     continue;
                  }
               }

               int var102 = var18;
               PearlFollowSolution var101 = var29;
               var86 = var101;
               PearlFollowSolution var82 = var101;
               if (var102 != 0) {
                  break label61;
               }

               PearlFollowSolution var103 = var82;
               if (var103 != null) {
                  int var105 = var18;
                  PearlFollow var104 = this;
                  var85 = var104;
                  PearlFollow var83 = var104;
                  if (var105 != 0) {
                     break label60;
                  }

                  PearlFollow var106 = var83;
                  PearlFollow var84 = var106;
                  Object[] var69 = new Object[]{var28, var29, var10};
                  PearlFollow var68 = var84;
                  boolean var107 = var68.dReturningBoolean(var69);
                  if (!var107) {
                     Object[] var114 = new Object[]{null, null, null, var29, var25, var8};
                     var114[2] = var23;
                     var114[1] = var2;
                     var114[0] = var5;
                     Object[] var72 = var114;
                     PearlFollow var71 = this;
                     var71.jReturningVoid(var72);
                  }
               }
               break;
            }

            var85 = this;
         }

         var10005 = new Object[]{null, null, var16};
         var10005[1] = var111;
         var10005[0] = var25;
         Object[] var75 = var10005;
         PearlFollow var74 = var85;
         var86 = var74.bReturninggw_C0370(var75);
      }

      PearlFollowSolution var112 = var86;
      PearlFollowSolution var108 = var112;
      Rotation var87;
      if (var108 == null) {
         Object var109 = null;
         var87 = (Rotation)var109;
      } else {
         PearlFollowSolution var77 = var112;
         var87 = new Rotation(var23, var77.bf());
      }

      return var87;
   }

   private List bReturningList(Object[] var1) {
      List var4 = (List)var1[0];
      long var2 = (Long)var1[1];
      var2 = 52293612455223L ^ var2;
      long var5 = var2 ^ 2492689832074L;
      ArrayList var8 = new ArrayList();
      int var10000 = Event.cReturningInt();
      int var7 = var10000;

      int var108;
      do {
         List var15 = var4;
         int var82 = var15.size();
         int var81 = var9;
         if (var81 >= var82) {
            break;
         }

         label124: {
            int var17 = var9;
            List var16 = var4;
            PearlFollowSolution var10 = (PearlFollowSolution)var16.get(var17);
            PearlFollowSolution var83 = var10;
            if (var83 != null) {
               double var63;
               label121: {
                  Object var62;
                  label120: {
                     int var84 = var9;
                     if (var84 > 0) {
                        int var20 = var9 - 1;
                        List var19 = var4;
                        var10000 = (int)var19.get(var20);
                        int var86 = var7;
                        Object var85 = var10000;
                        var62 = var85;
                        Object var60 = var85;
                        if (var86 == 0) {
                           break label120;
                        }

                        Object var87 = var60;
                        Object var61 = var87;
                        Object var88 = var61;
                        if (var88 != null) {
                           int var24 = var9 - 1;
                           List var23 = var4;
                           Object var89 = var23.get(var24);
                           var62 = var89;
                           break label120;
                        }
                     }

                     var63 = Double.POSITIVE_INFINITY;
                     break label121;
                  }

                  PearlFollowSolution var26 = (PearlFollowSolution)var62;
                  double var90 = var26.bg();
                  var63 = var90;
               }

               double var11;
               double var68;
               label112: {
                  Object var67;
                  label111: {
                     var11 = var63;
                     var10000 = var9 + 1;
                     List var27 = var4;
                     int var93 = var27.size();
                     int var92 = var10000;
                     if (var92 < var93) {
                        int var29 = var9 + 1;
                        List var28 = var4;
                        var10000 = (int)var28.get(var29);
                        int var95 = var7;
                        Object var94 = var10000;
                        var67 = var94;
                        Object var65 = var94;
                        if (var95 == 0) {
                           break label111;
                        }

                        Object var96 = var65;
                        Object var66 = var96;
                        Object var97 = var66;
                        if (var97 != null) {
                           int var33 = var9 + 1;
                           List var32 = var4;
                           Object var98 = var32.get(var33);
                           var67 = var98;
                           break label111;
                        }
                     }

                     var68 = Double.POSITIVE_INFINITY;
                     break label112;
                  }

                  PearlFollowSolution var35 = (PearlFollowSolution)var67;
                  double var99 = var35.bg();
                  var68 = var99;
               }

               double var13 = var68;
               int var101 = var7;
               if (var101 == 0) {
                  break label124;
               }

               PearlFollowSolution var36 = var10;
               double var139;
               int var102 = (var139 = var36.bg() - var11) == 0.0 ? 0 : (var139 < 0.0 ? -1 : 1);
               if (var102 <= 0) {
                  PearlFollowSolution var38 = var10;
                  double var140;
                  var10000 = (var140 = var38.bg() - var13) == 0.0 ? 0 : (var140 < 0.0 ? -1 : 1);
                  int var104 = var7;
                  int var103 = var10000;
                  int var70 = var103;
                  if (var104 != 0) {
                     int var105 = var70;
                     int var71 = var105;
                     int var106 = var71;
                     if (var106 <= 0) {
                        PearlFollowSolution var42 = var10;
                        ArrayList var41 = var8;
                        boolean var107 = var41.add(var42);
                     }
                  }
               }
            }

            var9++;
         }

         var108 = var7;
      } while (var108 != 0);

      ArrayList var129 = new ArrayList();

      ArrayList var80;
      while (true) {
         ArrayList var44 = var129;
         var10000 = var44.size();
         byte var110 = 3;
         int var109 = var10000;
         label88:
         if (var109 < var110) {
            PearlFollowSolution var130 = null;
            int var112 = var7;
            ArrayList var111 = var8;
            var80 = var111;
            ArrayList var73 = var111;
            if (var112 == 0) {
               break;
            }

            ArrayList var45 = var73;
            Iterator var131 = var45.iterator();

            while (true) {
               Iterator var46 = var131;
               boolean var113 = var46.hasNext();
               if (var113) {
                  Iterator var47 = var131;
                  PearlFollowSolution var12 = (PearlFollowSolution)var47.next();
                  Object[] var49 = new Object[]{var129, var12, var5};
                  PearlFollow var48 = this;
                  boolean var137 = var48.aReturningBoolean(var49);
                  int var115 = var7;
                  boolean var114 = var137;
                  boolean var74 = var114;
                  if (var115 == 0) {
                     break;
                  }

                  boolean var116 = var74;
                  if (var116) {
                     continue;
                  }

                  label80: {
                     PearlFollowSolution var78;
                     int var118 = var7;
                     PearlFollowSolution var117 = var130;
                     var78 = var117;
                     PearlFollowSolution var75 = var117;
                     label79:
                     if (var118 != 0) {
                        PearlFollowSolution var119 = var75;
                        if (var119 != null) {
                           int var121 = var7;
                           PearlFollowSolution var120 = var12;
                           var78 = var120;
                           PearlFollowSolution var76 = var120;
                           if (var121 == 0) {
                              break label79;
                           }

                           PearlFollowSolution var122 = var76;
                           PearlFollowSolution var77 = var122;
                           PearlFollowSolution var53 = var77;
                           double var138 = var53.bg();
                           PearlFollowSolution var54 = var130;
                           double var141;
                           int var123 = (var141 = var138 - var54.bg()) == 0.0 ? 0 : (var141 < 0.0 ? -1 : 1);
                           if (var123 >= 0) {
                              break label80;
                           }
                        }

                        PearlFollowSolution var124 = var12;
                        var78 = var124;
                     }

                     var130 = var78;
                  }

                  int var125 = var7;
                  if (var125 != 0) {
                     continue;
                  }
               }

               PearlFollowSolution var126 = var130;
               if (var126 == null) {
                  break label88;
               }

               PearlFollowSolution var59 = var130;
               ArrayList var58 = var129;
               boolean var79 = var58.add(var59);
               break;
            }

            int var127 = var7;
            if (var127 != 0) {
               continue;
            }
         }

         var80 = var129;
         break;
      }

      return var80;
   }

   private void jReturningVoid(Object[] var1) {
      Vec3d var7 = (Vec3d)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      float var6 = (Float)var1[2];
      PearlFollowSolution var2 = (PearlFollowSolution)var1[3];
      List var8 = (List)var1[4];
      long var3 = (Long)var1[5];
      var3 = 52293612455223L ^ var3;
      long var9 = var3 ^ 108927406462961L;
      double var16 = 11.0;
      int var12 = (int)Math.ceil(var16);
      int var10000 = Event.bReturningInt();
      int var13 = -var12;
      int var11 = var10000;

      int var34;
      do {
         int var28 = var12;
         int var27 = var13;
         if (var27 > var28) {
            break;
         }

         PearlFollowSolution var18 = var2;
         float var14 = var18.bf() + var13 * 0.2F;
         int var29 = var11;
         label29:
         if (var29 == 0) {
            float var36;
            int var30 = (var36 = var14 - -85.0F) == 0.0F ? 0 : (var36 < 0.0F ? -1 : 1);
            if (var30 >= 0) {
               float var37;
               int var31 = (var37 = var14 - 85.0F) == 0.0F ? 0 : (var37 < 0.0F ? -1 : 1);
               if (var31 <= 0) {
                  Object[] var10007 = new Object[]{null, null, null, null, var9};
                  var10007[3] = var14;
                  var10007[2] = var6;
                  var10007[1] = var5;
                  var10007[0] = var7;
                  Object[] var23 = var10007;
                  PearlFollow var22 = this;
                  PearlFollowSolution var15 = var22.aReturninggw_C0370(var23);
                  int var32 = var11;
                  if (var32 != 0) {
                     break label29;
                  }

                  PearlFollowSolution var33 = var15;
                  if (var33 != null) {
                     PearlFollowSolution var26 = var15;
                     List var25 = var8;
                     var25.add(var26);
                  }
               }
            }

            var13++;
         }

         var34 = var11;
      } while (var34 == 0);
   }

   private PearlFollowSolution aReturninggw_C0370(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      Vec3d var5 = (Vec3d)var1[1];
      float var7 = (Float)var1[2];
      float var6 = (Float)var1[3];
      long var3 = (Long)var1[4];
      var3 = 52293612455223L ^ var3;
      long var8 = var3 ^ 99198556325057L;
      Object[] var10006 = new Object[]{null, null, null, var8};
      var10006[2] = var6;
      var10006[1] = var7;
      var10006[0] = var2;
      Object[] var12 = var10006;
      PearlFollow var11 = this;
      PearlPathSample var10 = var11.aReturninggv_C0368(var12);
      PearlPathSample var19 = var10;
      if (var19 == null) {
         return null;
      }

      PearlPathSample var14 = var10;
      Vec3d var10003 = var14.bc();
      Vec3d var16 = var5;
      Vec3d var15 = var10003;
      double var21 = var15.distanceTo(var16);
      PearlPathSample var17 = var10;
      int var10004 = var17.bd();
      PearlPathSample var18 = var10;
      return new PearlFollowSolution(var6, var21, var10004, var18.be());
   }

   private PearlFollowSolution bReturninggw_C0370(Object[] var1) {
      List var6 = (List)var1[0];
      double var2 = (Double)var1[1];
      long var4 = (Long)var1[2];
      var4 = 52293612455223L ^ var4;
      long var7 = var4 ^ 58302723909196L;
      int var10000 = Event.cReturningInt();
      double var10 = Double.POSITIVE_INFINITY;
      int var9 = var10000;
      List var17 = var6;
      Iterator var12 = var17.iterator();

      double var58;
      label68: {
         int var57;
         while (true) {
            Iterator var18 = var12;
            boolean var65 = var18.hasNext();
            if (var65) {
               label59: {
                  Iterator var19 = var12;
                  PearlFollowSolution var13 = (PearlFollowSolution)var19.next();
                  PearlFollowSolution var20 = var13;
                  double var96 = var20.bg();
                  int var70 = var9;
                  double var68 = var2;
                  double var66 = var96;
                  double var51 = var66;
                  double var53 = var68;
                  double var45 = var66;
                  double var47 = var68;
                  if (var70 != 0) {
                     double var98;
                     var10000 = (var98 = var45 - var47) == 0.0 ? 0 : (var98 < 0.0 ? -1 : 1);
                     int var72 = var9;
                     int var71 = var10000;
                     var57 = var71;
                     int var49 = var71;
                     if (var72 == 0) {
                        break;
                     }

                     int var73 = var49;
                     int var50 = var73;
                     int var74 = var50;
                     if (var74 > 0) {
                        break label59;
                     }

                     PearlFollowSolution var23 = var13;
                     double var77 = var23.bg();
                     double var75 = var10;
                     var51 = var75;
                     var53 = var77;
                  }

                  double var27 = var53;
                  double var25 = var51;
                  var10 = Math.min(var25, var27);
               }

               int var79 = var9;
               if (var79 != 0) {
                  continue;
               }
            }

            int var82 = var9;
            double var80 = var10;
            var58 = var80;
            double var55 = var80;
            if (var82 == 0) {
               break label68;
            }

            double var29 = var55;
            byte var83 = ((byte)((Double.isFinite(var29)) ? 1 : 0));
            var57 = var83;
            break;
         }

         int var84 = var57;
         if (var84 == 0) {
            return null;
         }

         double var35 = var10 + 0.25;
         double var33 = var2;
         var58 = Math.min(var33, var35);
      }

      double var95 = var58;
      PearlFollowSolution var14 = null;
      List var37 = var6;
      Iterator var15 = var37.iterator();

      PearlFollowSolution var64;
      while (true) {
         Iterator var38 = var15;
         boolean var85 = var38.hasNext();
         if (var85) {
            Iterator var39 = var15;
            PearlFollowSolution var16 = (PearlFollowSolution)var39.next();
            int var87 = var9;
            PearlFollowSolution var86 = var16;
            var64 = var86;
            PearlFollowSolution var60 = var86;
            if (var87 == 0) {
               break;
            }

            label40: {
               int var89 = var9;
               PearlFollowSolution var88 = var60;
               PearlFollowSolution var63 = var88;
               PearlFollowSolution var61 = var88;
               if (var89 != 0) {
                  PearlFollowSolution var90 = var61;
                  PearlFollowSolution var62 = var90;
                  PearlFollowSolution var41 = var62;
                  double var99;
                  int var91 = (var99 = var41.bg() - var95) == 0.0 ? 0 : (var99 < 0.0 ? -1 : 1);
                  if (var91 > 0) {
                     break label40;
                  }

                  Object[] var44 = new Object[]{var14, var16, var7};
                  PearlFollow var43 = this;
                  PearlFollowSolution var92 = var43.dReturninggw_C0370(var44);
                  var63 = var92;
               }

               var14 = var63;
            }

            int var93 = var9;
            if (var93 != 0) {
               continue;
            }
         }

         var64 = var14;
         break;
      }

      return var64;
   }

   private PearlFollowSolution c(Object[] var1) {
      List var2 = (List)var1[0];
      double var3 = (Double)var1[1];
      long var5 = (Long)var1[2];
      var5 = 52293612455223L ^ var5;
      long var7 = var5 ^ 26224505787186L;
      int var10000 = Event.cReturningInt();
      PearlFollowSolution var10 = null;
      int var9 = var10000;
      List var13 = var2;
      Iterator var11 = var13.iterator();

      PearlFollowSolution var25;
      while (true) {
         Iterator var14 = var11;
         boolean var26 = var14.hasNext();
         if (var26) {
            Iterator var15 = var11;
            PearlFollowSolution var12 = (PearlFollowSolution)var15.next();
            int var28 = var9;
            PearlFollowSolution var27 = var12;
            var25 = var27;
            PearlFollowSolution var21 = var27;
            if (var28 == 0) {
               break;
            }

            label23: {
               int var30 = var9;
               PearlFollowSolution var29 = var21;
               PearlFollowSolution var24 = var29;
               PearlFollowSolution var22 = var29;
               if (var30 != 0) {
                  PearlFollowSolution var31 = var22;
                  PearlFollowSolution var23 = var31;
                  PearlFollowSolution var17 = var23;
                  double var36;
                  int var32 = (var36 = var17.bg() - var3) == 0.0 ? 0 : (var36 < 0.0 ? -1 : 1);
                  if (var32 > 0) {
                     break label23;
                  }

                  Object[] var20 = new Object[]{var10, var12, var7};
                  PearlFollow var19 = this;
                  PearlFollowSolution var33 = var19.dReturninggw_C0370(var20);
                  var24 = var33;
               }

               var10 = var24;
            }

            int var34 = var9;
            if (var34 != 0) {
               continue;
            }
         }

         var25 = var10;
         break;
      }

      return var25;
   }

   private PearlFollowSolution dReturninggw_C0370(Object[] var1) {
      PearlFollowSolution var2 = (PearlFollowSolution)var1[0];
      PearlFollowSolution var3 = (PearlFollowSolution)var1[1];
      long var4 = (Long)var1[2];
      long var10000 = 52293612455223L ^ var4;
      int var6 = Event.cReturningInt();
      int var54 = var6;
      PearlFollowSolution var53 = var2;
      PearlFollowSolution var40 = var53;
      PearlFollowSolution var39 = var53;
      if (var54 != 0) {
         PearlFollowSolution var55 = var39;
         if (var55 == null) {
            return var3;
         }

         var40 = var3;
      }

      PearlFollowSolution var12 = var40;
      int var76 = var12.bh();
      PearlFollowSolution var13 = var2;
      int var15 = var13.bh();
      int var14 = var76;
      int var7 = Integer.compare(var14, var15);
      int var57 = var6;
      int var56 = var7;
      int var43 = var56;
      int var41 = var56;
      if (var57 != 0) {
         int var58 = var41;
         if (var58 != 0) {
            int var59 = var7;
            PearlFollowSolution var42;
            if (var59 < 0) {
               PearlFollowSolution var60 = var3;
               var42 = var60;
            } else {
               var42 = var2;
            }

            return var42;
         }

         PearlFollowSolution var19 = var3;
         double var77 = var19.bi();
         PearlFollowSolution var20 = var2;
         double var23 = var20.bi();
         double var21 = var77;
         var43 = Double.compare(var21, var23);
      }

      int var8 = var43;
      int var62 = var6;
      int var61 = var8;
      int var46 = var61;
      int var44 = var61;
      if (var62 != 0) {
         int var63 = var44;
         if (var63 != 0) {
            int var64 = var8;
            PearlFollowSolution var45;
            if (var64 < 0) {
               PearlFollowSolution var65 = var3;
               var45 = var65;
            } else {
               var45 = var2;
            }

            return var45;
         }

         PearlFollowSolution var28 = var3;
         double var78 = var28.bg();
         PearlFollowSolution var29 = var2;
         double var32 = var29.bg();
         double var30 = var78;
         var46 = Double.compare(var30, var32);
      }

      int var9 = var46;
      int var67 = var6;
      int var66 = var9;
      int var50 = var66;
      int var47 = var66;
      if (var67 != 0) {
         int var68 = var47;
         if (var68 != 0) {
            int var69 = var9;
            PearlFollowSolution var48;
            if (var69 < 0) {
               PearlFollowSolution var70 = var3;
               var48 = var70;
            } else {
               var48 = var2;
            }

            return var48;
         }

         int var72 = var6;
         PearlFollowSolution var71 = var3;
         PearlFollowSolution var51 = var71;
         PearlFollowSolution var49 = var71;
         if (var72 == 0) {
            return var51;
         }

         PearlFollowSolution var37 = var49;
         float var79 = var37.bf();
         PearlFollowSolution var38 = var2;
         float var80;
         int var73 = (var80 = var79 - var38.bf()) == 0.0F ? 0 : (var80 < 0.0F ? -1 : 1);
         var50 = var73;
      }

      int var74 = var50;
      return var74 <= 0 ? var2 : var3;
   }

   private boolean aReturningBoolean(Object[] var1) {
      List var5 = (List)var1[0];
      PearlFollowSolution var4 = (PearlFollowSolution)var1[1];
      long var2 = (Long)var1[2];
      var2 = 52293612455223L ^ var2;
      long var6 = var2 ^ 27809795465694L;
      int var10000 = Event.bReturningInt();
      List var11 = var5;
      Iterator var9 = var11.iterator();
      int var8 = var10000;

      byte var20;
      while (true) {
         Iterator var12 = var9;
         boolean var21 = var12.hasNext();
         if (var21) {
            Iterator var13 = var9;
            PearlFollowSolution var10 = (PearlFollowSolution)var13.next();
            Object[] var15 = new Object[]{var10, var4, var6};
            PearlFollow var14 = this;
            byte var30 = ((byte)((var14.eReturningBoolean(var15)) ? 1 : 0));
            int var23 = var8;
            byte var22 = var30;
            var20 = var22;
            byte var16 = var22;
            if (var23 != 0) {
               break;
            }

            int var25 = var8;
            byte var24 = var16;
            byte var19 = var24;
            byte var17 = var24;
            if (var25 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var19);
            }

            byte var26 = var17;
            byte var18 = var26;
            byte var27 = var18;
            if (var27 != 0) {
               var19 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var19);
            }

            int var28 = var8;
            if (var28 == 0) {
               continue;
            }
         }

         var20 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var20);
   }

   private boolean dReturningBoolean(Object[] var1) {
      List var2 = (List)var1[0];
      PearlFollowSolution var5 = (PearlFollowSolution)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 52293612455223L ^ var3;
      int var28 = Event.bReturningInt();
      List var9 = var2;
      Iterator var7 = var9.iterator();
      int var6 = var28;

      int var19;
      while (true) {
         Iterator var10 = var7;
         boolean var20 = var10.hasNext();
         if (var20) {
            Iterator var11 = var7;
            PearlFollowSolution var8 = (PearlFollowSolution)var11.next();
            PearlFollowSolution var12 = var8;
            float var29 = var12.bf();
            PearlFollowSolution var13 = var5;
            float var14 = var29 - var13.bf();
            float var31;
            int var30 = (var31 = Math.abs(var14) - 0.1F) == 0.0F ? 0 : (var31 < 0.0F ? -1 : 1);
            int var22 = var6;
            int var21 = var30;
            var19 = var21;
            int var15 = var21;
            if (var22 != 0) {
               break;
            }

            int var24 = var6;
            int var23 = var15;
            int var18 = var23;
            int var16 = var23;
            if (var24 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var18);
            }

            int var25 = var16;
            int var17 = var25;
            int var26 = var17;
            if (var26 < 0) {
               byte var32 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var32);
            }

            int var27 = var6;
            if (var27 == 0) {
               continue;
            }
         }

         var19 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var19);
   }

   private boolean eReturningBoolean(Object[] var1) {
      PearlFollowSolution var4 = (PearlFollowSolution)var1[0];
      PearlFollowSolution var5 = (PearlFollowSolution)var1[1];
      long var2 = (Long)var1[2];
      long var10000 = 52293612455223L ^ var2;
      int var6 = Event.bReturningInt();
      int var20 = var6;
      PearlFollowSolution var19 = var4;
      PearlFollowSolution var13 = var19;
      PearlFollowSolution var12 = var19;
      if (var20 == 0) {
         PearlFollowSolution var21 = var12;
         if (var21 == null) {
            return false;
         }

         var13 = var5;
      }

      int var23 = var6;
      PearlFollowSolution var22 = var13;
      PearlFollowSolution var15 = var22;
      PearlFollowSolution var14 = var22;
      if (var23 == 0) {
         PearlFollowSolution var24 = var14;
         if (var24 == null) {
            return false;
         }

         var15 = var4;
      }

      PearlFollowSolution var9 = var15;
      float var29 = var9.bf();
      PearlFollowSolution var10 = var5;
      float var11 = var29 - var10.bf();
      float var31;
      int var30 = (var31 = Math.abs(var11) - 6.0F) == 0.0F ? 0 : (var31 < 0.0F ? -1 : 1);
      int var26 = var6;
      int var25 = var30;
      int var17 = var25;
      int var16 = var25;
      if (var26 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var17);
      } else {
         int var27 = var16;
         if (var27 < 0) {
            byte var32 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var32);
         } else {
            return false;
         }
      }
   }

   private PearlPathSample aReturninggv_C0368(Object[] var1) {
      Vec3d var6 = (Vec3d)var1[0];
      float var3 = (Float)var1[1];
      float var2 = (Float)var1[2];
      long var4 = (Long)var1[3];
      var4 = 52293612455223L ^ var4;
      long var7 = var4 ^ 104793407669612L;
      float var10 = var3 * (float) (Math.PI / 180.0);
      float var11 = var2 * (float) (Math.PI / 180.0);
      double var23 = var10;
      float var10000 = -MathHelper.sin(var23);
      double var25 = var11;
      double var12 = var10000 * MathHelper.cos(var25);
      int var81 = Event.bReturningInt();
      double var27 = var11;
      double var14 = -MathHelper.sin(var27);
      double var29 = var10;
      float var10001 = MathHelper.cos(var29);
      double var31 = var11;
      double var16 = var10001 * MathHelper.cos(var31);
      int var9 = var81;
      Vec3d var33 = new Vec3d(var12, var14, var16);
      Vec3d var82 = var33.normalize();
      double var35 = 1.5;
      Vec3d var34 = var82;
      Vec3d var18 = var34.multiply(var35);
      MinecraftClient var37 = b;
      MinecraftClient var38 = b;
      Item var39 = Items.ENDER_PEARL;
      PearlFollowProjectile var19 = new PearlFollowProjectile(var37.world, var38.player, var39.getDefaultStack(), var7);
      Vec3d var40 = var6;
      Vec3d var41 = var6;
      Vec3d var42 = var6;
      double var48 = var42.z;
      double var46 = var41.y;
      double var44 = var40.x;
      PearlFollowProjectile var43 = var19;
      var43.setPosition(var44, var46, var48);
      Vec3d var51 = var18;
      PearlFollowProjectile var50 = var19;
      var50.setVelocity(var51);
      Vec3d var52 = var6;
      double var21 = var52.y;

      int var67;
      while (true) {
         boolean var69 = var19.a;
         if (!var69) {
            int var71 = var9;
            int var70 = var20;
            var67 = var70;
            int var64 = var70;
            if (var71 != 0) {
               break;
            }

            int var73 = var9;
            int var72 = var64;
            var67 = var72;
            int var65 = var72;
            if (var73 != 0) {
               break;
            }

            int var74 = var65;
            int var66 = var74;
            short var83 = 23273;
            long var10002 = 2005676066692744765L ^ var4;
            short var76 = 400;
            int var75 = var66;
            if (var75 < var76) {
               PearlFollowProjectile var55 = var19;
               var55.tick();
               var20++;
               PearlFollowProjectile var56 = var19;
               double var59 = var56.getY();
               double var57 = var21;
               var21 = Math.max(var57, var59);
               int var77 = var9;
               if (var77 == 0) {
                  continue;
               }
            }
         }

         var67 = (((var19.a) ? 1 : 0));
         break;
      }

      int var78 = var67;
      PearlPathSample var68;
      if (var78 != 0) {
         PearlFollowProjectile var61 = var19;
         double var10004 = var61.getX();
         PearlFollowProjectile var62 = var19;
         double var10005 = var62.getY();
         PearlFollowProjectile var63 = var19;
         PearlPathSample var79 = new PearlPathSample(new Vec3d(var10004, var10005, var63.getZ()), var20, var21);
         var68 = var79;
      } else {
         var68 = null;
      }

      return var68;
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(116064981840068L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[4];
      String var6 = "#>\u009c\u0092\u001fæ\u0088\u009dG\u0004¹Û\u008cGW@";
      int var7 = "#>\u009c\u0092\u001fæ\u0088\u009dG\u0004¹Û\u008cGW@".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     A = var8;
                     B = new Integer[4];
                     p = 400;
                     x = 3;
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "º»i\u0085\u001fÛòP´\u009b\u0003\u0013óXÆñ";
                  var7 = "º»i\u0085\u001fÛòP´\u009b\u0003\u0013óXÆñ".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11824;
      if (B[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = A[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])C.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               C.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fb", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         B[var3] = var15;
      }

      return B[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fb_C0274",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = E[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = D[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 53;
            yield var15;
         }
         case 1 -> {
            byte var16 = 11;
            yield var16;
         }
         case 2 -> {
            byte var17 = 62;
            yield var17;
         }
         case 3 -> {
            byte var18 = 10;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 17;
            yield var20;
         }
         case 6 -> {
            byte var21 = 9;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 22;
            yield var23;
         }
         case 9 -> {
            byte var24 = 48;
            yield var24;
         }
         case 10 -> {
            byte var25 = 45;
            yield var25;
         }
         case 11 -> {
            byte var26 = 49;
            yield var26;
         }
         case 12 -> {
            byte var27 = 61;
            yield var27;
         }
         case 13 -> {
            byte var28 = 50;
            yield var28;
         }
         case 14 -> {
            byte var29 = 18;
            yield var29;
         }
         case 15 -> {
            byte var30 = 29;
            yield var30;
         }
         case 16 -> {
            byte var31 = 36;
            yield var31;
         }
         case 17 -> {
            byte var32 = 42;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 46;
            yield var34;
         }
         case 20 -> {
            byte var35 = 33;
            yield var35;
         }
         case 21 -> {
            byte var36 = 15;
            yield var36;
         }
         case 22 -> {
            byte var37 = 54;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 26;
            yield var40;
         }
         case 26 -> {
            byte var41 = 1;
            yield var41;
         }
         case 27 -> {
            byte var42 = 57;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 41;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 2;
            yield var46;
         }
         case 32 -> {
            byte var47 = 24;
            yield var47;
         }
         case 33 -> {
            byte var48 = 16;
            yield var48;
         }
         case 34 -> {
            byte var49 = 14;
            yield var49;
         }
         case 35 -> {
            byte var50 = 63;
            yield var50;
         }
         case 36 -> {
            byte var51 = 7;
            yield var51;
         }
         case 37 -> {
            byte var52 = 34;
            yield var52;
         }
         case 38 -> {
            byte var53 = 37;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 51;
            yield var55;
         }
         case 41 -> {
            byte var56 = 44;
            yield var56;
         }
         case 42 -> {
            byte var57 = 35;
            yield var57;
         }
         case 43 -> {
            byte var58 = 5;
            yield var58;
         }
         case 44 -> {
            byte var59 = 28;
            yield var59;
         }
         case 45 -> {
            byte var60 = 58;
            yield var60;
         }
         case 46 -> {
            byte var61 = 59;
            yield var61;
         }
         case 47 -> {
            byte var62 = 56;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 25;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 23;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 21;
            yield var70;
         }
         case 56 -> {
            byte var71 = 55;
            yield var71;
         }
         case 57 -> {
            byte var72 = 47;
            yield var72;
         }
         case 58 -> {
            byte var73 = 40;
            yield var73;
         }
         case 59 -> {
            byte var74 = 43;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 52;
            yield var77;
         }
         default -> 3;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            E[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      D[0] = "\n3' rl\u001c3\"za{\u000bx!|mo\u001a?6k&x\"";
      D[1] = "\u001e\u001eqI\u001ewk>zF\u000f8\n0qM\u000bb~";
      D[2] = void.class;
      E[2] = "java/lang/Void";
      D[3] = "LI\u0014\ng\u001bZI\u0011Pt\fM\u0002\u0012Vx\u0018\\E\u0005A3\nm";
      D[4] = int.class;
      E[4] = "java/lang/Integer";
      D[5] = "\u001eVj\r\u0004z\u001eV}Q\bu\u0004\u001d}O\b`\u0003l-\u0012Y";
      D[6] = "V;Al&TV;V0*[LpV.*NK\u0001\u0001q|";
      D[7] = "\u000f\tt<\u0006A\u0019\tqf\u0015V\u000eBr`\u0019B\u001f\u0005ewRR\u0004";
      D[8] = "\u0005\t99h4p)26y{\u0011'9=}!e";
      D[9] = "A\u0002\u001c\u0018%QA\u0002\u000bD)^[I\u000bZ)K\\8_\u0002~";
      D[10] = float.class;
      E[10] = "java/lang/Float";
      D[11] = boolean.class;
      E[11] = "java/lang/Boolean";
      D[12] = "`\u001eL/>_k\u0011]`R\\e\u0013_/~";
      D[13] = "0Dx\u0013\u0019\u0017&D}I\n\u00001\u000f~O\u0006\u0014 HiXM\u0001\r";
      D[14] = "(.\u0012\u0011fn]\u000e\u0019\u001ew!<\u0000\u0012\u0015s{H";
      D[15] = "\u001a\u000f\u0015/\u0006\"\f\u000f\u0010u\u00155\u001bD\u0013s\u0019!\n\u0003\u0004dR1\u0012";
      D[16] = "or\u0004\u0010\u001cJ\u001aR\u000f\u001f\r\u0005{\\\u0004\u0014\t_\u000f";
      D[17] = "b\u0013\u0007\u000br_t\u0013\u0002QaHcX\u0001Wm\\r\u001f\u0016@&K@";
      D[18] = "p0(U\u007fw{?9\u001a\u001eyp4=@";
      D[19] = "\u0013\u000bnq- \u0018\u0004\u007f>J\"\r\u000f\u007fuq";
      D[20] = "{\u0016\u0017qTL\u000e6\u001c~E\u0003o8\u0017uAY\u001b";
      D[21] = "_K\u000fZ3ZIK\n\u0000 M^\u0000\t\u0006,YOG\u001e\u0011gNC";
      D[22] = "ix)+$ \u001cX\"$5o}V)/15\t";
      D[23] = "koK\f\u00055\u001eO@\u0003\u0014z\u007fAK\b\u0010 \u000b";
      D[24] = "1Z\nL3Y1Z\u001d\u0010?V+\u0011\u001d\u000e?C,`OZn\u0002";
      D[25] = "O\rzU\u0010YO\rm\t\u001cVUFm\u0017\u001cCR7?LD\u0002";
      D[26] = "lit&`\u001dziq|s\nm\"rz\u007f\u001e|eem4\u000bj";
      D[27] = "\u0001<\u0013B\u0013't\u001c\u0018M\u0002h\u0015\u0012\u0013F\u00062a";
      D[28] = "D\u0005\u0016U>\u0011D\u0005\u0001\t2\u001e^N\u0001\u00172\u000bY?PO`";
      D[29] = "~\u0015S>q4u\u001aBq\u00129`\u0017M\u001a';q\u0004Q606";
      D[30] = "\n{NrVH\u007f[E}G\u0007\u001eUNvC]j";
      D[31] = "_3a\tK>*\u0013j\u0006ZqK\u001da\r^+?";
      D[32] = "\u0011&(/`\u0003\u0011&?sl\f\u000bm?ml\u0019\f\u001cj25";
      D[33] = ")C-r[V)C:.WY3\b:0WL4yhn\u0000\u0007";
      D[34] = "?@\u001f1/%)@\u001ak<2>\u000b\u0019m0&/L\u000ez{2-";
      D[35] = "y4Lm<\u0016\f\u0014Gb-Ym\u001aLi)\u0003\u0019";
      D[36] = double.class;
      E[36] = "java/lang/Double";
      D[37] = "\u001dNW\u0015VQ\u000bNROEF\u001c\u0005QIIR\rBF^\u0002F*";
      D[38] = "&.Y!\\U-!Hn?X8'";
      D[39] = "0\u00041\ne\u00020\u0004&Vi\r*O&Hi\u0018->t\u00131R";
      D[40] = "f!\u0001=b\ff!\u0016an\u0003|j\u0016\u007fn\u0016{\u001bF&<W";
      D[41] = "fI d(X\u0013i+k9\u0017rg `=M\u0006";
      D[42] = "[3.9\u0013\bM3+c\u0000\u001fZx(e\f\u000bK??rG\u001fH";
      D[43] = "\u0010\u0014\u0017\u001ej\b\u000e\u001c\rQ\b\u0014\t\u0001";
      D[44] = "W94\u001e:\u0010I1.Q]\u0011X*#\u000b{\u0017";
      D[45] = "Uu\u0013\u0013w? U\u0018\u001cfpA[\u0013\u0017b*5";
      D[46] = "\u0012n#cT\u0003\u0019a2,>\u0000\rm9g";
      D[47] = "+jP^\u000eN+jG\u0002\u0002A1!G\u001c\u0002T6P\u0015F[\u0013";
      D[48] = "GEER\u001eQGER\u000e\u0012^]\u000eR\u0010\u0012KZ\u007f\u0000JF\u000f";
      D[49] = "}\u0019Sw\u001d\u000bc\u0011I8f+^<";
      D[50] = "m\u001a@Ci@{\u001aE\u0019zWlQF\u001fvC}\u0016Q\b=Se\u0016S\u0003g\u001eY\rS\u001egYn\u001a";
      D[51] = "\n\u0005?J+X\u001c\u0005:\u00108O\u000bN9\u00164[\u001a\t.\u0001\u007fN:";
      D[52] = "R\u000eS\u001cA7D\u000eVFR SEU@^4B\u0002BW\u0015!y";
      D[53] = "YYh(%\u0005GQrgX\u0015G";
      D[54] = "\\\u0007\u0019T0_\\\u0007\u000e\b<PFL\u000e\u0016<EA=\\Hd\u0001";
      D[55] = "+pb6=u+puj1z1;ut1o6J$-f-";
      D[56] = "\u001dU=\u001cGB\u0016Z,S:Z\u0005]%\u001a";
      D[57] = "$I\u0018+>\u0018Qi\u0013$/W0g\u0018/+\rD";
      D[58] = "ce2#Wdhj#l0|lv% \u0015m";
      D[59] = "\u0002SS69>wsX9(q\u0016}S2,+b";
      D[60] = "?Tn[e{JteTt4+zn_pn_";
      D[61] = ":c\u001b?ul$k\u0001p\u0018v<n\b=/p?l";
      D[62] = "\u000bI\u007f2y&\u0000Fn}\u0011&\u000eI}";
      D[63] = "MU&K5\u001f8u-D$PY{&O \n-";
      D[64] = "qy+>J|gy.dYkp2-bU\u007fau:u\u001ehl";
      D[65] = "\u0013\u00079>\u007f4f'21n{\u0007)9:j!s";
      D[66] = "3i}+\u0004\u0004FIv$\u0015K'G}/\u0011\u0011S";
      D[67] = "AaL5\u0010\u00124AG:\u0001]UOL1\u0005\u0007!";
      D[68] = "/d`t\u0016\u0010ZDk{\u0007_;J`p\u0003\u0005O";
      D[69] = "d1F\u0014\u0005@\u0011\u0011M\u001b\u0014\u000fp\u001fF\u0010\u0010U\u0004";
      D[70] = ">.3Hf^K\u000e8Gw\u0011*\u00003LsK^";
      D[71] = "\u00001e\u0007\bou\u0011n\b\u0019 \u0014\u001fe\u0003\u001dz`";
      D[72] = "dB[>X_\u0011bP1I\u0010pl[:MJ\u0004";
      D[73] = ")$\u0005[@pj>\\\u0012}ts(\u0005O*#-x\\#Ab\u007f'\u0013\u0013\u0014\u007f\u007f|";
      D[74] = ";B#>2\u0011xM5a\u0003\u001e),ve2\u001b?U&3>\u0010G";
      D[75] = "%j11~7b#(bk\u000bpZj`)sd9(kl0'Zjrn5~=(`ly\u001c";
      D[76] = "w3+^\"h4`k\u0004\u0019n$!3Ru\\sac\u000f)\u000bv::Le4q4mI\u0019";
      D[77] = "oAyS;G,\u00129\t\u0000A<Sa_lsj\u0011=\u0005=$n\u00170Wx]>A<\\\u0000";
      D[78] = "~\u000f`_\u0017H8W3Q\u00159(X\u007fx\u000eC&Sl#K\u0003:[gI\u0015[?\u000bc#";
      D[79] = "\tU^2\u0011\u001f\rXYyp\u001f\u0011_eq\u001f\u001e\tI\u000bpH\u0019\u001e9\u001df\u0014\u0003\u0000W\u001c1\u0013\u0014pA\nm\t\n\u001e@]j\u001ez";
      D[80] = "]\u0013=\u0015UrR\u001c1\u001d3d<\u001a-GKq_X&\u0002\b2<\u001c'\u0012Ju\u0003\u001b)EO\t";
      D[81] = "w\u0019>\u0011^\u001d1[o\u00077Ib\u001ed\u000e[{5Y?S\u000e,w\r`\u0010GBvZg\u00077";
      D[82] = "TklHX7UenI:oFewSV]\u0011\",\u000e\u0003\nSvsMJdR!tZ:";
      D[83] = "'E\u007f\u0015aN(Js\u001d\u0007_FLoG\u007fM%\u000ed\u0002<\u000eF\b=@vQ*\t~Gl5";
      D[84] = ";l\u0012\u0017\u000e x?RM5&h~\n\u001bY\u0014>9WC\fCgf\u0007\u0000P;j3Q\u00125";
      D[85] = "hy\u000e%\u001fn',Q& :`5\u0005x[Wur]m\u001c3\u007fpSd h~!\u0015`\u001fopv\u0010\u001c";
      D[86] = "o\u0006=Z5l`\t1RS~\u000eU:\ri-1\\:J>\u0017mLy\u000ei(dL>YS";
      D[87] = "\\D_]$\u0017SKSUB\u0000=MO\u000f:\u0014^\u000fDJyW=KEZ;\u0010\u0002LK\r>l";
      D[88] = "p\u0006.JRtrQ=@\r\u0018\"Y9S\ny/E_CY)8\u0002;I['1>`H\na5\u0001gF]dI";
      D[89] = "/&\n\u007f\u000f\u001fid[ifK:!P`\nyjm\t;fV89Iw\bWo>^\u0007\u001eA3$@i\u001f\u0016430\u007f\tJ.-^~^M9]\tx\u001d\u00105:Kj\u001f\\W";
      D[90] = "*[ga\tBt\rdc1P-]jtf\u0003|\b>\u0018WU%I6d\t\u0003&K";
      D[91] = "{X\u001dv%\"zV\u001fwGziV\u0006m+H=\u001aY;w\u001ffN\u000bv\"gk\u001b]dG";
      D[92] = "a)!r\u001d|n&-z{k\u0000 1 \u0003\u007fcb:e@<\u0000e2v\u00186e&=`G\u0007";
      D[93] = "5c@!cy5iTvY-\t*\\%!<jhW`b\u007f\t*Nbg&nh\\`+D";
      D[94] = "\fh 1Xu\u0001=v#=h\u0003p-*QZW4w|=o\na1(Eb_7#M";
      D[95] = "$\u001exf+VhX&<K\\s\u0003x6\"PJ\rx&&6+\u0003u\"7\t,\r\"'K";
      D[96] = "Iw[|H\u0005\n$\u001b&s\u0003\u001aeCp\u001f1L'\u001f*LfH!\u0012x\u000b\u001f\u0018w\u001ess_\bb\u001du\u0014\u001d\u001a`Q\u0017";
      D[97] = "\u000b\t\u001el+c[H\u0007gN91\u000fC55 _\rJ<$R";
      D[98] = "NK.\u0019}g\u0018\u001e~HEn\u007fI/\u0014=|\u001c\u000b$Q~?\u007fO%A<x@H+\u00169\u0004";
      D[99] = "V\u000e(/&\u0014[[~=C\u0002U\u0007!?\u0014U\u000fW}S;\u0003P\u00135=:TW\u0004";
      D[100] = "W|\u0019\u0004{vO5\\\u0000\u0010jS\u0003\u0006\u0018qwEM\u001f\u0011trX#\u001eFse(r\u0000\u0017iw\u0017u\u000e@l\u000b";
      D[101] = "_dyAN\u001c\u001c~ \bs\u0018\u0005hyU$O[?!9M\u0018\u001cn&Z\u000eK\\4";
      D[102] = "7ao\u001fCC0?}M3GYeh\u001fKV:'cZ\b\u0015Yc=\u0012\\V 3k\u001eW.";
      D[103] = "upUxw\u0017q}R3\u0016\u000ekP\u0003,l\u001fagn;y\u0016ul\u0000:.\u0011b\u001c\u0016,r\u000b|r\u0017{u\u001c\f";
      D[104] = "Ow\u0002\u00113\u0013V,\u001d\nU\u0001X5<\u0006%\u001d1q\u001d\u0002,\u001d\u000ev\u0013U)a";
      D[105] = "Yd\u0015\u0012psX'\u0012\b\u0014~_\u0016K\u001bhn$dI\nmc\u001bcG]h\u001f";
      D[106] = "P=.&{\u0013\u0013nn|@\u0015\u0003/6*,'Umjp~pQkg\"8\t\u0001=k)@I\u0011(h/'\u000b\u0003*$M";
      D[107] = "\u001avDc}t\u00077F4\u0013c\u001foD7Tsv0\u00013ho\u00182\b:y\u001d\u001avDc}t\u00077F4\u0013";
      D[108] = "-;\u0003$V1kyR2?e8<Y;SWlp\u0006m\u000e\u00007$T Zx:q\u00022?9*;\u0007>X{89K\\";
      D[109] = "}=JL0\u0003y0M\u0007Q\ri0\u0015w)\t`(\u0001\u0019(^g?q\u000f>\u0002}!\u001f\u000ei\u0005jQ";
      D[110] = "\nVh\u0010d_\u000bXj\u0011\u0006\u0007\u0018Xs\u000bj5H\u001a)\\\u0006YMMh\u001eh[DDyl";
      D[111] = "!\u0018N8Iu!\tH92'SJJbJ60\bA'\tuS\u0003W<Y0=\tK<JN";
      D[112] = "?\u0018\u0006[q}8F\u0014\t\u0001zQ\u001c\u0001[yh2^\n\u001e:+Q\u001aTVnh(J\u0002Ze\u0010";
      D[113] = "jP\fi2ie_\u0000aT{\u000bY\u001c;,jh\u001b\u0017~o)\u000b\u001c\u001fm7#n_\u0010{h\u0012";
      D[114] = "\u0012\u0000\u0001=\u000f{Q\u000f\u0017b>t\u0001n\u00131Zg\u001e\u0000\u0012f]pn";
      D[115] = "e5+$j=dv,>\u000e8tf\u001094`i6t36n`\n/2g(d5(<0-\u0018";
      D[116] = "V<^%\u0003aW\u007fY?gvJq\bT\\5Bx\u0017:^<Kie";
      D[117] = "\u0018\u0002Lex\u0007LS\u0017l!zOY\u0011~m$HY\u000bz\u0011E\u0019\f\u0019oh\u0015O\u0000\u0012\u0017";
      D[118] = "'qk7\u0012(*$=%w5(if,\u001b\u0007|-<rw(*q\u007f;\u0019)}vhK\u00154(ic3\u0018a~{\u0006";
      D[119] = "#fir\u0004H>'k%jJ(~l\"\u0010LO ,\"\u0011S!\"%+\u0000!t#}0\u0018Ov*t!j\u001awro9\u0004\u0018~{~K";
      D[120] = "Br\u001c\fz)M}\u0010\u0004\u001c0#{\f^d*@9\u0007\u001b'i#{\u001e\u0019\"0D9\f\u001bnR";
      D[121] = "Hnz\u0015t!^#|-`\u001b\u001fs}Urx]x8\u00161\u001b\u001fa:\u0013h|]s8_\n";
      D[122] = "-A\u0019Q29)L\u001e\u001aS9=]\"\u0012<8-]L\u0013k?:-Z\u00057%$C[R02TUM\u000e*,:T\u001a\t=\\";
      D[123] = "ikvgV\u0017$4'9lK\u001b%|4\nV %m2\u000b";
      D[124] = "W$x\u0001\"b\u001a{)_\u00187%!!\u0005z2C'y](a";
      D[125] = "bq\u0016\"\u001e^!\"Vx%X1c\u000e.Ijg!Rt\u0019=c'_&]D3qS-%";
      D[126] = "\u0015(\u001dM\u001dI\u0017w\u0006\u0017 R\u0003k\u0019NL`W*B\u0017\u001a7\u0016x\u001dPPY\u0017/\u001aG \bV&\u0016QYX\u0000*\u001d)";
      D[127] = "!\\G\u0017fc \u001f@\r\u0002n \u000e\u0006\u000f~h&c\u0002_zu:\u0011\u001b\u0004en\\";
      D[128] = "!\b\u0007\u0004E5b\u0012^Mx:w\u0015\u0003\u001b\u0014\b#T]Mx`}\u0000\u001a\u0000GgsW\u001f|";
      D[129] = "bw%ey\u000f!x3:H\u0000\u007f\u00197i,\u0013nw6>+\u0004\u001e";
      D[130] = "\\P\u00114Z;A\u0011\u0013c43VQ2dP/]-W5])BCU<T80";
      D[131] = "\u0003?(%(\u0000\u00021*$JX\u001113>&jFqbcs=Et5#5\u0000\u0012p=31=";
      D[132] = "}.\f>ySdu\u0013%\u001fGng\bDs\u001b2fH y\u0019<ot";
      D[133] = "R\b!\\FrJAdX-dJ\\'OWb-A0BT\u007fC@gEC\u000fUV;_]aT\u0001<H-4\u0015P$TC6\u001cY5&";
      D[134] = "sf=Z5/wk:\u0011T#`q\u0006^l{er\u007f\u000e:wn\n9Ye%rsi\u000fi.\n";
      D[135] = "\u000f+/\u0017%@\u00143\u007f\b[I\u0004Zh\u0017?Z\u00194i@8Mi";
      D[136] = "\u0007H\u001f9\u001d;\bG\u00131{*fA\u000fk\u00038\u0005\u0003\u0004.@{f\u0016_=G0\u000b\u0011\u0001/\u0015@";
      D[137] = "\tM\u001e7L\u0001\u0004\u0018H%)\u0017\nD\u0017'~@P\u0014IKQ\u0016\u000fP\u0003%PA\bG";
      D[138] = "\u0019C\u0003D9R\u0014\u0016UV\\D\u001aJ\nT\u000b\u0013@\u001aW8$E\u001f^\u001eV%\u0012\u0018I";
      D[139] = "\u0003\n<S)i\r\u0012'\u0010Dk\u000e\n!\u000b(Y\\F|PDt]\u0006<U?`\u000fH:l";
      D[140] = "\u0015\u0004\u000b9K\u0013\u0015\u000e\u001fnqG)M\u0017=\tVJ\u000f\u001cxJ\u0015)\u0018\u0007|H@@\u0005F~\u001f.";
      D[141] = "\u0019\u0002~\t6\u000f\u001b]eS\u000b\u0014\u000fAz\ng&[\u0000!R7q\u001aR~\u0014{\u001f\u001b\u0005y\u0003\u000bNZ\fu\u0015r\u001e\f\u0000~m";
      D[142] = "x\u0007@>lFy\tB?\u000e\u001ej\t[%b,=N\u0000{1{\u007f\u001a_;~\u0015~MX,\u000e";
      D[143] = "'\u000ff\u0002\u0006R!W>PU4w7a\rPLfT#\u0006\u0015\u000f%7g\u0007\u0005Mb\b`\tRH\u001e";
      D[144] = "(cr\u0002\u001aA*4a\bE-v5\u0003\u000b\u0011\u001c`gg\u0001\u0013\u0012i[o]\u001a\\-?e_\u0014U\u001179VZ\u0011u=;XS-}a2\u0016\u0017Iwc<\u001f+\u0014)*fVG\u0016~9l\t+";
      D[145] = "?\u0013c:/\fyQ2,FX*\u00149%*j}Sb{y=?\u0007=;6S>P:,F";
      D[146] = "\u001e]8\u0004^6]R.[o9\u00023i_\u0006(\u0010]kV\u000f9b";
      D[147] = "\u0000[d'}\f\u0002\fw-\"`C\u000ei+-\u0006p\u0007qBu^@\u001fl/'PK\u0006|Bs\u0007P\u001ai}t\t\u0007\u001f\u0015";
      D[148] = "\u0019y*E};\u0016v&M\u001b)xp:\u0017c8\u001b21R {xv0Bb<Gq>\u0015g@";
      D[149] = "p\u0001m\u0013L,3\u001b4Zq(*\rm\u0007&\u007fuP6k\u0014/qZg\r\u000fx*X";
      D[150] = "d|GoXVe?@u<Ut?|%\u0004Sb1\u0012'\rZsC\u0010$\rK%'\u001a&\u0003B\u0019";
      D[151] = "\u000bMjaL`\nCh`.8\u0019CqzB\nN\u0004*$\u001e]\fPud^3\r\u0007rs.";
      D[152] = "\u0005!\u0001/<\u0013CcP9UG\u0010&[09uGa\u0000ne\"\u00055_.%L\u0004bX9U";
      D[153] = "uDuzR}\u007fXui,vhHwv@D8\n).,b4V..\u0015-a\t-\u0011";
      D[154] = "\u0019=\u0005\u0011\u001d7I|\u001c\u001axl#;XH\u0003tM9QA\u0012\u0006";
      D[155] = "\u0013Q#uq4\bIsj\u000f=\u001e ~~b+\u0010Xs+49u";
      D[156] = "B\u001eU~\u0010_@IFtO3\u0012JH\u001bM\tJW\u0018\u007fG\u000bD^$$FZ\u0002Z\u001b#H\r\u0007&";
      D[157] = ".\u0005\u0002y\u000fF5S\u000712_D\u0005\fuJL'G\u00070\t\u000fD\u0003\u0006 KH{\u0004\bwN4";
      D[158] = "KU\u001f~yYBU\u0015+\u0017Z!H_qf\u000fEB]\u007fo3";
      D[159] = "$\u0004n<+RgW.f\u0010Tw\u0016v0|f'U-f\u0010\b#\fl(-_'\u0004|,\u0010\u000e\"[y/i^tWrW";
      D[160] = "&}-ZU.a44\t@\u0012rMv\u000b\u0002jg.4\u0000G)$Mv\u0019E,}*4\u000bG`\u001f";
      D[161] = "Q\u0013,Sp,\u0007F|\u0002H&`\u0011-^07\u0003S&\u001bst`\u0011?\u0019v-\u0007S-\u001b:O";
      D[162] = "\u001a:syB\u001bWe\"'xFh?\"!DJTxk8\u0017_";
      D[163] = "?r\frB(?x\u0018%x|\u0003;\u0010v\u0000m`y\u001b3C.\u00039E#\u0003gm;L*\u0012\u0015";
      D[164] = "#\u001bS:@?~\bC~{(\"\u001cU+,v}J\rG\u001b:>N\\ \u0015\"%\r";
      D[165] = "h\u0006(\u0005:\u0014eS~\u0017_\tg\u001e%\u001e3;3Z\u007fC_\u000en\u000f9\u001c'\u0003;Y+y'\u0003n\u001b5\u0017&Ti\fE";
      D[166] = "\u000e%Xg}\u0002\u0001*To\u001b\u0010o,H5c\u0001\fnCp BowAdg\u001c\u0017z\u00142uy";
      D[167] = "4\u0003+\u0015^[>\u001f+\u0006 P)\u000f)\u0019LbyOvA \f~\u00105\u001bQJ&C;\u0019 ";
      D[168] = "j\u0001}0$\u0016q\u0019-/Z\u001f`pyg3\u000e~\u001e{n:\u001f\f";
      D[169] = "MDIwJ\\\u0015\u0017Fd\be\u0015\u0004Dw\u001e\u0019\u0013\u0002)sN\u001d\u000e\u001e[j\u0015\u0002\u0015x";
      D[170] = "->0\u000bDU'\"0\u0018:V$3;\u0004A;1tc\u0011\u0006_;vm\u0018:\u0004:'+\u001c\u0005\u00034p.`";
      D[171] = "/\u0013@\u0005\u0004x \u001cL\rbhN\u001aPW\u001a{-X[\u0012Y8N_S\u0001\u00012+\u001c\\\u0017^\u0003";
      D[172] = "?$_$dP;)Xo\u0005\\:!\u0002%\u0005M),\u001dokL~+\n\u001f}Z\"1\u0014q|\r%&dgjQ?8\nf=V(H";
      D[173] = "H\u0018\u0018nUp\u000eZIx<$]\u001fBqP\u0016\r\\\u001d-<xO\u0018\u001ct[:]\u001aP\u0016";
      D[174] = "5\u0005]CU.:\nQK3<T\fM\u0011K-7NFT\bnTSQ\u0012\\+7HIBCU";
      D[175] = "Cs_}crL|Su\u0005c\"zO/}qA8Dj>2\"?Lyf8G|Co9\t";
      D[176] = "r-\u000eG\u001f pz\u001dM@L q\u0012KTLrj\u0004\u001cL+0x\u0006P.";
      D[177] = "^IF\b]LE\u001e\u001d\n3OV\\\u001cU_}\u0002\u0010E\u000b\t*\u0002\u001c\u001cH\u000e\u0013ZO\u0013[L*";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = D[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(E[var4]);
            D[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = D[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            D[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  D[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1326701222790613L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = D[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  D[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1326701222790613L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        D[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1326701222790613L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 102;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 208;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 72;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 230;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 118;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 90;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 102;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 208;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 72;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fb_C0274",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
