package dev.zprestige.prestige.client.modules.state;

public record PearlFollowSolution(float bf, double bg, int bh, double bi) {
}
