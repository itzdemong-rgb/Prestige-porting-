package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.Vec3d;

public record PearlPathSample(Vec3d bc, int bd, double be) {
}
