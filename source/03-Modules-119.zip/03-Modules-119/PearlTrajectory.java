package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.PositionRotation;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.util.projectile.PearlTrajectoryProjectile;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class PearlTrajectory extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private ColorSetting c;
   private BooleanSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private ColorSetting h;
   private static final int i;
   private static final Identifier j;
   private static ManagedGlTexture k;
   private Map l;
   private Map m;
   private Map n;
   private static final long o;
   private static final float p = 1.0F;
   private static final long q = 59052423444182L;
   private static final String[] r;
   private static final String[] s;
   private static final Map t = new HashMap(13);
   private static final long[] u;
   private static final Integer[] v;
   private static final Map w;
   private static final Object[] x = new Object[146];
   private static final String[] y = new String[146];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;

   public PearlTrajectory() {
      super();
      long var10001 = 130217955587872L ^ 92164548129888L;
      var10001 = 130217955587872L ^ 115553550124535L;
      var10001 = 130217955587872L ^ 42537127853196L;

      this.l = new HashMap();
      this.m = new HashMap();
      this.n = new HashMap();
      ColorSetting var10000 = this.c;
      Object[] var10 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var9 = var10000;
      var9.aReturningColorSetting(var10);
      BooleanSetting var19 = this.a;
      Object[] var12 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var11 = var19;
      var11.aReturningBooleanSetting(var12);
      BooleanSetting var20 = this.g;
      Object[] var14 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var13 = var20;
      var13.aReturningBooleanSetting(var14);
      var10000 = this.h;
      Object[] var16 = new Object[]{invokeBinding4(this), 41489415177024L};
      ColorSetting var15 = var10000;
      var15.aReturningColorSetting(var16);
      FloatSetting var22 = this.f;
      Object[] var18 = new Object[]{invokeBinding5(this), 34595201528535L};
      FloatSetting var17 = var22;
      var17.aReturningFloatSetting(var18);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 97542483353529L ^ 88383020405012L;
      int var6 = Event.cReturningInt();
      int var37 = var6;
      MinecraftClient var36 = b;
      MinecraftClient var31 = var36;
      MinecraftClient var30 = var36;
      if (var37 != 0) {
         MinecraftClient var10 = var30;
         ClientWorld var38 = var10.world;
         if (var38 == null) {
            return;
         }

         MinecraftClient var39 = b;
         var31 = var39;
      }

      int var41 = var6;
      MinecraftClient var40 = var31;
      MinecraftClient var33 = var40;
      MinecraftClient var32 = var40;
      if (var41 != 0) {
         MinecraftClient var13 = var32;
         ClientPlayerEntity var42 = var13.player;
         if (var42 == null) {
            return;
         }

         Map var16 = this.n;
         var16.clear();
         var33 = b;
      }

      MinecraftClient var17 = var33;
      ClientWorld var18 = var17.world;
      Iterable var19 = var18.getEntities();
      Iterator var7 = var19.iterator();

      while (true) {
         Iterator var20 = var7;
         boolean var43 = var20.hasNext();
         if (!var43) {
            break;
         }

         Iterator var21 = var7;
         Entity var8 = (Entity)var21.next();
         int var45 = var6;
         Entity var44 = var8;
         Entity var35 = var44;
         Entity var34 = var44;
         if (var45 != 0) {
            boolean var46 = var34 instanceof EnderPearlEntity;
            if (!var46) {
               continue;
            }

            var35 = var8;
         }

         EnderPearlEntity var9 = (EnderPearlEntity)var35;
         Map var10000 = this.n;
         EnderPearlEntity var23 = var9;
         int var24 = var23.getId();
         Integer var48 = var24;
         Object[] var26 = new Object[]{var9, 9709438045869L};
         PearlTrajectory var25 = this;
         ArrayList var29 = var25.aReturningArrayList(var26);
         Integer var28 = var48;
         Map var27 = var10000;
         var27.put(var28, var29);
         int var47 = var6;
         if (var47 == 0) {
            break;
         }
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 124945289952805L ^ 133554961166472L;
      var10001 = 124945289952805L ^ 121606001179232L;
      var10001 = 124945289952805L ^ 127279504514071L;
      int var10 = Event.cReturningInt();
      int var126 = var10;
      MinecraftClient var125 = b;
      MinecraftClient var104 = var125;
      MinecraftClient var103 = var125;
      if (var126 != 0) {
         MinecraftClient var28 = var103;
         ClientWorld var127 = var28.world;
         if (var127 == null) {
            return;
         }

         MinecraftClient var128 = b;
         var104 = var128;
      }

      MinecraftClient var31 = var104;
      ClientPlayerEntity var129 = var31.player;
      if (var129 != null) {
         Map var33 = this.l;
         var33.clear();
         long var11 = System.currentTimeMillis();
         HashSet var13 = new HashSet();
         MinecraftClient var34 = b;
         ClientWorld var35 = var34.world;
         Iterable var36 = var35.getEntities();
         Iterator var14 = var36.iterator();

         while (true) {
            Iterator var37 = var14;
            boolean var130 = var37.hasNext();
            if (var130) {
               Iterator var38 = var14;
               Entity var15 = (Entity)var38.next();
               int var132 = var10;
               Entity var131 = var15;
               Entity var108 = var131;
               Entity var105 = var131;
               if (var132 != 0) {
                  boolean var10000 = var105 instanceof EnderPearlEntity;
                  int var134 = var10;
                  boolean var133 = var10000;
                  boolean var106 = var133;
                  if (var134 == 0) {
                     break;
                  }

                  boolean var135 = var106;
                  boolean var107 = var135;
                  boolean var136 = var107;
                  if (!var136) {
                     continue;
                  }

                  var108 = var15;
               }

               EnderPearlEntity var16 = (EnderPearlEntity)var108;
               EnderPearlEntity var41 = var16;
               int var17 = var41.getId();
               int var42 = var17;
               Integer var44 = var42;
               HashSet var43 = var13;
               var43.add(var44);
               Map var160 = this.m;
               int var45 = var17;
               Integer var173 = var45;
               long var46 = var11;
               Long var50 = var46;
               Integer var49 = var173;
               Map var48 = var160;
               var48.putIfAbsent(var49, var50);
               var160 = this.n;
               int var51 = var17;
               Integer var53 = var51;
               Map var52 = var160;
               ArrayList var18 = (ArrayList)var52.get(var53);
               int var138 = var10;
               ArrayList var137 = var18;
               ArrayList var110 = var137;
               ArrayList var109 = var137;
               if (var138 != 0) {
                  ArrayList var139 = var109;
                  if (var139 == null) {
                     Object[] var56 = new Object[]{var16, 9709438045869L};
                     PearlTrajectory var55 = this;
                     var18 = var55.aReturningArrayList(var56);
                     var160 = this.n;
                     int var57 = var17;
                     Integer var174 = var57;
                     ArrayList var60 = var18;
                     Integer var59 = var174;
                     Map var58 = var160;
                     var58.put(var59, var60);
                  }

                  var110 = var18;
               }

               ArrayList var61 = var110;
               int var163 = var61.size();
               int var142 = var10;
               byte var141 = 2;
               int var140 = var163;
               int var113 = var140;
               byte var114 = var141;
               int var111 = var140;
               byte var112 = var141;
               if (var142 != 0) {
                  byte var144 = var112;
                  int var143 = var111;
                  if (var143 < var144) {
                     continue;
                  }

                  ArrayList var63 = var18;
                  int var164 = var63.size();
                  var114 = 1;
                  var113 = var164;
               }

               float var19 = (var113 - var114) / 20.0F;
               Map var175 = this.m;
               int var64 = var17;
               Integer var66 = var64;
               Map var65 = var175;
               Long var67 = (Long)var65.get(var66);
               long var20 = var11 - var67;
               float var69 = (float)var20 / 1000.0F;
               float var68 = 1.0F;
               float var22 = Math.min(var68, var69);
               float var71 = var19 / 1.0F;
               float var70 = 1.0F;
               float var23 = Math.min(var70, var71);
               float var24 = var22 * var23;
               BooleanSetting var72 = this.d;
               Boolean var165 = (Boolean)var72.aReturningObject();
               int var146 = var10;
               Boolean var145 = var165;
               Object var123 = var145;
               Boolean var115 = var145;
               if (var146 != 0) {
                  Boolean var73 = var115;
                  boolean var147 = var73;
                  label75:
                  if (var147) {
                     Color var122;
                     label73: {
                        Object var121;
                        label98: {
                           float var178;
                           int var166 = (var178 = var24 - 0.01F) == 0.0F ? 0 : (var178 < 0.0F ? -1 : 1);
                           int var149 = var10;
                           int var148 = var166;
                           int var120 = var148;
                           int var116 = var148;
                           if (var149 != 0) {
                              int var150 = var116;
                              int var117 = var150;
                              int var151 = var117;
                              if (var151 <= 0) {
                                 break label75;
                              }

                              BooleanSetting var77 = this.a;
                              Boolean var167 = (Boolean)var77.aReturningObject();
                              int var153 = var10;
                              Boolean var152 = var167;
                              var121 = var152;
                              Boolean var118 = var152;
                              if (var153 == 0) {
                                 break label98;
                              }

                              Boolean var154 = var118;
                              Boolean var119 = var154;
                              Boolean var79 = var119;
                              byte var155 = ((byte)(((java.lang.Boolean)(var79)).booleanValue() ? 1 : 0));
                              var120 = var155;
                           }

                           int var156 = var120;
                           if (var156 != 0) {
                              Object[] var81 = new Object[]{2617886958130L};
                              Color var157 = ClientUiUtil.dReturningColor(var81);
                              var122 = var157;
                              break label73;
                           }

                           ColorSetting var83 = this.c;
                           var121 = var83.aReturningObject();
                        }

                        var122 = (Color)var121;
                     }

                     Color var25 = var122;
                     byte var168 = 0;
                     short var176 = 255;
                     Color var84 = var25;
                     int var86 = (int)(var84.getAlpha() * var24);
                     int var88 = Math.min(255, var86);
                     int var26 = Math.max(0, var88);
                     Color var89 = var25;
                     int var10002 = var89.getRed();
                     Color var90 = var25;
                     int var10003 = var90.getGreen();
                     Color var91 = var25;
                     Color var27 = new Color(var10002, var10003, var91.getBlue(), var26);
                     Object[] var92 = new Object[]{var1.b, var1.a, var18, var27, 34336336184389L};
                     ShapeRenderer.cReturningVoid(var92);
                  }

                  ArrayList var93 = var18;
                  int var95 = var93.size() - 1;
                  ArrayList var94 = var18;
                  var123 = var94.get(var95);
               }

               Vec3d var159 = (Vec3d)var123;
               var160 = this.l;
               int var96 = var17;
               Integer var177 = var96;
               PositionRotation var99 = new PositionRotation(var159, var19, var24);
               Integer var98 = var177;
               Map var97 = var160;
               var97.put(var98, var99);
               int var158 = var10;
               if (var158 != 0) {
                  continue;
               }
            }

            Map var100 = this.m;
            Set var170 = var100.keySet();
            HashSet var102 = var13;
            Set var101 = var170;
            boolean var124 = var101.retainAll(var102);
            break;
         }
      }
   }

   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      long var10001 = 113851151141719L ^ 116171419730546L;
      var10001 = 113851151141719L ^ 115134536123818L;
      var10001 = 113851151141719L ^ 58996015162445L;
      var10001 = 113851151141719L ^ 14806780098922L;
      var10001 = 113851151141719L ^ 25463848235970L;
      var10001 = 113851151141719L ^ 79855514604072L;
      var10001 = 113851151141719L ^ 7694469195571L;
      var10001 = 113851151141719L ^ 103796588811302L;
      var10001 = 113851151141719L ^ 45480480830359L;
      var10001 = 113851151141719L ^ 55781551703427L;
      var10001 = 113851151141719L ^ 7986365351665L;
      var10001 = 113851151141719L ^ 121724432432596L;
      int var28 = Event.cReturningInt();
      BooleanSetting var67 = this.e;
      Boolean var68 = (Boolean)var67.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var68)).booleanValue() ? 1 : 0));
      int var150 = var28;
      byte var149 = (byte)var10000;
      byte var132 = var149;
      byte var131 = var149;
      if (var150 != 0) {
         byte var151 = var131;
         if (var151 == 0) {
            return;
         }

         Object[] var71 = new Object[]{107148888616036L};
         PearlTrajectory var70 = this;
         var132 = ((byte)((var70.dReturningBoolean(var71)) ? 1 : 0));
      }

      int var153 = var28;
      byte var152 = var132;
      byte var134 = var152;
      byte var133 = var152;
      if (var153 != 0) {
         byte var154 = var133;
         if (var154 == 0) {
            return;
         }

         Map var73 = this.l;
         var134 = ((byte)((var73.isEmpty()) ? 1 : 0));
      }

      int var156 = var28;
      byte var155 = var134;
      byte var136 = var155;
      byte var135 = var155;
      if (var156 != 0) {
         byte var157 = var135;
         if (var157 != 0) {
            return;
         }

         BooleanSetting var75 = this.g;
         Boolean var76 = (Boolean)var75.aReturningObject();
         var136 = ((byte)(((java.lang.Boolean)(var76)).booleanValue() ? 1 : 0));
      }

      byte var29 = var136;
      byte var158 = var29;
      Color var137;
      if (var158 != 0) {
         ColorSetting var77 = this.h;
         Color var159 = (Color)var77.aReturningObject();
         var137 = var159;
      } else {
         var137 = null;
      }

      Color var30;
      MsdfFont var31;
      float var32;
      label98: {
         var30 = var137;
         MsdfFontManager var182 = Prestige.c;
         Object[] var80 = new Object[]{51869363673471L};
         MsdfFontManager var79 = var182;
         var31 = var79.aReturningcx_C0158(var80);
         Object[] var82 = new Object[]{15549079685413L};
         MsdfFont var81 = var31;
         var32 = var81.cReturningFloat(var82);
         int var161 = var28;
         ManagedGlTexture var160 = k;
         ManagedGlTexture var139 = var160;
         ManagedGlTexture var138 = var160;
         if (var161 != 0) {
            ManagedGlTexture var162 = var138;
            if (var162 != null) {
               break label98;
            }

            Object[] var84 = new Object[]{j, 86660470323392L};
            ManagedGlTexture var163 = ManagedGlTexture.dReturningbT_C0095(var84);
            var139 = var163;
         }

         k = var139;
      }

      float var33 = 1.0F;
      float var34 = 16.0F * var33;
      float var35 = 3.0F;
      float var36 = 0.5F;
      float var37 = 4.0F;
      float var38 = 3.0F;
      float var39 = 5.0F;
      Color var40 = new Color(255, 255, 255, 50);
      Map var86 = this.l;
      Collection var87 = var86.values();
      Iterator var41 = var87.iterator();

      while (true) {
         Iterator var88 = var41;
         boolean var164 = var88.hasNext();
         if (!var164) {
            break;
         }

         Iterator var89 = var41;
         PositionRotation var42 = (PositionRotation)var89.next();
         int var166 = var28;
         PositionRotation var165 = var42;
         PositionRotation var141 = var165;
         PositionRotation var140 = var165;
         if (var166 != 0) {
            float var205;
            int var167 = (var205 = var140.c - 0.01F) == 0.0F ? 0 : (var205 < 0.0F ? -1 : 1);
            if (var167 <= 0) {
               continue;
            }

            var141 = var42;
         }

         double var95 = 0.6;
         Vec3d var92 = var141.a;
         Object[] var99 = new Object[]{var92.add(var93, var95, var97), 123853079263381L};
         Vec3d var43 = GameRenderUtil.aReturningVec3d(var99);
         Vec3d var100 = var43;
         double var206;
         var10000 = (var206 = var100.z - 0.0) == 0.0 ? 0 : (var206 < 0.0 ? -1 : 1);
         int var169 = var28;
         int var168 = var10000;
         int var143 = var168;
         int var142 = var168;
         if (var169 != 0) {
            int var170 = var142;
            if (var170 < 0) {
               continue;
            }

            Vec3d var102 = var43;
            double var207;
            var143 = (var207 = var102.z - 1.0) == 0.0 ? 0 : (var207 < 0.0 ? -1 : 1);
         }

         int var171 = var143;
         if (var171 < 0) {
            String var44;
            float var46;
            float var49;
            float var50;
            float var51;
            Matrix4f var53;
            float var54;
            float var55;
            float var56;
            Color var146;
            label85: {
               Object[] var198 = new Object[1];
               float var103 = var42.b;
               var198[0] = var103;
               Object[] var105 = var198;
               String var104 = "%.1fs";
               var44 = String.format(var104, var105);
               FloatSetting var106 = this.f;
               Float var107 = (Float)var106.aReturningObject();
               float var45 = var107;
               Object[] var109 = new Object[]{var44, 117628177084989L};
               MsdfFont var108 = var31;
               var46 = var108.aReturningFloat(var109);
               float var111 = var46;
               float var110 = var34;
               float var47 = Math.max(var110, var111);
               float var48 = var34 + var35 + var36 + var35 + var32;
               var49 = var47 + 2.0F * var37;
               var50 = var48 + 2.0F * var38;
               Vec3d var112 = var43;
               var51 = (float)var112.x / var45;
               Vec3d var113 = var43;
               float var52 = (float)var113.y / var45;
               Matrix4f var184 = new Matrix4f();
               float var117 = var45;
               float var116 = var45;
               float var115 = var45;
               Matrix4f var114 = var184;
               var53 = var114.scale(var115, var116, var117);
               var54 = var51 - var49 / 2.0F;
               var55 = var52 - var50 / 2.0F;
               var56 = var42.c;
               int var173 = var28;
               Color var172 = var30;
               Color var145 = var172;
               Color var144 = var172;
               if (var173 != 0) {
                  Color var174 = var144;
                  if (var174 == null) {
                     Object var175 = null;
                     var146 = (Color)var175;
                     break label85;
                  }

                  var145 = var30;
               }

               Object[] var10004 = new Object[]{null, null, 93697647103700L};
               var10004[1] = var56;
               var10004[0] = var145;
               Object[] var120 = var10004;
               var146 = aReturningColor(var120);
            }

            Color var58;
            Color var59;
            label108: {
               Color var57 = var146;
               Object[] var201 = new Object[]{null, null, 93697647103700L};
               var201[1] = var56;
               var201[0] = var40;
               Object[] var121 = var201;
               var58 = aReturningColor(var121);
               var59 = new Color(255, 255, 255, (int)(255.0F * var56));
               int var177 = var28;
               byte var176 = var29;
               int var148 = var176;
               byte var147 = var176;
               if (var177 != 0) {
                  byte var178 = var147;
                  if (var178 == 0) {
                     break label108;
                  }

                  float var208;
                  int var179 = (var208 = var56 - 0.3F) == 0.0F ? 0 : (var208 < 0.0F ? -1 : 1);
                  var148 = var179;
               }

               int var180 = var148;
               if (var180 > 0) {
                  MeshBufferManager var185 = var1.a;
                  RenderContext var199 = var1.b;
                  Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 16745277116157L};
                  var10011[8] = var39;
                  var10011[7] = 5;
                  var10011[6] = var50;
                  var10011[5] = var49;
                  var10011[4] = var55;
                  var10011[3] = var54;
                  var10011[2] = var53;
                  var10011[1] = var199;
                  var10011[0] = var185;
                  Object[] var124 = var10011;
                  BlurredRectangleRenderer.eReturningVoid(var124);
               }

               MeshBufferManager var186 = var1.a;
               RenderContext var200 = var1.b;
               Object[] var204 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
               var204[8] = var39;
               var204[7] = var57;
               var204[6] = var50;
               var204[5] = var49;
               var204[4] = var55;
               var204[3] = var54;
               var204[2] = var53;
               var204[1] = var200;
               var204[0] = var186;
               Object[] var126 = var204;
               FilledRectangleRenderer.cReturningVoid(var126);
            }

            float var60 = var51 - var34 / 2.0F;
            float var61 = var55 + var38;
            Object[] var10009 = new Object[]{null, null, null, null, var53, k, var59, 106444071603622L};
            var10009[3] = var34;
            var10009[2] = var34;
            var10009[1] = var61;
            var10009[0] = var60;
            Object[] var127 = var10009;
            GameRenderUtil.v(var127);
            float var62 = var54 + var37;
            float var63 = var54 + var49 - var37;
            float var64 = var61 + var34 + var35;
            float var202 = var64 + var36;
            Object[] var10008 = new Object[]{null, null, null, null, null, var58, 90315074383642L};
            var10008[4] = var202;
            var10008[3] = var63;
            var10008[2] = var64;
            var10008[1] = var62;
            var10008[0] = var53;
            Object[] var128 = var10008;
            ShapeRenderer.lReturningVoid(var128);
            float var65 = var51 - var46 / 2.0F;
            float var66 = var64 + var36 + var35;
            var10008 = new Object[]{null, null, null, null, var59, 10141036836483L};
            var10008[3] = var66;
            var10008[2] = var65;
            var10008[1] = var44;
            var10008[0] = var53;
            Object[] var130 = var10008;
            MsdfFont var129 = var31;
            var129.v(var130);
            int var181 = var28;
            if (var181 == 0) {
               break;
            }
         }
      }
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 59052423444182L ^ var2;
      byte var10000 = 0;
      short var10001 = 20905;
      long var10002 = 4163094228433145210L ^ var2;
      var10001 = 255;
      Color var6 = var1;
      int var8 = (int)(var6.getAlpha() * var4);
      int var10 = Math.min(255, var8);
      int var5 = Math.max(0, var10);
      Color var11 = var1;
      int var16 = var11.getRed();
      Color var12 = var1;
      int var10003 = var12.getGreen();
      Color var13 = var1;
      return new Color(var16, var10003, var13.getBlue(), var5);
   }

   private ArrayList aReturningArrayList(Object[] var1) {
      EnderPearlEntity var2 = (EnderPearlEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 59052423444182L ^ var3;
      long var5 = var3 ^ 127197099469589L;
      ArrayList var8 = new ArrayList();
      MinecraftClient var11 = b;
      MinecraftClient var12 = b;
      Item var13 = Items.ENDER_PEARL;
      PearlTrajectoryProjectile var9 = new PearlTrajectoryProjectile(var11.world, var12.player, var13.getDefaultStack(), var5);
      int var10000 = Event.bReturningInt();
      EnderPearlEntity var14 = var2;
      double var10002 = var14.getX();
      EnderPearlEntity var15 = var2;
      double var10003 = var15.getY();
      EnderPearlEntity var16 = var2;
      double var22 = var16.getZ();
      double var20 = var10003;
      double var18 = var10002;
      PearlTrajectoryProjectile var17 = var9;
      var17.setPosition(var18, var20, var22);
      int var7 = var10000;
      EnderPearlEntity var24 = var2;
      Vec3d var26 = var24.getVelocity();
      PearlTrajectoryProjectile var25 = var9;
      var25.setVelocity(var26);
      int var45;
      while (true) {
         boolean var48 = var9.a;
         if (!var48) {
            var10000 = var10++;
            int var50 = var7;
            int var49 = var10000;
            var45 = var49;
            int var42 = var49;
            if (var50 != 0) {
               break;
            }

            int var52 = var7;
            int var51 = var42;
            var45 = var51;
            int var43 = var51;
            if (var52 != 0) {
               break;
            }

            int var53 = var43;
            int var44 = var53;
            short var10001 = 17866;
            long var63 = 1429979399364827495L ^ var3;
            short var55 = 400;
            int var54 = var44;
            if (var54 < var55) {
               PearlTrajectoryProjectile var29 = var9;
               var10003 = var29.getX();
               PearlTrajectoryProjectile var30 = var9;
               double var10004 = var30.getY();
               PearlTrajectoryProjectile var31 = var9;
               Vec3d var33 = new Vec3d(var10003, var10004, var31.getZ());
               ArrayList var32 = var8;
               var32.add(var33);
               PearlTrajectoryProjectile var34 = var9;
               var34.tick();
               int var56 = var7;
               if (var56 == 0) {
                  continue;
               }
            }
         }

         var45 = (((var9.a) ? 1 : 0));
         break;
      }

      int var58 = var7;
      int var57 = var45;
      int var46 = var57;
      if (var58 == 0) {
         int var59 = var46;
         if (var59 != 0) {
            PearlTrajectoryProjectile var37 = var9;
            var10003 = var37.getX();
            PearlTrajectoryProjectile var38 = var9;
            double var66 = var38.getY();
            PearlTrajectoryProjectile var39 = var9;
            Vec3d var41 = new Vec3d(var10003, var66, var39.getZ());
            ArrayList var40 = var8;
            boolean var60 = var40.add(var41);
         }
      }

      return var8;
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 59052423444182L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var5 = b;
      int var14 = var4;
      Screen var13 = var5.currentScreen;
      Screen var9 = var13;
      Screen var8 = var13;
      if (var14 != 0) {
         Screen var15 = var8;
         if (var15 == null) {
            return true;
         }

         MinecraftClient var7 = b;
         Screen var16 = var7.currentScreen;
         var9 = var16;
      }

      byte var21 = ((byte)((var9 instanceof ChatScreen) ? 1 : 0));
      int var18 = var4;
      byte var17 = var21;
      byte var11 = var17;
      byte var10 = var17;
      if (var18 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var11);
      }

      byte var19 = var10;
      return var19 != 0;
   }

   private boolean lambda$new$4(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.e;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.g;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      byte var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$3(Boolean var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$2(Float var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$1(Color var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 != 0) {
         byte var17 = var10;
         if (var17 == 0) {
            return false;
         }

         BooleanSetting var8 = this.a;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      byte var13 = var19;
      byte var12 = var19;
      if (var20 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 == 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(138548913841937L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[3];
      String var22 = ";\u0019\r\\ç·kªÄPÖ,dÊ\u0006jIj\u008ch5Ë°®\u0010@H\u0082Å¸á³Ûì\u0099UÖ)$B¢0\u009a\u001d-\u001føäþßÔ\u001bQA»5\u0090\u0019«<¨¨päR@\u0006Ý×A\u0097%\u001c\u0093Þ \u0090ûVô\u0019¸¡\fÔ\u0089±\u0082m¨";
      int var24 = ";\u0019\r\\ç·kªÄPÖ,dÊ\u0006jIj\u008ch5Ë°®\u0010@H\u0082Å¸á³Ûì\u0099UÖ)$B¢0\u009a\u001d-\u001føäþßÔ\u001bQA»5\u0090\u0019«<¨¨päR@\u0006Ý×A\u0097%\u001c\u0093Þ \u0090ûVô\u0019¸¡\fÔ\u0089±\u0082m¨"
         .length();
      char var21 = 24;
      int var20 = -1;

      while (true) {
         byte[] var26 = var18.doFinal(var22.substring(++var20, var20 + var21).getBytes("ISO-8859-1"));
         String var42 = b(var26).intern();
         int var10001 = -1;
         var25[var23++] = var42;
         if ((var20 += var21) >= var24) {
            r = var25;
            s = new String[3];
            w = new HashMap(13);
            Cipher var7;
            var10000 = var7 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var8 = 1; var8 < 8; var8++) {
               var10003[var8] = (byte)(138548913841937L << var8 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var13 = new long[5];
            String var11 = "(ç\nu±¤_ð<°N\u0091Ä÷ü¡\u009fðú_óéÇP";
            int var12 = "(ç\nu±¤_ð<°N\u0091Ä÷ü¡\u009fðú_óéÇP".length();
            label42:
            while (true) {
               var10001 = var9;
               var9 += 8;
               byte[] var14 = var11.substring(var10001, var9).getBytes("ISO-8859-1");
               long[] var34 = var13;
               var10001 = var10++;
               long var45 = (var14[0] & 255L) << 56
                  | (var14[1] & 255L) << 48
                  | (var14[2] & 255L) << 40
                  | (var14[3] & 255L) << 32
                  | (var14[4] & 255L) << 24
                  | (var14[5] & 255L) << 16
                  | (var14[6] & 255L) << 8
                  | var14[7] & 255L;
               // while (true) {
                  long var15 = var45;
                  byte[] var17 = var7.doFinal(
                     new byte[]{
                        (byte)(var15 >>> 56),
                        (byte)(var15 >>> 48),
                        (byte)(var15 >>> 40),
                        (byte)(var15 >>> 32),
                        (byte)(var15 >>> 24),
                        (byte)(var15 >>> 16),
                        (byte)(var15 >>> 8),
                        (byte)var15
                     }
                  );
                  long var53 = (var17[0] & 255L) << 56
                     | (var17[1] & 255L) << 48
                     | (var17[2] & 255L) << 40
                     | (var17[3] & 255L) << 32
                     | (var17[4] & 255L) << 24
                     | (var17[5] & 255L) << 16
                     | (var17[6] & 255L) << 8
                     | var17[7] & 255L;
                  switch (var50) {
                     case 0:
                        var34[var10001] = var53;
                        if (var9 >= var12) {
                           u = var13;
                           v = new Integer[5];
                           i = 400;
                           Cipher var2;
                           var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
                           var10002 = SecretKeyFactory.getInstance("DES");
                           var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                           for (int var3 = 1; var3 < 8; var3++) {
                              var10003[var3] = (byte)(138548913841937L << var3 * 8 >>> 56);
                           }

                           var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                           long var40 = -7950913401209575092L;
                           byte[] var6 = var2.doFinal(
                              new byte[]{
                                 (byte)145L,
                                 (byte)37288L,
                                 (byte)9545902L,
                                 (byte)2443751011L,
                                 (byte)625600258857L,
                                 (byte)160153666267394L,
                                 (byte)40999338564453033L,
                                 (byte)-7950913401209575092L
                              }
                           );
                           long var48 = (var6[0] & 255L) << 56
                              | (var6[1] & 255L) << 48
                              | (var6[2] & 255L) << 40
                              | (var6[3] & 255L) << 32
                              | (var6[4] & 255L) << 24
                              | (var6[5] & 255L) << 16
                              | (var6[6] & 255L) << 8
                              | var6[7] & 255L;
                           // long var0 = var48;
                           o = var0;
                           String var30 = "textures/item/ender_pearl.png";
                           String var29 = "minecraft";
                           j = Identifier.of(var29, var30);
                           break;
                        }
                        break;
                     default:
                        var34[var10001] = var53;
                        if (var9 < var12) {
                           continue label42;
                        }

                        var11 = "Ð\u001d\u0011Ë;(æÏq\u0095â0Q\u009a\u0083E";
                        var12 = "Ð\u001d\u0011Ë;(æÏq\u0095â0Q\u009a\u0083E".length();
                        var9 = 0;
                  }

                  int var39 = var9;
                  var9 += 8;
                  var14 = var11.substring(var39, var9).getBytes("ISO-8859-1");
                  var34 = var13;
                  var10001 = var10++;
                  var45 = (var14[0] & 255L) << 56
                     | (var14[1] & 255L) << 48
                     | (var14[2] & 255L) << 40
                     | (var14[3] & 255L) << 32
                     | (var14[4] & 255L) << 24
                     | (var14[5] & 255L) << 16
                     | (var14[6] & 255L) << 8
                     | var14[7] & 255L;
                  var50 = 0;
               }
            }
         }

         var21 = var22.charAt(var20);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            int var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8397;
      if (s[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])t.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fc", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = r[var5].getBytes("ISO-8859-1");
         s[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return s[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fc_C0276",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25813;
      if (v[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = u[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])w.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               w.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fc", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         v[var3] = var15;
      }

      return v[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fc_C0276",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = y[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = x[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 41;
            yield var15;
         }
         case 1 -> {
            byte var16 = 21;
            yield var16;
         }
         case 2 -> {
            byte var17 = 7;
            yield var17;
         }
         case 3 -> {
            byte var18 = 36;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 19;
            yield var23;
         }
         case 9 -> {
            byte var24 = 40;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 25;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 42;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 54;
            yield var31;
         }
         case 17 -> {
            byte var32 = 23;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 4;
            yield var34;
         }
         case 20 -> {
            byte var35 = 32;
            yield var35;
         }
         case 21 -> {
            byte var36 = 38;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 10;
            yield var39;
         }
         case 25 -> {
            byte var40 = 3;
            yield var40;
         }
         case 26 -> {
            byte var41 = 11;
            yield var41;
         }
         case 27 -> {
            byte var42 = 26;
            yield var42;
         }
         case 28 -> {
            byte var43 = 34;
            yield var43;
         }
         case 29 -> {
            byte var44 = 28;
            yield var44;
         }
         case 30 -> {
            byte var45 = 45;
            yield var45;
         }
         case 31 -> {
            byte var46 = 59;
            yield var46;
         }
         case 32 -> {
            byte var47 = 29;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 22;
            yield var50;
         }
         case 36 -> {
            byte var51 = 31;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 6;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 0;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 20;
            yield var61;
         }
         case 47 -> {
            byte var62 = 46;
            yield var62;
         }
         case 48 -> {
            byte var63 = 48;
            yield var63;
         }
         case 49 -> {
            byte var64 = 13;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 57;
            yield var66;
         }
         case 52 -> {
            byte var67 = 5;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 53;
            yield var70;
         }
         case 56 -> {
            byte var71 = 30;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 37;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 61;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 55;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            y[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      x[0] = "=6e!\u001a@+6`{\tW<}c}\u0005C-:tjNW\r";
      x[1] = double.class;
      y[1] = "java/lang/Double";
      x[2] = "t\"Ui;1b\"P3(&uiS5$2d.D\"o U";
      x[3] = int.class;
      y[3] = "java/lang/Integer";
      x[4] = "pn6\bPHpn!T\\Gj%!J\\RmTs\u0011\u0004\u0013";
      x[5] = "\u0007##`\u0001+\u0007#4<\r$\u001dh4\"\r1\u001a\u0019fyU{";
      x[6] = void.class;
      y[6] = "java/lang/Void";
      x[7] = "gc3_?bgc$\u00033m}($\u001d3xzYvGj?";
      x[8] = "9\u0000xA\u0011d'\bb\u000e~c!\u0000wlVb'";
      x[9] = "2\fQU'^9\u0003@\u001aFP2\bD@";
      x[10] = boolean.class;
      y[10] = "java/lang/Boolean";
      x[11] = "\u0011~2\u0019u_\u0007~7CfH\u001054Ej\\\u0001r#R!I\u0016";
      x[12] = "QN=Bi\u0017ZA,\r\n\u001aOL#f?\u0018^_?J(\u0015";
      x[13] = "K)W#kJK)@\u007fgEQb@agPV\u0013\u0010<6";
      x[14] = "=U-e\r|=U:9\u0001s'\u001e:'\u0001f ooxX";
      x[15] = "*\"$Y9B*\"3\u00055M0i3\u001b5X7\u0018gCb";
      x[16] = "H+]e\u000b\u0016H+J9\u0007\u0019R`J'\u0007\fU\u0011\u001b\u007fU";
      x[17] = "\u00054\u0017_@\u000f\u00054\u0000\u0003L\u0000\u001f\u007f\u0000\u001dL\u0015\u0018\u000eRI\u001dT";
      x[18] = "\\s7]\u0011BW|&\u0012rOBz";
      x[19] = "+\u0013*\b6\u001c6\u0006r*w\u0011.\u0000";
      x[20] = "'\u00035]@B1\u00030\u0007SU&H3\u0001_A7\u000f$\u0016\u0014V\u000b";
      x[21] = "\"5fL\u007fNW\u0015mCn\u00016\u001bfHj[B";
      x[22] = "\u001f<n\u00135\t\t<kI&\u001e\u001ewhO*\n\u000f0\u007fXa\u001d2";
      x[23] = "A\u001ab3\u001e!4:i<\u000fnU4b7\u000b4!";
      x[24] = "\"q \u0017=>4q%M.)#:&K\"=2}1\\i*\f";
      x[25] = "\u001ek\u0018}\n9kK\u0013r\u001bv\nE\u0018y\u001f,~";
      x[26] = "\u0001\u007f[1%y\npJ~Iz\u0004rH1e";
      x[27] = "c|f,}\u0011u|cvn\u0006b7`pb\u0012spwg)\u0005A";
      x[28] = "e$!tsEn+0;\u0011Fa\"";
      x[29] = long.class;
      y[29] = "java/lang/Long";
      x[30] = "nhe_\u001bBegt\u0010fWw}vS";
      x[31] = float.class;
      y[31] = "java/lang/Float";
      x[32] = "sm.\b\u0007\fem+R\u0014\u001br&(T\u0018\u000fca?CS\u0018a";
      x[33] = "ruU\"YB\u0007U^-H\rf[U&LW\u0012";
      x[34] = "nP\fy\u001a*pX\u00166g:p";
      x[35] = "v1H\u0013O\u0017h9R\\(\u0016y\"_\u0006\u000e\u0010";
      x[36] = "G2\u007f\u000bieY:eD\nq]";
      x[37] = "nEz\u0011\u0006=\u001beq\u001e\u0017rzkz\u0015\u0013(\u000e";
      x[38] = "\u0014\u001b\\G\u0005\u001e\u001f\u0014M\bb\u001c\n\u001fMCY";
      x[39] = "H;^U\u0001\u0019^;[\u000f\u0012\u000eIpX\t\u001e\u001aX7O\u001eU\bn";
      x[40] = "\u001bA4\u001bypna?\u0014h?\u000fo4\u001fle{";
      x[41] = "wyb~\u007f\u0011|vs1\u0018\txju}=\u0018";
      x[42] = "seXl:?mmB#W%uhKn`#vj";
      x[43] = "\u007fK\u0013{Y*iK\u0016!J=~\u0000\u0015'F)oG\u00020\r8O";
      x[44] = "j16o_d\u001f\u0011=`N+~\u001f6kJq\n";
      x[45] = "B-5\u001a KT-0@3\\Cf3F?HR!$Qt_Q";
      x[46] = "KW\u0003{aM>w\btp\u0002_y\u0003\u007ftX+";
      x[47] = "\u0013l\u001b*&R\u0005l\u001ep5E\u0012'\u001dv9Q\u0003`\narA\u001b`\bj(\f'{\bw(K\u0010l";
      x[48] = "q\f\u0002Xaag\f\u0007\u0002rvpG\u0004\u0004~ba\u0000\u0013\u00135ro";
      x[49] = "3G\u0016\u001a^YFg\u001d\u0015O\u0016'i\u0016\u001eKLS";
      x[50] = "x23\bE)\r\u00128\u0007Tfl\u001c3\fP<\u0018";
      x[51] = "N3fc+jL-/\u0000 qS(yy'";
      x[52] = "\u0007@)uX?r`\"zIp\u0013n)qM*g";
      x[53] = "6}\u001beVz=r\n*+b.u\u0003c";
      x[54] = "4A\u000b)!NAa\u0000&0\u0001 o\u000b-4[T";
      x[55] = "^a\\J,\u000eHaY\u0010?\u0019_*Z\u00163\rNmM\u0001x\u001dB";
      x[56] = "s3Aj\u0017E\u0006\u0013Je\u0006\ng\u001dAn\u0002P\u0013";
      x[57] = "\u0016\r!\u0011Cvc-*\u001eR9\u0002#!\u0015Vcv";
      x[58] = "=e>kG|HE5dV3)K>oRi]";
      x[59] = "H'\nz\u0013b=\u0007\u0001u\u0002-\\\t\n~\u0006w(";
      x[60] = "i{\u00056IIbt\u0014y!Il{\u0007";
      x[61] = "^\u001bj]I^H\u001bo\u0007ZI_Pl\u0001V]N\u0017{\u0016\u001dJ\\";
      x[62] = "<_\u0001<P\u000eI\u007f\n3AA(q\u00018E\u001b\\";
      x[63] = ":5*~_J,5/$L];~,\"@I*9;5\u000bYg";
      x[64] = "\\!S\u001eG!)\u0001X\u0011VnH\u000fS\u001aR4<";
      x[65] = "ts=E6F\u0001S6J'\t`]=A#S\u0014";
      x[66] = "\u0015,\u000fq0a\u0015,\u0018-<n\u000fg\u00183<{\b\u0016Ifk8";
      x[67] = "^9c Ls^9t|@|Drtb@iC\u0003#=\u0016";
      x[68] = "vv\u0001`$AddJzFKtvs'(J{9\r`-E|\u0006Is\"H\"x\u000ev-O\u001d<\u001dy \u0011c{\u0018v'.";
      x[69] = "x\u0016|\u00013\u007fm\u0018}B\u0002(y\bVXz'}t%Rf!+\nbWi&\u0014";
      x[70] = "eKj\n\u0013+bVjEr#\u0019\u000e;\u001c\u001b-\u007fQx\u000b\u001f$\u0019Kv\u001b\u0003.}Lk\u001bLO";
      x[71] = "wOn\u000bH\u00124ExAD,+KxPR@\u0019\u0018<\u000e\b\u0011N\u001f<MZJ)\u001bh\nHBN\u001f<MZJ)\u001bh\nHBN\u001fmZ\u000eQp\\gLD]N";
      x[72] = "\bH+G\u0000b\u001a\u001ba\u0003:peOa\u001fS{\u0003\u0010\"\bWre\u001bn\u0003\u0005#\u001e\t=IA\u0019";
      x[73] = "\u001ff\u0013S\u0005BGaBV;C\u0006q\u0007^]T'j\u0018^~I\u001fo\u001cH;K\u0011;\u0000\u000f\u0004\u0016\u00121\u001a3";
      x[74] = "`I# 4\rnU-}\u0004\u0001\u001f^:{y\u0013\"\u0012n!}";
      x[75] = "TXcrl\u0006\u001f\u0004s\u007f\u000fY\u0004\u0005u\u007fX\u000eZU,\u00136^\u001b\u0015r,7\f\u001cV.";
      x[76] = "\u0000/-* }\u0012=f0Bw\n9_3!sS!a6/s\u001b_;4#*\u0015a>:#bk;<6zlU>262\u0012";
      x[77] = "k@\u00115\u0001G>^\u0013r9AT\u000b\u001bmPJ2TXzTCT^Hi\u0004\u0019lKFhG(";
      x[78] = " %\tg\tzbaN`hc 1Kd\u0014e&\\Vs\u0016>8'[n\u0005r\\";
      x[79] = "RRyo\u0018a\u0000W~~bwV\r+Z\u000bwL\u0006Dg\b#LW{:\u000b)Vk";
      x[80] = "-\u0003x\u007fV&)B~\u007f06M\u0000qeY=+_2r]4MYz:M94];<M_";
      x[81] = "\u0015xQ' M@fS`\u0018N*3[\u007fq@Ll\u0018huI*5Vae\u001cEk\u0003`c\"";
      x[82] = "27t\u001e\u001e_?*gRzB89v\"DN8+mN\u0018\u001e5t\n";
      x[83] = "?Kj\u0017aS;\u001f-\u0005i4h\u0014m\u001dnH\u0006J/\u0005hRaN{BzZ\u0006J&\u001fnV`\u0015e\bj_\u0006J/\u0005hRaN{BzZ\u0006";
      x[84] = "\u001f>pN\u0010j\u0018'\u0000\u0011\u0003gF0l#W+\u0019f1t\u0004t\u0017*`\u0006TvH2\u0000H\u0002a\\7yO\f%AW";
      x[85] = "\u000b{\u000b\u0002xQU%]X'o[A\u000f\f%\u0006P'PO2\u0002YAR^#WL\u007fWP#\u001f2";
      x[86] = "QOqs\u001eYDAp0/\u000ePQH#Ca\u0007Cv(\u0010\u001f@Fy//";
      x[87] = "8\u0003~[vC}\u0003k\t\f^hAw\u0005`l?\u0006,X5;<\u0007{S2\u0003<G}\u001c\f";
      x[88] = "j[w\u001fah:Y(\u0007\u0001taY\"\u000eV#;\t|b8 l\u0005xZ8`jJ";
      x[89] = "OQ[Ej\u0018\u001fS\u0004]\n\u0004DS\u000eT]S\u001e\u0003S83PI\u000fT\u00003\u0010O@";
      x[90] = "*cut=<s3d._g|uz,3U.9'w_9hhf,1}`8cK";
      x[91] = "'y\u000e\"d\u0006 `~}w\u000b~w\u0012O'H!+~$v\rdp\u0007#xIy\u0010";
      x[92] = "#?i%\u0019a=w(z'`-)-s\\\u001e84htFfzp/s'";
      x[93] = "EE\u000fl7c\u0000E\u001a>M~\u0015\u0007\u00062!LB@]lr\u001bAA\nds#A\u0001\f+M";
      x[94] = "v$eu\bH)8|ozB};lm\u001cqt#\u0005p\u0003\u0000z&}2GG}G:0\u0003E.(de\u0002C\u0010";
      x[95] = "8@\u001bt\u0019\"kA\u0005 x0hDe#\u0016;c\u0007\u001bd\u00134d8[s\u0015=bT\u0007#\u0018b\u0005";
      x[96] = "lyB;9b9g@|\u0001dS;\u001f8xa\"r\u0002ya\rcmE}m|*p\u0004d\u0001";
      x[97] = ";~\u0014!r$p\"\u0004,\u0011{k#\u0002,F,4~Y@ li?\u001b>.q`+";
      x[98] = ";P,{k1~P9)\u0011,k\u0012%%}\u001e<U~{!I?T)s/q?\u0014/<\u0011";
      x[99] = "}V^Y<-6\u0016\u0003\u001cvH:\u0001\u0005\u001bi\u000f*h\u0005\u0005ep:V\u0000\u000be8DQ_Y;p!\u001a\u001f\u0004~:D";
      x[100] = "Fi|hd3\u001a;/d=_\u0012Y.486\u001d?qw/2\u0014Y+i%%\u001f ,ga8\u007f";
      x[101] = "n#=\u000f\u007f\u00000}kU ><\u00199\u0001\"W5\u007ffB5S<\u0019dS$\u0006)'a]$NW";
      x[102] = "&Av\u0006{I3OwEJ\u001e'_ZA'\u001c,#/U.\u0017u]hP!\u0010J";
      x[103] = "7at,vVraa~\fKg#}r`y3o\"$<.`0,hl\\02sp\f";
      x[104] = "sD\b/1F0C\u0019,\u000f\u0016J\u0003\b&iC4D\r)n|";
      x[105] = "\u0013=5ry\"\u001c5iv\u0013ame:xz}\u000b:yo~tm`gei\u007f\u0014gi!t\u001f";
      x[106] = "\u001c\u001ds\u0019\u001f#\u0002U2F!=\u0000\"/Z]-{Pv[\\b\u0014\u000e#ZZ\\";
      x[107] = "\u0016{J6_\u000bD~M'%\u0007\u001c&\n0b\u0017u!\u001dmXEJ|\u001egBy\u0016{J6_\u000bD~M'%";
      x[108] = "\u0010a\u001d\u001cT]C`\u0003H5[Lk\u000eq\u000fNI\u007f\\\u000fHKFxc";
      x[109] = "@.RV\u0003\u0017\u001cwSZ;MFwIPRA\u007fyI@V'\u001e,T@\u0005H@yUF;";
      x[110] = "O\u001e/Lcz\f\u0019>O]+vY/E;\u007f\b\u001e*J<@";
      x[111] = "=`U\u0000@p:y%_S}dnIm\u0004:?0\u0015:\u0007;h8\u001b\u0002\u0007{nw%";
      x[112] = ";G\u0016{ItnE\rq5p^\u001dUm\\y8B\u0016zXp^\u0018\bpO{'\u001f\u00064R\u001b";
      x[113] = "^\ryz\\RY\u0014\t%O_\u0007\u0003e\u0017\u001f\u0013^X\ty\u0018OVZ1yXI\u0019d0zN\u0012Y\\0:H]g]3,\u0013\u001d_]s*\\#[\bs:BZ\\\u00067'\"";
      x[114] = "kZU\u001b(+4FL\u0001Z2aU5\\06o^Y\u0000`;09\n^#&3VT\u000b\" \r";
      x[115] = "?\u000b?QU@j\t$[)KZQ|G@M<\u000e?PDDZT!ZSO#S/\u001eN/";
      x[116] = "\n+O!\u0004&\u0001r\u001a:`sh,\u0019*\u0002}\u0004pI']\u001a";
      x[117] = "g_wR\u0019g7](Jy{l]\"C.,6\r~/@/a\u0001x\u0017@ogN";
      x[118] = "\u0014\u001cs`\u0003kGA*c\u0018WVO\"n\bWIG*2\u001biLI*ze3NEst[6@E;\n\u00014L\u001c54\u0004:LTK3]oGBw`\u00006DYK";
      x[119] = "R\u0001[\u0016RyLI\u001aIliX\u000fb\u0013\u0006kW\u0014\u000eOVf\bs\\G\u0001dR\u001f\u0000\u0017\f;5";
      x[120] = "nyy:PR%%i73\r>$o7dZ`s7[YZ?/d#\u0002\u0005f$";
      x[121] = "['#\u000en}\u000e9!IV{dl)V?p\u00023jA;ydh`O;s\u0019;aQo\u0012";
      x[122] = "hB6}-)o[F\">$1L*\u0010icj\u0012yGjb=\u001ax\u007fj\";UF";
      x[123] = "g3kw^\u000bp>\u007fm`\bl\"je7V3t2\t[\fbpl7\u0002\\s*";
      x[124] = "4X\u000fuFf9E\u001c9\"}:]7$RaS\u0019M0_#<G\u00181Y\u001d";
      x[125] = "\fH7sd\u0013\u001eZ|i\u0006\u0019\u0006^E4h\u0018\u0001\u0007;sm\u0017\u00068\u007f`b\u001aXF8em\u001dg\u0002+j`C\u0019E.eg|";
      x[126] = "\u0004W\u0004U-h\u0012@XLTp\u0014JD@\u0013`}\u0014WI21\u0003SRF5\u000e\u0004W\u0004U-h\u0012@XLT";
      x[127] = "%`_+\u001a\u0017\"y/t\t\u001a|nCF^]'3\u0016\u0011]\\p8\u0011)]\u001cvw/";
      x[128] = "6'C\n|\u001dv(\u001e\u000e\u001b\u001bL!\u0014Sr\u0015*~WDv\u001cLtGW&FtaIVew";
      x[129] = "<\u0017E_\u0016\u001b.\u0005\u000eEt\u0011>\u00177F\u0017\u0015o\u0019\tC\u0019\u0015'gSA\u0015L)YVO\u0015\u0004W\u0003TCL\ni\u0006ZC\u0004t";
      x[130] = "u\tIT\u0010z`\u0007H\u0017!-t\u0017`\r\\/\u0019QD\rG}g\u0016A\u0002@B";
      x[131] = "^6\u001e[\u0015tE9@\r--Y*Z\u000eQ+_GG\u0019SpA<J\u0004@<%";
      x[132] = "\f<\u007f\fE5I<j^?(\\~vRS\u001a\f<,\u0005?w_fp\nA0Ziw5";
      x[133] = "#0Uwy%od\u000fs\u0000qS`]miz5?\u001ezmsS`V7?\"m>\bae}S";
      x[134] = "1g\n`\u0010M//K?.J+ir5gX-xU'.\f<xQ<BPlu\u000e[\u0010X;wT7L\b6(3eD_4r_9\u0014Rk\u0015";
      x[135] = "\u0014u,+m\u0000\u001b}p/\u0007Tj-#!n_\fr`6jVj~}wz]\u0018.\u007f(b=";
      x[136] = "\u0016R+ej\u000b\u001a\u001fq}\u0004\u001fxZ km\u0014\u001e\u0005c|i\u001dx\r 6m\u0018\u0005\u0001mluv";
      x[137] = ".6ZEe7}7D\u0011\u0004#\u007f\"$\u0016n'q)HJ>*.N\u001b\u0014}7-!EA|1\u0013";
      x[138] = "@)zoUA^a;0k]J*\u00189\u0017>A8#-\u0019N\u001e$:7k";
      x[139] = "qqV\u0002uz//\u0000X*D6KR\f(-*-\rO?)#KWQ5>(2P_q#H";
      x[140] = "B\u0003`P\u0013A\tC=\u0015Y$\u0015Y8\u0006Wz\u0012Y\"\u0002+@\u0018\\g\u0011\u0015E\u0016\\/o";
      x[141] = "\u0003U\f6C%\u001d\u001dMi}1\u0000J\\w}f\b]Om\u0004a\u0006\u0019R\r";
      x[142] = "4h[qon4o\bnm\u000efV\u000f2sgo0PqdcfV\nontm/\ra*i\r";
      x[143] = "3/AMPfc-\u001eU0q4<\u0010W\\C`xK\t0-c,A\u000e\b-#*\u000e0\t.5qN\b\tn3>p\t\nxh~H\tJ~'@\u001a_\u0001i92J]^qY";
      x[144] = "\u001eO^()\u000e\u0000\u0007\u001fw\u0017\t\u0004Ag-}\u001c\u001bZ\u000bq-\u0011D=Yyz\u0013\u001eQ\u0005)wLy\u0003\r~u\u0016\u0015_]s*q";
      x[145] = ";\u0019{P\b)5\u0004rDu2g\u001cxF\u0019\u00003P!\u0018OWq\u0011&\u001dMoj\u001exKu";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = x[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(y[var4]);
            x[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = y[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            x[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  x[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(641531880067145L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = x[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = y[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  x[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(641531880067145L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        x[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(641531880067145L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 71;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 205;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 110;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 194;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 105;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 122;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 71;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 205;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 110;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fc_C0276",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(PearlTrajectory var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fc_C0276;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fc_C0276", "lambda$new$1", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PearlTrajectory)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(PearlTrajectory var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fc_C0276;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fc_C0276", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PearlTrajectory)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(PearlTrajectory var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fc_C0276;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fc_C0276", "lambda$new$3", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((PearlTrajectory)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(PearlTrajectory var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fc_C0276;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fc_C0276", "lambda$new$4", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((PearlTrajectory)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(PearlTrajectory var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fc_C0276;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fc_C0276", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((PearlTrajectory)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
