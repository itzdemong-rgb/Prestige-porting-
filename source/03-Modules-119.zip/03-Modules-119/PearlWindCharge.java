package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BundleS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.Hand;

public class PearlWindCharge extends Module implements RotationSource {
   private BooleanSetting d;
   private BooleanSetting a;
   private boolean i;
   private boolean c;
   private static final long k = 107358278232377L;
   private static final long l;
   private static final Object[] m = new Object[76];
   private static final String[] n = new String[76];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.c = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 86502240407608L;
      long var6 = var2 ^ 106154985175646L;
      long var8 = var2 ^ 65762800970131L;
      long var10 = var2 ^ 117380820149222L;
      long var12 = var2 ^ 70631327292860L;
      long var14 = var2 ^ 138007752420630L;
      long var16 = var2 ^ 16882931127021L;
      int var18 = Event.bReturningInt();
      int var88 = var18;
      byte var87 = ((byte)((this.i) ? 1 : 0));
      byte var79 = var87;
      byte var69 = var87;
      if (var88 == 0) {
         byte var89 = var69;
         if (var89 == 0) {
            boolean var76;
            BooleanSetting var22 = this.d;
            Boolean var23 = (Boolean)var22.aReturningObject();
            boolean var10000 = var23;
            int var91 = var18;
            boolean var90 = var10000;
            var76 = var90;
            boolean var70 = var90;
            label64:
            if (var91 == 0) {
               boolean var92 = var70;
               boolean var71 = var92;
               boolean var93 = var71;
               if (var93) {
                  Object[] var26 = new Object[]{Items.ENDER_PEARL, var8};
                  var10000 = InventoryUtil.lReturningBoolean(var26);
                  int var95 = var18;
                  boolean var94 = var10000;
                  var76 = var94;
                  boolean var72 = var94;
                  if (var95 != 0) {
                     break label64;
                  }

                  boolean var96 = var72;
                  boolean var73 = var96;
                  boolean var97 = var73;
                  if (!var97) {
                     Object[] var29 = new Object[]{Items.ENDER_PEARL, var10};
                     Integer var30 = InventoryUtil.aReturningBoxedInteger(var29);
                     int var119 = var30;
                     int var99 = var18;
                     int var98 = var119;
                     int var75 = var98;
                     int var74 = var98;
                     if (var99 == 0) {
                        // int var100 = var74;
                        if (var100 == var101) {
                           Object[] var33 = new Object[]{var4};
                           PearlWindCharge var32 = this;
                           var32.aReturningVoid(var33);
                           return null;
                        }

                        var75 = var119;
                     }

                     Object[] var121 = new Object[]{null, var14};
                     var121[0] = var75;
                     Object[] var35 = var121;
                     InventoryUtil.aReturningVoid(var35);
                     return null;
                  }
               }

               Object[] var36 = new Object[]{Items.ENDER_PEARL, var8};
               var76 = InventoryUtil.lReturningBoolean(var36);
            }

            int var103 = var18;
            boolean var102 = var76;
            boolean var77 = var102;
            if (var103 == 0) {
               boolean var104 = var77;
               if (!var104) {
                  return null;
               }

               Object[] var38 = new Object[]{Hand.MAIN_HAND, var16};
               boolean var105 = ItemUseUtil.cReturningBoolean(var38);
            }

            this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
            return null;
         }

         var79 = ((byte)((this.c) ? 1 : 0));
      }

      int var107 = var18;
      byte var106 = var79;
      int var81 = var106;
      byte var80 = var106;
      if (var107 == 0) {
         byte var108 = var80;
         if (var108 == 0) {
            return null;
         }

         Object[] var42 = new Object[]{var6};
         PearlWindCharge var41 = this;
         int var109 = var41.dReturningInt(var42);
         var81 = var109;
      }

      int var19 = var81;
      // int var110 = var19;
      if (var110 != var111) {
         MinecraftClient var44 = b;
         ClientPlayerEntity var45 = var44.player;
         float var20 = var45.getPitch();
         MinecraftClient var46 = b;
         float var48 = 90.0F;
         ClientPlayerEntity var47 = var46.player;
         var47.setPitch(var48);
         Object[] var10003 = new Object[]{null, var14};
         var10003[0] = var19;
         Object[] var49 = var10003;
         InventoryUtil.aReturningVoid(var49);
         Object[] var50 = new Object[]{Hand.MAIN_HAND, var16};
         ItemUseUtil.cReturningBoolean(var50);
         int var113 = var18;
         PearlWindCharge var112 = this;
         PearlWindCharge var86 = var112;
         PearlWindCharge var82 = var112;
         if (var113 == 0) {
            ClientPlayerEntity var85;
            label73: {
               BooleanSetting var51 = var82.a;
               Boolean var52 = (Boolean)var51.aReturningObject();
               boolean var114 = var52;
               if (var114) {
                  MinecraftClient var54 = b;
                  int var116 = var18;
                  ClientPlayerEntity var115 = var54.player;
                  var85 = var115;
                  ClientPlayerEntity var83 = var115;
                  if (var116 != 0) {
                     break label73;
                  }

                  ClientPlayerEntity var117 = var83;
                  ClientPlayerEntity var84 = var117;
                  ClientPlayerEntity var56 = var84;
                  boolean var118 = var56.isOnGround();
                  if (var118) {
                     Object[] var58 = new Object[]{var12};
                     KeyBindingUtil.aReturningVoid(var58);
                  }
               }

               MinecraftClient var60 = b;
               var85 = var60.player;
            }

            float var62 = var20;
            ClientPlayerEntity var61 = var85;
            var61.setPitch(var62);
            var86 = this;
         }

         Object[] var64 = new Object[]{var4};
         PearlWindCharge var63 = var86;
         var63.aReturningVoid(var64);
         MinecraftClient var65 = b;
         ClientPlayerEntity var66 = var65.player;
         return new Rotation(var66.getYaw(), 90.0F);
      } else {
         Object[] var68 = new Object[]{var4};
         PearlWindCharge var67 = this;
         var67.aReturningVoid(var68);
         return null;
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var4 = Event.cReturningInt();
      Object[] var9 = new Object[0];
      PacketReceiveEvent var8 = var1;
      Packet var10000 = var8.aReturningVoid(var9);
      int var25 = var4;
      Packet var24 = var10000;
      Packet var21 = var24;
      Packet var20 = var24;
      if (var25 != 0) {
         boolean var26 = var20 instanceof PlayerPositionLookS2CPacket;
         if (var26) {
            this.c = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }

         Object[] var13 = new Object[0];
         PacketReceiveEvent var12 = var1;
         var21 = var12.aReturningVoid(var13);
      }

      Packet var6 = var21;
      int var28 = var4;
      Packet var27 = var6;
      Packet var23 = var27;
      Packet var22 = var27;
      if (var28 != 0) {
         boolean var29 = var22 instanceof BundleS2CPacket;
         if (!var29) {
            return;
         }

         Packet var30 = var6;
         var23 = var30;
      }

      BundleS2CPacket var5 = (BundleS2CPacket)var23;
      BundleS2CPacket var16 = var5;
      Iterable var17 = var16.getPackets();
      Iterator var36 = var17.iterator();

      int var35;
      do {
         Iterator var18 = var36;
         boolean var31 = var18.hasNext();
         if (!var31) {
            break;
         }

         label35: {
            Iterator var19 = var36;
            Packet var7 = (Packet)var19.next();
            int var32 = var4;
            if (var32 != 0) {
               boolean var33 = var7 instanceof PlayerPositionLookS2CPacket;
               if (!var33) {
                  break label35;
               }

               this.c = dev.prestige.recovery.SourceSupport.asBoolean(1);
            }

            int var34 = var4;
            if (var34 != 0) {
               break;
            }
         }

         var35 = var4;
      } while (var35 != 0);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 107358278232377L ^ var2;
      long var4 = var2 ^ 123227584898373L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var17;
      while (true) {
         int var19 = (int)l;
         int var18 = var7;
         if (var18 <= var19) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var28 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var28;
            Object[] var12 = new Object[]{var10.getStack(var11), var4};
            byte var29 = ((byte)((aReturningBoolean(var12)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var29;
            var17 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               break;
            }

            int var23 = var6;
            byte var22 = var13;
            int var16 = var22;
            byte var14 = var22;
            if (var23 == 0) {
               return var16;
            }

            byte var24 = var14;
            byte var15 = var24;
            byte var25 = var15;
            if (var25 != 0) {
               var16 = var7;
               return var16;
            }

            var7++;
            int var26 = var6;
            if (var26 != 0) {
               continue;
            }
         }

         var17 = -1;
         break;
      }

      return var17;
   }

   public static boolean aReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 107358278232377L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(73143992926465L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = 337584937211049680L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)4L, (byte)1199L, (byte)307031L, (byte)78600118L, (byte)20121630263L, (byte)5151137347580L, (byte)1318691160980662L, (byte)337584937211049680L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 26;
            yield var15;
         }
         case 1 -> {
            byte var16 = 24;
            yield var16;
         }
         case 2 -> {
            byte var17 = 36;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 5;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 47;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 12;
            yield var25;
         }
         case 11 -> {
            byte var26 = 22;
            yield var26;
         }
         case 12 -> {
            byte var27 = 62;
            yield var27;
         }
         case 13 -> {
            byte var28 = 59;
            yield var28;
         }
         case 14 -> {
            byte var29 = 54;
            yield var29;
         }
         case 15 -> {
            byte var30 = 18;
            yield var30;
         }
         case 16 -> {
            byte var31 = 16;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 9;
            yield var33;
         }
         case 19 -> {
            byte var34 = 63;
            yield var34;
         }
         case 20 -> {
            byte var35 = 35;
            yield var35;
         }
         case 21 -> {
            byte var36 = 15;
            yield var36;
         }
         case 22 -> {
            byte var37 = 8;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 45;
            yield var39;
         }
         case 25 -> {
            byte var40 = 43;
            yield var40;
         }
         case 26 -> {
            byte var41 = 49;
            yield var41;
         }
         case 27 -> {
            byte var42 = 19;
            yield var42;
         }
         case 28 -> {
            byte var43 = 58;
            yield var43;
         }
         case 29 -> {
            byte var44 = 14;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 52;
            yield var46;
         }
         case 32 -> {
            byte var47 = 34;
            yield var47;
         }
         case 33 -> {
            byte var48 = 44;
            yield var48;
         }
         case 34 -> {
            byte var49 = 53;
            yield var49;
         }
         case 35 -> {
            byte var50 = 41;
            yield var50;
         }
         case 36 -> {
            byte var51 = 6;
            yield var51;
         }
         case 37 -> {
            byte var52 = 13;
            yield var52;
         }
         case 38 -> {
            byte var53 = 48;
            yield var53;
         }
         case 39 -> {
            byte var54 = 42;
            yield var54;
         }
         case 40 -> {
            byte var55 = 1;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 33;
            yield var58;
         }
         case 44 -> {
            byte var59 = 40;
            yield var59;
         }
         case 45 -> {
            byte var60 = 7;
            yield var60;
         }
         case 46 -> {
            byte var61 = 37;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 57;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 11;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 39;
            yield var68;
         }
         case 54 -> {
            byte var69 = 27;
            yield var69;
         }
         case 55 -> {
            byte var70 = 55;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 50;
            yield var72;
         }
         case 58 -> {
            byte var73 = 20;
            yield var73;
         }
         case 59 -> {
            byte var74 = 30;
            yield var74;
         }
         case 60 -> {
            byte var75 = 3;
            yield var75;
         }
         case 61 -> {
            byte var76 = 51;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 25;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "\r\u000b{r`\t\u001b\u000b~(s\u001e\f@}.\u007f\n\u001d\u0007j94\u001f\r";
      m[1] = "n8bIqxe7s\u0006\u0012up:|m'wa)`A0z";
      m[2] = "R-@\u001d-,Y\"QRJ4]>W\u001eo%";
      m[3] = "w\u007fwbb2iwm-\u00053xl`w#5";
      m[4] = "z%@K9~l%E\u0011*i{nF\u0017&}j)Q\u0000mo[";
      m[5] = int.class;
      n[5] = "java/lang/Integer";
      m[6] = "2\n\"\u000e#N2\n5R/A(A5L/T/0n\u0010z\u0015";
      m[7] = ":1\fFe\u000b1>\u001d\t\u0004\u0005:5\u0019S";
      m[8] = "uCpnH\u0017cCu4[\u0000t\bv2W\u0014eOa%\u001c\u0005u";
      m[9] = "Ywp%)\u0016,W{*8YMYp!<\u00039";
      m[10] = "'GSv||'GD*ps=\fD4pf:}\u0015m(#";
      m[11] = boolean.class;
      n[11] = "java/lang/Boolean";
      m[12] = "j:P\u0016%_|:UL6HkqVJ:\\z6A]qKw";
      m[13] = "f\u0004E\u0015w\u0012\u0013$N\u001af]r*E\u0011b\u0007\u0006";
      m[14] = void.class;
      n[14] = "java/lang/Void";
      m[15] = "naa{3Cxad! To*g',@~mp0gPfmr;=\u001dZvr&=Zma";
      m[16] = "D\u0005ToZ;Z\rN '+Z";
      m[17] = "qN\u0005\u001f#\u000bgN\u0000E0\u001cp\u0005\u0003C<\baB\u0014Tw\u0018z";
      m[18] = "t9I^N\u0015\u0001\u0019BQ_Z`\u0017IZ[\u0000\u0014";
      m[19] = "\u000f\u000e\u001f|JS\u0004\u0001\u000e3-Q\u0011\n\u000ex\u0016";
      m[20] = "l1IT\u0001P\u0019\u0011B[\u0010\u001fx\u001fIP\u0014E\f";
      m[21] = "\u001bC80\u000e8nc3?\u001fw\u000fm84\u001b-{";
      m[22] = "X=~\u001a\nDX=iF\u0006KBviX\u0006^E\u0007=\u0000Q";
      m[23] = float.class;
      n[23] = "java/lang/Float";
      m[24] = "l~\u00057:Ggq\u0014xVDis\u00167z";
      m[25] = "M\u0007O\u000bFS[\u0007JQUDLLIWYP]\u000b^@\u0012Gx";
      m[26] = "\u0017U@\u0007.rbuK\b?=\u0003{@\u0003;gw";
      m[27] = "( o\u001c:-> jF):)ki@%.8,~Wn> ";
      m[28] = "iVg{Kq\u001cvltZ>}xg\u007f^d\t";
      m[29] = "\u0004vP\te_\u0012vUSvH\u0005=VUz\\\u0014zAB1K&";
      m[30] = "\u0019\f+3>J\u0019\f<o2E\u0003G<q2P\u00046l,c";
      m[31] = "eOglx=eOp0t2\u007f\u0004p.t'xu\"p#l";
      m[32] = "u\u001ajH;\u0016c\u001ao\u0012(\u0001tQl\u0014$\u0015e\u0016{\u0003o\u0005c";
      m[33] = "DQM7=\u00101qF8,_P\u007fM3(\u0005$";
      m[34] = "_\u0014!\u0011W/_\u00146M[ E_6S[5B.d\u0007\nt";
      m[35] = "\u0017/bp\u001bz\u0017/u,\u0017u\rdu2\u0017`\n\u0015'iO!";
      m[36] = "z;B._b\u000f\u001bI!N-n\u0015B*Jw\u001a";
      m[37] = "\u007fJNW/O\u007fJY\u000b#@e\u0001Y\u0015#Ubp\u000bN{\u001f";
      m[38] = "jwQr\u0012u\u001fWZ}\u0003:~YQv\u0007`\n";
      m[39] = "+LzVu\u000e+Lm\ny\u00011\u0007m\u0014y\u00146v?N.V";
      m[40] = "RX\u0002\u0019\n\u001a'x\t\u0016\u001bUFv\u0002\u001d\u001f\u000f2";
      m[41] = "-6 >\u0010\u0002o7oka\u0012\u0017}y9Q\u0006|}z`\nx";
      m[42] = "\u0004\u0017\u001f\u007fN8\u0001FJ\u0000X\u0000\u001aA\faC;PQLq1?\u0007S\u001br\bd\u000fOL\u0000";
      m[43] = "^Oi:\u0019H[R?#)\u0012]Se%E \u000b\u00168~\u0019wJ\u001f82\u0012\u001eYF;|)";
      m[44] = "\u0006\u0015\u0000N:^\u0011W\u0018\u0014UR\u0012W\u0002O9`@\u001aZ\u0019UP\u0003\u001aYGjQF\u0016\u0003(";
      m[45] = "_P\u0011a(VN\u0003\u001e\u007fZU[2Am9NMN\u001b\u007f*L5X\u001eo9@QIM`'2";
      m[46] = "\u0006 (x\\J\u0010!-=\"_mk!|CDV!1<S6\u0004y!{\u0012T\u0011y6q\"";
      m[47] = ".f{w!\u0015+{-n\u0011O-zwh}}{8+2-*/ki4}\u0010ze|7\u0011";
      m[48] = "\u0019\u0014U>/qQ\u0014I0Hg)\u0010\\()y\u0012ZLh9\u000b@\u0002\\/xiU\u0002K%H";
      m[49] = "\u0010\u001e\u0017:*tR\u001fXo[e*UN=kpAUMd0\u000e";
      m[50] = "\u001aM!K$k\tW`\u0010\u001fa\u0012P?\u0016vm+^?\u0006r\u000bJQ \u0011m2\u0011Y<F\u001f";
      m[51] = "M\\\u0006m\t\u0010HAPt9JN@\nrUx\u0018\u0002V(\u0006/LQ\u0014.U\u0015\u0019_\u0001-9FJU\u0010%[SJB\u001a\u0015";
      m[52] = " \b_ hG%\u0015\t9X\u001d#\u0014S?4/tT\u0003bhxq\u000eH2*A*\u0006TeX";
      m[53] = "\u001b@\u0007a(F\u0017\u0007Yq\u0013Cy\u0003UsrZBIE3b(F\u001eGda\u0011\u001d\u0016[3\u0013";
      m[54] = "9k\u007f\u001b2]7dzFY\u0004Z9(B%\u0015&c:Q'm";
      m[55] = "#_6Sy0sS4I\u0004+)B\nP`7\">o^mz1Uo]4!O";
      m[56] = "R\u0017\u0007Yq\u001b\u0004\u0000^\u0010\tN\u0003\u0011Z\u000ee|R]\u0001S5+W\u0014\u0002WiS\u0001\u0004\\\u0004\t";
      m[57] = "Q{>\u001eGs\u0019{\"\u0010 da\u007f7\bA{Z5'HQ\t\bm7\u000f\u0010k\u001dm \u0005 ";
      m[58] = "!\n\u007fo1i$\u0017)v\u00013\"\u0016spm\u0001tT/*<V \u0007m,mlu\tx/\u0001";
      m[59] = "\u007fS\u0012fR=>Z\u0016?1j(Z\u0010\u0003\fc&V\u0014\u007fVq5Tl";
      m[60] = "H\u0013JP+NP\u0010\u001fYV\u001aM@KW\u0001M\u0013\u0017\u0013;8\u0014@U\u001f\u0004=\t\u0016L";
      m[61] = "}<9\u0006Q\u001c'.*\u0004)\r9.3\u001eR`}<9\u0006Q\u001c'.*\u0004)_&(0\b\u0010\u0004.4gz";
      m[62] = "F_+\u0007wz^S;\u001b\u001da/\f/\u0002vaUD/\u001ex";
      m[63] = "*6E[.h6o\u0014I^=,a\u0011[\tcs7I79/|7\u001a\b8jpm";
      m[64] = "G*j?+\u0018\u0006#nfHI\u0014(R78U}lr!\"[D7z=u)";
      m[65] = "Q\u0010mc'\u0004TA8\u001c1<\r\u0017eq#\\UD;|X\u0005\fIng8]_\u0017c\u001c";
      m[66] = "'\u0010?Oq\u0007q\u0000a\u001c\u0011\u001eb\u0004}\u0018m\u0018di=\bo\u001a}X|\u0001kC\u001e";
      m[67] = " 6$gZR67!\"$GK}-cE\\p7=#U.'g&tYTwk$n$";
      m[68] = "m|T7oi{}Qr\u0011q\u00067]3pg=}Ms`\u00159*O$c,b\"Ss\u0011";
      m[69] = "Qg+Q\u0006[\f(+]lM1b#\u001d\rV\n(3]\u001d$Xp#\u001a\\FMp4\u0010l";
      m[70] = "<5?7I\u0016 ln%9C:bk7n\u0011j7>k9J'>44\u0006Kb2n";
      m[71] = "+sq%=H8*rk\u0006D<?,2jvl\u007fwe\u0006\u001a6*|+m\u001a5s'U\u007f\u001f3%#<h]+\u007fL";
      m[72] = "\u0018FH8$+\u0019\u0004N8H.\u001c\u0013\u0010*\u001f}MFDF-xA\u0000\u0018-,:G\u0000";
      m[73] = "\b)P}\\NI=BzmK54Sa\fP\u000e~C!\u001c\"\n.]~WAPsUgm";
      m[74] = "#\u0012\"\u001fK4z\u001bf\u001c:%F\u00124Y[>}X$\u0019KL/\u00004^\n.:\u0000#T:";
      m[75] = "\u0002\u0015U&-=\u0007D\u0000Y>\u0005\u001cCF8 >VS\u0006(R>\u0000C\u000b'9>\u0003\u001aPY";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(554569513354147L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(554569513354147L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(554569513354147L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 237;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 239;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 100;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 218;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 236;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 209;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 237;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 239;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 100;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fd_C0278",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
