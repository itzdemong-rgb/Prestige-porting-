package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.MovementEvaluationUtil;
import dev.zprestige.prestige.api.util.PredictionResult;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.util.PredictionType;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;

public class PredictDoubleHand extends Module {
   private MultiModeSetting a;
   private MultiModeSetting c;
   private MinMaxSetting d;
   private FloatSetting e;
   private ElapsedTimer f;
   private long g;
   private static final long k = 2242136072973L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long o;
   private static final Object[] p = new Object[86];
   private static final String[] q = new String[86];

   public PredictDoubleHand() {
      super();
      long var10001 = 131362445738571L ^ 24686067348834L;

      this.f = new ElapsedTimer(106698256430889L);
      this.g = o;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      int var12;
      boolean var47;
      long var10001 = 68244117898870L ^ 63422901323653L;
      var10001 = 68244117898870L ^ 115038718496240L;
      var10001 = 68244117898870L ^ 140622546207488L;
      var10001 = 68244117898870L ^ 139548398558232L;
      var12 = Event.bReturningInt();
      MultiModeSetting var10000 = this.c;
      Object[] var15 = new Object[]{"Auto Crystal", 71444480285294L};
      MultiModeSetting var14 = var10000;
      boolean var94 = var14.aReturningBoolean(var15);
      int var62 = var12;
      boolean var61 = var94;
      var47 = var61;
      boolean var44 = var61;
      label79:
      if (var62 == 0) {
         boolean var63 = var44;
         if (var63) {
            int var65 = var12;
            boolean var64 = AutoCrystal.a;
            var47 = var64;
            boolean var45 = var64;
            if (var65 != 0) {
               break label79;
            }

            boolean var66 = var45;
            boolean var46 = var66;
            boolean var67 = var46;
            if (var67) {
               return;
            }
         }

         var10000 = this.c;
         Object[] var20 = new Object[]{"Auto Hit Crystal", 71444480285294L};
         MultiModeSetting var19 = var10000;
         boolean var68 = var19.aReturningBoolean(var20);
         var47 = var68;
      }

      boolean var51;
      int var70 = var12;
      boolean var69 = var47;
      var51 = var69;
      boolean var48 = var69;
      label71:
      if (var70 == 0) {
         boolean var71 = var48;
         if (var71) {
            int var73 = var12;
            boolean var72 = AutoHitCrystal.a;
            var51 = var72;
            boolean var49 = var72;
            if (var73 != 0) {
               break label71;
            }

            boolean var74 = var49;
            boolean var50 = var74;
            boolean var75 = var50;
            if (var75) {
               return;
            }
         }

         var10000 = this.a;
         Object[] var26 = new Object[]{"Pearl", 71444480285294L};
         MultiModeSetting var25 = var10000;
         var51 = var25.aReturningBoolean(var26);
      }

      int var77 = var12;
      boolean var76 = var51;
      boolean var53 = var76;
      boolean var52 = var76;
      if (var77 == 0) {
         boolean var78 = var52;
         if (!var78) {
            return;
         }

         Object[] var29 = new Object[0];
         PacketSendEvent var28 = var1;
         boolean var79 = var28.aReturningVoid(var29) instanceof PlayerInteractItemC2SPacket;
         var53 = var79;
      }

      boolean var80 = var53;
      if (var80) {
         MinecraftClient var31 = b;
         ClientPlayerEntity var32 = var31.player;
         ItemStack var33 = var32.getMainHandStack();
         Item var97 = var33.getItem();
         int var82 = var12;
         Item var81 = var97;
         Item var56 = var81;
         Item var54 = var81;
         if (var82 == 0) {
            Item var83 = var54;
            Item var55 = var83;
            Item var85 = Items.ENDER_PEARL;
            Item var84 = var55;
            if (var84 != var85) {
               return;
            }

            Item var86 = Items.TOTEM_OF_UNDYING;
            var56 = var86;
         }

         int var88 = var12;
         Item var87 = var56;
         Item var58 = var87;
         Item var57 = var87;
         if (var88 == 0) {
            Object[] var37 = new Object[]{var57, 8519502184947L};
            boolean var89 = InventoryUtil.lReturningBoolean(var37);
            if (var89) {
               return;
            }

            Item var90 = Items.TOTEM_OF_UNDYING;
            var58 = var90;
         }

         Object[] var40 = new Object[]{var58, 95321893129094L};
         Integer var13 = InventoryUtil.aReturningBoxedInteger(var40);
         int var92 = var12;
         Integer var91 = var13;
         Integer var60 = var91;
         Integer var59 = var91;
         if (var92 == 0) {
            Integer var93 = var59;
            if (var93 == null) {
               return;
            }

            var60 = var13;
         }

         Integer var42 = var60;
         int var98 = var42;
         Object[] var10003 = new Object[]{null, 72518082610550L};
         var10003[0] = var98;
         Object[] var43 = var10003;
         InventoryUtil.aReturningVoid(var43);
      }
   }

   @EventListener
   public void a(Render2DEvent var1) {
      int var22;
      boolean var135;
      long var10001 = 66790645514664L ^ 64877382434907L;
      var10001 = 66790645514664L ^ 122943843483404L;
      var10001 = 66790645514664L ^ 109623190192967L;
      var10001 = 66790645514664L ^ 116613515250222L;
      var10001 = 66790645514664L ^ 1547262506273L;
      var10001 = 66790645514664L ^ 136634157571014L;
      var10001 = 66790645514664L ^ 135216207786169L;
      var10001 = 66790645514664L ^ 83212637805523L;
      var10001 = 66790645514664L ^ 49513797606932L;
      var22 = Event.bReturningInt();
      MultiModeSetting var10000 = this.c;
      Object[] var31 = new Object[]{"Auto Crystal", 71444480285294L};
      MultiModeSetting var30 = var10000;
      boolean var254 = var30.aReturningBoolean(var31);
      int var175 = var22;
      boolean var174 = var254;
      var135 = var174;
      boolean var132 = var174;
      label209:
      if (var175 == 0) {
         boolean var176 = var132;
         if (var176) {
            int var178 = var22;
            boolean var177 = AutoCrystal.a;
            var135 = var177;
            boolean var133 = var177;
            if (var178 != 0) {
               break label209;
            }

            boolean var179 = var133;
            boolean var134 = var179;
            boolean var180 = var134;
            if (var180) {
               return;
            }
         }

         var10000 = this.c;
         Object[] var36 = new Object[]{"Auto Hit Crystal", 71444480285294L};
         MultiModeSetting var35 = var10000;
         boolean var181 = var35.aReturningBoolean(var36);
         var135 = var181;
      }

      boolean var139;
      int var183 = var22;
      boolean var182 = var135;
      var139 = var182;
      boolean var136 = var182;
      label201:
      if (var183 == 0) {
         boolean var184 = var136;
         if (var184) {
            int var186 = var22;
            boolean var185 = AutoHitCrystal.a;
            var139 = var185;
            boolean var137 = var185;
            if (var186 != 0) {
               break label201;
            }

            boolean var187 = var137;
            boolean var138 = var187;
            boolean var188 = var138;
            if (var188) {
               return;
            }
         }

         ElapsedTimer var256 = this.f;
         Object[] var42 = new Object[]{this.d, 130913203968635L};
         ElapsedTimer var41 = var256;
         var139 = var41.bReturningBoolean(var42);
      }

      boolean var189 = var139;
      if (var189) {
         int var191 = var22;
         MinecraftClient var190 = b;
         MinecraftClient var142 = var190;
         MinecraftClient var140 = var190;
         if (var191 == 0) {
            MinecraftClient var192 = var140;
            MinecraftClient var141 = var192;
            MinecraftClient var44 = var141;
            Screen var193 = var44.currentScreen;
            if (var193 != null) {
               return;
            }

            MinecraftClient var194 = b;
            var142 = var194;
         }

         int var196 = var22;
         MinecraftClient var195 = var142;
         MinecraftClient var144 = var195;
         MinecraftClient var143 = var195;
         if (var196 == 0) {
            MinecraftClient var47 = var143;
            boolean var197 = var47.isWindowFocused();
            if (!var197) {
               return;
            }

            var144 = b;
         }

         Item var148;
         label215: {
            MinecraftClient var50 = var144;
            ClientWorld var51 = var50.world;
            long var23 = var51.getTime();
            long var282;
            int var257 = (var282 = var23 - this.g) == 0L ? 0 : (var282 < 0L ? -1 : 1);
            int var199 = var22;
            int var198 = var257;
            int var147 = var198;
            int var145 = var198;
            if (var199 == 0) {
               int var200 = var145;
               if (!((var200) != 0)) {
                  return;
               }

               this.g = var23;
               int var202 = var22;
               Item var201 = Items.TOTEM_OF_UNDYING;
               var148 = var201;
               Item var146 = var201;
               if (var202 != 0) {
                  break label215;
               }

               Object[] var53 = new Object[]{var146, 8519502184947L};
               byte var203 = ((byte)((InventoryUtil.lReturningBoolean(var53)) ? 1 : 0));
               var147 = var203;
            }

            int var204 = var147;
            if (((var204) != 0)) {
               return;
            }

            var148 = Items.TOTEM_OF_UNDYING;
         }

         Object[] var55 = new Object[]{var148, 95321893129094L};
         Integer var25 = InventoryUtil.aReturningBoxedInteger(var55);
         Integer var205 = var25;
         if (var205 != null) {
            Object[] var57 = new Object[]{77260333461777L};
            PlayerEntity var26 = EntityUtil.aReturningPlayerEntity(var57);
            PlayerEntity var206 = var26;
            if (var206 != null) {
               MinecraftClient var59 = b;
               ClientPlayerEntity var60 = var59.player;
               float var258 = var60.getHealth();
               MinecraftClient var61 = b;
               ClientPlayerEntity var62 = var61.player;
               float var27 = var258 + var62.getAbsorptionAmount();
               MinecraftClient var63 = b;
               PlayerEntity var65 = var26;
               ClientPlayerEntity var64 = var63.player;
               float var283;
               int var259 = (var283 = var64.distanceTo((Entity)var65) - 10.0F) == 0.0F ? 0 : (var283 < 0.0F ? -1 : 1);
               int var208 = var22;
               int var207 = var259;
               int var150 = var207;
               int var149 = var207;
               if (var208 == 0) {
                  int var209 = var149;
                  if (var209 > 0) {
                     return;
                  }

                  var10000 = this.c;
                  Object[] var68 = new Object[]{"Shield", 71444480285294L};
                  MultiModeSetting var67 = var10000;
                  var150 = (((var67.aReturningBoolean(var68)) ? 1 : 0));
               }

               label217: {
                  int var211 = var22;
                  int var210 = var150;
                  int var152 = var210;
                  int var151 = var210;
                  if (var211 == 0) {
                     int var212 = var151;
                     if (var212 == 0) {
                        break label217;
                     }

                     Object[] var70 = new Object[]{Items.SHIELD, 8519502184947L};
                     byte var213 = ((byte)((InventoryUtil.lReturningBoolean(var70)) ? 1 : 0));
                     var152 = var213;
                  }

                  int var215 = var22;
                  int var214 = var152;
                  int var154 = var214;
                  int var153 = var214;
                  if (var215 == 0) {
                     int var216 = var153;
                     if (var216 == 0) {
                        break label217;
                     }

                     MinecraftClient var73 = b;
                     ClientPlayerEntity var74 = var73.player;
                     byte var217 = ((byte)((var74.isUsingItem()) ? 1 : 0));
                     var154 = var217;
                  }

                  int var218 = var154;
                  if (var218 != 0) {
                     return;
                  }
               }

               Class<PredictionType> var76 = PredictionType.class;
               EnumSet var28 = EnumSet.noneOf(var76);
               var10000 = this.a;
               Object[] var78 = new Object[]{"Anchors", 71444480285294L};
               MultiModeSetting var77 = var10000;
               byte var262 = ((byte)((var77.aReturningBoolean(var78)) ? 1 : 0));
               int var220 = var22;
               byte var219 = var262;
               byte var156 = var219;
               byte var155 = var219;
               if (var220 == 0) {
                  byte var221 = var155;
                  if (var221 != 0) {
                     PredictionType var81 = PredictionType.ANCHOR;
                     EnumSet var80 = var28;
                     var80.add(var81);
                  }

                  var10000 = this.a;
                  Object[] var84 = new Object[]{"Crystals", 71444480285294L};
                  MultiModeSetting var83 = var10000;
                  var156 = ((byte)((var83.aReturningBoolean(var84)) ? 1 : 0));
               }

               int var223 = var22;
               byte var222 = var156;
               byte var158 = var222;
               byte var157 = var222;
               if (var223 == 0) {
                  byte var224 = var157;
                  if (var224 != 0) {
                     PredictionType var87 = PredictionType.CRYSTAL;
                     EnumSet var86 = var28;
                     var86.add(var87);
                  }

                  var10000 = this.a;
                  Object[] var90 = new Object[]{"Obsidian", 71444480285294L};
                  MultiModeSetting var89 = var10000;
                  var158 = ((byte)((var89.aReturningBoolean(var90)) ? 1 : 0));
               }

               int var226 = var22;
               byte var225 = var158;
               byte var160 = var225;
               byte var159 = var225;
               if (var226 == 0) {
                  byte var227 = var159;
                  if (var227 != 0) {
                     PredictionType var93 = PredictionType.OBSIDIAN;
                     EnumSet var92 = var28;
                     var92.add(var93);
                  }

                  var10000 = this.a;
                  Object[] var96 = new Object[]{"Mace", 71444480285294L};
                  MultiModeSetting var95 = var10000;
                  var160 = ((byte)((var95.aReturningBoolean(var96)) ? 1 : 0));
               }

               int var229 = var22;
               byte var228 = var160;
               byte var162 = var228;
               byte var161 = var228;
               if (var229 == 0) {
                  byte var230 = var161;
                  if (var230 != 0) {
                     PredictionType var99 = PredictionType.MACE;
                     EnumSet var98 = var28;
                     var98.add(var99);
                  }

                  EnumSet var101 = var28;
                  var162 = ((byte)((var101.isEmpty()) ? 1 : 0));
               }

               byte var167;
               int var232 = var22;
               byte var231 = var162;
               var167 = var231;
               byte var163 = var231;
               label150:
               if (var232 == 0) {
                  byte var233 = var163;
                  if (var233 == 0) {
                     FloatSetting var103 = this.e;
                     Float var104 = (Float)var103.aReturningObject();
                     float var10002 = var104;
                     Object[] var10005 = new Object[]{null, null, null, 91740244377252L};
                     var10005[2] = var10002;
                     var10005[1] = var28;
                     var10005[0] = var26;
                     Object[] var105 = var10005;
                     PredictionResult var29 = MovementEvaluationUtil.aReturningfX_C0317(var105);
                     Object[] var107 = new Object[0];
                     PredictionResult var106 = var29;
                     byte var266 = ((byte)((var106.aReturningBoolean(var107)) ? 1 : 0));
                     int var235 = var22;
                     byte var234 = var266;
                     var167 = var234;
                     byte var164 = var234;
                     if (var235 != 0) {
                        break label150;
                     }

                     byte var236 = var164;
                     if (var236 != 0) {
                        Object[] var10004 = new Object[]{null, 104510714069743L};
                        var10004[0] = var27;
                        Object[] var110 = var10004;
                        PredictionResult var109 = var29;
                        byte var267 = ((byte)((var109.bReturningBoolean(var110)) ? 1 : 0));
                        int var238 = var22;
                        byte var237 = var267;
                        var167 = var237;
                        byte var165 = var237;
                        if (var238 != 0) {
                           break label150;
                        }

                        byte var239 = var165;
                        byte var166 = var239;
                        byte var240 = var166;
                        if (var240 != 0) {
                           Integer var113 = var25;
                           int var278 = var113;
                           var10004 = new Object[]{null, 67992163153033L};
                           var10004[0] = var278;
                           Object[] var115 = var10004;
                           PredictDoubleHand var114 = this;
                           var114.jReturningVoid(var115);
                           return;
                        }
                     }
                  }

                  var10000 = this.a;
                  Object[] var118 = new Object[]{"Sword Pop", 71444480285294L};
                  MultiModeSetting var117 = var10000;
                  var167 = ((byte)((var117.aReturningBoolean(var118)) ? 1 : 0));
               }

               int var242 = var22;
               byte var241 = var167;
               byte var169 = var241;
               byte var168 = var241;
               if (var242 == 0) {
                  byte var243 = var168;
                  if (var243 == 0) {
                     return;
                  }

                  PlayerEntity var120 = var26;
                  Object[] var121 = new Object[]{var120.getMainHandStack(), 19476550655932L};
                  byte var244 = ((byte)((InventoryUtil.aReturningBoolean(var121)) ? 1 : 0));
                  var169 = var244;
               }

               int var173;
               int var246 = var22;
               byte var245 = var169;
               var173 = var245;
               byte var170 = var245;
               label134:
               if (var246 == 0) {
                  byte var247 = var170;
                  if (var247 == 0) {
                     PlayerEntity var124 = var26;
                     ItemStack var125 = var124.getMainHandStack();
                     byte var269 = ((byte)((var125.getItem() instanceof AxeItem) ? 1 : 0));
                     int var249 = var22;
                     byte var248 = var269;
                     var173 = var248;
                     byte var171 = var248;
                     if (var249 != 0) {
                        break label134;
                     }

                     byte var250 = var171;
                     byte var172 = var250;
                     byte var251 = var172;
                     if (var251 == 0) {
                        return;
                     }
                  }

                  float var284;
                  int var252 = (var284 = var27 - 1.0F) == 0.0F ? 0 : (var284 < 0.0F ? -1 : 1);
                  var173 = var252;
               }

               int var253 = var173;
               if (var253 < 0) {
                  Integer var129 = var25;
                  int var279 = var129;
                  Object[] var281 = new Object[]{null, 67992163153033L};
                  var281[0] = var279;
                  Object[] var131 = var281;
                  PredictDoubleHand var130 = this;
                  var130.jReturningVoid(var131);
               }
            }
         }
      }
   }

   private void jReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 2242136072973L ^ var3;
      long var5 = var3 ^ 83662343891403L;
      long var7 = var3 ^ 27668005748612L;
      long var9 = var3 ^ 138713746100978L;
      int var11 = Event.cReturningInt();
      MinecraftClient var12 = b;
      ClientPlayerEntity var13 = var12.player;
      byte var10000 = ((byte)((var13.isUsingItem()) ? 1 : 0));
      int var23 = var11;
      byte var22 = var10000;
      int var21 = var22;
      byte var20 = var22;
      if (var23 != 0) {
         byte var24 = var20;
         if (var24 != 0) {
            return;
         }

         var21 = var2;
      }

      Object[] var10003 = new Object[]{null, var9};
      var10003[0] = var21;
      Object[] var15 = var10003;
      InventoryUtil.aReturningVoid(var15);
      MinMaxSetting var26 = this.d;
      Object[] var17 = new Object[]{var5};
      MinMaxSetting var16 = var26;
      var16.bReturningVoid(var17);
      ElapsedTimer var27 = this.f;
      Object[] var19 = new Object[]{var7};
      ElapsedTimer var18 = var27;
      var18.aReturningVoid(var19);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(134412572946821L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[11];
      String var11 = "Ã[X¯ám\u009aOh°×£\u0018d2è\u0016ìÉ\u008d¹L\u0018ÌMív\u001cïì±\u00120ò)@\u0086·Óq\u0086xÞ\u009d\u0083Â\u0001¨Bµ&Ùí\u008a\t.\u0013·\u0085Rôö7\"p\u0087èØ·7\u001c±\r\u0005]\u0010Wª÷Ù\f\u0010\u001cÍ\u0001\u001a\u008b-E>#\u0084\u0084JÂT:é\u0010Ú\u00194]m|1\u008eÈ\u0084\u0012å;r\u0091b(ä\u009a¤\u000fîÄÙâ\u0089RÅ`^\u009c\b\u0013\u0088:C\u0002¿\\\u001f1ö;%kS['ÉÆa-H¬\u0017(i\u0018\u0006\b`;ËÞëb6z\u008dº\u007f[-\u0012Ø^m¦*\u0086^*\u0010\u000e\u0000yB\u0018\u0019k¾ùP+;»Æm6 k\u000b\u008f\\î\u009bI Y\u001b©\u0088u,\u009c\u008e\u0002tô&\u0017S±@VA\u009b\u009a\u009fx\u0018¯ BÍü*[\u00122Ñ\u008f5EIØ\u0013¹¤Ñ\u0002©\u0086$¯>\b@\u0096NÑ\u007fÚ<¢";
      int var13 = "Ã[X¯ám\u009aOh°×£\u0018d2è\u0016ìÉ\u008d¹L\u0018ÌMív\u001cïì±\u00120ò)@\u0086·Óq\u0086xÞ\u009d\u0083Â\u0001¨Bµ&Ùí\u008a\t.\u0013·\u0085Rôö7\"p\u0087èØ·7\u001c±\r\u0005]\u0010Wª÷Ù\f\u0010\u001cÍ\u0001\u001a\u008b-E>#\u0084\u0084JÂT:é\u0010Ú\u00194]m|1\u008eÈ\u0084\u0012å;r\u0091b(ä\u009a¤\u000fîÄÙâ\u0089RÅ`^\u009c\b\u0013\u0088:C\u0002¿\\\u001f1ö;%kS['ÉÆa-H¬\u0017(i\u0018\u0006\b`;ËÞëb6z\u008dº\u007f[-\u0012Ø^m¦*\u0086^*\u0010\u000e\u0000yB\u0018\u0019k¾ùP+;»Æm6 k\u000b\u008f\\î\u009bI Y\u001b©\u0088u,\u009c\u008e\u0002tô&\u0017S±@VA\u009b\u009a\u009fx\u0018¯ BÍü*[\u00122Ñ\u008f5EIØ\u0013¹¤Ñ\u0002©\u0086$¯>\b@\u0096NÑ\u007fÚ<¢"
         .length();
      char var10 = ' ';
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     l = var14;
                     m = new String[11];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(134412572946821L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = -2133622231088553812L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)226L,
                           (byte)57955L,
                           (byte)14836697L,
                           (byte)3798194658L,
                           (byte)972337832607L,
                           (byte)248918485147415L,
                           (byte)63723132197738272L,
                           (byte)-2133622231088553812L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     o = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "¸\fÐªÁ(Mä_\u0086\u0013~3n»\u0082\u0018[Lºm#§Ì#áònxâÿîÊ-\u0093yg\f\u0088DÉ";
                  var13 = "¸\fÐªÁ(Mä_\u0086\u0013~3n»\u0082\u0018[Lºm#§Ì#áònxâÿîÊ-\u0093yg\f\u0088DÉ".length();
                  var10 = 16;
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3094;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ff", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ff_C0282",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ff" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 53;
            yield var16;
         }
         case 2 -> {
            byte var17 = 6;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 5;
            yield var19;
         }
         case 5 -> {
            byte var20 = 9;
            yield var20;
         }
         case 6 -> {
            byte var21 = 51;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 11;
            yield var23;
         }
         case 9 -> {
            byte var24 = 52;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 7;
            yield var26;
         }
         case 12 -> {
            byte var27 = 44;
            yield var27;
         }
         case 13 -> {
            byte var28 = 19;
            yield var28;
         }
         case 14 -> {
            byte var29 = 26;
            yield var29;
         }
         case 15 -> {
            byte var30 = 56;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 36;
            yield var32;
         }
         case 18 -> {
            byte var33 = 39;
            yield var33;
         }
         case 19 -> {
            byte var34 = 12;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 15;
            yield var37;
         }
         case 23 -> {
            byte var38 = 30;
            yield var38;
         }
         case 24 -> {
            byte var39 = 60;
            yield var39;
         }
         case 25 -> {
            byte var40 = 41;
            yield var40;
         }
         case 26 -> {
            byte var41 = 37;
            yield var41;
         }
         case 27 -> {
            byte var42 = 10;
            yield var42;
         }
         case 28 -> {
            byte var43 = 20;
            yield var43;
         }
         case 29 -> {
            byte var44 = 46;
            yield var44;
         }
         case 30 -> {
            byte var45 = 21;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 0;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 8;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 48;
            yield var53;
         }
         case 39 -> {
            byte var54 = 45;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 61;
            yield var56;
         }
         case 42 -> {
            byte var57 = 38;
            yield var57;
         }
         case 43 -> {
            byte var58 = 1;
            yield var58;
         }
         case 44 -> {
            byte var59 = 34;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 22;
            yield var64;
         }
         case 50 -> {
            byte var65 = 35;
            yield var65;
         }
         case 51 -> {
            byte var66 = 14;
            yield var66;
         }
         case 52 -> {
            byte var67 = 58;
            yield var67;
         }
         case 53 -> {
            byte var68 = 32;
            yield var68;
         }
         case 54 -> {
            byte var69 = 42;
            yield var69;
         }
         case 55 -> {
            byte var70 = 59;
            yield var70;
         }
         case 56 -> {
            byte var71 = 17;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 13;
            yield var73;
         }
         case 59 -> {
            byte var74 = 25;
            yield var74;
         }
         case 60 -> {
            byte var75 = 31;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 4;
            yield var77;
         }
         default -> 27;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      p[0] = "\u0019\u0000\nt\u0004x\u000f\u0000\u000f.\u0017o\u0018K\f(\u001b{\t\f\u001b?Pi8";
      p[1] = int.class;
      q[1] = "java/lang/Integer";
      p[2] = "s]\u00136J$e]\u0016lY3r\u0016\u0015jU'cQ\u0002}\u001e0Y";
      p[3] = "N;\u007f\u0000sx;\u001bt\u000fb7Z\u0015\u007f\u0004fm.";
      p[4] = boolean.class;
      q[4] = "java/lang/Boolean";
      p[5] = "\u0013\u0016X\u0000GX\u0005\u0016]ZTO\u0012]^\\X[\u0003\u001aIK\u0013N/";
      p[6] = "y$'*\u0010X\f\u0004,%\u0001\u0017m\n'.\u0005M\u0019";
      p[7] = "/\b\u0010uN\u001f/\b\u0007)B\u00105C\u00077B\u000522Ul\u001aO";
      p[8] = "M\u0012%\u000e\u0002UM\u00122R\u000eZWY2L\u000eOP(`\u0017V\u000e";
      p[9] = "-J\u007fyqT-Jh%}[7\u0001h;}N0p8f,";
      p[10] = "\r_\rRi9\r_\u001a\u000ee6\u0017\u0014\u001a\u0010e#\u0010eMO3";
      p[11] = ";>\u000e\u001bj\u0018->\u000bAy\u000f:u\bGu\u001b+2\u001fP>\u000e\u0006";
      p[12] = "\u0001E,\u0003\u001c\u0000te'\f\rO\u0015k,\u0007\t\u0015a";
      p[13] = "hU(\u007f9\\~U-%*Ki\u001e.#&_xY94mHJ";
      p[14] = "T7\u0013<> _8\u0002s_.T3\u0006)";
      p[15] = "ND\u0003\u0019QxND\u0014E]wT\u000f\u0014[]bS~@\u0003\n";
      p[16] = "\u0013G3\u0003:/\u0013G$_6 \t\f$A65\u000e}v\u001fnq";
      p[17] = float.class;
      q[17] = "java/lang/Float";
      p[18] = "c(EUz=h'T\u001a\u001d?},TQ&";
      p[19] = "W\"\f|t%W\"\u001b x*Mi\u001b>x?J\u0018Id,{";
      p[20] = "\u0003!6,6-\u001d),c]6\u001c-\u0013(l";
      p[21] = "' \u0017\u001c\u0015w,/\u0006Sxw,2\u0012";
      p[22] = "V\u0000vE\u0001*# }J\u0010eB.vA\u0014?6";
      p[23] = "\u000b:0@X\u001d\u001d:5\u001aK\n\nq6\u001cG\u001e\u001b6!\u000b\f\u000e\u0000";
      p[24] = "X\u0016\tjS0-6\u0002eB\u007fL8\tnF%8";
      p[25] = "C\n\\\u0019f`U\nYCuwBAZEycS\u0006MR2vA";
      p[26] = "\u001c[\r\u00136Ci{\u0006\u001c'\f\bu\r\u0017#V|";
      p[27] = void.class;
      q[27] = "java/lang/Void";
      p[28] = "}\u0012P7@\u000fv\u001dAx#\u0002c\u0010N\u0013\u0016\u0000r\u0003R?\u0001\r";
      p[29] = "fRQU\u000b;\u0013rZZ\u001atr|QQ\u001e.\u0006";
      p[30] = "0.\u001aEeO&.\u001f\u001fvX1e\u001c\u0019zL \"\u000b\u000e1Y\u0001";
      p[31] = "@\u007fJl-\n5_Ac<ETQJh8\u001f ";
      p[32] = "+'d\u000fIE+'sSEJ1lsME_6\u001d!\u0019\u0014\u001e";
      p[33] = "\u000fxHUE+\u0019xM\u000fV<\u000e3N\tZ(\u001ftY\u001e\u0011=<";
      p[34] = "L~G\"W29^L-F}XPG&B',";
      p[35] = "\u0002'Ol\u0006`\u0002'X0\no\u0018lX.\nz\u001f\u001d\rqS";
      p[36] = "l)Ls\nGg&]<bGi)N";
      p[37] = "=\u001b)\b\u00017H;\"\u0007\u0010x)5)\f\u0014\"]";
      p[38] = long.class;
      q[38] = "java/lang/Long";
      p[39] = "}qE\u0006|L\bQN\tm\u0003i_E\u0002iY\u001d";
      p[40] = "\u00197/4=\u0000\u000f7*n.\u0017\u0018|)h\"\u0003\t;>\u007fi\u0012\u0018";
      p[41] = "Js8\u0012E6?S3\u001dTy^]8\u0016P#*";
      p[42] = "={zF\u000b\t={m\u001a\u0007\u0006'0m\u0004\u0007\u0013 A<]_V";
      p[43] = "\u001e(Yy\u0016^\u0000 C6kN\u0000";
      p[44] = "S1\u001f8\u0018'E1\u001ab\u000b0Rz\u0019d\u0007$C=\u000esL3{";
      p[45] = "\fs},\b+ySv#\u0019d\u0018]}(\u001d>l";
      p[46] = "]N\u0002 qp(n\t/`?I`\u0002$de=";
      p[47] = "Y5:ZK@F=h\u0005!P$)i\u001b\u0018A\\?;TD:E(-VXE\u001e9-\u0017!";
      p[48] = "\u001b$u\u0018\u0012J@co(\u0000(B%zQWBCe-Dj";
      p[49] = "*\u0013W\u0012Z9b\n\u0001R==\u0013\u000e\u0006S\u0004/k\u0018T\u001cXT(III\u0000.|OFZ=";
      p[50] = "iw#\u0010W\"4mbDipRta\rPa*b3B\f\u001ai3.\u0017T`=5!\u0004i";
      p[51] = "<?\tl\u001c]xi\rxfCly\u0002`\nq>4Z6f\u001b{{\u0005iVIho\u001a\u0007";
      p[52] = "\u00148F\u001a0GO5D\u001bZVKdEM\r\u0001\u00154\u001c!eQ\u00148_\u001b5\u0001Q3";
      p[53] = "|X8\u0000|S\u007f\u001b`\u0007\u0015G\u0013\u001e?\u0011,Uk\bm^p.r\u001f{\\lQ)\u000e{\u001d\u0015";
      p[54] = "b~\u0005:\u0016{$j\u0012ux\"q\u0012\u0000;A~\u007f{\u0011`\u00134\u001fo\u0005iG+!)\u0011~\bE";
      p[55] = "wTVjQD,YTk;^$\u0019Q6WlpX\u000f`;\u0000q\u0014ZlATw\u001bIQ";
      p[56] = "n\u00009\u0007@`5G#7S\u00027\u00016N\u0005h6Aa[8";
      p[57] = "\u000b\nG\u001d\r,[S\u001cTw&;HAUN7C^\u0013\u001a\u0012L\u0000\u000f\u000eOJ6T\t\u0001\\w";
      p[58] = "\u001cZyE\u000fEDF+_1\u001c-T|\u001d\n\u0015DE'O@u";
      p[59] = "o\u0007s\np\u0004eC3\u0013M\u001dk\u0002-\u000b!/;Av]M\u0012e\u00176\u00061\u0018|\u0018=l'\u0007{\u001d<Rv\u0018<\u0012M";
      p[60] = "m3\u007fbg`kt<b\u00168gv[vr$l\n<!y <`=a.5\u0001";
      p[61] = "E\u0017\u001fF\u001aP\u001e\u001a\u001dGpA\u001aK\u001c\u0011'\u0016D\u001cD}\u0019VE@E\u0001\u0013\u0012\u0005Y";
      p[62] = "\u0006^w\u0000\u0012\u001cV\u0007,Ih\u00156\u001cqHQ\u0007N\n#\u0007\r|W\u001d5\u0005\u0011\u0003\f\f5Dh";
      p[63] = "3L\u00021+\u001dj^\u0010x\u0017\t7M\rl@Wh\u001bU\u0000*\u001d(G\u00070x\u000e<X";
      p[64] = ":\u0012>;ffkIo0_e;^1>3Wh\u001amf_=lI:#$y:M.Y";
      p[65] = "M \u0013<f8K#\u001ff\u001b07&Dq\"\"O0\u0016>~YK0\bijiU!\u0017\u007f\u001b";
      p[66] = "9\u0014\u001eV\u000b\u0014mO\u001b\bv\u00183M\u001aq\u0018~9S\u0013\u000f\r\u0013dT\u001dLv\u0013kB\u0017K\u001cG0GI6";
      p[67] = "\u0015[m}*dHA,)\u00145.X/`-'VN}/q\\\u0015\u001f`z)&A\u0019oi\u0014";
      p[68] = "T>i\u0017Er^z)\u000exkP;7\u0016\u0014Y\u0003\u007flKxdB:4\u0000F5]};q";
      p[69] = "l9]5Whoz\u00052>|\u0003\u007fZ$\u0007n{i\bk[\u0015o9\u001e(O,i~](>";
      p[70] = "z4Tj\u007f`%7W$\u0011r\u001a/\u000f'(kb9]ht\u0010{.Kjho ?K+\u0011";
      p[71] = "6^ 0*Mi]#~DTVX\"k%\u0003;C|h%=4]\"mzP/\u0003!mD";
      p[72] = "\u0002tx\u0019#=\u00017 \u001eJ$m2\u007f\bs;\u0015$-G/@Vu0\u0012w:\u0002s?\u0001J";
      p[73] = "1FYlT|.\u001aD2eiU\u0005\u0019#\\{-\u0013Kl\u0000\u00009JH0\\fh\u0011\u0019;e";
      p[74] = "{80;!s\"*\"r\u001dg\u007f9?fJ9$dk\n s`35:r`t,";
      p[75] = "wz<\u007f\u0018v}>|f%os\u007fb~I] ;>&%7$hic^srl}\u0019";
      p[76] = "p3\\PO\u000e$hY\u000e2\u0005fAPHN\u0015\u001d7\rAYYgc\u000bNJd";
      p[77] = "=_SzJq+QFl*e[N\u0000g\u0013w#XR(O\f`MBz\u00144=W\u0003.*";
      p[78] = "\u0005\u001bL\t\u000e\rQ@IWs\u000e\u0004H%\u0000M^SDL\u0011\u0016\f\u0019$\u001eQ\u0002\fU^JW\r\u001fh";
      p[79] = ".B\u001a}t\nuO\u0018|\u001e\u001bq\u001e\u0019*IL.CBFy\u001bi\u0010\u0011#%L.\t";
      p[80] = "Rw.<]\u001f\u000be<ua\u000bVv!a6U\r&x\r\\\u001fI|+=\u000e\f]c";
      p[81] = "N\u0006=PWTVW2Z7]R\b2KiZR\u001267]LK\f*\t\fS\f\u0003[";
      p[82] = "zU\u001c\u0002d/p\u0011\\\u001bY6~PB\u00035\u0004-\u0014\u001c[Y9lQA\u0015ghs\u0016Nd";
      p[83] = "r\fx\u000ev[qO \t\u001fO\u001dJ\u007f\u001f&]e\\-Pz&&\r0\u0005\"\\r\u000b?\u0016\u001f";
      p[84] = "}YyMfJw\u001d9T[Sy\\'L7a*\u0019~\u0016[\r,Q,\u0016!Y*^?+";
      p[85] = "S#]\u0013y^\u000ft\u001a\n\u0015^Y1D\u0017yl\u000bp\u001eN-;M(J\u001f~_\u000et\u001fN\u0015";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1032612166556530L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1032612166556530L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1032612166556530L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 214;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 103;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 236;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 225;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 88;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 216;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 214;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 103;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 236;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ff_C0282",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ff" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
