package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

public class Refill extends Module {
   private ModeSetting a;
   private BindSetting f;
   private IntSetting c;
   private IntSetting d;
   private ElapsedTimer e;
   private static final long k = 51390688064913L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[52];
   private static final String[] s = new String[52];

   public Refill() {
      super();
      long var10001 = 84818935626355L ^ 48580059139418L;

      this.e = new ElapsedTimer(106698256430889L);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 99872381032974L ^ 8774226341188L;
      var10001 = 99872381032974L ^ 39956463324186L;
      var10001 = 99872381032974L ^ 136477106123278L;
      var10001 = 99872381032974L ^ 69358434002459L;
      var10001 = 99872381032974L ^ 94818317254456L;
      int var14 = Event.bReturningInt();
      int var78 = var14;
      MinecraftClient var77 = b;
      MinecraftClient var56 = var77;
      MinecraftClient var55 = var77;
      if (var78 == 0) {
         MinecraftClient var19 = var55;
         ClientPlayerEntity var79 = var19.player;
         if (var79 == null) {
            return;
         }

         MinecraftClient var80 = b;
         var56 = var80;
      }

      MinecraftClient var22 = var56;
      ClientWorld var81 = var22.world;
      if (var81 != null) {
         ElapsedTimer var10000 = this.e;
         IntSetting var24 = this.d;
         Integer var25 = (Integer)var24.aReturningObject();
         float var125 = var25.intValue();
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var125;
         Object[] var27 = var10004;
         ElapsedTimer var26 = var10000;
         byte var115 = ((byte)((var26.aReturningBoolean(var27)) ? 1 : 0));
         int var83 = var14;
         byte var82 = var115;
         byte var58 = var82;
         byte var57 = var82;
         if (var83 == 0) {
            byte var84 = var57;
            if (var84 == 0) {
               return;
            }

            Object[] var30 = new Object[]{14198186009910L};
            Refill var29 = this;
            var58 = ((byte)((var29.dReturningBoolean(var30)) ? 1 : 0));
         }

         int var86 = var14;
         byte var85 = var58;
         byte var60 = var85;
         byte var59 = var85;
         if (var86 == 0) {
            byte var87 = var59;
            if (var87 == 0) {
               return;
            }

            var60 = 0;
         }

         int var15 = var60;

         int var17;
         int var75;
         int var76;
         label90: {
            int var114;
            do {
               byte var89 = 9;
               int var88 = var15;
               if (var88 >= var89) {
                  break;
               }

               label102: {
                  MinecraftClient var32 = b;
                  ClientPlayerEntity var33 = var32.player;
                  PlayerInventory var116 = var33.getInventory();
                  int var35 = var15;
                  PlayerInventory var34 = var116;
                  ItemStack var16 = var34.getStack(var35);
                  ItemStack var36 = var16;
                  byte var117 = ((byte)((var36.isEmpty()) ? 1 : 0));
                  int var91 = var14;
                  byte var90 = var117;
                  int var62 = var90;
                  byte var61 = var90;
                  if (var91 == 0) {
                     byte var92 = var61;
                     if (var92 != 0) {
                        break label102;
                     }

                     ItemStack var38 = var16;
                     var62 = var38.getMaxCount();
                  }

                  int var95 = var14;
                  byte var94 = 1;
                  int var93 = var62;
                  int var65 = var93;
                  int var66 = var94;
                  int var63 = var93;
                  byte var64 = var94;
                  if (var95 == 0) {
                     byte var97 = var64;
                     int var96 = var63;
                     if (var96 <= var97) {
                        break label102;
                     }

                     ItemStack var40 = var16;
                     int var118 = var40.getCount();
                     ItemStack var41 = var16;
                     var66 = var41.getMaxCount();
                     var65 = var118;
                  }

                  int var72;
                  label103: {
                     int var100 = var14;
                     int var99 = var66;
                     int var98 = var65;
                     int var70 = var98;
                     int var71 = var99;
                     int var67 = var98;
                     int var68 = var99;
                     if (var100 == 0) {
                        int var102 = var68;
                        int var101 = var67;
                        if (var101 >= var102) {
                           break label102;
                        }

                        ItemStack var43 = var16;
                        int var119 = var43.getCount();
                        int var104 = var14;
                        int var103 = var119;
                        var72 = var103;
                        int var69 = var103;
                        if (var104 != 0) {
                           break label103;
                        }

                        IntSetting var44 = this.c;
                        Integer var45 = (Integer)var44.aReturningObject();
                        int var106 = var45;
                        int var105 = var69;
                        var70 = var105;
                        var71 = var106;
                     }

                     int var108 = var71;
                     int var107 = var70;
                     if (var107 > var108) {
                        break label102;
                     }

                     Object[] var48 = new Object[]{var16, 102459421734730L};
                     Refill var47 = this;
                     var72 = var47.aReturningInt(var48);
                  }

                  var17 = var72;
                  int var111 = var14;
                  // int var109 = var17;
                  var75 = var109;
                  var76 = var110;
                  int var73 = var109;
                  byte var74 = var110;
                  if (var111 != 0) {
                     break label90;
                  }

                  byte var113 = var74;
                  int var112 = var73;
                  if (var112 != var113) {
                     var76 = var15;
                     var75 = 36;
                     break label90;
                  }
               }

               var15++;
               var114 = var14;
            } while (var114 == 0);

            return;
         }

         int var18 = var75 + var76;
         Object[] var10005 = new Object[]{null, null, SlotActionType.PICKUP, 111882238786581L};
         var10005[1] = 0;
         var10005[0] = var17;
         Object[] var50 = var10005;
         InventoryUtil.eReturningBoolean(var50);
         var10005 = new Object[]{null, null, SlotActionType.PICKUP, 111882238786581L};
         var10005[1] = 0;
         var10005[0] = var18;
         Object[] var51 = var10005;
         InventoryUtil.eReturningBoolean(var51);
         var10005 = new Object[]{null, null, SlotActionType.PICKUP, 111882238786581L};
         var10005[1] = 0;
         var10005[0] = var17;
         Object[] var52 = var10005;
         InventoryUtil.eReturningBoolean(var52);
         var10000 = this.e;
         Object[] var54 = new Object[]{42835128969216L};
         ElapsedTimer var53 = var10000;
         var53.aReturningVoid(var54);
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 51390688064913L ^ var2;
      int var4 = Event.cReturningInt();
      ModeSetting var6 = this.a;
      String var10000 = (String)var6.aReturningObject();
      short var10001 = 1753;
      long var10002 = 7810544816718250203L ^ var2;
      String var8 = "Always";
      String var7 = var10000;
      byte var47 = ((byte)((var7.equals(var8)) ? 1 : 0));
      int var31 = var4;
      byte var30 = var47;
      int var21 = var30;
      byte var20 = var30;
      if (var31 != 0) {
         byte var32 = var20;
         if (var32 != 0) {
            MinecraftClient var10 = b;
            return var10.currentScreen instanceof InventoryScreen;
         }

         BindSetting var12 = this.f;
         Integer var13 = (Integer)var12.aReturningObject();
         var21 = var13;
      }

      int var5 = var21;
      int var35 = var4;
      // int var33 = var5;
      int var26 = var33;
      byte var27 = var34;
      int var22 = var33;
      byte var23 = var34;
      if (var35 != 0) {
         byte var37 = var23;
         int var36 = var22;
         if (var36 == var37) {
            return false;
         }

         MinecraftClient var15 = b;
         Window var16 = var15.getWindow();
         long var48 = var16.getHandle();
         int var19 = var5;
         long var17 = var48;
         int var49 = GLFW.glfwGetKey(var17, var19);
         int var39 = var4;
         int var38 = var49;
         int var28 = var38;
         int var24 = var38;
         if (var39 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var28);
         }

         int var40 = var24;
         int var25 = var40;
         byte var42 = 1;
         int var41 = var25;
         var26 = var41;
         var27 = var42;
      }

      byte var44 = var27;
      int var43 = var26;
      if (var43 == var44) {
         byte var50 = 1;
         return dev.prestige.recovery.SourceSupport.asBoolean(var50);
      } else {
         return false;
      }
   }

   private int aReturningInt(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      long var3 = (Long)var1[1];
      var3 = 51390688064913L ^ var3;
      int var10000 = Event.cReturningInt();
      short var10001 = 13046;
      long var10002 = 755192907183040195L ^ var3;
      int var6 = 9;
      int var5 = var10000;

      byte var21;
      while (true) {
         var10001 = 4433;
         var10002 = 1009095108006544741L ^ var3;
         byte var23 = 36;
         int var22 = var6;
         if (var22 < var23) {
            label27: {
               MinecraftClient var8 = b;
               ClientPlayerEntity var9 = var8.player;
               PlayerInventory var34 = var9.getInventory();
               int var11 = var6;
               PlayerInventory var10 = var34;
               ItemStack var7 = var10.getStack(var11);
               int var25 = var5;
               ItemStack var24 = var7;
               ItemStack var20 = var24;
               ItemStack var17 = var24;
               if (var25 != 0) {
                  ItemStack var12 = var17;
                  byte var35 = ((byte)((var12.isEmpty()) ? 1 : 0));
                  int var27 = var5;
                  byte var26 = var35;
                  var21 = var26;
                  byte var18 = var26;
                  if (var27 == 0) {
                     break;
                  }

                  byte var28 = var18;
                  byte var19 = var28;
                  byte var29 = var19;
                  if (var29 != 0) {
                     break label27;
                  }

                  var20 = var7;
               }

               ItemStack var15 = var20;
               Item var36 = var15.getItem();
               ItemStack var16 = var2;
               Item var31 = var16.getItem();
               Item var30 = var36;
               if (var30 == var31) {
                  return var6;
               }
            }

            var6++;
            int var32 = var5;
            if (var32 != 0) {
               continue;
            }
         }

         var21 = -1;
         break;
      }

      return var21;
   }

   private boolean lambda$new$0(Integer var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Keybind";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(2489208464293L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[2];
      String var17 = "õ¬Â)Å¸0ÌþÊäÔñt<Ü\u0010(ü/r[\"Õ\u0096n\u0098ykp÷ð8";
      int var19 = "õ¬Â)Å¸0ÌþÊäÔñt<Ü\u0010(ü/r[\"Õ\u0096n\u0098ykp÷ð8".length();
      char var16 = 16;
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var30 = b(var21).intern();
         int var10001 = -1;
         var20[var18++] = var30;
         if ((var15 += var16) >= var19) {
            l = var20;
            m = new String[2];
            q = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(2489208464293L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[4];
            String var4 = "\u0091\u001b·mîµÌ:Ð½\u0086\tL\u0002\u000eö";
            int var5 = "\u0091\u001b·mîµÌ:Ð½\u0086\tL\u0002\u000eö".length();
            label32:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var25 = var6;
               var10001 = var3++;
               long var33 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               // while (true) {
                  long var8 = var33;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var38 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var36) {
                     case 0:
                        var25[var10001] = var38;
                        if (var2 >= var5) {
                           o = var6;
                           p = new Integer[4];
                           break;
                        }
                        break;
                     default:
                        var25[var10001] = var38;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "µ}MsÖ\u001c9H\u009b\u0093\u0000Oxl\u001cè";
                        var5 = "µ}MsÖ\u001c9H\u009b\u0093\u0000Oxl\u001cè".length();
                        var2 = 0;
                  }

                  int var29 = var2;
                  var2 += 8;
                  var7 = var4.substring(var29, var2).getBytes("ISO-8859-1");
                  var25 = var6;
                  var10001 = var3++;
                  var33 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var36 = 0;
               }
            }
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5797;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fh", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fh_C0286",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22252;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fh", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fh_C0286",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 16;
            yield var15;
         }
         case 1 -> {
            byte var16 = 11;
            yield var16;
         }
         case 2 -> {
            byte var17 = 43;
            yield var17;
         }
         case 3 -> {
            byte var18 = 62;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 52;
            yield var21;
         }
         case 7 -> {
            byte var22 = 60;
            yield var22;
         }
         case 8 -> {
            byte var23 = 5;
            yield var23;
         }
         case 9 -> {
            byte var24 = 14;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 47;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 54;
            yield var29;
         }
         case 15 -> {
            byte var30 = 34;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 48;
            yield var32;
         }
         case 18 -> {
            byte var33 = 28;
            yield var33;
         }
         case 19 -> {
            byte var34 = 39;
            yield var34;
         }
         case 20 -> {
            byte var35 = 26;
            yield var35;
         }
         case 21 -> {
            byte var36 = 57;
            yield var36;
         }
         case 22 -> {
            byte var37 = 51;
            yield var37;
         }
         case 23 -> {
            byte var38 = 41;
            yield var38;
         }
         case 24 -> {
            byte var39 = 50;
            yield var39;
         }
         case 25 -> {
            byte var40 = 59;
            yield var40;
         }
         case 26 -> {
            byte var41 = 46;
            yield var41;
         }
         case 27 -> {
            byte var42 = 42;
            yield var42;
         }
         case 28 -> {
            byte var43 = 1;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 61;
            yield var45;
         }
         case 31 -> {
            byte var46 = 25;
            yield var46;
         }
         case 32 -> {
            byte var47 = 56;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 63;
            yield var50;
         }
         case 36 -> {
            byte var51 = 44;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 17;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 29;
            yield var59;
         }
         case 45 -> {
            byte var60 = 21;
            yield var60;
         }
         case 46 -> {
            byte var61 = 13;
            yield var61;
         }
         case 47 -> {
            byte var62 = 9;
            yield var62;
         }
         case 48 -> {
            byte var63 = 15;
            yield var63;
         }
         case 49 -> {
            byte var64 = 32;
            yield var64;
         }
         case 50 -> {
            byte var65 = 33;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 49;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 45;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 37;
            yield var72;
         }
         case 58 -> {
            byte var73 = 3;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 7;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 35;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "G+l\u0006bOG+{Zn@]`{DnUZ\u0011/\u001c9";
      r[1] = "?|*\u0012Jw?|=NFx%7=PFm\"Fo\n\u0011/";
      r[2] = "j$p88\u0014j$gd4\u001bpogz4\u000ew\u001e5!lD";
      r[3] = "V\u000eVL\f>V\u000eA\u0010\u00001LEA\u000e\u0000$K4\u0013UXe";
      r[4] = "q\u0011~<5rg\u0011{f&epZx`*qa\u001dowad}";
      r[5] = "l?1\u00005\u007fg0 OVrr=/$cpc.3\bt}";
      r[6] = boolean.class;
      s[6] = "java/lang/Boolean";
      r[7] = "\u0006P\u0001M\u00127\u0010P\u0004\u0017\u0001 \u0007\u001b\u0007\u0011\r4\u0016\\\u0010\u0006F&'";
      r[8] = int.class;
      s[8] = "java/lang/Integer";
      r[9] = "#\u0000V\u0006#'#\u0000AZ/(9KAD/=>:\u0011\u0019~";
      r[10] = "P1s]\u001e\u007fF1v\u0007\rhQzu\u0001\u0001|@=b\u0016Jim";
      r[11] = "'4K\u0010\u0014tR\u0014@\u001f\u0005;3\u001aK\u0014\u0001aG";
      r[12] = "\u007fu6%T\f\nU=*ECk[6!A\u0019\u001f";
      r[13] = "O\u0015A\u001d\n\u001dO\u0015VA\u0006\u0012U^V_\u0006\u0007R/\u0003\u0000_";
      r[14] = "+:r\u001d\u0018]=:wG\u000bJ*qtA\u0007^;6cVLI\t";
      r[15] = "WB@g+\u000e\\MQ(J\u0000WFUr";
      r[16] = "&\u0012{ElT-\u001dj\n\u000bV8\u0016jA0";
      r[17] = "2vYyt\\GVRve\u0013&XY}aIR";
      r[18] = void.class;
      s[18] = "java/lang/Void";
      r[19] = " \u0000\u0016i%\u0019U \u001df4V4.\u0016m0\f@";
      r[20] = "1ZS8\u000e)'ZVb\u001d>0\u0011Ud\u0011*!VBsZ::";
      r[21] = "-\u0016i\u0015>\u001bX6b\u001a/T98i\u0011+\u000eM";
      r[22] = "tEae\u001bRtEv9\u0017]n\u000ev'\u0017Hi\u007f$|G\b";
      r[23] = "\u0019@\u0006Xv$\u0019@\u0011\u0004z+\u0003\u000b\u0011\u001az>\u0004zCF/|";
      r[24] = long.class;
      s[24] = "java/lang/Long";
      r[25] = "6\u0003\u000bx>~=\f\u001a7Cf.\u000b\u0013~";
      r[26] = "K6q\u0018\u0019\u0006K6fD\u0015\tQ}fZ\u0015\u001cV\f1\u0005C";
      r[27] = "\fs]\nZR\tfV\nQI\u0005v\u0014czc4";
      r[28] = "P\u001e\u001a'W\u0019\u0002\u000b\u001f<g\tmLU$\u0006^QJ\u00178\u0017c";
      r[29] = "Q\u000f*1wQ\u0000Q,7M\tS\u001c'4!;\u0002\\vkM\f\u0000\fxot\bW\u001e>S";
      r[30] = "N2\u001d0K9^?\u0012#*8W-E$QUG>\u0017z\u0014/\u0014`L,*iN-V,I7K\"W@";
      r[31] = "\u0019\u001d\u0005\u0004>5WMP~29Z\u0010\u0006\u0012\u0000o\u001fM]NWm\u001f\u001f\u0003G*?CK]~";
      r[32] = "\\\rQW^y_\u0005PI3`c\u0004T\u000fCl\u0002VUQ\r\t_\tOH_j\u0001\f@I3";
      r[33] = "\u001d$5\u000egAO'xFW\\&'/C'UGu.\u001di0\u001a*4\u0004;SD/;\u0005W";
      r[34] = "\"\u0013J\u0005*7+\u001d\u001f^\u0016;v\u0011@\u0005z\t$\\\u0018S\u0016dq\u000fM\u0001xbc\u000b\\b";
      r[35] = "Q3[Te\u0000X=\u000e\u000fY\f\u00051QT5>W|\b\u000fYT\u001a(P\u000eeRX4A3";
      r[36] = "C^(\u0007(h\u0011]eO\u0018px\u000b5\u0007`wEZlO#\u0019CQ$\u000fv$\u0012\blL\u0018";
      r[37] = "4\n\u0002n\n\u0007{\u0011\u0014yvTk\u001a\bs!\u00035JQ\u001f\u0017\u0003mMSy\b_g\u0019";
      r[38] = "2,__?c;\"\n\u0004\u0003of.U_o]4c\u000b\u0000\u00036k/OT`hn N8";
      r[39] = "\b\u0002\u0007j~F\u000eP\u0005{\u0019V\u000eS\bDtE)P\u0006\u000by\u0007\u0006\u0002K2}P\u0014Dw6k\\\u000b\u0000K0)@\u001a=Jy|XW\u0001L;`Ij";
      r[40] = "\u000f\u0000(\u000e,j]\u0015-\u0015\u001c{2Rg\r}-\u000eT%\u0011l\u0010";
      r[41] = "\f*l\u001f@Q^v8AyIXoc\u001a\u0015{\b/8My\u0011Gvb@E\u0017\u0005js}@R_t?\u0014I\\\n/\u0003";
      r[42] = "\u0005q/\ff8Jj9\u001b\u001akZa%\u0011M<\u0005<~}+4\u0006q-B%oP`";
      r[43] = "=1\u001b#mUswP UE\f'\u0004\"o\u0012vtZy9,";
      r[44] = "\r\r.s>\u0002_\u0007qg\u0001\u001a\u0001\u001aAqe\u0006\nf\"jd\u001aZZ$(x\u000bg";
      r[45] = "pv>\u0014)\r?m(\u0003U^/f4\t\u0002\tq1lej]*q9\u0004$\r\u007f";
      r[46] = "Vsn\u0019\u0018\u0015U{o\u0007u\fizkA\u0005\u0000\b(j\u001fKe\u0002pk\u001f\u001e^\u0019|fGu";
      r[47] = "?)Ct*6m*\u000e<\u001a.\u0004*Y9j\"exXg$G95Ze'{?wFt\u001a";
      r[48] = "tV(\u0006/|)\tn\u0018El\u0019T3W5dx\u00062\t{\u0001%Y(\u0010)b{\\'\u0011E";
      r[49] = "\u0014t\u001bQmV[o\rF\u0011\u000eGu\u0015G}<\u00103K\u0010*kEf\u0018B+V\u00148\u001eD\u0011";
      r[50] = "NK\u000b,p/GE^wL#\u001aI\u0001, \u0011H\u0004]tL{\u0005P\u0000vp}GL\u0011K";
      r[51] = "\u0010}T.L/@aK8w:\u001f~M> kA\"\u0011R\u0019:\u0003o\u0012)I&\u001cy";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1058156069603953L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1058156069603953L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1058156069603953L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 249;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 255;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 226;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 88;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 241;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 196;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 249;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 255;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 226;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fh_C0286",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
