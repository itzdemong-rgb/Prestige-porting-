package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.MouseInputManager;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;

public class RightClicker extends Module {
   private FloatSetting a;
   private FloatSetting c;
   private ElapsedTimer d;
   private float e;
   private static final long k = 3068771071118L;
   private static final Object[] l = new Object[41];
   private static final String[] m = new String[41];

   public RightClicker() {
      super();
      long var10001 = 115058655503545L ^ 10650208572304L;

      this.d = new ElapsedTimer(106698256430889L);
      this.e = 200.0F;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 119773971332340L;
      Object[] var7 = new Object[]{var4};
      RightClicker var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 138919760953709L ^ 938585085817L;
      var10001 = 138919760953709L ^ 97502529612141L;
      var10001 = 138919760953709L ^ 62629936670950L;
      var10001 = 138919760953709L ^ 102557185157103L;
      var10001 = 138919760953709L ^ 56089038581061L;
      int var14 = Event.cReturningInt();
      int var48 = var14;
      MinecraftClient var47 = b;
      MinecraftClient var38 = var47;
      MinecraftClient var37 = var47;
      if (var48 != 0) {
         MinecraftClient var15 = var37;
         Screen var49 = var15.currentScreen;
         if (var49 != null) {
            return;
         }

         MinecraftClient var50 = b;
         var38 = var50;
      }

      MinecraftClient var18 = var38;
      int var52 = var14;
      ClientPlayerEntity var51 = var18.player;
      ClientPlayerEntity var40 = var51;
      ClientPlayerEntity var39 = var51;
      if (var52 != 0) {
         ClientPlayerEntity var53 = var39;
         if (var53 == null) {
            return;
         }

         MinecraftClient var20 = b;
         ClientPlayerEntity var54 = var20.player;
         var40 = var54;
      }

      ClientPlayerEntity var22 = var40;
      boolean var10000 = var22.isUsingItem();
      int var56 = var14;
      boolean var55 = var10000;
      boolean var42 = var55;
      boolean var41 = var55;
      if (var56 != 0) {
         boolean var57 = var41;
         if (var57) {
            return;
         }

         MouseInputManager var66 = Prestige.j;
         Object[] var25 = new Object[]{38614768952962L};
         MouseInputManager var24 = var66;
         boolean var58 = var24.aReturningBoolean(var25);
         var42 = var58;
      }

      ElapsedTimer var46;
      label51: {
         int var60 = var14;
         boolean var59 = var42;
         boolean var45 = var59;
         boolean var43 = var59;
         if (var60 != 0) {
            boolean var61 = var43;
            if (var61) {
               return;
            }

            int var63 = var14;
            ElapsedTimer var62 = this.d;
            var46 = var62;
            ElapsedTimer var44 = var62;
            if (var63 == 0) {
               break label51;
            }

            float var72 = this.e;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var72;
            Object[] var29 = var10004;
            ElapsedTimer var28 = var44;
            boolean var64 = var28.aReturningBoolean(var29);
            var45 = var64;
         }

         boolean var65 = var45;
         if (!var65) {
            return;
         }

         MouseInputManager var67 = Prestige.j;
         Object[] var10005 = new Object[]{null, null, 85057401875496L};
         var10005[1] = 0.0F;
         var10005[0] = 1;
         Object[] var32 = var10005;
         MouseInputManager var31 = var67;
         var31.aReturningVoid(var32);
         Object[] var34 = new Object[]{77717099882891L};
         RightClicker var33 = this;
         var33.jReturningVoid(var34);
         var46 = this.d;
      }

      Object[] var36 = new Object[]{42835128969216L};
      ElapsedTimer var35 = var46;
      var35.aReturningVoid(var36);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 3068771071118L ^ var2;
      long var4 = var2 ^ 54332772407800L;
      FloatSetting var6 = this.a;
      Float var7 = (Float)var6.aReturningObject();
      float var10002 = var7;
      float var9 = 1.0F;
      float var8 = var10002;
      var10002 = Math.max(var8, var9);
      FloatSetting var10 = this.c;
      Float var11 = (Float)var10.aReturningObject();
      float var10003 = var11;
      Object[] var10006 = new Object[]{null, null, var4};
      var10006[1] = var10003;
      var10006[0] = var10002;
      Object[] var12 = var10006;
      this.e = 1000.0F / RandomUtil.aReturningFloat(var12);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 37;
            yield var15;
         }
         case 1 -> {
            byte var16 = 40;
            yield var16;
         }
         case 2 -> {
            byte var17 = 11;
            yield var17;
         }
         case 3 -> {
            byte var18 = 9;
            yield var18;
         }
         case 4 -> {
            byte var19 = 0;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 13;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 16;
            yield var23;
         }
         case 9 -> {
            byte var24 = 14;
            yield var24;
         }
         case 10 -> {
            byte var25 = 5;
            yield var25;
         }
         case 11 -> {
            byte var26 = 39;
            yield var26;
         }
         case 12 -> {
            byte var27 = 19;
            yield var27;
         }
         case 13 -> {
            byte var28 = 2;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 21;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 24;
            yield var32;
         }
         case 18 -> {
            byte var33 = 60;
            yield var33;
         }
         case 19 -> {
            byte var34 = 17;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 27;
            yield var37;
         }
         case 23 -> {
            byte var38 = 15;
            yield var38;
         }
         case 24 -> {
            byte var39 = 55;
            yield var39;
         }
         case 25 -> {
            byte var40 = 48;
            yield var40;
         }
         case 26 -> {
            byte var41 = 20;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 46;
            yield var43;
         }
         case 29 -> {
            byte var44 = 22;
            yield var44;
         }
         case 30 -> {
            byte var45 = 45;
            yield var45;
         }
         case 31 -> {
            byte var46 = 53;
            yield var46;
         }
         case 32 -> {
            byte var47 = 30;
            yield var47;
         }
         case 33 -> {
            byte var48 = 35;
            yield var48;
         }
         case 34 -> {
            byte var49 = 43;
            yield var49;
         }
         case 35 -> {
            byte var50 = 31;
            yield var50;
         }
         case 36 -> {
            byte var51 = 3;
            yield var51;
         }
         case 37 -> {
            byte var52 = 61;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 29;
            yield var54;
         }
         case 40 -> {
            byte var55 = 1;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 49;
            yield var57;
         }
         case 43 -> {
            byte var58 = 50;
            yield var58;
         }
         case 44 -> {
            byte var59 = 58;
            yield var59;
         }
         case 45 -> {
            byte var60 = 41;
            yield var60;
         }
         case 46 -> {
            byte var61 = 25;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 28;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 56;
            yield var65;
         }
         case 51 -> {
            byte var66 = 54;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 34;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 47;
            yield var72;
         }
         case 58 -> {
            byte var73 = 32;
            yield var73;
         }
         case 59 -> {
            byte var74 = 7;
            yield var74;
         }
         case 60 -> {
            byte var75 = 4;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 57;
            yield var77;
         }
         default -> 8;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "s\u001d\u001e(Q\u0015e\u001d\u001brB\u0002rV\u0018tN\u0016c\u0011\u000fc\u0005\u0003N";
      l[1] = "Y{k]{V,[`Rj\u0019MUkYnC9";
      l[2] = boolean.class;
      m[2] = "java/lang/Boolean";
      l[3] = "s\btgB\u0016e\bq=Q\u0001rCr;]\u0015c\u0004e,\u0016\u0000}";
      l[4] = "\u001fw\u0015\u001c\u0013{jW\u001e\u0013\u00024\u000bY\u0015\u0018\u0006n\u007f";
      l[5] = void.class;
      m[5] = "java/lang/Void";
      l[6] = "\u000b\u00192%h9\u000b\u0019%yd6\u0011R%gd#\u0016#u:5";
      l[7] = "\u001d\u0004m\u0018v\u0019\u001d\u0004zDz\u0016\u0007OzZz\u0003\u0000>-\u0005,";
      l[8] = "q\u0005\b0<vz\n\u0019\u007f_{o\u0007\u0016\u0014jy~\u0014\n8}t";
      l[9] = "[&\u000b\nU\u0005M&\u000ePF\u0012Zm\rVJ\u0006K*\u001aA\u0001\u0014z";
      l[10] = int.class;
      m[10] = "java/lang/Integer";
      l[11] = "]\u0010i\u0014{\u0018K\u0010lNh\u000f\\[oHd\u001bM\u001cx_/\u000bU\u001czTuFi\u0007zIu\u0001^\u0010";
      l[12] = "~=0R\u007f{h=5\bll\u007fv6\u000e`xn1!\u0019+jh";
      l[13] = "\u000bo\bd\"U\u000bo\u001f8.Z\u0011$\u001f&.O\u0016UK~y";
      l[14] = "ra\u0007\u0019\tn\u0007A\f\u0016\u0018!fO\u0007\u001d\u001c{\u0012";
      l[15] = "0~~\bS\u0004E^u\u0007BK$P~\fF\u0011P";
      l[16] = "v/)3\u001b+\u0003\u000f\"<\ndb\u0001)7\u000e>\u0016";
      l[17] = "\u0015\"c17\u001e\u001e-r~T\u0013\u000b+";
      l[18] = float.class;
      m[18] = "java/lang/Float";
      l[19] = ",\u001e#\u00042\u000e:\u001e&^!\u0019-U%X-\r<\u00122Of\u001a\u000e";
      l[20] = "\u0006]p\u0019cD\rRaV\u0002J\u0006Ye\f";
      l[21] = "*c_\u000e\"\u0000!lNAJ\u0000/c]";
      l[22] = "\u0001\u0006o~GN\u0017\u0006j$TY\u0000Mi\"XM\u0011\n~5\u0013Z\f";
      l[23] = "M q4hm8\u0000z;y\"Y\u000eq0}x-";
      l[24] = "Mu#\u001d{-S}9R\u0006=S";
      l[25] = "\u0002\u001f\u0003t\b\u0013\r\u0011\u000f\u0019\u001ex\u000e\u0010\u0000pH\u0002P\u001d\u0000%wA\u0006\u0016\fvOI\u0019\u0017A\u0019";
      l[26] = "HIU]l \u0013^A\u001aP8KG*\f6'F\r\u0015\rjmE7A\u0001*9\u0018\b@]`:\"\\L\u001d4g\u001d]\u0010W7]";
      l[27] = "$2\u0011i-9geF$\u0013e\u001e1E$z8doH$/\u0007\"fB'ihbc\u00127\u0013";
      l[28] = "\u0004d<t\u00197Qp\"qi3\u0005\u001d=-\u00178\u0013t,e\u0017lkpji\u0005,\u0002a\"iQT\u0004d<t\u00197Qp\"qi";
      l[29] = "!NEu@JoXDk%\u001d|O_{rJ\"\u001f\u0006\u0017\u0018\u0011}RC.B\n{Y";
      l[30] = "{U\u0013p!\u00128\u0002D=\u001fEA\u0007\u0012-$H\"FV=g,\u007f\u0000Jw{O>DZ4\u001f";
      l[31] = "\u0010\u0006\u000e< sN\u0017BfN~.X\u0015p*hI\u0002Fk?\u0015";
      l[32] = "\u0014\u0016$HD7\u0011\u0007!D(bx\u0010#\u0006Ds\u0011\u0001k\u0006\u0010\u000b";
      l[33] = "Y52/\tP\u000ec!(uLi9&>\b\u001e\u0016h7#\u0011";
      l[34] = "\tP\u001aB(\u001bGF\u001b\\MLTQ\u0000L\u001a\u001b\n\u0006X |\u0013P\\\u0000\\-\u001f\b^";
      l[35] = "g5\u001cT57h;\u00109#\\k:\u001fPu&57\u001f\u0005J`<=\u001cC% 9m\f9";
      l[36] = "\u001b\u0005\"d%3\u001a\u001f+%G'\u0012\u0006s!\u0019 \u0012\u001cw],/\f\u0005 b-sF\u0006\u001a";
      l[37] = "\u000b_\u0006\u000f{zZN\u001b\u0016Kl;N\u001a\u0003\":A\u0010\u0017\u0003w\u0005\u0002F\u001c\u000f$=\nY\u001dBK";
      l[38] = "\u0015/\u001f\u007f\u0010>\u001d4\u0016'q4{)\u001d6\u0018b\u0001w\u00106M]\u0010 \u000b#Kb\u0011|A q";
      l[39] = "\u007f\u0005I31I.\t\u00111UP#HL49bp\r\u0015nU\f)^Q<m\u00046_\u001cS";
      l[40] = "\u001c2\r\n(GM#\u0010\u0013\u0018Q,#\u0011\u0006q\u0007V}\u001c\u0006$8\u0010t\u0016\u0005bWPqF\u0015\u0018";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1429940730280140L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1429940730280140L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1429940730280140L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 228;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 90;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 193;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 118;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 229;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 115;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 228;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 90;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 193;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fj_C0290",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fj" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
