package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.api.util.ExplosionDamageUtil;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.PacketSendEvent;
import dev.zprestige.prestige.api.util.InteractionUtil;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.FloatAnimation;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;

public class SafeAnchor extends Module implements RotationSource {
   private ModeSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private FloatSetting e;
   private ModeSetting f;
   private MinMaxSetting g;
   private ModeSetting h;
   private ModeSetting i;
   private IntSetting j;
   private FloatSetting k;
   private HashMap l;
   private HashMap m;
   private BlockPos n;
   private ArrayList o;
   private ArrayList p;
   private ElapsedTimer q;
   private static final long r = 38256680837620L;
   private static final String[] s;
   private static final String[] t;
   private static final Map u = new HashMap(13);
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x;
   private static final Object[] y = new Object[194];
   private static final String[] z = new String[194];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;

   public SafeAnchor() {
      super();
      long var10001 = 45970339114426L ^ 80014470519443L;
      var10001 = 45970339114426L ^ 60170865024877L;
      var10001 = 45970339114426L ^ 78437669600894L;
      var10001 = 45970339114426L ^ 133101122676246L;

      this.l = new HashMap();
      this.m = new HashMap();
      this.o = new ArrayList();
      this.p = new ArrayList();
      this.q = new ElapsedTimer(106698256430889L);
      ModeSetting var10000 = this.f;
      Object[] var12 = new Object[]{invokeBinding1(this), 121607650890692L};
      ModeSetting var11 = var10000;
      var11.aReturningModeSetting(var12);
      FloatSetting var17 = this.k;
      Object[] var14 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var13 = var17;
      var13.aReturningFloatSetting(var14);
      BooleanSetting var18 = this.d;
      Object[] var16 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var15 = var18;
      var15.aReturningBooleanSetting(var16);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      HashMap var4 = this.l;
      var4.clear();
      HashMap var5 = this.m;
      var5.clear();
      ArrayList var6 = this.o;
      var6.clear();
      ArrayList var7 = this.p;
      var7.clear();
      this.n = null;
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 3384857487926L ^ 5134647864261L;
      var10001 = 3384857487926L ^ 104361687955843L;
      var10001 = 3384857487926L ^ 95544561944425L;
      var10001 = 3384857487926L ^ 89707138714183L;
      var10001 = 3384857487926L ^ 39955429430757L;
      var10001 = 3384857487926L ^ 115267443680778L;
      var10001 = 3384857487926L ^ 58034703061391L;
      var10001 = 3384857487926L ^ 79437996277747L;
      var10001 = 3384857487926L ^ 127562713837645L;
      int var22 = Event.bReturningInt();
      BooleanSetting var31 = this.d;
      Boolean var32 = (Boolean)var31.aReturningObject();
      int var10000 = ((((java.lang.Boolean)(var32)).booleanValue() ? 1 : 0));
      int var262 = var22;
      boolean var261 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var201 = var261;
      boolean var200 = var261;
      if (var262 == 0) {
         boolean var263 = var200;
         if (var263) {
            ArrayList var372 = this.p;
            Predicate var35 = invokeBinding4();
            ArrayList var34 = var372;
            var34.removeIf(var35);
         }

         HashMap var37 = this.l;
         Set var373 = var37.keySet();
         Predicate var39 = invokeBinding5();
         Set var38 = var373;
         var38.removeIf(var39);
         HashMap var40 = this.m;
         Set var374 = var40.keySet();
         Predicate var42 = invokeBinding6();
         Set var41 = var374;
         var41.removeIf(var42);
         ModeSetting var43 = this.a;
         String var375 = (String)var43.aReturningObject();
         String var45 = "Legit";
         String var44 = var375;
         var201 = var44.equalsIgnoreCase(var45);
      }

      boolean var264 = var201;
      if (var264) {
         int var266 = var22;
         MinecraftClient var265 = b;
         MinecraftClient var204 = var265;
         MinecraftClient var202 = var265;
         if (var266 == 0) {
            MinecraftClient var267 = var202;
            MinecraftClient var203 = var267;
            MinecraftClient var47 = var203;
            Screen var268 = var47.currentScreen;
            if (var268 != null) {
               return;
            }

            MinecraftClient var269 = b;
            var204 = var269;
         }

         MinecraftClient var50 = var204;
         ClientPlayerEntity var51 = var50.player;
         var10000 = (((var51.isUsingItem()) ? 1 : 0));
         int var271 = var22;
         boolean var270 = ((((int)(var10000) & 1) != 0));
         boolean var206 = var270;
         boolean var205 = var270;
         if (var271 == 0) {
            boolean var272 = var205;
            if (var272) {
               return;
            }

            MinecraftClient var53 = b;
            ClientPlayerEntity var54 = var53.player;
            boolean var273 = var54.isOnGround();
            var206 = var273;
         }

         int var275 = var22;
         boolean var274 = var206;
         boolean var208 = var274;
         boolean var207 = var274;
         if (var275 == 0) {
            boolean var276 = var207;
            if (!var276) {
               return;
            }

            RotationManager var377 = Prestige.o;
            Object[] var58 = new Object[0];
            RotationManager var57 = var377;
            var208 = var57.fReturningBoolean(var58);
         }

         boolean var277 = var208;
         if (!var277) {
            SafeAnchor var214;
            label307: {
               int var279 = var22;
               BlockPos var278 = this.n;
               BlockPos var211 = var278;
               BlockPos var209 = var278;
               if (var279 == 0) {
                  BlockPos var280 = var209;
                  if (var280 == null) {
                     return;
                  }

                  int var282 = var22;
                  SafeAnchor var281 = this;
                  var214 = var281;
                  SafeAnchor var210 = var281;
                  if (var282 != 0) {
                     break label307;
                  }

                  BlockPos var283 = var210.n;
                  var211 = var283;
               }

               Object[] var61 = new Object[]{var211, Blocks.RESPAWN_ANCHOR, 90720632922225L};
               boolean var284 = BlockUtil.bReturningBoolean(var61);
               label251:
               if (var284) {
                  SafeAnchor var217;
                  label287: {
                     Object[] var62 = new Object[]{43167644123091L};
                     Vec3d var378 = RaycastUtil.bReturningVec3d(var62);
                     BlockPos var63 = this.n;
                     Vec3d var65 = var63.toCenterPos();
                     Vec3d var64 = var378;
                     double var379 = var64.distanceTo(var65);
                     Object[] var66 = new Object[]{118480199388220L};
                     double var420;
                     var10000 = (var420 = var379 - ItemUseUtil.bReturningFloat(var66)) == 0.0 ? 0 : (var420 < 0.0 ? -1 : 1);
                     int var286 = var22;
                     int var285 = var10000;
                     int var216 = var285;
                     int var212 = var285;
                     if (var286 == 0) {
                        int var287 = var212;
                        int var213 = var287;
                        int var288 = var213;
                        if (var288 > 0) {
                           break label251;
                        }

                        int var290 = var22;
                        SafeAnchor var289 = this;
                        var217 = var289;
                        SafeAnchor var215 = var289;
                        if (var290 != 0) {
                           break label287;
                        }

                        ElapsedTimer var381 = var215.q;
                        Object[] var70 = new Object[]{this.g, 130913203968635L};
                        ElapsedTimer var69 = var381;
                        byte var291 = ((byte)((var69.bReturningBoolean(var70)) ? 1 : 0));
                        var216 = var291;
                     }

                     int var292 = var216;
                     if (var292 == 0) {
                        return;
                     }

                     var217 = this;
                  }

                  BlockPos var23 = var217.n;
                  MinecraftClient var72 = b;
                  ClientPlayerEntity var73 = var72.player;
                  double var382 = var73.getY();
                  BlockPos var74 = var23;
                  double var421;
                  var10000 = (var421 = var382 - var74.getY()) == 0.0 ? 0 : (var421 < 0.0 ? -1 : 1);
                  int var294 = var22;
                  int var293 = var10000;
                  int var219 = var293;
                  int var218 = var293;
                  if (var294 == 0) {
                     int var295 = var218;
                     if (var295 < 0) {
                        return;
                     }

                     ModeSetting var76 = this.i;
                     String var384 = (String)var76.aReturningObject();
                     String var78 = "Glowstone";
                     String var77 = var384;
                     var219 = (((var77.equals(var78)) ? 1 : 0));
                  }

                  int var296 = var219;
                  Block var220;
                  if (var296 != 0) {
                     Block var297 = Blocks.GLOWSTONE;
                     var220 = var297;
                  } else {
                     var220 = Blocks.OBSIDIAN;
                  }

                  Block var24;
                  label237: {
                     var24 = var220;
                     ModeSetting var80 = this.h;
                     String var385 = (String)var80.aReturningObject();
                     String var82 = "None";
                     String var81 = var385;
                     boolean var386 = var81.equals(var82);
                     int var299 = var22;
                     boolean var298 = var386;
                     boolean var222 = var298;
                     boolean var221 = var298;
                     if (var299 == 0) {
                        boolean var300 = var221;
                        if (!var300) {
                           break label237;
                        }

                        Block var84 = var24;
                        Object[] var85 = new Object[]{var84.asItem(), 8519502184947L};
                        boolean var301 = InventoryUtil.lReturningBoolean(var85);
                        var222 = var301;
                     }

                     boolean var302 = var222;
                     if (!var302) {
                        return;
                     }
                  }

                  MinecraftClient var87 = b;
                  HitResult var26 = var87.crosshairTarget;
                  int var304 = var22;
                  HitResult var303 = var26;
                  HitResult var224 = var303;
                  HitResult var223 = var303;
                  if (var304 == 0) {
                     boolean var305 = var223 instanceof BlockHitResult;
                     if (!var305) {
                        return;
                     }

                     HitResult var306 = var26;
                     var224 = var306;
                  }

                  BlockHitResult var25 = (BlockHitResult)var224;
                  int var307 = var22;
                  if (var307 == 0) {
                     BlockHitResult var91 = var25;
                     BlockPos var371 = var91.getBlockPos();
                     BlockPos var93 = var371;
                     BlockPos var92 = var23;
                     int var387 = (((var92.equals(var93)) ? 1 : 0));
                     int var309 = var22;
                     byte var308 = (byte)var387;
                     int var226 = var308;
                     byte var225 = var308;
                     if (var309 == 0) {
                        byte var310 = var225;
                        if (var310 != 0) {
                           return;
                        }

                        HashMap var388 = this.l;
                        Integer var98 = 0;
                        BlockPos var97 = var23;
                        HashMap var96 = var388;
                        Integer var99 = ((java.lang.Integer)(Object)(var96.getOrDefault(var97, var98)));
                        int var311 = var99;
                        var226 = var311;
                     }

                     int var313 = var22;
                     int var312 = var226;
                     int var228 = var312;
                     int var227 = var312;
                     if (var313 == 0) {
                        IntSetting var101 = this.j;
                        Integer var102 = (Integer)var101.aReturningObject();
                        int var315 = var102;
                        int var314 = var227;
                        if (var314 >= var315) {
                           return;
                        }

                        ModeSetting var104 = this.f;
                        String var389 = (String)var104.aReturningObject();
                        String var106 = "After Charge";
                        String var105 = var389;
                        byte var316 = ((byte)((var105.equals(var106)) ? 1 : 0));
                        var228 = var316;
                     }

                     int var232;
                     int var318 = var22;
                     int var317 = var228;
                     var232 = var317;
                     int var229 = var317;
                     label219:
                     if (var318 == 0) {
                        int var319 = var229;
                        if (var319 != 0) {
                           Object[] var109 = new Object[]{var23, 61419523816377L};
                           var387 = BlockUtil.aReturningInt(var109);
                           int var321 = var22;
                           int var320 = var387;
                           var232 = var320;
                           int var230 = var320;
                           if (var321 != 0) {
                              break label219;
                           }

                           int var322 = var230;
                           int var231 = var322;
                           int var323 = var231;
                           if (var323 == 0) {
                              return;
                           }
                        }

                        ExplosionDamageUtil var391 = Prestige.f;
                        MinecraftClient var112 = b;
                        BlockPos var113 = var23;
                        Object[] var115 = new Object[]{var112.player, var113.toCenterPos(), 103347657692085L};
                        ExplosionDamageUtil var114 = var391;
                        double var392 = var114.kReturningVoid(var115);
                        FloatSetting var116 = this.c;
                        Float var117 = (Float)var116.aReturningObject();
                        double var422;
                        var232 = (var422 = var392 - var117.floatValue()) == 0.0 ? 0 : (var422 < 0.0 ? -1 : 1);
                     }

                     int var325 = var22;
                     int var324 = var232;
                     int var234 = var324;
                     int var233 = var324;
                     if (var325 == 0) {
                        int var326 = var233;
                        if (var326 < 0) {
                           return;
                        }

                        BlockHitResult var119 = var25;
                        Object[] var120 = new Object[]{var119.getBlockPos(), Blocks.FIRE, 90720632922225L};
                        var234 = (((BlockUtil.bReturningBoolean(var120)) ? 1 : 0));
                     }

                     int var248;
                     label292: {
                        int var246;
                        int var247;
                        label293: {
                           label309: {
                              int var328 = var22;
                              int var327 = var234;
                              int var238 = var327;
                              int var235 = var327;
                              if (var328 == 0) {
                                 int var329 = var235;
                                 label196:
                                 if (var329 == 0) {
                                    BlockHitResult var122 = var25;
                                    BlockPos var393 = var122.getBlockPos();
                                    Object[] var123 = new Object[]{82650215142853L};
                                    Object[] var124 = new Object[]{var393, BlockUtil.aReturningBlock(var123), 90720632922225L};
                                    byte var394 = ((byte)((BlockUtil.bReturningBoolean(var124)) ? 1 : 0));
                                    int var331 = var22;
                                    byte var330 = var394;
                                    int var241 = var330;
                                    byte var236 = var330;
                                    if (var331 == 0) {
                                       byte var332 = var236;
                                       byte var237 = var332;
                                       byte var333 = var237;
                                       if (var333 != 0) {
                                          break label196;
                                       }

                                       BlockPos var131 = var371;
                                       var241 = var131.getY();
                                    }

                                    BlockPos var132 = var23;
                                    int var411 = var132.getY();
                                    int var342 = var22;
                                    int var341 = var411;
                                    int var340 = var241;
                                    var246 = var340;
                                    var247 = var341;
                                    int var242 = var340;
                                    int var243 = var341;
                                    if (var342 != 0) {
                                       break label293;
                                    }

                                    int var344 = var243;
                                    int var343 = var242;
                                    if (var343 >= var344) {
                                       return;
                                    }
                                    break label309;
                                 }

                                 BlockPos var127 = var371;
                                 int var334 = var127.getY();
                                 var238 = var334;
                              }

                              BlockPos var129 = var23;
                              int var412 = var129.getY();
                              int var337 = var22;
                              int var336 = var412;
                              int var335 = var238;
                              var246 = var335;
                              var247 = var336;
                              int var239 = var335;
                              int var240 = var336;
                              if (var337 != 0) {
                                 break label293;
                              }

                              int var339 = var240;
                              int var338 = var239;
                              if (var338 > var339) {
                                 return;
                              }
                           }

                           BlockPos var134 = var371;
                           var387 = var134.getY();
                           int var346 = var22;
                           int var345 = var387;
                           var248 = var345;
                           int var244 = var345;
                           if (var346 != 0) {
                              break label292;
                           }

                           int var347 = var244;
                           int var245 = var347;
                           BlockPos var136 = var23;
                           int var349 = var136.getY() - 1;
                           int var348 = var245;
                           var246 = var348;
                           var247 = var349;
                        }

                        int var351 = var247;
                        int var350 = var246;
                        if (var350 < var351) {
                           return;
                        }

                        MinecraftClient var138 = b;
                        ClientPlayerEntity var396 = var138.player;
                        BlockPos var139 = var23;
                        Vec3d var141 = var139.toCenterPos();
                        ClientPlayerEntity var140 = var396;
                        double var397 = var140.squaredDistanceTo(var141);
                        MinecraftClient var142 = b;
                        ClientPlayerEntity var413 = var142.player;
                        BlockPos var143 = this.n;
                        Vec3d var145 = var143.toCenterPos();
                        ClientPlayerEntity var144 = var413;
                        double var423;
                        var248 = (var423 = var397 - var144.squaredDistanceTo(var145)) == 0.0 ? 0 : (var423 < 0.0 ? -1 : 1);
                     }

                     int var353 = var22;
                     int var352 = var248;
                     int var250 = var352;
                     int var249 = var352;
                     if (var353 == 0) {
                        int var354 = var249;
                        if (var354 > 0) {
                           return;
                        }

                        BlockPos var147 = this.n;
                        Vec3d var149 = var147.toCenterPos();
                        BlockPos var148 = var23;
                        double var398 = var148.getSquaredDistance((Position)var149);
                        MinecraftClient var150 = b;
                        ClientPlayerEntity var414 = var150.player;
                        BlockPos var151 = this.n;
                        Vec3d var153 = var151.toCenterPos();
                        ClientPlayerEntity var152 = var414;
                        double var424;
                        var250 = (var424 = var398 - var152.squaredDistanceTo(var153)) == 0.0 ? 0 : (var424 < 0.0 ? -1 : 1);
                     }

                     BlockPos var258;
                     label311: {
                        int var356 = var22;
                        int var355 = var250;
                        int var253 = var355;
                        int var251 = var355;
                        if (var356 == 0) {
                           int var357 = var251;
                           if (var357 > 0) {
                              return;
                           }

                           int var359 = var22;
                           BlockPos var358 = var371;
                           BlockPos var256 = var358;
                           BlockPos var252 = var358;
                           if (var359 != 0) {
                              BlockPos var367 = var256;
                              var258 = var367;
                              break label311;
                           }

                           Object[] var155 = new Object[]{var252, Blocks.FIRE, 90720632922225L};
                           byte var360 = ((byte)((BlockUtil.bReturningBoolean(var155)) ? 1 : 0));
                           var253 = var360;
                        }

                        int var361 = var253;
                        label162:
                        if (var361 == 0) {
                           int var363 = var22;
                           BlockPos var362 = var371;
                           BlockPos var257 = var362;
                           BlockPos var254 = var362;
                           if (var363 == 0) {
                              BlockPos var364 = var254;
                              BlockPos var255 = var364;
                              Object[] var158 = new Object[]{82650215142853L};
                              Object[] var159 = new Object[]{var255, BlockUtil.aReturningBlock(var158), 90720632922225L};
                              boolean var365 = BlockUtil.bReturningBoolean(var159);
                              if (var365) {
                                 break label162;
                              }

                              var257 = var371;
                           }

                           BlockHitResult var162 = var25;
                           Direction var163 = var162.getSide();
                           int var415 = var163.getOffsetX();
                           BlockHitResult var164 = var25;
                           Direction var165 = var164.getSide();
                           int var10002 = var165.getOffsetY();
                           BlockHitResult var166 = var25;
                           Direction var167 = var166.getSide();
                           int var171 = var167.getOffsetZ();
                           int var170 = var10002;
                           int var169 = var415;
                           BlockPos var168 = var257;
                           var258 = var168.add(var169, var170, var171);
                           break label311;
                        }

                        BlockPos var366 = var371;
                        var258 = var366;
                     }

                     BlockPos var27 = var258;
                     MinecraftClient var172 = b;
                     BlockPos var174 = var27;
                     ClientWorld var173 = var172.world;
                     BlockState var28 = var173.getBlockState(var174);
                     MinecraftClient var175 = b;
                     ClientWorld var399 = var175.world;
                     Block var176 = var24;
                     BlockState var179 = var176.getDefaultState();
                     BlockPos var178 = var27;
                     ClientWorld var177 = var399;
                     var177.setBlockState(var178, var179);
                     ExplosionDamageUtil var400 = Prestige.f;
                     MinecraftClient var180 = b;
                     BlockPos var181 = var23;
                     Object[] var183 = new Object[]{var180.player, var181.toCenterPos(), 103347657692085L};
                     ExplosionDamageUtil var182 = var400;
                     double var29 = var182.kReturningVoid(var183);
                     MinecraftClient var184 = b;
                     BlockState var187 = var28;
                     BlockPos var186 = var27;
                     ClientWorld var185 = var184.world;
                     var185.setBlockState(var186, var187);
                     FloatSetting var188 = this.e;
                     Float var189 = (Float)var188.aReturningObject();
                     double var425;
                     var387 = (var425 = var29 - var189.floatValue()) == 0.0 ? 0 : (var425 < 0.0 ? -1 : 1);
                     int var369 = var22;
                     int var368 = var387;
                     int var259 = var368;
                     if (var369 == 0) {
                        int var370 = var259;
                        if (var370 > 0) {
                           return;
                        }

                        HashMap var402 = this.l;
                        Integer var417 = 1;
                        BiFunction var195 = invokeBinding7();
                        Integer var194 = var417;
                        BlockPos var193 = var23;
                        HashMap var192 = var402;
                        var192.merge(var193, var194, var195);
                        Runnable var416 = invokeBinding8(var25);
                        ModeSetting var196 = this.h;
                        String var418 = (String)var196.aReturningObject();
                        String var198 = "Silent";
                        String var197 = var418;
                        boolean var419 = var197.equals(var198);
                        Object[] var10005 = new Object[]{null, null, null, 94496437480799L};
                        var10005[2] = var419;
                        var10005[1] = var416;
                        var10005[0] = var24;
                        Object[] var199 = var10005;
                        boolean var260 = InventoryUtil.kReturningBoolean(var199);
                     }

                     return;
                  }

                  return;
               }

               var214 = this;
            }

            var214.n = null;
         }
      }
   }

   @EventListener
   public void a(PacketSendEvent var1) {
      long var10001 = 82800659555512L ^ 62144128064247L;
      var10001 = 82800659555512L ^ 120653470698680L;
      var10001 = 82800659555512L ^ 28364182062281L;
      var10001 = 82800659555512L ^ 433914425725L;
      int var10000 = Event.cReturningInt();
      Object[] var18 = new Object[0];
      PacketSendEvent var17 = var1;
      Packet var14 = var17.aReturningVoid(var18);
      int var12 = var10000;
      boolean var255 = var14 instanceof PlayerInteractBlockC2SPacket;
      int var170 = var12;
      boolean var169 = var255;
      boolean var144 = var169;
      boolean var111 = var169;
      if (var170 != 0) {
         Object var143;
         label125: {
            boolean var171 = var111;
            if (var171) {
               PlayerInteractBlockC2SPacket var13 = (PlayerInteractBlockC2SPacket)var14;
               PlayerInteractBlockC2SPacket var20 = var13;
               Hand var256 = var20.getHand();
               Hand var22 = Hand.MAIN_HAND;
               Hand var21 = var256;
               boolean var172 = var21.equals(var22);
               ItemStack var112;
               if (var172) {
                  MinecraftClient var23 = b;
                  ClientPlayerEntity var24 = var23.player;
                  ItemStack var173 = var24.getMainHandStack();
                  var112 = var173;
               } else {
                  MinecraftClient var26 = b;
                  ClientPlayerEntity var27 = var26.player;
                  var112 = var27.getOffHandStack();
               }

               ItemStack var250 = var112;
               ItemStack var28 = var250;
               Item var257 = var28.getItem();
               int var175 = var12;
               Item var174 = var257;
               var143 = var174;
               Item var113 = var174;
               if (var175 == 0) {
                  break label125;
               }

               Item var177 = Items.RESPAWN_ANCHOR;
               Item var176 = var113;
               if (var176 == var177) {
                  BlockHitResult var15;
                  BlockPos var16;
                  ArrayList var120;
                  BlockPos var121;
                  label134: {
                     PlayerInteractBlockC2SPacket var30 = var13;
                     var15 = var30.getBlockHitResult();
                     BlockHitResult var31 = var15;
                     BlockPos var258 = var31.getBlockPos();
                     BlockHitResult var32 = var15;
                     Direction var33 = var32.getSide();
                     int var270 = var33.getOffsetX();
                     BlockHitResult var34 = var15;
                     Direction var35 = var34.getSide();
                     int var10002 = var35.getOffsetY();
                     BlockHitResult var36 = var15;
                     Direction var37 = var36.getSide();
                     int var41 = var37.getOffsetZ();
                     int var40 = var10002;
                     int var39 = var270;
                     BlockPos var38 = var258;
                     var16 = var38.add(var39, var40, var41);
                     BooleanSetting var42 = this.d;
                     Boolean var43 = (Boolean)var42.aReturningObject();
                     var255 = var43;
                     int var179 = var12;
                     boolean var178 = var255;
                     boolean var119 = var178;
                     boolean var114 = var178;
                     if (var179 != 0) {
                        boolean var180 = var114;
                        if (!var180) {
                           return;
                        }

                        int var183 = var12;
                        BlockPos var182 = var16;
                        ArrayList var181 = this.p;
                        var120 = var181;
                        var121 = var182;
                        ArrayList var115 = var181;
                        BlockPos var116 = var182;
                        if (var183 == 0) {
                           break label134;
                        }

                        BlockPos var185 = var116;
                        ArrayList var184 = var115;
                        ArrayList var117 = var184;
                        BlockPos var118 = var185;
                        BlockPos var47 = var118;
                        ArrayList var46 = var117;
                        boolean var186 = var46.contains(var47);
                        var119 = var186;
                     }

                     boolean var187 = var119;
                     if (var187) {
                        return;
                     }

                     ArrayList var260 = this.p;
                     BlockHitResult var49 = var15;
                     var121 = var49.getBlockPos();
                     var120 = var260;
                  }

                  ArrayList var141;
                  BlockPos var142;
                  label113: {
                     ArrayList var137;
                     label112: {
                        int var190 = var12;
                        BlockPos var189 = var121;
                        ArrayList var188 = var120;
                        ArrayList var138 = var188;
                        BlockPos var139 = var189;
                        ArrayList var122 = var188;
                        BlockPos var123 = var189;
                        if (var190 != 0) {
                           Object[] var50 = new Object[]{var123, Blocks.RESPAWN_ANCHOR, 90720632922225L};
                           boolean var192 = BlockUtil.bReturningBoolean(var50);
                           ArrayList var191 = var122;
                           var137 = var191;
                           ArrayList var124 = var191;
                           if (var192) {
                              break label112;
                           }

                           ArrayList var193 = var124;
                           ArrayList var125 = var193;
                           BlockHitResult var52 = var15;
                           BlockPos var271 = var52.getBlockPos();
                           int var196 = var12;
                           BlockPos var195 = var271;
                           ArrayList var194 = var125;
                           var138 = var194;
                           var139 = var195;
                           ArrayList var126 = var194;
                           BlockPos var127 = var195;
                           if (var196 != 0) {
                              BlockPos var198 = var127;
                              ArrayList var197 = var126;
                              ArrayList var128 = var197;
                              BlockPos var129 = var198;
                              Object[] var54 = new Object[]{var129, Blocks.FIRE, 90720632922225L};
                              boolean var200 = BlockUtil.bReturningBoolean(var54);
                              ArrayList var199 = var128;
                              var137 = var199;
                              ArrayList var130 = var199;
                              if (var200) {
                                 break label112;
                              }

                              ArrayList var201 = var130;
                              ArrayList var131 = var201;
                              BlockHitResult var56 = var15;
                              BlockPos var272 = var56.getBlockPos();
                              int var204 = var12;
                              BlockPos var203 = var272;
                              ArrayList var202 = var131;
                              var138 = var202;
                              var139 = var203;
                              ArrayList var132 = var202;
                              BlockPos var133 = var203;
                              if (var204 != 0) {
                                 BlockPos var206 = var133;
                                 ArrayList var205 = var132;
                                 ArrayList var134 = var205;
                                 BlockPos var135 = var206;
                                 Object[] var58 = new Object[]{82650215142853L};
                                 Object[] var59 = new Object[]{var135, BlockUtil.aReturningBlock(var58), 90720632922225L};
                                 boolean var208 = BlockUtil.bReturningBoolean(var59);
                                 ArrayList var207 = var134;
                                 ArrayList var140 = var207;
                                 ArrayList var136 = var207;
                                 if (!var208) {
                                    var142 = var16;
                                    var141 = var140;
                                    break label113;
                                 }

                                 ArrayList var209 = var136;
                                 var137 = var209;
                                 break label112;
                              }
                           }
                        }

                        BlockPos var213 = var139;
                        ArrayList var212 = var138;
                        var141 = var212;
                        var142 = var213;
                        break label113;
                     }

                     BlockHitResult var61 = var15;
                     BlockPos var211 = var61.getBlockPos();
                     ArrayList var210 = var137;
                     var141 = var210;
                     var142 = var211;
                  }

                  BlockPos var64 = var142;
                  ArrayList var63 = var141;
                  var63.add(var64);
               }
            }

            ModeSetting var65 = this.a;
            var143 = var65.aReturningObject();
         }

         String var261 = (String)var143;
         String var67 = "Legit";
         String var66 = var261;
         var144 = var66.equalsIgnoreCase(var67);
      }

      boolean var214 = var144;
      if (var214) {
         Object[] var69 = new Object[0];
         PacketSendEvent var68 = var1;
         var14 = var68.aReturningVoid(var69);
         int var216 = var12;
         Packet var215 = var14;
         Packet var146 = var215;
         Packet var145 = var215;
         if (var216 != 0) {
            boolean var217 = var145 instanceof PlayerInteractBlockC2SPacket;
            if (!var217) {
               return;
            }

            Packet var218 = var14;
            var146 = var218;
         }

         PlayerInteractBlockC2SPacket var249 = (PlayerInteractBlockC2SPacket)var146;
         PlayerInteractBlockC2SPacket var72 = var249;
         Hand var262 = var72.getHand();
         Hand var74 = Hand.MAIN_HAND;
         Hand var73 = var262;
         boolean var219 = var73.equals(var74);
         ItemStack var147;
         if (var219) {
            MinecraftClient var75 = b;
            ClientPlayerEntity var76 = var75.player;
            ItemStack var220 = var76.getMainHandStack();
            var147 = var220;
         } else {
            MinecraftClient var78 = b;
            ClientPlayerEntity var79 = var78.player;
            var147 = var79.getOffHandStack();
         }

         ItemStack var252 = var147;
         ItemStack var80 = var252;
         Item var263 = var80.getItem();
         Item var222 = Items.RESPAWN_ANCHOR;
         Item var221 = var263;
         if (var221 == var222) {
            SafeAnchor var167;
            BlockPos var168;
            label80: {
               SafeAnchor var163;
               BlockHitResult var253;
               label79: {
                  PlayerInteractBlockC2SPacket var81 = var249;
                  var253 = var81.getBlockHitResult();
                  BlockHitResult var82 = var253;
                  BlockPos var264 = var82.getBlockPos();
                  BlockHitResult var83 = var253;
                  Direction var84 = var83.getSide();
                  int var273 = var84.getOffsetX();
                  BlockHitResult var85 = var253;
                  Direction var86 = var85.getSide();
                  int var277 = var86.getOffsetY();
                  BlockHitResult var87 = var253;
                  Direction var88 = var87.getSide();
                  int var92 = var88.getOffsetZ();
                  int var91 = var277;
                  int var90 = var273;
                  BlockPos var89 = var264;
                  BlockPos var254 = var89.add(var90, var91, var92);
                  BlockHitResult var93 = var253;
                  BlockPos var274 = var93.getBlockPos();
                  int var225 = var12;
                  BlockPos var224 = var274;
                  SafeAnchor var223 = this;
                  SafeAnchor var164 = var223;
                  BlockPos var165 = var224;
                  SafeAnchor var148 = var223;
                  BlockPos var149 = var224;
                  if (var225 != 0) {
                     Object[] var94 = new Object[]{var149, Blocks.RESPAWN_ANCHOR, 90720632922225L};
                     boolean var227 = BlockUtil.bReturningBoolean(var94);
                     SafeAnchor var226 = var148;
                     var163 = var226;
                     SafeAnchor var150 = var226;
                     if (var227) {
                        break label79;
                     }

                     SafeAnchor var228 = var150;
                     SafeAnchor var151 = var228;
                     BlockHitResult var96 = var253;
                     BlockPos var275 = var96.getBlockPos();
                     int var231 = var12;
                     BlockPos var230 = var275;
                     SafeAnchor var229 = var151;
                     var164 = var229;
                     var165 = var230;
                     SafeAnchor var152 = var229;
                     BlockPos var153 = var230;
                     if (var231 != 0) {
                        BlockPos var233 = var153;
                        SafeAnchor var232 = var152;
                        SafeAnchor var154 = var232;
                        BlockPos var155 = var233;
                        Object[] var98 = new Object[]{var155, Blocks.FIRE, 90720632922225L};
                        boolean var235 = BlockUtil.bReturningBoolean(var98);
                        SafeAnchor var234 = var154;
                        var163 = var234;
                        SafeAnchor var156 = var234;
                        if (var235) {
                           break label79;
                        }

                        SafeAnchor var236 = var156;
                        SafeAnchor var157 = var236;
                        BlockHitResult var100 = var253;
                        BlockPos var276 = var100.getBlockPos();
                        int var239 = var12;
                        BlockPos var238 = var276;
                        SafeAnchor var237 = var157;
                        var164 = var237;
                        var165 = var238;
                        SafeAnchor var158 = var237;
                        BlockPos var159 = var238;
                        if (var239 != 0) {
                           BlockPos var241 = var159;
                           SafeAnchor var240 = var158;
                           SafeAnchor var160 = var240;
                           BlockPos var161 = var241;
                           Object[] var102 = new Object[]{82650215142853L};
                           Object[] var103 = new Object[]{var161, BlockUtil.aReturningBlock(var102), 90720632922225L};
                           boolean var243 = BlockUtil.bReturningBoolean(var103);
                           SafeAnchor var242 = var160;
                           SafeAnchor var166 = var242;
                           SafeAnchor var162 = var242;
                           if (!var243) {
                              var168 = var254;
                              var167 = var166;
                              break label80;
                           }

                           SafeAnchor var244 = var162;
                           var163 = var244;
                           break label79;
                        }
                     }
                  }

                  BlockPos var248 = var165;
                  SafeAnchor var247 = var164;
                  var167 = var247;
                  var168 = var248;
                  break label80;
               }

               BlockHitResult var105 = var253;
               BlockPos var246 = var105.getBlockPos();
               SafeAnchor var245 = var163;
               var167 = var245;
               var168 = var246;
            }

            var167.n = var168;
            ElapsedTimer var265 = this.q;
            Object[] var108 = new Object[]{42835128969216L};
            ElapsedTimer var107 = var265;
            var107.aReturningVoid(var108);
            MinMaxSetting var266 = this.g;
            Object[] var110 = new Object[]{127318019014223L};
            MinMaxSetting var109 = var266;
            var109.bReturningVoid(var110);
         }
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      HashMap var8 = this.l;
      var8.clear();
      HashMap var9 = this.m;
      var9.clear();
      ArrayList var10 = this.o;
      var10.clear();
      this.n = null;
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 75092756173221L;
      long var6 = var2 ^ 65762800970131L;
      long var8 = var2 ^ 8240362383072L;
      long var10 = var2 ^ 116005641930047L;
      long var12 = var2 ^ 4547998816304L;
      long var14 = var2 ^ 59641449638428L;
      long var16 = var2 ^ 82878281429531L;
      long var18 = var2 ^ 107264693124053L;
      long var20 = var2 ^ 87666872358447L;
      long var22 = var2 ^ 29159961624672L;
      long var24 = var2 ^ 29904810088371L;
      long var26 = var2 ^ 77379818547405L;
      long var28 = var2 ^ 96421272380508L;
      long var30 = var2 ^ 87600335452073L;
      long var32 = var2 ^ 16698288195949L;
      long var34 = var2 ^ 99151219427774L;
      int var36 = Event.bReturningInt();
      RotationManager var10000 = Prestige.o;
      Object[] var57 = new Object[0];
      RotationManager var56 = var10000;
      boolean var364 = var56.fReturningBoolean(var57);
      int var265 = var36;
      boolean var264 = var364;
      boolean var215 = var264;
      boolean var214 = var264;
      if (var265 == 0) {
         boolean var266 = var214;
         if (var266) {
            return null;
         }

         ModeSetting var60 = this.a;
         String var365 = (String)var60.aReturningObject();
         short var10001 = 24060;
         long var10002 = 4583581545644887736L ^ var2;
         String var62 = "Blatant";
         String var61 = var365;
         var215 = var61.equalsIgnoreCase(var62);
      }

      boolean var267 = var215;
      if (!var267) {
         return null;
      }

      int var269 = var36;
      MinecraftClient var268 = b;
      MinecraftClient var217 = var268;
      MinecraftClient var216 = var268;
      if (var269 == 0) {
         MinecraftClient var64 = var216;
         Screen var270 = var64.currentScreen;
         if (var270 != null) {
            return null;
         }

         MinecraftClient var271 = b;
         var217 = var271;
      }

      MinecraftClient var67 = var217;
      ClientPlayerEntity var68 = var67.player;
      boolean var366 = var68.isUsingItem();
      int var273 = var36;
      boolean var272 = var366;
      boolean var219 = var272;
      boolean var218 = var272;
      if (var273 == 0) {
         boolean var274 = var218;
         if (var274) {
            return null;
         }

         ElapsedTimer var367 = this.q;
         Object[] var72 = new Object[]{this.g, var16};
         ElapsedTimer var71 = var367;
         var219 = var71.bReturningBoolean(var72);
      }

      int var276 = var36;
      boolean var275 = var219;
      boolean var221 = var275;
      boolean var220 = var275;
      if (var276 == 0) {
         boolean var277 = var220;
         if (!var277) {
            return null;
         }

         ModeSetting var75 = this.h;
         String var368 = (String)var75.aReturningObject();
         short var395 = 9704;
         long var403 = 2648586925874706086L ^ var2;
         String var77 = "None";
         String var76 = var368;
         var221 = var76.equals(var77);
      }

      boolean var225;
      int var279 = var36;
      boolean var278 = var221;
      var225 = var278;
      boolean var222 = var278;
      label264:
      if (var279 == 0) {
         boolean var280 = var222;
         if (var280) {
            ModeSetting var79 = this.i;
            String var369 = (String)var79.aReturningObject();
            short var396 = 1940;
            long var404 = 5879158157143037144L ^ var2;
            String var81 = "Glowstone";
            String var80 = var369;
            boolean var281 = var80.equals(var81);
            Item var223;
            if (var281) {
               Block var83 = Blocks.GLOWSTONE;
               Item var282 = var83.asItem();
               var223 = var282;
            } else {
               Block var85 = Blocks.OBSIDIAN;
               var223 = var85.asItem();
            }

            Object[] var86 = new Object[]{var223, var6};
            boolean var370 = InventoryUtil.lReturningBoolean(var86);
            int var284 = var36;
            boolean var283 = var370;
            var225 = var283;
            boolean var224 = var283;
            if (var284 != 0) {
               break label264;
            }

            boolean var285 = var224;
            if (!var285) {
               return null;
            }
         }

         ModeSetting var89 = this.i;
         String var371 = (String)var89.aReturningObject();
         short var397 = 1940;
         long var405 = 5879158157143037144L ^ var2;
         String var91 = "Glowstone";
         String var90 = var371;
         var225 = var90.equals(var91);
      }

      boolean var286 = var225;
      Block var226;
      if (var286) {
         Block var287 = Blocks.GLOWSTONE;
         var226 = var287;
      } else {
         var226 = Blocks.OBSIDIAN;
      }

      Block var37 = var226;
      short var372 = 5928;
      ArrayList var93 = this.o;
      var93.clear();
      long var398 = 6759362632906914780L ^ var2;
      Object[] var10004 = new Object[]{null, invokeBinding9(), var12};
      var10004[0] = 10;
      Object[] var94 = var10004;
      List var95 = BlockUtil.aReturningList(var94);
      Iterator var38 = var95.iterator();

      int var293;
      do {
         Iterator var96 = var38;
         boolean var288 = var96.hasNext();
         if (!var288) {
            break;
         }

         label252: {
            Iterator var97 = var38;
            BlockPos var39 = (BlockPos)var97.next();
            Object[] var98 = new Object[]{var24};
            Vec3d var373 = RaycastUtil.bReturningVec3d(var98);
            BlockPos var99 = var39;
            Vec3d var101 = var99.toCenterPos();
            Vec3d var100 = var373;
            double var413;
            int var374 = (var413 = var100.distanceTo(var101) - 10.0) == 0.0 ? 0 : (var413 < 0.0 ? -1 : 1);
            int var290 = var36;
            int var289 = var374;
            int var227 = var289;
            if (var290 == 0) {
               int var291 = var227;
               if (var291 > 0) {
                  break label252;
               }

               BlockPos var104 = var39;
               ArrayList var103 = this.o;
               boolean var292 = var103.add(var104);
            }

            HashMap var375 = this.m;
            Function var108 = invokeBinding10(this);
            BlockPos var107 = var39;
            HashMap var106 = var375;
            var106.computeIfAbsent(var107, var108);
         }

         var293 = var36;
      } while (var293 == 0);

      HitResult var361 = null;
      Rotation var362 = null;
      BlockPos var40 = null;
      double var41 = Double.MAX_VALUE;
      ArrayList var109 = this.o;
      Iterator var43 = var109.iterator();

      label242:
      while (true) {
         Iterator var110 = var43;
         byte var229 = ((byte)((var110.hasNext()) ? 1 : 0));

         boolean var262;
         label239:
         while (true) {
            byte var294 = var229;
            if (var294 != 0) {
               BlockPos var44;
               Object var235;
               Iterator var111 = var43;
               var44 = (BlockPos)var111.next();
               int var296 = var36;
               ArrayList var295 = this.p;
               var235 = var295;
               ArrayList var230 = var295;
               label234:
               if (var296 == 0) {
                  BlockPos var113 = var44;
                  ArrayList var112 = var230;
                  boolean var376 = var112.contains(var113);
                  int var298 = var36;
                  boolean var297 = var376;
                  var262 = var297;
                  boolean var231 = var297;
                  if (var298 != 0) {
                     break;
                  }

                  boolean var299 = var231;
                  boolean var232 = var299;
                  boolean var300 = var232;
                  if (!var300) {
                     BooleanSetting var116 = this.d;
                     Boolean var377 = (Boolean)var116.aReturningObject();
                     int var302 = var36;
                     Boolean var301 = var377;
                     var235 = var301;
                     Boolean var233 = var301;
                     if (var302 != 0) {
                        break label234;
                     }

                     Boolean var303 = var233;
                     Boolean var234 = var303;
                     Boolean var118 = var234;
                     boolean var304 = var118;
                     if (var304) {
                        continue label242;
                     }
                  }

                  BlockPos var122 = var44;
                  HashMap var121 = this.m;
                  var235 = var121.get(var122);
               }

               FloatAnimation var45 = (FloatAnimation)var235;
               int var306 = var36;
               FloatAnimation var305 = var45;
               FloatAnimation var237 = var305;
               FloatAnimation var236 = var305;
               if (var306 == 0) {
                  FloatAnimation var307 = var236;
                  if (var307 == null) {
                     continue label242;
                  }

                  var237 = var45;
               }

               Object[] var125 = new Object[]{var34};
               FloatAnimation var124 = var237;
               byte var378 = ((byte)((var124.recoveryAccess_call_aReturningBoolean(var125)) ? 1 : 0));
               int var309 = var36;
               byte var308 = var378;
               int var239 = var308;
               byte var238 = var308;
               if (var309 == 0) {
                  byte var310 = var238;
                  if (var310 == 0) {
                     continue label242;
                  }

                  ExplosionDamageUtil var379 = Prestige.f;
                  MinecraftClient var127 = b;
                  BlockPos var128 = var44;
                  Object[] var130 = new Object[]{var127.player, var128.toCenterPos(), var18};
                  ExplosionDamageUtil var129 = var379;
                  double var380 = var129.kReturningVoid(var130);
                  FloatSetting var131 = this.c;
                  Float var132 = (Float)var131.aReturningObject();
                  double var414;
                  var239 = (var414 = var380 - var132.floatValue()) == 0.0 ? 0 : (var414 < 0.0 ? -1 : 1);
               }

               int var312 = var36;
               int var311 = var239;
               int var241 = var311;
               int var240 = var311;
               if (var312 == 0) {
                  int var313 = var240;
                  if (var313 < 0) {
                     continue label242;
                  }

                  HashMap var381 = this.l;
                  Integer var137 = 0;
                  BlockPos var136 = var44;
                  HashMap var135 = var381;
                  Integer var138 = ((java.lang.Integer)(Object)(var135.getOrDefault(var136, var137)));
                  var241 = var138;
               }

               int var315 = var36;
               int var314 = var241;
               int var243 = var314;
               int var242 = var314;
               if (var315 == 0) {
                  IntSetting var139 = this.j;
                  Integer var140 = (Integer)var139.aReturningObject();
                  int var317 = var140;
                  int var316 = var242;
                  if (var316 >= var317) {
                     continue label242;
                  }

                  short var382 = 31651;
                  var398 = 292768479052912470L ^ var2;
                  var243 = -5;
               }

               int var46 = var243;

               int var353;
               label225:
               do {
                  int var244 = var46;

                  label222:
                  while (true) {
                     byte var319 = 5;
                     int var318 = var244;
                     if (var318 > var319) {
                        break label225;
                     }

                     short var383 = 10805;
                     var398 = 4274646480291104451L ^ var2;
                     int var321 = var36;
                     byte var320 = -5;
                     var229 = var320;
                     byte var245 = var320;
                     if (var321 != 0) {
                        continue label239;
                     }

                     int var47 = var245;

                     while (true) {
                        byte var323 = 5;
                        int var322 = var47;
                        if (var322 > var323) {
                           break label222;
                        }

                        Object[] var143 = new Object[]{var24};
                        Vec3d var384 = RaycastUtil.bReturningVec3d(var143);
                        BlockPos var144 = var44;
                        Vec3d var146 = var144.toCenterPos();
                        Vec3d var145 = var384;
                        double var385 = var145.distanceTo(var146);
                        Object[] var147 = new Object[]{var28};
                        double var415;
                        int var386 = (var415 = var385 - ItemUseUtil.bReturningFloat(var147)) == 0.0 ? 0 : (var415 < 0.0 ? -1 : 1);
                        int var325 = var36;
                        int var324 = var386;
                        var244 = var324;
                        int var246 = var324;
                        if (var325 != 0) {
                           break;
                        }

                        label217: {
                           int var326 = var246;
                           if (var326 <= 0) {
                              // int var151 = var47;
                              int var149 = var46;
                              BlockPos var148 = var44;
                              BlockPos var48 = var148.add(var149, -1, var151);
                              int var327 = var36;
                              if (var327 != 0) {
                                 break label217;
                              }

                              Object[] var152 = new Object[]{var48, var8};
                              boolean var328 = BlockUtil.eReturningBoolean(var152);
                              label214:
                              if (var328) {
                                 BlockPos var154 = var48;
                                 BlockPos var387 = var154.up();
                                 int var330 = var36;
                                 BlockPos var329 = var387;
                                 BlockPos var249 = var329;
                                 BlockPos var247 = var329;
                                 if (var330 == 0) {
                                    BlockPos var331 = var247;
                                    BlockPos var248 = var331;
                                    Object[] var156 = new Object[]{var248, var32};
                                    boolean var332 = BlockUtil.gReturningBoolean(var156);
                                    if (var332) {
                                       break label214;
                                    }

                                    boolean var407 = false;
                                    int var161 = var47;
                                    int var159 = var46;
                                    BlockPos var158 = var44;
                                    BlockPos var333 = var158.add(var159, 0, var161);
                                    var249 = var333;
                                 }

                                 BlockPos var49 = var249;
                                 ExplosionDamageUtil var388 = Prestige.f;
                                 MinecraftClient var163 = b;
                                 ClientPlayerEntity var401 = var163.player;
                                 BlockPos var164 = var44;
                                 Vec3d var408 = var164.toCenterPos();
                                 Block var165 = var37;
                                 Object[] var167 = new Object[]{var401, var408, var49, var165.getDefaultState(), var30};
                                 ExplosionDamageUtil var166 = var388;
                                 double var50 = var166.lReturningVoid(var167);
                                 FloatSetting var168 = this.e;
                                 Float var169 = (Float)var168.aReturningObject();
                                 double var416;
                                 int var334 = (var416 = var50 - var169.floatValue()) == 0.0 ? 0 : (var416 < 0.0 ? -1 : 1);
                                 if (var334 <= 0) {
                                    Object[] var171 = new Object[]{var48, var4};
                                    Vec3d var52 = InteractionUtil.bReturningVec3d(var171);
                                    Vec3d var335 = var52;
                                    if (var335 != null) {
                                       var10000 = Prestige.o;
                                       Object[] var174 = new Object[]{var52, var26};
                                       RotationManager var173 = var10000;
                                       Rotation var53 = var173.aReturningdx_C0210(var174);
                                       Object[] var176 = new Object[0];
                                       Rotation var175 = var53;
                                       float var390 = var175.aReturningFloat(var176);
                                       MinecraftClient var177 = b;
                                       ClientPlayerEntity var178 = var177.player;
                                       float var179 = var390 - var178.getYaw();
                                       float var54 = MathHelper.wrapDegrees(var179);
                                       int var336 = var36;
                                       if (var336 != 0) {
                                          break label217;
                                       }

                                       FloatSetting var180 = this.k;
                                       Float var181 = (Float)var180.aReturningObject();
                                       float var417;
                                       int var337 = (var417 = var54 - var181) == 0.0F ? 0 : (var417 < 0.0F ? -1 : 1);
                                       if (var337 <= 0) {
                                          FloatSetting var183 = this.k;
                                          Float var184 = (Float)var183.aReturningObject();
                                          float var418;
                                          int var338 = (var418 = var54 - -var184) == 0.0F ? 0 : (var418 < 0.0F ? -1 : 1);
                                          label204:
                                          if (var338 >= 0) {
                                             Object[] var187 = new Object[]{var53, var14};
                                             HitResult var55 = RotationUtil.aReturningHitResult(var187);
                                             int var340 = var36;
                                             HitResult var339 = var55;
                                             HitResult var251 = var339;
                                             HitResult var250 = var339;
                                             if (var340 == 0) {
                                                HitResult var188 = var250;
                                                Vec3d var391 = var188.getPos();
                                                Vec3d var190 = var52;
                                                Vec3d var189 = var391;
                                                double var419;
                                                int var341 = (var419 = var189.distanceTo(var190) - 0.5) == 0.0 ? 0 : (var419 < 0.0 ? -1 : 1);
                                                if (var341 > 0) {
                                                   break label204;
                                                }

                                                var251 = var361;
                                             }

                                             double var258;
                                             label197: {
                                                int var343 = var36;
                                                HitResult var342 = var251;
                                                HitResult var257 = var342;
                                                HitResult var252 = var342;
                                                if (var343 == 0) {
                                                   HitResult var344 = var252;
                                                   if (var344 != null) {
                                                      int var347 = var36;
                                                      double var345 = var50;
                                                      var258 = var345;
                                                      double var253 = var345;
                                                      if (var347 != 0) {
                                                         break label197;
                                                      }

                                                      double var348 = var253;
                                                      double var255 = var348;
                                                      double var420;
                                                      int var350 = (var420 = var255 - var41) == 0.0 ? 0 : (var420 < 0.0 ? -1 : 1);
                                                      if (var350 >= 0) {
                                                         break label204;
                                                      }
                                                   }

                                                   HitResult var351 = var55;
                                                   var257 = var351;
                                                }

                                                var361 = var257;
                                                var258 = var50;
                                             }

                                             var41 = var258;
                                             var362 = var53;
                                             var40 = var44;
                                          }
                                       }
                                    }
                                 }
                              }
                           }

                           var47++;
                        }

                        int var352 = var36;
                        if (var352 != 0) {
                           break label222;
                        }
                     }
                  }

                  var46++;
                  var353 = var36;
               } while (var353 == 0);

               int var354 = var36;
               if (var354 == 0) {
                  continue label242;
               }
            }

            HitResult var355 = var361;
            if (var355 == null) {
               return null;
            }

            int var357 = var36;
            Rotation var356 = var362;
            Rotation var263 = var356;
            Rotation var260 = var356;
            if (var357 != 0) {
               return var263;
            }

            Rotation var358 = var260;
            Rotation var261 = var358;
            Object[] var199 = new Object[0];
            Rotation var198 = var261;
            boolean var359 = var198.aReturningBoolean(var199);
            var262 = var359;
            break;
         }

         boolean var360 = var262;
         if (!var360) {
            HitResult var363 = var361;
            Runnable var402 = invokeBinding11(var363);
            ModeSetting var201 = this.h;
            String var409 = (String)var201.aReturningObject();
            short var10003 = 28637;
            long var412 = 5270159905625881756L ^ var2;
            String var203 = "Silent";
            String var202 = var409;
            boolean var410 = var202.equals(var203);
            Object[] var10005 = new Object[]{null, null, null, var10};
            var10005[2] = var410;
            var10005[1] = var402;
            var10005[0] = var37;
            Object[] var204 = var10005;
            InventoryUtil.kReturningBoolean(var204);
            HashMap var392 = this.l;
            Integer var411 = 1;
            BiFunction var209 = invokeBinding12();
            Integer var208 = var411;
            BlockPos var207 = var40;
            HashMap var206 = var392;
            var206.merge(var207, var208, var209);
            ElapsedTimer var393 = this.q;
            Object[] var211 = new Object[]{var22};
            ElapsedTimer var210 = var393;
            var210.aReturningVoid(var211);
            MinMaxSetting var394 = this.g;
            Object[] var213 = new Object[]{var20};
            MinMaxSetting var212 = var394;
            var212.bReturningVoid(var213);
            return var362;
         }

         Rotation var421 = var362;
         return var421;
      }
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.cReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var25 = var4;
      Packet var24 = var6;
      Packet var21 = var24;
      Packet var20 = var24;
      if (var25 != 0) {
         boolean var26 = var20 instanceof BlockUpdateS2CPacket;
         if (!var26) {
            return;
         }

         Packet var27 = var6;
         var21 = var27;
      }

      BlockUpdateS2CPacket var5 = (BlockUpdateS2CPacket)var21;
      BlockUpdateS2CPacket var11 = var5;
      BlockState var34 = var11.getState();
      int var29 = var4;
      BlockState var28 = var34;
      BlockState var23 = var28;
      BlockState var22 = var28;
      if (var29 != 0) {
         BlockState var30 = var22;
         if (var30 == null) {
            return;
         }

         BlockUpdateS2CPacket var13 = var5;
         BlockState var31 = var13.getState();
         var23 = var31;
      }

      BlockState var15 = var23;
      Block var35 = var15.getBlock();
      Block var33 = Blocks.RESPAWN_ANCHOR;
      Block var32 = var35;
      if (var32 != var33) {
         ArrayList var36 = this.p;
         BlockUpdateS2CPacket var17 = var5;
         BlockPos var19 = var17.getPos();
         ArrayList var18 = var36;
         var18.remove(var19);
      }
   }

   private static void lambda$calculate$9(HitResult var0) {
      long var10001 = 58711820304044L ^ 69655319625353L;
      Object[] var5 = new Object[]{(BlockHitResult)var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private FloatAnimation lambda$calculate$8(BlockPos var1) {
      long var10001 = 4731909984852L ^ 2880121293477L;
      var10001 = 4731909984852L ^ 76754388987204L;
      MinMaxSetting var10002 = this.g;
      Object[] var9 = new Object[]{7504101316849L};
      MinMaxSetting var8 = var10002;
      return new FloatAnimation(var8.fReturningFloat(var9), 72033006747408L);
   }

   private static boolean lambda$calculate$7(BlockPos var0) {
      long var10001 = 23052615320323L ^ 77471847015282L;
      Object[] var5 = new Object[]{var0, Blocks.RESPAWN_ANCHOR, 90720632922225L};
      return BlockUtil.bReturningBoolean(var5);
   }

   private static void lambda$onTick$6(BlockHitResult var0) {
      long var10001 = 53353730386827L ^ 64572409113518L;
      Object[] var5 = new Object[]{var0, 11253043183653L};
      ItemUseUtil.aReturningBoolean(var5);
   }

   private static boolean lambda$onTick$5(BlockPos var0) {
      long var10001 = 109344808275174L ^ 54908362288279L;
      int var5 = Event.cReturningInt();
      Object[] var6 = new Object[]{var0, Blocks.RESPAWN_ANCHOR, 90720632922225L};
      byte var10000 = ((byte)((BlockUtil.bReturningBoolean(var6)) ? 1 : 0));
      int var11 = var5;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 != 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private static boolean lambda$onTick$4(BlockPos var0) {
      long var10001 = 4350853869297L ^ 89573824663168L;
      int var5 = Event.bReturningInt();
      Object[] var6 = new Object[]{var0, Blocks.RESPAWN_ANCHOR, 90720632922225L};
      byte var10000 = ((byte)((BlockUtil.bReturningBoolean(var6)) ? 1 : 0));
      int var11 = var5;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private static boolean lambda$onTick$3(BlockPos var0) {
      MinecraftClient var3 = b;
      BlockPos var5 = var0;
      ClientWorld var4 = var3.world;
      BlockState var6 = var4.getBlockState(var5);
      Block var10000 = var6.getBlock();
      Block var9 = Blocks.RESPAWN_ANCHOR;
      Block var8 = var10000;
      byte var7;
      if (var8 != var9) {
         byte var10 = 1;
         var7 = var10;
      } else {
         var7 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$2(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Blatant";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(String var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Blatant";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(42793802298717L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[11];
      String var17 = "0\u0087m\u0089\u008bÖþrrÉ\u0012®&N¸!\u0010` ¥ËwxÊ\u0098ªr\u00ad\u0097Ýf\u0019Ø\u0010Øù$9\u0089\u001a[¥:È6·_rØ\u0094\u0010\nô\u008c\u0088ü\u001b\u0082\u0093e¦¹\u001chÁ4\u0084\u0010ìcZ\n6ö<Ë\u0017J\u0083zþ\u0084ú±\u0010\u0088H\u0000\u0013\u009dî=iÍß\u0090¯,\u0015¾0 À|×Cw\u0094\rdU#ë/¤ÊÂk«Æq\u0080D\u007fã¸U6H\u001b\u001b]\u0015¾\u0010ÑèB×\u0096\u0092]\u0000$à\u0087t\u008fÁ\u0002\u001c \u0087È\u001dÃõ¥\u000b/\u0094\u008f\u0083o¥Ð\u009d\u0099Y1~³àà!\b\u0015Ü}á}î\u001aæ";
      int var19 = "0\u0087m\u0089\u008bÖþrrÉ\u0012®&N¸!\u0010` ¥ËwxÊ\u0098ªr\u00ad\u0097Ýf\u0019Ø\u0010Øù$9\u0089\u001a[¥:È6·_rØ\u0094\u0010\nô\u008c\u0088ü\u001b\u0082\u0093e¦¹\u001chÁ4\u0084\u0010ìcZ\n6ö<Ë\u0017J\u0083zþ\u0084ú±\u0010\u0088H\u0000\u0013\u009dî=iÍß\u0090¯,\u0015¾0 À|×Cw\u0094\rdU#ë/¤ÊÂk«Æq\u0080D\u007fã¸U6H\u001b\u001b]\u0015¾\u0010ÑèB×\u0096\u0092]\u0000$à\u0087t\u008fÁ\u0002\u001c \u0087È\u001dÃõ¥\u000b/\u0094\u008f\u0083o¥Ð\u009d\u0099Y1~³àà!\b\u0015Ü}á}î\u001aæ"
         .length();
      char var16 = 16;
      int var23 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var24.getBytes("ISO-8859-1"));
            String var33 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var23 += var16) >= var19) {
                     s = var20;
                     t = new String[11];
                     x = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(42793802298717L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     String var4 = "#É¬Ô\u009aÀ\u000eT\u0002\u0086Gâ\u0097lÕ\u008aî\u0088à\u0096Ö\u009dÐ¼";
                     int var5 = "#É¬Ô\u009aÀ\u000eT\u0002\u0086Gâ\u0097lÕ\u008aî\u0088à\u0096Ö\u009dÐ¼".length();
                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var10001] = var10004;
                     } while (var2 < var5);

                     v = var6;
                     w = new Integer[3];
                     break;
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label45;
                  }

                  var17 = ") N\u008fu%ó6\u001aç\u0097¹ÊqÚ>c³\u0082×\u0086¹\bAõZ²íË§o¤\u0010þ¾A\u00adþ;º¬+þÇð\u009b\u0097lq";
                  var19 = ") N\u008fu%ó6\u001aç\u0097¹ÊqÚ>c³\u0082×\u0086¹\bAõZ²íË§o¤\u0010þ¾A\u00adþ;º¬+þÇð\u009b\u0097lq".length();
                  var16 = ' ';
                  var23 = -1;
            }

            var24 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15140;
      if (t[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])u.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               u.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fk", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = s[var5].getBytes("ISO-8859-1");
         t[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return t[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fk_C0292",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fk" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17556;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fk", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fk_C0292",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fk" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 62;
            yield var15;
         }
         case 1 -> {
            byte var16 = 11;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 49;
            yield var18;
         }
         case 4 -> {
            byte var19 = 29;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 26;
            yield var21;
         }
         case 7 -> {
            byte var22 = 31;
            yield var22;
         }
         case 8 -> {
            byte var23 = 5;
            yield var23;
         }
         case 9 -> {
            byte var24 = 9;
            yield var24;
         }
         case 10 -> {
            byte var25 = 22;
            yield var25;
         }
         case 11 -> {
            byte var26 = 27;
            yield var26;
         }
         case 12 -> {
            byte var27 = 8;
            yield var27;
         }
         case 13 -> {
            byte var28 = 39;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 50;
            yield var30;
         }
         case 16 -> {
            byte var31 = 58;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 1;
            yield var35;
         }
         case 21 -> {
            byte var36 = 42;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 3;
            yield var40;
         }
         case 26 -> {
            byte var41 = 48;
            yield var41;
         }
         case 27 -> {
            byte var42 = 56;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 60;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 2;
            yield var48;
         }
         case 34 -> {
            byte var49 = 28;
            yield var49;
         }
         case 35 -> {
            byte var50 = 19;
            yield var50;
         }
         case 36 -> {
            byte var51 = 33;
            yield var51;
         }
         case 37 -> {
            byte var52 = 35;
            yield var52;
         }
         case 38 -> {
            byte var53 = 32;
            yield var53;
         }
         case 39 -> {
            byte var54 = 53;
            yield var54;
         }
         case 40 -> {
            byte var55 = 16;
            yield var55;
         }
         case 41 -> {
            byte var56 = 55;
            yield var56;
         }
         case 42 -> {
            byte var57 = 14;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 7;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 38;
            yield var62;
         }
         case 48 -> {
            byte var63 = 0;
            yield var63;
         }
         case 49 -> {
            byte var64 = 41;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 20;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 17;
            yield var68;
         }
         case 54 -> {
            byte var69 = 43;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 13;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 25;
            yield var73;
         }
         case 59 -> {
            byte var74 = 34;
            yield var74;
         }
         case 60 -> {
            byte var75 = 51;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 45;
            yield var77;
         }
         default -> 59;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      y[0] = "/LC;O\u001b9LFa\\\f.\u0007EgP\u0018?@Rp\u001b\u000f\u0003";
      y[1] = "n`Gw;K\u001b@Lx*\u0004zNGs.^\u000e";
      y[2] = "\u001dB\r&=B\u000bB\b|.U\u001c\t\u000bz\"A\rN\u001cmiV3";
      y[3] = "f\u0005zN\u007f\u001f\u0013%qAnPr+zJj\n\u0006";
      y[4] = "F\tD\t#wP\tAS0`GBBU<tV\u0005UBwco";
      y[5] = "ZN~X%K/nuW4\u0004N`~\\0^:";
      y[6] = "8p>YHN.p;\u0003[Y9;8\u0005WM(|/\u0012\u001cZ\u0010";
      y[7] = "rA+l[I\u0007a cJ\u0006fo+hN\\\u0012";
      y[8] = float.class;
      z[8] = "java/lang/Float";
      y[9] = "I3\u001f\u0004r\u001aB<\u000eK\u000f\u0002Q;\u0007\u0002";
      y[10] = "A|$\t(hJs5FIfAx1\u001c";
      y[11] = boolean.class;
      z[11] = "java/lang/Boolean";
      y[12] = "sfhFq\u0013efm\u001cb\u0004r-n\u001an\u0010cjy\r%\u0007Q";
      y[13] = "px[!\bSnpAnuCn";
      y[14] = "y\\\u001c\u0017(\u0017y\\\u000bK$\u0018c\u0017\u000bU$\rdfZ\u000bqH";
      y[15] = "P\fNo\u0004DP\fY3\bKJGY-\b^M6\bs]\u0015";
      y[16] = "/\u001ec9\n6/\u001ete\u000695Ut{\u0006,2$%!_o";
      y[17] = "2k-tgR$k(.tE3 +(xQ\"g<?3D=";
      y[18] = "\u0012j\t'o|\u0019e\u0018h\fq\fh\u0017\u00039s\u001d{\u000b/.~";
      y[19] = "{\u000f?%%%{\u000f(y)*aD(g)?f5x:x";
      y[20] = "5\u0001\u001eK~'5\u0001\t\u0017r(/J\t\tr=(;\\V+";
      y[21] = "\u0014X(t0^\u0014X?(<Q\u000e\u0013?6<D\tbnin\u000f";
      y[22] = "?\u0010\u0015\u0002gk)\u0010\u0010Xt|>[\u0013^xh/\u001c\u0004I3\u007f\"";
      y[23] = "k\u0013\\]c<\u001e3WRrs\u007f=\\Yv)\u000b";
      y[24] = void.class;
      z[24] = "java/lang/Void";
      y[25] = "\u00193yR\u001b\u0005\u0007;c\u001dt\u0002\u00013v\u007f\\\u0003\u0007";
      y[26] = "&#gM<:0#b\u0017/-'ha\u0011#96/v\u0006h)./t\r2d\u00124t\u00102#%#";
      y[27] = "g\u0004a-W2y\f{b1&~\rZ-\t";
      y[28] = "86\"76A.6'm%V9}$k)B(:3|bP0";
      y[29] = "f\u0000p$b\n\u0013 {+sEr.p w\u001f\u0006";
      y[30] = "{\u0000~N\u0003fm\u0000{\u0014\u0010qzKx\u0012\u001cek\fo\u0005WwZ";
      y[31] = int.class;
      z[31] = "java/lang/Integer";
      y[32] = "Z^t$S\u001fL^q~@\b[\u0015rxL\u001cJReo\u0007\fR";
      y[33] = "|%\u0007\u0012\u0012\u0010\t\u0005\f\u001d\u0003_h\u000b\u0007\u0016\u0007\u0005\u001c";
      y[34] = "\u0012\\\\C&C\u0012\\K\u001f*L\b\u0017K\u0001*Y\u000ff\u001a[y\u001c";
      y[35] = "8&\u000fCv[.&\n\u0019eL9m\t\u001fiX(*\u001e\b\"I8";
      y[36] = "\u000f8/7~\nz\u0018$8oE\u001b\u0016/3k\u001fo";
      y[37] = "\u00167,'\u000bn\u00167;{\u0007a\f|;e\u0007t\u000b\rj<_1";
      y[38] = "#\r%\u001145V-.\u001e%z7#%\u0015! C";
      y[39] = "v uXx\fv b\u0004t\u0003lkb\u001at\u0016k\u001a5E\"";
      y[40] = "\u0007\u0004be6 \u0007\u0004u9:/\u001dOu'::\u001a>!\u007fm";
      y[41] = "`ga\u000f\f<~o{@n yr";
      y[42] = "Q\u0007\u00028`@O\u000f\u0018w\u0007A^\u0014\u0015-!G";
      y[43] = "Ft\n.q6M{\u001ba\u00164Xp\u001b*-";
      y[44] = "L\u0015BQYAL\u0015U\rUNV^U\u0013U[Q/\u0004L\r";
      y[45] = "i#;\u001fA7i#,CM8sh,]M-t\u0019}\u0005\u001f";
      y[46] = "]*V/I.]*AsE!GaAmE4@\u0010\u00114\u0017u";
      y[47] = "E\u007fUQAlS\u007fP\u000bR{D4S\r^oUsD\u001a\u0015\u007f\u0013";
      y[48] = "y\u0010*]\u0007?\f0!R\u0016pm>*Y\u0012*\u0019";
      y[49] = "kcX3SZ}c]i@Mj(^oLY{oIx\u0007NM";
      y[50] = "*qu0\u001d\u0000_Q~?\fO>_u4\b\u0015J";
      y[51] = "^h{V7p+HpY&?JF{R\"e>";
      y[52] = "7\u0013\u0015|t\u001a!\u0013\u0010&g\r6X\u0013 k\u0019'\u001f\u00047 \t`";
      y[53] = "\\\u000b .>\u0003)++!/LH% *+\u0016<";
      y[54] = "7\u0015`k\u00135!\u0015e1\u0000\"6^f7\f6'\u0019q G!+";
      y[55] = ">.V4\u000f6K\u000e];\u001ey*\u0000V0\u001a#^";
      y[56] = "E\u0003=yv\u001dS\u00038#e\nDH;%i\u001eU\u000f,2\"\fY";
      y[57] = "3 8c&hF\u00003l7''\u000e8g3}S";
      y[58] = double.class;
      z[58] = "java/lang/Double";
      y[59] = ",QBq%\u0006:QG+6\u0011-\u001aD-:\u0005<]S:q\u0015'";
      y[60] = "b&\u001f8gH\u0017\u0006\u00147v\u0007v\b\u001f<r]\u0002";
      y[61] = "\";J\n+j4;OP8}#pLV4i27[A\u007f~\u0003";
      y[62] = "\u0014?\u0012jc5a\u001f\u0019erz\u0000\u0011\u0012nv t";
      y[63] = "*S5\u0005M+!\\$J!(/^&\u0005\r";
      y[64] = "|d\u001ecx&jd\u001b9k1}/\u0018?g%lh\u000f(,0A";
      y[65] = "XsJTN+-SA[_dL]JP[>8";
      y[66] = "$ M\u0011\u000ehQ\u0000F\u001e\u001f'0\u000eM\u0015\u001b}D";
      y[67] = "*0q9|N_\u0010z6m\u0001>\u001eq=i[J";
      y[68] = "g\u0014Wy9\u0013\u00124\\v(\\s:W},\u0006\u0007";
      y[69] = "X\u001aG\u0004+\u0011-:L\u000b:^L4G\u0000>\u00048";
      y[70] = "Z%`iB\u0013Z%w5N\u001c@nw+N\tG\u001f%p\u0016H";
      y[71] = "\u0007c\u0017T\u0004RrC\u001c[\u0015\u001d\u0013M\u0017P\u0011Gg";
      y[72] = "_XhHfGAPr\u0007.G[Zj@'\\\u001b{wo=\\VMwF&";
      y[73] = "-r\u0000?sZXR\u000b0b\u00159\\\u0000;fOM";
      y[74] = "U$e2rkK,\u007f}:kQ&g:3p\u0011\u0003f=?jV*}";
      y[75] = "AR\u0001\u0018r\u001f4r\n\u0017cPU|\u0001\u001cg\n!";
      y[76] = "\u001f9c\t\u0003<\u00146rFk<\u001a9a";
      y[77] = "4\u0011-oH\rA1&`YB ?-k]\u0018T";
      y[78] = "Z\t\u001c\u001fhj/)\u0017\u0010y%N'\u001c\u001b}\u007f:";
      y[79] = "E\u0005AzN\t[\r[5\u0006\tA\u0007Cr\u000f\u0012\u00014E~\u0004\u0015L\u0005C~";
      y[80] = "\u0011nnS\">\u0011ny\u000f.1\u000b%y\u0011.$\fT(Nzg";
      y[81] = "ax==]sax*aQ|{3*\u007fQi|Bz*\u0006/";
      y[82] = "Wv\r\u0003o?\"V\u0006\f~pCX\r\u0007z*7";
      y[83] = "\u00022b\u00134W\u00022uO8X\u0018yuQ8M\u001f\b$\u000en\n";
      y[84] = "u\u0012\u0013zL\u0014\u00002\u0018u][a<\u0013~Y\u0001\u0015";
      y[85] = "\u0017ru!<ebR~.-*\u0003\\u%)pw";
      y[86] = "B'8\u0006w[B'/Z{TXl/D{A_\u001d}\u001f#\u000b";
      y[87] = "^!Xr\u001aF^!O.\u0016IDjO0\u0016\\C\u001b\u001edO\u001a";
      y[88] = "\b87C-{\u001e82\u0019>l\ts1\u001f2x\u00184&\byi\t";
      y[89] = "\u000e\u000b\u000fZ\u0007\u0000{+\u0004U\u0016O\u001a%\u000f^\u0012\u0015n";
      y[90] = "2W\u000bCX}2W\u001c\u001fTr(\u001c\u001c\u0001Tg/mNU\u0005&";
      y[91] = "!UkNq\u0002!U|\u0012}\r;\u001e|\f}\u0018<o.R*S";
      y[92] = "\u0010\u00036?PjDS!10m\u0018\u000292g:ARaf0j\u001d_l`\blI\n'";
      y[93] = "z.r\u001a&Ur/:jp1$)x\u0006%K#-9V\"1z.r\u001a&Ur/:j";
      y[94] = "wo\u007f\u0010w\u000b$|~L\u001a\u0000pj!Lv2'({\u0013&etrq\u001a$]r&$Q\u001a";
      y[95] = "Edf\u001c^b\u00126=\u0018,nH`8\u0016{9\u00160azVi[am\u0003K}Uv";
      y[96] = "\u000eo\u0001o_=Yn\u000b-;'\u0005m\u0005qW\u0015Q(^.\u000bB\u0002h[-V,Q{Zq;";
      y[97] = "gL`Y\u0001\\y\u0010#\u0002aI\t\u0013 C\r\u0019s\u0014$\u0002]\u001e\tE?AZ\u001a3V=_\u0004%";
      y[98] = "r\u0004;\"\u001cRt\ra  ZKF\"7L\u000f1A&v\u001c\bKF!-N\u000f*@(wL3";
      y[99] = "I\u001cn(DqQFc$ ._[m\"L\u001c\b\u001b=\u007f\u0010K\rBr}\u001d1NX1| ";
      y[100] = "vYPSN\u000esZM\r0I{YHI]3)RIXHOsXQ\u000b0\fsC\u0017\nJOi\u0000\u00167";
      y[101] = "Q\u00152\u0011o=\u0004QhS\u000f:\u0016\u0017?\ttWP\u00040\u0002w+\n\u000e(Q\u000fh\n\u0015nPu+\u0010Vom";
      y[102] = "5\"GnT90!Z0*e)*BcVc/GDq\u0015;e$YfQ~U";
      y[103] = "9/\u001c\u001fQV5h\u001b\u0019*H5/:\u001afJ6:\u0000\u0004V'g=\u001b\u000fR[=7\u0003\\*\u001865\u0012\u0018VB<-A`\u0015I><\u0005\u001cOC&o}";
      y[104] = "`\u000b0#{l=O1f2\\010&x0eK7\"9`b16;|ddKu!?eY";
      y[105] = "{\u000b/T\u0003\u0013sR}Tj\u001bxH!]\u0006),\fy\nV~{\u000b/T\u0003\u0013sR}Tj";
      y[106] = "L!3hO\u0000\u0010=2,V|\u001b:>0A+Hkkd-E\u000f;o6Q\u0019\u0013:+/";
      y[107] = ";SJ\\U{b\u0018JOOAai\u0002EU->\u0013\u0005A\u0014}9i\u0002\u0001W<2\u000fUOJ-}i";
      y[108] = ";u`wgw&~zw\u0004b^6`eh7$1d$80^0}a<6$sg\"=\u000b";
      y[109] = "%Z\u0016`\u0011@=\u0000\u001blu\u001f3\u001d\u0015j\u0019-`XL0uE;\u001eM0\u000f\u0006!]L\r";
      y[110] = "f\u0019\u0001b<1a\u0014XpfK:\u0012\u0019pe'\b@T(3Kf\u0014\u0003txw1\u0006T}?K";
      y[111] = "rj\u0011FW(&:\u0006H7/zk\u001eK`{ ?G\u001d7(\u007f6K\u0019\u000f.+c\u0000";
      y[112] = "~c'OjK.vd\u0017\u0015]!\fbCsU7p8Ik\u0006O=2WwE>m'\u0014/:";
      y[113] = "3b;dJKd&0?]$c\\e|VH6&bx\u0017\u00181\\caR\u001c7& {\u0011\u001d\n";
      y[114] = "v1cCb>zvdE\u0019 z1\u0002\u0003w)x5~Y}1+M=R\u007f o1gXgs\u0017";
      y[115] = "\u001d`WSoJ@:I\fWMynLM/\u001b\u001bk\u000b\f*&";
      y[116] = "'S%j\u00147{_\"3\u0004St\u0004xo\u0002:x=vo\u0012>\u001e\\ztWnd\u001f`7VS";
      y[117] = "\u0000A\u00171|\u0001\u001b\f\u00104\u0016\u0003jX\ne(TW\u0002U<pj\u0001STe(W[\f\r=\u0016";
      y[118] = "]^ \u0010a0\n\u00154LwT\u000ent\u0004|8X\u0014s\u0000=h_nr\u0019xlY\u00141\u0003;md";
      y[119] = "6\u0000KfYy3\u0003V8'>;\u0000S|J\u00058e\r`\u001f6'\u0001PiB+ie\u000bgX|k\u001fH}\u001b}V";
      y[120] = "9@Ay+&n\u0012\u001a}Y*4D\u001fs\u000e}j\u0013G\u001f\"\u007f6D\u001f%:%;H";
      y[121] = "@\f;\u0003*h\u0014\\,\rJoH\r4\u000e\u001d8\u0011Yo[JhMPa\\rn\u0019\u0005*";
      y[122] = "\u001e\u0015J\\HQCQK\u0019\u0001aN/JYK\r\u001bUM]\n]\u001c/NGHQKCK\u0019\b\\'";
      y[123] = "l}X\u0019p7qj\u001c\\@4y}!K0(\u00109\u0002Yxijz\u0018\u001ayT";
      y[124] = "\u001aY7ep\u001cJ\u0000>2$vFW.jy\u001at\u0003m5!I#Tmdp\u001fN\\46pv";
      y[125] = ",\u001aBW^D%P\u001fL?UO\u001b\u000bVS\u00005\u001c\u000f\u0017\u0003\u0007OF\bUG\u0001-CO\u0014B<";
      y[126] = "}^`JW1'Wi_O\u000f-&6[Ecx\\1_\u00043\u007f&wE_p~\u001ca\u001fC>D";
      y[127] = "bm\u007fcSBy-u~.Lv3psi\\\u001f3vfV\u000f}61'S2bm\u007fcSBy-u~.";
      y[128] = "\u001f\n\u0016,.&\u0007P\u001b Jy\tM\u0015&&KY\u000eM~Jb\u0001H\u001a|vc\u0000H\u0010As \u001dLE'$n\u0000]\nA";
      y[129] = "\u0010\u001c.j{\r\u0019Vsq\u001a\u0018s\u001dgkvI\t\u001ac*&Ns\u001bzo\"H\tX`,#u";
      y[130] = "\u0006V\u0014\"Q}\u000f\u001cI90oeW]#\\9\u001fPYb\f>eQ@'\b8\u001f\u0012Zd\t\u0005";
      y[131] = "\u0007'$\u001ce*\u000b`#\u001a\u001e>\u000b!*\u000e\u001ed\b=*\u001bb>\u0002%yc!5\u00004=\u001f{?\u0018gEZs6\\>=\u0005q>\u00017E\\p=\t#9\u0006z%Z[";
      y[132] = "\\q/Ut\u0001\u0019<~Y%9\u0001LvMnUY6qI/\u0005^LpPj\u0001X63J)\u0000e";
      y[133] = "]\u0010|K1%EJqGUzKW\u007fA9H\u0018\u0013#\u0019U&@Om\u0018/!M\u0016\u007fBU";
      y[134] = "Y#rO\u000ffQz OfnZ`|F\n\\\u000e-#\u001e^\u000b\u000ey'\u0019[:\n-#GV\u000b\u000e e\\VmYnxM\u0019\u000b";
      y[135] = "lI^Q;,(\u0000P\u0016oG;QOI=\u0010o\u000b\u001b\u0011hGl[DI+{;I\u0013@l";
      y[136] = "\u00006(-^\f\u000555s X\f?WvNW\u000f++,DO\\Sh,_\t])+6\u001c\b`";
      y[137] = "\u0002}]\u0007\u000fy\u000bv\u0001\u000bI\u0002^w@\u0000\u0016nl#\u0006]M<;#F\u0000M`G\u007fZ\u0001\ty;";
      y[138] = "ym<[\u0003=q4n[j5z.2R\u0006\u0007+lo\bZPi7+ZWlh6+Pj";
      y[139] = "+ns\b\u001b\u0011r%s\u001b\u0001+vT;\u0011\u001bG..<\u0015Z\u0017)T;U\u0019V\"2l\u001b\u0004GmT";
      y[140] = "z\u007f\u0004\u0018?3%z\u001bL?\n-t\u0013@\"T*t\tD^7%hDE22{(I)";
      y[141] = "\u0005u)/0q\u0005u\"`j\u001aYz:\u007f0vk.~&i&<s=g/'^vz&*\u001a";
      y[142] = "Lq\u0007\u0003\u0014\rR-DXt\u001d\".G\u0019\u0018HX)CXHO\".\u0005[\t\f\u0012sAZLE\"";
      y[143] = "\n\u0015YP@.V\tX\u0014YR^\u0016D\u0005F)3PW\nM*O\n]\u0012\u001eR\f\nFT\u001f(O\u0010\u0005U\"";
      y[144] = "tmY[t}|4\u000b[\u001duw.WRqG#j\u000f\u000b,\u0010~)OM r{n\u000eH\u001dta*O\b\u007fq&kJ5ykb*\nW|,#/7[\"~t;ZS{,tR";
      y[145] = "W\u0011w\u0001\"\u000f^[*\u001aC\u001e4\u0010>\u0000/KN\u0017:A\u007fL4@\"KrI\fFv\u001e9w";
      y[146] = "qZ7z=H}\u001d0|FRtK?\u007fFVw_m:|EuA3\u0005";
      y[147] = "\"+Z[v|$\u007f\u000f\u0010H!&3\n\r$\u0013zrTVH.2qQ\u0007&}!p\rj";
      y[148] = "(C\u0003\b!=\u007fF\u001eZJ*\u0014\u0015\u0000\u001e&|n\u0012\u0004_v{\u0014C\u001f\u001cq\u007f.P\u001d\u0002/@";
      y[149] = "\u0011z\u0012hB\u001fAoQ0=\u0014Mp\u000ftP/N\u0015Qh\u0005\u001cQq\faX\u0001\u001f\u0015WoBV\u001do\u0014u\u0001W ";
      y[150] = "'E?\u00112\u001e?\u001f2\u001dVA1\u0002<\u001b:sg@`Aj$a\u0018$L:HdFdAV";
      y[151] = "-\u001fIT(\"m_\u0012BF:*\rUW:<,`SEydf\u0003NR=!V";
      y[152] = "R>Fe\u0014\u0015I~Lxi\u0004Ixjq\r\u0018B\u0004Pc\u0011\u001d\u0012fU$P\u0018/";
      y[153] = "\u000f\u007f\u001f>@JCyB>2O\u001fa\u001a+^}K\"E|\u000e*\fx\u0003#\u000f\u0016\ry\u0003)2";
      y[154] = "\u000eU[\u001e/3\u0013B\u001f[\u001f6\u001f^\u0018! >\u0014A\u001c]z4\f\u0012d";
      y[155] = "\u000f>.\u0015O\u0011Wb(_+\t4?6VG\\N82\u0017\u0017[4=vM\u0013\u0004Ee*KY`";
      y[156] = "\u0003\u0001a^;c\u0001\u00036X^6\u0010\u0002kV2\u0004DC0\u0000eS@\u0018s\u00012?EF3\f^n\u001b\u0006;]2kEF61";
      y[157] = "\u0010aXO_$\u0010aS\u0000\u0005OLnK\u001f_#~:\u000fF\u0006r)gL\u0007@rKb\u000bFEO";
      y[158] = "*ujV7Fa)g\u0010ERZs.V)\u0004 t*\u0017y\u0003Z43T*\u0005f52T 8";
      y[159] = "6?w!|\f:ca}\u001f\u0005G?u6sP=8qw#WG{o(m\u001e'7iuml";
      y[160] = "\u0011VaSw+\u0018\u001c<H\u0016:rW(Rzo\bP,\u0013*hr\u0015/O|=\u000bUo\u0014jS";
      y[161] = "Z>#)n\u0000Zeh%5e\t\u0006*6(\t_|-2iYX\u0006m+*\n^:l**\u0000c";
      y[162] = "\u0012l\u0004\u0005p\u0017E>_\u0001\u0002\u001b\u001fhZ\u000fULA;\u0003c\u007f\u0017\u001bwL\u00033\u0011Fw";
      y[163] = "\u0000\b\nYB|WZQ]0p\r\fTSg'RQ\u000f?\\n\u000b\u0007\\\u0001I&\u000fP";
      y[164] = "bd\u000f~\u0006\u001az>\u0002rbEt#\ft\u000ew'gS\"b\u0019\u007f;\u001e-\u0018\u001erb\fwb";
      y[165] = "\f(W\u0018J\u000f[-JJ!\u001c0~T\u000eMNJyPO\u001dI0zJ\r\u0011\u001e\\\u007f\u0014M\u001cr";
      y[166] = "\u001f]\u0014Z\u001fp\u001d\f\r[/c~UMJNvD\f\u0006J]l";
      y[167] = "O\u007f\u000e0\u00100\u0012%\u0010o(6+q\u0015.PaItRoU\\";
      y[168] = "xs g\u0006Ym;$0j\u0002y\u007f'f\u00060$>\u007f8j\t+m)h\u0007\u0001r?)\u0001\u0000\u001e*8*oS\r+dG>\u000f\u0018,>=}\u0015[-\u0003";
      y[169] = ")\u00128Q?Jl_i]nrs/aI%\u001e,UfMdN+/gT!J-U$NbK\u0010";
      y[170] = "\t\u001ce(Y,\u0001E7(0$\n_k!\\\u0016^\u001b1x\fA\u0003Xs>\r#\u0006\u001f2;0";
      y[171] = "\u0006\u0014S\u0016.|\nST\u0010Un\n\u0019i\u0004)\rV\u0007H\u000b*|\u0006\u0012\u000bSU";
      y[172] = "\"O\u0005zwKs\\\u0012i\u0005\\\u0012\b\u0012`jMnR\u0018x95";
      y[173] = "o~@Vq\fq\"\u0003\r\u0011\u001b\u0001!\u0000L}I{&\u0004\r-N\u0001'\u001dH)H{d\u0007\u000b(u";
      y[174] = "k0Aou=ul\u00024\u0015)\u0005o\u0001uyx\u007fh\u00054)\u007f\u00059\u001ew.{?*\u001cipD";
      y[175] = "\r\u001aq;,pZQeg:\u0014]*%/1x\bP\"+p(\u000f*s03/\u000b\u0010`2-q4";
      y[176] = "\u001d\u001fL1|<\u0014\u0014\u0010=:GA\u0015Q6e+sA\u0017k>|$AN3m)N\u0011\u0017::}$";
      y[177] = "\u0011\u001eXI\u001au\u0019G\nIsu\u0006\\_C\b\u0018@OPH\u000bd\u001aEH\u001bs'\u001a^\u000e\u001a\td\u0000\u001d\u000f'";
      y[178] = "8x|lR[:)embAY'y5\u0003F 9%vX";
      y[179] = "\u0004\u001b\u0007AA \u0004\u001b\f\u000e\u001bKX\u0014\u0014\u0011A'j@PH\u001a{=\u001d\u0013\t^v_\u0018TH[K";
      y[180] = "\u0017\u0016H\u001cG\u0017\u000fLE\u0010#H\u0001QK\u0016OzV\u0016\u0010H\u0013-U\u0011R\f\u0013K\u0002_O\u001d\\-";
      y[181] = "#w\u00138kW\"v\u00132V\u000e0n\n0:<d*PmV\u00158k\u0005jj\u00149k\u000fWoW$oZ18\u00199~\u0015W";
      y[182] = "7!z,.B>k'7OUT 3-#\u0006.'7ls\u0001T&.)w\u0007.e4jv:";
      y[183] = "\u0010}+\u000e|c\u00055/Y\u00108\u0011q,\u000f|\nL6vP\u00103Cc\"\u0001};\u001a1\"hz$B6!\u0006)7CjL";
      y[184] = "\u0016;\u000b(?y\u0010o^c\u0001$\u0012#[~m\u0016Od\u000b(\u0001x\u00149_c=/\u0006nV$\u0001";
      y[185] = "WY-\u001b7A\u0000X'YS[\\[)\u0005?i\b\u001erZb>_\u0018'\f:SWAu\fS";
      y[186] = "AX<F8\u0014\u0014\u001cf\u0004X\u0013\u0006Z1^#?\u0010A?@55\u0016\\5:f\u0001\u001b[8P3EA\u0019X\u0005=\u0001G\u001a\"F'BF'";
      y[187] = "E^O(Z[I\u0019H.!ACGV*]GeLg=ZGB^.hOLKZR2ET\u0018\"\u00179A\u001a_IM=B\u0017N\"\u00119GE\\^K3_\u0016$";
      y[188] = "v |vLfs#a(20q#\u007f{S=mE<|T4n9fvLg\u0016zfm\nfl9|.\u000b[";
      y[189] = "\u001bM$]\nt\u001eN9\u0003t\"\u001fE2Ct&\u001cQ`\u0006N5\u001eO>9";
      y[190] = "V|,kb`]{3)_p195o3%K>1.c\"1x+u #\u000bnqin\u0019";
      y[191] = "4FW\u00116\u0001)MM\u0011U\u0017Q\u0005W\u00039A+\u0002SBiFQ\u0001I\u0000e\u0011=\u0004\u0017@h}";
      y[192] = "X\u0003\u0014nL\u0017\fS\u0003`,\u0010P\u0002\u001bc{G\tWD1,\u0017U_N1\u0014\u0011\u0001\n\u0005";
      y[193] = "g7l\u0004qj7neS%\u0000;9u\u000bxl\tm6T/8^mk\u0004/g5mk\u000f`=^";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(755075111000368L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(755075111000368L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(755075111000368L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 203;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 227;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 107;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 110;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 195;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 78;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 203;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 227;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 107;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fk_C0292",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fk" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(SafeAnchor var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fk_C0292;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fk_C0292", "lambda$new$1", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((SafeAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(SafeAnchor var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fk_C0292;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fk_C0292", "lambda$new$2", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((SafeAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(SafeAnchor var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fk_C0292;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fk_C0292", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((SafeAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$onTick$3", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding5() {
         MethodHandle var4 = bindingCache5;
         MethodHandle var3 = bindingCache5;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$onTick$4", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Predicate invokeBinding6() {
         MethodHandle var4 = bindingCache6;
         MethodHandle var3 = bindingCache6;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$onTick$5", "(Lnet/minecraft/util/math/BlockPos;)Z"),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static BiFunction invokeBinding7() {
         MethodHandle var4 = bindingCache7;
         MethodHandle var3 = bindingCache7;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/BiFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "java/lang/Integer", "sum", "(II)I"),
                  SourceSupport.methodType("(Ljava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Runnable invokeBinding8(BlockHitResult var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/BlockHitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$onTick$6", "(Lnet/minecraft/util/hit/BlockHitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((BlockHitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9() {
         MethodHandle var4 = bindingCache9;
         MethodHandle var3 = bindingCache9;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$calculate$7", "(Lnet/minecraft/util/math/BlockPos;)Z"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding10(SafeAnchor var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fk_C0292;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/fk_C0292",
                     "lambda$calculate$8",
                     "(Lnet/minecraft/util/math/BlockPos;)Ldev/zprestige/prestige/dE_C0173;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/util/math/BlockPos;)Ldev/zprestige/prestige/dE_C0173;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var2.invokeExact((SafeAnchor)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding11(HitResult var0) {
         MethodHandle var5 = bindingCache11;
         MethodHandle var4 = bindingCache11;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Lnet/minecraft/util/hit/HitResult;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fk_C0292", "lambda$calculate$9", "(Lnet/minecraft/util/hit/HitResult;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((HitResult)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static BiFunction invokeBinding12() {
         MethodHandle var4 = bindingCache12;
         MethodHandle var3 = bindingCache12;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/BiFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "java/lang/Integer", "sum", "(II)I"),
                  SourceSupport.methodType("(Ljava/lang/Integer;Ljava/lang/Integer;)Ljava/lang/Integer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
