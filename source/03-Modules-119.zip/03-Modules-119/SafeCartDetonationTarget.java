package dev.zprestige.prestige.client.modules.state;

import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.util.math.Vec3d;

public record SafeCartDetonationTarget(TntMinecartEntity aa, Vec3d ab, double ac, double ad) {
}
