package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;

public record SafeCartPlacementTarget(BlockPos x, BlockHitResult y, double z) {
}
