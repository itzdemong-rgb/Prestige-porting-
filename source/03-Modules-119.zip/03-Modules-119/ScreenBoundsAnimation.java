package dev.zprestige.prestige.client.modules.state;

public final class ScreenBoundsAnimation {
   public float a;
   public float b;
   public float c;
   public float d;
   public float e;
   public long f;
   public EntityScreenBounds g;

   public ScreenBoundsAnimation() {
   }
}
