package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

public class SelfDestruct extends Module {
   private static final long[] k;
   private static final Long[] l;
   private static final Map m = new HashMap(13);
   private static final Object[] n = new Object[43];
   private static final String[] o = new String[43];

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 97434553232679L;
      long var6 = var2 ^ 100105570071765L;
      int var10000 = Event.bReturningInt();
      dev.zprestige.prestige.client.Prestige.w = (boolean)(true);
      int var8 = var10000;
      Object var13 = null;
      MinecraftClient var12 = b;
      var12.setScreen((Screen)var13);
      ModuleManager var14 = Prestige.d;
      List var15 = var14.aReturningVoid();
      Iterator var9 = var15.iterator();

      while (true) {
         Iterator var16 = var9;
         boolean var45 = var16.hasNext();
         if (var45) {
            Iterator var17 = var9;
            Module var10 = (Module)var17.next();
            int var46 = var8;
            if (var46 != 0) {
               break;
            }

            int var48 = var8;
            Module var47 = var10;
            Module var43 = var47;
            Module var41 = var47;
            if (var48 == 0) {
               Module var49 = var41;
               Module var42 = var49;
               Module var19 = var42;
               boolean var50 = var19.aReturningBoolean();
               if (var50) {
                  Object[] var22 = new Object[]{var4};
                  Module var21 = var10;
                  var21.aReturningVoid(var22);
               }

               Object[] var25 = new Object[]{var6};
               Module var24 = var10;
               var24.cReturningVoid(var25);
               var43 = var10;
            }

            Object[] var27 = new Object[0];
            Module var26 = var43;
            BindSetting var53 = var26.bReturningBindSetting(var27);
            Integer var30 = -1;
            BindSetting var29 = var53;
            var29.aReturningVoid(var30);
            int var51 = var8;
            if (var51 == 0) {
               continue;
            }
         }

         ModuleManager var54 = Prestige.d;
         ArrayList var32 = new ArrayList();
         ModuleManager var31 = var54;
         var31.aReturningVoid(var32);

         try {
            System.gc();
            short var55 = 31403;
            System.gc();
            long var10001 = 6452703763164948165L ^ var2;
            Thread.sleep(3176017286240387361L);
            var55 = 4031;
            System.gc();
            var10001 = 4155348472905634770L ^ var2;
            Thread.sleep(3045908606595862689L);
            var55 = 18534;
            System.gc();
            var10001 = 6894987851665429513L ^ var2;
            Thread.sleep(691501497686709126L);
            System.gc();
            break;
         } catch (InterruptedException var52) {
            StackTraceElement[] var40 = new StackTraceElement[0];
            var52.setStackTrace(var40);
            throw new RuntimeException(var52);
         }
      }

      System.gc();
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   static {

      f();
      long var10000 = 25728380268000L ^ 109772522158256L;
      Cipher var2;
      Cipher var13 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(128300114974032L << var3 * 8 >>> 56);
      }

      var13.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[3];
      String var6 = "*O6ðUq\u009eÓ`\u0092úÌ\u001c¶P\u009c)]\u008bLÛ¥j\u009f";
      int var7 = "*O6ðUq\u009eÓ`\u0092úÌ\u001c¶P\u009c)]\u008bLÛ¥j\u009f".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      k = var8;
      l = new Long[3];
   
      
}

   private static InterruptedException a(InterruptedException var0) {
      return var0;
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2320;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])m.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fl", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fl_C0294",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fl" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = o[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = n[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 9;
            yield var15;
         }
         case 1 -> {
            byte var16 = 31;
            yield var16;
         }
         case 2 -> {
            byte var17 = 28;
            yield var17;
         }
         case 3 -> {
            byte var18 = 11;
            yield var18;
         }
         case 4 -> {
            byte var19 = 29;
            yield var19;
         }
         case 5 -> {
            byte var20 = 58;
            yield var20;
         }
         case 6 -> {
            byte var21 = 16;
            yield var21;
         }
         case 7 -> {
            byte var22 = 37;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 24;
            yield var25;
         }
         case 11 -> {
            byte var26 = 50;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 33;
            yield var30;
         }
         case 16 -> {
            byte var31 = 57;
            yield var31;
         }
         case 17 -> {
            byte var32 = 62;
            yield var32;
         }
         case 18 -> {
            byte var33 = 45;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 30;
            yield var35;
         }
         case 21 -> {
            byte var36 = 26;
            yield var36;
         }
         case 22 -> {
            byte var37 = 49;
            yield var37;
         }
         case 23 -> {
            byte var38 = 55;
            yield var38;
         }
         case 24 -> {
            byte var39 = 47;
            yield var39;
         }
         case 25 -> {
            byte var40 = 48;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 44;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 1;
            yield var47;
         }
         case 33 -> {
            byte var48 = 12;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 27;
            yield var50;
         }
         case 36 -> {
            byte var51 = 0;
            yield var51;
         }
         case 37 -> {
            byte var52 = 39;
            yield var52;
         }
         case 38 -> {
            byte var53 = 46;
            yield var53;
         }
         case 39 -> {
            byte var54 = 21;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 20;
            yield var56;
         }
         case 42 -> {
            byte var57 = 2;
            yield var57;
         }
         case 43 -> {
            byte var58 = 10;
            yield var58;
         }
         case 44 -> {
            byte var59 = 8;
            yield var59;
         }
         case 45 -> {
            byte var60 = 53;
            yield var60;
         }
         case 46 -> {
            byte var61 = 54;
            yield var61;
         }
         case 47 -> {
            byte var62 = 25;
            yield var62;
         }
         case 48 -> {
            byte var63 = 51;
            yield var63;
         }
         case 49 -> {
            byte var64 = 40;
            yield var64;
         }
         case 50 -> {
            byte var65 = 3;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 35;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 15;
            yield var69;
         }
         case 55 -> {
            byte var70 = 38;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 52;
            yield var72;
         }
         case 58 -> {
            byte var73 = 23;
            yield var73;
         }
         case 59 -> {
            byte var74 = 34;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 32;
            yield var76;
         }
         case 62 -> {
            byte var77 = 17;
            yield var77;
         }
         default -> 14;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            o[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      n[0] = "\u0015Z\u000e8o[\u001eU\u001fw\bY\u000b^\u001f<3";
      n[1] = int.class;
      o[1] = "java/lang/Integer";
      n[2] = "\f\u0015(`kD\u001a\u0015-:xS\r^.<tG\u001c\u00199+?P9";
      n[3] = "|\u0010O<\u0011\u000f\t0D3\u0000@h>O8\u0004\u001a\u001c";
      n[4] = void.class;
      o[4] = "java/lang/Void";
      n[5] = "\u0012,\u0005H\u00190g\f\u000eG\b\u007f\u0006\u0002\u0005L\f%r";
      n[6] = "h\u0015%]+)~\u0015 \u00078>i^#\u00014*x\u00194\u0016\u007f=K";
      n[7] = "ZWD\u0001*ULWA[9B[\u001cB]5VJ[UJ~D{";
      n[8] = "4`8}EM?o)2\"O*d<n\u001eQ*d*Y\u0013B;q:u\u0004O";
      n[9] = "P\u001e\t\f!(%>\u0002\u00030gX&\u0002\u000e<\u001dy3\u0000\b\u0012%n?\u0006\u0003#r";
      n[10] = "\n{z\u0010LU\u0001tk_6Q\u0012\u007fm\u0015";
      n[11] = long.class;
      o[11] = "java/lang/Long";
      n[12] = "tP\u001f^!wtP\b\u0002-xn\u001b\b\u001c-mijXA|";
      n[13] = "QfF\u00157&QfQI;)K-QW;<L\\\u0006\bm";
      n[14] = "Kw;\u0014vgU\u007f![\u0014{Rb";
      n[15] = "e8\u001d\u0011\ti{0\u0007^nhj+\n\u0004Hn";
      n[16] = "29H]K\u001096Y\u00126\u0005+,[Q";
      n[17] = "P;Q\u0012Zm%\u001bZ\u001dK\"D\u0015Q\u0016Ox0";
      n[18] = "*B\u0006\u0015e)<B\u0003Ov>+\t\u0000Iz*:N\u0017^1:\t";
      n[19] = boolean.class;
      o[19] = "java/lang/Boolean";
      n[20] = "fue2\u0014\u001dmzt}u\u0013fqp'";
      n[21] = "eZ\tzZssZ\f Idd\u0011\u000f&EpuV\u00181\u000egG";
      n[22] = "q\u000fWQ;Eg\u000fR\u000b(RpDQ\r$Fa\u0003F\u001aoVy\u0003D\u00115\u001bE\u0018D\f5\\r\u000f";
      n[23] = "8-\u0002pLE.-\u0007*_R9f\u0004,SF(!\u0013;\u0018S0";
      n[24] = "G\u0006Sr\u0010-M\u00145|D#\u0001\u0012rl-~GCY=A+\u001fC_\u0002\u0016>\u001a\u000f\bh\u001c,|";
      n[25] = "M\u0019<\u000eCW\u001dD3\n;\u0004t\u0016|J^\u0004\u0011Bx^@oN\r-\t\\\u0010N\f#Z;";
      n[26] = "pz49jR ';=\u0012\u0000Iut}w\u0001,!piijug3?c\u0003w#$w\u0012";
      n[27] = "\u0004&\u001a\u0000!{]uFR\u001ek9r\u001cUr>U'DUt\u0001";
      n[28] = "_V\u000f\u001c?\rXVB\u001b\u0000\u0012\u000fZ$\u001ci\u0002\u0001z\u0005\tk\u0004b\u0018\u0005\u00059\u000f\\YB\u0018jiXV\u0010Xg\u0016XW\u001e\u000b\u0000";
      n[29] = "1,\u007fTYy42%A%zj#pG%16!&XEyhsl?\u001fqavz@\u001fpo%\u001d";
      n[30] = ":jR)\u0017\u007f4j_-ezgzVw\tH3;\u000e/e.ea\u0007 \u0018n:{L\u0010_oe>Qo_nkm6";
      n[31] = "A3`*\u0012_\b8a$\u007f\u0006\f$p \u0003\u0000\nI`p\u0000\u0007\u001d;4$\u0019\np";
      n[32] = "!&\u0001\u0002w\u00057\"\u001fF\u001cP OA\u000bs\u0007,0A\n}TK";
      n[33] = "R\u000fK2\u0001\u0006\u0002RD6yWk\u0000\u000bv\u001cU\u000eT\u000fb\u0002>Q\u001bZ5\u001eAQ\u001aTfy";
      n[34] = "eF11dIoNr+]E\u000e\u0010u1>A6Y~00,4Q`c:S4Pn0]";
      n[35] = "j\u0003(6\u000e\u001a:^'2vKS\u000b;`F]2X9q\b\"";
      n[36] = "Kc_YV/Ak\u001cCo# 5\u001bY\f'\u0018|\u0010X\u0002J";
      n[37] = "j*\\cr\u001a>~En\u001f\u000emc_\u0003r\u0006kp\u001dssQ<v#";
      n[38] = "OP#`aSFK4q\u0018K\"A6e{\u001cR@a2}\"\u0018\\76\u007f]\u0018]9e\u0018";
      n[39] = "\u0003,wFb!T!\u007fM\u001f-m,v\u0011ux\b&~Ro";
      n[40] = "\u001f#COr\bH.KD\u000f\u0017q$HO?\u0017\u0010wJ^q";
      n[41] = "A\u001cSkg\u001b\u0015HJf\n\tB^jfz\u0015+IAb:\u0016J\u001aCsti";
      n[42] = "H\u000eVx-W\u0019\u0000\u0006*U\u0001'\\Ka)WC[K,.h\u001a\u0011Kmj\f\u001d\u0011\u0006jU";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = n[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            n[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  n[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1465140366417910L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = n[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  n[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1465140366417910L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        n[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1465140366417910L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 114;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 86;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 65;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 222;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 230;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 197;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 114;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 86;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 65;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fl_C0294",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fl" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
