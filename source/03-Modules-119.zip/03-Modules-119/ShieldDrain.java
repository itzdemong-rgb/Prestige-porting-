package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

public class ShieldDrain extends Module {
   private FloatSetting a;
   private FloatSetting c;
   private FloatSetting d;
   private BooleanSetting e;
   private BooleanSetting f;
   private BooleanSetting g;
   private IntSetting h;
   private BooleanSetting i;
   private BooleanSetting j;
   private int k;
   private static final long l = 81581950393936L;
   private static final Object[] m = new Object[88];
   private static final String[] n = new String[88];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public ShieldDrain() {
      super();
      long var10001 = 117333913784634L ^ 64285574765206L;

      this.k = -1;
      BooleanSetting var10000 = this.i;
      Object[] var6 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var5 = var10000;
      var5.aReturningBooleanSetting(var6);
      var10000 = this.j;
      Object[] var8 = new Object[]{invokeBinding2(this), 88791076916140L};
      BooleanSetting var7 = var10000;
      var7.aReturningBooleanSetting(var8);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      this.k = -1;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64554193807848L;
      Object[] var7 = new Object[]{var4};
      ShieldDrain var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 11858199343175L ^ 98356606699064L;
      var10001 = 11858199343175L ^ 98482218627361L;
      var10001 = 11858199343175L ^ 47510934929613L;
      var10001 = 11858199343175L ^ 43751855945544L;
      var10001 = 11858199343175L ^ 115904621052381L;
      var10001 = 11858199343175L ^ 82723709367601L;
      var10001 = 11858199343175L ^ 120001907460015L;
      int var18 = Event.bReturningInt();
      int var123 = var18;
      MinecraftClient var122 = b;
      MinecraftClient var94 = var122;
      MinecraftClient var93 = var122;
      if (var123 == 0) {
         MinecraftClient var22 = var93;
         ClientPlayerEntity var124 = var22.player;
         if (var124 == null) {
            return;
         }

         MinecraftClient var125 = b;
         var94 = var125;
      }

      int var127 = var18;
      MinecraftClient var126 = var94;
      MinecraftClient var96 = var126;
      MinecraftClient var95 = var126;
      if (var127 == 0) {
         MinecraftClient var25 = var95;
         ClientWorld var128 = var25.world;
         if (var128 == null) {
            return;
         }

         MinecraftClient var129 = b;
         var96 = var129;
      }

      int var131 = var18;
      MinecraftClient var130 = var96;
      MinecraftClient var98 = var130;
      MinecraftClient var97 = var130;
      if (var131 == 0) {
         MinecraftClient var28 = var97;
         Screen var132 = var28.currentScreen;
         if (var132 != null) {
            return;
         }

         MinecraftClient var133 = b;
         var98 = var133;
      }

      MinecraftClient var31 = var98;
      int var10000 = (((var31.isWindowFocused()) ? 1 : 0));
      int var135 = var18;
      byte var134 = (byte)var10000;
      byte var100 = var134;
      byte var99 = var134;
      if (var135 == 0) {
         byte var136 = var99;
         if (var136 == 0) {
            return;
         }

         MinecraftClient var33 = b;
         ClientPlayerEntity var34 = var33.player;
         var100 = ((byte)((var34.isUsingItem()) ? 1 : 0));
      }

      int var138 = var18;
      byte var137 = var100;
      byte var102 = var137;
      byte var101 = var137;
      if (var138 == 0) {
         byte var139 = var101;
         if (var139 != 0) {
            return;
         }

         BooleanSetting var36 = this.g;
         Boolean var37 = (Boolean)var36.aReturningObject();
         var102 = ((byte)(((java.lang.Boolean)(var37)).booleanValue() ? 1 : 0));
      }

      Object var108;
      label161: {
         int var107;
         int var141 = var18;
         byte var140 = var102;
         var107 = var140;
         byte var103 = var140;
         label138:
         if (var141 == 0) {
            byte var142 = var103;
            if (var142 != 0) {
               MinecraftClient var39 = b;
               ClientPlayerEntity var40 = var39.player;
               var10000 = (((var40.isOnGround()) ? 1 : 0));
               int var144 = var18;
               byte var143 = ((byte)(var10000));
               var107 = var143;
               byte var104 = var143;
               if (var144 != 0) {
                  break label138;
               }

               byte var145 = var104;
               byte var105 = var145;
               byte var146 = var105;
               if (var146 != 0) {
                  Object[] var44 = new Object[]{37378893033610L};
                  ShieldDrain var43 = this;
                  var43.jReturningVoid(var44);
                  return;
               }
            }

            MinecraftClient var46 = b;
            int var148 = var18;
            ClientPlayerEntity var147 = var46.player;
            var108 = var147;
            ClientPlayerEntity var106 = var147;
            if (var148 != 0) {
               break label161;
            }

            ClientPlayerEntity var47 = var106;
            double var180 = var47.fallDistance;
            FloatSetting var48 = this.d;
            Float var49 = (Float)var48.aReturningObject();
            double var191;
            int var149 = (var191 = var180 - var49.floatValue()) == 0.0 ? 0 : (var191 < 0.0 ? -1 : 1);
            var107 = var149;
         }

         int var150 = var107;
         if (var150 < 0) {
            Object[] var52 = new Object[]{37378893033610L};
            ShieldDrain var51 = this;
            var51.jReturningVoid(var52);
            return;
         }

         Object[] var55 = new Object[]{109551026598298L};
         ShieldDrain var54 = this;
         var108 = var54.aReturningPlayerEntity(var55);
      }

      Object var19 = var108;
      int var151 = var18;
      if (var151 == 0) {
         Object var152 = var19;
         if (var152 != null) {
            MinecraftClient var60 = b;
            Object var62 = var19;
            ClientPlayerEntity var61 = var60.player;
            float var181 = var61.distanceTo((Entity)var62);
            FloatSetting var63 = this.c;
            Float var64 = (Float)var63.aReturningObject();
            float var192;
            var10000 = (var192 = var181 - var64) == 0.0F ? 0 : (var192 < 0.0F ? -1 : 1);
            int var154 = var18;
            int var153 = var10000;
            int var110 = var153;
            int var109 = var153;
            if (var154 == 0) {
               int var155 = var109;
               if (var155 > 0) {
                  Object[] var67 = new Object[]{37378893033610L};
                  ShieldDrain var66 = this;
                  var66.jReturningVoid(var67);
                  return;
               }

               MinecraftClient var69 = b;
               ClientPlayerEntity var70 = var69.player;
               Object[] var71 = new Object[]{var70.getMainHandStack(), 91643301200230L};
               var110 = (((InventoryUtil.o(var71)) ? 1 : 0));
            }

            int var157 = var18;
            int var156 = var110;
            int var121 = var156;
            int var111 = var156;
            if (var157 == 0) {
               int var158 = var111;
               if (var158 == 0) {
                  BooleanSetting var73 = this.f;
                  Boolean var74 = (Boolean)var73.aReturningObject();
                  byte var183 = ((byte)(((java.lang.Boolean)(var74)).booleanValue() ? 1 : 0));
                  int var160 = var18;
                  boolean var159 = dev.prestige.recovery.SourceSupport.asBoolean(var183);
                  boolean var114 = var159;
                  boolean var112 = var159;
                  if (var160 == 0) {
                     boolean var161 = var112;
                     boolean var113 = var161;
                     boolean var162 = var113;
                     if (var162) {
                        return;
                     }

                     BooleanSetting var77 = this.i;
                     Boolean var78 = (Boolean)var77.aReturningObject();
                     var114 = var78;
                  }

                  boolean var163 = var114;
                  if (!var163) {
                     return;
                  }

                  Object[] var79 = new Object[]{92069558810239L};
                  Integer var20 = InventoryUtil.cReturningBoxedInteger(var79);
                  int var165 = var18;
                  Integer var164 = var20;
                  Object var116 = var164;
                  Integer var115 = var164;
                  if (var165 == 0) {
                     Integer var166 = var115;
                     if (var166 == null) {
                        return;
                     }

                     BooleanSetting var81 = this.j;
                     var116 = var81.aReturningObject();
                  }

                  int var120;
                  Boolean var82 = (Boolean)var116;
                  var183 = ((byte)(((java.lang.Boolean)(var82)).booleanValue() ? 1 : 0));
                  int var168 = var18;
                  byte var167 = var183;
                  var120 = var167;
                  byte var117 = var167;
                  label116:
                  if (var168 == 0) {
                     byte var169 = var117;
                     if (var169 != 0) {
                        int var171 = var18;
                        int var170 = this.k;
                        var120 = var170;
                        int var118 = var170;
                        if (var171 != 0) {
                           break label116;
                        }

                        int var172 = var118;
                        int var119 = var172;
                        // int var173 = var119;
                        if (var173 == var174) {
                           Object[] var86 = new Object[]{49487520630543L};
                           this.k = InventoryUtil.aReturningInt(var86);
                        }
                     }

                     Integer var88 = var20;
                     var120 = var88;
                  }

                  Object[] var10003 = new Object[]{null, 72518082610550L};
                  var10003[0] = var120;
                  Object[] var89 = var10003;
                  InventoryUtil.aReturningVoid(var89);
               }

               IntSetting var90 = this.h;
               Integer var91 = (Integer)var90.aReturningObject();
               var121 = var91;
            }

            int var178 = var121;
            int var177;
            do {
               int var176 = var178;
               int var175 = var21;
               if (var175 >= var176) {
                  break;
               }

               Object[] var92 = new Object[]{var19, 114267283224552L};
               ItemUseUtil.aReturningVoid(var92);
               var21++;
               var177 = var18;
            } while (var177 == 0);

            return;
         }

         Object[] var58 = new Object[]{37378893033610L};
         ShieldDrain var57 = this;
         var57.jReturningVoid(var58);
      }
   }

   private PlayerEntity aReturningPlayerEntity(Object[] var1) {
      long var8;
      ShieldDrain var42;
      label44: {
         boolean var41;
         long var2 = (Long)var1[0];
         var2 = 81581950393936L ^ var2;
         long var4 = var2 ^ 126213407581303L;
         long var6 = var2 ^ 14539146105371L;
         var8 = var2 ^ 57957054679705L;
         int var10000 = Event.cReturningInt();
         MinecraftClient var14 = b;
         HitResult var13 = var14.crosshairTarget;
         int var10 = var10000;
         boolean var62 = var13 instanceof EntityHitResult;
         int var44 = var10;
         boolean var43 = var62;
         var41 = var43;
         boolean var35 = var43;
         label41:
         if (var44 != 0) {
            boolean var45 = var35;
            if (var45) {
               EntityHitResult var11 = (EntityHitResult)var13;
               EntityHitResult var16 = var11;
               Entity var61 = var16.getEntity();
               var62 = var61 instanceof PlayerEntity;
               int var47 = var10;
               boolean var46 = var62;
               var41 = var46;
               boolean var36 = var46;
               if (var47 == 0) {
                  break label41;
               }

               boolean var48 = var36;
               if (var48) {
                  PlayerEntity var12 = (PlayerEntity)var61;
                  Object[] var18 = new Object[]{var12, var4};
                  var62 = EntityUtil.aReturningBoolean(var18);
                  int var50 = var10;
                  boolean var49 = var62;
                  var41 = var49;
                  boolean var37 = var49;
                  if (var50 == 0) {
                     break label41;
                  }

                  boolean var51 = var37;
                  if (var51) {
                     SocialsManager var65 = Prestige.g;
                     PlayerEntity var20 = var12;
                     Text var21 = var20.getName();
                     Object[] var23 = new Object[]{var21.getString(), var6};
                     SocialsManager var22 = var65;
                     var62 = var22.aReturningBoolean(var23);
                     int var53 = var10;
                     boolean var52 = var62;
                     var41 = var52;
                     boolean var38 = var52;
                     if (var53 == 0) {
                        break label41;
                     }

                     boolean var54 = var38;
                     boolean var39 = var54;
                     boolean var55 = var39;
                     if (!var55) {
                        return var12;
                     }
                  }
               }
            }

            int var57 = var10;
            ShieldDrain var56 = this;
            var42 = var56;
            ShieldDrain var40 = var56;
            if (var57 == 0) {
               break label44;
            }

            BooleanSetting var27 = var40.e;
            Boolean var28 = (Boolean)var27.aReturningObject();
            boolean var58 = var28;
            var41 = var58;
         }

         boolean var59 = var41;
         if (var59) {
            return null;
         }

         var42 = this;
      }

      FloatSetting var31 = this.a;
      Float var32 = (Float)var31.aReturningObject();
      float var10001 = var32;
      Object[] var10004 = new Object[]{null, var8};
      var10004[0] = var10001;
      Object[] var34 = var10004;
      ShieldDrain var33 = var42;
      return var33.bReturningPlayerEntity(var34);
   }

   private PlayerEntity bReturningPlayerEntity(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 81581950393936L ^ var2;
      long var5 = var2 ^ 13532164223166L;
      long var7 = var2 ^ 127258843399890L;
      PlayerEntity var10 = null;
      int var10000 = Event.cReturningInt();
      double var11 = Double.MAX_VALUE;
      int var9 = var10000;
      MinecraftClient var18 = b;
      ClientWorld var19 = var18.world;
      List var20 = var19.getPlayers();
      Iterator var13 = var20.iterator();

      PlayerEntity var57;
      while (true) {
         Iterator var21 = var13;
         boolean var58 = var21.hasNext();
         if (var58) {
            Iterator var22 = var13;
            PlayerEntity var14 = (PlayerEntity)var22.next();
            int var60 = var9;
            PlayerEntity var59 = var14;
            var57 = var59;
            PlayerEntity var43 = var59;
            if (var60 == 0) {
               break;
            }

            PlayerEntity var23 = var43;
            int var82 = (((var23.isAlive()) ? 1 : 0));
            int var62 = var9;
            boolean var61 = dev.prestige.recovery.SourceSupport.asBoolean(var82);
            boolean var46 = var61;
            boolean var44 = var61;
            if (var62 != 0) {
               boolean var63 = var44;
               boolean var45 = var63;
               boolean var64 = var45;
               if (!var64) {
                  continue;
               }

               MinecraftClient var26 = b;
               ClientPlayerEntity var28 = var26.player;
               PlayerEntity var27 = var14;
               var46 = var27.equals(var28);
            }

            int var66 = var9;
            boolean var65 = var46;
            boolean var48 = var65;
            boolean var47 = var65;
            if (var66 != 0) {
               boolean var67 = var47;
               if (var67) {
                  continue;
               }

               SocialsManager var83 = Prestige.g;
               PlayerEntity var30 = var14;
               Text var31 = var30.getName();
               Object[] var33 = new Object[]{var31.getString(), var7};
               SocialsManager var32 = var83;
               var48 = var32.aReturningBoolean(var33);
            }

            int var69 = var9;
            boolean var68 = var48;
            boolean var50 = var68;
            boolean var49 = var68;
            if (var69 != 0) {
               boolean var70 = var49;
               if (var70) {
                  continue;
               }

               Object[] var35 = new Object[]{var14, var5};
               var50 = EntityUtil.aReturningBoolean(var35);
            }

            boolean var71 = var50;
            if (!var71) {
               continue;
            }

            label57: {
               double var55;
               label73: {
                  PlayerEntity var36 = var14;
                  double var10002 = var36.getX();
                  MinecraftClient var37 = b;
                  ClientPlayerEntity var38 = var37.player;
                  double var10003 = var38.getY();
                  PlayerEntity var39 = var14;
                  Vec3d var15 = new Vec3d(var10002, var10003, var39.getZ());
                  MinecraftClient var40 = b;
                  Vec3d var42 = var15;
                  ClientPlayerEntity var41 = var40.player;
                  double var16 = var41.squaredDistanceTo(var42);
                  double var85;
                  var82 = (var85 = var16 - var4 * var4) == 0.0 ? 0 : (var85 < 0.0 ? -1 : 1);
                  int var73 = var9;
                  int var72 = var82;
                  int var54 = var72;
                  int var51 = var72;
                  if (var73 != 0) {
                     int var74 = var51;
                     if (var74 > 0) {
                        continue;
                     }

                     int var77 = var9;
                     double var75 = var16;
                     var55 = var75;
                     double var52 = var75;
                     if (var77 == 0) {
                        break label73;
                     }

                     double var86;
                     int var78 = (var86 = var52 - var11) == 0.0 ? 0 : (var86 < 0.0 ? -1 : 1);
                     var54 = var78;
                  }

                  int var79 = var54;
                  if (var79 >= 0) {
                     break label57;
                  }

                  var55 = var16;
               }

               var11 = var55;
               var10 = var14;
            }

            int var80 = var9;
            if (var80 != 0) {
               continue;
            }
         }

         var57 = var10;
         break;
      }

      return var57;
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 81581950393936L ^ var2;
      long var4 = var2 ^ 46421516856236L;
      int var6 = Event.cReturningInt();
      int var13 = var6;
      int var12 = this.k;
      int var11 = var12;
      int var10 = var12;
      if (var13 != 0) {
         // int var14 = var10;
         if (var14 == var15) {
            return;
         }

         int var16 = this.k;
         var11 = var16;
      }

      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var11;
      Object[] var9 = var10003;
      InventoryUtil.aReturningVoid(var9);
      this.k = -1;
   }

   private boolean lambda$new$1(Boolean var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.f;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var16 = var4;
      byte var15 = var10000;
      byte var11 = var15;
      byte var10 = var15;
      if (var16 == 0) {
         byte var17 = var10;
         if (var17 != 0) {
            return false;
         }

         BooleanSetting var8 = this.i;
         Boolean var9 = (Boolean)var8.aReturningObject();
         byte var18 = ((byte)(((java.lang.Boolean)(var9)).booleanValue() ? 1 : 0));
         var11 = var18;
      }

      int var20 = var4;
      byte var19 = var11;
      byte var13 = var19;
      byte var12 = var19;
      if (var20 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var13);
      } else {
         byte var21 = var12;
         if (var21 != 0) {
            var13 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var13);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      int var4 = Event.cReturningInt();
      BooleanSetting var5 = this.f;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 != 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 22;
            yield var15;
         }
         case 1 -> {
            byte var16 = 17;
            yield var16;
         }
         case 2 -> {
            byte var17 = 48;
            yield var17;
         }
         case 3 -> {
            byte var18 = 16;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 49;
            yield var20;
         }
         case 6 -> {
            byte var21 = 30;
            yield var21;
         }
         case 7 -> {
            byte var22 = 50;
            yield var22;
         }
         case 8 -> {
            byte var23 = 9;
            yield var23;
         }
         case 9 -> {
            byte var24 = 19;
            yield var24;
         }
         case 10 -> {
            byte var25 = 61;
            yield var25;
         }
         case 11 -> {
            byte var26 = 28;
            yield var26;
         }
         case 12 -> {
            byte var27 = 53;
            yield var27;
         }
         case 13 -> {
            byte var28 = 35;
            yield var28;
         }
         case 14 -> {
            byte var29 = 26;
            yield var29;
         }
         case 15 -> {
            byte var30 = 57;
            yield var30;
         }
         case 16 -> {
            byte var31 = 43;
            yield var31;
         }
         case 17 -> {
            byte var32 = 2;
            yield var32;
         }
         case 18 -> {
            byte var33 = 52;
            yield var33;
         }
         case 19 -> {
            byte var34 = 29;
            yield var34;
         }
         case 20 -> {
            byte var35 = 5;
            yield var35;
         }
         case 21 -> {
            byte var36 = 8;
            yield var36;
         }
         case 22 -> {
            byte var37 = 51;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 12;
            yield var39;
         }
         case 25 -> {
            byte var40 = 31;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 10;
            yield var42;
         }
         case 28 -> {
            byte var43 = 40;
            yield var43;
         }
         case 29 -> {
            byte var44 = 55;
            yield var44;
         }
         case 30 -> {
            byte var45 = 13;
            yield var45;
         }
         case 31 -> {
            byte var46 = 0;
            yield var46;
         }
         case 32 -> {
            byte var47 = 54;
            yield var47;
         }
         case 33 -> {
            byte var48 = 24;
            yield var48;
         }
         case 34 -> {
            byte var49 = 59;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 62;
            yield var53;
         }
         case 39 -> {
            byte var54 = 25;
            yield var54;
         }
         case 40 -> {
            byte var55 = 27;
            yield var55;
         }
         case 41 -> {
            byte var56 = 37;
            yield var56;
         }
         case 42 -> {
            byte var57 = 60;
            yield var57;
         }
         case 43 -> {
            byte var58 = 32;
            yield var58;
         }
         case 44 -> {
            byte var59 = 21;
            yield var59;
         }
         case 45 -> {
            byte var60 = 47;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 34;
            yield var63;
         }
         case 49 -> {
            byte var64 = 23;
            yield var64;
         }
         case 50 -> {
            byte var65 = 7;
            yield var65;
         }
         case 51 -> {
            byte var66 = 42;
            yield var66;
         }
         case 52 -> {
            byte var67 = 36;
            yield var67;
         }
         case 53 -> {
            byte var68 = 39;
            yield var68;
         }
         case 54 -> {
            byte var69 = 6;
            yield var69;
         }
         case 55 -> {
            byte var70 = 33;
            yield var70;
         }
         case 56 -> {
            byte var71 = 45;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 38;
            yield var73;
         }
         case 59 -> {
            byte var74 = 44;
            yield var74;
         }
         case 60 -> {
            byte var75 = 41;
            yield var75;
         }
         case 61 -> {
            byte var76 = 18;
            yield var76;
         }
         case 62 -> {
            byte var77 = 46;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "\u001fA\fd\u0007>\tA\t>\u0014)\u001e\n\n8\u0018=\u000fM\u001d/S*3";
      m[1] = "hq-$D\n\u001dQ&+UE|_- Q\u001f\b";
      m[2] = "j\u0002\u0001cai|\u0002\u00049r~kI\u0007?~jz\u000e\u0010(5za";
      m[3] = "\tA{d\u001d\u001d|apk\fR\u001do{`\b\bi";
      m[4] = "\u0005\u0007>6g\u0014\u000e\b/y\u0000\u0016\u001b\u0003/2;";
      m[5] = "(p x#B>p%\"0U);&$<A8|13wT!";
      m[6] = "e,u8-\u001f\u0010\f~7<Pq\u0002u<8\n\u0005";
      m[7] = "\u0005AO\u0004p{\u0005AXX|t\u001f\nXF|a\u0018{\n\u001c(%";
      m[8] = "a\u001fe7\\%w\u001f`mO2`TckC&q\u0013t|\b4@";
      m[9] = int.class;
      n[9] = "java/lang/Integer";
      m[10] = "\u0003O\u001aK$:vo\u0011D5u\u0017a\u001aO1/c";
      m[11] = boolean.class;
      n[11] = "java/lang/Boolean";
      m[12] = "\u0015}RG\u0001\u0012\u0015}E\u001b\r\u001d\u000f6E\u0005\r\b\bG\u0011]Z";
      m[13] = double.class;
      n[13] = "java/lang/Double";
      m[14] = "\u0015I\u0012T\u0017\u001b\u0015I\u0005\b\u001b\u0014\u000f\u0002\u0005\u0016\u001b\u0001\bsWMCK";
      m[15] = "[]_`gt[]H<k{A\u0016H\"knFg\u0018\u007f:";
      m[16] = "pS}F[;pSj\u001aW4j\u0018j\u0004W!mi=[\u0001";
      m[17] = "HE)g\u0002J=e\"h\u0013\u0005\\k)c\u0017_(";
      m[18] = void.class;
      n[18] = "java/lang/Void";
      m[19] = "p^6\u0018s3{Q'W\u001f0uS%\u00183";
      m[20] = "\u0017\u001b\u00062\u000et\u0017\u001b\u0011n\u0002{\rP\u0011p\u0002n\n!D/[";
      m[21] = "HG0j\u0005*CH!%f'VE.NS%GV2bD(";
      m[22] = ")\fYQ\u0004\u001e?\f\\\u000b\u0017\t(G_\r\u001b\u001d9\u0000H\u001aP\r!";
      m[23] = "u\u0007m \u0016V\u0000'f/\u0007\u0019a)m$\u0003C\u0015";
      m[24] = "'>tw\u001e$1>q-\r3&ur+\u0001'72e<J0\u0005";
      m[25] = "z1JI\r?q>[\u0006l1z5_\\";
      m[26] = "5i\u007f7\u001065ihk\u001c9/\"hu\u001c,(S:+Dh";
      m[27] = float.class;
      n[27] = "java/lang/Float";
      m[28] = "\u0002Do)*#wdd&;l\u0016jo-?6b";
      m[29] = "_7<2SXT8-};XZ7>";
      m[30] = "e\u001cQ\b~n\u0010<Z\u0007o!q2Q\fk{\u0005";
      m[31] = "J9\u007fzrTT1e5\u000fDT";
      m[32] = "7\u0016\u0018kp\u000e)\u001e\u0002$\u0012\u0012.\u0003";
      m[33] = "sDQPRPsDF\f^_i\u000fF\u0012^Jn~\u0017J\f";
      m[34] = "e\u0006zp#Es\u0006\u007f*0RdM|,<Fu\nk;wVm\ni0-\u001bQ\u0011i--\\f\u0006";
      m[35] = "XN\u000e\u0016B~NN\u000bLQiY\u0005\bJ]}HB\u001f]\u0016hs";
      m[36] = "\u001cqO#z\u000eiQD,kA\b_O'o\u001b|";
      m[37] = "C19U-\u0013]9#\u001aJ\u0012L\".@l\u0014";
      m[38] = "\bl@'sV\blW{\u007fY\u0012'We\u007fL\u0015V\u0006<(\u000e";
      m[39] = "7y$\u001d\ra<v5Rpy/q<\u001b";
      m[40] = "H<\u0000`D(^<\u0005:W?Iw\u0006<[+X0\u0011+\u0010>y";
      m[41] = "\u000e\u0019OX6A{9DW'\u000e\u001a7O\\#Tn";
      m[42] = "\b^\u0017\u0018\u0005S\b^\u0000D\t\\\u0012\u0015\u0000Z\tI\u0015dQ\u0005Q";
      m[43] = "!o\t\u007f\u0004\u001d!o\u001e#\b\u0012;$\u001e=\b\u0007<UNh_B";
      m[44] = "\u001e\u001fo=1\u0006k?d2 I\n1o9$\u0013~";
      m[45] = "x\u0013\u0018MC\"*\u0014\u0015\u0003)9C\fX@W!;@K\u0004VP\u007f\u0003J\u001a\u00172;\u0010\u0019\u001b)";
      m[46] = "\u0006Y\u0019s\u001dqESSs-*8]\u0002e\u0012~^ZUkP@";
      m[47] = "\u0011#|l\u001bgYvn0#q@+cat!\u0019\u007f8\r\u0012x_>~q\u0013v[8";
      m[48] = "\u0000\"6,4BD1e-\nEQ,4-fw\u0006kop3 \r7*2s\\\f9.4\n";
      m[49] = "\u001a|{u\u0001)\u0018u\u001a-{1U&d5\u0003}FbeDD*D+`!F#%";
      m[50] = ".g\u001fm\u001eK3 \u0005ww\u001fI=\u0016l\u0018\u0017'b\u0010vG";
      m[51] = "\u0004\\NA[&Q\u001eYFk(\fKVS<\u007fR\u001b\u000f?\u0001!PVC\u0004\u000e+\u0007\u0017";
      m[52] = "es/\u0011I^9:k\u00015S\\w\"RKK$;1\u0016J:7l0\u0012\n_ q=^5";
      m[53] = "R+mYVq\u00069pOhkXS}[\u0002oX1fS\u0015267e@\u00012Kcw]\u0017\f";
      m[54] = "]{D\u001b\t\u001b\byW\u0006vEDzG\u0002\nCB\u0017E\u0010\u0019H\u0003oR\r\u0017N8";
      m[55] = "0m^#|<e/I$L94kB: \u000b`*\u001clLl0iO\"re jN]";
      m[56] = "Lz!Ht!Gz$^\f-G-~Ne!~#~^aG\u0010#dNsy\u00193gO\f";
      m[57] = "z7\u0014\u0011K\u00199=^\u0011{CD3\u000f\u0007D\u0016\"4X\t\u0006(";
      m[58] = "\u0002\u0014Py6\nJAB%\u000e\u0017_\rK\u007fb%\bM\u001b\">r\u0002\u0018UuqL\u000b\bVt\u000e";
      m[59] = "\u0019\u0007L-H\f\tZW}%\nw\u0016]([\u0012\u000fZNlZc\u001c\rOh\u001a\u0006\u000b\u0010B$%";
      m[60] = ")\u001cpIDo&Qz\u0012)vF\riBJq$\u0016aU\u0017\u001f";
      m[61] = "\\j1/>K\u0014?#s\u0006V\u0001s*)jdQ0q\u007f\u0006R\u000e1-*<T\u0014q(Nd\t\r21$bU\u0007\u007fJ";
      m[62] = "Sl[ClQ\u000eyY\u0014TR\u000flnD0N\u0004\u0010\u000eG?\fWv\t\u00101Ni";
      m[63] = "\u0003\u00115X\u000b\u0002Q\u00168\u0016a\u00128\u000euU\u001f\u0001@Bf\u0011\u001epS\u0015g\u0015^\u0015D\bjYa";
      m[64] = " k?qr47v1wI*5`,\u001d)'2s>\u007f2/%.P";
      m[65] = "I\u0013OR\u001eG\u001cQXU.IA\u0004W@y\u001e\u001fS\u000f,\u001eB[\b\u000bTV\u0017IT";
      m[66] = "\u0014ru~3\u000e\u001crvxJZ\u0000c_n0T\u000bp\u0004h&X\r!tru\\\u001c\u001f";
      m[67] = "0\u0002iS Pb\u0005d\u001dJH\u000b\u001d)^4SsQ:\u001a5\"7\u0012;\u0004t@s\u0001h\u0005J";
      m[68] = "]\fw\u0001l`\u0001E3\u0011\u0010md\bzBnu\u001cDi\u0006o\u0004Z\u001faA.b]Ho\u0003\u0010";
      m[69] = "\b7CX\\w@bQ\u0004djU.X^\bX\u0002i\u0003\u0000T\u000f\t5FA\u001ds\b;BGd";
      m[70] = "\n\u0004\u0006=H;\u001d\u0019\b;s#\u001b\u0004/<\u0003?rO\u0000/\u001e<LF\u0010,\u001fC";
      m[71] = "nYp#\u0013\u0007*J#\"-\u0000?Wr\"A2o\u0017-z-\u001c?Z~<\u0016\u0014?YxE";
      m[72] = "\u001eP@\u0016\b\u0005B\u0019\u0004\u0006t\n'TMU\n\u0010_\u0018^\u0011\u000ba\u001dUV\u0007L\u0003@@TPt";
      m[73] = "13-\u000erR<j\u007f\t\u000eE1q'\u0000bwe={Z0 9a>\u0017q\u001flc-\n\u000e";
      m[74] = "rU\u0019Ez56FJDD2#[\u001bD(\u0000s\u0017C\u001eDg'Y\u0016\\zn7Z\u0017#";
      m[75] = "a\u0010&)\u0019})E4u!`<\t=/MRlJew!cl\u0015`\"P?k\u0004aH\u0010b/\r$4\u0011l+\u000b]";
      m[76] = "O\u0015qs+\u0013\u0013\\5cW\u0010v\u0011|0)\u0006\u000e]ot(wF\u0005ra(IO\u0015q`W";
      m[77] = "`Di\u001e-\u0012$W:\u001f\u0013\u001d%Kb\u001chp<]a\u001b}\u0012'UvF\u0013@5Hf\u0007-I%Kgx";
      m[78] = "Q*V}%l\u0019\u007fD!\u001dq\f3M{qC_w\u0011#\u001d%\u001c.J%glPuL\u001c";
      m[79] = "QkoW&F\u000emu\bAA6nc\u0004?YN\"p@>(\u0006zmU>\u0016\u000fjnTA";
      m[80] = "8mQeAHm/FbqF0zIw&\u0011n)\u0010\u001b\rC-)Ju\u001aPas";
      m[81] = "@2|>OpM4'~6{Pv#%ZI\u00045|r\f\u001e\\h}%R$Zr= 6";
      m[82] = "\u0005\u001f1\"\u000f\u001eP]&%?\u0010\r\b)0hGRUr\\R@\u0006\f1._\u0019T\u000b";
      m[83] = "xrO%T3*uBk>(C~B*U}#yDvNA--A\u007f\u0002!*+\u001dd>";
      m[84] = "x4.{\u001e*<'}z -):,zL\u001f~}w$\u001fHu!2eY4t/6c ";
      m[85] = "Snh\u007f`u\t2ai\u001c}TmhlBzTwl\u0010~)Q7zzxu[z\u0001";
      m[86] = "`\u0014\u001b\u001d!|&X\u0018\u000f_)\u001bU\tQ!1c\u0019\u001a\u0015 @+A\u0007\u0000 ~\"Q\u0004\u0001_";
      m[87] = "D\u001ff\b{=\fJtTC \u0019\u0006}\u000e/\u0012JC$TCu\u001d\u0004p\u0016}|\r\u0007qi";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1761279063943038L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1761279063943038L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1761279063943038L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 111;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 233;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 72;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 201;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 116;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 111;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 233;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 72;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fm_C0296",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fm" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(ShieldDrain var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fm_C0296;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fm_C0296", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((ShieldDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(ShieldDrain var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fm_C0296;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fm_C0296", "lambda$new$1", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((ShieldDrain)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
