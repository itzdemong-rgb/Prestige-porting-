package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.ShieldEntityEvent;
import dev.zprestige.prestige.api.events.ShieldStyleEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.BiFunction;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShieldItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

public class ShieldRenderer extends Module {
   private BooleanSetting d;
   private BooleanSetting a;
   private ModeSetting c;
   private FloatSetting e;
   private FloatSetting f;
   private FloatSetting g;
   private FloatSetting h;
   private FloatSetting i;
   private FloatSetting j;
   private ColorSetting k;
   private ColorSetting l;
   private static final Map m;
   private static final Map n;
   private static final long o = 847954009950L;
   private static final long p;
   private static final Object[] q = new Object[55];
   private static final String[] r = new String[55];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   @EventListener
   public void a(ShieldStyleEvent var1) {
      ShieldRenderer var4 = this;
      var1.b = var4.aReturningBoolean();
      BooleanSetting var5 = this.d;
      Boolean var6 = (Boolean)var5.aReturningObject();
      var1.a = var6;
      FloatSetting var7 = this.e;
      Float var8 = (Float)var7.aReturningObject();
      double var10003 = var8.floatValue();
      FloatSetting var9 = this.f;
      Float var10 = (Float)var9.aReturningObject();
      double var10004 = var10.floatValue();
      FloatSetting var11 = this.g;
      Float var12 = (Float)var11.aReturningObject();
      var1.d = new Vec3d(var10003, var10004, var12.floatValue());
      FloatSetting var13 = this.h;
      Float var14 = (Float)var13.aReturningObject();
      var10003 = var14.floatValue();
      FloatSetting var15 = this.i;
      Float var16 = (Float)var15.aReturningObject();
      var10004 = var16.floatValue();
      FloatSetting var17 = this.j;
      Float var18 = (Float)var17.aReturningObject();
      var1.e = new Vec3d(var10003, var10004, var18.floatValue());
      BooleanSetting var19 = this.a;
      Boolean var20 = (Boolean)var19.aReturningObject();
      var1.c = var20;
      ModeSetting var21 = this.c;
      String var22 = (String)var21.aReturningObject();
      var1.f = var22.toString();
      ColorSetting var23 = this.k;
      var1.g = (Color)var23.aReturningObject();
      ColorSetting var24 = this.l;
      var1.h = (Color)var24.aReturningObject();
   }

   @EventListener
   public void a(TickEvent var1) {
      int var10000 = Event.bReturningInt();
      MinecraftClient var8 = b;
      ClientWorld var9 = var8.world;
      List var10 = var9.getPlayers();
      Iterator var5 = var10.iterator();
      int var4 = var10000;

      while (true) {
         Iterator var11 = var5;
         boolean var48 = var11.hasNext();
         if (var48) {
            Iterator var12 = var5;
            PlayerEntity var6 = (PlayerEntity)var12.next();
            PlayerEntity var13 = var6;
            UUID var7 = var13.getUuid();
            int var50 = var4;
            PlayerEntity var49 = var6;
            PlayerEntity var41 = var49;
            label34:
            if (var50 == 0) {
               PlayerEntity var14 = var41;
               boolean var62 = var14.isUsingItem();
               int var52 = var4;
               boolean var51 = var62;
               boolean var42 = var51;
               if (var52 != 0) {
                  break;
               }

               boolean var53 = var42;
               boolean var43 = var53;
               boolean var54 = var43;
               if (var54) {
                  PlayerEntity var17 = var6;
                  Hand var19 = var17.getActiveHand();
                  PlayerEntity var18 = var6;
                  ItemStack var20 = var18.getStackInHand(var19);
                  Item var63 = var20.getItem();
                  int var56 = var4;
                  Item var55 = var63;
                  Item var44 = var55;
                  if (var56 != 0) {
                     break label34;
                  }

                  Item var57 = var44;
                  Item var45 = var57;
                  boolean var58 = var45 instanceof ShieldItem;
                  if (var58) {
                     Map var64 = m;
                     Map var10002 = m;
                     Integer var26 = 0;
                     UUID var25 = var7;
                     Map var24 = var10002;
                     Integer var27 = ((java.lang.Integer)(Object)(var24.getOrDefault(var25, var26)));
                     int var28 = var27 + 1;
                     Integer var31 = var28;
                     UUID var30 = var7;
                     Map var29 = var64;
                     var29.put(var30, var31);
                     int var59 = var4;
                     if (var59 == 0) {
                        break label34;
                     }
                  }
               }

               UUID var34 = var7;
               Map var33 = m;
               Object var60 = var33.remove(var34);
            }

            int var61 = var4;
            if (var61 == 0) {
               continue;
            }
         }

         Map var36 = n;
         Set var65 = var36.entrySet();
         Predicate var38 = invokeBinding1();
         Set var37 = var65;
         boolean var47 = var37.removeIf(var38);
         break;
      }

      Map var66 = n;
      BiFunction var40 = invokeBinding2();
      Map var39 = var66;
      var39.replaceAll(var40);
   }

   @EventListener
   public void a(ShieldEntityEvent var1) {
      int var10000 = Event.bReturningInt();
      LivingEntity var6 = var1.a;
      int var4 = var10000;
      int var18 = var4;
      LivingEntity var17 = var6;
      LivingEntity var16 = var17;
      LivingEntity var15 = var17;
      if (var18 == 0) {
         boolean var19 = var15 instanceof PlayerEntity;
         if (!var19) {
            return;
         }

         LivingEntity var20 = var6;
         var16 = var20;
      }

      PlayerEntity var5 = (PlayerEntity)var16;
      int var21 = var4;
      if (var21 == 0) {
         Map var22 = n;
         PlayerEntity var10 = var5;
         UUID var10001 = var10.getUuid();
         int var11 = (int)p;
         Integer var14 = var11;
         UUID var13 = var10001;
         Map var12 = var22;
         var12.put(var13, var14);
      }
   }

   public static boolean aReturningBoolean(Object[] var0) {
      PlayerEntity var3 = (PlayerEntity)var0[0];
      long var1 = (Long)var0[1];
      var1 = 847954009950L ^ var1;
      int var4 = invokeBinding3(2559725716935431676L, var1);

      try {
         int var10000 = invokeBinding7(
            (Integer)invokeBinding6(
               n, invokeBinding4(var3, 2560935693447286428L, var1), invokeBinding5(0, 2560246017133140821L, var1), 2559970030716376719L, var1
            ),
            2559298961327041937L,
            var1
         );
         int var10 = var4;
         int var9 = var10000;
         int var7 = var9;
         int var5 = var9;
         if (var10 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var7);
         }

         int var11 = var5;
         if (var11 == 0) {
            return false;
         }
      } catch (MatchException var13) {
         throw invokeBinding8(var13, 2559582664813759585L, var1);
      }

      byte var15 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private static Integer lambda$onTick$1(UUID var0, Integer var1) {
      int var13;
      label15: {
         int var4 = Event.bReturningInt();
         int var15 = var4;
         Integer var14 = var1;
         Integer var12 = var14;
         Integer var11 = var14;
         if (var15 == 0) {
            Integer var5 = var11;
            int var10000 = var5;
            byte var17 = 1;
            int var16 = var10000;
            if (var16 > var17) {
               Integer var7 = var1;
               int var18 = var7 - 1;
               var13 = var18;
               break label15;
            }

            var12 = var1;
         }

         Integer var9 = var12;
         var13 = var9;
      }

      int var10 = var13;
      return var10;
   }

   private static boolean lambda$onTick$0(Entry var0) {
      int var3 = Event.cReturningInt();
      Entry var4 = var0;
      Integer var5 = (Integer)var4.getValue();
      int var10000 = var5;
      int var10 = var3;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      int var8;
      if (var10 != 0) {
         byte var12 = 1;
         int var11 = var6;
         if (var11 <= var12) {
            byte var13 = 1;
            var8 = var13;
         } else {
            var8 = 0;
         }
      } else {
         int var14 = var7;
         var8 = var14;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(86017628731201L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -3623194132539335542L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)205L,
            (byte)52663L,
            (byte)13481940L,
            (byte)3451376674L,
            (byte)883552428553L,
            (byte)226189421709750L,
            (byte)57904491957696156L,
            (byte)-3623194132539335542L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      
      m = new HashMap();
      n = new HashMap();
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = r[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 5;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 36;
            yield var17;
         }
         case 3 -> {
            byte var18 = 33;
            yield var18;
         }
         case 4 -> {
            byte var19 = 63;
            yield var19;
         }
         case 5 -> {
            byte var20 = 45;
            yield var20;
         }
         case 6 -> {
            byte var21 = 12;
            yield var21;
         }
         case 7 -> {
            byte var22 = 49;
            yield var22;
         }
         case 8 -> {
            byte var23 = 7;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 23;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 28;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 50;
            yield var30;
         }
         case 16 -> {
            byte var31 = 48;
            yield var31;
         }
         case 17 -> {
            byte var32 = 39;
            yield var32;
         }
         case 18 -> {
            byte var33 = 52;
            yield var33;
         }
         case 19 -> {
            byte var34 = 0;
            yield var34;
         }
         case 20 -> {
            byte var35 = 14;
            yield var35;
         }
         case 21 -> {
            byte var36 = 20;
            yield var36;
         }
         case 22 -> {
            byte var37 = 47;
            yield var37;
         }
         case 23 -> {
            byte var38 = 41;
            yield var38;
         }
         case 24 -> {
            byte var39 = 46;
            yield var39;
         }
         case 25 -> {
            byte var40 = 56;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 3;
            yield var42;
         }
         case 28 -> {
            byte var43 = 42;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 43;
            yield var45;
         }
         case 31 -> {
            byte var46 = 61;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 19;
            yield var50;
         }
         case 36 -> {
            byte var51 = 16;
            yield var51;
         }
         case 37 -> {
            byte var52 = 51;
            yield var52;
         }
         case 38 -> {
            byte var53 = 15;
            yield var53;
         }
         case 39 -> {
            byte var54 = 18;
            yield var54;
         }
         case 40 -> {
            byte var55 = 59;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 54;
            yield var58;
         }
         case 44 -> {
            byte var59 = 31;
            yield var59;
         }
         case 45 -> {
            byte var60 = 24;
            yield var60;
         }
         case 46 -> {
            byte var61 = 53;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 29;
            yield var64;
         }
         case 50 -> {
            byte var65 = 27;
            yield var65;
         }
         case 51 -> {
            byte var66 = 13;
            yield var66;
         }
         case 52 -> {
            byte var67 = 35;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 2;
            yield var69;
         }
         case 55 -> {
            byte var70 = 6;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 44;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 8;
            yield var75;
         }
         case 61 -> {
            byte var76 = 26;
            yield var76;
         }
         case 62 -> {
            byte var77 = 34;
            yield var77;
         }
         default -> 1;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            r[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      q[0] = "\fyZI#\u0013\fyM\u0015/\u001c\u00162M\u000b/\t\u0011C\u001fQ{M";
      q[1] = "\u007f\u001c\"*%<a\u00148e^\u001c\\9";
      q[2] = "l@EI~\u0019gOT\u0006\u0019\u001brDTM\"";
      q[3] = int.class;
      r[3] = "java/lang/Integer";
      q[4] = "F\u0013os:PP\u0013j))GGXi/%SV\u001f~8nAg";
      q[5] = "\"!\u001f\u001cod4!\u001aF|s#j\u0019@pg2-\u000eW;r(";
      q[6] = "N\u0014t\u007f\u00180E\u001be0{=P\u0016j[N?A\u0005vwY2";
      q[7] = ";+\\O2p%#F\u0000Qd!";
      q[8] = "0\u0006_M\r\u0006;\tN\u0002l\b0\u0002JX";
      q[9] = "\u001a=($\u0011T\u000452kr@\u0000x\u001b+KS\t";
      q[10] = ".\u0013\u0003M\u001ab%\u001c\u0012\u0002va+\u001e\u0010MZ";
      q[11] = boolean.class;
      r[11] = "java/lang/Boolean";
      q[12] = "\u0010$;\n?u\u0006$>P,b\u0011o=V v\u0000(*Aka%";
      q[13] = "/FmK/\u00199Fh\u0011<\u000e.\rk\u00170\u001a?J|\u0000{\r\r";
      q[14] = "*/t\u001a*]! eUB]
      q[15] = float.class;
      r[15] = "java/lang/Float";
      q[16] = "Bw\u0007_POIx\u0016\u0010-WZ\u007f\u001fY";
      q[17] = "\u0001\u000eYZ?'\u0001\u000eN\u00063(\u001bEN\u00183=\u001c4\u001bGj";
      q[18] = "U\u001cS^\u0000#K\u0014I\u0011b?L\t";
      q[19] = "\u0014no:D;\nfuu9+\n";
      q[20] = "\u00178\t\f{/\t0\u0013C3/\u0013:\u000b\u0004:4S\t\r\b13\u001e8\u000b\b";
      q[21] = "sTsk\u0000ssTd7\f|i\u001fd)\finn6rT#";
      q[22] = "F_qV1(F_f\n='\\\u0014f\u0014=2[e4Oes";
      q[23] = "=;A\u0018\n\u0002#3[Wm\u00032(V\rK\u0005";
      q[24] = "'\u001b(r;('\u001b?.7'=P?072:!omf";
      q[25] = "=\\)'NI=\\>{BF'\u0017>eBS fl;\u0015\u0018";
      q[26] = "91\u000f\\y\u0003'9\u0015\u00131\u0003=3\rT8\u0018}\u0012\u0010{\"\u00180$\u0010R9";
      q[27] = void.class;
      r[27] = "java/lang/Void";
      q[28] = "\u001f-\bTO]\u0013(\u001di[\b\u0001u\u0016\u0005iXC+Ni\u0007X@s\u000b\u0003\u000f\\A*q";
      q[29] = "UX~a\u0012KVV<d#\u001fn\r%`\u0012\u0004\u000e\byfQu";
      q[30] = "K\tP\u001dYj_\u0012H\u0004#\u007fJ\nL\u0003NDIoFF\u001de\u001f_Z\u000fE\u007f'PM\u0010]jV\u0016U\u0003\u001f\u0005";
      q[31] = "\u007f;i0\tXj9'w6R\u007f<6.Z`-qnx6Yt$gwSY|%7I";
      q[32] = "thN\u0016\rt\u007fp\u001bQ2&O0A_S>6j\u001d^_OshTOC6)4UC2";
      q[33] = "\u0018\u0007L\u0016*z\nY_@Rf\u000f\bYE.`\teLN9y\u0015\u001c\u001dPoks";
      q[34] = "#\u0007UImo \t\u0017L\\:\u0018R\u000eHm xWRN.Q";
      q[35] = "}\u001b*\u0017N]~\nz\u0019\u007fL%\u0016!\u0018\u0016@\u001c\u0018!\b\u0012&}\u0017(\u000b\u0010W;\u000f;I\u007f";
      q[36] = "6BU\u001bE\u0001f\u0003TF\u007f\u001eiBw\u0014\u001b\u0002b>\u0013\u0018\u0006N~^\u0016D\u0000\r\u000f";
      q[37] = "@\b*\n\r5\u0017Xf\u0001|1q\u0004gT\u001e3\u0001Zt\tCX";
      q[38] = "NVn&`h\u001fH84\u0006wLDyX;lEVn(e\u007f\u0018\u000b\u0005";
      q[39] = ">9Hrp\u001f5:Hs\u0013\u00033\u0007Exr\u0019;\\Sgb\u000f7<Xdb\u000eT";
      q[40] = "DH \ttXHM54`\rZ\u0010>XR]\u0017Ai4e\u001eZ\u000f5Ne\u000b\u001b\u0015YY~__O6L|\u0011\u0018p";
      q[41] = "},_RkN,2\t@\rW{5rA}K\u0012qRAsXc7JR17";
      q[42] = "n?9\tm0>~8TW0>'8\u0002\u0010 Wy \u0016f?7||\u0010%Nn?9\tm0>~8TW";
      q[43] = "\u007f\u0018\u0004G\u007f\u0007)\nZA\u0001\tx\u0015^_m;,Y\u0002\u0005?l~\u000bQ\u0002y\u0011lUBT\u0001";
      q[44] = "\u0012[\tg\u000e*\u0015\\\u0006>\u007f'I\u001dBw$'SaT`\u0004*U\u000e@{\u001c3/";
      q[45] = "a\u0000orr&f\u0007`+\u0003<1_9mnFaG:qh6?Tg,\u0003{!^<xs%2\u0003a\u0013";
      q[46] = "vF2-\"\u001bqA=tS\u0014&\u0000D6\u001f\u0016%\u0015~(/{v\u0001g.8\u000b(\u0012:sSF6\u0018a'#\u0018%E<Ln\u0006/\u001eh<0\u0015rC\u0003";
      q[47] = "F\u0014i\u0007NwH\u001a+Hr&v@t\u001b\f \u0007\u0006l\bNO";
      q[48] = "\u0004Kk[Z\u001b\u001f\u0001rZ?\u0010\u0005\u0017s[hGZJ(7U\u000f^\u0005i\\\u0003\u001d\u0000\u0003";
      q[49] = "\u0018\u0001{\\%]\u0014\u0004na1\b\u0006Ye\r\u0003[B\u00042a4\u001b\u0006Fn\u001b4\u000eG\\\u0002";
      q[50] = ",d)?!\u001b(d/d\\D!?+y\u0002C!%/\u00055P}$~n'\u001by8B";
      q[51] = "o\u0014\u001a\u0003}\u00023KP\u000fF]<\u000fu\b\"O<s\u0016\u001c\"P:\u0003H\u000f\u007f\rQ";
      q[52] = " \u001f\u000f7ak'\u0018\u0000n\u0010qp]Z?{fTAZVqeb\u001fQns6vK>4|mtK\u0006j\u007foc%";
      q[53] = "T\b\u0010J\u007f&S\u000f\u001f\u0013\u000e>\u0014N!\u0016s\"\u000bYQH`\u007fV2\u001cVj$\u0002BBE7yi\u000f\\Ol-\u0019QO\u00121F";
      q[54] = "\u0014h\u0017oV\u0012\u0018m\u0002RBG\n0\t>p\u0014OiSR\u0018L\u001b.\u0001#^T\bln";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(r[var4]);
            q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(594120868850203L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(594120868850203L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(594120868850203L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 194;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 222;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 199;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 102;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 226;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 254;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 194;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 222;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 199;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fn_C0298",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fn" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fn_C0298", "lambda$onTick$0", "(Ljava/util/Map$Entry;)Z"),
                  SourceSupport.methodType("(Ljava/util/Map$Entry;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static BiFunction invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/BiFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/fn_C0298",
                     "lambda$onTick$1",
                     "(Ljava/util/UUID;Ljava/lang/Integer;)Ljava/lang/Integer;"
                  ),
                  SourceSupport.methodType("(Ljava/util/UUID;Ljava/lang/Integer;)Ljava/lang/Integer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (BiFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static int invokeBinding3(long var0, long var2) {
         MethodHandle var8 = bindingCache3;
         MethodHandle var7 = bindingCache3;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache3 = b(MethodHandles.lookup(), "þ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static UUID invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/UUID;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (UUID)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Integer invokeBinding5(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "þ", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding6(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache6;
         MethodHandle var10 = bindingCache6;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache6 = b(
                  MethodHandles.lookup(),
                  "â",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(MethodHandles.lookup(), "â", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(
                  MethodHandles.lookup(), "þ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
