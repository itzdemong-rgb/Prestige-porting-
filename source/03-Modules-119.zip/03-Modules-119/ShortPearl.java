package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class ShortPearl extends Module implements RotationSource {
   private ModeSetting a;
   private MinMaxSetting c;
   private BooleanSetting d;
   private FloatSetting e;
   private FloatSetting f;
   private ElapsedTimer g;
   private float h;
   private int i;
   private int j;
   private static final long k = 89151336058685L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[72];
   private static final String[] p = new String[72];
   private static volatile MethodHandle bindingCache1;

   public ShortPearl() {
      super();
      long var10001 = 26403855453958L ^ 133080631277615L;

      this.g = new ElapsedTimer(106698256430889L);
      this.h = 0.0F;
      this.i = 0;
      this.j = 0;
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 86502240407608L;
      long var6 = var2 ^ 137095829889339L;
      int var8 = Event.bReturningInt();
      ModeSetting var10 = this.a;
      String var10000 = (String)var10.aReturningObject();
      int var28 = var8;
      String var27 = var10000;
      Object var26 = var27;
      String var25 = var27;
      if (var28 == 0) {
         short var10001 = 10500;
         long var10002 = 7492621079365967832L ^ var2;
         String var12 = "Silent";
         String var11 = var25;
         boolean var29 = var11.equals(var12);
         if (!var29) {
            return null;
         }

         FloatSetting var15 = this.e;
         var26 = var15.aReturningObject();
      }

      Float var16 = (Float)var26;
      float var32 = var16 - 1.0F;
      Random var17 = RandomUtil.a;
      float var9 = var32 + var17.nextFloat() * 2.0F;
      int var30 = var8;
      if (var30 == 0) {
         Item var33 = Items.ENDER_PEARL;
         Runnable var34 = invokeBinding1(var9);
         Object[] var10005 = new Object[]{null, null, null, var6};
         var10005[2] = true;
         var10005[1] = var34;
         var10005[0] = var33;
         Object[] var18 = var10005;
         boolean var31 = InventoryUtil.jReturningBoolean(var18);
         if (!var31) {
            return null;
         }

         Object[] var22 = new Object[]{var4};
         ShortPearl var21 = this;
         var21.aReturningVoid(var22);
      }

      MinecraftClient var23 = b;
      ClientPlayerEntity var24 = var23.player;
      return new Rotation(var24.getYaw(), var9);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 101256178638452L ^ 51452974343724L;
      var10001 = 101256178638452L ^ 38026659612768L;
      var10001 = 101256178638452L ^ 40683168993910L;
      var10001 = 101256178638452L ^ 11709441594866L;
      var10001 = 101256178638452L ^ 97805381257552L;
      var10001 = 101256178638452L ^ 124338172434811L;
      var10001 = 101256178638452L ^ 32864620174082L;
      var10001 = 101256178638452L ^ 122309227652345L;
      int var20 = Event.cReturningInt();
      ModeSetting var22 = this.a;
      String var10000 = (String)var22.aReturningObject();
      String var24 = "Legit";
      String var23 = var10000;
      byte var143 = ((byte)((var23.equals(var24)) ? 1 : 0));
      int var105 = var20;
      byte var104 = var143;
      byte var84 = var104;
      byte var83 = var104;
      if (var105 != 0) {
         byte var106 = var83;
         if (var106 == 0) {
            return;
         }

         ElapsedTimer var144 = this.g;
         MinMaxSetting var26 = this.c;
         Float var27 = (Float)var26.aReturningObject();
         float var159 = var27;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var159;
         Object[] var29 = var10004;
         ElapsedTimer var28 = var144;
         var84 = ((byte)((var28.aReturningBoolean(var29)) ? 1 : 0));
      }

      int var108 = var20;
      byte var107 = var84;
      int var86 = var107;
      byte var85 = var107;
      if (var108 != 0) {
         byte var109 = var85;
         if (var109 == 0) {
            return;
         }

         var86 = this.i;
      }

      int var110 = var86;
      switch (var110) {
         case 0:
            MinecraftClient var31 = b;
            ClientPlayerEntity var32 = var31.player;
            ItemStack var33 = var32.getMainHandStack();
            Item var145 = var33.getItem();
            int var112 = var20;
            Item var111 = var145;
            Item var89 = var111;
            Item var87 = var111;
            if (var112 != 0) {
               Item var113 = var87;
               Item var88 = var113;
               Item var115 = Items.ENDER_PEARL;
               Item var114 = var88;
               if (var114 == var115) {
                  Object[] var37 = new Object[]{5375647471396L};
                  ShortPearl var36 = this;
                  var36.jReturningVoid(var37);
                  return;
               }

               var89 = Items.ENDER_PEARL;
            }

            Object[] var39 = new Object[]{var89, 95321893129094L};
            Integer var21 = InventoryUtil.aReturningBoxedInteger(var39);
            int var117 = var20;
            Integer var116 = var21;
            Integer var91 = var116;
            Integer var90 = var116;
            if (var117 != 0) {
               Integer var118 = var90;
               if (var118 == null) {
                  Object[] var42 = new Object[]{126290808879192L};
                  ShortPearl var41 = this;
                  var41.aReturningVoid(var42);
                  return;
               }

               Object[] var44 = new Object[]{49487520630543L};
               this.j = InventoryUtil.aReturningInt(var44);
               var91 = var21;
            }

            Integer var45 = var91;
            int var146 = var45;
            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var146;
            Object[] var46 = var10003;
            InventoryUtil.aReturningVoid(var46);
            Object[] var48 = new Object[]{5375647471396L};
            ShortPearl var47 = this;
            var47.jReturningVoid(var48);
            int var119 = var20;
            if (var119 != 0) {
               break;
            }
         case 1:
            FloatSetting var49 = this.e;
            Float var50 = (Float)var49.aReturningObject();
            Rotation var147 = new Rotation(0.0F, var50);
            FloatSetting var51 = this.f;
            Float var52 = (Float)var51.aReturningObject();
            float var160 = var52 / 2.0F;
            Object[] var10006 = new Object[]{null, null, null, null, 133142968601602L};
            var10006[3] = 0.5F;
            var10006[2] = 0.0F;
            var10006[1] = var160;
            var10006[0] = var147;
            Object[] var53 = var10006;
            boolean var148 = RotationUtil.dReturningBoolean(var53);
            int var121 = var20;
            boolean var120 = var148;
            boolean var92 = var120;
            if (var121 != 0) {
               boolean var122 = var92;
               boolean var93 = var122;
               boolean var123 = var93;
               if (!var123) {
                  break;
               }

               Object[] var56 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
               boolean var124 = ItemUseUtil.cReturningBoolean(var56);
            }

            Object[] var59 = new Object[]{5375647471396L};
            ShortPearl var58 = this;
            var58.jReturningVoid(var59);
            int var125 = var20;
            if (var125 != 0) {
               break;
            }
         case 2:
            ShortPearl var100;
            label97: {
               Rotation var149 = new Rotation(0.0F, this.h);
               FloatSetting var60 = this.f;
               Float var61 = (Float)var60.aReturningObject();
               float var161 = var61 / 2.0F;
               Object[] var163 = new Object[]{null, null, null, null, 133142968601602L};
               var163[3] = 0.5F;
               var163[2] = 0.0F;
               var163[1] = var161;
               var163[0] = var149;
               Object[] var62 = var163;
               boolean var150 = RotationUtil.dReturningBoolean(var62);
               int var127 = var20;
               boolean var126 = var150;
               boolean var99 = var126;
               boolean var95 = var126;
               if (var127 != 0) {
                  boolean var128 = var95;
                  boolean var96 = var128;
                  boolean var129 = var96;
                  if (!var129) {
                     break;
                  }

                  int var131 = var20;
                  ShortPearl var130 = this;
                  var100 = var130;
                  ShortPearl var97 = var130;
                  if (var131 == 0) {
                     break label97;
                  }

                  ShortPearl var132 = var97;
                  ShortPearl var98 = var132;
                  BooleanSetting var66 = var98.d;
                  Boolean var67 = (Boolean)var66.aReturningObject();
                  boolean var133 = var67;
                  var99 = var133;
               }

               boolean var134 = var99;
               if (!var134) {
                  Object[] var70 = new Object[]{126290808879192L};
                  ShortPearl var69 = this;
                  var69.aReturningVoid(var70);
                  int var135 = var20;
                  if (var135 != 0) {
                     break;
                  }
               }

               ShortPearl var136 = this;
               var100 = var136;
            }

            Object[] var74 = new Object[]{5375647471396L};
            ShortPearl var73 = var100;
            var73.jReturningVoid(var74);
            int var137 = var20;
            if (var137 != 0) {
               break;
            }
         case 3:
            BooleanSetting var75 = this.d;
            Boolean var76 = (Boolean)var75.aReturningObject();
            byte var151 = ((byte)(((java.lang.Boolean)(var76)).booleanValue() ? 1 : 0));
            int var139 = var20;
            byte var138 = var151;
            int var103 = var138;
            byte var101 = var138;
            if (var139 != 0) {
               byte var140 = var101;
               byte var102 = var140;
               byte var141 = var102;
               if (var141 == 0) {
                  return;
               }

               int var142 = this.j;
               var103 = var142;
            }

            Object[] var162 = new Object[]{null, 72518082610550L};
            var162[0] = var103;
            Object[] var80 = var162;
            InventoryUtil.aReturningVoid(var80);
            Object[] var82 = new Object[]{126290808879192L};
            ShortPearl var81 = this;
            var81.aReturningVoid(var82);
      }
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 98450992130864L;
      long var6 = var2 ^ 13970279202175L;
      long var8 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var8};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
      ElapsedTimer var20 = this.g;
      Object[] var13 = new Object[]{var6};
      ElapsedTimer var12 = var20;
      var12.aReturningVoid(var13);
      MinecraftClient var14 = b;
      ClientPlayerEntity var15 = var14.player;
      this.h = var15.getPitch();
      this.i = 0;
      ElapsedTimer var21 = this.g;
      Object[] var17 = new Object[]{var6};
      ElapsedTimer var16 = var21;
      var16.aReturningVoid(var17);
      MinMaxSetting var22 = this.c;
      Object[] var19 = new Object[]{var4};
      MinMaxSetting var18 = var22;
      var18.bReturningVoid(var19);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 89151336058685L ^ var2;
      long var4 = var2 ^ 42044465784406L;
      long var6 = var2 ^ 126460490428441L;
      ElapsedTimer var10000 = this.g;
      Object[] var9 = new Object[]{var6};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      MinMaxSetting var13 = this.c;
      Object[] var11 = new Object[]{var4};
      MinMaxSetting var10 = var13;
      var10.bReturningVoid(var11);
      this.i++;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private static void lambda$calculate$3(float var0) {
      long var10001 = 34104399788415L ^ 48577426244594L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      float var10 = var0;
      ClientPlayerEntity var9 = var8.player;
      var9.setPitch(var10);
      Object[] var11 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var11);
      MinecraftClient var12 = b;
      float var14 = var5;
      ClientPlayerEntity var13 = var12.player;
      var13.setPitch(var14);
   }

   private boolean lambda$new$2(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(106616557794641L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      String var6 = "\u007f\u0098ÝZ>¢V¥D\u0097Þ)é\u0019«\u001f\u0010vÉµ_\u0080\u00915jËC³³\u0090Z¬\u008b\u0010l\u00adQÞ\u0017àöÉ\u0004\u009dÏb¡\\Å¬";
      int var8 = "\u007f\u0098ÝZ>¢V¥D\u0097Þ)é\u0019«\u001f\u0010vÉµ_\u0080\u00915jËC³³\u0090Z¬\u008b\u0010l\u00adQÞ\u0017àöÉ\u0004\u009dÏb¡\\Å¬".length();
      char var5 = 16;
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[3];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7869;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fo", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fo_C0300",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fo" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 0;
            yield var15;
         }
         case 1 -> {
            byte var16 = 2;
            yield var16;
         }
         case 2 -> {
            byte var17 = 22;
            yield var17;
         }
         case 3 -> {
            byte var18 = 49;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 13;
            yield var22;
         }
         case 8 -> {
            byte var23 = 35;
            yield var23;
         }
         case 9 -> {
            byte var24 = 29;
            yield var24;
         }
         case 10 -> {
            byte var25 = 52;
            yield var25;
         }
         case 11 -> {
            byte var26 = 4;
            yield var26;
         }
         case 12 -> {
            byte var27 = 31;
            yield var27;
         }
         case 13 -> {
            byte var28 = 21;
            yield var28;
         }
         case 14 -> {
            byte var29 = 20;
            yield var29;
         }
         case 15 -> {
            byte var30 = 58;
            yield var30;
         }
         case 16 -> {
            byte var31 = 36;
            yield var31;
         }
         case 17 -> {
            byte var32 = 25;
            yield var32;
         }
         case 18 -> {
            byte var33 = 17;
            yield var33;
         }
         case 19 -> {
            byte var34 = 32;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 40;
            yield var36;
         }
         case 22 -> {
            byte var37 = 1;
            yield var37;
         }
         case 23 -> {
            byte var38 = 23;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 26;
            yield var40;
         }
         case 26 -> {
            byte var41 = 62;
            yield var41;
         }
         case 27 -> {
            byte var42 = 18;
            yield var42;
         }
         case 28 -> {
            byte var43 = 47;
            yield var43;
         }
         case 29 -> {
            byte var44 = 9;
            yield var44;
         }
         case 30 -> {
            byte var45 = 50;
            yield var45;
         }
         case 31 -> {
            byte var46 = 28;
            yield var46;
         }
         case 32 -> {
            byte var47 = 42;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 7;
            yield var49;
         }
         case 35 -> {
            byte var50 = 45;
            yield var50;
         }
         case 36 -> {
            byte var51 = 61;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 5;
            yield var53;
         }
         case 39 -> {
            byte var54 = 27;
            yield var54;
         }
         case 40 -> {
            byte var55 = 3;
            yield var55;
         }
         case 41 -> {
            byte var56 = 12;
            yield var56;
         }
         case 42 -> {
            byte var57 = 48;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 10;
            yield var59;
         }
         case 45 -> {
            byte var60 = 16;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 46;
            yield var65;
         }
         case 51 -> {
            byte var66 = 37;
            yield var66;
         }
         case 52 -> {
            byte var67 = 63;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 15;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 60;
            yield var71;
         }
         case 57 -> {
            byte var72 = 34;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 8;
            yield var74;
         }
         case 60 -> {
            byte var75 = 38;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 56;
            yield var77;
         }
         default -> 19;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "6ag\u0000\u0017k abZ\u0004|7*a\\\bh&mvKC\u007f\u001e";
      o[1] = "\u0011.Q\u0005O_d\u000eZ\n^\u0010\u0005\u0000Q\u0001ZJq";
      o[2] = void.class;
      p[2] = "java/lang/Void";
      o[3] = ">\u000fbh=H(\u000fg2._?Dd4\"K.\u0003s#i^\u0003";
      o[4] = "Z|Z2L^/\\Q=]\u0011NRZ6YK:";
      o[5] = "fs(SZ\u001dps-\tI\ng8.\u000fE\u001ev\u007f9\u0018\u000e\t@";
      o[6] = ",%S)\r.Y\u0005X&\u001ca8\u000bS-\u0018;L";
      o[7] = boolean.class;
      p[7] = "java/lang/Boolean";
      o[8] = "U\u0014}5@U^\u001blz=MM\u001ce3";
      o[9] = "\u0001M+\u0013\f\u0007\nB:\\m\t\u0001I>\u0006";
      o[10] = "\u0011xR\u00158#dXY\u001a)l\u0005VR\u0011-6q";
      o[11] = "j\u000e@/\u0013N|\u000eEu\u0000YkEFs\fMz\u0002QdG]a";
      o[12] = "z1V$\u0014:\u000f\u0011]+\u0005un\u001fV \u0001/\u001a";
      o[13] = "\r\u0012B649\u0006\u001dSyS;\u0013\u0016S2h";
      o[14] = "/A!n`v/A62ly5\n6,ll2{dw4&";
      o[15] = "b\u0018>\u0003y(b\u0018)_u'xS)Au2\u007f\"{\u001a-s";
      o[16] = "T\u0006Mq#tT\u0006Z-/{NMZ3/nI<\u000ekx";
      o[17] = "\u001b:7fS]n\u001a<iB\u0012\u000f\u00147bFH{";
      o[18] = "\u0013=C0sN\u00182R\u007f\u001fM\u00160P03";
      o[19] = "W\u0019=wj\u0003A\u00198-y\u0014VR;+u\u0000G\u0015,<>\u0012v";
      o[20] = int.class;
      p[20] = "java/lang/Integer";
      o[21] = " |~^T\r6|{\u0004G\u001a!7x\u0002K\u000e0po\u0015\u0000\u0019\u0015";
      o[22] = "\u001eg:=\u001eokG12\u000f \nI:9\u000bz~";
      o[23] = "%0U'`;30P}s,${S{\u007f85<Dl4(-";
      o[24] = "26mf9TG\u0016fi(\u001b&\u0018mb,AR";
      o[25] = "w\"\u0002i\u00141a\"\u00073\u0007&vi\u00045\u000b2g.\u0013\"@%U";
      o[26] = "`+\u0004\b\u001fO`+\u0013T\u0013@z`\u0013J\u0013U}\u0011C\u0017B";
      o[27] = "b\"+3@?i-:|(?g\")";
      o[28] = float.class;
      p[28] = "java/lang/Float";
      o[29] = "<9x\u0003kE<9o_gJ&roAg_!\u0003=\u001f0\u0014";
      o[30] = "PxLejn%XGj{!DVLa\u007f{0";
      o[31] = "\u000fuzF\fR\u000fum\u001a\u0000]\u0015>m\u0004\u0000H\u0012O?PQ\t";
      o[32] = "qE+6FtgE.lUcp\u000e-jYwaI:}\u0012bz";
      o[33] = "*O;D\u001f\u0014!@*\u000b|\u00194M%`I\u001b%^9L^\u0016";
      o[34] = "\u001e\u0015L,X\u0011k5G#I^\n;L(M\u0004~";
      o[35] = "\u0003|!k9\u0013\u0015|$1*\u0004\u00027'7&\u0010\u0013p0 m\u0007\u001e";
      o[36] = "\u0012 \u0017o\u0019Pg\u0000\u001c`\b\u001f\u0006\u000e\u0017k\fEr";
      o[37] = "rIz kSdI\u007fzxDs\u0002||tPbEkk?@zEi`e\rF^i}eJqI";
      o[38] = "\ns+]Wh\u007fS RF'\u001e]+YB}j";
      o[39] = "\u0018\u00135%mSm3>*|\u001c\f=5!xFx";
      o[40] = "v?9y`\u001ch7#6\u001c\br: u";
      o[41] = "(U\u001e6:^,E\u0012N,dnZ\u0015#)\u0003}T\t)F]{U\u0011w:\u0003)\b\u0016N";
      o[42] = "y9r2}>\u007fxo4F<B9a4+?%*o(!P~=b!?/s}\u007f+F";
      o[43] = "o\u0007^\t{\u0018~\u001e\u0002\f\u0010\u0015\u0003\u000fT\u0005iN<\bTP.\u007f";
      o[44] = "/$\u0017\u001e\u0004H!%@\u0007tT+3\u001c\t\u0018fy~D_tX 2B\t\u0016\f(7\u0007n";
      o[45] = "]$vH]\u0002\u001cho\u0011,\fb,o\u0003A\n\u0005?a\u001fKe[9`\u0007\u0015\u0019\u0005k=\u0000,";
      o[46] = "N9yS\\~CafZ:cI f\rVQ\u001fb:W\u0006\u0006F$w\t\u0001w\u0019dmR:";
      o[47] = "5+\\e`scu\nu\u0011nR2Vb|m5!X~v\u0002k'Yf(~5u\u0004a\u0011";
      o[48] = "IC-Z^VM\u000b0\u0004dCEU-\f\rO|[-\u001c\t)\u001eL)\u000f\u001dV\u0013\f4\u0005d";
      o[49] = "\u0005w\u0007F\u0013Y\u0014n[CxUi\u007f\rJ\u0001\u000fVx\r\u001fF>";
      o[50] = "lEK%=\u0000a\u001dT,[\u001dk\\T{7/=\u001e\b!dxdXE\u007f`\t;\u0018_$[AiLK%'\u001f;\u0011L\u001c";
      o[51] = "JbV\n|uNiK\u0003Gu%uZ\u0014*qBfT\b \u001e\u0019qY\u0001>a\u00141D\u000bG";
      o[52] = "D.Cu^QD~\u0001}#\u0006$q\u0002`BVJ6\u0019>\u0012o";
      o[53] = "\":\u0010u\u0000vx`Rteku{w \u0001w~\u0007D\"\u0000s\"8C\"U4\u0013";
      o[54] = " $umr|-|jd\u0014a'=j3xSq\u007f6i)\u0004(9{7/uwyal\u0014";
      o[55] = "\u001b\\~u\u0017&M\u0002(ef:|Etr\u000b8\u001bVzn\u0001WEP{v_+\u001b\u0002&qf";
      o[56] = " \u0014sc\u001e\u0011~\u0015*cb\u0014\u001a\u0002p#\u000f\u0012}\u0011~?\u0005}#\u0017\u007f'[\u0001}E\" b";
      o[57] = " 4XiX-qh^%!$ 5\u0003tvs~b[\u0018K/>a\u0001`Fw!h";
      o[58] = "~YBcT\u0003?\u0015[:%\u0006AQ[(H\u000b&BU4Bd}UX=\\\u001bp\u0015E7%";
      o[59] = "\u000e-U \u0004v\r+L(:*wvUpF<\u0006 \u000b&V";
      o[60] = "\u001bk\u007fCCUZ'f\u001a2[$cf\b_]Cph\u0014U2Ir`\n\u0003\rNr5M2";
      o[61] = "<\u0016r#)*>UgcY?9\u0001dv\u000eafW<\u001a07%Rgxd? \u0017";
      o[62] = "-\t\u00034\u001aB!\u0005\u00070#LH\u001f\n!NA/\f\u0004=D.q\n\u0005%\u001aR/XX\"#";
      o[63] = "o3-9F]/3+h\"Y+(<7Y4l(22\u001bZ+3lb\"\b,5;*]\u0005l(1S";
      o[64] = ",F]\u0006K\u007frG\u0004\u00067z\u0016P^FZ|qCPZP\u0013*T]SNl'\u0014@Y7";
      o[65] = "\u0018[*H+\\Y\u00173\u0011ZR'S3\u00037T@@=\u001f=;\u0016\u0014iD?GLN+EZ";
      o[66] = "\u00011M\t\u0014\u0007\fiR\u0000r\u001a\u0006(RW\u001e(Ul\u000e\u000fr\u0016\u0000?B@\u000b\u0018\u0001h[0";
      o[67] = "\u001e9\u001b,Kj\u0017d\\&-;py@3@=\u0017jN/JRIlO7\u0014.\u0017>\u00120-";
      o[68] = "h&0/\u007f4rf$sF:nq#c\u0018=nk'\u001f$,{uqn{la.J";
      o[69] = "Z{DOn1\u0005+\u0013\u000f\u0014-X'NSC~\tr\u001a?wrW:PM(\"\u0000z";
      o[70] = "R\u0012\u0017'SC^\u001e\u0013#jF7\u0018\u001c%Q\u0017\t\u0017\u0003p\u000f/Q\u001f\u0011rR\u0011^\u0000D,j";
      o[71] = "\u001dO\u0007\u0003[3\u001cP\u0002\u001d'+\nF@#C*\u000eJ<\u000f_<\u0004\rMP\u001f&_6";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(695913046157853L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(695913046157853L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(695913046157853L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 212;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 224;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 243;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 213;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 82;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 233;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 212;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 224;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 243;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fo_C0300",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fo" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(float var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(F)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fo_C0300", "lambda$calculate$3", "(F)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
