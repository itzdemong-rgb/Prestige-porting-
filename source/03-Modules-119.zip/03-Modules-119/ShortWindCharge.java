package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.KeyBindingUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

public class ShortWindCharge extends Module implements RotationSource {
   private ModeSetting a;
   private MinMaxSetting c;
   private BooleanSetting d;
   private BooleanSetting e;
   private FloatSetting f;
   private FloatSetting g;
   private ElapsedTimer h;
   private float i;
   private int j;
   private int k;
   private boolean l;
   private static final long m = 29256377285450L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long q;
   private static final Object[] r = new Object[87];
   private static final String[] s = new String[87];
   private static volatile MethodHandle bindingCache1;

   public ShortWindCharge() {
      super();
      long var10001 = 108470750289219L ^ 4045039610474L;

      this.h = new ElapsedTimer(106698256430889L);
      this.i = 0.0F;
      this.j = 0;
      this.k = 0;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 86502240407608L;
      long var6 = var2 ^ 17084490921257L;
      long var8 = var2 ^ 70631327292860L;
      long var10 = var2 ^ 125416469990252L;
      long var12 = var2 ^ 19182256418671L;
      long var14 = var2 ^ 138007752420630L;
      long var16 = var2 ^ 16882931127021L;
      int var18 = Event.cReturningInt();
      int var91 = var18;
      MinecraftClient var90 = b;
      MinecraftClient var70 = var90;
      MinecraftClient var69 = var90;
      if (var91 != 0) {
         MinecraftClient var21 = var69;
         Screen var92 = var21.currentScreen;
         if (var92 != null) {
            return null;
         }

         MinecraftClient var93 = b;
         var70 = var93;
      }

      MinecraftClient var24 = var70;
      int var10000 = (((var24.isWindowFocused()) ? 1 : 0));
      int var95 = var18;
      byte var94 = (byte)var10000;
      byte var72 = var94;
      byte var71 = var94;
      if (var95 != 0) {
         byte var96 = var71;
         if (var96 == 0) {
            return null;
         }

         var72 = ((byte)((this.l) ? 1 : 0));
      }

      int var98 = var18;
      byte var97 = var72;
      byte var79 = var97;
      byte var73 = var97;
      if (var98 != 0) {
         byte var99 = var73;
         if (var99 != 0) {
            MinecraftClient var28 = b;
            ClientPlayerEntity var29 = var28.player;
            boolean var127 = var29.isOnGround();
            int var101 = var18;
            boolean var100 = var127;
            boolean var74 = var100;
            label82:
            if (var101 != 0) {
               boolean var102 = var74;
               boolean var75 = var102;
               boolean var103 = var75;
               if (var103) {
                  BooleanSetting var32 = this.e;
                  Boolean var33 = (Boolean)var32.aReturningObject();
                  var127 = var33;
                  int var105 = var18;
                  boolean var104 = var127;
                  boolean var76 = var104;
                  if (var105 == 0) {
                     break label82;
                  }

                  boolean var106 = var76;
                  boolean var77 = var106;
                  boolean var107 = var77;
                  if (var107) {
                     Object[] var36 = new Object[]{var8};
                     KeyBindingUtil.aReturningVoid(var36);
                  }
               }

               Object[] var38 = new Object[]{Hand.MAIN_HAND, var16};
               boolean var78 = ItemUseUtil.cReturningBoolean(var38);
            }

            this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
         }

         ModeSetting var39 = this.a;
         String var129 = (String)var39.aReturningObject();
         short var10001 = 9941;
         long var10002 = 2529327208669725817L ^ var2;
         String var41 = "Silent";
         String var40 = var129;
         var79 = ((byte)((var40.equals(var41)) ? 1 : 0));
      }

      Object var83;
      label100: {
         int var109 = var18;
         byte var108 = var79;
         int var82 = var108;
         byte var80 = var108;
         if (var109 != 0) {
            byte var110 = var80;
            if (var110 == 0) {
               return null;
            }

            int var112 = var18;
            ShortWindCharge var111 = this;
            var83 = var111;
            ShortWindCharge var81 = var111;
            if (var112 == 0) {
               break label100;
            }

            int var113 = var81.k;
            var82 = var113;
         }

         // int var114 = var82;
         if (var114 != var115) {
            var10000 = this.k;
            Object[] var10003 = new Object[]{null, var14};
            var10003[0] = var10000;
            Object[] var45 = var10003;
            InventoryUtil.aReturningVoid(var45);
            this.k = -1;
            Object[] var47 = new Object[]{var4};
            ShortWindCharge var46 = this;
            var46.aReturningVoid(var47);
            return null;
         }

         FloatSetting var49 = this.f;
         var83 = var49.aReturningObject();
      }

      Float var50 = (Float)var83;
      float var131 = var50 - 1.0F;
      Random var51 = RandomUtil.a;
      float var19 = var131 + var51.nextFloat() * 2.0F;
      Object[] var53 = new Object[]{var6};
      ShortWindCharge var52 = this;
      int var20 = var52.dReturningInt(var53);
      int var117 = var18;
      int var116 = var20;
      int var85 = var116;
      int var84 = var116;
      if (var117 != 0) {
         // int var118 = var84;
         if (var118 == var119) {
            return null;
         }

         Object[] var56 = new Object[]{var12};
         this.k = InventoryUtil.aReturningInt(var56);
         MinecraftClient var57 = b;
         ClientPlayerEntity var58 = var57.player;
         var85 = (((var58.isOnGround()) ? 1 : 0));
      }

      int var89;
      int var121 = var18;
      int var120 = var85;
      var89 = var120;
      int var86 = var120;
      label65:
      if (var121 != 0) {
         int var122 = var86;
         if (var122 != 0) {
            BooleanSetting var60 = this.e;
            Boolean var61 = (Boolean)var60.aReturningObject();
            byte var132 = ((byte)(((java.lang.Boolean)(var61)).booleanValue() ? 1 : 0));
            int var124 = var18;
            byte var123 = var132;
            var89 = var123;
            byte var87 = var123;
            if (var124 == 0) {
               break label65;
            }

            byte var125 = var87;
            byte var88 = var125;
            byte var126 = var88;
            if (var126 != 0) {
               Object[] var64 = new Object[]{var8};
               KeyBindingUtil.aReturningVoid(var64);
            }
         }

         var89 = var20;
      }

      Runnable var133 = invokeBinding1(var19);
      Object[] var10005 = new Object[]{null, null, null, var10};
      var10005[2] = false;
      var10005[1] = var133;
      var10005[0] = var89;
      Object[] var66 = var10005;
      InventoryUtil.bReturningVoid(var66);
      MinecraftClient var67 = b;
      ClientPlayerEntity var68 = var67.player;
      return new Rotation(var68.getYaw(), var19);
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 105424329921373L ^ 49745878936325L;
      var10001 = 105424329921373L ^ 39638821696914L;
      var10001 = 105424329921373L ^ 36697487869257L;
      var10001 = 105424329921373L ^ 42836945100639L;
      var10001 = 105424329921373L ^ 118866596171284L;
      var10001 = 105424329921373L ^ 126307298628690L;
      var10001 = 105424329921373L ^ 33081670080043L;
      var10001 = 105424329921373L ^ 34035033165232L;
      var10001 = 105424329921373L ^ 134421492018399L;
      int var22 = Event.bReturningInt();
      int var116 = var22;
      MinecraftClient var115 = b;
      MinecraftClient var91 = var115;
      MinecraftClient var90 = var115;
      if (var116 == 0) {
         MinecraftClient var24 = var90;
         Screen var117 = var24.currentScreen;
         if (var117 != null) {
            return;
         }

         MinecraftClient var118 = b;
         var91 = var118;
      }

      MinecraftClient var27 = var91;
      byte var10000 = ((byte)((var27.isWindowFocused()) ? 1 : 0));
      int var120 = var22;
      byte var119 = var10000;
      byte var93 = var119;
      byte var92 = var119;
      if (var120 == 0) {
         byte var121 = var92;
         if (var121 == 0) {
            return;
         }

         ModeSetting var29 = this.a;
         String var164 = (String)var29.aReturningObject();
         String var31 = "Legit";
         String var30 = var164;
         var93 = ((byte)((var30.equals(var31)) ? 1 : 0));
      }

      int var123 = var22;
      byte var122 = var93;
      byte var95 = var122;
      byte var94 = var122;
      if (var123 == 0) {
         byte var124 = var94;
         if (var124 == 0) {
            return;
         }

         ElapsedTimer var165 = this.h;
         MinMaxSetting var33 = this.c;
         Float var34 = (Float)var33.aReturningObject();
         float var178 = var34;
         Object[] var10004 = new Object[]{null, 139098136696340L};
         var10004[0] = var178;
         Object[] var36 = var10004;
         ElapsedTimer var35 = var165;
         var95 = ((byte)((var35.aReturningBoolean(var36)) ? 1 : 0));
      }

      int var126 = var22;
      byte var125 = var95;
      int var97 = var125;
      byte var96 = var125;
      if (var126 == 0) {
         byte var127 = var96;
         if (var127 == 0) {
            return;
         }

         var97 = this.j;
      }

      label139: {
         label140: {
            label141: {
               int var129 = var22;
               int var128 = var97;
               int var99 = var128;
               int var98 = var128;
               if (var129 == 0) {
                  int var130 = var98;
                  switch (var130) {
                     case 0:
                        MinecraftClient var39 = b;
                        ClientPlayerEntity var40 = var39.player;
                        Object[] var41 = new Object[]{var40.getMainHandStack(), 136267004028623L};
                        byte var131 = ((byte)((aReturningBoolean(var41)) ? 1 : 0));
                        var99 = var131;
                        break;
                     case 1:
                        break label141;
                     case 2:
                        break label140;
                     case 3:
                        break label139;
                     default:
                        return;
                  }
               }

               int var133 = var22;
               int var132 = var99;
               int var101 = var132;
               int var100 = var132;
               if (var133 == 0) {
                  int var134 = var100;
                  if (var134 != 0) {
                     Object[] var45 = new Object[]{41383938523010L};
                     ShortWindCharge var44 = this;
                     var44.jReturningVoid(var45);
                     return;
                  }

                  Object[] var48 = new Object[]{57147937381705L};
                  ShortWindCharge var47 = this;
                  var101 = var47.dReturningInt(var48);
               }

               int var23 = var101;
               int var136 = var22;
               int var135 = var23;
               int var103 = var135;
               int var102 = var135;
               if (var136 == 0) {
                  // int var137 = var102;
                  if (var137 == var138) {
                     Object[] var51 = new Object[]{126290808879192L};
                     ShortWindCharge var50 = this;
                     var50.aReturningVoid(var51);
                     return;
                  }

                  Object[] var53 = new Object[]{49487520630543L};
                  this.k = InventoryUtil.aReturningInt(var53);
                  var103 = var23;
               }

               Object[] var10003 = new Object[]{null, 72518082610550L};
               var10003[0] = var103;
               Object[] var54 = var10003;
               InventoryUtil.aReturningVoid(var54);
               Object[] var56 = new Object[]{41383938523010L};
               ShortWindCharge var55 = this;
               var55.jReturningVoid(var56);
               int var139 = var22;
               if (var139 == 0) {
                  return;
               }
            }

            label109: {
               FloatSetting var57 = this.f;
               Float var58 = (Float)var57.aReturningObject();
               float var166 = var58 - 1.0F;
               Random var59 = RandomUtil.a;
               float var163 = var166 + var59.nextFloat() * 2.0F;
               int var140 = var22;
               if (var140 == 0) {
                  Rotation var167 = new Rotation(0.0F, var163);
                  FloatSetting var60 = this.g;
                  Float var61 = (Float)var60.aReturningObject();
                  float var179 = var61 / 2.0F;
                  Object[] var10006 = new Object[]{null, null, null, null, 71564451356397L};
                  var10006[3] = 0.5F;
                  var10006[2] = 0.0F;
                  var10006[1] = var179;
                  var10006[0] = var167;
                  Object[] var62 = var10006;
                  boolean var141 = RotationUtil.cReturningBoolean(var62);
                  if (!var141) {
                     break label109;
                  }

                  this.l = dev.prestige.recovery.SourceSupport.asBoolean(1);
               }

               Object[] var65 = new Object[]{41383938523010L};
               ShortWindCharge var64 = this;
               var64.jReturningVoid(var65);
            }

            int var142 = var22;
            if (var142 == 0) {
               return;
            }
         }

         int var144 = var22;
         boolean var143 = this.l;
         boolean var106 = var143;
         boolean var104 = var143;
         if (var144 == 0) {
            boolean var145 = var104;
            boolean var105 = var145;
            boolean var146 = var105;
            if (var146) {
               return;
            }

            Rotation var168 = new Rotation(0.0F, this.i);
            FloatSetting var68 = this.g;
            Float var69 = (Float)var68.aReturningObject();
            float var180 = var69 / 2.0F;
            Object[] var182 = new Object[]{null, null, null, null, 133142968601602L};
            var182[3] = 0.5F;
            var182[2] = 0.0F;
            var182[1] = var180;
            var182[0] = var168;
            Object[] var70 = var182;
            var106 = RotationUtil.dReturningBoolean(var70);
         }

         ShortWindCharge var111;
         label142: {
            int var148 = var22;
            boolean var147 = var106;
            boolean var110 = var147;
            boolean var107 = var147;
            if (var148 == 0) {
               boolean var149 = var107;
               if (!var149) {
                  return;
               }

               int var151 = var22;
               ShortWindCharge var150 = this;
               var111 = var150;
               ShortWindCharge var108 = var150;
               if (var151 != 0) {
                  break label142;
               }

               ShortWindCharge var152 = var108;
               ShortWindCharge var109 = var152;
               BooleanSetting var73 = var109.d;
               Boolean var74 = (Boolean)var73.aReturningObject();
               boolean var153 = var74;
               var110 = var153;
            }

            boolean var154 = var110;
            if (!var154) {
               Object[] var77 = new Object[]{126290808879192L};
               ShortWindCharge var76 = this;
               var76.aReturningVoid(var77);
               int var155 = var22;
               if (var155 == 0) {
                  return;
               }
            }

            ShortWindCharge var156 = this;
            var111 = var156;
         }

         Object[] var81 = new Object[]{41383938523010L};
         ShortWindCharge var80 = var111;
         var80.jReturningVoid(var81);
         int var157 = var22;
         if (var157 == 0) {
            return;
         }
      }

      BooleanSetting var82 = this.d;
      Boolean var83 = (Boolean)var82.aReturningObject();
      var10000 = ((byte)(((java.lang.Boolean)(var83)).booleanValue() ? 1 : 0));
      int var159 = var22;
      byte var158 = var10000;
      int var114 = var158;
      byte var112 = var158;
      if (var159 == 0) {
         byte var160 = var112;
         byte var113 = var160;
         byte var161 = var113;
         if (var161 == 0) {
            return;
         }

         int var162 = this.k;
         var114 = var162;
      }

      Object[] var181 = new Object[]{null, 72518082610550L};
      var181[0] = var114;
      Object[] var87 = var181;
      InventoryUtil.aReturningVoid(var87);
      Object[] var89 = new Object[]{126290808879192L};
      ShortWindCharge var88 = this;
      var88.aReturningVoid(var89);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 98450992130864L;
      long var6 = var2 ^ 13970279202175L;
      long var8 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var11 = new Object[]{this, var8};
      RotationManager var10 = var10000;
      var10.dReturningVoid(var11);
      ElapsedTimer var20 = this.h;
      Object[] var13 = new Object[]{var6};
      ElapsedTimer var12 = var20;
      var12.aReturningVoid(var13);
      MinecraftClient var14 = b;
      ClientPlayerEntity var15 = var14.player;
      this.i = var15.getPitch();
      this.j = 0;
      ElapsedTimer var21 = this.h;
      Object[] var17 = new Object[]{var6};
      ElapsedTimer var16 = var21;
      var16.aReturningVoid(var17);
      MinMaxSetting var22 = this.c;
      Object[] var19 = new Object[]{var4};
      MinMaxSetting var18 = var22;
      var18.bReturningVoid(var19);
   }

   private void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 29256377285450L ^ var2;
      long var4 = var2 ^ 84607571999367L;
      long var6 = var2 ^ 28372044917960L;
      ElapsedTimer var10000 = this.h;
      Object[] var9 = new Object[]{var6};
      ElapsedTimer var8 = var10000;
      var8.aReturningVoid(var9);
      MinMaxSetting var13 = this.c;
      Object[] var11 = new Object[]{var4};
      MinMaxSetting var10 = var13;
      var10.bReturningVoid(var11);
      this.j++;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 29256377285450L ^ var2;
      int var25 = Event.cReturningInt();
      int var4 = var25;

      byte var16;
      while (true) {
         int var18 = (int)q;
         int var17 = var5;
         if (var17 <= var18) {
            MinecraftClient var7 = b;
            ClientPlayerEntity var8 = var7.player;
            PlayerInventory var26 = var8.getInventory();
            int var10 = var5;
            PlayerInventory var9 = var26;
            ItemStack var6 = var9.getStack(var10);
            int var19 = var4;
            if (var19 != 0) {
               ItemStack var11 = var6;
               Item var27 = var11.getItem();
               Item var13 = Items.WIND_CHARGE;
               Item var12 = var27;
               byte var28 = ((byte)((var12.equals(var13)) ? 1 : 0));
               int var21 = var4;
               byte var20 = var28;
               var16 = var20;
               byte var14 = var20;
               if (var21 == 0) {
                  break;
               }

               byte var22 = var14;
               byte var15 = var22;
               byte var23 = var15;
               if (var23 != 0) {
                  return var5;
               }

               var5++;
            }

            int var24 = var4;
            if (var24 != 0) {
               continue;
            }
         }

         var16 = -1;
         break;
      }

      return var16;
   }

   public static boolean aReturningBoolean(Object[] var0) {
      ItemStack var3 = (ItemStack)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 29256377285450L ^ var1;
      ItemStack var4 = var3;
      Item var7 = var4.getItem();
      Item var6 = Items.WIND_CHARGE;
      Item var5 = var7;
      return var5.equals(var6);
   }

   private static void lambda$calculate$3(float var0) {
      long var10001 = 21541550127547L ^ 35997545874230L;
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      float var5 = var7.getPitch();
      MinecraftClient var8 = b;
      float var10 = var0;
      ClientPlayerEntity var9 = var8.player;
      var9.setPitch(var10);
      Object[] var11 = new Object[]{Hand.MAIN_HAND, 56259183000205L};
      ItemUseUtil.cReturningBoolean(var11);
      MinecraftClient var12 = b;
      float var14 = var5;
      ClientPlayerEntity var13 = var12.player;
      var13.setPitch(var14);
   }

   private boolean lambda$new$2(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$1(Boolean var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   private boolean lambda$new$0(Float var1) {
      ModeSetting var4 = this.a;
      String var10000 = (String)var4.aReturningObject();
      String var6 = "Legit";
      String var5 = var10000;
      return var5.equals(var6);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(40451617917108L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[3];
      String var11 = "z|}\u001còÜç¼\u001aùï¼ÐÜÄI\u0010ö¥½QæªôrÔ\u0095Å&¼\u0092²Â\u0010\u0015©'\u0003ÇÒ§·Âe\u0007\u0089<ÌÕ\u0095";
      int var13 = "z|}\u001còÜç¼\u001aùï¼ÐÜÄI\u0010ö¥½QæªôrÔ\u0095Å&¼\u0092²Â\u0010\u0015©'\u0003ÇÒ§·Âe\u0007\u0089<ÌÕ\u0095".length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = b(var15).intern();
         // var14[var12++] = var21;
         if ((var9 += var10) >= var13) {
            n = var14;
            o = new String[3];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(40451617917108L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = -5657349846538511994L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)177L,
                  (byte)45437L,
                  (byte)11631886L,
                  (byte)2977762889L,
                  (byte)762307299802L,
                  (byte)195150668749558L,
                  (byte)49958571199886873L,
                  (byte)-5657349846538511994L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            q = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2765;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fp", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fp_C0302",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fp" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 56;
            yield var15;
         }
         case 1 -> {
            byte var16 = 37;
            yield var16;
         }
         case 2 -> {
            byte var17 = 17;
            yield var17;
         }
         case 3 -> {
            byte var18 = 39;
            yield var18;
         }
         case 4 -> {
            byte var19 = 11;
            yield var19;
         }
         case 5 -> {
            byte var20 = 25;
            yield var20;
         }
         case 6 -> {
            byte var21 = 2;
            yield var21;
         }
         case 7 -> {
            byte var22 = 29;
            yield var22;
         }
         case 8 -> {
            byte var23 = 30;
            yield var23;
         }
         case 9 -> {
            byte var24 = 8;
            yield var24;
         }
         case 10 -> {
            byte var25 = 5;
            yield var25;
         }
         case 11 -> {
            byte var26 = 10;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 61;
            yield var28;
         }
         case 14 -> {
            byte var29 = 34;
            yield var29;
         }
         case 15 -> {
            byte var30 = 45;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 31;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 50;
            yield var34;
         }
         case 20 -> {
            byte var35 = 51;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 14;
            yield var37;
         }
         case 23 -> {
            byte var38 = 47;
            yield var38;
         }
         case 24 -> {
            byte var39 = 32;
            yield var39;
         }
         case 25 -> {
            byte var40 = 44;
            yield var40;
         }
         case 26 -> {
            byte var41 = 54;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 53;
            yield var44;
         }
         case 30 -> {
            byte var45 = 13;
            yield var45;
         }
         case 31 -> {
            byte var46 = 16;
            yield var46;
         }
         case 32 -> {
            byte var47 = 28;
            yield var47;
         }
         case 33 -> {
            byte var48 = 35;
            yield var48;
         }
         case 34 -> {
            byte var49 = 57;
            yield var49;
         }
         case 35 -> {
            byte var50 = 0;
            yield var50;
         }
         case 36 -> {
            byte var51 = 33;
            yield var51;
         }
         case 37 -> {
            byte var52 = 42;
            yield var52;
         }
         case 38 -> {
            byte var53 = 4;
            yield var53;
         }
         case 39 -> {
            byte var54 = 46;
            yield var54;
         }
         case 40 -> {
            byte var55 = 21;
            yield var55;
         }
         case 41 -> {
            byte var56 = 3;
            yield var56;
         }
         case 42 -> {
            byte var57 = 49;
            yield var57;
         }
         case 43 -> {
            byte var58 = 60;
            yield var58;
         }
         case 44 -> {
            byte var59 = 40;
            yield var59;
         }
         case 45 -> {
            byte var60 = 1;
            yield var60;
         }
         case 46 -> {
            byte var61 = 26;
            yield var61;
         }
         case 47 -> {
            byte var62 = 55;
            yield var62;
         }
         case 48 -> {
            byte var63 = 58;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 62;
            yield var65;
         }
         case 51 -> {
            byte var66 = 20;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 27;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 7;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 41;
            yield var72;
         }
         case 58 -> {
            byte var73 = 22;
            yield var73;
         }
         case 59 -> {
            byte var74 = 12;
            yield var74;
         }
         case 60 -> {
            byte var75 = 15;
            yield var75;
         }
         case 61 -> {
            byte var76 = 24;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 63;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = ">xL;\u0000*(xIa\u0013=?3Jg\u001f).t]pT>\u0018";
      r[1] = "D_/FA]1\u007f$IP\u0012Pq/BTH$";
      r[2] = boolean.class;
      s[2] = "java/lang/Boolean";
      r[3] = "G\feyP$L\u0003t6-<_\u0004}\u007f";
      r[4] = ":zL\r1w1u]BPy:~Y\u0018";
      r[5] = "M^\u0019PGy[^\u001c\nTnL\u0015\u001f\fXz]R\b\u001b\u0013hl";
      r[6] = int.class;
      s[6] = "java/lang/Integer";
      r[7] = "Q$|<K\u0011G$yfX\u0006Poz`T\u0012A(mw\u001f\u0007l";
      r[8] = "'XS8<`RxX7-/3vS<)uG";
      r[9] = "&ch@\"|0cm\u001a1k'(n\u001c=\u007f6oy\u000bvj2";
      r[10] = "kM\u0019VtA`B\b\u0019\u0017LuO\u0007r\"Nd\\\u001b^5C";
      r[11] = "j0;RZ]j0,\u000eVRp{,\u0010VGw\nxH\u0001";
      r[12] = ")\u0000\u000b\"a\u001b)\u0000\u001c~m\u00143K\u001c`m\u00014:N;5K";
      r[13] = "\nZ\u0003\u000f#\f\nZ\u0014S/\u0003\u0010\u0011\u0014M/\u0016\u0017`D\u0010~";
      r[14] = "^A6o52^A!39=D\n!-9(C{vro";
      r[15] = "'_k\u007frm1_n%az&\u0014m#mn7Sz4&~,";
      r[16] = "\u0016j2$A\u0000cJ9+PO\u0002D2 T\u0015v";
      r[17] = void.class;
      s[17] = "java/lang/Void";
      r[18] = "H[&Z@TCT7\u0015,WMV5Z\u0000";
      r[19] = "\b\u0017\u001aEP}\u001e\u0017\u001f\u001fCj\t\\\u001c\u0019O~\u0018\u001b\u000b\u000e\u0004i=";
      r[20] = "}\u0005>jo:\b%5e~ui+>nz/\u001d";
      r[21] = "\u0016.BXP0\u0000.G\u0002C'\u0017eD\u0004O3\u0006\"S\u0013\u0004$4";
      r[22] = "eD\u0000Go.\u0010d\u000bH~aqj\u0000Cz;\u0005";
      r[23] = "t@?\u0017;q\u007fO.XSqq@=";
      r[24] = float.class;
      s[24] = "java/lang/Float";
      r[25] = "O^f^\u001e`:~mQ\u000f/[pfZ\u000bu/";
      r[26] = "F'n\u0000-33\u0007e\u000f<|R\tn\u00048&&";
      r[27] = "ng*\u000b\u0017`po0Dktjb3\u0007";
      r[28] = "\u0011Vd\u001a\u0012Bdvo\u0015\u0003\r\u0005xd\u001e\u0007Wq";
      r[29] = "3\u007fWn0kF_\\a!$'QWj%~S";
      r[30] = "L>\ftC)Z>\t.P>Mu\n(\\*\\2\u001d?\u0017:D";
      r[31] = "\u0010\"$\fnNe\u0002/\u0003\u007f\u0001\u0004\f$\b{[p";
      r[32] = "uyF9{\buyQew\u0007o2Q{w\u0012hC\u0003% Y";
      r[33] = "\u007fw\u0015mPfa\u007f\u000f\"-va";
      r[34] = "^\u0016ql<\u0015^\u0016f00\u001aD]f.0\u000fC,4tgM";
      r[35] = "\u000bM]o\rh\u000bMJ3\u0001g\u0011\u0006J-\u0001r\u0016w\u0018vY3";
      r[36] = ";q\u0004\\Cw;q\u0013\u0000Ox!:\u0013\u001eOm&KAJ\u001e,";
      r[37] = "\u00131P_B\u0000\u00051U\u0005Q\u0017\u0012zV\u0003]\u0003\u0003=A\u0014\u0016\u0014;";
      r[38] = "\u0001zo\u0001\u0018~tZd\u000e\t1\u0015To\u0005\rka";
      r[39] = "7Pk( \u0000!Pnr3\u00176\u001bmt?\u0003'\\zct\u0014*";
      r[40] = "<{0,(zI[;#95(U0(=o\\";
      r[41] = "Evy~\b20Vrq\u0019}QXyz\u001d'%";
      r[42] = "I: \tWX_:%SDOHq&UH[Y61B\u0003KA63IY\u0006}-3TYAJ:";
      r[43] = "\\\"\f\\Ri)\u0002\u0007SC&H\f\fXG|<";
      r[44] = "\u0006^u [\f\u0010^pzH\u001b\u0007\u0015s|D\u000f\u0016Rdk\u000f\u001f\u0010";
      r[45] = "+w\u0019g%!^W\u0012h4n?Y\u0019c04K";
      r[46] = "6jY\u0017r\tCJR\u0018cF\"DY\u0013g\u001cV";
      r[47] = "T\u0015#I\u0010\u0004\u0010E!\rs\u0007-ZaL\u0011\rGH%L\u0017mGT$R\t\u0016\u0011]eAs";
      r[48] = "h1\u000e2>^(i]X>g,4K:2\r>pK<R^7d\r*;\u0003=c\u0007X";
      r[49] = "!\u0006\u0001P3*$\u0012E\\I%\u001aGX\u0002#6+\u0018ZR O";
      r[50] = "$N<\u001f\"\u0011|\u0003l\u001aF\u000evB2\u001f*< \u0007oDvk}F9\u0004#Tx\u0003+DF";
      r[51] = "Ba\r\u001d\u001b\\\u0012b\u0018\u000e`K\u001fd\u0007\u0000\fyM)_V`I\re\u0016\u0015\u0002E\u000bv[g";
      r[52] = "sH#y^\n/B-tg\u0013M\u0011`2\u0007A$\u001e'\"\u001dzr\u0013'(\\\u0013}T72g";
      r[53] = "]\\w>\u001cH\n\u0001q `X\r\tu77\u000fSY,[QL\u0017\u000fjgPV\u0000\u001d";
      r[54] = "w[kl\t\u001byR1dr\u0012\u001eJ5j\u0010\u001btXqj\u0016{tDpt\b\u0000\"M1gr";
      r[55] = "\u0004}iA\u0000\n\u001c>&Cz\u000f\fGbZ\u0005\u000e\u001bw1U\u0018\rb!b\u001b\u0011\u0012\u00009!T\u0013h";
      r[56] = "O&pnn,\u0017k k\n3\u001d*~nf\u0001Kh\"46V\u001f.\u007fb7?\u0017-pg\n";
      r[57] = "8w\u001a&c3.#\u0006?\u0018.BbN9z\"(p\n9|B(l\u000b'b9~eJ4\u0018";
      r[58] = "`[Vg\t_7\u0006PyuD<\u001fPe\u0019vh^\u000e3u\u00185\n\np\u001cE?\r\u0000\u0002";
      r[59] = "\u0000z\n[\u0014r\tqNUv|\f}\u0017G\u001fp5s\u0017W\u001b\u0016R~\u001a\u0010\u0004\u007f\u000ft\u001d\u001av";
      r[60] = "\u007f\n\n\ru+'GZ\b\u00114-\u0006\u0004\r}\u0006{DXW.Q/\u0002\u0005\u0001,8'\u0001\n\u0004\u0011;1\u0006\u0006\u0010jm8G\u0015j";
      r[61] = "VM;E6ySY\u007fILwm\fb\u0017&e\\S`G%\u001c";
      r[62] = "\u00065@=\u0013v^x\u00108wiT9N=\u001b[\u0003y\u001e`G\f\u0000!G`\u0005e]+@jw";
      r[63] = "r)n(u\u0016p37u\u0005\u0012\u001fl\u007f2c\u0002/?p/`{";
      r[64] = "\u0004\"\u0014~8\u0000\\%\u000bzX\u0010g Va:\u001b\r2\u0012a<{^;\u0006'*\u0012\u00031\u0001-X";
      r[65] = "+!Q#NRsl\u0001&*My-_#F\u007f/o\u0003y\u0017({)^/\u0017As*Q**";
      r[66] = "^<X('oHhD1\\s$)\f7>~N;H78\u001eN'I)&e\u0018.\b:\\";
      r[67] = "V:\u007fwW \u0001gyi+0\u0006o}~|gX8%\u0012\u0014.\te}hLcY`";
      r[68] = "\t3zfO\u0001W>8+/\u00134|}'M\u001a^n9'Kz^r89U\u0001\b{y*/";
      r[69] = ">|.<\u001b\u001dbv 1\"\u0001\u0000eiq@\rjw-qFm<x?g[\\czod\"";
      r[70] = "A\"}PF\u001d\u0012-`S?@\u0002/kRD-A\"}PF\u001d\u0012-`S?\u0014\u001f;8DVI\u0015<26";
      r[71] = "QI\u0016|-hPHH|Q?-HLs2#\\^\u0018o+";
      r[72] = "|e 9+\brlz1P\u0001\u0015t~?2\b\u007ff:?4h)i())Yvkx*P";
      r[73] = "hccG\u001d#(;0-\u001a\u001a,f&O\u0011p>\"&Iq#76`_\u0018~=1j-";
      r[74] = "Mz~J\u000bSMl3JaT\u000eagU\u001a9MlqW\u0018\t\u001eclTa\u0000\u0013u4C\b]\u0019r>1";
      r[75] = "`1&\r\u0000K><d@`Y]~!L\u0002P7leL\u00040deq\n\u0012Y9ov\u0000`";
      r[76] = "S4\u0010i)$\u000by@lM;\u00018\u001ei!\tR|B1Mn\u0015.\u0004u?>\u0016;\u0017\u000e";
      r[77] = "\u007f*71'\u0005q#m9\\\u000f\u0016;i7>\u0005|)-78e|5,)&\u001e*<m:\\";
      r[78] = "Y]\u001am\u0000F\u000bNEh\u007f@5CGp\u001dI_Q\u0003p\u001b)_M\u0002n\u0005R\tDC}\u007f";
      r[79] = "i\n\t]\u0003F\u007f\u000fH]g\u0010p^UK0B \u000b\u0000\u0017g\u0019nN@U\u0005\u0015h]\r";
      r[80] = "d0oWo\u0010au}\u0017\nJo4dLfx?t?\u001b\n\u0013`'nR;Lbwm+:Vh2\u007fYjU}!\u0004";
      r[81] = ")i}kG\u0005ucsf~\u0017\u0017p:&\u001c\u0015}b~&\u001au}~\u007f8\u0004\u000e+w>+~";
      r[82] = "\",c/=sp,%1\u0000e)s7*^b)i3Vos,\u007fc?gp#z^";
      r[83] = "p%\u000b+n)\u007f7\ri\u001c't*\u0003wKt%\u007fW\u001by+yw\u0015{v9\u007f5";
      r[84] = "\u0013~\u0002(\f\u0012\u0016f\u001a\"m@ndQ8\u000fI\u0004v\u00158\t)\u0004j\u0014&\u0017RRcU5m";
      r[85] = "F4/,sZK3u+\u0018UJ=c\u0007|TN1\u001f&`RLpv.c]IM";
      r[86] = "x]\u0002\t\u0006-$W\f\u0004?4FDED]=,V\u0001D[]\u007f_\u0015\u0002M4\"U\u0012\b?";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(298775845593922L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(298775845593922L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(298775845593922L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 75;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 203;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 112;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 165;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 245;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 223;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 75;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 203;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 112;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fp_C0302",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fp" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(float var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(F)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fp_C0302", "lambda$calculate$3", "(F)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((float)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
