package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackTargetUpdateEvent;
import dev.zprestige.prestige.api.events.PostAttackEvent;
import dev.zprestige.prestige.api.util.BlockUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.AttackAttemptEvent;
import dev.zprestige.prestige.api.events.MouseButtonEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.client.management.KeybindManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.eventbus.EventPhase;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class SilentAim extends Module implements RotationSource {
   private BooleanSetting d;
   private BooleanSetting a;
   private BooleanSetting c;
   private FloatSetting e;
   private FloatSetting f;
   private MultiModeSetting g;
   private BooleanSetting h;
   private FloatSetting i;
   private ColorSetting j;
   private boolean k;
   private boolean l;
   private Vec3d m;
   private Entity n;
   private static final String[] o;
   private static final double[] p;
   private static final long q = 119525033668006L;
   private static final long[] r;
   private static final Integer[] s;
   private static final Map t;
   private static final Object[] u = new Object[147];
   private static final String[] v = new String[147];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public SilentAim() {
      super();
      long var10001 = 30597708088659L ^ 68616739292691L;
      var10001 = 30597708088659L ^ 5097173497732L;

      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.m = null;
      this.n = null;
      ColorSetting var10000 = this.j;
      Object[] var8 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var7 = var10000;
      var7.aReturningColorSetting(var8);
      FloatSetting var11 = this.i;
      Object[] var10 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var9 = var11;
      var9.aReturningFloatSetting(var10);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.Mace;
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4, var5);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 119525033668006L ^ var2;
      int var4 = Event.cReturningInt();
      int var13 = var4;
      KillAura var12 = KillAura.a;
      KillAura var8 = var12;
      KillAura var7 = var12;
      if (var13 != 0) {
         KillAura var14 = var7;
         if (var14 == null) {
            return false;
         }

         var8 = KillAura.a;
      }

      KillAura var6 = var8;
      boolean var19 = var6.aReturningBoolean();
      int var16 = var4;
      boolean var15 = var19;
      boolean var10 = var15;
      boolean var9 = var15;
      return var16 == 0 ? var10 : var9;
   }

   private boolean aReturningBoolean(Object[] var1) {
      Rotation var2 = (Rotation)var1[0];
      long var3 = (Long)var1[1];
      var3 = 119525033668006L ^ var3;
      long var5 = var3 ^ 66552519170770L;
      int var7 = Event.bReturningInt();
      Object[] var9 = new Object[0];
      Rotation var8 = var2;
      float var10000 = var8.aReturningFloat(var9);
      MinecraftClient var10 = b;
      ClientPlayerEntity var11 = var10.player;
      var10000 -= var11.getYaw();
      Object[] var10003 = new Object[]{null, var5};
      var10003[0] = var10000;
      Object[] var12 = var10003;
      float var13 = RotationUtil.bReturningFloat(var12);
      var10000 = Math.abs(var13);
      FloatSetting var14 = this.e;
      Float var15 = (Float)var14.aReturningObject();
      float var44;
      int var40 = (var44 = var10000 - var15) == 0.0F ? 0 : (var44 < 0.0F ? -1 : 1);
      int var30 = var7;
      int var29 = var40;
      int var27 = var29;
      int var24 = var29;
      if (var30 == 0) {
         int var31 = var24;
         if (var31 <= 0) {
            Object[] var18 = new Object[0];
            Rotation var17 = var2;
            var10000 = var17.bReturningFloat(var18);
            MinecraftClient var19 = b;
            ClientPlayerEntity var20 = var19.player;
            float var21 = var10000 - var20.getPitch();
            var10000 = Math.abs(var21);
            FloatSetting var22 = this.f;
            Float var23 = (Float)var22.aReturningObject();
            float var45;
            int var43 = (var45 = var10000 - var23) == 0.0F ? 0 : (var45 < 0.0F ? -1 : 1);
            int var33 = var7;
            int var32 = var43;
            var27 = var32;
            int var25 = var32;
            if (var33 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var27);
            }

            int var34 = var25;
            int var26 = var34;
            int var35 = var26;
            if (var35 <= 0) {
               return false;
            }
         }

         var27 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var27);
   }

   private Entity aReturningEntity(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 119525033668006L ^ var2;
      long var4 = var2 ^ 780928657221L;
      long var6 = var2 ^ 80957241598L;
      long var8 = var2 ^ 2041786368230L;
      int var10 = Event.cReturningInt();
      BooleanSetting var12 = this.d;
      Boolean var13 = (Boolean)var12.aReturningObject();
      boolean var44 = var13;
      Object var32;
      if (var44) {
         Object[] var14 = new Object[]{var6};
         PlayerEntity var45 = EntityUtil.aReturningPlayerEntity(var14);
         var32 = var45;
      } else {
         Object[] var16 = new Object[]{var4};
         var32 = EntityUtil.aReturningEntity(var16);
      }

      Object var11 = var32;
      int var47 = var10;
      Object var46 = var11;
      Object var34 = var46;
      Object var33 = var46;
      if (var47 != 0) {
         Object var48 = var33;
         if (var48 == null) {
            return null;
         }

         var34 = var11;
      }

      Object var18 = var34;
      byte var10000 = ((byte)((((Entity)var18).isAlive()) ? 1 : 0));
      int var50 = var10;
      byte var49 = var10000;
      int var36 = var49;
      byte var35 = var49;
      if (var50 != 0) {
         byte var51 = var35;
         if (var51 == 0) {
            return null;
         }

         MinecraftClient var20 = b;
         Object var22 = var11;
         ClientPlayerEntity var21 = var20.player;
         float var66;
         int var52 = (var66 = var21.distanceTo((Entity)var22) - 3.0F) == 0.0F ? 0 : (var66 < 0.0F ? -1 : 1);
         var36 = var52;
      }

      int var54 = var10;
      int var53 = var36;
      int var38 = var53;
      int var37 = var53;
      if (var54 != 0) {
         int var55 = var37;
         if (var55 > 0) {
            return null;
         }

         MinecraftClient var25 = b;
         Object var27 = var11;
         ClientPlayerEntity var26 = var25.player;
         byte var56 = ((byte)((var26.canSee((Entity)var27)) ? 1 : 0));
         var38 = var56;
      }

      int var58 = var10;
      int var57 = var38;
      int var42 = var57;
      int var39 = var57;
      if (var58 != 0) {
         int var59 = var39;
         if (var59 == 0) {
            return null;
         }

         int var61 = var10;
         Object var60 = var11;
         Object var43 = var60;
         Object var40 = var60;
         if (var61 == 0) {
            return (Entity)var43;
         }

         Object var62 = var40;
         Object var41 = var62;
         Object[] var31 = new Object[]{var41, var8};
         byte var63 = ((byte)((BlockUtil.aReturningBoolean(var31)) ? 1 : 0));
         var42 = var63;
      }

      int var64 = var42;
      return (Entity)(var64 != 0 ? null : var11);
   }

   @EventListener
   public void a(AttackAttemptEvent var1) {
      long var10001 = 131140779127846L ^ 102970959335535L;
      var10001 = 131140779127846L ^ 32459561752940L;
      var10001 = 131140779127846L ^ 39706064860480L;
      var10001 = 131140779127846L ^ 88710529027559L;
      var10001 = 131140779127846L ^ 113120963318955L;
      var10001 = 131140779127846L ^ 42494806827275L;
      var10001 = 131140779127846L ^ 113194591595418L;
      int var18 = Event.bReturningInt();
      int var103 = var18;
      MinecraftClient var102 = b;
      MinecraftClient var80 = var102;
      MinecraftClient var79 = var102;
      if (var103 == 0) {
         MinecraftClient var22 = var79;
         Screen var104 = var22.currentScreen;
         if (var104 != null) {
            return;
         }

         MinecraftClient var105 = b;
         var80 = var105;
      }

      MinecraftClient var25 = var80;
      boolean var106 = var25.isWindowFocused();
      if (var106) {
         Object[] var28 = new Object[0];
         AttackAttemptEvent var27 = var1;
         EventPhase var10000 = var27.aReturningEventPhase(var28);
         EventPhase var108 = EventPhase.PRE;
         EventPhase var107 = var10000;
         if (var107 == var108) {
            int var110 = var18;
            boolean var109 = this.l;
            boolean var82 = var109;
            boolean var81 = var109;
            if (var110 == 0) {
               boolean var111 = var81;
               if (var111) {
                  Object[] var32 = new Object[]{true};
                  AttackAttemptEvent var31 = var1;
                  var31.bReturningVoid(var32);
                  return;
               }

               Object[] var35 = new Object[]{117372919475530L};
               SilentAim var34 = this;
               var82 = var34.dReturningBoolean(var35);
            }

            MinecraftClient var90;
            label117: {
               int var113 = var18;
               boolean var112 = var82;
               boolean var85 = var112;
               boolean var83 = var112;
               if (var113 == 0) {
                  boolean var114 = var83;
                  if (var114) {
                     return;
                  }

                  int var116 = var18;
                  MinecraftClient var115 = b;
                  var90 = var115;
                  MinecraftClient var84 = var115;
                  if (var116 != 0) {
                     break label117;
                  }

                  MinecraftClient var37 = var84;
                  ClientPlayerEntity var38 = var37.player;
                  Object[] var39 = new Object[]{var38.getMainHandStack(), 19476550655932L};
                  boolean var117 = InventoryUtil.aReturningBoolean(var39);
                  var85 = var117;
               }

               boolean var118 = var85;
               if (!var118) {
                  int var120 = var18;
                  MinecraftClient var119 = b;
                  var90 = var119;
                  MinecraftClient var86 = var119;
                  if (var120 != 0) {
                     break label117;
                  }

                  MinecraftClient var121 = var86;
                  MinecraftClient var87 = var121;
                  MinecraftClient var42 = var87;
                  ClientPlayerEntity var43 = var42.player;
                  ItemStack var44 = var43.getMainHandStack();
                  boolean var122 = var44.getItem() instanceof AxeItem;
                  if (!var122) {
                     int var124 = var18;
                     MinecraftClient var123 = b;
                     var90 = var123;
                     MinecraftClient var88 = var123;
                     if (var124 != 0) {
                        break label117;
                     }

                     MinecraftClient var125 = var88;
                     MinecraftClient var89 = var125;
                     MinecraftClient var47 = var89;
                     ClientPlayerEntity var48 = var47.player;
                     Object[] var49 = new Object[]{var48.getMainHandStack(), 91643301200230L};
                     boolean var126 = InventoryUtil.o(var49);
                     if (!var126) {
                        BooleanSetting var51 = this.a;
                        Boolean var52 = (Boolean)var51.aReturningObject();
                        boolean var127 = var52;
                        if (var127) {
                           return;
                        }
                     }
                  }
               }

               var90 = b;
            }

            MinecraftClient var55 = var90;
            HitResult var19 = var55.crosshairTarget;
            int var129 = var18;
            HitResult var128 = var19;
            HitResult var92 = var128;
            HitResult var91 = var128;
            if (var129 == 0) {
               HitResult var130 = var91;
               if (var130 == null) {
                  return;
               }

               var92 = var19;
            }

            Object var99;
            label87: {
               label120: {
                  HitResult var57 = var92;
                  Type var148 = var57.getType();
                  int var133 = var18;
                  Type var132 = Type.MISS;
                  Type var131 = var148;
                  Type var95 = var131;
                  Type var96 = var132;
                  Type var93 = var131;
                  Type var94 = var132;
                  if (var133 == 0) {
                     Type var135 = var94;
                     Type var134 = var93;
                     if (var134 == var135) {
                        break label120;
                     }

                     HitResult var59 = var19;
                     Type var149 = var59.getType();
                     Type var137 = Type.BLOCK;
                     Type var136 = var149;
                     var95 = var136;
                     var96 = var137;
                  }

                  Type var139 = var96;
                  Type var138 = var95;
                  if (var138 != var139) {
                     return;
                  }

                  MinecraftClient var61 = b;
                  int var141 = var18;
                  ClientPlayerEntity var140 = var61.player;
                  var99 = var140;
                  ClientPlayerEntity var97 = var140;
                  if (var141 != 0) {
                     break label87;
                  }

                  ClientPlayerEntity var142 = var97;
                  ClientPlayerEntity var98 = var142;
                  ClientPlayerEntity var63 = var98;
                  Object[] var64 = new Object[]{var63.getMainHandStack(), 19476550655932L};
                  boolean var143 = InventoryUtil.aReturningBoolean(var64);
                  if (!var143) {
                     return;
                  }
               }

               Object[] var68 = new Object[]{47156005839945L};
               SilentAim var67 = this;
               var99 = var67.aReturningEntity(var68);
            }

            Object var20 = var99;
            Object var144 = var20;
            if (var144 != null) {
               Object[] var71 = new Object[]{var20, 90037552387373L};
               SilentAim var70 = this;
               Object[] var72 = new Object[]{var70.aReturningVec3d(var71), 43890541083073L};
               Rotation var21 = RotationUtil.aReturningdx_C0210(var72);
               int var146 = var18;
               SilentAim var145 = this;
               SilentAim var101 = var145;
               SilentAim var100 = var145;
               if (var146 == 0) {
                  Object[] var74 = new Object[]{var21, 19411395928205L};
                  SilentAim var73 = var100;
                  boolean var147 = var73.aReturningBoolean(var74);
                  if (var147) {
                     return;
                  }

                  this.n = (Entity)var20;
                  var101 = this;
               }

               var101.k = dev.prestige.recovery.SourceSupport.asBoolean(1);
               Object[] var78 = new Object[0];
               AttackAttemptEvent var77 = var1;
               var77.aReturningVoid(var78);
            }
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var4;
      long var8;
      long var10;
      long var12;
      int var14;
      Entity var15;
      boolean var59;
      label106: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 24822184201257L;
         long var6 = var2 ^ 95313958864170L;
         var8 = var2 ^ 42474886202141L;
         var10 = var2 ^ 29417629257502L;
         var12 = var2 ^ 120480305610061L;
         int var10000 = Event.bReturningInt();
         var15 = this.n;
         var14 = var10000;
         int var77 = var14;
         SilentAim var76 = this;
         SilentAim var58 = var76;
         SilentAim var55 = var76;
         if (var77 == 0) {
            var55.n = null;
            Entity var78 = var15;
            if (var78 != null) {
               Entity var18 = var15;
               boolean var112 = var18.isAlive();
               int var80 = var14;
               boolean var79 = var112;
               var59 = var79;
               boolean var56 = var79;
               if (var80 != 0) {
                  break label106;
               }

               boolean var81 = var56;
               boolean var57 = var81;
               boolean var82 = var57;
               if (!var82) {
                  var15 = null;
               }
            }

            var58 = this;
         }

         Object[] var22 = new Object[]{var6};
         SilentAim var21 = var58;
         var59 = var21.dReturningBoolean(var22);
      }

      int var84 = var14;
      boolean var83 = var59;
      boolean var61 = var83;
      boolean var60 = var83;
      if (var84 == 0) {
         boolean var85 = var60;
         if (var85) {
            this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.m = null;
            return null;
         }

         BooleanSetting var25 = this.c;
         Boolean var26 = (Boolean)var25.aReturningObject();
         var61 = var26;
      }

      SilentAim var71;
      label114: {
         Rotation var16;
         label110: {
            int var87 = var14;
            boolean var86 = var61;
            boolean var70 = var86;
            boolean var62 = var86;
            if (var87 == 0) {
               boolean var88 = var62;
               if (var88) {
                  int var90 = var14;
                  Entity var89 = var15;
                  Entity var65 = var89;
                  Entity var63 = var89;
                  if (var90 == 0) {
                     Entity var91 = var63;
                     Entity var64 = var91;
                     Entity var92 = var64;
                     if (var92 == null) {
                        Object[] var31 = new Object[]{var4};
                        SilentAim var30 = this;
                        var15 = var30.aReturningEntity(var31);
                     }

                     var65 = var15;
                  }

                  Entity var93 = var65;
                  Rotation var66;
                  if (var93 != null) {
                     Object[] var33 = new Object[]{var15, var10};
                     SilentAim var32 = this;
                     Rotation var94 = var32.bReturningdx_C0210(var33);
                     var66 = var94;
                  } else {
                     var66 = null;
                  }

                  var16 = var66;
                  int var95 = var14;
                  if (var95 != 0) {
                     break label110;
                  }

                  Rotation var96 = var16;
                  if (var96 != null) {
                     Object[] var37 = new Object[]{var15, var12};
                     SilentAim var36 = this;
                     this.m = var36.aReturningVec3d(var37);
                     break label110;
                  }

                  this.m = null;
               }

               int var102 = var14;
               SilentAim var101 = this;
               var71 = var101;
               SilentAim var69 = var101;
               if (var102 != 0) {
                  break label114;
               }

               boolean var103 = var69.k;
               var70 = var103;
            }

            boolean var104 = var70;
            if (!var104) {
               return null;
            }

            var71 = this;
            break label114;
         }

         int var98 = var14;
         SilentAim var97 = this;
         SilentAim var68 = var97;
         SilentAim var67 = var97;
         if (var98 == 0) {
            boolean var99 = var67.k;
            if (!var99) {
               return var16;
            }

            this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
            SilentAim var100 = this;
            var68 = var100;
         }

         Object[] var42 = new Object[]{var15, var8};
         SilentAim var41 = var68;
         var41.jReturningVoid(var42);
         return var16;
      }

      int var106 = var14;
      SilentAim var105 = var71;
      SilentAim var73 = var105;
      SilentAim var72 = var105;
      if (var106 == 0) {
         var72.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
         Entity var107 = var15;
         if (var107 == null) {
            return null;
         }

         var73 = this;
      }

      Object[] var48 = new Object[]{var15, var10};
      SilentAim var47 = var73;
      Rotation var111 = var47.bReturningdx_C0210(var48);
      int var109 = var14;
      Rotation var108 = var111;
      Rotation var75 = var108;
      Rotation var74 = var108;
      if (var109 == 0) {
         Rotation var110 = var74;
         if (var110 == null) {
            return null;
         }

         Object[] var52 = new Object[]{var15, var12};
         SilentAim var51 = this;
         this.m = var51.aReturningVec3d(var52);
         Object[] var54 = new Object[]{var15, var8};
         SilentAim var53 = this;
         var53.jReturningVoid(var54);
         var75 = var111;
      }

      return var75;
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Entity var2;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      int var17;
      MinecraftClient var79;
      var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 119525033668006L ^ var3;
      long var5 = var3 ^ 27887685274558L;
      var7 = var3 ^ 120874705695513L;
      var9 = var3 ^ 100759205243477L;
      var11 = var3 ^ 30682267688949L;
      var13 = var3 ^ 14883904865233L;
      var15 = var3 ^ 100824241608036L;
      var17 = Event.bReturningInt();
      int var99 = var17;
      MinecraftClient var98 = b;
      var79 = var98;
      MinecraftClient var74 = var98;
      label112:
      if (var99 == 0) {
         MinecraftClient var20 = var74;
         ClientPlayerEntity var21 = var20.player;
         Object[] var22 = new Object[]{var21.getMainHandStack(), var15};
         boolean var100 = InventoryUtil.aReturningBoolean(var22);
         if (!var100) {
            int var102 = var17;
            MinecraftClient var101 = b;
            var79 = var101;
            MinecraftClient var75 = var101;
            if (var102 != 0) {
               break label112;
            }

            MinecraftClient var103 = var75;
            MinecraftClient var76 = var103;
            MinecraftClient var25 = var76;
            ClientPlayerEntity var26 = var25.player;
            ItemStack var27 = var26.getMainHandStack();
            boolean var104 = var27.getItem() instanceof AxeItem;
            if (!var104) {
               int var106 = var17;
               MinecraftClient var105 = b;
               var79 = var105;
               MinecraftClient var77 = var105;
               if (var106 != 0) {
                  break label112;
               }

               MinecraftClient var107 = var77;
               MinecraftClient var78 = var107;
               MinecraftClient var30 = var78;
               ClientPlayerEntity var31 = var30.player;
               Object[] var32 = new Object[]{var31.getMainHandStack(), var5};
               boolean var108 = InventoryUtil.o(var32);
               if (!var108) {
                  BooleanSetting var34 = this.a;
                  Boolean var35 = (Boolean)var34.aReturningObject();
                  boolean var109 = var35;
                  if (var109) {
                     return null;
                  }
               }
            }
         }

         var79 = b;
      }

      Object var89;
      label101: {
         MinecraftClient var38 = var79;
         HitResult var18 = var38.crosshairTarget;
         BooleanSetting var39 = this.c;
         Boolean var40 = (Boolean)var39.aReturningObject();
         boolean var110 = var40;
         label100:
         if (!var110) {
            int var112 = var17;
            HitResult var111 = var18;
            HitResult var82 = var111;
            HitResult var80 = var111;
            if (var112 == 0) {
               HitResult var113 = var80;
               HitResult var81 = var113;
               HitResult var114 = var81;
               if (var114 == null) {
                  return null;
               }

               var82 = var18;
            }

            HitResult var43 = var82;
            Type var10000 = var43.getType();
            int var117 = var17;
            Type var116 = Type.MISS;
            Type var115 = var10000;
            Type var85 = var115;
            Type var86 = var116;
            Type var83 = var115;
            Type var84 = var116;
            if (var117 == 0) {
               Type var119 = var84;
               Type var118 = var83;
               if (var118 == var119) {
                  break label100;
               }

               HitResult var45 = var18;
               var10000 = var45.getType();
               Type var121 = Type.BLOCK;
               Type var120 = var10000;
               var85 = var120;
               var86 = var121;
            }

            Type var123 = var86;
            Type var122 = var85;
            if (var122 != var123) {
               return null;
            }

            MinecraftClient var47 = b;
            int var125 = var17;
            ClientPlayerEntity var124 = var47.player;
            var89 = var124;
            ClientPlayerEntity var87 = var124;
            if (var125 != 0) {
               break label101;
            }

            ClientPlayerEntity var126 = var87;
            ClientPlayerEntity var88 = var126;
            ClientPlayerEntity var49 = var88;
            Object[] var50 = new Object[]{var49.getMainHandStack(), var15};
            boolean var127 = InventoryUtil.aReturningBoolean(var50);
            if (!var127) {
               return null;
            }
         }

         var89 = var2;
      }

      int var129 = var17;
      Object var128 = var89;
      Object var91 = var128;
      Object var90 = var128;
      if (var129 == 0) {
         Object var130 = var90;
         if (var130 == null) {
            return null;
         }

         var91 = var2;
      }

      Object var54 = var91;
      byte var147 = ((byte)((((Entity)var54).isAlive()) ? 1 : 0));
      int var132 = var17;
      byte var131 = var147;
      int var93 = var131;
      byte var92 = var131;
      if (var132 == 0) {
         byte var133 = var92;
         if (var133 == 0) {
            return null;
         }

         MinecraftClient var56 = b;
         Entity var58 = var2;
         ClientPlayerEntity var57 = var56.player;
         float var148;
         int var134 = (var148 = var57.distanceTo(var58) - 3.0F) == 0.0F ? 0 : (var148 < 0.0F ? -1 : 1);
         var93 = var134;
      }

      int var136 = var17;
      int var135 = var93;
      int var95 = var135;
      int var94 = var135;
      if (var136 == 0) {
         int var137 = var94;
         if (var137 > 0) {
            return null;
         }

         MinecraftClient var61 = b;
         Entity var63 = var2;
         ClientPlayerEntity var62 = var61.player;
         byte var138 = ((byte)((var62.canSee(var63)) ? 1 : 0));
         var95 = var138;
      }

      int var140 = var17;
      int var139 = var95;
      int var97 = var139;
      int var96 = var139;
      if (var140 == 0) {
         int var141 = var96;
         if (var141 == 0) {
            return null;
         }

         Object[] var66 = new Object[]{var2, var13};
         byte var142 = ((byte)((BlockUtil.aReturningBoolean(var66)) ? 1 : 0));
         var97 = var142;
      }

      int var143 = var97;
      if (var143 == 0) {
         Object[] var70 = new Object[]{var2, var11};
         SilentAim var69 = this;
         Object[] var71 = new Object[]{var69.aReturningVec3d(var70), var7};
         Rotation var19 = RotationUtil.aReturningdx_C0210(var71);
         Object[] var73 = new Object[]{var19, var9};
         SilentAim var72 = this;
         boolean var144 = var72.aReturningBoolean(var73);
         return var144 ? null : var19;
      } else {
         return null;
      }
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 119525033668006L ^ var2;
      long var5 = var2 ^ 138181473313509L;
      MinecraftClient var28 = b;
      ClientPlayerEntity var29 = var28.player;
      Vec3d var8 = var29.getEyePos();
      int var10000 = Event.cReturningInt();
      Entity var30 = var4;
      Box var9 = var30.getBoundingBox();
      int var7 = var10000;
      Box var31 = var9;
      Box var32 = var9;
      double var10 = var31.maxY - var32.minY;
      int var82 = var7;
      double var78 = var10;
      double var71 = var78;
      double var73 = var80;
      double var67 = var78;
      double var69 = var80;
      if (var82 != 0) {
         double var99;
         int var83 = (var99 = var67 - var69) == 0.0 ? 0 : (var99 < 0.0 ? -1 : 1);
         if (var83 <= 0) {
            Entity var34 = var4;
            return var34.getEyePos();
         }

         Vec3d var36 = var8;
         Box var37 = var9;
         var73 = var37.minX;
         var71 = var36.x;
      }

      Box var38 = var9;
      double var43 = var38.maxX;
      double var41 = var73;
      double var39 = var71;
      double var12 = MathHelper.clamp(var39, var41, var43);
      Vec3d var45 = var8;
      Box var46 = var9;
      Box var47 = var9;
      double var52 = var47.maxZ;
      double var50 = var46.minZ;
      double var48 = var45.z;
      double var14 = MathHelper.clamp(var48, var50, var52);
      Vec3d var54 = var8;
      double var96 = var54.x - var12;
      Vec3d var55 = var8;
      double var97 = var96 * (var55.x - var12);
      Vec3d var56 = var8;
      double var10001 = var56.z - var14;
      Vec3d var57 = var8;
      double var16 = var97 + var10001 * (var57.z - var14);
      double var18 = Double.POSITIVE_INFINITY;
      Vec3d var20 = null;
      while (true) {
         int var85 = o.length;
         int var84 = var21;
         if (var84 < var85) {
            int var86 = var7;
            if (var86 == 0) {
               break;
            }

            label45: {
               MultiModeSetting var98 = this.g;
               Object[] var59 = new Object[]{o[var21], var5};
               MultiModeSetting var58 = var98;
               boolean var87 = var58.aReturningBoolean(var59);
               if (var87) {
                  Box var62 = var9;
                  double var22 = var62.minY + p[var21] * var10;
                  Vec3d var63 = var8;
                  double var24 = var63.y - var22;
                  double var26 = var16 + var24 * var24;
                  int var88 = var7;
                  if (var88 == 0) {
                     break label45;
                  }

                  double var100;
                  int var89 = (var100 = var26 - var18) == 0.0 ? 0 : (var100 < 0.0 ? -1 : 1);
                  if (var89 < 0) {
                     var18 = var26;
                     var20 = new Vec3d(var12, var22, var14);
                  }
               }

               var21++;
            }

            int var90 = var7;
            if (var90 != 0) {
               continue;
            }
         }

         int var92 = var7;
         Vec3d var91 = var20;
         Vec3d var76 = var91;
         Vec3d var75 = var91;
         if (var92 == 0) {
            return var76;
         }

         Vec3d var93 = var75;
         if (var93 != null) {
            var76 = var20;
            return var76;
         }
         break;
      }

      Entity var66 = var4;
      return var66.getEyePos();
   }

   private void jReturningVoid(Object[] var1) {
      Entity var2 = (Entity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 119525033668006L ^ var3;
      long var5 = var3 ^ 100708013164959L;
      long var7 = var3 ^ 19278212165939L;
      int var9 = Event.bReturningInt();
      int var17 = var9;
      Entity var16 = var2;
      Entity var15 = var16;
      Entity var14 = var16;
      if (var17 == 0) {
         Entity var18 = var14;
         if (var18 == null) {
            return;
         }

         PostAttackEvent var10000 = new PostAttackEvent();
         Object[] var12 = new Object[]{var5};
         PostAttackEvent var11 = var10000;
         var11.bReturningBoolean(var12);
         this.l = dev.prestige.recovery.SourceSupport.asBoolean(1);
         var15 = var2;
      }

      Object[] var13 = new Object[]{var15, var7};
      ItemUseUtil.aReturningVoid(var13);
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(MouseButtonEvent var1) {
      long var10001 = 113093996127583L ^ 83807219548438L;
      var10001 = 113093996127583L ^ 13313263847445L;
      var10001 = 113093996127583L ^ 71677357268126L;
      var10001 = 113093996127583L ^ 123764421108598L;
      var10001 = 113093996127583L ^ 131375234336210L;
      var10001 = 113093996127583L ^ 60714717065330L;
      var10001 = 113093996127583L ^ 131310095252195L;
      int var18 = Event.cReturningInt();
      int var81 = var18;
      MinecraftClient var80 = b;
      MinecraftClient var64 = var80;
      MinecraftClient var63 = var80;
      if (var81 != 0) {
         MinecraftClient var22 = var63;
         Screen var82 = var22.currentScreen;
         if (var82 != null) {
            return;
         }

         MinecraftClient var83 = b;
         var64 = var83;
      }

      MinecraftClient var25 = var64;
      byte var10000 = ((byte)((var25.isWindowFocused()) ? 1 : 0));
      int var85 = var18;
      byte var84 = var10000;
      byte var66 = var84;
      byte var65 = var84;
      if (var85 != 0) {
         byte var86 = var65;
         if (var86 == 0) {
            return;
         }

         Object[] var28 = new Object[]{117372919475530L};
         SilentAim var27 = this;
         var66 = ((byte)((var27.dReturningBoolean(var28)) ? 1 : 0));
      }

      int var88 = var18;
      byte var87 = var66;
      int var68 = var87;
      byte var67 = var87;
      if (var88 != 0) {
         byte var89 = var67;
         if (var89 != 0) {
            return;
         }

         Object[] var31 = new Object[0];
         MouseButtonEvent var30 = var1;
         var68 = var30.aReturningInt(var31);
      }

      int var91 = var18;
      int var90 = var68;
      int var70 = var90;
      int var69 = var90;
      if (var91 != 0) {
         int var92 = var69;
         if (var92 != 0) {
            return;
         }

         Object[] var34 = new Object[0];
         MouseButtonEvent var33 = var1;
         int var93 = var33.dReturningInt(var34);
         var70 = var93;
      }

      int var95 = var18;
      int var94 = var70;
      int var72 = var94;
      int var71 = var94;
      if (var95 != 0) {
         byte var97 = 1;
         int var96 = var71;
         if (var96 != var97) {
            return;
         }

         KeybindManager var114 = Prestige.q;
         Object[] var38 = new Object[0];
         MouseButtonEvent var37 = var1;
         int var122 = var37.aReturningInt(var38);
         Object[] var10004 = new Object[]{null, 24513948157481L};
         var10004[0] = var122;
         Object[] var40 = var10004;
         KeybindManager var39 = var114;
         byte var98 = ((byte)((var39.aReturningBoolean(var40)) ? 1 : 0));
         var72 = var98;
      }

      int var99 = var72;
      if (var99 == 0) {
         MinecraftClient var42 = b;
         HitResult var19 = var42.crosshairTarget;
         int var101 = var18;
         HitResult var100 = var19;
         HitResult var74 = var100;
         HitResult var73 = var100;
         if (var101 != 0) {
            HitResult var102 = var73;
            if (var102 == null) {
               return;
            }

            var74 = var19;
         }

         HitResult var44 = var74;
         Type var115 = var44.getType();
         Type var104 = Type.BLOCK;
         Type var103 = var115;
         if (var103 == var104) {
            MinecraftClient var45 = b;
            int var106 = var18;
            ClientPlayerEntity var105 = var45.player;
            Object var77 = var105;
            ClientPlayerEntity var75 = var105;
            if (var106 != 0) {
               ClientPlayerEntity var107 = var75;
               ClientPlayerEntity var76 = var107;
               ClientPlayerEntity var47 = var76;
               Object[] var48 = new Object[]{var47.getMainHandStack(), 19476550655932L};
               boolean var108 = InventoryUtil.aReturningBoolean(var48);
               if (!var108) {
                  return;
               }

               Object[] var51 = new Object[]{47156005839945L};
               SilentAim var50 = this;
               Entity var109 = var50.aReturningEntity(var51);
               var77 = var109;
            }

            Object var20 = var77;
            Object var110 = var20;
            if (var110 == null) {
               return;
            }

            Object[] var55 = new Object[]{var20, 90037552387373L};
            SilentAim var54 = this;
            Object[] var56 = new Object[]{var54.aReturningVec3d(var55), 43890541083073L};
            Rotation var21 = RotationUtil.aReturningdx_C0210(var56);
            int var112 = var18;
            SilentAim var111 = this;
            SilentAim var79 = var111;
            SilentAim var78 = var111;
            if (var112 != 0) {
               Object[] var58 = new Object[]{var21, 19411395928205L};
               SilentAim var57 = var78;
               boolean var113 = var57.aReturningBoolean(var58);
               if (var113) {
                  return;
               }

               this.n = (Entity)var20;
               var79 = this;
            }

            var79.k = dev.prestige.recovery.SourceSupport.asBoolean(1);
            Object[] var62 = new Object[0];
            MouseButtonEvent var61 = var1;
            var61.aReturningVoid(var62);
         }
      }
   }

   @EventListener
   public void a(AttackTargetUpdateEvent var1) {
      long var10001 = 45776362297850L ^ 3579841248691L;
      var10001 = 45776362297850L ^ 74088739222704L;
      var10001 = 45776362297850L ^ 15707564433467L;
      var10001 = 45776362297850L ^ 61597121493367L;
      var10001 = 45776362297850L ^ 132223311531223L;
      var10001 = 45776362297850L ^ 61661221373510L;
      int var16 = Event.bReturningInt();
      int var57 = var16;
      MinecraftClient var56 = b;
      MinecraftClient var48 = var56;
      MinecraftClient var47 = var56;
      if (var57 == 0) {
         MinecraftClient var20 = var47;
         Screen var58 = var20.currentScreen;
         if (var58 != null) {
            return;
         }

         MinecraftClient var59 = b;
         var48 = var59;
      }

      MinecraftClient var23 = var48;
      boolean var10000 = var23.isWindowFocused();
      int var61 = var16;
      boolean var60 = var10000;
      boolean var50 = var60;
      boolean var49 = var60;
      if (var61 == 0) {
         boolean var62 = var49;
         if (!var62) {
            return;
         }

         Object[] var26 = new Object[]{117372919475530L};
         SilentAim var25 = this;
         var50 = var25.dReturningBoolean(var26);
      }

      boolean var63 = var50;
      if (!var63) {
         MinecraftClient var27 = b;
         HitResult var17 = var27.crosshairTarget;
         int var65 = var16;
         HitResult var64 = var17;
         HitResult var52 = var64;
         HitResult var51 = var64;
         if (var65 == 0) {
            HitResult var66 = var51;
            if (var66 == null) {
               return;
            }

            var52 = var17;
         }

         HitResult var29 = var52;
         Type var76 = var29.getType();
         Type var68 = Type.BLOCK;
         Type var67 = var76;
         if (var67 == var68) {
            MinecraftClient var30 = b;
            int var70 = var16;
            ClientPlayerEntity var69 = var30.player;
            Object var55 = var69;
            ClientPlayerEntity var53 = var69;
            if (var70 == 0) {
               ClientPlayerEntity var71 = var53;
               ClientPlayerEntity var54 = var71;
               ClientPlayerEntity var32 = var54;
               Object[] var33 = new Object[]{var32.getMainHandStack(), 19476550655932L};
               boolean var72 = InventoryUtil.aReturningBoolean(var33);
               if (!var72) {
                  return;
               }

               Object[] var36 = new Object[]{47156005839945L};
               SilentAim var35 = this;
               Entity var73 = var35.aReturningEntity(var36);
               var55 = var73;
            }

            Object var18 = var55;
            Object var74 = var18;
            if (var74 == null) {
               return;
            }

            Object[] var40 = new Object[]{var18, 90037552387373L};
            SilentAim var39 = this;
            Object[] var41 = new Object[]{var39.aReturningVec3d(var40), 43890541083073L};
            Rotation var19 = RotationUtil.aReturningdx_C0210(var41);
            Object[] var43 = new Object[]{var19, 19411395928205L};
            SilentAim var42 = this;
            boolean var75 = var42.aReturningBoolean(var43);
            if (var75) {
               return;
            }

            Object[] var46 = new Object[0];
            AttackTargetUpdateEvent var45 = var1;
            var45.aReturningVoid(var46);
         }
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 76334392798589L ^ 63338776992445L;
      var10001 = 76334392798589L ^ 40759129046393L;
      int var8 = Event.cReturningInt();
      int var46 = var8;
      SilentAim var45 = this;
      SilentAim var42 = var45;
      SilentAim var41 = var45;
      if (var46 != 0) {
         BooleanSetting var19 = var41.h;
         Boolean var20 = (Boolean)var19.aReturningObject();
         boolean var47 = var20;
         if (!var47) {
            return;
         }

         var42 = this;
      }

      Vec3d var9 = var42.m;
      int var49 = var8;
      Vec3d var48 = var9;
      Object var44 = var48;
      Vec3d var43 = var48;
      if (var49 != 0) {
         Vec3d var50 = var43;
         if (var50 == null) {
            return;
         }

         FloatSetting var24 = this.i;
         var44 = var24.aReturningObject();
      }

      Float var25 = (Float)var44;
      float var10 = var25;
      Vec3d var26 = var9;
      float var11 = (float)(var26.x - var10);
      Vec3d var27 = var9;
      float var12 = (float)(var27.y - var10);
      Vec3d var28 = var9;
      float var13 = (float)(var28.z - var10);
      Vec3d var29 = var9;
      float var14 = (float)(var29.x + var10);
      Vec3d var30 = var9;
      float var15 = (float)(var30.y + var10);
      Vec3d var31 = var9;
      float var16 = (float)(var31.z + var10);
      ColorSetting var32 = this.j;
      Color var17 = (Color)var32.aReturningObject();
      Color var33 = var17;
      int var10002 = var33.getRed();
      Color var34 = var17;
      int var10003 = var34.getGreen();
      Color var35 = var17;
      int var10004 = var35.getBlue();
      short var10005 = 255;
      Color var36 = var17;
      int var38 = var36.getAlpha() + 55;
      Color var18 = new Color(var10002, var10003, var10004, Math.min(255, var38));
      RenderContext var10000 = var1.b;
      MeshBufferManager var53 = var1.a;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var17, 137403672065984L};
      var10011[7] = var16;
      var10011[6] = var15;
      var10011[5] = var14;
      var10011[4] = var13;
      var10011[3] = var12;
      var10011[2] = var11;
      var10011[1] = var53;
      var10011[0] = var10000;
      Object[] var39 = var10011;
      ShapeRenderer.hReturningVoid(var39);
      var10000 = var1.b;
      MeshBufferManager var54 = var1.a;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, var18, 106090074574852L};
      var10011[7] = var16;
      var10011[6] = var15;
      var10011[5] = var14;
      var10011[4] = var13;
      var10011[3] = var12;
      var10011[2] = var11;
      var10011[1] = var54;
      var10011[0] = var10000;
      Object[] var40 = var10011;
      ShapeRenderer.gReturningVoid(var40);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      this.m = null;
      this.n = null;
      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      this.m = null;
      this.n = null;
      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private boolean lambda$new$1(Color var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.h;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var12;
      Cipher var10000 = var12 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(138915143414899L << var13 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var11 = new String[7];
      String var16 = "YBñ4\u000b\"äG\b\u008cpè\u0099pÎb¿\bÂ\u0083\u00ad\u0015^zú¨\bÄ\\[\tÒ\u0094\fy\bÄ¿ò#í|Òç";
      int var18 = "YBñ4\u000b\"äG\b\u008cpè\u0099pÎb¿\bÂ\u0083\u00ad\u0015^zú¨\bÄ\\[\tÒ\u0094\fy\bÄ¿ò#í|Òç".length();
      char var15 = '\b';
      int var22 = -1;

      label54:
      while (true) {
         String var23 = var16.substring(++var22, var22 + var15);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var12.doFinal(var23.getBytes("ISO-8859-1"));
            String var36 = b(var19).intern();
            switch (var10001) {
               case 0:
                  var11[var17++] = var36;
                  if ((var22 += var15) >= var18) {
                     t = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(138915143414899L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[6];
                     String var4 = "ËaAëK?Ö«þ¦òHHÁØµ\u0082\u0088\u00119\u008cM K\u0000ñªOIF\u0010Â";
                     int var5 = "ËaAëK?Ö«þ¦òHHÁØµ\u0082\u0088\u00119\u008cM K\u0000ñªOIF\u0010Â".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var26[var10001] = var45;
                                 if (var2 >= var5) {
                                    r = var6;
                                    s = new Integer[6];
                                    o = new String[]{var11[0], var11[3], var11[4], var11[5], var11[6], var11[1], var11[2]};
                                    short var27 = 16774;
                                    long var34 = 2655927672849631855L;
                                    p = new double[]{0.95, 0.85, 0.7, 0.65, 0.35, 0.2, 0.05};
                                    break;
                                 }
                                 break;
                              default:
                                 var26[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0096û\u0087nø\u008b\u0086[\u008e\u0089<xUçw\u0016";
                                 var5 = "\u0096û\u0087nø\u008b\u0086[\u008e\u0089<xUçw\u0016".length();
                                 var2 = 0;
                           }

                           int var33 = var2;
                           var2 += 8;
                           var7 = var4.substring(var33, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var15 = var16.charAt(var22);
                  break;
               default:
                  var11[var17++] = var36;
                  if ((var22 += var15) < var18) {
                     var15 = var16.charAt(var22);
                     continue label54;
                  }

                  var16 = "\u0000ÙE,n¶¥r\be¸±üù\u0016r\u001a";
                  var18 = "\u0000ÙE,n¶¥r\be¸±üù\u0016r\u001a".length();
                  var15 = '\b';
                  var22 = -1;
            }

            var23 = var16.substring(++var22, var22 + var15);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19435;
      if (s[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = r[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])t.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fq", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         s[var3] = var15;
      }

      return s[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fq_C0304",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fq" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = v[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = u[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 3;
            yield var15;
         }
         case 1 -> {
            byte var16 = 46;
            yield var16;
         }
         case 2 -> {
            byte var17 = 40;
            yield var17;
         }
         case 3 -> {
            byte var18 = 32;
            yield var18;
         }
         case 4 -> {
            byte var19 = 43;
            yield var19;
         }
         case 5 -> {
            byte var20 = 15;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 20;
            yield var22;
         }
         case 8 -> {
            byte var23 = 19;
            yield var23;
         }
         case 9 -> {
            byte var24 = 38;
            yield var24;
         }
         case 10 -> {
            byte var25 = 56;
            yield var25;
         }
         case 11 -> {
            byte var26 = 0;
            yield var26;
         }
         case 12 -> {
            byte var27 = 61;
            yield var27;
         }
         case 13 -> {
            byte var28 = 35;
            yield var28;
         }
         case 14 -> {
            byte var29 = 24;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 48;
            yield var31;
         }
         case 17 -> {
            byte var32 = 27;
            yield var32;
         }
         case 18 -> {
            byte var33 = 9;
            yield var33;
         }
         case 19 -> {
            byte var34 = 54;
            yield var34;
         }
         case 20 -> {
            byte var35 = 60;
            yield var35;
         }
         case 21 -> {
            byte var36 = 6;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 12;
            yield var38;
         }
         case 24 -> {
            byte var39 = 31;
            yield var39;
         }
         case 25 -> {
            byte var40 = 25;
            yield var40;
         }
         case 26 -> {
            byte var41 = 23;
            yield var41;
         }
         case 27 -> {
            byte var42 = 17;
            yield var42;
         }
         case 28 -> {
            byte var43 = 47;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 58;
            yield var45;
         }
         case 31 -> {
            byte var46 = 1;
            yield var46;
         }
         case 32 -> {
            byte var47 = 16;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 55;
            yield var49;
         }
         case 35 -> {
            byte var50 = 22;
            yield var50;
         }
         case 36 -> {
            byte var51 = 49;
            yield var51;
         }
         case 37 -> {
            byte var52 = 2;
            yield var52;
         }
         case 38 -> {
            byte var53 = 5;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 21;
            yield var55;
         }
         case 41 -> {
            byte var56 = 13;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 41;
            yield var58;
         }
         case 44 -> {
            byte var59 = 51;
            yield var59;
         }
         case 45 -> {
            byte var60 = 53;
            yield var60;
         }
         case 46 -> {
            byte var61 = 44;
            yield var61;
         }
         case 47 -> {
            byte var62 = 57;
            yield var62;
         }
         case 48 -> {
            byte var63 = 50;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 7;
            yield var66;
         }
         case 52 -> {
            byte var67 = 34;
            yield var67;
         }
         case 53 -> {
            byte var68 = 11;
            yield var68;
         }
         case 54 -> {
            byte var69 = 59;
            yield var69;
         }
         case 55 -> {
            byte var70 = 10;
            yield var70;
         }
         case 56 -> {
            byte var71 = 14;
            yield var71;
         }
         case 57 -> {
            byte var72 = 42;
            yield var72;
         }
         case 58 -> {
            byte var73 = 45;
            yield var73;
         }
         case 59 -> {
            byte var74 = 4;
            yield var74;
         }
         case 60 -> {
            byte var75 = 52;
            yield var75;
         }
         case 61 -> {
            byte var76 = 8;
            yield var76;
         }
         case 62 -> {
            byte var77 = 28;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            v[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      u[0] = "R\u000e\u001bW$LD\u000e\u001e\r7[SE\u001d\u000b;OB\u0002\n\u001cpX\u007f";
      u[1] = "5\b)!\u0003{@(\".\u00124!&)%\u0016nU";
      u[2] = "j=Q 1S|=Tz\"DkvW|.Pz1@keGD";
      u[3] = "\u000e-\u0005y1w{\r\u000ev 8\u001a\u0003\u0005}$bn";
      u[4] = "I>{2Gr_>~hTeHu}nXqY2jy\u0013ch";
      u[5] = int.class;
      v[5] = "java/lang/Integer";
      u[6] = "bA9\u0006\u0002/tA<\\\u00118c\n?Z\u001d,rM(MV9w";
      u[7] = "\r3\u0014\nDix\u0013\u001f\u0005U&\u0019\u001d\u0014\u000eQ|m";
      u[8] = boolean.class;
      v[8] = "java/lang/Boolean";
      u[9] = "f]:G|^\u0013}1Hm\u0011rs:CiK\u0006";
      u[10] = "\u0007^#\u0018f\u0016\u0007^4Dj\u0019\u001d\u00154Zj\f\u001ade\u00028";
      u[11] = "K\u0015n\u0001WM>5e\u000eF\u0002_;n\u0005BX+";
      u[12] = "\u001b\u0017\b\u0006F\f\r\u0017\r\\U\u001b\u001a\\\u000eZY\u000f\u000b\u001b\u0019M\u0012\u0018\u0007";
      u[13] = "aKI1[J\u0014kB>J\u0005ueI5N_\u0001";
      u[14] = void.class;
      v[14] = "java/lang/Void";
      u[15] = "aF\u000b'H(jI\u001ah$+dK\u0018'\b";
      u[16] = ".._'}B..H{qM4eHeqX3\u0014\u001a;)\u001c";
      u[17] = "WcmT\u0007'Ach\u000e\u00140V(k\b\u0018$Go|\u001fS3u";
      u[18] = "o\u0007C\u0002@\u001ed\bRM!\u0010o\u0003V\u0017";
      u[19] = "5\u0016.\tM\u001b>\u0019?F.\u0016+\u00140-\u001b\u0014:\u0007,\u0001\f\u0019";
      u[20] = "p\nsw&\u001d\u0005*xx7Rd$ss3\b\u0010";
      u[21] = "\u0005A\u000eb\u000ey\u001bI\u0014-si\u001b";
      u[22] = "E[7*z\u0000E[ vv\u000f_\u0010 hv\u001aXaq7.MHR\"wd6\u0019\ns";
      u[23] = "\u0010\u0014n^\u001f\u0001\u0006\u0014k\u0004\f\u0016\u0011_h\u0002\u0000\u0002\u0000\u0018\u007f\u0015K\u00156";
      u[24] = "9,P\u000f?8L\f[\u0000.w-\u0002P\u000b*-Y";
      u[25] = "y3\b&\u000e\u000ey3\u001fz\u0002\u0001cx\u001fd\u0002\u0014d\tK<U";
      u[26] = "|6GQT\u0001|6P\rX\u000ef}P\u0013X\u001ba\f\u0002H\u0000Q";
      u[27] = "~wO\u0002\u0018u~wX^\u0014zd<X@\u0014ocM\b\u001dE";
      u[28] = ":2\u0000\u00049\n:2\u0017X5\u0005 y\u0017F5\u0010'\b@\u0019c";
      u[29] = "]\u001di,hl(=b#y#I3i(}y=";
      u[30] = "o\"B_\"\u0007o\"U\u0003.\buiU\u001d.\u001dr\u0018\u0004Bv";
      u[31] = "\u001a9\r}#So\u0019\u0006r2\u001c\u000e\u0017\ry6Fz";
      u[32] = "A]h`\n\fW]m:\u0019\u001b@\u0016n<\u0015\u000fQQy+^\u001fJ";
      u[33] = "\u0004:L-6^q\u001aG\"'\u0011\u0010\u0014L)#Kd";
      u[34] = "&\u0002u-,\\0\u0002pw?K'Isq3_6\u000edfxJ\u0017";
      u[35] = "4kS sUAKX/b\u001a ES$f@T";
      u[36] = "\u0017\u0007i\u0018\u0010&\u0017\u0007~D\u001c)\rL~Z\u001c<\n=,\u0000Hx";
      u[37] = "\u0011\r+|\u001cs\u0007\r.&\u000fd\u0010F- \u0003p\u0001\u0001:7Hb\u0019";
      u[38] = "v5;\r)\b\u0003\u00150\u00028Gb\u001b;\t<\u001d\u0016";
      u[39] = float.class;
      v[39] = "java/lang/Float";
      u[40] = "1M=~j/Dm6q{`%c=z\u007f:Q";
      u[41] = "Vy\u001ev\b\u007f@y\u001b,\u001bhW2\u0018*\u0017|Fu\u000f=\\kK";
      u[42] = "\u0003Z\u0005L\u001cUvz\u000eC\r\u001a\u0017t\u0005H\t@c";
      u[43] = "O)\u0013\n+AY)\u0016P8VNb\u0015V4B_%\u0002A\u007fRG%\u0000J%\u001f{>\u0000W%XL)";
      u[44] = "\u0018'4\u001e\u001dTm\u0007?\u0011\f\u001b\f\t4\u001a\bAx";
      u[45] = "+ui?Mj+u~cAe1>~}Ap6O,&\u00191";
      u[46] = "(88YL?>8=\u0003_()s>\u0005S<84)\u0012\u0018+\u001d";
      u[47] = "7\u0019N%1G!\u0019K\u007f\"P6RHy.D'\u0015_neU1";
      u[48] = "\ney}Q*\u007fErr@e\u001eKyyD?j";
      u[49] = "6}c4MRC]h;\\\u001d\"Sc0XGV";
      u[50] = "\u00009+T\u0007M\u00169.\u000e\u0014Z\u0001r-\b\u0018N\u00105:\u001fS^.";
      u[51] = "\u0014\u0001|\u0012P]a!w\u001dA\u0012\u0000/|\u0016EHt";
      u[52] = "w9/!X\u001c\u0002\u0019$.ISc\u0017/%M\t\u0017";
      u[53] = "\u000fOW\u00136\u0011\u0019ORI%\u0006\u000e\u0004QO)\u0012\u001fCFXb\u0016";
      u[54] = "\u0001&X\u000e<Z\u0017&]T/M\u0000m^R#Y\u0011*IEhH$";
      u[55] = "rp\u007f^uW\u0007PtQd\u0018f^\u007fZ`B\u0012";
      u[56] = "J:\u000ft[f?\u001a\u0004{J)^\u0014\u000fpNs*";
      u[57] = double.class;
      v[57] = "java/lang/Double";
      u[58] = "yUS\u001eh\u0018d@\u000b<)\u0015|F";
      u[59] = "E9\r?\u0019uS9\be\nbDr\u000bc\u0006vU5\u001ctMaW";
      u[60] = "O\\2\u0013\u0001^:|9\u001c\u0010\u0011[r2\u0017\u0014K/";
      u[61] = "[,\u001bpw3P#\n?\u001f3^,\u0019";
      u[62] = "(\u0005E*\u0011\u0002]%N%\u0000M<+E.\u0004\u0017H";
      u[63] = "\u001d\u001d\u0003vJ(\u0016\u0012\u00129)%\u0003\u0014";
      u[64] = "\n{G#?}\u007f[L,.2\u001eUG'*hj";
      u[65] = "\u0004xE$\u000e\u000eqXN+\u001fA\u0010VE \u001b\u001bd";
      u[66] = "\u000b;k\u0019\u00000~\u001b`\u0016\u0011\u007f\u001f\u0015k\u001d\u0015%k";
      u[67] = "eTE\u0003z\u001b\u0010tN\fkTqzE\u0007o\u000e\u0005";
      u[68] = "1\u0010KhSB'\u0010N2@U0[M4LA!\u001cZ#\u0007Q9";
      u[69] = "x\u001bc\u0003|+\r;h\fmdl5c\u0007i>\u0018";
      u[70] = "x\u0015[#\u0011Jn\u0015^y\u0002]y^]\u007f\u000eIh\u0019JhE^R";
      u[71] = "k\u0000\u0011cu3\u001e \u001ald|\u007f.\u0011g`&\u000b";
      u[72] = "yV\u007f#X<yVh\u007fT3c\u001dhaT&dl9>\r";
      u[73] = "\u0005`<U/g\u0005`+\t#h\u001f++\u0017#}\u0018Z{Nq<";
      u[74] = "1\u0017\u0018\u0013C\u0005a\tB\u0007}\u000e>\u001c\u001c\u0016*YdJBz\u0013\u0006?\u0018F\u001fC\u0018e\f";
      u[75] = "v\u000euBOq~M1T]\r _uaYu/[\t\u0013Bb,BbNScr2";
      u[76] = ".x\\;|\u007fw+\u0017v+\u0015yuC\"+B./\u0014|G,,dB4vwg.\u0011+";
      u[77] = "=\fsy\u001d85\u0011z8z;=\u001buj-lcK,\u0006\u0018*8\u0011 b\u001f8cI";
      u[78] = "\\e{|1\u0006\u001fy-{W\r`%q}k\u0018\u001fd$'*\u0004`,z 5\u0000\u001f`fg9g";
      u[79] = "^w\r+CkZq\u001e,9wSq\u0017uUE\u00053K/\u0005\u0012D0GpV\u007f\u0007gF)9";
      u[80] = "\u00014\u0011E4\u0016\u00143\u001d\tN\u0003zu\u0010Qr\u0010\u00054E\u000b3\fz%@\b%\b\u0001w\u0000J6o";
      u[81] = "6=`7\u001aq> iv}y:;b/\u0011Knz<y}\"j+z,\u0013$n<3H";
      u[82] = "\u001eL2\\@B\\\u0002 J<M'\u0004/H\u0000[XEz\u0012AG'\u00042\\MXAF|N[$";
      u[83] = "Qz:}b/Qa=po\u001f\u0001\u0010y{c#\u0017o8.9b\u000b\u0010)+:t\u000fk{kxgh";
      u[84] = "6s\u001b\u0015u<2u\b\u0012\u000f ;u\u0001Kc\u0012m7]\u00112E,4QN`(ocP\u0017\u000f";
      u[85] = "\u007fQB\u00142\u001a<W\u0010LKCD\u0007\u0013\u0016wU;FFL6IDWCO M?\u0005\u0003\r3*";
      u[86] = "|+jt6Au',?:\",q/O#\u001fuy;\"`Ht T5d\u0012't9v3\u0013~\u001b";
      u[87] = "_aI!\f0\u00062\u0002l[Z\blV8[\r_6\u0001e7c]}W.\u00068\u00167\u00041";
      u[88] = "b\u0006WI3C&UIAs=>\u0006NH-Q\fR\u000f\u0013w\u0005[R\tX&Oj\tB\u0012uP[R\tX&Oj\tB\u0012uP[R\tX&Oj\tB\u0012uP[R\tX&Oj\tB\u0012uP[";
      u[89] = "8%jw6\u00020f.a$~ntjG)\u0012\u0001\"ir'\u000ej\u007fxsy~";
      u[90] = "Cj\u001cgh%Gl\u000f`\u00129Nl\u00069~\u000b\u0018+[a+\\\u001cq\\#qlNa\u0019=\u0012";
      u[91] = "*G\u001d\u001aFxxWX\u0004%&tKC\u000brq.\u001b\u001dg\u001cseJUVG8/\u0019J";
      u[92] = "+6~\u001aa\ty&;\u0004\u0002Wu: \u000bU\u0000/j}g;\u0002d;6V`I.h)";
      u[93] = "Is!zkY\now}\rQu3+{1G\nr~!p[u5&$p[Eg6an8";
      u[94] = "a\u000f\tD\u000eB\"\u0013_ChJ]O\u0003ET\\\"\u000eV\u001f\u0015@]HRL\u0010G3NV[Y#";
      u[95] = "]\u001a$Y\u000fg\u0004Io\u0014X\r\n\u0017;@XZ]Ml\u001c44_\u0006:V\u0005o\u0014LiI";
      u[96] = "p;h%Dux&ad#vp,n6t!.\u007f7ZG%+{q'\u001f|-3";
      u[97] = "\u0000@J^\u0006RCF\u0018\u0006\u007f\b;\u0016\u001b\\C\u001dDWN\u0006\u0002\u0001;\u0011JU\u0007\u0006U\u0017NBNb";
      u[98] = "g\u00011`p\u001cdC1,u-48x}h\u0011!G9(2P=8(-1F9CzmsU^";
      u[99] = "Ye% \u0011\u007f\u00006nmF\u0015\u000eh:9FBY2mf*,[y;/\u001bw\u00103h0";
      u[100] = "\u0003l\rT]3[5\u000b\u001c&+\n-W\tJ\u0019^n\b^\u001dN\t7W\u0007\u0018+Y)\r\u0013&";
      u[101] = "\rjE1Hq\u0012lH`sek.CeOs\u0014o\u0016?\u000eok}E~Hh\u0002f\u001fp\u0016\f";
      u[102] = "$\u000f5Sh\u0006\u007f\u00032Gr9r26Fi\u0005bMw\u00133D~2f\u00160RzI4VrA\u001d";
      u[103] = "Y\u001a**ml\u000eH-*\u0010t6A&7,aI\u0000smm}6\u0002wbrq[A c+\u001e";
      u[104] = "6p\u0014blFkbU.\u0002\u0012S2\u0002{>\u0004,sW!\u007f\u0018S5Srz\u001f=3We3{";
      u[105] = "Dqf\u0015)\u0007L2\"\u0003;{\u0012 f0!\u0016\u0010+\u001aD$\u0014\u001e=q\u00195\u0015@M";
      u[106] = "{\u00156N]\u00058\u0013d\u0016$_@AtFGE+\u001ceG\u00195";
      u[107] = "~,I}\u0019 )~N}d;\u0011wE`X-n6\u0010:\u00191\u0011~N=\u00065n2Rz\nR";
      u[108] = "]s\u0010\f<Z\u001aeW@)4\r\u0018W\\6\b\u001bg\u0016\tlI\u0007\u0018P\r?L\u0000vV\t(\u0005d";
      u[109] = "\u00172WZs\u0016KpW[\nH\u001bqS\u0001fzI<\u000bW\nS\u00103^\r{D\fm\rf";
      u[110] = "@A\u000f0{\u001e\u0010_U$E\u0015OJ\u000b5\u0012B\u0015\u001cTY+\u001dNNQ<{\u0003\u0014Z";
      u[111] = "\u001aC!\u001cht\u000e\u001f&J\f(\u001ay5\u000b<1\u001b\u0004?\u0014rtt\u0012 Er \t\u0018?\u000b7O\u001aC!\u001cht\u000e\u001f&J\f";
      u[112] = "62\u0016G\b\u0005m>\u0011S\u0012:o\u000f\u0015R\t\u0006ppT\u0007SGl\u000fE\u0002PQht\u0017B\u0012B\u000f";
      u[113] = "2\fe;;!q\n7cBx\tZ49~nv\u001bac?r\tZal%|1Sb<</\t";
      u[114] = "W?T)>2Y.YaS8Y;A}:4`5Am>R\u0000aIh7<\u0006e^!S";
      u[115] = "\b*\u0013/HZ\u0013p\u001dq,V\u000f<\rs@d_pU),\r_,\u0015pB\u000b[;\\\u0014";
      u[116] = "HAp1\u001d!\u000bG\"idzs\u001529\u0007a\u0018H#8Y\u0011";
      u[117] = "S#b\u0018_e\u0013*#Z?0*pw\u0003\u0003&U1\"YB:*w&\nG=Dq\"\u001d\u000eY";
      u[118] = ".y9-F<5#7s\"0)o'qN\u0002y#}'\"l(a:-H5{*wz\"";
      u[119] = "K\u001emU\u0017\u000e\u0010\u0002bB{\u0017 \u0019\u007f\b\u0005\u0011]\u0013`F@~";
      u[120] = "wi\u0003SK2so\u0010T1.zo\u0019\r]\u001c*,B[1!}mB\u000eX:'c\u001cjKv'q\u0016\u0007\b!&(y";
      u[121] = "\n=lL\u0018@\u001aqaD\"Sz5=F\u001eE\u0005th\u001c_Yz7.LAJ\u0011j?M\u001f:";
      u[122] = "\u0000(0Ky\u0015R8uU\u001aK^$nZM\u001c\u0004t26#\u001eO%x\u0007xU\u0005vg";
      u[123] = "\u0013p\u0018GN<\u0017v\u000b@4 \u001ev\u0002\u0019X\u0012M2_A4/\u0019tY\u001a]4Cz\u0007~\nx\u001fr\u0006\u0010\f|\b;b";
      u[124] = "c>QPehv9]\u001c\u001f|\u0018\u007fPD#ng>\u0005\u001ebr\u0018/\u0000\u001dtvc}@_g\u0011";
      u[125] = "Em\\Q^k\u001c>\u0017\u001c\t\u0001\u0012`CH\tVE:\u0014\u0011e8GqB^Tc\f;\u0011A";
      u[126] = "Kf\\<v]C{U}\u0011^KqZ/F\t\u0015&\u0002CqJP%D:uLC\"";
      u[127] = "]di\u0016\u00021\u001ex?\u0011d9aqh\u001b\u0001-\u0010~h\u0015\u001eP\rzf\u0017\u0019!\u0002zh\bd";
      u[128] = "{\u0010W/\u001bqiI\u0007`\u007f}\u0006P\u0011r\u000e`\u007fE\u0016~B";
      u[129] = "?+p\u0006]56v6^!<M(`Y\u001d*2i5\u0003\\6M/1PY1#)5G\u0010U";
      u[130] = ";c\u0012\u0003ciw\u007fU\u000f\u0004\u007f\u000b=F\u00048it|\u0013^yu\u000b~\u0017Qfyf=@P?\u0016";
      u[131] = "\u0019kI3nK@8\u0002~9!NfV*9v\u0019<\u0001rU\u0018\u001bwW<dCP=\u0004#";
      u[132] = "\u001biF\u0003.Q\u0012e\u0000H\"2G8\u001e8zMM:\bS'\\Ldx\u0003>]A)\u0013^/\\\u001fYCG.QR2\u001eV/\u000f\"";
      u[133] = "~i0f}\u0011#{q*\u0013K\u001b+&\u007f/Sdjs%nO\u001b,wvkHu*sa\",";
      u[134] = "\u001ef\u0002\u0003g\f\u000e*\u000f\u000b]\u001annS\ta\t\u0011/\u0006S \u0015nl@\u0003>\u0006\u00051Q\u0002`v";
      u[135] = "\u0018NUit\n[R\u0003n\u0012\u0007$\u000e_h.\u0014[O\n2o\b$\t\u000eaj\u000fJ\u000f\nv#k";
      u[136] = "(\u0005\u007fI\u0003\t F;_\u0011u~T\u007fi\u0015\b|98\\\u001e\u0016aReM\u001fH\u0011";
      u[137] = "cB5\u001e\u0002ux\u0018;@fydT+B\nK2\u0013v\u001a_\u001c6IqX\u0005,dY4Ff";
      u[138] = "b U\b\u0018#f&F\u000fb?o&OV\u000e\r<b\u0013\u000eb;=>\u0013HYg\u007f>\u00121";
      u[139] = "g2\u001a?lLx4\u0017nWX\u0001v\u001ckkN~7I1*R\u00017\u001bb0Wzu\n~'1";
      u[140] = "+pmv!cgl*zFv\u001b.9qzcdol+;\u007f\u001bmh$$sv.?%}\u001c";
      u[141] = "\bzS2^UKf\u000558V4:Y3\u0004KK{\fiEW4j\tjSSO8I(@4";
      u[142] = "s.>(EAjs>F\u001d/)~bz\u000bPh+8;\u0017/s.>(EAjs>F";
      u[143] = "x\u0019\u000f>e[i\u001cQz\u001f_\u0007IT,gRiOP;.6";
      u[144] = "\u000e-5lQe\u001cte#5wsd1 \u000fr\u0013mlfW";
      u[145] = "a?,,yK<</ez76e-}ci1e7y\u001fMe1({r\u000e20q\u0014";
      u[146] = ";Y\u0018K>pxENLXx\u0007\u0019\u0012JdnxXG\u0010%r\u0007J\u0014QcunQN_=\u0011";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = u[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(v[var4]);
            u[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            u[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  u[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1306869299428863L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = u[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  u[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1306869299428863L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        u[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1306869299428863L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 205;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 68;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 71;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 196;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 85;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 205;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 68;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 71;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fq_C0304",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fq" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(SilentAim var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fq_C0304;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fq_C0304", "lambda$new$1", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((SilentAim)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(SilentAim var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fq_C0304;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fq_C0304", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((SilentAim)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
