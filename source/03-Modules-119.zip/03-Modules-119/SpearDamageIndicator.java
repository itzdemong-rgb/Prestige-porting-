package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.api.util.ExpiringValue;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.util.Easing;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.component.type.KineticWeaponComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class SpearDamageIndicator extends Module {
   private static final float a = 20.0F;
   private static final float c = 4.0F;
   private ExpiringValue d;
   private float e;
   private static final long k = 11982045400830L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[79];
   private static final String[] s = new String[79];

   public SpearDamageIndicator() {
      super();
      long var10001 = 74175618111562L ^ 68538417624913L;

      this.d = new ExpiringValue(500.0F, false, Easing.BACK_IN_OUT, 137591480872731L);
      this.e = 0.0F;
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Spear;
      return Set.of(var4);
   }

   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      int var28;
      boolean var133;
      label66: {
         boolean var132;
         label65: {
            label69: {
               long var10001 = 27340636413862L ^ 33986973467556L;
               var10001 = 27340636413862L ^ 26282727346523L;
               var10001 = 27340636413862L ^ 125510979825051L;
               var10001 = 27340636413862L ^ 34506388872789L;
               var10001 = 27340636413862L ^ 126906754428906L;
               var10001 = 27340636413862L ^ 29395743096212L;
               var10001 = 27340636413862L ^ 61510274827993L;
               var10001 = 27340636413862L ^ 36518820184279L;
               var10001 = 27340636413862L ^ 102275407103883L;
               var10001 = 27340636413862L ^ 19673501280549L;
               var10001 = 27340636413862L ^ 132896177445267L;
               var10001 = 27340636413862L ^ 104012000063159L;
               var28 = Event.bReturningInt();
               Object[] var58 = new Object[]{Items.NETHERITE_SPEAR, 8519502184947L};
               boolean var10000 = InventoryUtil.lReturningBoolean(var58);
               int var149 = var28;
               boolean var148 = var10000;
               boolean var130 = var148;
               boolean var129 = var148;
               if (var149 == 0) {
                  boolean var150 = var129;
                  if (!var150) {
                     break label69;
                  }

                  MinecraftClient var60 = b;
                  ClientPlayerEntity var61 = var60.player;
                  boolean var151 = var61.isUsingItem();
                  var130 = var151;
               }

               int var153 = var28;
               boolean var152 = var130;
               var132 = var152;
               boolean var131 = var152;
               if (var153 != 0) {
                  break label65;
               }

               boolean var154 = var131;
               if (var154) {
                  var132 = true;
                  break label65;
               }
            }

            var133 = false;
            break label66;
         }

         boolean var155 = var132;
         var133 = var155;
      }

      boolean var29 = var133;
      boolean var156 = var29;
      PlayerEntity var134;
      if (var156) {
         Object[] var64 = new Object[]{77260333461777L};
         PlayerEntity var157 = EntityUtil.aReturningPlayerEntity(var64);
         var134 = var157;
      } else {
         var134 = null;
      }

      PlayerEntity var30 = var134;
      PlayerEntity var159 = var30;
      ExpiringValue var158 = this.d;
      ExpiringValue var136 = var158;
      ExpiringValue var135 = var158;
      ExpiringValue var137;
      boolean var138;
      if (var159 != null) {
         boolean var161 = true;
         ExpiringValue var160 = var135;
         var137 = var160;
         var138 = var161;
      } else {
         var138 = false;
         var137 = var136;
      }

      Object[] var10004 = new Object[]{null, 118431390085196L};
      var10004[0] = var138;
      Object[] var68 = var10004;
      ExpiringValue var67 = var137;
      var67.aReturningVoid(var68);
      ExpiringValue var174 = this.d;
      Object[] var70 = new Object[]{76800015505453L};
      ExpiringValue var69 = var174;
      float var31 = var69.aReturningFloat(var70);
      float var209;
      int var162 = (var209 = var31 - 0.01F) == 0.0F ? 0 : (var209 < 0.0F ? -1 : 1);
      if (var162 > 0) {
         MinecraftClient var72 = b;
         ClientPlayerEntity var73 = var72.player;
         Vec3d var32 = var73.getRotationVector();
         MinecraftClient var74 = b;
         ClientPlayerEntity var75 = var74.player;
         Vec3d var77 = KineticWeaponComponent.getAmplifiedMovement((Entity)var75);
         Vec3d var76 = var32;
         double var33 = var76.dotProduct(var77);
         MinecraftClient var78 = b;
         RegistryEntry var80 = EntityAttributes.ATTACK_DAMAGE;
         ClientPlayerEntity var79 = var78.player;
         double var35 = var79.getAttributeBaseValue(var80);
         PlayerEntity var163 = var30;
         double var139;
         if (var163 == null) {
            var139 = var164;
         } else {
            PlayerEntity var82 = var30;
            Vec3d var84 = KineticWeaponComponent.getAmplifiedMovement((Entity)var82);
            Vec3d var83 = var32;
            var139 = var83.dotProduct(var84);
         }

         Matrix4f var42;
         float var43;
         float var44;
         float var45;
         float var46;
         String var143;
         label49: {
            double var37 = var139;
            double var87 = var33 - var37;
            double var39 = Math.max(var85, var87);
            float var175 = (float)var35;
            double var89 = var39 / 2.0;
            float var41 = var175 + MathHelper.floor(var89);
            float var197 = this.e;
            Object[] var91 = new Object[]{105570054506037L};
            float var10003 = GameRenderUtil.aReturningFloat(var91) / 5.0F;
            Object[] var10006 = new Object[]{null, null, null, 6822716038146L};
            var10006[2] = var10003;
            var10006[1] = var41;
            var10006[0] = var197;
            Object[] var92 = var10006;
            this.e = ClientUiUtil.bReturningFloat(var92);
            var42 = new Matrix4f();
            var43 = 64.0F;
            var44 = 20.0F;
            MinecraftClient var93 = b;
            Window var94 = var93.getWindow();
            var45 = var94.getScaledWidth() / 2.0F - var43 / 2.0F;
            MinecraftClient var95 = b;
            Window var96 = var95.getWindow();
            var46 = var96.getScaledHeight() / 2.0F + 30.0F;
            var197 = var45 + var43 / 2.0F;
            float var10002 = var46 + var44 / 2.0F;
            float var100 = 0.0F;
            float var99 = var10002;
            float var98 = var197;
            Matrix4f var97 = var42;
            var97.translate(var98, var99, var100);
            float var104 = var31;
            float var103 = var31;
            float var102 = var31;
            Matrix4f var101 = var42;
            var101.scale(var102, var103, var104);
            var197 = -var45 - var43 / 2.0F;
            var10002 = -var46 - var44 / 2.0F;
            float var108 = 0.0F;
            float var107 = var10002;
            float var106 = var197;
            Matrix4f var105 = var42;
            var105.translate(var106, var107, var108);
            MeshBufferManager var176 = var1.a;
            RenderContext var200 = var1.b;
            Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 16745277116157L};
            var10011[8] = 5.0F;
            var10011[7] = 5;
            var10011[6] = var44;
            var10011[5] = var43;
            var10011[4] = var46;
            var10011[3] = var45;
            var10011[2] = var42;
            var10011[1] = var200;
            var10011[0] = var176;
            Object[] var109 = var10011;
            BlurredRectangleRenderer.eReturningVoid(var109);
            MeshBufferManager var177 = var1.a;
            RenderContext var201 = var1.b;
            Color var10007 = new Color(14, 14, 14, 150);
            var10011 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
            var10011[8] = 5.0F;
            var10011[7] = var10007;
            var10011[6] = var44;
            var10011[5] = var43;
            var10011[4] = var46;
            var10011[3] = var45;
            var10011[2] = var42;
            var10011[1] = var201;
            var10011[0] = var177;
            Object[] var110 = var10011;
            FilledRectangleRenderer.cReturningVoid(var110);
            float var210;
            int var178 = (var210 = this.e - 20.0F) == 0.0F ? 0 : (var210 < 0.0F ? -1 : 1);
            int var167 = var28;
            int var166 = var178;
            int var142 = var166;
            int var141 = var166;
            if (var167 == 0) {
               int var168 = var141;
               if (var168 >= 0) {
                  String var169 = "LETHAL";
                  var143 = var169;
                  break label49;
               }

               var142 = (int)this.e;
            }

            var143 = "Damage: " + var142 + "HP";
         }

         String var47 = var143;
         MsdfFontManager var179 = Prestige.c;
         Object[] var114 = new Object[]{51869363673471L};
         MsdfFontManager var113 = var179;
         MsdfFont var180 = var113.aReturningcx_C0158(var114);
         Object[] var116 = new Object[]{var47, 117628177084989L};
         MsdfFont var115 = var180;
         float var48 = var115.aReturningFloat(var116);
         float var49 = 7.0F;
         float var181 = this.e / 20.0F;
         float var119 = 1.0F;
         float var118 = 0.0F;
         float var117 = var181;
         float var50 = MathHelper.clamp(var117, var118, var119);
         float var51 = var45 + var49;
         float var52 = var46 + var44 - 4.0F - 3.0F;
         float var53 = var43 - var49 * 2.0F;
         float var54 = var53 * var50;
         Color var55 = new Color(0, 0, 0, 90);
         Color var56 = new Color((int)((1.0F - var50) * 255.0F), (int)(var50 * 255.0F), 0, 220);
         MeshBufferManager var182 = var1.a;
         RenderContext var202 = var1.b;
         Object[] var207 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
         var207[8] = 2.0F;
         var207[7] = var55;
         var207[6] = 4.0F;
         var207[5] = var53;
         var207[4] = var52;
         var207[3] = var51;
         var207[2] = var42;
         var207[1] = var202;
         var207[0] = var182;
         Object[] var120 = var207;
         FilledRectangleRenderer.cReturningVoid(var120);
         int var172 = var28;
         float var171 = 0.0F;
         float var170 = var54;
         float var146 = var170;
         float var147 = var171;
         float var144 = var170;
         float var145 = var171;
         if (var172 == 0) {
            float var211;
            int var173 = (var211 = var144 - var145) == 0.0F ? 0 : (var211 < 0.0F ? -1 : 1);
            if (var173 > 0) {
               MeshBufferManager var183 = var1.a;
               var202 = var1.b;
               var207 = new Object[]{null, null, null, null, null, null, null, null, null, 63681742626673L};
               var207[8] = 2.0F;
               var207[7] = var56;
               var207[6] = 4.0F;
               var207[5] = var54;
               var207[4] = var52;
               var207[3] = var51;
               var207[2] = var42;
               var207[1] = var202;
               var207[0] = var183;
               Object[] var122 = var207;
               FilledRectangleRenderer.cReturningVoid(var122);
            }

            var147 = (var43 - var48) / 2.0F;
            var146 = var45;
         }

         float var57 = var146 + var147;
         MsdfFontManager var184 = Prestige.c;
         Object[] var125 = new Object[]{51869363673471L};
         MsdfFontManager var124 = var184;
         MsdfFont var185 = var124.aReturningcx_C0158(var125);
         float var205 = var46 + 3.0F;
         Object[] var126 = new Object[]{2617886958130L};
         Object[] var10008 = new Object[]{null, null, null, null, ClientUiUtil.dReturningColor(var126), 10141036836483L};
         var10008[3] = var205;
         var10008[2] = var57;
         var10008[1] = var47;
         var10008[0] = var42;
         Object[] var128 = var10008;
         MsdfFont var127 = var185;
         var127.v(var128);
      }
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(87456453332808L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[3];
      String var17 = "ÿÉ\u0007¯qmM\u001d\u0095Ó\u009d\u009dkÔ\u001a®\u0010èü´Õ\u0016%\u0085Hïù =\u0088á\u0082U ÅTr±z(\u001eV\u0087O\u0085J^\r\u0087\u0085\u0089\u0091úþê7Í\"\u0097\u009ca\u0011°öIi";
      int var19 = "ÿÉ\u0007¯qmM\u001d\u0095Ó\u009d\u009dkÔ\u001a®\u0010èü´Õ\u0016%\u0085Hïù =\u0088á\u0082U ÅTr±z(\u001eV\u0087O\u0085J^\r\u0087\u0085\u0089\u0091úþê7Í\"\u0097\u009ca\u0011°öIi"
         .length();
      char var16 = 16;
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var30 = b(var21).intern();
         int var10001 = -1;
         var20[var18++] = var30;
         if ((var15 += var16) >= var19) {
            l = var20;
            m = new String[3];
            q = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(87456453332808L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[5];
            String var4 = ">åj»î\u0014\u001aOÜj\b÷\u0082pß×f<«Æ\u00072 '";
            int var5 = ">åj»î\u0014\u001aOÜj\b÷\u0082pß×f<«Æ\u00072 '".length();
            label32:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var25 = var6;
               var10001 = var3++;
               long var33 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               // while (true) {
                  long var8 = var33;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var38 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var36) {
                     case 0:
                        var25[var10001] = var38;
                        if (var2 >= var5) {
                           o = var6;
                           p = new Integer[5];
                           break;
                        }
                        break;
                     default:
                        var25[var10001] = var38;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "\u0016à\u008a\u0083ì\u009c¦\u009büi4©#ãW¥";
                        var5 = "\u0016à\u008a\u0083ì\u009c¦\u009büi4©#ãW¥".length();
                        var2 = 0;
                  }

                  int var29 = var2;
                  var2 += 8;
                  var7 = var4.substring(var29, var2).getBytes("ISO-8859-1");
                  var25 = var6;
                  var10001 = var3++;
                  var33 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var36 = 0;
               }
            }
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11289;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fr", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fr_C0306",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29433;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fr", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fr_C0306",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 58;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 39;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 42;
            yield var20;
         }
         case 6 -> {
            byte var21 = 48;
            yield var21;
         }
         case 7 -> {
            byte var22 = 20;
            yield var22;
         }
         case 8 -> {
            byte var23 = 9;
            yield var23;
         }
         case 9 -> {
            byte var24 = 10;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 33;
            yield var26;
         }
         case 12 -> {
            byte var27 = 63;
            yield var27;
         }
         case 13 -> {
            byte var28 = 41;
            yield var28;
         }
         case 14 -> {
            byte var29 = 22;
            yield var29;
         }
         case 15 -> {
            byte var30 = 47;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 13;
            yield var32;
         }
         case 18 -> {
            byte var33 = 51;
            yield var33;
         }
         case 19 -> {
            byte var34 = 6;
            yield var34;
         }
         case 20 -> {
            byte var35 = 61;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 24;
            yield var37;
         }
         case 23 -> {
            byte var38 = 34;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 55;
            yield var41;
         }
         case 27 -> {
            byte var42 = 14;
            yield var42;
         }
         case 28 -> {
            byte var43 = 50;
            yield var43;
         }
         case 29 -> {
            byte var44 = 31;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 52;
            yield var46;
         }
         case 32 -> {
            byte var47 = 3;
            yield var47;
         }
         case 33 -> {
            byte var48 = 43;
            yield var48;
         }
         case 34 -> {
            byte var49 = 62;
            yield var49;
         }
         case 35 -> {
            byte var50 = 36;
            yield var50;
         }
         case 36 -> {
            byte var51 = 26;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 5;
            yield var53;
         }
         case 39 -> {
            byte var54 = 46;
            yield var54;
         }
         case 40 -> {
            byte var55 = 32;
            yield var55;
         }
         case 41 -> {
            byte var56 = 27;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 60;
            yield var58;
         }
         case 44 -> {
            byte var59 = 7;
            yield var59;
         }
         case 45 -> {
            byte var60 = 37;
            yield var60;
         }
         case 46 -> {
            byte var61 = 35;
            yield var61;
         }
         case 47 -> {
            byte var62 = 56;
            yield var62;
         }
         case 48 -> {
            byte var63 = 2;
            yield var63;
         }
         case 49 -> {
            byte var64 = 23;
            yield var64;
         }
         case 50 -> {
            byte var65 = 30;
            yield var65;
         }
         case 51 -> {
            byte var66 = 19;
            yield var66;
         }
         case 52 -> {
            byte var67 = 59;
            yield var67;
         }
         case 53 -> {
            byte var68 = 11;
            yield var68;
         }
         case 54 -> {
            byte var69 = 54;
            yield var69;
         }
         case 55 -> {
            byte var70 = 40;
            yield var70;
         }
         case 56 -> {
            byte var71 = 12;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 8;
            yield var73;
         }
         case 59 -> {
            byte var74 = 17;
            yield var74;
         }
         case 60 -> {
            byte var75 = 16;
            yield var75;
         }
         case 61 -> {
            byte var76 = 21;
            yield var76;
         }
         case 62 -> {
            byte var77 = 38;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "M\"Swk:S*I8\u0016*S";
      r[1] = "m:NR_\u001bf5_\u001d>\u0015m>[G";
      r[2] = "o\u0001:\u0013\u0002my\u0001?I\u0011znJ<O\u001dn\u007f\r+XV|N";
      r[3] = int.class;
      s[3] = "java/lang/Integer";
      r[4] = "6&\\%K:6&KyG5,mKgG +\u001c\u001f?\u0010";
      r[5] = "E\u0003\u0014\u001d+YE\u0003\u0003A'V_H\u0003_'CX9V\u000b~\u0000";
      r[6] = double.class;
      s[6] = "java/lang/Double";
      r[7] = "\u0007tYu?\u0011\f{H:\\\u001c\u0019}";
      r[8] = "Wj\u0019\u0005\b)Wj\u000eY\u0004&M!\u000eG\u00043JP\\\u001bQq";
      r[9] = "^W\u0010?q/HW\u0015eb8_\u001c\u0016cn,N[\u0001t%<V[\u0003\u007f\u007fqj@\u0003b\u007f6]W";
      r[10] = "${\f\u00158#2{\tO+4%0\nI' 4w\u001d^l0:";
      r[11] = "WC\u0016\u007fhUAC\u0013%{BV\b\u0010#wVGO\u00074<DV";
      r[12] = "\t\f\u0016(\u000eb|,\u001d'\u001f-\u001d\"\u0016,\u001bwi";
      r[13] = float.class;
      s[13] = "java/lang/Float";
      r[14] = "%m\u0019r{t%m\u000e.w{?&\u000e0wn8WXm%)";
      r[15] = "/\u0018+\u0015,E-\u0006bv'^2\u00034\u000f ";
      r[16] = "s@7z\fms@ &\u0000bi\u000b 8\u0000wnzq`R";
      r[17] = "\t$\u0001j\u001b\u0000\t$\u00166\u0017\u000f\u0013o\u0016(\u0017\u001a\u0014\u001eFuF";
      r[18] = "SF.XD/EF+\u0002W8R\r(\u0004[,CJ?\u0013\u0010<O";
      r[19] = "\u001b\u0012\u000fj/8n2\u0004e>w\u000f<\u000fn:-{";
      r[20] = "\u001bb\u000e\u000fJS\rb\u000bUYD\u001a)\bSUP\u000bn\u001fD\u001eB=";
      r[21] = "^!i9S\u000b+\u0001b6BDJ\u000fi=F\u001e>";
      r[22] = "\u0016&\u0007l\u001d\u0012\u000b3_N\\\u001f\u00135";
      r[23] = "D_{Ku~1\u007fpDd1Pq{O`k$";
      r[24] = void.class;
      s[24] = "java/lang/Void";
      r[25] = "g\u001a?\u0006U$\u0012:4\tDks4?\u0002@1\u0007";
      r[26] = "R>m,\u000e\rD>hv\u001d\u001aSukp\u0011\u000eB2|gZ\u001eY";
      r[27] = "\rSp \u001d\u001bxs{/\fT\u0019}p$\b\u000em";
      r[28] = boolean.class;
      s[28] = "java/lang/Boolean";
      r[29] = "\u001e< 2\u001e-\b<%h\r:\u001fw&n\u0001.\u000e01yJ9\r";
      r[30] = "8a.k\u007f\u001cMA%dnS,O.oj\tX";
      r[31] = "\u0014\u001e\u001bI\u007fF\u0002\u001e\u001e\u0013lQ\u0015U\u001d\u0015`E\u0004\u0012\n\u0002+P%";
      r[32] = "\u001b\u001ee\u001b\u001e\bn>n\u0014\u000fG\u000f0e\u001f\u000b\u001d{";
      r[33] = "\u0000yEN\u001f\u0011\u0000yR\u0012\u0013\u001e\u001a2R\f\u0013\u000b\u001dC\u0000VGO";
      r[34] = "W\n\\<\u0012=W\nK`\u001e2MAK~\u001e'J0\u0019*Of";
      r[35] = "\u000ex\u000b?0D\u000ex\u001cc<K\u00143\u001c}<^\u0013BN&d\u001f";
      r[36] = "j_)[s~j_>\u0007\u007fqp\u0014>\u0019\u007fdwen@-%";
      r[37] = ",^D\u0019\f|Y~O\u0016\u001d38pD\u001d\u0019iL";
      r[38] = "Ww\u000bsN9Aw\u000e)].V<\r/Q:G{\u001a8\u001a/A";
      r[39] = "2\u0010s&Q\u001a9\u001fbi2\u0017,\u0012m\u0002\u0007\u0015=\u0001q.\u0010\u0018";
      r[40] = "_[zG\u001an_[m\u001b\u0016aE\u0010m\u0005\u0016tBa?[F5\u0002";
      r[41] = "Vf\u0005\u0010@XVf\u0012LLWL-\u0012RLBK\\@\f\u0014\u0006";
      r[42] = "]u\u0012B7d(U\u0019M&+I[\u0012F\"q=";
      r[43] = "j\u001b<i63|\u001b93%$kP:5)0z\u0017-\"b'h";
      r[44] = "nfqULf\u001bFzZ])zHqQYs\u000e";
      r[45] = "/K\u0013\u000e{\u00009K\u0016Th\u0017.\u0000\u0015Rd\u0003?G\u0002E/\u0013r";
      r[46] = "~\u001c\u0004\rKj\u000b<\u000f\u0002Z%j2\u0004\t^\u007f\u001e";
      r[47] = "cR:\u000e+\t<[.LF\u000fZ\u00132U'\u0006dU2\fye";
      r[48] = "bUWB+*e\\\u000fTM 4B\rL!\u0012e\u0003V\u0011sEbFTL&:9T]TMy3T\u0011\u00145'0\u0006\u0000+";
      r[49] = "<J\u00143Reo\\\n`=ghPqaWh}\u001f\t?T:l M7W~>X\u00134\u0005o\u0001\u001c\u001b7A=yB\u0018eP\u0002";
      r[50] = "|\u0006K \u0006\u000e,\u0000RvaZ/AR{\rh~\u0000\n&a\u0005'[S\u007f_C'\u0002\r\u001c";
      r[51] = "S6:Qy'Q5a\u001f\u0018.mob\u001ae9\u0012:2\u001ax";
      r[52] = "S\u0004\u00169k\u0000\nXP`\u0016\tcC_yzP\u0007C\u0014m/`RTB0t[\u0001\u0001Af\u0016";
      r[53] = "pg\u0017\u0003l}`7\u0014rty\u001fw\b\u001es}zbMO\u0013xso\u0002\ryh#ls";
      r[54] = "#l>\u001dM|4>s\u001f3m+1*Kd9qct\u001e382e)LLc l1";
      r[55] = "'GY|\u0000e.\u0006\u0000wia%SXki+'U\fdRxrVZ\u0006Xs!\n^=\u000b&\"\\<7\u0000u~X\u0007dUv(:U{\f`'E\\:UkN";
      r[56] = "%=YW4\u000e1%BZM\f\"9[L!>v}\u0001\u0015M\u00037'GR*\u0017/<J+q\u0003%9\u0004S/\u0000w(;";
      r[57] = "\u0013\u001a.&s\n\u0001\u001b+>\u001e\u0000\u0019\u00190.IWGNhB%\u0005B\u001d2-\"\f\u001a\u000b";
      r[58] = "n'\u001d\u000f\u0013E> \u001a\u0000s\u0015\u0005%S\t\u001fLa%\u0018\u001dJ|42N@\u0011GggM\u0016s";
      r[59] = "aTl]yRsUiE\u0014SgFv^xa0\u0000(\t/64\u0001o\u0005s\u0007d\u0007vS\u0014";
      r[60] = "&\u0007Uz):/F\fq@95\u0013V{$,3\u001701)*\u007f\u0018\u000bb|))z\u0001i/u-AR<,#OKYop't\u0018\fl&E&\u0007Uz):/F\fq@";
      r[61] = "E!ks\u000e!\u0010{?>r5(`w{\u001eiL`<oKYFa~mK`\u0011y;`r";
      r[62] = "\u001aGK)D\nC\u001b\rp9\u0003*\u0000\u0002iUZN\u0000I}\u0000jE\f\u0019!Y\u0017\u0017\u0010\u0012q9";
      r[63] = "\u001f>l\u001fcGJnl\u0002\u001fQ |d\u001bs\bD|/\u000f&8K~*\u001d\u007f\u0001\u001by-\u0012\u001f";
      r[64] = "<s;\rhQ6kyV\u001a\b]os\u0012v\\9o8\u0006#l?mj\f{\u001c>psP\u001a";
      r[65] = "|vF\u0014G|vyAJ!\u007f\u001fcR\u000eM&{c\u0019\u001a\u0018\u0016.tOGC-}!L\u0011!";
      r[66] = "D.G9>\u0006Dn\u001dw\u0003\u0004!iV1o]Ei\u001d%:mGwI%>PPt\u001a,\u0003";
      r[67] = "6AB\tPj)\u0011BVi<0\u0013\u001fX>ljEJ\fi52G\u001f]Y#k\u0002\u000b";
      r[68] = "(\tr\u0010_A-\u0017fM=C=\u0014i\u0012QqiU2K\u0006&a\u0001fE_\u001d2Te\u0013=\u00179\u00079\u0017\u0006Dl\u0004ou\fO?XkN_\u001a<\u000e\tDTI`\n2\u0017\u0001J6h";
      r[69] = " \r8i\bMp\n?fh\nK\u000fvo\u0004D/\u000f={Qt$\u0003m'\b\tv\u001ffwh";
      r[70] = "d*1nfsemf4V \u001d+is<$w3hm2Ig`$e;#\u007fa:kV";
      r[71] = "M\rWHD\u0000J\u0004\u000f^\"\n\u001b\u001a\rFN8KYW\u0019\"\u0005\u000e\u0004\u0011XE\u0011\u0016\u001f\u001c!";
      r[72] = "\u0017||i>i\u0001&j*Ru\u0001kr|>GS*(!c\u0010\u0017nj*?(\rlx$Rz\u0014unb5n\fnc\u001b";
      r[73] = "g'P\"\u0011n2}\u0004om|\nfL*\u0001&nf\u0007>T\u0016;qQc\u000f-h$R5m";
      r[74] = "O\u0018_\u0015(~J\u0006KHJ|Z\u0005D\u0017&N\u000eD\u001fMu\u0019\u000b\u0013N\fuaU\u0010\u001c\u001dJ#R\u001fE\u0013teRF\u001bp";
      r[75] = ";Zz\u001b%\u0001\u007fB8J\u001e\u0015GVp\rrN#V;\u0019'~(ZkE~\u0003zF`\u0015\u001e";
      r[76] = "\u0007\bGDu:\u0006\u001c\u001e\u0003\u001cfy\r\\Gp;\u001d\r\u0017S%\u000b\u0016\u0001G\u000f|vD\u001dL_\u001c";
      r[77] = "rkl~\u0000^\"mu(g\n!,u%\u000b8pl%|gU)6t!Y\u0013)o*B";
      r[78] = "\u0006A\"sl<\u0001Hze\n6PVx}f\u0004\u0003\u0013!'\n1AA\u007f{z0\\X#\u001a";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(84035729521661L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(84035729521661L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(84035729521661L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 211;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 249;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 254;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 100;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 237;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 211;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 249;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fr_C0306",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
