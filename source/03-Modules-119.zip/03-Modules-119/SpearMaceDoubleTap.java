package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class SpearMaceDoubleTap extends Module {
   private FloatSetting a;
   private ElapsedTimer c;
   private boolean i;
   private static final long k = 46163125912252L;
   private static final long l;
   private static final Object[] m = new Object[86];
   private static final String[] n = new String[86];

   public SpearMaceDoubleTap() {
      super();
      long var10001 = 5248517718904L ^ 111929459012689L;

      this.c = new ElapsedTimer(106698256430889L);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.Mace;
      CombatProfile var4 = CombatProfile.Spear;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(TickEvent var1) {
      SpearMaceDoubleTap var27;
      long var10001 = 55066620069742L ^ 84213526352250L;
      var10001 = 55066620069742L ^ 94531668635782L;
      int var8 = Event.bReturningInt();
      int var29 = var8;
      SpearMaceDoubleTap var28 = this;
      var27 = var28;
      SpearMaceDoubleTap var21 = var28;
      label30:
      if (var29 == 0) {
         boolean var30 = var21.i;
         if (var30) {
            int var32 = var8;
            SpearMaceDoubleTap var31 = this;
            var27 = var31;
            SpearMaceDoubleTap var22 = var31;
            if (var32 != 0) {
               break label30;
            }

            SpearMaceDoubleTap var33 = var22;
            SpearMaceDoubleTap var23 = var33;
            ElapsedTimer var10000 = var23.c;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = 1000.0F;
            Object[] var12 = var10004;
            ElapsedTimer var11 = var10000;
            boolean var34 = var11.aReturningBoolean(var12);
            if (!var34) {
               MinecraftClient var14 = b;
               int var36 = var8;
               HitResult var35 = var14.crosshairTarget;
               HitResult var26 = var35;
               HitResult var24 = var35;
               if (var36 == 0) {
                  HitResult var37 = var24;
                  HitResult var25 = var37;
                  boolean var38 = var25 instanceof EntityHitResult;
                  if (!var38) {
                     return;
                  }

                  MinecraftClient var18 = b;
                  var26 = var18.crosshairTarget;
               }

               EntityHitResult var19 = (EntityHitResult)var26;
               Object[] var20 = new Object[]{var19.getEntity(), 114267283224552L};
               ItemUseUtil.aReturningVoid(var20);
            }
         }

         var27 = this;
      }

      var27.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      long var10001 = 64536738728762L ^ 133031201132068L;
      var10001 = 64536738728762L ^ 31093244191546L;
      var10001 = 64536738728762L ^ 135541918977612L;
      int var10 = Event.cReturningInt();
      Object[] var14 = new Object[0];
      PacketReceiveEvent var13 = var1;
      byte var10000 = ((byte)((var13.aReturningVoid(var14) instanceof EntityStatusS2CPacket) ? 1 : 0));
      int var46 = var10;
      byte var45 = var10000;
      byte var38 = var45;
      byte var37 = var45;
      if (var46 != 0) {
         byte var47 = var37;
         if (var47 == 0) {
            return;
         }

         Object[] var17 = new Object[0];
         PacketReceiveEvent var16 = var1;
         EntityStatusS2CPacket var18 = (EntityStatusS2CPacket)var16.aReturningVoid(var17);
         byte var48 = var18.getStatus();
         var38 = var48;
      }

      byte var11 = var38;
      int var50 = var10;
      byte var49 = var11;
      int var40 = var49;
      byte var39 = var49;
      if (var50 != 0) {
         byte var52 = 2;
         byte var51 = var39;
         if (var51 != var52) {
            return;
         }

         Object[] var22 = new Object[]{72909689177374L};
         SpearMaceDoubleTap var21 = this;
         int var53 = var21.aReturningInt(var22);
         var40 = var53;
      }

      int var12 = var40;
      int var55 = var10;
      int var54 = var12;
      int var42 = var54;
      int var41 = var54;
      if (var55 != 0) {
         // int var56 = var41;
         if (var56 == var57) {
            return;
         }

         MinecraftClient var25 = b;
         ClientPlayerEntity var26 = var25.player;
         double var63 = var26.fallDistance;
         FloatSetting var27 = this.a;
         Float var28 = (Float)var27.aReturningObject();
         double var67;
         int var58 = (var67 = var63 - var28.floatValue()) == 0.0 ? 0 : (var67 < 0.0 ? -1 : 1);
         var42 = var58;
      }

      int var60 = var10;
      int var59 = var42;
      int var44 = var59;
      int var43 = var59;
      if (var60 != 0) {
         int var61 = var43;
         if (var61 <= 0) {
            return;
         }

         MinecraftClient var31 = b;
         ClientPlayerEntity var32 = var31.player;
         var32.stopUsingItem();
         int var62 = var12;
         var44 = var62;
      }

      Object[] var10003 = new Object[]{null, 72518082610550L};
      var10003[0] = var44;
      Object[] var34 = var10003;
      InventoryUtil.aReturningVoid(var34);
      ElapsedTimer var64 = this.c;
      Object[] var36 = new Object[]{42835128969216L};
      ElapsedTimer var35 = var64;
      var35.aReturningVoid(var36);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   public int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 46163125912252L ^ var2;
      long var4 = var2 ^ 62581747025604L;
      long var6 = var2 ^ 50048334245227L;
      long var8 = var2 ^ 32154176775447L;
      int var10000 = Event.bReturningInt();
      ArrayList var11 = new ArrayList();
      int var10 = var10000;
      byte var45;
      while (true) {
         int var55 = (int)l;
         int var54 = var12;
         if (var54 <= var55) {
            MinecraftClient var17 = b;
            ClientPlayerEntity var18 = var17.player;
            PlayerInventory var79 = var18.getInventory();
            int var20 = var12;
            PlayerInventory var19 = var79;
            Object[] var21 = new Object[]{var19.getStack(var20), var4};
            byte var80 = ((byte)((InventoryUtil.o(var21)) ? 1 : 0));
            int var57 = var10;
            byte var56 = var80;
            var45 = var56;
            byte var41 = var56;
            if (var57 != 0) {
               break;
            }

            int var59 = var10;
            byte var58 = var41;
            byte var42 = var58;
            if (var59 == 0) {
               byte var60 = var42;
               byte var43 = var60;
               byte var61 = var43;
               if (var61 != 0) {
                  int var24 = var12;
                  Integer var26 = var24;
                  ArrayList var25 = var11;
                  boolean var62 = var25.add(var26);
               }
            }

            var12++;
            int var63 = var10;
            if (var63 == 0) {
               continue;
            }
         }

         var12 = -1;
         var45 = -1;
         break;
      }

      int var13 = var45;
      ArrayList var28 = var11;
      Iterator var14 = var28.iterator();

      int var53;
      while (true) {
         Iterator var29 = var14;
         boolean var64 = var29.hasNext();
         if (var64) {
            Iterator var30 = var14;
            Integer var31 = (Integer)var30.next();
            int var15 = var31;
            MinecraftClient var32 = b;
            ClientPlayerEntity var33 = var32.player;
            double var83;
            var10000 = (var83 = var33.fallDistance - 7.0) == 0.0 ? 0 : (var83 < 0.0 ? -1 : 1);
            int var66 = var10;
            int var65 = var10000;
            var53 = var65;
            int var46 = var65;
            if (var66 != 0) {
               break;
            }

            int var68 = var10;
            int var67 = var46;
            int var49 = var67;
            int var47 = var67;
            int var50;
            if (var68 == 0) {
               int var69 = var47;
               int var48 = var69;
               int var70 = var48;
               if (var70 <= 0) {
                  Object[] var10004 = new Object[]{null, var8};
                  var10004[0] = var15;
                  Object[] var37 = var10004;
                  SpearMaceDoubleTap var36 = this;
                  int var71 = var36.dReturningInt(var37);
                  var50 = var71;
               } else {
                  Object[] var82 = new Object[]{null, var6};
                  var82[0] = var15;
                  Object[] var40 = var82;
                  SpearMaceDoubleTap var39 = this;
                  var50 = var39.cReturningInt(var40);
               }
            } else {
               int var72 = var49;
               var50 = var72;
            }

            label43: {
               int var16 = var50;
               int var74 = var10;
               int var73 = var16;
               int var52 = var73;
               int var51 = var73;
               if (var74 == 0) {
                  int var76 = var12;
                  int var75 = var51;
                  if (var75 <= var76) {
                     break label43;
                  }

                  var12 = var16;
                  var52 = var15;
               }

               var13 = var52;
            }

            int var77 = var10;
            if (var77 == 0) {
               continue;
            }
         }

         var53 = var13;
         break;
      }

      return var53;
   }

   public int cReturningInt(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 46163125912252L ^ var3;
      int var32 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      PlayerInventory var10001 = var9.getInventory();
      int var11 = var2;
      PlayerInventory var10 = var10001;
      ItemStack var6 = var10.getStack(var11);
      int var5 = var32;
      int var29 = var5;
      ItemStack var28 = var6;
      Object var27 = var28;
      ItemStack var26 = var28;
      if (var29 != 0) {
         ItemStack var30 = var26;
         if (var30 == null) {
            return 0;
         }

         MinecraftClient var13 = b;
         ClientWorld var14 = var13.world;
         DynamicRegistryManager var33 = var14.getRegistryManager();
         RegistryKey var15 = Enchantments.DENSITY;
         RegistryKey var17 = var15.getRegistryRef();
         DynamicRegistryManager var16 = var33;
         Optional var18 = var16.getOptional(var17);
         Registry var34 = (Registry)var18.get();
         RegistryKey var19 = Enchantments.DENSITY;
         Identifier var21 = var19.getValue();
         Registry var20 = var34;
         Optional var22 = var20.getEntry(var21);
         Object var31 = var22.get();
         var27 = var31;
      }

      RegistryEntry var35 = (RegistryEntry)var27;
      ItemStack var25 = var6;
      RegistryEntry var24 = var35;
      float var7 = EnchantmentHelper.getLevel(var24, var25);
      return (int)var7;
   }

   public int dReturningInt(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 46163125912252L ^ var2;
      int var32 = Event.cReturningInt();
      MinecraftClient var8 = b;
      ClientPlayerEntity var9 = var8.player;
      PlayerInventory var10001 = var9.getInventory();
      int var11 = var4;
      PlayerInventory var10 = var10001;
      ItemStack var6 = var10.getStack(var11);
      int var5 = var32;
      int var29 = var5;
      ItemStack var28 = var6;
      Object var27 = var28;
      ItemStack var26 = var28;
      if (var29 != 0) {
         ItemStack var30 = var26;
         if (var30 == null) {
            return 0;
         }

         MinecraftClient var13 = b;
         ClientWorld var14 = var13.world;
         DynamicRegistryManager var33 = var14.getRegistryManager();
         RegistryKey var15 = Enchantments.BREACH;
         RegistryKey var17 = var15.getRegistryRef();
         DynamicRegistryManager var16 = var33;
         Optional var18 = var16.getOptional(var17);
         Registry var34 = (Registry)var18.get();
         RegistryKey var19 = Enchantments.DENSITY;
         Identifier var21 = var19.getValue();
         Registry var20 = var34;
         Optional var22 = var20.getEntry(var21);
         Object var31 = var22.get();
         var27 = var31;
      }

      RegistryEntry var35 = (RegistryEntry)var27;
      ItemStack var25 = var6;
      RegistryEntry var24 = var35;
      float var7 = EnchantmentHelper.getLevel(var24, var25);
      return (int)var7;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(83581996615646L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -3209985555550274972L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)211L,
            (byte)54131L,
            (byte)13857751L,
            (byte)3547584292L,
            (byte)908181579003L,
            (byte)232494484224842L,
            (byte)59518587961559674L,
            (byte)-3209985555550274972L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 5;
            yield var15;
         }
         case 1 -> {
            byte var16 = 3;
            yield var16;
         }
         case 2 -> {
            byte var17 = 35;
            yield var17;
         }
         case 3 -> {
            byte var18 = 43;
            yield var18;
         }
         case 4 -> {
            byte var19 = 21;
            yield var19;
         }
         case 5 -> {
            byte var20 = 38;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 19;
            yield var22;
         }
         case 8 -> {
            byte var23 = 53;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 30;
            yield var25;
         }
         case 11 -> {
            byte var26 = 16;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 28;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 0;
            yield var31;
         }
         case 17 -> {
            byte var32 = 61;
            yield var32;
         }
         case 18 -> {
            byte var33 = 10;
            yield var33;
         }
         case 19 -> {
            byte var34 = 12;
            yield var34;
         }
         case 20 -> {
            byte var35 = 4;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 44;
            yield var37;
         }
         case 23 -> {
            byte var38 = 40;
            yield var38;
         }
         case 24 -> {
            byte var39 = 26;
            yield var39;
         }
         case 25 -> {
            byte var40 = 17;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 14;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 20;
            yield var44;
         }
         case 30 -> {
            byte var45 = 54;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 59;
            yield var47;
         }
         case 33 -> {
            byte var48 = 42;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 58;
            yield var50;
         }
         case 36 -> {
            byte var51 = 18;
            yield var51;
         }
         case 37 -> {
            byte var52 = 34;
            yield var52;
         }
         case 38 -> {
            byte var53 = 27;
            yield var53;
         }
         case 39 -> {
            byte var54 = 57;
            yield var54;
         }
         case 40 -> {
            byte var55 = 29;
            yield var55;
         }
         case 41 -> {
            byte var56 = 24;
            yield var56;
         }
         case 42 -> {
            byte var57 = 11;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 45;
            yield var59;
         }
         case 45 -> {
            byte var60 = 52;
            yield var60;
         }
         case 46 -> {
            byte var61 = 6;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 41;
            yield var63;
         }
         case 49 -> {
            byte var64 = 48;
            yield var64;
         }
         case 50 -> {
            byte var65 = 50;
            yield var65;
         }
         case 51 -> {
            byte var66 = 51;
            yield var66;
         }
         case 52 -> {
            byte var67 = 1;
            yield var67;
         }
         case 53 -> {
            byte var68 = 62;
            yield var68;
         }
         case 54 -> {
            byte var69 = 23;
            yield var69;
         }
         case 55 -> {
            byte var70 = 22;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 55;
            yield var72;
         }
         case 58 -> {
            byte var73 = 63;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 15;
            yield var75;
         }
         case 61 -> {
            byte var76 = 7;
            yield var76;
         }
         case 62 -> {
            byte var77 = 32;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "\u001cLEX\u0006j\u0017CT\u0017ah\u0002HT\\Z";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "~ \u0012GM'h \u0017\u001d^0\u007fk\u0014\u001bR$n,\u0003\f\u00191i";
      m[3] = "=2R4{QH\u0012Y;j\u001e)\u001cR0nD]";
      m[4] = "62Q\u00136q 2TI%f7yWO)r&>@Xb`\u0017";
      m[5] = "8\rr\u0019*!.\rwC969FtE5\"(\u0001cR~23";
      m[6] = "By\u0000{B\u001b7Y\u000btSTVW\u0000\u007fW\u000e\"";
      m[7] = boolean.class;
      n[7] = "java/lang/Boolean";
      m[8] = "_'\u0004\u00063k_'\u0013Z?dEl\u0013D?qB\u001dG\u001ch";
      m[9] = "f5\u000bI\rgf5\u001c\u0015\u0001h|~\u001c\u000b\u0001}{\u000fNQV?";
      m[10] = double.class;
      n[10] = "java/lang/Double";
      m[11] = "\u001a'Gri\u0001\u0011(V=\n\f\u0004%YV?\u000e\u00156Ez(\u0003";
      m[12] = "byD62\r|q^yP\u0011{l";
      m[13] = "\u0015\u000bg9;\f\u000b\u0003}v\\\r\u001a\u0018p,z\u000b";
      m[14] = "\u001a#nL^\"\u001a#y\u0010R-\u0000hy\u000eR8\u0007\u0019+U\nr";
      m[15] = "[v\u0007#siPy\u0016l\u0012g[r\u00126";
      m[16] = "K\f\u0019%N`K\f\u000eyBoQG\u000egBzV6^:\u0013";
      m[17] = "&v_b\u000efSVTm\u001f)2X_f\u001bsF";
      m[18] = "qC6wD\u0018qC!+H\u0017k\b!5H\u0002lywm\u001cD";
      m[19] = "!3\u0018 FX!3\u000f|JW;x\u000fbJB<\tY=\u0019\u0000";
      m[20] = "X-\u0005SP\rF%\u001f\u001c1\bF%\u001c\\\u001f\u0014";
      m[21] = "Pqro>\rPqe32\u0002J:e-2\u0017MK7yjW";
      m[22] = "r1X9q\u007fr1Oe}phzO{}eo\u000b\u001a$$";
      m[23] = "Rt:Bd\u0012Rt-\u001eh\u001dH?-\u0000h\bON|U?K";
      m[24] = ".Su\r\u0016\u000b.SbQ\u001a\u00044\u0018bO\u001a\u00113i3\u0010LZ";
      m[25] = "t<}OD\u0004t<j\u0013H\u000bnwj\rH\u001ei\u00068Y\u0010]";
      m[26] = "k=Q\u001f.1k=FC\">qvF]\"+v\u0007\u0013\t{h";
      m[27] = "[\u0016+r}\u0014M\u0016.(n\u0003Z]-.b\u0017K\u001a:9)\u0002f";
      m[28] = "#a#&M%VA()\\j7O#\"X0C";
      m[29] = "{,[\u001dkd{,LAgkagL_g~f\u0016\u001d\u0000?";
      m[30] = "\u0015c\u000eOyG\u0015c\u0019\u0013uH\u000f(\u0019\ru]\bYIX\"\u0018";
      m[31] = "3'pQ\u0017x3'g\r\u001bw)lg\u0013\u001bb.\u001d5MC&";
      m[32] = "\"bjs>\u00064bo)-\u0011#)l/!\u00052n{8j\u0015*";
      m[33] = "\u0005\u001deqDGp=n~U\b\u00113euQRe";
      m[34] = void.class;
      n[34] = "java/lang/Void";
      m[35] = "^\u00114'I*@\u0019.h4:@";
      m[36] = ">|J0d\bK\\A?uG*RJ4q\u001d^";
      m[37] = "\u0005s'o \u000f\u0013s\"53\u0018\u00048!3?\f\u0015\u007f6$t\u001b'";
      m[38] = "*\u0016]>f@!\u0019Lq\u000e@/\u0016_";
      m[39] = float.class;
      n[39] = "java/lang/Float";
      m[40] = ".\u0004ITVN[$B[G\u0001:*IPC[N";
      m[41] = "|\tLhG\u0013j\tI2T\u0004}BJ4X\u0010l\u0005]#\u0013\u0001|";
      m[42] = "?7_\u001f8JJ\u0017T\u0010)\u0005+\u0019_\u001b-__";
      m[43] = "X\u007f#{J`X\u007f4'FoB449FzEEe`\u001e?";
      m[44] = "(<9t6M]\u001c2{'\u0002<\u00129p#XH";
      m[45] = ":`)e-|:`>9!s +>'!f'Zo}v&";
      m[46] = byte.class;
      n[46] = "java/lang/Byte";
      m[47] = "6\u001dON{_\u007f\u0013H\u001d\u0003\\\u000f\u0011IK2IrU\u0002Ci0s\t\b\u001d\u007f@c\u0000\fs";
      m[48] = "\u00128sU\u001eYSx?\n\u007fK)ye@\u0011]YilD\u007f";
      m[49] = "\u001a@G*\\\u0017\u001e\u0004\u0012(>\u001eJA\u001d?R,\u001c\u0004@d\u000e{\u0019G\u0017&D\u0003NCA7>";
      m[50] = "\rn%F$!\t*pDF#Q~{X\u0011s\b* 4ywT/!_=,Wj";
      m[51] = "E\u0018!\\GMI\u00154T6ZLu9_\\\u0000\u001eD9FKW\"\u001c6S\u000b\u0001\u0013\u001c/D\\=E\u0018!\\GMI\u00154T6";
      m[52] = "\u0005]3\u0002$6\u0000OoKM'>Q7\u0001|7C\u0015|\t'NXK3W-uW\u00106CM";
      m[53] = "\u001d\u001doV*4T\u0013h\u0005R2$_oQ9f_\u0000=\u0000c[\u0014Si\u0000o K\u00018ZR";
      m[54] = "KE\u0005%\u000bz\u0019^\u001191u\u0007S\u0005+Ms\u0001>NyP+\u001cW\u000f$R/{";
      m[55] = "0pQo(<q0\u001d0I/\u000b1Gz'8{!N~I";
      m[56] = "vm\u0006/.\u0002p*\u0013<\\\u0005po\u0001707!-^mm`qz\u0004)a\u0003r-\u00137\\\rt,Y(&\u001f&a\u0002P";
      m[57] = "o\u0006#6;$a\u0019o=\u0004&l\u001e3(h\u0014:Zhs5Cj\u001c40v!l[!#\u0004";
      m[58] = "~Mu+wF/Vk6I\u0016rCr!\u001eE+\u0017+}I\u0014zKop*\u0017-\\q";
      m[59] = "U\nk*DyBV*o#r0\u0015n+\u0012bMQ%#I\u001bV\u000fj}C YToi#";
      m[60] = "'Z\u001f.Vb!_GCV|7<H'JwK\u001eG8Yf;\u000eN<7";
      m[61] = "\u0018C_\u001f\u001fj\u0000U\u0002AecaCT\u0015X6PCM\u0002\u000f\n";
      m[62] = "2W\u0010\u0015\u0004{6\u0013E\u0017frbVJ\u0000\n@1\u0012\u0015Zfqk\u0014D\u0007]~0\u0011Pg";
      m[63] = "\u0006\u0014h~a&GIjz\u0006)Z_uAo)]\u00125po0JE\t";
      m[64] = "\u0013y|BH]\u0017w\u007f\u0007v\u000b\u0018~d\u0015!\\F)<yK\u0018Cab\u0015O\\\u0016c";
      m[65] = "\u0002V&{1\u001c\u0013\u001e$<\u000e\u0013cZb;?\u0003\u001e\u001e)3dz\u0005@fmnA\n\u001bcy\u000e";
      m[66] = "@)8B\u0014_@k;\u001ft\u0001B,*\u0014\u00183\u0016hpIOd@a/\u001aD\u0016H91Jt\tFor\u000b\u000e\u001b\u0014\")s";
      m[67] = "0Z~\u0003Nyq\u0007|\u0007)ph\u001aYQYl\u0001]n[\u0017i;\u000fmAV\u0010";
      m[68] = "\u000b,\u007f\u0015:\u0003B\"xFB\u00052 y\u0010s\u0015Od2\u0018(lN88F>\u001c^1<(";
      m[69] = "`\u001a5kV>yO#u9 m\t,jU\u00120Ov09$l\u001b.m\u0001u0\u0019<\r\b8oI1bV(x\u0005Lq_>n\t<aV:\u0000";
      m[70] = "i\u000f<+3p \u0001;xKtP\u0003:.zf-Gq&!\u001f,\u001b{x7o<\u0012\u007f\u0016";
      m[71] = "3\u0017A\\;)5\u0012\u00191$8;R\u0012v4Q#I\u0004_&!3@\u000016iaB\u001eI0l9/";
      m[72] = "\u0000,AYQ{\u0005>\u001d\u00108d; EZ\tzFd\u000eRR\u0003\u0007/\u0018\\A9U,\u0002\u001d8";
      m[73] = "\u001e\u001c/iF\u000f\u000fT-.y\u0000\u007f\u0010k)H\u0010\u0002T !\u0013iC\u001f6/\u0000S\u0011\u001c,ny";
      m[74] = "Os\u000f|\u0012\u000fK}\f9,YDt\u0017+{\u000e\u001a'NGOY\u001c$\u0016{N\b\u001a(";
      m[75] = "\n01Z^:]4gK$'Y6;CH\u0015\tv`\u0014$>R15XT.[5[\u0015Y-\b74KI:DJ";
      m[76] = "V<\u0011pbg\u0004'\u0005lX`\n+k~>c[{Z~'t\fGWf?7\u001f}\u0005e%vf";
      m[77] = "\"`y\u0011vjs{g\fH:.n~\u001b\u001fiw:'HH8&fcJ+;qq}";
      m[78] = "#\f\u0004prz}D\u001c6\u0003\u007f*A\u0019(oM~\u0002F\u007f9\u001a#]\u0012ta\u007f$BDq\u0003";
      m[79] = "R\u000fr\u001d-uV\u0001qX\u0013#Y\bjJDt\u0006U1&})H\u001c1As6\u0004\u0017";
      m[80] = "pm\u0011@y0ugO]H8mr\u0017E\u0016?mh\u001392:2\u007f\u001c\u0004+ls$~";
      m[81] = "t?-<!O0!-gN\u001d\u000f!~o\u007f\rre5g$trn 3q\u001ee<+gN";
      m[82] = "\u0003t\u000b@\u0012\u0002\u0000#\u001c^/\u0004\u0002a\u000e^C6U,W\u0006\u0010a\u0000,\u000bP\u001f\u0013\bt\u0015\u0000/";
      m[83] = "\u00011_K?4\u0013c\u0012\u0010G!\u0001$`\u001a!$QdQ\u001a83\u0006X";
      m[84] = "MtUp+\u0015N#Bn\u0016\u0013LaPnz!\u001c-\n6-vMtUp+\u0015N#Bn\u0016";
      m[85] = "Z>|'k.\u001d7w\"\u0014)Ir, x\u001b\u001d7px,L[lv+erNa6\u007f\u0014";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1081358241762755L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1081358241762755L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1081358241762755L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 220;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 200;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 236;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 240;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 250;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 106;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 220;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 200;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 236;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fs_C0308",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fs" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
