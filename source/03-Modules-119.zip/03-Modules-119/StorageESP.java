package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.ClientChunkManagerAccessor;
import dev.zprestige.prestige.api.accessor.ClientChunkMapAccessor;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.RenderEvents;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.client.management.BlurManager;
import dev.zprestige.prestige.renderlib.ScissorBox;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.PrimitiveMode;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.DropperBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.TrappedChestBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientChunkManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;
import org.joml.Vector3d;

public class StorageESP extends Module {
   private MultiModeSetting a;
   private BooleanSetting d;
   private ColorSetting c;
   private ColorSetting e;
   private ColorSetting f;
   private ColorSetting g;
   private ColorSetting h;
   private ColorSetting i;
   private ColorSetting j;
   private ColorSetting k;
   private ColorSetting l;
   private ColorSetting m;
   private static final int n;
   private static final float o = 15.0F;
   private static BlurManager p;
   private boolean q;
   private List r;
   private static final long s = 33660692940369L;
   private static final String[] t;
   private static final String[] u;
   private static final Map v = new HashMap(13);
   private static final long[] w;
   private static final Integer[] x;
   private static final Map y;
   private static final Object[] z = new Object[105];
   private static final String[] A = new String[105];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;

   public StorageESP() {
      super();
      long var10001 = 130182441265758L ^ 92197780220190L;

      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.r = new ArrayList();
      ColorSetting var10000 = this.i;
      Object[] var6 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var5 = var10000;
      var5.aReturningColorSetting(var6);
      var10000 = this.c;
      Object[] var8 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var7 = var10000;
      var7.aReturningColorSetting(var8);
      var10000 = this.h;
      Object[] var10 = new Object[]{invokeBinding3(this), 41489415177024L};
      ColorSetting var9 = var10000;
      var9.aReturningColorSetting(var10);
      var10000 = this.m;
      Object[] var12 = new Object[]{invokeBinding4(this), 41489415177024L};
      ColorSetting var11 = var10000;
      var11.aReturningColorSetting(var12);
      var10000 = this.k;
      Object[] var14 = new Object[]{invokeBinding5(this), 41489415177024L};
      ColorSetting var13 = var10000;
      var13.aReturningColorSetting(var14);
      var10000 = this.j;
      Object[] var16 = new Object[]{invokeBinding6(this), 41489415177024L};
      ColorSetting var15 = var10000;
      var15.aReturningColorSetting(var16);
      var10000 = this.l;
      Object[] var18 = new Object[]{invokeBinding7(this), 41489415177024L};
      ColorSetting var17 = var10000;
      var17.aReturningColorSetting(var18);
      var10000 = this.g;
      Object[] var20 = new Object[]{invokeBinding8(this), 41489415177024L};
      ColorSetting var19 = var10000;
      var19.aReturningColorSetting(var20);
      var10000 = this.e;
      Object[] var22 = new Object[]{invokeBinding9(this), 41489415177024L};
      ColorSetting var21 = var10000;
      var21.aReturningColorSetting(var22);
      var10000 = this.f;
      Object[] var24 = new Object[]{invokeBinding10(this), 41489415177024L};
      ColorSetting var23 = var10000;
      var23.aReturningColorSetting(var24);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      List var4 = this.r;
      var4.clear();
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 28212019928889L ^ 71432223575125L;
      var10001 = 28212019928889L ^ 46098394959834L;
      var10001 = 28212019928889L ^ 8713338611947L;
      int var10 = Event.cReturningInt();
      int var69 = var10;
      MinecraftClient var68 = b;
      MinecraftClient var59 = var68;
      MinecraftClient var58 = var68;
      if (var69 != 0) {
         MinecraftClient var25 = var58;
         ClientWorld var70 = var25.world;
         if (var70 == null) {
            return;
         }

         MinecraftClient var71 = b;
         var59 = var71;
      }

      int var73 = var10;
      MinecraftClient var72 = var59;
      MinecraftClient var61 = var72;
      MinecraftClient var60 = var72;
      if (var73 != 0) {
         MinecraftClient var28 = var60;
         ClientPlayerEntity var74 = var28.player;
         if (var74 == null) {
            return;
         }

         List var31 = this.r;
         var31.clear();
         var61 = b;
      }

      MinecraftClient var32 = var61;
      ClientWorld var33 = var32.world;
      ClientChunkManager var11 = var33.getChunkManager();
      ClientChunkManagerAccessor var10002 = new ClientChunkManagerAccessor(var11);
      Object[] var35 = new Object[]{53075076829411L};
      ClientChunkManagerAccessor var34 = var10002;
      ClientChunkMapAccessor var10000 = new ClientChunkMapAccessor(var34.aReturningVoid(var35));
      Object[] var37 = new Object[]{98264609379180L};
      ClientChunkMapAccessor var36 = var10000;
      AtomicReferenceArray var12 = var36.aReturningVoid(var37);
      int var89;
      do {
         AtomicReferenceArray var38 = var12;
         int var76 = var38.length();
         int var75 = var13;
         if (var75 >= var76) {
            break;
         }

         int var40 = var13;
         AtomicReferenceArray var39 = var12;
         Object var62 = var39.get(var40);

         label60:
         while (true) {
            WorldChunk var14 = (WorldChunk)var62;
            int var78 = var10;
            WorldChunk var77 = var14;
            WorldChunk var64 = var77;
            WorldChunk var63 = var77;
            if (var78 != 0) {
               WorldChunk var79 = var63;
               if (var79 == null) {
                  break;
               }

               var64 = var14;
            }

            WorldChunk var41 = var64;
            Map var42 = var41.getBlockEntities();
            Set var43 = var42.entrySet();
            Iterator var15 = var43.iterator();

            while (true) {
               Iterator var44 = var15;
               boolean var80 = var44.hasNext();
               if (!var80) {
                  break label60;
               }

               Iterator var45 = var15;
               Entry var16 = (Entry)var45.next();
               Entry var46 = var16;
               BlockEntity var17 = (BlockEntity)var46.getValue();
               int var82 = var10;
               BlockEntity var81 = var17;
               var62 = var81;
               BlockEntity var65 = var81;
               if (var82 == 0) {
                  break;
               }

               BlockEntity var83 = var65;
               if (var83 != null) {
                  Object[] var48 = new Object[]{var17, 33278012618706L};
                  StorageESP var47 = this;
                  Color var18 = var47.aReturningColor(var48);
                  int var85 = var10;
                  Color var84 = var18;
                  Object var67 = var84;
                  Color var66 = var84;
                  if (var85 != 0) {
                     Color var86 = var66;
                     if (var86 == null) {
                        continue;
                     }

                     Entry var50 = var16;
                     var67 = var50.getKey();
                  }

                  BlockPos var19 = (BlockPos)var67;
                  BlockPos var87 = var19;
                  if (var87 != null) {
                     Color var52 = var18;
                     int var20 = var52.getRGB();
                     int var21 = var20 >> 16 & 0xFF;
                     int var22 = var20 >> 8 & 0xFF;
                     int var23 = var20 & 0xFF;
                     short var90 = 20136;
                     var10001 = 3509593278970849441L;
                     int var24 = 0xFF000000 | var23 << 16 | var22 << 8 | var21;
                     List var91 = this.r;
                     BlockPos var53 = var19;
                     int var10003 = var53.getX();
                     BlockPos var54 = var19;
                     int var10004 = var54.getY();
                     BlockPos var55 = var19;
                     ScissorBox var57 = new ScissorBox(var10003, var10004, var55.getZ(), var24);
                     List var56 = var91;
                     var56.add(var57);
                     int var88 = var10;
                     if (var88 == 0) {
                        break label60;
                     }
                  }
               }
            }
         }

         var13++;
         var89 = var10;
      } while (var89 != 0);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      int var4 = Event.cReturningInt();
      int var11 = var4;
      StorageESP var10 = this;
      StorageESP var9 = var10;
      StorageESP var8 = var10;
      if (var11 != 0) {
         boolean var12 = var8.q;
         if (var12) {
            return;
         }

         net.fabricmc.fabric.api.event.Event var10000 = RenderEvents.c;
         RenderCallback var7 = invokeBinding11(this);
         net.fabricmc.fabric.api.event.Event var6 = var10000;
         var6.register(var7);
         StorageESP var13 = this;
         var9 = var13;
      }

      var9.q = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 60293987392542L ^ 115432559382819L;
      var10001 = 60293987392542L ^ 67452072975524L;
      var10001 = 60293987392542L ^ 26398696907053L;
      var10001 = 60293987392542L ^ 65367238033328L;
      var10001 = 60293987392542L ^ 66881811287361L;
      var10001 = 60293987392542L ^ 48354312295958L;
      var10001 = 60293987392542L ^ 59568303484919L;
      var10001 = 60293987392542L ^ 84448808887567L;
      var10001 = 60293987392542L ^ 24677168996412L;
      int var22 = Event.cReturningInt();
      int var179 = var22;
      MinecraftClient var178 = b;
      MinecraftClient var177 = var178;
      MinecraftClient var176 = var178;
      if (var179 != 0) {
         MinecraftClient var39 = var176;
         ClientWorld var180 = var39.world;
         if (var180 == null) {
            return;
         }

         MinecraftClient var181 = b;
         var177 = var181;
      }

      MinecraftClient var42 = var177;
      ClientPlayerEntity var182 = var42.player;
      if (var182 != null) {
         Object[] var45 = new Object[]{103536444689725L};
         StorageESP var44 = this;
         boolean var183 = var44.dReturningBoolean(var45);
         if (var183) {
            Object[] var47 = new Object[]{32075153984008L};
            BlurManager var23 = aReturningfS_C0307(var47);
            Object[] var49 = new Object[]{134243715004689L};
            BlurManager var48 = var23;
            DrawPipeline var24 = var48.aReturningdn_C0192(var49);
            MeshBufferManager var10000 = var1.a;
            Object[] var51 = new Object[]{var24, 35905127005218L};
            MeshBufferManager var50 = var10000;
            GlBufferMeshBuilder var25 = var50.aReturningGlBufferMeshBuilder(var51);
            Matrix4f var26 = new Matrix4f();
            boolean var27 = false;
            Object[] var53 = new Object[]{12707221340346L};
            GlBufferMeshBuilder var52 = var25;
            var52.kReturningVoid(var53);
            List var54 = this.r;
            Iterator var28 = var54.iterator();

            while (true) {
               Iterator var55 = var28;
               boolean var184 = var55.hasNext();
               if (var184) {
                  Iterator var56 = var28;
                  ScissorBox var29 = (ScissorBox)var56.next();
                  ScissorBox var57 = var29;
                  int var30 = var57.bU();
                  RenderContext var189 = var1.b;
                  ScissorBox var58 = var29;
                  double var247 = var58.bR();
                  ScissorBox var59 = var29;
                  double var10002 = var59.bS();
                  ScissorBox var60 = var29;
                  double var10003 = var60.bT();
                  Object[] var10006 = new Object[]{null, null, null, null, 51488692960563L};
                  var10006[3] = var10003;
                  var10006[2] = var10002;
                  var10006[1] = var247;
                  var10006[0] = var189;
                  Object[] var61 = var10006;
                  Vector3d var31 = RenderThreadUtil.aReturningVector3d(var61);
                  RenderContext var190 = var1.b;
                  ScissorBox var62 = var29;
                  double var248 = var62.bR() + 1.0F;
                  ScissorBox var63 = var29;
                  var10002 = var63.bS() + 1.0F;
                  ScissorBox var64 = var29;
                  var10003 = var64.bT() + 1.0F;
                  var10006 = new Object[]{null, null, null, null, 51488692960563L};
                  var10006[3] = var10003;
                  var10006[2] = var10002;
                  var10006[1] = var248;
                  var10006[0] = var190;
                  Object[] var65 = var10006;
                  Vector3d var32 = RenderThreadUtil.aReturningVector3d(var65);
                  Vector3d var66 = var31;
                  float var33 = (float)var66.x;
                  Vector3d var67 = var31;
                  float var34 = (float)var67.y;
                  Vector3d var68 = var31;
                  float var35 = (float)var68.z;
                  Vector3d var69 = var32;
                  float var36 = (float)var69.x;
                  Vector3d var70 = var32;
                  float var37 = (float)var70.y;
                  Vector3d var71 = var32;
                  float var38 = (float)var71.z;
                  Object[] var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var73 = var10007;
                  GlBufferMeshBuilder var72 = var25;
                  GlBufferMeshBuilder var191 = var72.dReturningGlBufferMeshBuilder(var73);
                  Object[] var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var75 = var10004;
                  GlBufferMeshBuilder var74 = var191;
                  GlBufferMeshBuilder var192 = var74.eReturningGlBufferMeshBuilder(var75);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var77 = var10007;
                  GlBufferMeshBuilder var76 = var192;
                  GlBufferMeshBuilder var193 = var76.dReturningGlBufferMeshBuilder(var77);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var79 = var10004;
                  GlBufferMeshBuilder var78 = var193;
                  GlBufferMeshBuilder var194 = var78.eReturningGlBufferMeshBuilder(var79);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var81 = var10007;
                  GlBufferMeshBuilder var80 = var194;
                  GlBufferMeshBuilder var195 = var80.dReturningGlBufferMeshBuilder(var81);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var83 = var10004;
                  GlBufferMeshBuilder var82 = var195;
                  GlBufferMeshBuilder var196 = var82.eReturningGlBufferMeshBuilder(var83);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var85 = var10007;
                  GlBufferMeshBuilder var84 = var196;
                  GlBufferMeshBuilder var197 = var84.dReturningGlBufferMeshBuilder(var85);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var87 = var10004;
                  GlBufferMeshBuilder var86 = var197;
                  GlBufferMeshBuilder var198 = var86.eReturningGlBufferMeshBuilder(var87);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var89 = var10007;
                  GlBufferMeshBuilder var88 = var198;
                  GlBufferMeshBuilder var199 = var88.dReturningGlBufferMeshBuilder(var89);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var91 = var10004;
                  GlBufferMeshBuilder var90 = var199;
                  GlBufferMeshBuilder var200 = var90.eReturningGlBufferMeshBuilder(var91);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var93 = var10007;
                  GlBufferMeshBuilder var92 = var200;
                  GlBufferMeshBuilder var201 = var92.dReturningGlBufferMeshBuilder(var93);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var95 = var10004;
                  GlBufferMeshBuilder var94 = var201;
                  GlBufferMeshBuilder var202 = var94.eReturningGlBufferMeshBuilder(var95);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var97 = var10007;
                  GlBufferMeshBuilder var96 = var202;
                  GlBufferMeshBuilder var203 = var96.dReturningGlBufferMeshBuilder(var97);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var99 = var10004;
                  GlBufferMeshBuilder var98 = var203;
                  GlBufferMeshBuilder var204 = var98.eReturningGlBufferMeshBuilder(var99);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var101 = var10007;
                  GlBufferMeshBuilder var100 = var204;
                  GlBufferMeshBuilder var205 = var100.dReturningGlBufferMeshBuilder(var101);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var103 = var10004;
                  GlBufferMeshBuilder var102 = var205;
                  GlBufferMeshBuilder var206 = var102.eReturningGlBufferMeshBuilder(var103);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var105 = var10007;
                  GlBufferMeshBuilder var104 = var206;
                  GlBufferMeshBuilder var207 = var104.dReturningGlBufferMeshBuilder(var105);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var107 = var10004;
                  GlBufferMeshBuilder var106 = var207;
                  GlBufferMeshBuilder var208 = var106.eReturningGlBufferMeshBuilder(var107);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var109 = var10007;
                  GlBufferMeshBuilder var108 = var208;
                  GlBufferMeshBuilder var209 = var108.dReturningGlBufferMeshBuilder(var109);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var111 = var10004;
                  GlBufferMeshBuilder var110 = var209;
                  GlBufferMeshBuilder var210 = var110.eReturningGlBufferMeshBuilder(var111);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var113 = var10007;
                  GlBufferMeshBuilder var112 = var210;
                  GlBufferMeshBuilder var211 = var112.dReturningGlBufferMeshBuilder(var113);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var115 = var10004;
                  GlBufferMeshBuilder var114 = var211;
                  GlBufferMeshBuilder var212 = var114.eReturningGlBufferMeshBuilder(var115);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var117 = var10007;
                  GlBufferMeshBuilder var116 = var212;
                  GlBufferMeshBuilder var213 = var116.dReturningGlBufferMeshBuilder(var117);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var119 = var10004;
                  GlBufferMeshBuilder var118 = var213;
                  GlBufferMeshBuilder var214 = var118.eReturningGlBufferMeshBuilder(var119);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var121 = var10007;
                  GlBufferMeshBuilder var120 = var214;
                  GlBufferMeshBuilder var215 = var120.dReturningGlBufferMeshBuilder(var121);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var123 = var10004;
                  GlBufferMeshBuilder var122 = var215;
                  GlBufferMeshBuilder var216 = var122.eReturningGlBufferMeshBuilder(var123);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var125 = var10007;
                  GlBufferMeshBuilder var124 = var216;
                  GlBufferMeshBuilder var217 = var124.dReturningGlBufferMeshBuilder(var125);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var127 = var10004;
                  GlBufferMeshBuilder var126 = var217;
                  GlBufferMeshBuilder var218 = var126.eReturningGlBufferMeshBuilder(var127);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var129 = var10007;
                  GlBufferMeshBuilder var128 = var218;
                  GlBufferMeshBuilder var219 = var128.dReturningGlBufferMeshBuilder(var129);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var131 = var10004;
                  GlBufferMeshBuilder var130 = var219;
                  GlBufferMeshBuilder var220 = var130.eReturningGlBufferMeshBuilder(var131);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var133 = var10007;
                  GlBufferMeshBuilder var132 = var220;
                  GlBufferMeshBuilder var221 = var132.dReturningGlBufferMeshBuilder(var133);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var135 = var10004;
                  GlBufferMeshBuilder var134 = var221;
                  GlBufferMeshBuilder var222 = var134.eReturningGlBufferMeshBuilder(var135);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var137 = var10007;
                  GlBufferMeshBuilder var136 = var222;
                  GlBufferMeshBuilder var223 = var136.dReturningGlBufferMeshBuilder(var137);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var139 = var10004;
                  GlBufferMeshBuilder var138 = var223;
                  GlBufferMeshBuilder var224 = var138.eReturningGlBufferMeshBuilder(var139);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var141 = var10007;
                  GlBufferMeshBuilder var140 = var224;
                  GlBufferMeshBuilder var225 = var140.dReturningGlBufferMeshBuilder(var141);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var143 = var10004;
                  GlBufferMeshBuilder var142 = var225;
                  GlBufferMeshBuilder var226 = var142.eReturningGlBufferMeshBuilder(var143);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var145 = var10007;
                  GlBufferMeshBuilder var144 = var226;
                  GlBufferMeshBuilder var227 = var144.dReturningGlBufferMeshBuilder(var145);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var147 = var10004;
                  GlBufferMeshBuilder var146 = var227;
                  GlBufferMeshBuilder var228 = var146.eReturningGlBufferMeshBuilder(var147);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var33;
                  var10007[0] = var26;
                  Object[] var149 = var10007;
                  GlBufferMeshBuilder var148 = var228;
                  GlBufferMeshBuilder var229 = var148.dReturningGlBufferMeshBuilder(var149);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var151 = var10004;
                  GlBufferMeshBuilder var150 = var229;
                  GlBufferMeshBuilder var230 = var150.eReturningGlBufferMeshBuilder(var151);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var153 = var10007;
                  GlBufferMeshBuilder var152 = var230;
                  GlBufferMeshBuilder var231 = var152.dReturningGlBufferMeshBuilder(var153);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var155 = var10004;
                  GlBufferMeshBuilder var154 = var231;
                  GlBufferMeshBuilder var232 = var154.eReturningGlBufferMeshBuilder(var155);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var35;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var157 = var10007;
                  GlBufferMeshBuilder var156 = var232;
                  GlBufferMeshBuilder var233 = var156.dReturningGlBufferMeshBuilder(var157);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var159 = var10004;
                  GlBufferMeshBuilder var158 = var233;
                  GlBufferMeshBuilder var234 = var158.eReturningGlBufferMeshBuilder(var159);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var37;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var161 = var10007;
                  GlBufferMeshBuilder var160 = var234;
                  GlBufferMeshBuilder var235 = var160.dReturningGlBufferMeshBuilder(var161);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var163 = var10004;
                  GlBufferMeshBuilder var162 = var235;
                  GlBufferMeshBuilder var236 = var162.eReturningGlBufferMeshBuilder(var163);
                  var10007 = new Object[]{null, null, null, null, 11005504115039L};
                  var10007[3] = var38;
                  var10007[2] = var34;
                  var10007[1] = var36;
                  var10007[0] = var26;
                  Object[] var165 = var10007;
                  GlBufferMeshBuilder var164 = var236;
                  GlBufferMeshBuilder var237 = var164.dReturningGlBufferMeshBuilder(var165);
                  var10004 = new Object[]{null, 15003238523822L};
                  var10004[0] = var30;
                  Object[] var167 = var10004;
                  GlBufferMeshBuilder var166 = var237;
                  var166.eReturningGlBufferMeshBuilder(var167);
                  var27 = true;
                  int var185 = var22;
                  if (var185 == 0) {
                     break;
                  }

                  int var186 = var22;
                  if (var186 != 0) {
                     continue;
                  }
               }

               boolean var187 = var27;
               if (var187) {
                  Object[] var170 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
                  GlBufferMeshBuilder var169 = var25;
                  GlBufferMeshBuilder var238 = (GlBufferMeshBuilder)var169.iReturningVoid(var170);
                  Object[] var172 = new Object[0];
                  GlBufferMeshBuilder var171 = var238;
                  var171.hReturningGlBufferMeshBuilder(var172);
                  int var188 = var22;
                  if (var188 != 0) {
                     return;
                  }
               }
               break;
            }

            Object[] var175 = new Object[0];
            GlBufferMeshBuilder var174 = var25;
            var174.hReturningGlBufferMeshBuilder(var175);
         }
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 33660692940369L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var5 = b;
      int var14 = var4;
      Screen var13 = var5.currentScreen;
      Screen var9 = var13;
      Screen var8 = var13;
      if (var14 != 0) {
         Screen var15 = var8;
         if (var15 == null) {
            return true;
         }

         MinecraftClient var7 = b;
         Screen var16 = var7.currentScreen;
         var9 = var16;
      }

      byte var21 = ((byte)((var9 instanceof ChatScreen) ? 1 : 0));
      int var18 = var4;
      byte var17 = var21;
      byte var11 = var17;
      byte var10 = var17;
      if (var18 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var11);
      }

      byte var19 = var10;
      return var19 != 0;
   }

   private Color aReturningColor(Object[] var1) {
      BlockEntity var2 = (BlockEntity)var1[0];
      long var3 = (Long)var1[1];
      var3 = 33660692940369L ^ var3;
      long var5 = var3 ^ 70520936983533L;
      int var7 = Event.cReturningInt();
      boolean var10000 = var2 instanceof TrappedChestBlockEntity;
      int var138 = var7;
      boolean var137 = var10000;
      boolean var82 = var137;
      boolean var77 = var137;
      if (var138 != 0) {
         boolean var139 = var77;
         if (var139) {
            int var141 = var7;
            MultiModeSetting var140 = this.a;
            Object var80 = var140;
            MultiModeSetting var78 = var140;
            if (var141 != 0) {
               MultiModeSetting var142 = var78;
               MultiModeSetting var79 = var142;
               short var237 = 31873;
               long var246 = 416448510431245220L ^ var3;
               Object[] var11 = new Object[]{"Trapped Chests", var5};
               MultiModeSetting var10 = var79;
               boolean var143 = var10.aReturningBoolean(var11);
               if (!var143) {
                  return null;
               }

               ColorSetting var13 = this.e;
               Object var144 = var13.aReturningObject();
               var80 = var144;
            }

            return (Color)var80;
         }

         var82 = var2 instanceof ChestBlockEntity;
      }

      int var147 = var7;
      boolean var146 = var82;
      boolean var88 = var146;
      boolean var83 = var146;
      if (var147 != 0) {
         boolean var148 = var83;
         if (var148) {
            int var150 = var7;
            MultiModeSetting var149 = this.a;
            Object var86 = var149;
            MultiModeSetting var84 = var149;
            if (var150 != 0) {
               MultiModeSetting var151 = var84;
               MultiModeSetting var85 = var151;
               short var236 = 12123;
               long var245 = 4200980187756159090L ^ var3;
               Object[] var18 = new Object[]{"Chests", var5};
               MultiModeSetting var17 = var85;
               boolean var152 = var17.aReturningBoolean(var18);
               if (!var152) {
                  return null;
               }

               ColorSetting var20 = this.c;
               Object var153 = var20.aReturningObject();
               var86 = var153;
            }

            return (Color)var86;
         }

         var88 = var2 instanceof EnderChestBlockEntity;
      }

      int var156 = var7;
      boolean var155 = var88;
      boolean var94 = var155;
      boolean var89 = var155;
      if (var156 != 0) {
         boolean var157 = var89;
         if (var157) {
            int var159 = var7;
            MultiModeSetting var158 = this.a;
            Object var92 = var158;
            MultiModeSetting var90 = var158;
            if (var159 != 0) {
               MultiModeSetting var160 = var90;
               MultiModeSetting var91 = var160;
               short var235 = 2747;
               long var244 = 4670805203640403351L ^ var3;
               Object[] var25 = new Object[]{"Ender Chests", var5};
               MultiModeSetting var24 = var91;
               boolean var161 = var24.aReturningBoolean(var25);
               if (!var161) {
                  return null;
               }

               ColorSetting var27 = this.f;
               Object var162 = var27.aReturningObject();
               var92 = var162;
            }

            return (Color)var92;
         }

         var94 = var2 instanceof ShulkerBoxBlockEntity;
      }

      int var165 = var7;
      boolean var164 = var94;
      boolean var100 = var164;
      boolean var95 = var164;
      if (var165 != 0) {
         boolean var166 = var95;
         if (var166) {
            int var168 = var7;
            MultiModeSetting var167 = this.a;
            Object var98 = var167;
            MultiModeSetting var96 = var167;
            if (var168 != 0) {
               MultiModeSetting var169 = var96;
               MultiModeSetting var97 = var169;
               short var234 = 14737;
               long var243 = 1328001435425928873L ^ var3;
               Object[] var32 = new Object[]{"Shulker Boxes", var5};
               MultiModeSetting var31 = var97;
               boolean var170 = var31.aReturningBoolean(var32);
               if (!var170) {
                  return null;
               }

               ColorSetting var34 = this.g;
               Object var171 = var34.aReturningObject();
               var98 = var171;
            }

            return (Color)var98;
         }

         var100 = var2 instanceof BarrelBlockEntity;
      }

      int var174 = var7;
      boolean var173 = var100;
      boolean var106 = var173;
      boolean var101 = var173;
      if (var174 != 0) {
         boolean var175 = var101;
         if (var175) {
            int var177 = var7;
            MultiModeSetting var176 = this.a;
            Object var104 = var176;
            MultiModeSetting var102 = var176;
            if (var177 != 0) {
               MultiModeSetting var178 = var102;
               MultiModeSetting var103 = var178;
               short var233 = 14494;
               long var242 = 8531241069361461180L ^ var3;
               Object[] var39 = new Object[]{"Barrels", var5};
               MultiModeSetting var38 = var103;
               boolean var179 = var38.aReturningBoolean(var39);
               if (!var179) {
                  return null;
               }

               ColorSetting var41 = this.h;
               Object var180 = var41.aReturningObject();
               var104 = var180;
            }

            return (Color)var104;
         }

         var106 = var2 instanceof HopperBlockEntity;
      }

      int var183 = var7;
      boolean var182 = var106;
      boolean var112 = var182;
      boolean var107 = var182;
      if (var183 != 0) {
         boolean var184 = var107;
         if (var184) {
            int var186 = var7;
            MultiModeSetting var185 = this.a;
            Object var110 = var185;
            MultiModeSetting var108 = var185;
            if (var186 != 0) {
               MultiModeSetting var187 = var108;
               MultiModeSetting var109 = var187;
               short var232 = 7709;
               long var241 = 6587136747412803895L ^ var3;
               Object[] var46 = new Object[]{"Hoppers", var5};
               MultiModeSetting var45 = var109;
               boolean var188 = var45.aReturningBoolean(var46);
               if (!var188) {
                  return null;
               }

               ColorSetting var48 = this.i;
               Object var189 = var48.aReturningObject();
               var110 = var189;
            }

            return (Color)var110;
         }

         var112 = var2 instanceof DropperBlockEntity;
      }

      int var192 = var7;
      boolean var191 = var112;
      boolean var118 = var191;
      boolean var113 = var191;
      if (var192 != 0) {
         boolean var193 = var113;
         if (var193) {
            int var195 = var7;
            MultiModeSetting var194 = this.a;
            Object var116 = var194;
            MultiModeSetting var114 = var194;
            if (var195 != 0) {
               MultiModeSetting var196 = var114;
               MultiModeSetting var115 = var196;
               short var231 = 2381;
               long var240 = 7412355415913547363L ^ var3;
               Object[] var53 = new Object[]{"Droppers", var5};
               MultiModeSetting var52 = var115;
               boolean var197 = var52.aReturningBoolean(var53);
               if (!var197) {
                  return null;
               }

               ColorSetting var55 = this.k;
               Object var198 = var55.aReturningObject();
               var116 = var198;
            }

            return (Color)var116;
         }

         var118 = var2 instanceof DispenserBlockEntity;
      }

      int var201 = var7;
      boolean var200 = var118;
      boolean var124 = var200;
      boolean var119 = var200;
      if (var201 != 0) {
         boolean var202 = var119;
         if (var202) {
            int var204 = var7;
            MultiModeSetting var203 = this.a;
            Object var122 = var203;
            MultiModeSetting var120 = var203;
            if (var204 != 0) {
               MultiModeSetting var205 = var120;
               MultiModeSetting var121 = var205;
               short var230 = 16152;
               long var239 = 7954261162932367419L ^ var3;
               Object[] var60 = new Object[]{"Dispensers", var5};
               MultiModeSetting var59 = var121;
               boolean var206 = var59.aReturningBoolean(var60);
               if (!var206) {
                  return null;
               }

               ColorSetting var62 = this.j;
               Object var207 = var62.aReturningObject();
               var122 = var207;
            }

            return (Color)var122;
         }

         var124 = var2 instanceof AbstractFurnaceBlockEntity;
      }

      int var210 = var7;
      boolean var209 = var124;
      boolean var130 = var209;
      boolean var125 = var209;
      if (var210 != 0) {
         boolean var211 = var125;
         if (var211) {
            int var213 = var7;
            MultiModeSetting var212 = this.a;
            Object var128 = var212;
            MultiModeSetting var126 = var212;
            if (var213 != 0) {
               MultiModeSetting var214 = var126;
               MultiModeSetting var127 = var214;
               short var229 = 13099;
               long var238 = 741083257319783434L ^ var3;
               Object[] var67 = new Object[]{"Furnaces", var5};
               MultiModeSetting var66 = var127;
               boolean var215 = var66.aReturningBoolean(var67);
               if (!var215) {
                  return null;
               }

               ColorSetting var69 = this.l;
               Object var216 = var69.aReturningObject();
               var128 = var216;
            }

            return (Color)var128;
         }

         var130 = var2 instanceof BrewingStandBlockEntity;
      }

      int var219 = var7;
      boolean var218 = var130;
      boolean var134 = var218;
      boolean var131 = var218;
      if (var219 != 0) {
         boolean var220 = var131;
         if (!var220) {
            return null;
         }

         int var222 = var7;
         MultiModeSetting var221 = this.a;
         MultiModeSetting var135 = var221;
         MultiModeSetting var132 = var221;
         if (var222 == 0) {
            return (Color)((java.awt.Color)(Object)(var135));
         }

         MultiModeSetting var223 = var132;
         MultiModeSetting var133 = var223;
         short var10001 = 16868;
         long var10002 = 8070660665081564866L ^ var3;
         Object[] var74 = new Object[]{"Brewing Stands", var5};
         MultiModeSetting var73 = var133;
         boolean var224 = var73.aReturningBoolean(var74);
         var134 = var224;
      }

      boolean var225 = var134;
      if (!var225) {
         return null;
      }

      ColorSetting var76 = this.m;
      Object var226 = var76.aReturningObject();
      Object var247 = var226;
      return (Color)var247;
   }

   private static synchronized BlurManager aReturningfS_C0307(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 33660692940369L ^ var1;
      long var3 = var1 ^ 68569990735552L;
      int var5 = Event.bReturningInt();
      int var9 = var5;
      BlurManager var8 = p;
      BlurManager var7 = var8;
      BlurManager var6 = var8;
      if (var9 == 0) {
         BlurManager var10 = var6;
         if (var10 == null) {
            p = new BlurManager(var3);
         }

         var7 = p;
      }

      return var7;
   }

   private void lambda$onEnable$10(MeshBufferManager var1, RenderContext var2) {
      long var10001 = 83355442584101L ^ 24076622649112L;
      var10001 = 83355442584101L ^ 95535770062893L;
      var10001 = 83355442584101L ^ 62671630215917L;
      int var11 = Event.bReturningInt();
      StorageESP var13 = this;
      boolean var10000 = var13.aReturningBoolean();
      int var36 = var11;
      boolean var35 = var10000;
      boolean var24 = var35;
      boolean var23 = var35;
      if (var36 == 0) {
         boolean var37 = var23;
         if (!var37) {
            return;
         }

         Object[] var16 = new Object[]{103536444689725L};
         StorageESP var15 = this;
         var24 = var15.dReturningBoolean(var16);
      }

      boolean var38 = var24;
      if (var38) {
         Object[] var17 = new Object[]{32075153984008L};
         BlurManager var12 = aReturningfS_C0307(var17);
         BooleanSetting var18 = this.d;
         Boolean var19 = (Boolean)var18.aReturningObject();
         boolean var42 = var19;
         float var41 = 15.0F;
         byte var40 = 2;
         BlurManager var39 = var12;
         BlurManager var28 = var39;
         byte var29 = var40;
         float var30 = var41;
         BlurManager var25 = var39;
         byte var26 = var40;
         float var27 = var41;
         BlurManager var31;
         byte var32;
         float var33;
         float var34;
         if (var42) {
            float var46 = 0.3F;
            float var45 = var27;
            byte var44 = var26;
            BlurManager var43 = var25;
            var31 = var43;
            var32 = var44;
            var33 = var45;
            var34 = var46;
         } else {
            var34 = 0.0F;
            var33 = var30;
            var32 = var29;
            var31 = var28;
         }

         Object[] var10006 = new Object[]{null, null, null, 126651401384136L};
         var10006[2] = var34;
         var10006[1] = var33;
         var10006[0] = Integer.valueOf(var32);
         Object[] var22 = var10006;
         BlurManager var21 = var31;
         var21.bReturningVoid(var22);
      }
   }

   private boolean lambda$new$9(Color var1) {
      long var10001 = 36919243597932L ^ 107106161668610L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Brewing Stands", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$8(Color var1) {
      long var10001 = 128218404996017L ^ 57618507078111L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Furnaces", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$7(Color var1) {
      long var10001 = 58607849677362L ^ 129432108005468L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Droppers", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$6(Color var1) {
      long var10001 = 21030776565511L ^ 92199746876777L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Dispensers", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$5(Color var1) {
      long var10001 = 40551922351989L ^ 110070552814875L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Hoppers", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$4(Color var1) {
      long var10001 = 2109898300639L ^ 71542501492401L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Barrels", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$3(Color var1) {
      long var10001 = 96080121951747L ^ 25941926980717L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Shulker Boxes", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$2(Color var1) {
      long var10001 = 113257050914933L ^ 43962221435419L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Ender Chests", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$1(Color var1) {
      long var10001 = 5092715597501L ^ 75161044735187L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Trapped Chests", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$0(Color var1) {
      long var10001 = 54894400229259L ^ 124345475634661L;
      MultiModeSetting var10000 = this.a;
      Object[] var7 = new Object[]{"Chests", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(8866233536956L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[20];
      String var17 = "\u00147\u0016ô\u0012*\u0082s)Ì<èN~³K\u0010\u008cék\tâðD{\u0084ñ§'¿â'k ©Õã3`\u000bØ\u0019î½jóvÅ\u0019 8JÌÁdÞ-Ësß76õBÒ~\u0010WÃô¾¾\u009aHÜ2\u0014õ½\u0099\u009f\u0000ë sº\u009eN\u0081ú{\u001dû)Âq\u0003Þ5Ù\u0011ëÍ=XT\u008bt\u008d\u0000þ\u0017)âÇÕ\u0010ÚX·¡³2AÝ\n¹s\u0096\u008cbÑa\u0018¯'á\u0085\u0003övÆ·?aW\ned³Â\u0095&\u0094\u0098\f\u000bá\u0010û#1AÞÄ;l%þÔØ\"wT\u0014\u0010G°\u0014ú\u0007«©£Ó93º\u00ad\nÁR ²+lW\u0094ñÑù\u0005»®b@îÑÙBTâÒ\u0018ãæ¹õ\u0004vq\u0000\u007f*] \u0089ü\fº3\u001b\u0000¹ð±\u0011\u0011¢FÿitnT7Ät¦\u001fZ»\u0091\u0098ÌÔZè\u0018!:\u009e{ç\u0093µ±J\u009dn©ï%\u00943\u0013\u001dèr½4&ö S#Ùx\u0003\u009d\u0082kðå,å¼zÅä·\u0093\u0018\u008a¹\u0081\u0084J¬¸\u001bi|\u0083fâ ´t!;\u00802\u0016ª¥\"üº-ü\u0085q\u008c\u0015r\u0082õ\n\u001fñN\u008af¬0`\u008bF\u0018UCg\u0088µÑ\u00076T\\]\u009c±æijõ³\u0089L!£6´ g®z/L\u001eÇÿ\u000e{a²\u009cÉy§$æu\u0095hÌ\u0090\u0082ÔÅ\u0014\u0017'Aõ$ +zï\u0081\u0094©2\u009b\b\u009b3¾Á\u0089\u009c\u009e¬P\u0092u+\u0092\u0004\b>c²\u0086\u001e\u0000@k ý\u008bòÿÍy_úÜ\u0013\u008dó\u0011q\u0012\u0084qg(ó\u0010øú\u009aùÐ³\u0099\u0004`ßq";
      int var19 = "\u00147\u0016ô\u0012*\u0082s)Ì<èN~³K\u0010\u008cék\tâðD{\u0084ñ§'¿â'k ©Õã3`\u000bØ\u0019î½jóvÅ\u0019 8JÌÁdÞ-Ësß76õBÒ~\u0010WÃô¾¾\u009aHÜ2\u0014õ½\u0099\u009f\u0000ë sº\u009eN\u0081ú{\u001dû)Âq\u0003Þ5Ù\u0011ëÍ=XT\u008bt\u008d\u0000þ\u0017)âÇÕ\u0010ÚX·¡³2AÝ\n¹s\u0096\u008cbÑa\u0018¯'á\u0085\u0003övÆ·?aW\ned³Â\u0095&\u0094\u0098\f\u000bá\u0010û#1AÞÄ;l%þÔØ\"wT\u0014\u0010G°\u0014ú\u0007«©£Ó93º\u00ad\nÁR ²+lW\u0094ñÑù\u0005»®b@îÑÙBTâÒ\u0018ãæ¹õ\u0004vq\u0000\u007f*] \u0089ü\fº3\u001b\u0000¹ð±\u0011\u0011¢FÿitnT7Ät¦\u001fZ»\u0091\u0098ÌÔZè\u0018!:\u009e{ç\u0093µ±J\u009dn©ï%\u00943\u0013\u001dèr½4&ö S#Ùx\u0003\u009d\u0082kðå,å¼zÅä·\u0093\u0018\u008a¹\u0081\u0084J¬¸\u001bi|\u0083fâ ´t!;\u00802\u0016ª¥\"üº-ü\u0085q\u008c\u0015r\u0082õ\n\u001fñN\u008af¬0`\u008bF\u0018UCg\u0088µÑ\u00076T\\]\u009c±æijõ³\u0089L!£6´ g®z/L\u001eÇÿ\u000e{a²\u009cÉy§$æu\u0095hÌ\u0090\u0082ÔÅ\u0014\u0017'Aõ$ +zï\u0081\u0094©2\u009b\b\u009b3¾Á\u0089\u009c\u009e¬P\u0092u+\u0092\u0004\b>c²\u0086\u001e\u0000@k ý\u008bòÿÍy_úÜ\u0013\u008dó\u0011q\u0012\u0084qg(ó\u0010øú\u009aùÐ³\u0099\u0004`ßq"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     t = var20;
                     u = new String[20];
                     y = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(8866233536956L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "·I\u0013\bØ¤tÇjÒ\b0'NOË½\u0080,\t?\u009f¢Él\u000e³â\u0089\u007fÆôx6Á«4g:xî\u000eÓ\u0005a\u0081þ¨";
                     int var5 = "·I\u0013\bØ¤tÇjÒ\b0'NOË½\u0080,\t?\u009f¢Él\u000e³â\u0089\u007fÆôx6Á«4g:xî\u000eÓ\u0005a\u0081þ¨".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    w = var6;
                                    x = new Integer[8];
                                    n = 2;
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "}KX\u009c\u0082Eé´*\u00adò\u0092÷*dC";
                                 var5 = "}KX\u009c\u0082Eé´*\u00adò\u0092÷*dC".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "öu`\u0085\u0015è\u0082\u009dk\u0091Ä£N¡!\u0081®å\u001b.\u0082Eé$\u0007¢¢1\u0000Tl\u0085 fðÞÆÚOwZ\u0005hO\u009býÿÅQ.R'x\u0019EØªR@¸)\u0082N&w";
                  var19 = "öu`\u0085\u0015è\u0082\u009dk\u0091Ä£N¡!\u0081®å\u001b.\u0082Eé$\u0007¢¢1\u0000Tl\u0085 fðÞÆÚOwZ\u0005hO\u009býÿÅQ.R'x\u0019EØªR@¸)\u0082N&w"
                     .length();
                  var16 = ' ';
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32425;
      if (u[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])v.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fu", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = t[var5].getBytes("ISO-8859-1");
         u[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return u[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fu_C0312",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9738;
      if (x[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = w[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])y.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fu", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         x[var3] = var15;
      }

      return x[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fu_C0312",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = A[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = z[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 60;
            yield var15;
         }
         case 1 -> {
            byte var16 = 3;
            yield var16;
         }
         case 2 -> {
            byte var17 = 6;
            yield var17;
         }
         case 3 -> {
            byte var18 = 18;
            yield var18;
         }
         case 4 -> {
            byte var19 = 53;
            yield var19;
         }
         case 5 -> {
            byte var20 = 63;
            yield var20;
         }
         case 6 -> {
            byte var21 = 30;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 4;
            yield var23;
         }
         case 9 -> {
            byte var24 = 39;
            yield var24;
         }
         case 10 -> {
            byte var25 = 13;
            yield var25;
         }
         case 11 -> {
            byte var26 = 41;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 11;
            yield var28;
         }
         case 14 -> {
            byte var29 = 55;
            yield var29;
         }
         case 15 -> {
            byte var30 = 48;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 27;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 47;
            yield var34;
         }
         case 20 -> {
            byte var35 = 12;
            yield var35;
         }
         case 21 -> {
            byte var36 = 37;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 57;
            yield var38;
         }
         case 24 -> {
            byte var39 = 14;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 19;
            yield var41;
         }
         case 27 -> {
            byte var42 = 52;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 46;
            yield var44;
         }
         case 30 -> {
            byte var45 = 43;
            yield var45;
         }
         case 31 -> {
            byte var46 = 34;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 35;
            yield var50;
         }
         case 36 -> {
            byte var51 = 26;
            yield var51;
         }
         case 37 -> {
            byte var52 = 16;
            yield var52;
         }
         case 38 -> {
            byte var53 = 25;
            yield var53;
         }
         case 39 -> {
            byte var54 = 42;
            yield var54;
         }
         case 40 -> {
            byte var55 = 44;
            yield var55;
         }
         case 41 -> {
            byte var56 = 61;
            yield var56;
         }
         case 42 -> {
            byte var57 = 28;
            yield var57;
         }
         case 43 -> {
            byte var58 = 5;
            yield var58;
         }
         case 44 -> {
            byte var59 = 22;
            yield var59;
         }
         case 45 -> {
            byte var60 = 51;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 0;
            yield var62;
         }
         case 48 -> {
            byte var63 = 17;
            yield var63;
         }
         case 49 -> {
            byte var64 = 45;
            yield var64;
         }
         case 50 -> {
            byte var65 = 50;
            yield var65;
         }
         case 51 -> {
            byte var66 = 56;
            yield var66;
         }
         case 52 -> {
            byte var67 = 15;
            yield var67;
         }
         case 53 -> {
            byte var68 = 59;
            yield var68;
         }
         case 54 -> {
            byte var69 = 2;
            yield var69;
         }
         case 55 -> {
            byte var70 = 58;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 1;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 23;
            yield var74;
         }
         case 60 -> {
            byte var75 = 32;
            yield var75;
         }
         case 61 -> {
            byte var76 = 40;
            yield var76;
         }
         case 62 -> {
            byte var77 = 8;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            A[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      z[0] = "\fi\u0015,aI\u001ai\u0010vr^\r\"\u0013p~J\u001ce\u0004g5]&";
      z[1] = "\u0016g\u0018~9ScG\u0013q(\u001c\u0002I\u0018z,Fv";
      z[2] = boolean.class;
      A[2] = "java/lang/Boolean";
      z[3] = "[mQ\u0016eLEeKY\u0007PBx";
      z[4] = void.class;
      A[4] = "java/lang/Void";
      z[5] = "x6\u0014\u001514n6\u0011O\"#y}\u0012I.7h:\u0005^e\"i";
      z[6] = ".!)H%O%.8\u0007FB0#7ls@!0+@dM";
      z[7] = "v$X6t\u0015`$]lg\u0002wo^jk\u0016f(I} \u0004W";
      z[8] = int.class;
      A[8] = "java/lang/Integer";
      z[9] = "W\u001aFK\t\bA\u001aC\u0011\u001a\u001fVQ@\u0017\u0016\u000bG\u0016W\u0000]\u001cu";
      z[10] = "; \u0015`sv0/\u0004/\u0012x;$\u0000u";
      z[11] = "|OQ]5^|OF\u00019Qf\u0004F\u001f9Dau\u0016Bh";
      z[12] = "GV>!q\u0002GV)}}\r]\u001d)c}\u0018Zl~<+";
      z[13] = "9l\u0012J$t2c\u0003\u0005Hw<a\u0001Jd";
      z[14] = "Y4CgoRO4F=|EX\u007fE;pQI8R,;Fl";
      z[15] = "Lye}\b+9Ynr\u0019dXWey\u001d>,";
      z[16] = ".\u0001>4g\u000e8\u0001;nt\u0019/J8hx\r>\r/\u007f3\u0018\u0019";
      z[17] = "Nw:#T];W1,E\u0012ZY:'AH.";
      z[18] = "@cE\u0012.A5CN\u001d?\u000eTME\u0016;T ";
      z[19] = "R\u0019sOg\u0018'9x@vWF7sKr\r2";
      z[20] = "(yG\u001d!G>yBG2P)2AA>D8uVVuS\"";
      z[21] = "x?>{t~n?;!giyt8'k}h3/0 lM";
      z[22] = ".#\u0018@7~[\u0003\u0013O&1:\r\u0018D\"kN";
      z[23] = "(J99\u0002T*TpA\rX3W,$\f";
      z[24] = double.class;
      A[24] = "java/lang/Double";
      z[25] = "]T\u001d\u0019p:(t\u0016\u0016auIz\u001d\u001de/=";
      z[26] = "bXy|.[tX|&=Lc\u0013\u007f 1XrTh7zLJ";
      z[27] = "'|\u0006\u000f6U1|\u0003U%B&7\u0000S)V7p\u0017DbF\u0000";
      z[28] = "4\"\f>\bkA\u0002\u00071\u0019$ \f\f:\u001d~T";
      z[29] = "a\u0005\u0011Y!\\w\u0005\u0014\u00032K`N\u0017\u0005>_q\t\u0000\u0012uHo";
      z[30] = "T{\u007f@q=![tO`r@U\u007fDd(4";
      z[31] = "Q\r5\bJDG\r0RYSPF3TUGA\u0001$C\u001eU[";
      z[32] = "\u0005:LR=\u0010p\u001aG],_\u0011\u0014LV(\u0005e";
      z[33] = "DKB<|~1kI3m1PeB8ik$";
      z[34] = "/\">-\f*1*$bk+ 1)8M-";
      z[35] = "\n%\u001cdM+\u007f\u0005\u0017k\\d\u001e\u000b\u001c`X>j";
      z[36] = "|\u0006.\u000f\u001b7|\u00069S\u00178fM9M\u0017-a<l\u0012N";
      z[37] = "\u001adm\u0019\b\u001c\u001adzE\u0004\u0013\u0000/z[\u0004\u0006\u0007^.\u0003S";
      z[38] = "{yJ\n6+wnWG=);z_F\"#v2_T9dpj[J$dPj[J$";
      z[39] = "6\u00042\u007f)\u0004(\f(0J\u0010,";
      z[40] = "?\u0002]{0{!\nG4Mk!";
      z[41] = "\bH1\u0000 Z\u0016@+OCN\u0012\r\u0002\u000fz]\u001b";
      z[42] = "-(p<[?-(g`W07cg~W%0\u00126*\u0007n";
      z[43] = "\bq9nCY\bq.2OV\u0012:.,OC\u0015K\u007fs\u001d\b";
      z[44] = "\u000e'T2\u0010,\u0010/N}]6\n%W!L<\n2\f2J6\t/A}\u007f-\u000b+K0l<\u0002#P6P:\u0001\u0007P!_ ";
      z[45] = "zPN@\u001aqlPK\u001a\tf{\u001bH\u001c\u0005rj\\_\u000bNB";
      z[46] = ":\u0013\u00129\u0004OO3\u00196\u0015\u0000.=\u0012=\u0011ZZ";
      z[47] = "|\"b\f\u0007$j\"gV\u00143}idP\u0018'l.sGS\u0016";
      z[48] = "4xXXCUAXSWR\u001a VX\\V@T";
      z[49] = "eF^/\u001e)eFIs\u0012&\u007f\rIm\u00123x|\u001c2BdhOKr\u0000\u001f8\u0015\u00120";
      z[50] = "|\u001e\u0005\u000e.>\t>\u000e\u0001?qh0\u0005\n;+\u001c";
      z[51] = "Ab&C1\u0018\\w~ap\u0015Dq";
      z[52] = "?.\u0001s\t\u0001?.\u0016/\u0005\u000e%e\u00161\u0005\u001b\"\u0014CnU";
      z[53] = "7\u0017\u0000w^3!\u0017\u0005-M$6\\\u0006+A0'\u001b\u0011<\n'\u001a";
      z[54] = "V\u0011\u000eGx\u000b#1\u0005HiDB?\u000eCm\u001e6";
      z[55] = ";G\u001c:+o4\u0011\u0015|F<Q\u0019H'zhhO\u0003??$QM\u0018+x1aF\b,xU";
      z[56] = "H\u001e6r\u001b/\u0015\u0011~'&>%B5-\u001ac\u001c\u0014~5_/%\u0016iq\u001fcTKf9J^";
      z[57] = "%X6.\u0005lq]z$<rJ\u0004xm\u0006p#\u001d.o\u0002";
      z[58] = "\u00110B\u000b\u001fE@pD]#E+\u000b\u0002\u0006@Q\bqN\u0013_\u001ep";
      z[59] = "(\u000fhad$ Lv+\u0001+IH7|=wp\u001e|dx;I\u0010p|z/'\u00183b0J";
      z[60] = "ZU\u0001\f(MO\u001bS\t\u0016SL[\u007f\u0018g<\u001e\u0017\u0007Et[CVA\u000f\u0016";
      z[61] = "Tt\u000bVr\u001c\u0006$T\\\u0010J\u0005%V\nG\u001d[u\u000ff X\u0004!\u000b\f-\u001bZ#";
      z[62] = "]\b{,fxUKef\u0003u<O$1?+\u0005\u0019o)zg<\u0017c1xsR\u001f /2\u0016";
      z[63] = "Oj\u000b:\u001esE+Uk#`\t:\u0013<_f\u000fW\u000f$\u001fs\u0004i\u0002jFbu";
      z[64] = "\u0011/We\u0014>\u001ca\u000etef\u001a.\u0017\u0017Z0Ln\tp\u0007q\n$k";
      z[65] = "@#nf\f[Oug a\u000b*}:{]\\\u0013+qc\u0018\u0010*~\u007fl\u000b\u0007A e%Xa";
      z[66] = "\u0013f\u0016\u001f.j\u0019'HN\u0013sM6\u001d\n\u0013\"U*\u001e\u0016x|OcMp";
      z[67] = ",I\u0019i]EqFQ<`YA\u0015\u001a6\\\txCQ.\u0019EAAFjY\t0\u001cI\"\f4";
      z[68] = ";tn)3\u00147uxpB\u000f*kcv.=~-9(~j=*z*2\n?ycuB";
      z[69] = "M\u000fw\u0005nrS\u0015\"\u0016\u0007jK\u0019a\u0013{lMt}\u000b;yFJpEbh7";
      z[70] = ".z)*s\u0011!9g(\u001cE>97vpwj}m/$ n\"4odZ\"7+ \u001c";
      z[71] = "@^\u0010eiqW\u0001\u001ec\u0006qPBo\"a}CF\u0015ntb\f>P/=._Y\rn{d=";
      z[72] = "\fz|$-\"^*#.Ot]+!x\u0018#\u0002vz\u0014(hG#4~%u@*";
      z[73] = "xW-l$ew\u0014cnK1h\u001430'\u0003<PiipT8\u000f0)3.t\u001a/fK";
      z[74] = "\u0006V71<u\u001d\t9|Uex\rnhi1A[%p,}xI7q/c\u0017^h\u007f)\f";
      z[75] = "w_\u0002\u0007V;u\u0016HU?xc@[\u0017Cot/\u0005\\\u00042lHX\u001dBx\u000e\u0015F\u001dUdeK\\T\u0006\u0002";
      z[76] = "\u001f$yCP$H$&D(=${/\u001a\u0014i\u001d-d\u0002Q%$0g\u001fNd@r+\u0019PT";
      z[77] = "pr^v\u001a\u001c{u\u001a\u001a\u0011u(5C&EL~~[c\tu(}Ba\b\f!4]xx";
      z[78] = "\u0003\u000b\u0014\u001f\u007f#XT^MOs>Y\tB1aD\u0015\u001c]~\u0019";
      z[79] = "I\u0015\u0000\u00137.\u001d\u0010L\u0019\u000e2&INP42OP\u0018R0";
      z[80] = "+\u0015\u0004'DTzU\u0002qxT\u0010.D*\u001b@2T\b?\u0004\u000fJ";
      z[81] = "Mx$\u0002 SB;j\u0000O\u0007];:^#5\t\u007f`\u0007sb\r 9G7\u0018A5&\bO";
      z[82] = "2RG\u0000d#oC\u001b\u0010\u001eqQ\u0004D\u001b\"%hR\u000f\u0003giQRA\u000fe!?\u0006DCo\u0018";
      z[83] = "W@<^\u001d@_\u0006?[yC2AwFE\u0017\u000b\u0017<^\u0000[2\u0015+\u001a@\u0017CH$R\u0015*";
      z[84] = "%\u0004\rKFx~[G\u0019v)\u0018V\u0010\u0016\b:b\u001a\u0005\tGB";
      z[85] = "\tyP5FCT9Ry-B_\"NdDNf,Nt@(\u00014Mr]Q\b}Rk-";
      z[86] = "#\u000b_\u0000|\u000e~\u0004\u0017UA\u0013NW\\_}Bw\u0001\u0017G8\u000eN\u0003\u0000\u0003xB?^\u000fK-\u007f";
      z[87] = "6d\u001cv\u0001)g$\u001a =)\n_\\{^=/%\u0010nArW";
      z[88] = "pwM|u \"x[z\r N6\u0012;=+)kS}wI";
      z[89] = "_h\u000eRyM\r8QX\u001b\u001b\u000e9S\u000eLLPn\u000bbc\u0007\u0002)\u0006\fx\u0005\u000f:";
      z[90] = ">L)._Q3\u0002p?.\u000f1FS1^\u0013X\u0004d;U\u001f!\r-$Lo";
      z[91] = "/\u0007\u0010V\u001dg~G\u0016\u0000!g\u0012<P[Bs6F\u001cN]<N";
      z[92] = "%e\u000eN\u0007\u00002:\u0000Hh\u000b5c\u001eH\boeb\u0012J\u0010\u0015)w\r\u0005h";
      z[93] = "o7`0rxmdyo\u0002usvczYui\ncpng|s}j;t\u0015";
      z[94] = "Xp&\u0006:v\u000fpy\u0001Boc*%\u0000?h\u001e/1C2\u0006_zpD,{Zn3IB";
      z[95] = "mA[\u000b\fv*\u0013P\\TK=x\u000e^\bwiAX\u0015\u00102%x\u000e^\u0002'6EI\f\tpnx";
      z[96] = "\u0000R7 A\u007f\u0014\u000e{'8qiQ4~Ch\u0010X}aZ\u0018";
      z[97] = "8G-2[JoGr5#V\u0003\u0018{k\u001f\u0007:N0sZK\u0003\u00183jXJz\u0011zuA:";
      z[98] = " \u0019l{\u00169*X2*+\"vH\u000e+\u001bp*FivZ6`$7eL0j]>,S)\u001a";
      z[99] = "_\u00118/>)J_j*\u00007I\u001f[?d%Ic:f;hF\u0004g'}\"$";
      z[100] = "M\b/\u000fl\u0010\u001a\bp\b\u0014\tvWyV(]O\u00012Nm\u0011v\u0004']o\rL\u000bqT)`";
      z[101] = "_GzxP\u0001XL}09\u0017 \u000f$o\u0005C\u0019Yow@\u000f Gp6\u0004\u0013\u0018Xsc_~";
      z[102] = "\"\u000b15V@`G7+fK=\u0006\b\u001c,$m\u001d1-\u001e^!\b.bf";
      z[103] = "\u001c\u0010D\u001fb\u0004\u0011\rC\u0016\u0013\u000b\u0016\u001e_\u001d\u007f9AS\u0004G\u0013WC\u0000G\u0003s\t\u0005\u001f\u0001\u0002\u0013";
      z[104] = "=\u0016y1Sui\u00135;jjRJ7rPi;SapT";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = z[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(A[var4]);
            z[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = z[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            z[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  z[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(733742272789299L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = z[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = A[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  z[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(733742272789299L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        z[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(733742272789299L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 218;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 110;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 249;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 231;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 236;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 120;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 218;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 110;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 249;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fu_C0312",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fu" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(StorageESP var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$5", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(StorageESP var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(StorageESP var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$4", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(StorageESP var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$9", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(StorageESP var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$7", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(StorageESP var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$6", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(StorageESP var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$8", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(StorageESP var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$3", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(StorageESP var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$1", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(StorageESP var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fu_C0312", "lambda$new$2", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static RenderCallback invokeBinding11(StorageESP var0) {
         MethodHandle var5 = bindingCache11;
         MethodHandle var4 = bindingCache11;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fu_C0312;)Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/fu_C0312",
                     "lambda$onEnable$10",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderCallback)var2.invokeExact((StorageESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
