package dev.zprestige.prestige.client.modules;

import com.mojang.authlib.GameProfile;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.EntityNameEvent;
import dev.zprestige.prestige.api.events.PlayerNameEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.StringSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.io.Serializable;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.atomic.AtomicInteger;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;

public class StreamerMode extends Module {
   private BooleanSetting d;
   private StringSetting a;
   private ModeSetting c;
   private BooleanSetting e;
   private Map f = new LinkedHashMap();
   private AtomicInteger g = new AtomicInteger(0);
   private static final long k = 137596489110566L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[99];
   private static final String[] p = new String[99];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Map var4 = this.f;
      var4.clear();
      AtomicInteger var5 = this.g;
      var5.set(0);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Map var4 = this.f;
      var4.clear();
      AtomicInteger var5 = this.g;
      var5.set(0);
   }

   
   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 33268380606163L ^ 86239459962718L;
      var10001 = 33268380606163L ^ 7880044290532L;
      var10001 = 33268380606163L ^ 25129963683855L;
      int var10 = Event.bReturningInt();
      MinecraftClient var14 = b;
      int var71 = var10;
      ClientWorld var70 = var14.world;
      ClientWorld var52 = var70;
      ClientWorld var51 = var70;
      if (var71 == 0) {
         ClientWorld var72 = var51;
         if (var72 == null) {
            return;
         }

         MinecraftClient var16 = b;
         var52 = var16.world;
      }

      ClientWorld var17 = var52;
      List var18 = var17.getPlayers();
      Iterator var11 = var18.iterator();

      while (true) {
         Iterator var19 = var11;
         boolean var73 = var19.hasNext();
         label108:
         if (var73) {
            Iterator var20 = var11;
            PlayerEntity var12 = (PlayerEntity)var20.next();
            PlayerEntity var21 = var12;
            Text var22 = var21.getName();
            String var13 = var22.getString();
            Object[] var24 = new Object[]{var13, 88162095493517L};
            StreamerMode var23 = this;
            byte var10000 = ((byte)((var23.aReturningBoolean(var24)) ? 1 : 0));
            int var75 = var10;
            byte var74 = var10000;
            byte var61 = var74;
            byte var53 = var74;
            if (var75 != 0) {
               byte var117 = var61;
               if (var117 == 0) {
                  return;
               }
               break;
            }

            int var77 = var10;
            byte var76 = var53;
            int var57 = var76;
            byte var54 = var76;
            if (var77 == 0) {
               byte var78 = var54;
               byte var55 = var78;
               byte var79 = var55;
               if (var79 != 0) {
                  continue;
               }

               int var81 = var10;
               String var80 = var13;
               String var56 = var80;
               if (var81 != 0) {
                  int var116 = var10;
                  if (var116 == 0) {
                     continue;
                  }
                  break label108;
               }

               String var27 = var56;
               int var82 = var27.length();
               var57 = var82;
            }

            byte var84 = 3;
            int var83 = var57;
            if (var83 < var84) {
               continue;
            }

            Object[] var31 = new Object[]{var13, 27948715327287L};
            StreamerMode var30 = this;
            String var58 = var30.bReturningString(var31);
            int var85 = var10;
            if (var85 == 0) {
               continue;
            }
         }

         MinecraftClient var32 = b;
         ClientPlayNetworkHandler var122 = var32.getNetworkHandler();
         int var87 = var10;
         ClientPlayNetworkHandler var86 = var122;
         ClientPlayNetworkHandler var60 = var86;
         ClientPlayNetworkHandler var59 = var86;
         if (var87 == 0) {
            ClientPlayNetworkHandler var88 = var59;
            if (var88 == null) {
               return;
            }

            MinecraftClient var34 = b;
            ClientPlayNetworkHandler var89 = var34.getNetworkHandler();
            var60 = var89;
         }

         ClientPlayNetworkHandler var36 = var60;
         Collection var37 = var36.getPlayerList();
         var11 = var37.iterator();
         Iterator var38 = var11;
         boolean var110 = var38.hasNext();
         boolean var90 = var110;
         if (!var90) {
            return;
         }
         break;
      }

      while (true) {
         Iterator var39 = var11;
         PlayerListEntry var103 = (PlayerListEntry)var39.next();
         int var92 = var10;
         PlayerListEntry var91 = var103;
         PlayerListEntry var63 = var91;
         PlayerListEntry var62 = var91;
         if (var92 == 0) {
            PlayerListEntry var93 = var62;
            if (var93 == null) {
               Iterator var107 = var11;
               boolean var113 = var107.hasNext();
               boolean var120 = var113;
               if (!var120) {
                  break;
               }
               continue;
            }

            var63 = var103;
         }

         PlayerListEntry var41 = var63;
         GameProfile var123 = var41.getProfile();
         int var95 = var10;
         GameProfile var94 = var123;
         GameProfile var65 = var94;
         GameProfile var64 = var94;
         if (var95 == 0) {
            GameProfile var96 = var64;
            if (var96 == null) {
               Iterator var106 = var11;
               boolean var112 = var106.hasNext();
               boolean var119 = var112;
               if (!var119) {
                  break;
               }
               continue;
            }

            PlayerListEntry var43 = var103;
            var65 = var43.getProfile();
         }

         Object[] var44 = new Object[]{var65, 9461285330652L};
         String var104 = RaycastUtil.aReturningString(var44);
         String var97 = var104;
         if (var97 != null) {
            int var100 = var10;
            String var99 = var104;
            StreamerMode var98 = this;
            StreamerMode var68 = var98;
            String var69 = var99;
            StreamerMode var66 = var98;
            String var67 = var99;
            if (var100 == 0) {
               Object[] var46 = new Object[]{var67, 88162095493517L};
               StreamerMode var45 = var66;
               boolean var101 = var45.aReturningBoolean(var46);
               if (!var101) {
                  var69 = var104;
                  var68 = this;
                  Object[] var50 = new Object[]{var69, 27948715327287L};
                  StreamerMode var49 = var68;
                  var49.bReturningString(var50);
                  int var102 = var10;
                  if (var102 != 0) {
                     break;
                  }
               }
            } else {
               Object[] var109 = new Object[]{var69, 27948715327287L};
               StreamerMode var108 = var68;
               var108.bReturningString(var109);
               int var121 = var10;
               if (var121 != 0) {
                  break;
               }
            }
         }

         Iterator var105 = var11;
         boolean var111 = var105.hasNext();
         boolean var118 = var111;
         if (!var118) {
            break;
         }
      }
   }

   @EventListener
   public void a(EntityNameEvent var1) {
      long var10001 = 110206448084837L ^ 57267589404392L;
      var10001 = 110206448084837L ^ 137783105493074L;
      int var10000 = Event.cReturningInt();
      Object[] var13 = new Object[0];
      EntityNameEvent var12 = var1;
      Entity var10 = var12.aReturningEntity(var13);
      int var8 = var10000;
      int var35 = var8;
      Entity var34 = var10;
      Entity var29 = var34;
      Entity var28 = var34;
      if (var35 != 0) {
         boolean var36 = var28 instanceof PlayerEntity;
         if (!var36) {
            return;
         }

         Entity var37 = var10;
         var29 = var37;
      }

      PlayerEntity var9 = (PlayerEntity)var29;
      int var38 = var8;
      if (var38 != 0) {
         PlayerEntity var17 = var9;
         Text var18 = var17.getName();
         String var43 = var18.getString();
         int var41 = var8;
         String var40 = var43;
         StreamerMode var39 = this;
         StreamerMode var32 = var39;
         String var33 = var40;
         StreamerMode var30 = var39;
         String var31 = var40;
         if (var41 != 0) {
            Object[] var20 = new Object[]{var31, 88162095493517L};
            StreamerMode var19 = var30;
            boolean var42 = var19.aReturningBoolean(var20);
            if (var42) {
               return;
            }

            var33 = var43;
            var32 = this;
         }

         Object[] var24 = new Object[]{var33, 27948715327287L};
         StreamerMode var23 = var32;
         String var11 = var23.bReturningString(var24);
         String var25 = var11;
         Object[] var27 = new Object[]{Text.literal(var25)};
         EntityNameEvent var26 = var1;
         var26.bReturningVoid(var27);
      }
   }

   @EventListener
   public void a(PlayerNameEvent var1) {
      int var10000 = Event.cReturningInt();
      Object[] var11 = new Object[0];
      PlayerNameEvent var10 = var1;
      String var5 = var10.bReturningString(var11);
      int var4 = var10000;
      int var54 = var4;
      String var53 = var5;
      String var41 = var53;
      String var40 = var53;
      if (var54 != 0) {
         String var55 = var40;
         if (var55 == null) {
            return;
         }

         var41 = var5;
      }

      String var13 = var41;
      boolean var75 = var13.isEmpty();
      int var57 = var4;
      boolean var56 = var75;
      boolean var43 = var56;
      boolean var42 = var56;
      if (var57 != 0) {
         boolean var58 = var42;
         if (var58) {
            return;
         }

         Map var15 = this.f;
         boolean var59 = var15.isEmpty();
         var43 = var59;
      }

      boolean var60 = var43;
      if (!var60) {
         String var6 = var5;
         Map var17 = this.f;
         Set var18 = var17.entrySet();
         Iterator var7 = var18.iterator();

         boolean var52;
         while (true) {
            Iterator var19 = var7;
            boolean var61 = var19.hasNext();
            if (var61) {
               Iterator var20 = var7;
               Entry var8 = (Entry)var20.next();
               Entry var21 = var8;
               String var9 = (String)var21.getKey();
               String var22 = var9;
               var75 = var22.isEmpty();
               int var63 = var4;
               boolean var62 = var75;
               var52 = var62;
               boolean var44 = var62;
               if (var63 == 0) {
                  break;
               }

               String var50;
               String var51;
               label67: {
                  int var65 = var4;
                  boolean var64 = var44;
                  boolean var49 = var64;
                  boolean var45 = var64;
                  if (var65 != 0) {
                     boolean var66 = var45;
                     boolean var46 = var66;
                     boolean var67 = var46;
                     if (var67) {
                        continue;
                     }

                     int var70 = var4;
                     String var69 = var9;
                     String var68 = var6;
                     var50 = var68;
                     var51 = var69;
                     String var47 = var68;
                     String var48 = var69;
                     if (var70 == 0) {
                        break label67;
                     }

                     String var26 = var48;
                     String var25 = var47;
                     boolean var71 = var25.contains(var26);
                     var49 = var71;
                  }

                  boolean var72 = var49;
                  if (!var72) {
                     continue;
                  }

                  var51 = var9;
                  var50 = var6;
               }

               Entry var28 = var8;
               CharSequence var31 = (CharSequence)var28.getValue();
               String var30 = var51;
               String var29 = var50;
               var6 = var29.replace(var30, var31);
               int var73 = var4;
               if (var73 != 0) {
                  continue;
               }
            }

            String var33 = var5;
            String var32 = var6;
            var52 = var32.equals(var33);
            break;
         }

         boolean var74 = var52;
         if (!var74) {
            Object[] var35 = new Object[]{var5};
            PlayerNameEvent var34 = var1;
            var34.bReturningVoid(var35);
            Object[] var37 = new Object[]{var6};
            PlayerNameEvent var36 = var1;
            var36.cReturningVoid(var37);
            Object[] var39 = new Object[0];
            PlayerNameEvent var38 = var1;
            var38.aReturningVoid(var39);
         }
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      var3 = 137596489110566L ^ var3;
      long var5 = var3 ^ 10596794816634L;
      int var7 = Event.cReturningInt();
      int var47 = var7;
      String var46 = var2;
      String var32 = var46;
      String var31 = var46;
      if (var47 != 0) {
         String var48 = var31;
         if (var48 == null) {
            return true;
         }

         var32 = var2;
      }

      String var9 = var32;
      byte var10000 = ((byte)((var9.isEmpty()) ? 1 : 0));
      int var50 = var7;
      byte var49 = var10000;
      byte var34 = var49;
      byte var33 = var49;
      if (var50 != 0) {
         byte var51 = var33;
         if (var51 != 0) {
            return true;
         }

         BooleanSetting var12 = this.e;
         Boolean var13 = (Boolean)var12.aReturningObject();
         var34 = ((byte)(((java.lang.Boolean)(var13)).booleanValue() ? 1 : 0));
      }

      byte var41;
      int var53 = var7;
      byte var52 = var34;
      var41 = var52;
      byte var35 = var52;
      label56:
      if (var53 != 0) {
         Object var40;
         label54: {
            byte var54 = var35;
            if (var54 == 0) {
               MinecraftClient var15 = b;
               int var56 = var7;
               ClientPlayerEntity var55 = var15.player;
               var40 = var55;
               ClientPlayerEntity var36 = var55;
               if (var56 == 0) {
                  break label54;
               }

               ClientPlayerEntity var57 = var36;
               ClientPlayerEntity var37 = var57;
               ClientPlayerEntity var58 = var37;
               if (var58 != null) {
                  MinecraftClient var18 = b;
                  ClientPlayerEntity var19 = var18.player;
                  Text var20 = var19.getName();
                  String var22 = var20.getString();
                  String var21 = var2;
                  var10000 = ((byte)((var21.equals(var22)) ? 1 : 0));
                  int var60 = var7;
                  byte var59 = var10000;
                  var41 = var59;
                  byte var38 = var59;
                  if (var60 == 0) {
                     break label56;
                  }

                  byte var61 = var38;
                  byte var39 = var61;
                  byte var62 = var39;
                  if (var62 != 0) {
                     return true;
                  }
               }
            }

            BooleanSetting var26 = this.d;
            var40 = var26.aReturningObject();
         }

         Boolean var27 = (Boolean)var40;
         var41 = ((byte)(((java.lang.Boolean)(var27)).booleanValue() ? 1 : 0));
      }

      int var64 = var7;
      byte var63 = var41;
      byte var45 = var63;
      byte var42 = var63;
      if (var64 != 0) {
         byte var65 = var42;
         if (var65 != 0) {
            SocialsManager var72 = Prestige.g;
            Object[] var30 = new Object[]{var2, var5};
            SocialsManager var29 = var72;
            boolean var73 = var29.aReturningBoolean(var30);
            int var67 = var7;
            boolean var66 = var73;
            boolean var74 = var66;
            boolean var43 = var66;
            if (var67 == 0) {
               return var74;
            }

            boolean var68 = var43;
            boolean var44 = var68;
            boolean var69 = var44;
            if (var69) {
               return true;
            }
         }

         var45 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var45);
   }

   private String bReturningString(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 137596489110566L ^ var2;
      long var5 = var2 ^ 32133045606861L;
      int var10000 = Event.bReturningInt();
      String var11 = var4;
      Map var10 = this.f;
      String var8 = (String)var10.get(var11);
      int var7 = var10000;
      int var22 = var7;
      String var21 = var8;
      String var20 = var21;
      String var19 = var21;
      if (var22 == 0) {
         String var23 = var19;
         if (var23 != null) {
            return var8;
         }

         Object[] var15 = new Object[]{var5};
         StreamerMode var14 = this;
         var20 = var14.dReturningString(var15);
      }

      String var9 = var20;
      String var18 = var9;
      String var17 = var4;
      Map var16 = this.f;
      var16.put(var17, var18);
      return var9;
   }

   private String dReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 137596489110566L ^ var2;
      int var10000 = Event.bReturningInt();
      StringSetting var9 = this.a;
      String var10 = (String)var9.aReturningObject();
      String var5 = var10.toString();
      int var4 = var10000;
      ModeSetting var11 = this.c;
      String var33 = (String)var11.aReturningObject();
      int var27 = var4;
      String var26 = var33;
      String var25 = var26;
      String var24 = var26;
      if (var27 == 0) {
         short var10001 = 5251;
         long var10002 = 8707389466579197915L ^ var2;
         String var13 = "Random";
         String var12 = var24;
         boolean var28 = var12.equals(var13);
         if (var28) {
            StringBuilder var6 = new StringBuilder();
            short var34 = 6834;
            long var35 = 154160363772596713L ^ var2;
            String var7 = "abcdefghijklmnopqrstuvwxyz0123456789";
            int var31;
            do {
               byte var30 = 4;
               int var29 = var8;
               if (var29 >= var30) {
                  break;
               }

               Random var36 = RandomUtil.a;
               String var15 = var7;
               int var17 = var15.length();
               Random var16 = var36;
               int var19 = var16.nextInt(var17);
               String var18 = var7;
               char var21 = var18.charAt(var19);
               StringBuilder var20 = var6;
               var20.append(var21);
               var8++;
               var31 = var4;
            } while (var31 == 0);

            StringBuilder var22 = var6;
            return var5 + var22;
         }

         AtomicInteger var23 = this.g;
         var25 = var5 + var23.incrementAndGet();
      }

      return var25;
   }

   @Override
   public String aReturningString(Object[] var1) {
      long var2 = (Long)var1[0];
      return invokeBinding1(this.f, -4955077220628927285L, var2) + invokeBinding2(5431, 1697359291390624698L ^ var2);
   }

   static {

      {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(122058845412624L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[3];
      String var6 = "Ë\r\rÇC1Eàó¤a³å.ô/\u0010\u000f\u00196òÛ¡_ùù\u0087E{¥µ\u0086\u001c@\u0096K>ÿ\u0084á\u0002è5\u009bÌ¹\u0002ëe\u000eæè×´Yx>¯(\u0083©[ä \u0080Ô\u0017\u0093Õ?©°%e(Ø\u000eãªÜ\u0099LË}åbK¨B5\u001a¬çÀÑúÁ\u009a";
      int var8 = "Ë\r\rÇC1Eàó¤a³å.ô/\u0010\u000f\u00196òÛ¡_ùù\u0087E{¥µ\u0086\u001c@\u0096K>ÿ\u0084á\u0002è5\u009bÌ¹\u0002ëe\u000eæè×´Yx>¯(\u0083©[ä \u0080Ô\u0017\u0093Õ?©°%e(Ø\u000eãªÜ\u0099LË}åbK¨B5\u001a¬çÀÑúÁ\u009a"
         .length();
      char var5 = 16;
      int var4 = -1;

      while (true) {
         byte[] var10 = var2.doFinal(var6.substring(++var4, var4 + var5).getBytes("ISO-8859-1"));
         String var13 = b(var10).intern();
         // var9[var7++] = var13;
         if ((var4 += var5) >= var8) {
            l = var9;
            m = new String[3];
            break;
         }

         var5 = var6.charAt(var4);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 11683;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fv", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fv_C0314",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fv" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 30;
            yield var15;
         }
         case 1 -> {
            byte var16 = 39;
            yield var16;
         }
         case 2 -> {
            byte var17 = 35;
            yield var17;
         }
         case 3 -> {
            byte var18 = 55;
            yield var18;
         }
         case 4 -> {
            byte var19 = 12;
            yield var19;
         }
         case 5 -> {
            byte var20 = 52;
            yield var20;
         }
         case 6 -> {
            byte var21 = 44;
            yield var21;
         }
         case 7 -> {
            byte var22 = 9;
            yield var22;
         }
         case 8 -> {
            byte var23 = 29;
            yield var23;
         }
         case 9 -> {
            byte var24 = 25;
            yield var24;
         }
         case 10 -> {
            byte var25 = 7;
            yield var25;
         }
         case 11 -> {
            byte var26 = 4;
            yield var26;
         }
         case 12 -> {
            byte var27 = 34;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 17;
            yield var29;
         }
         case 15 -> {
            byte var30 = 40;
            yield var30;
         }
         case 16 -> {
            byte var31 = 38;
            yield var31;
         }
         case 17 -> {
            byte var32 = 51;
            yield var32;
         }
         case 18 -> {
            byte var33 = 2;
            yield var33;
         }
         case 19 -> {
            byte var34 = 19;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 61;
            yield var37;
         }
         case 23 -> {
            byte var38 = 56;
            yield var38;
         }
         case 24 -> {
            byte var39 = 11;
            yield var39;
         }
         case 25 -> {
            byte var40 = 53;
            yield var40;
         }
         case 26 -> {
            byte var41 = 58;
            yield var41;
         }
         case 27 -> {
            byte var42 = 59;
            yield var42;
         }
         case 28 -> {
            byte var43 = 24;
            yield var43;
         }
         case 29 -> {
            byte var44 = 20;
            yield var44;
         }
         case 30 -> {
            byte var45 = 42;
            yield var45;
         }
         case 31 -> {
            byte var46 = 62;
            yield var46;
         }
         case 32 -> {
            byte var47 = 1;
            yield var47;
         }
         case 33 -> {
            byte var48 = 26;
            yield var48;
         }
         case 34 -> {
            byte var49 = 22;
            yield var49;
         }
         case 35 -> {
            byte var50 = 18;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 6;
            yield var52;
         }
         case 38 -> {
            byte var53 = 50;
            yield var53;
         }
         case 39 -> {
            byte var54 = 16;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 36;
            yield var56;
         }
         case 42 -> {
            byte var57 = 45;
            yield var57;
         }
         case 43 -> {
            byte var58 = 8;
            yield var58;
         }
         case 44 -> {
            byte var59 = 41;
            yield var59;
         }
         case 45 -> {
            byte var60 = 27;
            yield var60;
         }
         case 46 -> {
            byte var61 = 10;
            yield var61;
         }
         case 47 -> {
            byte var62 = 32;
            yield var62;
         }
         case 48 -> {
            byte var63 = 47;
            yield var63;
         }
         case 49 -> {
            byte var64 = 60;
            yield var64;
         }
         case 50 -> {
            byte var65 = 3;
            yield var65;
         }
         case 51 -> {
            byte var66 = 43;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 13;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 21;
            yield var70;
         }
         case 56 -> {
            byte var71 = 37;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 28;
            yield var74;
         }
         case 60 -> {
            byte var75 = 46;
            yield var75;
         }
         case 61 -> {
            byte var76 = 15;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 23;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "\u0014@] w_\nHGo:E\u0010B^3+O\u0010U\u0005 -E\u0013HHo\u0018^\u0011LB\"\u0010D\nDL$+";
      o[1] = int.class;
      p[1] = "java/lang/Integer";
      o[2] = void.class;
      p[2] = "java/lang/Void";
      o[3] = "P\u0000|L$eN\bf\u0003GqJ";
      o[4] = "?]0CS\u001f)]5\u0019@\b>\u00166\u001fL\u001c/Q!\b\u0007\t-";
      o[5] = "\t\u001b|\u00150w|;w\u001a!8\u001d5|\u0011%bi";
      o[6] = "\u000f|'14\u0012\u0004s6~I\n\u0017t?7";
      o[7] = "%df4\u00067%dqh\n8?/qv\n-8^ /]o";
      o[8] = "/G**A,/G=vM#5\f=hM62}k6\u0019u";
      o[9] = "F\u0000BA U3 IN1\u001aR.BE5@&";
      o[10] = boolean.class;
      p[10] = "java/lang/Boolean";
      o[11] = "~8Q\u0012L_h8TH_H\u007fsWNS\\n4@Y\u0018N_";
      o[12] = "Zi3>Z\u0016Li6dI\u0001[\"5bE\u0015Je\"u\u000e\u0007\u0007";
      o[13] = "\u001cRQbHwirZmY8\b|Qf]b|";
      o[14] = "RfvL~(Rfa\u0010r'H-a\u000er2O\\3P*v";
      o[15] = "\u0012\u0013 1\u0015\rg3+>\u0004B\u0006= 5\u0000\u0018r";
      o[16] = "P\u0003?y[_[\f.68RN\u0001!]\rP_\u0012=q\u001a]";
      o[17] = "\u0012Up\b\r\u007f\u0012UgT\u0001p\b\u001egJ\u0001e\u000fo5\u0010U!";
      o[18] = "@In\u0016p+KF\u007fY\u0011%@M{\u0003";
      o[19] = "-(zY^6X\bqVOy9\u0006z]K#M";
      o[20] = "yNw\nM%gFmE11}Kn\u0006";
      o[21] = char.class;
      p[21] = "java/lang/Character";
      o[22] = "\u000b@{\nSe\u001d@~P@r\n\u000b}VLf\u001bLjA\u0007q)";
      o[23] = "G<>y\u0010\"L3/6m:_4&\u007f|;D1,}L";
      o[24] = "2Q5Y\u0016\u0013$Q0\u0003\u0005\u00043\u001a3\u0005\t\u0010\"]$\u0012B\u0000:]&\u0019\u0018M\u0006F&\u0004\u0018\n1Q";
      o[25] = "\u0011\u0017}\u001b\u001dN\u0007\u0017xA\u000eY\u0010\\{G\u0002M\u0001\u001blPIX:";
      o[26] = "\u0006\u000b~E2\u0016s+uJ#Y\u0012%~A'\u0003f";
      o[27] = ":\b\u0013rNp1\u0007\u0002=\"s?\u0005\u0000r\u000e";
      o[28] = "~\\,WSZ~\\;\u000b_Ud\u0017;\u0015_@cfoM\b";
      o[29] = " jUaK> jB=G1:!B#G$=P\u0012~\u0016";
      o[30] = "Naf\u001c=_Naq@1PT*q^1ES[$\u0001h";
      o[31] = "W\u0012\r5nkI\u001a\u0017z\fwN\u0007";
      o[32] = "S\u0002#j\u00025M\n9%e4\\\u00114\u007fC2";
      o[33] = "E\u0018Ft|{E\u0018Q(pt_SQ6paX\"\u0004n!";
      o[34] = "\u001dM;_eZ\u0014C8\u0016&T\u000bV>\u001daWPe7\u001cme\fM0\u0018dP";
      o[35] = "-jG\u00177w3b]XZm+gT\u0015mk(e";
      o[36] = "\u0017_\u0002\u0004\u000f\\\u0017_\u0015X\u0003S\r\u0014\u0015F\u0003F\ne@\u0019V";
      o[37] = "x9\u001d:A\u000en9\u0018`R\u0019yr\u001bf^\rh5\fq\u0015\u001d/";
      o[38] = "4,vT3qA\f}[\"> \u0002vP&dT";
      o[39] = "xSn\n,\u000ef[tEQ\u001ef";
      o[40] = "jO#\u00025[|O&X&Lk\u0004%^*XzC2IaJQ";
      o[41] = "\r@k{\u007f?x``tnp\u0019nk\u007fj*m";
      o[42] = "\u000ed`K<\n\u0005kq\u0004Q\u000e\u0005wEOc\u0013\u0001kuO";
      o[43] = "g>Vk<d\u0012\u001e]d-+s\u0010Vo)q\u0007";
      o[44] = "#Q6\u0002CT=Y,M @9\u0014\u0005\r\u0019S0";
      o[45] = "1K3 \u001a\u001eDk8/\u000bQ%e3$\u000f\u000bQ";
      o[46] = "\u0016\"Vvh$c\u0002]yyk\u0002\fVr}1v";
      o[47] = "W3+\u0015?\rP%eYP\u0000m0$OoZ\u00070y\u001c2jQ7j@=S\n5y]P";
      o[48] = "b! [\r13'=Ct2\r;$AO>wc<RK";
      o[49] = "!+l\nv\u00012dg\u0018\u0012\u0019[*c\u001b-C1*>Hpsb$c\u001bm\u001fa,-\u0000\u0012";
      o[50] = "\u000e=]\u0003\u0002#\u001d2KX`!\u001e eS\u0011N\u0018\"T\u0007\u0019$\u001a7C\\`";
      o[51] = "\u0007\u0011jGK'P\u0011\"=H;\u0006S=XD;\u0011`6Qf0\u0011)i\u0007G$\u0002\u0010hM\u0012<m";
      o[52] = "I`wQQ/Mv~JntQ}\u007f]\u0012rW\u0010`V\u0016oH{4\u0004Vi-";
      o[53] = "b:\r\u0000\n%n)\u000b\u0018e:j9Q\u0000\t\b=t\u000fYe9v'\u0000\u001c\u001a&b;Mg";
      o[54] = "%<\u001eV;=8>\u0019[Kg>?_^7a8R@U3|'9\u0014\u0007szB";
      o[55] = "#X\u0005/\r\r$A@4i\u0010-C\u00195\u0005\"y\u0002Ghi\rp@\t>\u0003H|YCR";
      o[56] = "f1g\u0000a\nh,%G\u001f\u0001V(b\u0012 [<(?A}ko&b\u0012`\u0007l.,\t\u001f";
      o[57] = "e\u001b7R;^>\u0019$OV\u00034\u0005(K6g`Y)N9^a\u0013|VV";
      o[58] = "*X>X\u0017N9\u00175JsWPY1IL\f:Yl\u001a\u0011<iW1I\fPj_\u007fRs";
      o[59] = "{{/\\O3/)oZ*>si+&A&l .LC3{{W";
      o[60] = "\u0013~\u001e,ncW{@vVmCh$1,cH{\u007fq.rKyF*,aV\u0014";
      o[61] = " $\f\u00159\u0014oyPSY\f\u0010b\u000e@fUzbS\u0013;e)l\u000e@&\t*d@[Y";
      o[62] = "\u0010\u0004\u0019Un9\u0017\u0012W\u0019\u00012*\u0007\u0016\u000f>n@\u0007K\\c^\u0016\u0000X\u0000lgM\u0002K\u001d\u0001";
      o[63] = "+\u007f!\noWns8@\u0003X>3>\u001doji\u007fnB\u0003Z=t?\n8G?s2z";
      o[64] = "\u001ayT6R,A{G+?t]LA+Cd&>\u00180D+Ac\u00158\u000f\u0015";
      o[65] = "?\u0019eTNY`\u0016lQ G6\bcYLubD?\u0003\u001e\"?\u0004q[\u001f\u0018;\u0012x@ ";
      o[66] = "c\u001b#z=\u00138\u00190gPG&\u001e:{+*4\u001d!&)@6\b6}P\u0015c\u0000(!7Hn\bc\u001f";
      o[67] = "!\"\"%7%'4\")G~!?n\t!dLv(&>wuwbs&\u0018uu|1(!t?))G";
      o[68] = "7OR^d=oWAZ\u0007.WT\u000f\u000f8w=TR\\eGh\u0017R\u001e9 5\u001aZU\u0007";
      o[69] = "^1\u0006L\u0015=\u0018=KEs;X0\r\u0014\u000f=^]\u0012\u001f\u000b A6FMK&$";
      o[70] = "S\tQCz$\u0004\t\u00199c3E1R\u0003v'V\bSI#?9\b\u001a\u0007r!U\u000b\u0012Ii^";
      o[71] = "msyflvcn;!\u0012~]j|t-'7j!'p\u0017lo>\u007fli9v$`\u0012";
      o[72] = "\u000fA\u000bH{s\bXNS\u001fe\rK\u0013YH2R\u0016H5{f\nL\u0019N$i\u0003I";
      o[73] = "\u0017\u0011X6u4C\u001f\u00164\u0013\"L\u0003D\u000f*cC\bF6+)\u0016\u0010)";
      o[74] = "ot3Y`\u000bg>>\r[\u0000\u0016:i_dY|:4\f9i*='P6Pq?4M[";
      o[75] = "R\u0017x\u001c\f?U\u00016Pc1h\u0001vG\u0000%W\r3]\u001eX\u0002T\"O\u001eg\u000e\u00118Qc";
      o[76] = "\f{\u000e7\nC\u001f4\u0005%n[vz\u0001&Q\u0001\u001cz\\u\f1J}O)\u0003\b\u0011\u007f\\4n";
      o[77] = "ao!z\u0001|.2}<agQo'+\u0018bhnm~\u0000\r";
      o[78] = "K\u000f\u0015f\\q\u0010\r\u0006{1#\u0010\u0011\u0019jP.\fw\u0019{^v\u001aF\bbR(wHY`Jv\u0010\u0015Th\u0001H";
      o[79] = "_4\u0018wLc\u000b:Vu*o\u001e\u0019\f6V\u007fekU-Q0\u00026X%\u001a\u000e";
      o[80] = "\u001ee\u0013$pP\u0019s]h\u001f^$f\u001c~ \u0007NfA-}7\u001b%Ao!PF(I$\u001f";
      o[81] = ",.\u001aQt\bcsF\u0017\u0014\u0012\u001c.\u001c\u0000m\u0016%/VUuy";
      o[82] = "`\tAUi\u0003:\u0019\u0012\t\rUf\u001fK\u0000dY_\u0011K\u0010`?>DL\u00163XcID]\r";
      o[83] = ")>H\tF^!x\\H?\u0006G/ZB\u0006\u0016--OU]o";
      o[84] = "W\u0000\u0000_W\u0002\u0003\u000eN]1\u0000\u0000\u001cq\rO\u001dT\u0019\u001b\u000fZ\n\u000f`\u001a\u0018CV\u0014\n\u0018\rT\rm";
      o[85] = "+8_7vU,!\u001a,\u0012C)2G&E\u0014we\u001fJpB.%J#.Gqa";
      o[86] = "'Z\u0002q^A|X\u0011l3\u0004|y\u000enR\u001et\"NlC\u001dv\u001b\u0015nP\u0000\u001b";
      o[87] = "{\u0018\t=)\n/H_qD\u0001lY\t*(hy_\rw-T(\u001e\u0006rD\u0007-L\u0015!&S}\u001aYL";
      o[88] = "=)(D15i{hBT>10\u0016S$\"Xtl]/`?)aUd^";
      o[89] = "{\u0010.\u000e@!vVs\u0018 <}P*\u0013L\u000e-\u0010uK dzM+LA \u007f\u0013qt";
      o[90] = "\f\u001fM\u0014u&X\u0011\u0003\u0016\u0013&P\u0003F\\H&J\u007fFAbzP\u0018\u0000M/s6";
      o[91] = "\"Z\b_\u0017IyX\u001bBz\nsZ\u001cS\u0011\u001d\u001e^\u0000UD\u001d/O\u0019Y\u001apbZ\u0017\u0004\u0017AsC\u001bZzLfR\u001dWC\u0017dA\u0000:";
      o[92] = "y5;'\u0013\u0002=0e}+\u0006)#:!G4xdfy\u0013cx'*#FZ#%9>+^588%\u0017\u001b\u007f87F";
      o[93] = "\u000f\u001aq,P4T\u0018b1=fS\u000b{\u0000A\r\nXo0R4\u000b\u0012:(=`M\u000b: \u00011\f\u0000?I";
      o[94] = "vo\u0019\r\u000fM(jFIfAy|\u001f\u0010\ns)<@Hf\u0019~a\u001eO\u0007]{?Dw";
      o[95] = "DKl\n;f\u001fI\u007f\u0017V!\u0011Wa\u0002\u00111xXb\u001do&\u0012Zw\n4_DKl\n;f\u001fI\u007f\u0017V";
      o[96] = "_O\t,?S\u000bAG.YU\u0001B\u0011oY\u0007\u0014\u0011\u0012j5\u0004\u001c_\t\u0015";
      o[97] = "\u0014\u0001\u0014@ki\u0007\u000e\u0002\u001b\tk\u0004\u001c1\u0014my\u0004`\u0004\u0003{=\u0010\n\u0006\u0016lfi";
      o[98] = "\u001bT!.!kOZo,G~\\HP|9t\u0018M:~,cC4;i5?X^9|\"d!_.e~\u007fK];r%\u0006";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1308920400757099L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1308920400757099L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1308920400757099L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 239;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 219;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 203;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 109;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 254;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 238;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 239;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 219;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 203;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fv_C0314",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fv" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(MethodHandles.lookup(), "þ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = b(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
