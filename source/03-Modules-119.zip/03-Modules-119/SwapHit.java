package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackInputEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

public class SwapHit extends Module {
   private BooleanSetting d;
   private FloatSetting a;
   private FloatSetting c;
   private BooleanSetting e;
   private BooleanSetting f;
   private ElapsedTimer g;
   private ElapsedTimer h;
   private int i;
   private int j;
   private static final long k = 31763251502069L;
   private static final long[] l;
   private static final Integer[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[65];
   private static final String[] p = new String[65];

   public SwapHit() {
      super();
      long var10001 = 23261620636361L ^ 127691979144672L;

      this.g = new ElapsedTimer(106698256430889L);
      this.h = new ElapsedTimer(106698256430889L);
      this.i = -1;
      this.j = 0;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      this.i = -1;
      this.j = 0;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      this.i = -1;
      this.j = 0;
   }

   private int aReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 31763251502069L ^ var2;
      long var4 = var2 ^ 92424694153887L;
      int var10000 = Event.cReturningInt();
      int var6 = var10000;

      byte var17;
      while (true) {
         short var10001 = 15349;
         long var10002 = 7759030585115564707L ^ var2;
         byte var19 = 8;
         int var18 = var7;
         if (var18 <= var19) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var28 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var28;
            Object[] var12 = new Object[]{var10.getStack(var11), var4};
            byte var29 = ((byte)((InventoryUtil.aReturningBoolean(var12)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var29;
            var17 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               break;
            }

            int var23 = var6;
            byte var22 = var13;
            int var16 = var22;
            byte var14 = var22;
            if (var23 == 0) {
               return var16;
            }

            byte var24 = var14;
            byte var15 = var24;
            byte var25 = var15;
            if (var25 != 0) {
               var16 = var7;
               return var16;
            }

            var7++;
            int var26 = var6;
            if (var26 != 0) {
               continue;
            }
         }

         var17 = -1;
         break;
      }

      return var17;
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 31763251502069L ^ var2;
      long var4 = var2 ^ 12304750147154L;
      int var10000 = Event.bReturningInt();
      int var6 = var10000;

      byte var17;
      while (true) {
         short var10001 = 6531;
         long var10002 = 7483814775547301833L ^ var2;
         byte var19 = 8;
         int var18 = var7;
         if (var18 <= var19) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var28 = var9.getInventory();
            int var11 = var7;
            PlayerInventory var10 = var28;
            Object[] var12 = new Object[]{var10.getStack(var11), var4};
            byte var29 = ((byte)((InventoryUtil.bReturningBoolean(var12)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var29;
            var17 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               break;
            }

            int var23 = var6;
            byte var22 = var13;
            int var16 = var22;
            byte var14 = var22;
            if (var23 != 0) {
               return var16;
            }

            byte var24 = var14;
            byte var15 = var24;
            byte var25 = var15;
            if (var25 != 0) {
               var16 = var7;
               return var16;
            }

            var7++;
            int var26 = var6;
            if (var26 == 0) {
               continue;
            }
         }

         var17 = -1;
         break;
      }

      return var17;
   }

   @EventListener
   public void a(AttackInputEvent var1) {
      long var10001 = 127671532490668L ^ 51984408151057L;
      var10001 = 127671532490668L ^ 117996624625253L;
      var10001 = 127671532490668L ^ 91158750619564L;
      var10001 = 127671532490668L ^ 49784525638010L;
      var10001 = 127671532490668L ^ 97993676097699L;
      var10001 = 127671532490668L ^ 59277911411418L;
      var10001 = 127671532490668L ^ 111786803433488L;
      int var18 = Event.cReturningInt();
      int var111 = var18;
      MinecraftClient var110 = b;
      MinecraftClient var83 = var110;
      MinecraftClient var82 = var110;
      if (var111 != 0) {
         MinecraftClient var24 = var82;
         ClientPlayerEntity var112 = var24.player;
         if (var112 == null) {
            return;
         }

         MinecraftClient var113 = b;
         var83 = var113;
      }

      int var115 = var18;
      MinecraftClient var114 = var83;
      MinecraftClient var85 = var114;
      MinecraftClient var84 = var114;
      if (var115 != 0) {
         MinecraftClient var27 = var84;
         ClientWorld var116 = var27.world;
         if (var116 == null) {
            return;
         }

         var85 = b;
      }

      int var118 = var18;
      MinecraftClient var117 = var85;
      MinecraftClient var87 = var117;
      MinecraftClient var86 = var117;
      if (var118 != 0) {
         MinecraftClient var30 = var86;
         boolean var119 = var30.isWindowFocused();
         if (!var119) {
            return;
         }

         MinecraftClient var120 = b;
         var87 = var120;
      }

      int var122 = var18;
      MinecraftClient var121 = var87;
      MinecraftClient var89 = var121;
      MinecraftClient var88 = var121;
      if (var122 != 0) {
         MinecraftClient var33 = var88;
         Screen var123 = var33.currentScreen;
         if (var123 != null) {
            return;
         }

         var89 = b;
      }

      MinecraftClient var36 = var89;
      ClientPlayerEntity var37 = var36.player;
      Object[] var38 = new Object[]{var37.getMainHandStack(), 19476550655932L};
      byte var10000 = ((byte)((InventoryUtil.aReturningBoolean(var38)) ? 1 : 0));
      int var125 = var18;
      boolean var124 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
      boolean var91 = var124;
      boolean var90 = var124;
      if (var125 != 0) {
         boolean var126 = var90;
         if (var126) {
            return;
         }

         BooleanSetting var40 = this.d;
         Boolean var41 = (Boolean)var40.aReturningObject();
         var91 = var41;
      }

      MinecraftClient var94;
      label121: {
         boolean var127 = var91;
         if (var127) {
            int var129 = var18;
            MinecraftClient var128 = b;
            var94 = var128;
            MinecraftClient var92 = var128;
            if (var129 == 0) {
               break label121;
            }

            MinecraftClient var130 = var92;
            MinecraftClient var93 = var130;
            MinecraftClient var43 = var93;
            ClientPlayerEntity var44 = var43.player;
            ItemStack var45 = var44.getMainHandStack();
            Item var166 = var45.getItem();
            Item var132 = Items.TOTEM_OF_UNDYING;
            Item var131 = var166;
            if (var131 != var132) {
               return;
            }
         }

         var94 = b;
      }

      MinecraftClient var48 = var94;
      HitResult var20 = var48.crosshairTarget;
      int var134 = var18;
      HitResult var133 = var20;
      HitResult var96 = var133;
      HitResult var95 = var133;
      if (var134 != 0) {
         boolean var135 = var95 instanceof EntityHitResult;
         if (!var135) {
            return;
         }

         HitResult var136 = var20;
         var96 = var136;
      }

      EntityHitResult var19 = (EntityHitResult)var96;
      int var137 = var18;
      if (var137 != 0) {
         EntityHitResult var52 = var19;
         Entity var164 = var52.getEntity();
         int var139 = var18;
         Entity var138 = var164;
         Entity var98 = var138;
         Entity var97 = var138;
         if (var139 != 0) {
            boolean var140 = var97 instanceof PlayerEntity;
            if (!var140) {
               return;
            }

            Entity var141 = var164;
            var98 = var141;
         }

         PlayerEntity var21 = (PlayerEntity)var98;
         int var142 = var18;
         if (var142 != 0) {
            int var22;
            label147: {
               int var107;
               BooleanSetting var56 = this.e;
               Boolean var57 = (Boolean)var56.aReturningObject();
               var10000 = ((byte)(((java.lang.Boolean)(var57)).booleanValue() ? 1 : 0));
               int var144 = var18;
               byte var143 = var10000;
               var107 = var143;
               byte var99 = var143;
               label99:
               if (var144 != 0) {
                  byte var145 = var99;
                  if (var145 != 0) {
                     Object[] var59 = new Object[]{var21, 100443321076669L};
                     var10000 = ((byte)((EntityUtil.aReturningBoolean(var59)) ? 1 : 0));
                     int var147 = var18;
                     byte var146 = var10000;
                     var107 = var146;
                     byte var100 = var146;
                     if (var147 == 0) {
                        break label99;
                     }

                     byte var148 = var100;
                     byte var101 = var148;
                     byte var149 = var101;
                     if (var149 != 0) {
                        BooleanSetting var62 = this.f;
                        Boolean var63 = (Boolean)var62.aReturningObject();
                        var10000 = ((byte)(((java.lang.Boolean)(var63)).booleanValue() ? 1 : 0));
                        int var151 = var18;
                        byte var150 = var10000;
                        int var104 = var150;
                        byte var102 = var150;
                        if (var151 != 0) {
                           byte var152 = var102;
                           byte var103 = var152;
                           byte var153 = var103;
                           if (var153 == 0) {
                              return;
                           }

                           Object[] var67 = new Object[]{34415081337289L};
                           SwapHit var66 = this;
                           int var154 = var66.dReturningInt(var67);
                           var104 = var154;
                        }

                        int var23 = var104;
                        int var156 = var18;
                        int var155 = var23;
                        int var106 = var155;
                        int var105 = var155;
                        if (var156 != 0) {
                           // int var157 = var105;
                           if (var157 == var158) {
                              return;
                           }

                           var106 = var23;
                        }

                        var22 = var106;
                        int var159 = var18;
                        if (var159 == 0) {
                           return;
                        }
                        break label147;
                     }
                  }

                  Object[] var73 = new Object[]{98245307057878L};
                  SwapHit var72 = this;
                  var107 = var72.aReturningInt(var73);
               }

               int var165 = var107;
               int var161 = var18;
               int var160 = var165;
               int var109 = var160;
               int var108 = var160;
               if (var161 != 0) {
                  // int var162 = var108;
                  if (var162 == var163) {
                     return;
                  }

                  var109 = var165;
               }

               var22 = var109;
            }

            Object[] var77 = new Object[0];
            AttackInputEvent var76 = var1;
            var76.aReturningVoid(var77);
            Object[] var78 = new Object[]{49487520630543L};
            this.i = InventoryUtil.aReturningInt(var78);
            Object[] var10003 = new Object[]{null, 72518082610550L};
            var10003[0] = var22;
            Object[] var79 = var10003;
            InventoryUtil.aReturningVoid(var79);
            this.j = 1;
            ElapsedTimer var170 = this.g;
            Object[] var81 = new Object[]{42835128969216L};
            ElapsedTimer var80 = var170;
            var80.aReturningVoid(var81);
         }
      }
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 34472883669313L ^ 107580759908181L;
      var10001 = 34472883669313L ^ 63423838232897L;
      var10001 = 34472883669313L ^ 104102381063223L;
      var10001 = 34472883669313L ^ 132726219816617L;
      int var12 = Event.cReturningInt();
      int var59 = this.j;
      if (var59 != 0) {
         label84: {
            int var61 = var12;
            MinecraftClient var60 = b;
            MinecraftClient var47 = var60;
            MinecraftClient var46 = var60;
            if (var61 != 0) {
               MinecraftClient var16 = var46;
               ClientPlayerEntity var62 = var16.player;
               if (var62 == null) {
                  break label84;
               }

               MinecraftClient var63 = b;
               var47 = var63;
            }

            MinecraftClient var19 = var47;
            ClientWorld var64 = var19.world;
            if (var64 != null) {
               int var54;
               label89: {
                  int var67 = var12;
                  byte var66 = 1;
                  int var65 = this.j;
                  int var52 = var65;
                  byte var53 = var66;
                  int var48 = var65;
                  byte var49 = var66;
                  if (var67 != 0) {
                     byte var69 = var49;
                     int var68 = var48;
                     if (var68 == var69) {
                        ElapsedTimer var10000 = this.g;
                        FloatSetting var22 = this.a;
                        Float var23 = (Float)var22.aReturningObject();
                        float var99 = var23;
                        Object[] var10004 = new Object[]{null, 139098136696340L};
                        var10004[0] = var99;
                        Object[] var25 = var10004;
                        ElapsedTimer var24 = var10000;
                        boolean var70 = var24.aReturningBoolean(var25);
                        if (!var70) {
                           return;
                        }

                        MinecraftClient var28 = b;
                        HitResult var14 = var28.crosshairTarget;
                        int var71 = var12;
                        label71:
                        if (var71 != 0) {
                           boolean var72 = var14 instanceof EntityHitResult;
                           if (var72) {
                              EntityHitResult var13 = (EntityHitResult)var14;
                              EntityHitResult var30 = var13;
                              Entity var92 = var30.getEntity();
                              int var73 = var12;
                              if (var73 == 0) {
                                 break label71;
                              }

                              Entity var74 = var92;
                              if (var74 != null) {
                                 Object[] var32 = new Object[]{var92, 114267283224552L};
                                 ItemUseUtil.aReturningVoid(var32);
                              }
                           }

                           this.j = 2;
                           var10000 = this.h;
                           Object[] var35 = new Object[]{42835128969216L};
                           ElapsedTimer var34 = var10000;
                           var34.aReturningVoid(var35);
                        }

                        int var75 = var12;
                        if (var75 != 0) {
                           return;
                        }
                     }

                     int var77 = var12;
                     int var76 = this.j;
                     var54 = var76;
                     int var50 = var76;
                     if (var77 == 0) {
                        break label89;
                     }

                     int var78 = var50;
                     int var51 = var78;
                     byte var80 = 2;
                     int var79 = var51;
                     var52 = var79;
                     var53 = var80;
                  }

                  byte var82 = var53;
                  int var81 = var52;
                  if (var81 != var82) {
                     return;
                  }

                  ElapsedTimer var94 = this.h;
                  FloatSetting var38 = this.c;
                  Float var39 = (Float)var38.aReturningObject();
                  float var100 = var39;
                  Object[] var101 = new Object[]{null, 139098136696340L};
                  var101[0] = var100;
                  Object[] var41 = var101;
                  ElapsedTimer var40 = var94;
                  byte var83 = ((byte)((var40.aReturningBoolean(var41)) ? 1 : 0));
                  var54 = var83;
               }

               SwapHit var58;
               label92: {
                  int var85 = var12;
                  int var84 = var54;
                  int var57 = var84;
                  int var55 = var84;
                  if (var85 != 0) {
                     int var86 = var55;
                     if (var86 == 0) {
                        return;
                     }

                     int var88 = var12;
                     SwapHit var87 = this;
                     var58 = var87;
                     SwapHit var56 = var87;
                     if (var88 == 0) {
                        break label92;
                     }

                     int var89 = var56.i;
                     var57 = var89;
                  }

                  // int var90 = var57;
                  if (var90 != var91) {
                     int var95 = this.i;
                     Object[] var10003 = new Object[]{null, 72518082610550L};
                     var10003[0] = var95;
                     Object[] var45 = var10003;
                     InventoryUtil.aReturningVoid(var45);
                     this.i = -1;
                  }

                  var58 = this;
               }

               var58.j = 0;
               return;
            }
         }

         this.j = 0;
         this.i = -1;
      }
   }

   private boolean lambda$new$0(Boolean var1) {
      BooleanSetting var4 = this.e;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(81189538439577L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[3];
      String var6 = "O\t¡È¹\u0081FÀ¤ZÎ¸<\u001b\u0087d\u0015\u0014\u0081½\u0000:b{";
      int var7 = "O\t¡È¹\u0081FÀ¤ZÎ¸<\u001b\u0087d\u0015\u0014\u0081½\u0000:b{".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      l = var8;
      m = new Integer[3];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15476;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fw", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fw_C0316",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 49;
            yield var16;
         }
         case 2 -> {
            byte var17 = 53;
            yield var17;
         }
         case 3 -> {
            byte var18 = 5;
            yield var18;
         }
         case 4 -> {
            byte var19 = 4;
            yield var19;
         }
         case 5 -> {
            byte var20 = 46;
            yield var20;
         }
         case 6 -> {
            byte var21 = 44;
            yield var21;
         }
         case 7 -> {
            byte var22 = 18;
            yield var22;
         }
         case 8 -> {
            byte var23 = 55;
            yield var23;
         }
         case 9 -> {
            byte var24 = 37;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 48;
            yield var27;
         }
         case 13 -> {
            byte var28 = 31;
            yield var28;
         }
         case 14 -> {
            byte var29 = 25;
            yield var29;
         }
         case 15 -> {
            byte var30 = 59;
            yield var30;
         }
         case 16 -> {
            byte var31 = 11;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 36;
            yield var33;
         }
         case 19 -> {
            byte var34 = 10;
            yield var34;
         }
         case 20 -> {
            byte var35 = 62;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 19;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 35;
            yield var40;
         }
         case 26 -> {
            byte var41 = 0;
            yield var41;
         }
         case 27 -> {
            byte var42 = 9;
            yield var42;
         }
         case 28 -> {
            byte var43 = 40;
            yield var43;
         }
         case 29 -> {
            byte var44 = 17;
            yield var44;
         }
         case 30 -> {
            byte var45 = 16;
            yield var45;
         }
         case 31 -> {
            byte var46 = 39;
            yield var46;
         }
         case 32 -> {
            byte var47 = 27;
            yield var47;
         }
         case 33 -> {
            byte var48 = 30;
            yield var48;
         }
         case 34 -> {
            byte var49 = 8;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 12;
            yield var51;
         }
         case 37 -> {
            byte var52 = 23;
            yield var52;
         }
         case 38 -> {
            byte var53 = 6;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 45;
            yield var55;
         }
         case 41 -> {
            byte var56 = 20;
            yield var56;
         }
         case 42 -> {
            byte var57 = 60;
            yield var57;
         }
         case 43 -> {
            byte var58 = 50;
            yield var58;
         }
         case 44 -> {
            byte var59 = 33;
            yield var59;
         }
         case 45 -> {
            byte var60 = 41;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 63;
            yield var63;
         }
         case 49 -> {
            byte var64 = 3;
            yield var64;
         }
         case 50 -> {
            byte var65 = 7;
            yield var65;
         }
         case 51 -> {
            byte var66 = 34;
            yield var66;
         }
         case 52 -> {
            byte var67 = 28;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 52;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 51;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 2;
            yield var73;
         }
         case 59 -> {
            byte var74 = 1;
            yield var74;
         }
         case 60 -> {
            byte var75 = 22;
            yield var75;
         }
         case 61 -> {
            byte var76 = 32;
            yield var76;
         }
         case 62 -> {
            byte var77 = 61;
            yield var77;
         }
         default -> 29;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      o[0] = "f_`gy\"p_e=j5g\u0014f;f!vSq,-3G";
      o[1] = int.class;
      p[1] = "java/lang/Integer";
      o[2] = "(C:\n%^(C-V)Q2\b-H)D5yy\u0010~";
      o[3] = "9\u0018\u001d\u000f<C9\u0018\nS0L#S\nM0Y$\"X\u0017g\u001b";
      o[4] = "Mc\u0018E#sMc\u000f\u0019/|W(\u000f\u0007/iPY]\\w#";
      o[5] = "QtU\u0000\u000e\bQtB\\\u0002\u0007K?BB\u0002\u0012LN\u0012\u001fS";
      o[6] = "6LiiJ\u0013 Ll3Y\u00047\u0007o5U\u0010&@x\"\u001e\u0000=";
      o[7] = "]#t\u0010C\\(\u0003\u007f\u001fR\u0013I\rt\u0014VI=";
      o[8] = boolean.class;
      p[8] = "java/lang/Boolean";
      o[9] = "\u00069C\\VL\u00109F\u0006E[\u0007rE\u0000IO\u00165R\u0017\u0002Z\u0015";
      o[10] = "@>Z\u0002q(K1KM\u0012%^<D&''O/X\n0*";
      o[11] = "\r?L!A)x\u001fG.Pf\u0019\u0011L%T<m";
      o[12] = " L\u007f\u0004\u000b5+CnKg6%Al\u0004K";
      o[13] = "\\NL*h-JNIp{:]\u0005Jvw.LB]a<9~";
      o[14] = "lTF{n0g[W4\u000f>lPSn";
      o[15] = "5\u0015*|$-5\u0015= (\"/^=>(7(/oepv";
      o[16] = "%FeO\"K%Fr\u0013.D?\rr\r.Q8| Y\u007f\u0010";
      o[17] = "_+\u000b\u0011\u0012C_+\u001cM\u001eLE`\u001cS\u001eYB\u0011K\fH";
      o[18] = "S@s]\u0003m&`xR\u0012\"GnsY\u0016x3";
      o[19] = void.class;
      p[19] = "java/lang/Void";
      o[20] = "=\u001aBdtr=\u001aU8x}'QU&xh  \u0004y ";
      o[21] = "\u001a\u0018w\u0007W\f\u001a\u0018`[[\u0003\u0000S`E[\u0016\u0007\"0\u0010\fS";
      o[22] = ">MRk6\u0014>ME7:\u001b$\u0006E):\u000e#w\u0017wbJ";
      o[23] = "0h\u000fa\r\u00160h\u0018=\u0001\u0019*#\u0018#\u0001\f-RM|X";
      o[24] = "Ww\u0005zE;\"W\u000euTtCY\u0005~P.7";
      o[25] = "\bRy*=9\u001eR|p..\t\u0019\u007fv\":\u0018^hai/5";
      o[26] = "JD,]~)?d'Rof^j,Yk<*";
      o[27] = "/gL}3{9gI' l.,J!,x?k]6gm\u001e";
      o[28] = "f<}.B$\u0013\u001cv!Skr\u0012}*W1\u0006";
      o[29] = "\u0007=}\u0007\u0015;r\u001dv\b\u0004t\u0013\u0013}\u0003\u0000.g";
      o[30] = "\u0012 -\u001f\u001d+g\u0000&\u0010\fd\u0006\u000e-\u001b\b>r";
      o[31] = "\u0017\\X2mMb|S=|\u0002\u0003rX6xXw";
      o[32] = "2 =)\u001cXG\u00006&\r\u0017&\u000e=-\tMR";
      o[33] = "z\u0001/gL*l\u0001*=_={J);S)j\r>,\u00189r";
      o[34] = "V\u0017\u007f#x\u0016#7t,iYB9\u007f'm\u00036";
      o[35] = "\u0016Q2nio\u001d^#!\u0001o\u0013Q0";
      o[36] = float.class;
      p[36] = "java/lang/Float";
      o[37] = "'\nB\r\u0018/k\u0017\u0011tM\u001f.\\DN\u0016dg\t\u0006\u0010'";
      o[38] = "6\u0012\b\u0016\u0015e1[\b\u0005i:b\u001e\u0015\r\u0005\b4[HVY_5\t\u001f\fW6c\u0013\u0012\u0017i";
      o[39] = "N\u0012JK\u00014\u0004\u0003\u0001\fsj\u0019\u0011ZP\u001fXK\\\u0002\u0006sf\u0012\u0015\u0002\n\u0016rIT\u00067";
      o[40] = "f\u001fqAmD$\u001d=EW\u0017<\fd\u0011\u0000@b\\=}=\u000b8\u0019d\u00060Ig\u001e";
      o[41] = "H,+`[\u0006\u0004(4=?\u0017t.>hD\f\u001b)<bV~\u00181\u007f=\u0005N\u0019:5\u007f?";
      o[42] = "K7{;-\u001c\u0007*(By,Ba}x#W\u000b4?&\u0012";
      o[43] = "l6&\u000f>\u001d8uy\u000fNF;/#\u0012'J\u0002!#\u0002#,a7\"A1\u00137->ON";
      o[44] = "\u0001ArMVxCC>Il WCc\u0016\u0000\u0012\u0003\u0002=@lxEZ=\u000eS._F3q";
      o[45] = "\nTc~\\\u0002VTq*`\u0012l_`%\u001b\t\u0003Xb/\t{\u0000@!pZK\u0001Kk2`";
      o[46] = "I$Z9\u00063\nz\u0013emexpY}\u0016t\u0006;Kj\u001c\f";
      o[47] = "EoHk\u001eD\u0007m\u0004o$\u0017\u001f|];s@A+\u0005W\u001d\t\u0003mEm\u001a@\u0003~";
      o[48] = "BWCS\u001c\u001d\u001f^\u0006J\u007f\u001f\"\\GD\u0004\u0004M[EN\u0016vNC\u0006\u0011EFOHLS\u007f";
      o[49] = ";g[\u001dnJwcD@\nX\u0007eN\u0015q@hbL\u001fc2:|PAu\rlfLO\n";
      o[50] = "\\(T>rX\u0010,Kc\u0016I`*A6mR\u000f-C<\u007f Yw\u0004f'[\u0010\"F8\u0016";
      o[51] = "hcY\u0003k=$~\nz=\r>u\u000b\u0001&b9w\u0001\u0013Ta!4^@d`*~\u001cz";
      o[52] = "5H0\".hhAu;MjUC456q:D6?$\u0003hZ*a2<>@6oM";
      o[53] = "C\u0012(6(<D[(%Tc\u0017\u001e5-8QDZiuT<\u0005\u0012)8ov\u0014YnJ";
      o[54] = "!\u000475g\"(\u001d$*\t3*\u0002?9^mq_kU`;3Wf0t`rS";
      o[55] = "y:,>6$;8`:\fw#)9n[ }z`\u0002`f\"+:yak~/";
      o[56] = "/6'\u001d+7y,*\u0006\u0015;x!-\u001cy\t(avK\u0015g.cwJn.{!){/!e!?@e0.fM";
      o[57] = "c6i$PXwm:#(\rc.exD?7m:/\u0012h`1y!L\u0014>#tn(";
      o[58] = "?PM6C\u0000}R\u00012ySeCXf.\u0004:\u001e\u0003\n\u0016\u0007hP\u00075\u0017\u00064N";
      o[59] = "T8E\u001fhZ\b/J[\u001aTj#\u0000IaJ\u0005$\u0002Cs8S~E\u0019+C\u001a+\u0007G\u001a";
      o[60] = "CYe\t~IH\u001fn\u0012\u000eA!\u0003y\u0003uZN\u0004{\tg(\u001c\u001agWq\u0017J\u0000{Y\u000e";
      o[61] = "\\RG$\u0003DVD]~n\u0012_OV20\u0015_URN\u0016C\u0006LX+\u0012\u0015]F?";
      o[62] = "ZU\u0016 {p\u0006B\u0019d\t{dNSvr`\u000bIQ|`\u0012]\u0013\u0016&8i\u0014FTx\t";
      o[63] = "F\u001e]\\\u0003>\u001a\tR\u0018q5x\\\\\f\f6\u001d\u0004\u0003\u0010\u0014\\G\\\u000f\u001d\u001b9\u001f\u0003\u0013\u0005q";
      o[64] = "\u001d[7T{AQ_(\t\u001fP!Y\"\\dKN^ Vv9\u001c@<\b`\u0006JZ \u0006\u001f";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1011978965885794L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1011978965885794L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1011978965885794L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 65;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 112;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 206;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 122;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 254;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 66;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 65;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 112;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 206;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fw_C0316",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
