package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.client.management.TargetManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3d;

public class TargetRenderer extends Module {
   private ModeSetting a;
   private ManagedGlTexture b;
   private ManagedGlTexture c;
   private static final float d = 850.0F;
   private static final float e = 1100.0F;
   private static final float f = 14.0F;
   private float g;
   private Vec3d h;
   private float i;
   private float j;
   private float k = 0.0F;
   private long l = System.currentTimeMillis();
   private long m = 0L;
   private long n = 0L;
   private boolean o = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private float p = 0.0F;
   private static final long q = 54056711095188L;
   private static final String[] r;
   private static final String[] s;
   private static final Map t = new HashMap(13);
   private static final long[] u;
   private static final Integer[] v;
   private static final Map w;
   private static final long[] x;
   private static final Long[] y;
   private static final Map z;
   private static final Object[] A = new Object[106];
   private static final String[] B = new String[106];

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 71030142448026L ^ 14733634567275L;
      var10001 = 71030142448026L ^ 89669107433042L;
      var10001 = 71030142448026L ^ 13898832923250L;
      var10001 = 71030142448026L ^ 62997660610188L;
      var10001 = 71030142448026L ^ 35846064551855L;
      var10001 = 71030142448026L ^ 68548680705336L;
      int var10000 = Event.cReturningInt();
      long var17 = System.currentTimeMillis();
      int var16 = var10000;
      long var191;
      int var120 = (var191 = this.m - 0L) == 0L ? 0 : (var191 < 0L ? -1 : 1);
      float var99;
      if (!((var120) != 0)) {
         float var121 = 0.0F;
         var99 = var121;
      } else {
         float var30 = (float)(var17 - this.m) / 1000.0F;
         float var29 = 0.1F;
         var99 = Math.min(var29, var30);
      }

      float var19 = var99;
      this.m = var17;
      this.k = (float)(var17 % 3600L) * 0.1F;
      TargetManager var173 = Prestige.n;
      Object[] var32 = new Object[0];
      TargetManager var31 = var173;
      PlayerEntity var20 = var31.aReturningPlayerEntity(var32);
      PlayerEntity var122 = var20;
      byte var100;
      if (var122 != null) {
         byte var123 = 1;
         var100 = var123;
      } else {
         var100 = 0;
      }

      byte var21;
      label131: {
         var21 = var100;
         int var124 = var16;
         if (var124 != 0) {
            byte var126 = ((byte)((this.o) ? 1 : 0));
            byte var125 = var21;
            if (var125 == var126) {
               break label131;
            }

            this.n = var17;
            this.p = this.g;
         }

         this.o = dev.prestige.recovery.SourceSupport.asBoolean(var21);
      }

      label125: {
         long var22 = var17 - this.n;
         byte var127 = var21;
         if (var127 != 0) {
            float var37 = (float)var22 / 850.0F;
            float var36 = 1.0F;
            float var24 = Math.min(var36, var37);
            Object[] var10003 = new Object[]{null, 18778824052680L};
            var10003[0] = var24;
            Object[] var38 = var10003;
            float var25 = bReturningFloat(var38);
            this.g = this.p + (1.0F - this.p) * var25;
            int var128 = var16;
            if (var128 != 0) {
               break label125;
            }
         }

         float var40 = (float)var22 / 1100.0F;
         float var39 = 1.0F;
         float var167 = Math.min(var39, var40);
         Object[] var183 = new Object[]{null, 18778824052680L};
         var183[0] = var167;
         Object[] var41 = var183;
         float var170 = bReturningFloat(var41);
         this.g = this.p * (1.0F - var170);
      }

      int var130 = var16;
      TargetRenderer var129 = this;
      TargetRenderer var106 = var129;
      TargetRenderer var101 = var129;
      if (var130 != 0) {
         float var182 = this.g;
         Object[] var10004 = new Object[]{null, 133943777435414L};
         var10004[0] = var182;
         Object[] var42 = var10004;
         var101.g = cReturningFloat(var42);
         PlayerEntity var131 = var20;
         label107:
         if (var131 != null) {
            Vec3d var26;
            label116: {
               TargetRenderer var105;
               PlayerEntity var44 = var20;
               this.j = var44.getHeight();
               PlayerEntity var45 = var20;
               this.i = var45.getWidth();
               Object[] var46 = new Object[]{var20, 85760017780209L};
               Vec3d var168 = RaycastUtil.cReturningVec3d(var46);
               Object[] var47 = new Object[]{105570054506037L};
               float var171 = GameRenderUtil.aReturningFloat(var47);
               Vec3d var48 = var168;
               float var184 = (float)var48.x;
               PlayerEntity var49 = var20;
               float var187 = (float)var49.getX();
               Object[] var10007 = new Object[]{null, null, var171};
               var10007[1] = var187;
               var10007[0] = var184;
               Object[] var51 = var10007;
               TargetRenderer var50 = this;
               double var10002 = var50.eReturningFloat(var51);
               Vec3d var52 = var168;
               float var188 = (float)var52.y;
               PlayerEntity var53 = var20;
               float var10005 = (float)var53.getY();
               Object[] var10008 = new Object[]{null, null, var171};
               var10008[1] = var10005;
               var10008[0] = var188;
               Object[] var55 = var10008;
               TargetRenderer var54 = this;
               double var185 = var54.eReturningFloat(var55) + this.j / 2.0F;
               Vec3d var56 = var168;
               var10005 = (float)var56.z;
               PlayerEntity var57 = var20;
               float var10006 = (float)var57.getZ();
               Object[] var10009 = new Object[]{null, null, var171};
               var10009[1] = var10006;
               var10009[0] = var10005;
               Object[] var59 = var10009;
               TargetRenderer var58 = this;
               var26 = new Vec3d(var10002, var185, var58.eReturningFloat(var59));
               int var133 = var16;
               TargetRenderer var132 = this;
               var105 = var132;
               TargetRenderer var102 = var132;
               label115:
               if (var133 != 0) {
                  Vec3d var134 = var102.h;
                  if (var134 != null) {
                     int var136 = var16;
                     TargetRenderer var135 = this;
                     var105 = var135;
                     TargetRenderer var103 = var135;
                     if (var136 == 0) {
                        break label115;
                     }

                     TargetRenderer var137 = var103;
                     TargetRenderer var104 = var137;
                     Vec3d var63 = var26;
                     Vec3d var62 = var104.h;
                     double var192;
                     int var138 = (var192 = var62.distanceTo(var63) - 50.0) == 0.0 ? 0 : (var192 < 0.0 ? -1 : 1);
                     if (var138 <= 0) {
                        break label116;
                     }
                  }

                  TargetRenderer var139 = this;
                  var105 = var139;
               }

               var105.h = var26;
               int var140 = var16;
               if (var140 != 0) {
                  break label107;
               }
            }

            double var66 = -var19 * 14.0F;
            float var27 = 1.0F - (float)Math.exp(var66);
            Vec3d var68 = this.h;
            Vec3d var69 = var26;
            Vec3d var70 = this.h;
            double var186 = var68.x + (var69.x - var70.x) * var27;
            Vec3d var71 = this.h;
            Vec3d var72 = var26;
            Vec3d var73 = this.h;
            double var189 = var71.y + (var72.y - var73.y) * var27;
            Vec3d var74 = this.h;
            Vec3d var75 = var26;
            Vec3d var76 = this.h;
            this.h = new Vec3d(var186, var189, var74.z + (var75.z - var76.z) * var27);
         }

         var106 = this;
      }

      TargetRenderer var112;
      int var142 = var16;
      TargetRenderer var141 = var106;
      var112 = var141;
      TargetRenderer var107 = var141;
      label90:
      if (var142 != 0) {
         float var193;
         int var143 = (var193 = var107.g - 0.01F) == 0.0F ? 0 : (var193 < 0.0F ? -1 : 1);
         if (var143 >= 0) {
            int var145 = var16;
            TargetRenderer var144 = this;
            var112 = var144;
            TargetRenderer var108 = var144;
            if (var145 == 0) {
               break label90;
            }

            TargetRenderer var146 = var108;
            TargetRenderer var109 = var146;
            Vec3d var147 = var109.h;
            label97:
            if (var147 != null) {
               int var149 = var16;
               TargetRenderer var148 = this;
               Object var113 = var148;
               TargetRenderer var110 = var148;
               if (var149 != 0) {
                  TargetRenderer var150 = var110;
                  TargetRenderer var111 = var150;
                  float var194;
                  int var151 = (var194 = var111.j - -1.0F) == 0.0F ? 0 : (var194 < 0.0F ? -1 : 1);
                  if (!((var151) != 0)) {
                     break label97;
                  }

                  ModeSetting var83 = this.a;
                  var113 = var83.aReturningObject();
               }

               int var119;
               String var169 = (String)var113;
               // String var84 = var169;
               var10000 = var84.hashCode();
               int var154 = var16;
               int var153 = var10000;
               var119 = var153;
               int var114 = var153;
               label85:
               if (var154 != 0) {
                  int var155 = var114;
                  switch (var155) {
                     case 68778607:
                        String var87 = "Ghost";
                        String var86 = var169;
                        byte var175 = ((byte)((var86.equals(var87)) ? 1 : 0));
                        int var157 = var16;
                        byte var156 = var175;
                        var119 = var156;
                        byte var115 = var156;
                        if (var157 == 0) {
                           break label85;
                        }

                        byte var158 = var115;
                        byte var116 = var158;
                        byte var159 = var116;
                        if (var159 == 0) {
                           break;
                        }

                        var172 = 0;
                        int var160 = var16;
                        if (var160 != 0) {
                           break;
                        }
                     case -1810807491:
                        String var91 = "Square";
                        String var90 = var169;
                        byte var176 = ((byte)((var90.equals(var91)) ? 1 : 0));
                        int var162 = var16;
                        byte var161 = var176;
                        var119 = var161;
                        byte var117 = var161;
                        if (var162 == 0) {
                           break label85;
                        }

                        byte var163 = var117;
                        byte var118 = var163;
                        byte var164 = var118;
                        if (var164 != 0) {
                           var172 = 1;
                        }
                  }

                  var119 = var172;
               }

               int var165 = var119;
               switch (var165) {
                  case 0:
                     Object[] var95 = new Object[]{var1, 139370710160546L};
                     TargetRenderer var94 = this;
                     var94.jReturningVoid(var95);
                     int var166 = var16;
                     if (var166 != 0) {
                        break;
                     }
                  case 1:
                     Object[] var98 = new Object[]{var1, 83828846066664L};
                     TargetRenderer var97 = this;
                     var97.kReturningVoid(var98);
               }

               return;
            }
         }

         TargetRenderer var152 = this;
         var112 = var152;
      }

      var112.k = 0.0F;
   }

   private static float bReturningFloat(Object[] var0) {
      float var3 = (Float)var0[0];
      long var1 = (Long)var0[1];
      var1 = 54056711095188L ^ var1;
      long var4 = var1 ^ 98872050651978L;
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var3;
      Object[] var6 = var10003;
      var3 = cReturningFloat(var6);
      return var3 * var3 * var3 * (var3 * (var3 * 6.0F - 15.0F) + 10.0F);
   }

   private static float cReturningFloat(Object[] var0) {
      float var3 = (Float)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 54056711095188L ^ var1;
      int var4 = Event.bReturningInt();
      float var20;
      int var19 = (var20 = var3 - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
      int var11 = var4;
      int var10 = var19;
      int var7 = var10;
      int var5 = var10;
      if (var11 == 0) {
         int var12 = var5;
         if (var12 < 0) {
            return 0.0F;
         }

         int var15 = var4;
         float var14 = var3;
         float var8 = var14;
         float var6 = var14;
         if (var15 != 0) {
            return var8;
         }

         float var21;
         int var16 = (var21 = var6 - 1.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
         var7 = var16;
      }

      int var17 = var7;
      return var17 <= 0 ? var3 : 1.0F;
   }

   public void jReturningVoid(Object[] var1) {
      Render3DEvent var4 = (Render3DEvent)var1[0];
      long var2 = (Long)var1[1];
      var2 = 54056711095188L ^ var2;
      long var5 = var2 ^ 106927237048837L;
      long var7 = var2 ^ 57287319846763L;
      long var9 = var2 ^ 104697994547999L;
      int var11 = Event.bReturningInt();
      int var140 = var11;
      TargetRenderer var139 = this;
      TargetRenderer var120 = var139;
      TargetRenderer var119 = var139;
      if (var140 == 0) {
         Vec3d var141 = var119.h;
         if (var141 == null) {
            return;
         }

         var120 = this;
      }

      label68: {
         int var143 = var11;
         TargetRenderer var142 = var120;
         TargetRenderer var122 = var142;
         TargetRenderer var121 = var142;
         if (var143 == 0) {
            ManagedGlTexture var144 = var121.c;
            if (var144 != null) {
               break label68;
            }

            TargetRenderer var145 = this;
            var122 = var145;
         }

         short var10001 = 4577;
         long var10002 = 7693482948956543599L ^ var2;
         Object[] var62 = new Object[]{"assets/prestige/particles/glow.png", var9};
         var122.c = TextureLoader.aReturningbT_C0095(var62);
      }

      RenderContext var10000 = var4.b;
      Vec3d var63 = this.h;
      double var173 = var63.x;
      Vec3d var64 = this.h;
      double var179 = var64.y;
      Vec3d var65 = this.h;
      double var10003 = var65.z;
      Object[] var10006 = new Object[]{null, null, null, null, var5};
      var10006[3] = var10003;
      var10006[2] = var179;
      var10006[1] = var173;
      var10006[0] = var10000;
      Object[] var66 = var10006;
      Vector3d var12 = RenderThreadUtil.aReturningVector3d(var66);
      Matrix4f var13 = new Matrix4f();
      Vector3d var67 = var12;
      float var174 = (float)var67.x;
      Vector3d var68 = var12;
      float var180 = (float)var68.y;
      Vector3d var69 = var12;
      float var73 = (float)var69.z;
      float var72 = var180;
      float var71 = var174;
      Matrix4f var70 = var13;
      var70.translate(var71, var72, var73);
      Quaternionf var74 = new Quaternionf();
      Quaternionf var14 = var74.identity();
      RenderContext var75 = var4.b;
      Camera var76 = var75.bo();
      float var78 = -var76.getYaw() * (float) Math.PI / 180.0F;
      Quaternionf var77 = var14;
      var77.rotateY(var78);
      RenderContext var79 = var4.b;
      Camera var80 = var79.bo();
      float var82 = var80.getPitch() * (float) Math.PI / 180.0F;
      Quaternionf var81 = var14;
      var81.rotateX(var82);
      Quaternionf var84 = var14;
      Matrix4f var83 = var13;
      var83.rotate((Quaternionfc)var84);
      double var168 = (float)(System.currentTimeMillis() - this.l) / 3000.0F;
      double var85 = (float)(System.currentTimeMillis() - this.l) / 2500.0F;
      float var15 = (float)(var168 + Math.sin(var85) / 10.0);
      float var16 = -0.05F;
      float var17 = this.j / 4.0F;
      byte var18 = 1;
      ModuleManager var169 = Prestige.d;
      Object[] var88 = new Object[0];
      ModuleManager var87 = var169;
      MenuSettings var170 = var87.aReturningMenuSettings(var88);
      Object[] var90 = new Object[0];
      MenuSettings var89 = var170;
      ColorSetting var91 = var89.bReturningColorSetting(var90);
      Color var19 = (Color)var91.aReturningObject();
      Color var92 = var19;
      int var20 = var92.getRed();
      Color var93 = var19;
      int var21 = var93.getGreen();
      Color var94 = var19;
      int var22 = var94.getBlue();
      int var166;
      do {
         byte var147 = 4;
         int var146 = var23;
         if (var146 >= var147) {
            break;
         }

         float var24 = var15 * 360.0F;
         float var25 = var24 + 150.0F;
         float var26 = var24;

         float var134;
         float var135;
         while (true) {
            float var183;
            int var148 = (var183 = var26 - (var24 + 100.0F)) == 0.0F ? 0 : (var183 < 0.0F ? -1 : 1);
            if (var148 < 0) {
               float var175 = var24 - 90.0F;
               Object[] var10004 = new Object[]{null, null, var25};
               var10004[1] = var175;
               var10004[0] = var26;
               Object[] var95 = var10004;
               float var27 = dReturningFloat(var95);
               float var28 = this.i * this.g;
               double var96 = var26;
               double var29 = Math.toRadians(var96);
               double var98 = var29 * 1.5;
               double var31 = Math.sin(var98);
               double var100 = var29;
               double var33 = Math.cos(var100);
               double var102 = var29;
               double var35 = Math.sin(var102);
               double var37 = var17 + var31 * 0.25;
               int var151 = var11;
               float var150 = 0.15F;
               float var149 = 0.15F;
               var134 = var149;
               var135 = var150;
               float var123 = var149;
               float var124 = var150;
               if (var151 != 0) {
                  break;
               }

               byte var154 = var18;
               float var153 = var124;
               float var152 = var123;
               float var129 = var152;
               float var130 = var153;
               float var125 = var152;
               float var126 = var153;
               float var131;
               float var132;
               float var133;
               if (var154 != 0) {
                  float var156 = var126;
                  float var155 = var125;
                  float var127 = var155;
                  float var128 = var156;
                  float var159 = var27;
                  float var158 = var128;
                  float var157 = var127;
                  var131 = var157;
                  var132 = var158;
                  var133 = var159;
               } else {
                  var133 = (1.0F - var27) * 1.5F;
                  var132 = var130;
                  var131 = var129;
               }

               float var107 = var133;
               float var106 = var132;
               float var39 = var131 * (Math.max(var106, var107) + 0.45F);
               float var40 = var39 * (1.7F + (0.5F - var16) * 2.0F);
               byte var160 = var18;
               if (var160 != 0) {
                  var27 = 1.0F - var27;
               }

               float var41 = 5.0F;
               var173 = var27;
               double var110 = var41;
               double var108 = var173;
               float var42 = 1.0F - (float)Math.pow(var108, var110);
               float var43 = var40 * var42 * this.g;
               float var44 = 0.5F;
               var173 = var27;
               double var114 = var44;
               double var112 = var173;
               float var45 = 1.0F - (float)Math.pow(var112, var114);
               float var46 = var40 * var45 * this.g;
               float var47 = (float)(var33 * var28);
               float var48 = (float)((var37 - 0.9F) * this.g);
               float var49 = (float)(var35 * var28);
               float var171 = var46 * 2.5F;
               float var117 = 1.0F;
               float var116 = var171;
               float var50 = Math.min(var116, var117);
               int var51 = (int)(var20 * (1.0F - var50) + 255.0F * var50);
               int var52 = (int)(var21 * (1.0F - var50) + 255.0F * var50);
               int var53 = (int)(var22 * (1.0F - var50) + 255.0F * var50);
               float var54 = var51 / 255.0F;
               float var55 = var52 / 255.0F;
               float var56 = var53 / 255.0F;
               Color var57 = new Color(var54, var55, var56, var46);
               MeshBufferManager var172 = var4.a;
               RenderContext var178 = var4.b;
               ManagedGlTexture var181 = this.c;
               float var182 = var47 - var43 / 2.0F;
               float var10005 = var48 - var43 / 2.0F;
               float var10007 = var47 + var43 / 2.0F;
               float var10008 = var48 + var43 / 2.0F;
               Object[] var10018 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, var7};
               var10018[15] = true;
               var10018[14] = 0.0F;
               var10018[13] = var57;
               var10018[12] = var57;
               var10018[11] = var57;
               var10018[10] = var57;
               var10018[9] = var49;
               var10018[8] = var10008;
               var10018[7] = var10007;
               var10018[6] = var49;
               var10018[5] = var10005;
               var10018[4] = var182;
               var10018[3] = var181;
               var10018[2] = var13;
               var10018[1] = var178;
               var10018[0] = var172;
               Object[] var118 = var10018;
               TexturedRectangleRenderer.o(var118);
               var26++;
               int var161 = var11;
               if (var161 == 0) {
                  continue;
               }
            }

            var135 = -1.35F;
            var134 = var15;
            break;
         }

         byte var138;
         label49: {
            var15 = var134 * var135;
            int var163 = var11;
            byte var162 = var18;
            byte var137 = var162;
            byte var136 = var162;
            if (var163 == 0) {
               byte var164 = var136;
               if (var164 != 0) {
                  var138 = 0;
                  break label49;
               }

               var137 = 1;
            }

            byte var165 = var137;
            var138 = var165;
         }

         var18 = var138;
         var17 += this.j / 4.0F;
         var23++;
         var166 = var11;
      } while (var166 == 0);
   }

   public void kReturningVoid(Object[] var1) {
      Render3DEvent var4;
      long var5;
      long var7;
      long var9;
      label14: {
         var4 = (Render3DEvent)var1[0];
         long var2 = (Long)var1[1];
         var2 = 54056711095188L ^ var2;
         var5 = var2 ^ 92100318692687L;
         var7 = var2 ^ 7585304793121L;
         var9 = var2 ^ 47621916381647L;
         long var11 = var2 ^ 120692070333525L;
         int var13 = Event.bReturningInt();
         int var126 = var13;
         TargetRenderer var125 = this;
         TargetRenderer var124 = var125;
         TargetRenderer var123 = var125;
         if (var126 == 0) {
            ManagedGlTexture var127 = var123.b;
            if (var127 != null) {
               break label14;
            }

            TargetRenderer var128 = this;
            var124 = var128;
         }

         short var10001 = 31208;
         long var10002 = 897147714883362095L ^ var2;
         Object[] var25 = new Object[]{"assets/prestige/icons/target.png", var11};
         var124.b = TextureLoader.aReturningbT_C0095(var25);
      }

      RenderContext var10000 = var4.b;
      Vec3d var26 = this.h;
      double var131 = var26.x;
      Vec3d var27 = this.h;
      double var147 = var27.y;
      Vec3d var28 = this.h;
      double var10003 = var28.z;
      Object[] var10006 = new Object[]{null, null, null, null, var5};
      var10006[3] = var10003;
      var10006[2] = var147;
      var10006[1] = var131;
      var10006[0] = var10000;
      Object[] var29 = var10006;
      Vector3d var14 = RenderThreadUtil.aReturningVector3d(var29);
      Matrix4f var15 = new Matrix4f();
      Vector3d var30 = var14;
      float var132 = (float)var30.x;
      Vector3d var31 = var14;
      float var148 = (float)var31.y;
      Vector3d var32 = var14;
      float var36 = (float)var32.z;
      float var35 = var148;
      float var34 = var132;
      Matrix4f var33 = var15;
      var33.translate(var34, var35, var36);
      Quaternionf var37 = new Quaternionf();
      Quaternionf var16 = var37.identity();
      RenderContext var38 = var4.b;
      Camera var39 = var38.bo();
      float var41 = -var39.getYaw() * (float) Math.PI / 180.0F;
      Quaternionf var40 = var16;
      var40.rotateY(var41);
      RenderContext var42 = var4.b;
      Camera var43 = var42.bo();
      var131 = var43.getPitch() * (float) Math.PI / 180.0F;
      double var44 = this.k / 50.0F;
      float var47 = (float)(var131 + Math.sin(var44) / 4.0);
      Quaternionf var46 = var16;
      var46.rotateX(var47);
      double var48 = this.k;
      float var51 = (float)Math.toRadians(var48);
      Quaternionf var50 = var16;
      var50.rotateZ(var51);
      Quaternionf var53 = var16;
      Matrix4f var52 = var15;
      var52.rotate((Quaternionfc)var53);
      float var17 = (this.j / 2.0F + 0.5F) * 80.0F / 100.0F * this.g * 0.85F;
      float var18 = var17 / 2.0F;
      ModuleManager var134 = Prestige.d;
      Object[] var55 = new Object[0];
      ModuleManager var54 = var134;
      MenuSettings var135 = var54.aReturningMenuSettings(var55);
      Object[] var57 = new Object[0];
      MenuSettings var56 = var135;
      ColorSetting var58 = var56.bReturningColorSetting(var57);
      Color var59 = (Color)var58.aReturningObject();
      Color var60 = var59.brighter();
      int var136 = var60.getRGB();
      ModuleManager var149 = Prestige.d;
      Object[] var62 = new Object[0];
      ModuleManager var61 = var149;
      MenuSettings var150 = var61.aReturningMenuSettings(var62);
      Object[] var64 = new Object[0];
      MenuSettings var63 = var150;
      ColorSetting var65 = var63.bReturningColorSetting(var64);
      Color var66 = (Color)var65.aReturningObject();
      int var151 = var66.getRGB();
      double var67 = System.currentTimeMillis() * 0.001;
      float var161 = (float)(Math.sin(var67) * 0.5 + 0.5);
      var10006 = new Object[]{null, null, null, var9};
      var10006[2] = var161;
      var10006[1] = var151;
      var10006[0] = var136;
      Object[] var70 = var10006;
      TargetRenderer var69 = this;
      Color var19 = var69.aReturningColor(var70);
      ModuleManager var137 = Prestige.d;
      Object[] var72 = new Object[0];
      ModuleManager var71 = var137;
      MenuSettings var138 = var71.aReturningMenuSettings(var72);
      Object[] var74 = new Object[0];
      MenuSettings var73 = var138;
      ColorSetting var75 = var73.bReturningColorSetting(var74);
      Color var76 = (Color)var75.aReturningObject();
      Color var77 = var76.brighter();
      int var139 = var77.getRGB();
      ModuleManager var152 = Prestige.d;
      Object[] var79 = new Object[0];
      ModuleManager var78 = var152;
      MenuSettings var153 = var78.aReturningMenuSettings(var79);
      Object[] var81 = new Object[0];
      MenuSettings var80 = var153;
      ColorSetting var82 = var80.bReturningColorSetting(var81);
      Color var83 = (Color)var82.aReturningObject();
      int var154 = var83.getRGB();
      double var84 = System.currentTimeMillis() * 0.001 + 1.0;
      float var162 = (float)(Math.sin(var84) * 0.5 + 0.5);
      var10006 = new Object[]{null, null, null, var9};
      var10006[2] = var162;
      var10006[1] = var154;
      var10006[0] = var139;
      Object[] var87 = var10006;
      TargetRenderer var86 = this;
      Color var20 = var86.aReturningColor(var87);
      ModuleManager var140 = Prestige.d;
      Object[] var89 = new Object[0];
      ModuleManager var88 = var140;
      MenuSettings var141 = var88.aReturningMenuSettings(var89);
      Object[] var91 = new Object[0];
      MenuSettings var90 = var141;
      ColorSetting var92 = var90.bReturningColorSetting(var91);
      Color var93 = (Color)var92.aReturningObject();
      Color var94 = var93.brighter();
      int var142 = var94.getRGB();
      ModuleManager var155 = Prestige.d;
      Object[] var96 = new Object[0];
      ModuleManager var95 = var155;
      MenuSettings var156 = var95.aReturningMenuSettings(var96);
      Object[] var98 = new Object[0];
      MenuSettings var97 = var156;
      ColorSetting var99 = var97.bReturningColorSetting(var98);
      Color var100 = (Color)var99.aReturningObject();
      int var157 = var100.getRGB();
      double var101 = System.currentTimeMillis() * 0.001 + 2.0;
      float var163 = (float)(Math.sin(var101) * 0.5 + 0.5);
      var10006 = new Object[]{null, null, null, var9};
      var10006[2] = var163;
      var10006[1] = var157;
      var10006[0] = var142;
      Object[] var104 = var10006;
      TargetRenderer var103 = this;
      Color var21 = var103.aReturningColor(var104);
      ModuleManager var143 = Prestige.d;
      Object[] var106 = new Object[0];
      ModuleManager var105 = var143;
      MenuSettings var144 = var105.aReturningMenuSettings(var106);
      Object[] var108 = new Object[0];
      MenuSettings var107 = var144;
      ColorSetting var109 = var107.bReturningColorSetting(var108);
      Color var110 = (Color)var109.aReturningObject();
      Color var111 = var110.brighter();
      int var145 = var111.getRGB();
      ModuleManager var158 = Prestige.d;
      Object[] var113 = new Object[0];
      ModuleManager var112 = var158;
      MenuSettings var159 = var112.aReturningMenuSettings(var113);
      Object[] var115 = new Object[0];
      MenuSettings var114 = var159;
      ColorSetting var116 = var114.bReturningColorSetting(var115);
      Color var117 = (Color)var116.aReturningObject();
      int var160 = var117.getRGB();
      double var118 = System.currentTimeMillis() * 0.001 + 3.0;
      float var164 = (float)(Math.sin(var118) * 0.5 + 0.5);
      var10006 = new Object[]{null, null, null, var9};
      var10006[2] = var164;
      var10006[1] = var160;
      var10006[0] = var145;
      Object[] var121 = var10006;
      TargetRenderer var120 = this;
      Color var22 = var120.aReturningColor(var121);
      MeshBufferManager var130 = var4.a;
      RenderContext var146 = var4.b;
      ManagedGlTexture var165 = this.b;
      float var10004 = -var18;
      float var10005 = -var18;
      Object[] var10018 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, var7};
      var10018[15] = false;
      var10018[14] = 0.0F;
      var10018[13] = var22;
      var10018[12] = var21;
      var10018[11] = var20;
      var10018[10] = var19;
      var10018[9] = 0.0F;
      var10018[8] = var18;
      var10018[7] = var18;
      var10018[6] = 0.0F;
      var10018[5] = var10005;
      var10018[4] = var10004;
      var10018[3] = var165;
      var10018[2] = var15;
      var10018[1] = var146;
      var10018[0] = var130;
      Object[] var122 = var10018;
      TexturedRectangleRenderer.o(var122);
   }

   public static float dReturningFloat(Object[] var0) {
      float var3 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var2 = (Float)var0[2];
      return (var3 - var1) / (var2 - var1);
   }

   private float eReturningFloat(Object[] var1) {
      float var4 = (Float)var1[0];
      float var3 = (Float)var1[1];
      float var2 = (Float)var1[2];
      return var4 + var2 * (var3 - var4);
   }

   private Color aReturningColor(Object[] var1) {
      int var4 = (Integer)var1[0];
      int var2 = (Integer)var1[1];
      float var3 = (Float)var1[2];
      long var5 = (Long)var1[3];
      var5 = 54056711095188L ^ var5;
      int var10001 = 23578;
      long var10002 = 6571888635438095464L ^ var5;
      int var10000 = var4 >> 16;
      var10001 = (short)24058;
      var10002 = 1620797891969441162L ^ var5;
      float var11 = (var10000 & 0xFF) * (1.0F - var3);
      short var22 = 884;
      long var10003 = 7079243120378741509L ^ var5;
      var10001 = var2 >> 16;
      short var23 = 7982;
      var10003 = 7176300037683617624L ^ var5;
      int var7 = (int)(var11 + (var10001 & 0xFF) * var3);
      int var17 = 23602;
      var10002 = 2132472923520097345L ^ var5;
      var10000 = var4 >> 8;
      var17 = (short)7982;
      var10002 = 7176300037683617624L ^ var5;
      float var13 = (var10000 & 0xFF) * (1.0F - var3);
      short var26 = 19876;
      var10003 = 3510562287808433619L ^ var5;
      var17 = var2 >> 8;
      short var27 = 7982;
      var10003 = 7176300037683617624L ^ var5;
      int var8 = (int)(var13 + (var17 & 0xFF) * var3);
      short var20 = 7982;
      var10002 = 7176300037683617624L ^ var5;
      float var14 = (var4 & 0xFF) * (1.0F - var3);
      short var29 = 7982;
      var10003 = 7176300037683617624L ^ var5;
      int var9 = (int)(var14 + (var2 & 0xFF) * var3);
      short var35 = 884;
      long var10004 = 7079243120378741509L ^ var5;
      int var30 = var7 << 16;
      short var36 = 19876;
      long var10005 = 3510562287808433619L ^ var5;
      return new Color(var30 | var8 << 8 | var9);
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(100649206534208L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[4];
      String var28 = "]\u0092\u0016æ^ÚØ~m¾½\u0011Ãc\b\u008a@8àÕ2U4[r\u008d\u0010¯¸Ù¯®iLV|Wp\u008aò\u0087çR1æî\u0093ÍÚZ\u007f¯Ù\u0000.\u008c÷¥)|Ã\u0003N¿\u0088¤\u0081f\u0018È\u0007 \u0017\u0088ÈÃ}Ðù\u0017C";
      int var30 = "]\u0092\u0016æ^ÚØ~m¾½\u0011Ãc\b\u008a@8àÕ2U4[r\u008d\u0010¯¸Ù¯®iLV|Wp\u008aò\u0087çR1æî\u0093ÍÚZ\u007f¯Ù\u0000.\u008c÷¥)|Ã\u0003N¿\u0088¤\u0081f\u0018È\u0007 \u0017\u0088ÈÃ}Ðù\u0017C"
         .length();
      char var27 = 16;
      int var35 = -1;

      label72:
      while (true) {
         String var36 = var28.substring(++var35, var35 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var36.getBytes("ISO-8859-1"));
            String var50 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var50;
                  if ((var35 += var27) >= var30) {
                     r = var31;
                     s = new String[4];
                     w = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(100649206534208L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[6];
                     String var15 = "´y´¥ZåènØ¸«ZíÛev\u0005ÁG}ÐXÀÜ\u0015\u0010\u0085Ê\u0018Üöþ";
                     int var16 = "´y´¥ZåènØ¸«ZíÛev\u0005ÁG}ÐXÀÜ\u0015\u0010\u0085Ê\u0018Üöþ".length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var39 = var17;
                        var10001 = var14++;
                        long var54 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var54;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var62 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var58) {
                              case 0:
                                 var39[var10001] = var62;
                                 if (var13 >= var16) {
                                    u = var17;
                                    v = new Integer[6];
                                    z = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(100649206534208L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[3];
                                    String var4 = "Jâ+í\u0087½ë\u0097jöäuwè\u0004´¦jP'\u0084mÉ\u007f";
                                    int var5 = "Jâ+í\u0087½ë\u0097jöäuwè\u0004´¦jP'\u0084mÉ\u007f".length();
                                    do {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       var47 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var62 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       // var6[var47] = var62;
                                    } while (var2 < var5);

                                    x = var6;
                                    y = new Long[3];
                                    break;
                                 }
                                 break;
                              default:
                                 var39[var10001] = var62;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "ÝF\u008d'yÙèÜV\u0086ùÞÏÊ£ë";
                                 var16 = "ÝF\u008d'yÙèÜV\u0086ùÞÏÊ£ë".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var39 = var17;
                           var10001 = var14++;
                           var54 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var58 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var35);
                  break;
               default:
                  var31[var29++] = var50;
                  if ((var35 += var27) < var30) {
                     var27 = var28.charAt(var35);
                     continue label72;
                  }

                  var28 = "¨=Ô\u008d\u0092zYÍ\\í\u001a\u0003V\"\u0088Ôû\u0087¥\"1od*¢\u0010Öä\u0085#\u0000\u0003ï2\f¯ËÆ¹d2\rr ¡\u0094`|\u008fG{\n\u0086¬ê@:8\u0006!v\u0000«\u0087\u0010\u001cfOëÓnaIµ\u0086¼Ûü\u00ad >";
                  var30 = "¨=Ô\u008d\u0092zYÍ\\í\u001a\u0003V\"\u0088Ôû\u0087¥\"1od*¢\u0010Öä\u0085#\u0000\u0003ï2\f¯ËÆ¹d2\rr ¡\u0094`|\u008fG{\n\u0086¬ê@:8\u0006!v\u0000«\u0087\u0010\u001cfOëÓnaIµ\u0086¼Ûü\u00ad >"
                     .length();
                  var27 = '@';
                  var35 = -1;
            }

            var36 = var28.substring(++var35, var35 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 7354;
      if (s[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])t.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fx", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = r[var5].getBytes("ISO-8859-1");
         s[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return s[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fx_C0318",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10837;
      if (v[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = u[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])w.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               w.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fx", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         v[var3] = var15;
      }

      return v[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fx_C0318",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12289;
      if (y[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = x[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])z.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               z.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fx", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         y[var3] = var15;
      }

      return y[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fx_C0318",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = B[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = A[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 29;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 5;
            yield var22;
         }
         case 8 -> {
            byte var23 = 7;
            yield var23;
         }
         case 9 -> {
            byte var24 = 26;
            yield var24;
         }
         case 10 -> {
            byte var25 = 48;
            yield var25;
         }
         case 11 -> {
            byte var26 = 3;
            yield var26;
         }
         case 12 -> {
            byte var27 = 43;
            yield var27;
         }
         case 13 -> {
            byte var28 = 49;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 53;
            yield var31;
         }
         case 17 -> {
            byte var32 = 12;
            yield var32;
         }
         case 18 -> {
            byte var33 = 38;
            yield var33;
         }
         case 19 -> {
            byte var34 = 57;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 13;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 59;
            yield var38;
         }
         case 24 -> {
            byte var39 = 23;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 35;
            yield var41;
         }
         case 27 -> {
            byte var42 = 30;
            yield var42;
         }
         case 28 -> {
            byte var43 = 51;
            yield var43;
         }
         case 29 -> {
            byte var44 = 44;
            yield var44;
         }
         case 30 -> {
            byte var45 = 17;
            yield var45;
         }
         case 31 -> {
            byte var46 = 18;
            yield var46;
         }
         case 32 -> {
            byte var47 = 47;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 56;
            yield var51;
         }
         case 37 -> {
            byte var52 = 4;
            yield var52;
         }
         case 38 -> {
            byte var53 = 0;
            yield var53;
         }
         case 39 -> {
            byte var54 = 46;
            yield var54;
         }
         case 40 -> {
            byte var55 = 52;
            yield var55;
         }
         case 41 -> {
            byte var56 = 6;
            yield var56;
         }
         case 42 -> {
            byte var57 = 8;
            yield var57;
         }
         case 43 -> {
            byte var58 = 50;
            yield var58;
         }
         case 44 -> {
            byte var59 = 28;
            yield var59;
         }
         case 45 -> {
            byte var60 = 42;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 62;
            yield var62;
         }
         case 48 -> {
            byte var63 = 34;
            yield var63;
         }
         case 49 -> {
            byte var64 = 1;
            yield var64;
         }
         case 50 -> {
            byte var65 = 41;
            yield var65;
         }
         case 51 -> {
            byte var66 = 40;
            yield var66;
         }
         case 52 -> {
            byte var67 = 15;
            yield var67;
         }
         case 53 -> {
            byte var68 = 11;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 37;
            yield var70;
         }
         case 56 -> {
            byte var71 = 60;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 32;
            yield var73;
         }
         case 59 -> {
            byte var74 = 22;
            yield var74;
         }
         case 60 -> {
            byte var75 = 55;
            yield var75;
         }
         case 61 -> {
            byte var76 = 10;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 2;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            B[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      A[0] = "%fJV!\b3fO\f2\u001f$-L\n>\u000b5j[\u001du\u001e9";
      A[1] = "wRk\u0006Nv\u0002r`\t_9c|k\u0002[c\u0017";
      A[2] = float.class;
      B[2] = "java/lang/Float";
      A[3] = "i)\u001c1\u0016|b&\r~kdq!\u00047";
      A[4] = int.class;
      B[4] = "java/lang/Integer";
      A[5] = "g7+0ciq7.jp~f|-l|jw;:{7zo;8pm7S 8mmpd7";
      A[6] = "S\u0006\f\u0004KzE\u0006\t^XmRM\nXTyC\n\u001dO\u001flc";
      A[7] = "\u0014g\u0006r\u0018P\u0014g\u0011.\u0014_\u000e,\u00110\u0014J\t]Cj@\u000e";
      A[8] = double.class;
      B[8] = "java/lang/Double";
      A[9] = "lF\u0012#\b`gI\u0003luuuS\u0001/";
      A[10] = long.class;
      B[10] = "java/lang/Long";
      A[11] = "*J/fej<J*<v}+\u0001):zi:F>-1y}";
      A[12] = "MHrc@\u000f8hylQ@YfrgU\u001a-";
      A[13] = "q\t\u001bN\u0014-q\t\f\u0012\u0018\"kB\f\f\u00187l3]TJ";
      A[14] = ";4\u0011'9>0;\u0000hZ3%=";
      A[15] = "JcJ\u0007N+\\cO]]<K(L[Q(Zo[L\u001a:k";
      A[16] = "T\u000b:\u0011]\u001eB\u000b?KN\tU@<MB\u001dD\u0007+Z\t\nv";
      A[17] = "\u001alslv&\u0011cb#\u0017(\u001ahfy";
      A[18] = "5oDM7\u007f>`U\u0002Tr+mZiap:~FEv}";
      A[19] = "@?\u000f7oR5\u001f\u00048~\u001dT\u0011\u000f3zG ";
      A[20] = boolean.class;
      B[20] = "java/lang/Boolean";
      A[21] = "os}\u0013\u0017qysxI\u0004fn8{O\br\u007f\u007flXCe|";
      A[22] = "(rVwff]R]xw)<\\VsssH";
      A[23] = "stV\u0017sE\u0006T]\u0018b\ngZV\u0013fP\u0013";
      A[24] = "b\tg[\u001dd\u0017)lT\f+v'g_\bq\u0002";
      A[25] = ",Zq\u001dPyYzz\u0012A68tq\u0019ElL";
      A[26] = void.class;
      B[26] = "java/lang/Void";
      A[27] = "@\u0000LqC\u001c5 G~RST.LuV\t ";
      A[28] = "r-k\u007fHBp3\"\u0007GNi0~bF";
      A[29] = "\u0012|\u0005]\b\u0018\u000fi]\u007fI\u0015\u0017o";
      A[30] = "OOS$p>YOV~c)N\u0004Uxo=_CBo$*A";
      A[31] = "%AoYtKPadVe\u00041oo]a^E";
      A[32] = "x\nH\u0012\u00141z\u0014\u0001m\u000b?c\u001d]R\u00171y\u001e";
      A[33] = ">Sw\u001c':(SrF4-?\u0018q@89._fWs)\u001d";
      A[34] = "PC,JJR%c'E[\u001dDm,N_G0";
      A[35] = "_\n\u001cr\u0015\u0006I\n\u0019(\u0006\u0011^A\u001a.\n\u0005O\u0006\r9A\u0013\b";
      A[36] = "'I\u000e gX'I\u0019|kW=\u0002\u0019bkB:sN?2\u0005";
      A[37] = "e\u007f0nld\u0010_;a}+qQ0jyq\u0005";
      A[38] = "ax2@6gcf{#=||c-Z:";
      A[39] = ";bPxyINB[wh\u0006/LP|l\\[";
      A[40] = "O\u007f':'\u001aY\u007f\"`4\rN4!f8\u0019_s6qs\u000eb";
      A[41] = ")|@t;\u001b+b\t\u000b$\u00152kU48\u001b(hD";
      A[42] = "\u001a^\",dO\f^'vwX\u001b\u0015$p{L\nR3g0[\u0016";
      A[43] = "}#`\u0011\u001eI\b\u0003k\u001e\u000f\u0006i\r`\u0015\u000b\\\u001d";
      A[44] = "=PGI\u0019\u007f+PB\u0013\nh<\u001bA\u0015\u0006|-\\V\u0002Mm\r";
      A[45] = "\u0003\u001e&\u0003i5\u0015\u001e#Yz\"\u0002U _v6\u0013\u00127H=!\u0000";
      A[46] = "M\u0005\t\nhD8%\u0002\u0005y\u000bY+\t\u000e}Q-";
      A[47] = "\u001dXJ=Dt\u000bXOgWc\u001c\u0013La[w\rT[v\u0010c\u0003";
      A[48] = "\u001a^\\\t\u007f,o~W\u0006nc\u000ep\\\rj9z";
      A[49] = "s:t.\u0005\u0004cqat?L\u0011}m9\u0005@vqgz\u0005";
      A[50] = "\rpn\u0013_.Tw4b\t\u0014F5\u007f\f\ruHvh\u0013d-D$cZUx\r:lb";
      A[51] = "sdk`0xu)izS} .bO4q$U8z6c ;<:*{I";
      A[52] = "cP\n'B\u0000$UOa(\u0006X\u000b\u00114\u0011\u000f2\u000eB0W";
      A[53] = "\u0019\u0015='\tYB\u0004d-{\f\u0000\u001d;}\u0007\u000b\u0000|7t\u0012\\\bCleKVz";
      A[54] = "qc\u0007JL\u00030+\u0000\u001fp\u00132`F\u001b\u0016\u0004\u0013{Y\u001b5\u0019+~]\rpG\u007f}GOM\b!t]v";
      A[55] = "~\u0018\u0000\u0006g\u001c#\u0006F\u0018\r\u0013.\u000f9D\u007f\u001a\"Q\b\u00116\u0004-i\u0000\u000fa\u001bwXUF\u007f\u0014OPK\u0011`N~\u0005\u0002\u000fov";
      A[56] = "_\u000bM_Dh\u0002\u0015\u000bA.z\t\u0005t\u0019\\\u007fT\u0006\u0013\u0015V<TzIVS8\u0012\u001dE\\\u00108nG\u0006Y\u0014~\tK\f\u001a\u0014\u0002";
      A[57] = "C\fw\tz%GPa\u0002\u001du%\u001ew\u0018suD\u00104\u000fl\u001cB\u000em\u0011zuKR5T\u001d";
      A[58] = "~C\u007f\u0011L\u0000#]9\u000f&\u0016(h/\u0006G\u0003)IFWT\u0017uN![^Tu2{\u0018[P3Uw\u0012\u0018PO";
      A[59] = "\u000f\u001aM\u0000?8R\u0004\u000b\u001eU9Y\u0010tF'/\u0004\u0017\u0013J-l\u0004kI\t(hB\fE\u0003kh>";
      A[60] = "x\u0013\u000b(8\u001eqBC8@\u0011m\u0000R4,#9M\tiqt9\u000e^>xElG@1@";
      A[61] = "H\u0005'dHI\u0011\u0002}\u0015\u001as\u0003@6{\u001a\u0012\r\u0003!ds\u0010\u001aT}gLK\u000b\rw\u0015";
      A[62] = "?\u001brk\u0011Pd\n+ac\u00001\u000eA<\u000fof\f~/\n\u0001bLb7c";
      A[63] = "\u001f^9)NUFYcX\u001coO\u0007$$J\u001e\u001b\u001e0<u\u0004E\u001b%g\u0004P\\\u000f=X";
      A[64] = "Cb\u0014_3:\u0007u\u0004\u0003Yw@m\u0013\u0015=bFiuW+gW<D\u0002byX\u0004L\u001c5f\u00025\u0019U+i:=\u0007\u000243\u000bhN\u001c;\u000bCb\u0014_3:\u0007u\u0004\u0003Y";
      A[65] = "mF@\b2\u0005#\u0013B\u000bW\u001b=GI\r\u0000Lg\u0017\u0017aj\u0007!\u0010Q\u0006f\rb\u0010";
      A[66] = "s\\+\u0000Ga=\t)\u0003\"\u007f#]\"\u0005u(y\r\u007fi\u001fc?\n:\u000e\u0013i|\n";
      A[67] = "~\u00012S--xL0IN%=M2S5H/\f?P)q;A9SN$;L2V6s?Qe7";
      A[68] = "&x\u0002+19ga\bn\rfwy\u0013saT#:M$4\u0003#w\u001fy52v>\u0001v\r";
      A[69] = "|\u001c9gJ/\u007fCz{:7\u0012Q6wT7s_u`K^+S'k\u0002o~\u001a9d:";
      A[70] = "OMiC\rq\u0013\u0016-\u0000vjF\u0011sE\u0017w[|p\b\nqQ\u0006,SN2*";
      A[71] = "\u000fB\u001cE bS\u0019X\u0006[b\r\u000f\tC6HjJ\u0012S6 [\u001f[M9\u0018\u000fB\u001cE bS\u0019X\u0006[";
      A[72] = "WOt!7\u0017VQ1/\u0006C+_q.hCJQ29w*U\u0016|e8K[\u0017ao\u0006";
      A[73] = "\u001a[;Q,\u0015ZE%\u0017\u001c\u001ddE!\u001fr\u0013\u0005Kb\bmz\u0005\r%W%C\u0019E6\u000b\u001c";
      A[74] = "~lpY\u001c1c/c\u0019y;f\u0014fJ@*y~o\u001b\b:\u0001";
      A[75] = "\u001ar\u000e\u0016p\u0012AcW\u001c\u0002B\u0014g(Vo@\u001f\u001b]RgS\u0010uY\u0012{Ky";
      A[76] = "N0Jz>p\u001b.M=Oq'x\u000fe1rI|Oy)\u001b";
      A[77] = "\u001dZGTGJ\r\u0011R\u000e}\u0000\u007f\u001d^CG\u000e\u0018\u0011T\u0000G";
      A[78] = "\u000e\u0017\u001a&\u0019 S\t\\8s1^\u0000#`\u00017\u0005\u001aDl\u000bt\u0005f\u001e/\u000epC\u0001\u0012%Mp?";
      A[79] = "a\u001fRq.? \u0006X4\u0012`0\u001eC)~RgY\u0018t+\u0005`\u0010^tnbl\u001a\u001dt\u0012";
      A[80] = "v+\u0018:\u001d\u001c%w\u0001.q\tFc\u00079\u001f\u000b'mD.\u0000bw\u007f\u0017!\u0014\u00129*\u0015\"q";
      A[81] = "L0\u000b\u001e\u001b:^6\u001cXq</<\u001b\u0010\u001f<N2X\u0007\u0000UM6\r\u000bKm]}\u0018Qq";
      A[82] = "k{JA\u0004.6e\f_n)*rs\u0007\u001c9`v\u0014\u000b\u0016z`\nNH\u0013~&mBBP~Z";
      A[83] = "\ftqvcPMm{3_\u000f]u`.3=\t6>yej\t{l$g[\\2r+_";
      A[84] = "d\u0014cZ\u0004p8O'\u0019\u007fpfYv\\\u0012[\u0001\u001cmL\u001220I$R\u001d\nd\u0014cZ\u0004p8O'\u0019\u007f";
      A[85] = "\\m`*5#\tsgmD#5%%5:![!e)\"H";
      A[86] = "rU\u001fj6\u0004<\u0000\u001diS\u001a\"T\u0016o\u0004Mx\u0004J\u0003n\u0006>\u0003\u000edb\f}\u0003";
      A[87] = "`D,FoQx\u00009\u0002PV\nWhX7X3C%^4?";
      A[88] = "F=;.\u001fv\u00018~huz}<!/\u0015qD8}9\u001e";
      A[89] = "K\t_X`\u001f\u0005\\][\u0005\n\u0017\u0019RVi8C]\b\u000b\u0005^\u0016\b[Tu\u0010C\nX18\u001d\u0007_NV4\u0017D_2";
      A[90] = "c\u00131i\u000f\u0006:\u0014k\u0018^<(V v]]&\u00157i4\u0005*G< \u0005PcY3\u0018";
      A[91] = "e\u0011\f y(lMTe\u001e+\u0002\u0001\u0016)p(c\u000fU>oAx\u0000\n2%3s\u0000U=\u001e";
      A[92] = "fte]YB;j#C3M>u\\\u001fAD:=mJ\bZ5\u0005eT_Eo40\u001dAJW<.J^\u0010figTQ(";
      A[93] = "6\u001eOp]\u0011m\u000f\u0016z/A8\u000bl.RCUMX/QG;I\u00183I.";
      A[94] = "\u00107Q\u0016f\f\u0015dUP\t\u000f,$C^g\u000fM*\u0000Ixf\u0010)O\u00105\\Q0EU\t";
      A[95] = " b\u001d\u000f\u000f\u0011du\rSeZ>x\u0015B\b \"kBL]J%|\u0001NeY?eMTT\u001d(u\u0011>";
      A[96] = "\u0000NUO\u001c\\AW_\n \u0003QOD\u0017L1\u0006\b\u001fI\u0010f\u0001AYJ\\\u0001\rK\u001aJ ";
      A[97] = "fw\n0\u001b\u0014?pPAK.-2\u001b/IO#q\f0 \u0017/#\u0007y\u0011Bf=\bA";
      A[98] = "\u0006JdO}?\u000f\u001b,_\u00050\u0013Y=Si\u0002G\u0014f\u000f=UGW1Y=d\u0012\u001e/V\u0005";
      A[99] = "G2\u00119[a\u0006+\u001b|g>\u00163\u0000a\u000b\fAt[?X[F=\u001d<\u001b<J7^<g";
      A[100] = "s\u000bUlXn(\u001a\ff*>}\u001ef\u0019`Q*\u001cY(C?.\\E0*";
      A[101] = "r\u000b,q$\f.Ph2_\fpF9w2$\u0017\u0003\"g2N&Vky=vr\u000b,q$\f.Ph2_";
      A[102] = "O+rZQ\u0012\u0016,(+\u0006(\u0004ncE\u0003I\n-tZj\u0011\u0006\u007f\u007f\u0013[DOap+";
      A[103] = "\"x\u0013p}k23\u0006*G\"@?\ng}/'3\u0000$}";
      A[104] = "\u0011-!37\u0004H*{Bn>Zh0,e_T+'3\f_\u0012lx{5CZ\u007f$B";
      A[105] = "\u0013f{\r?\u001bJa!|g!X#j\u0012m@V`}\r\u0004@\u0010'\"E=\\X4~|";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = A[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(B[var4]);
            A[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            A[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  A[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1231703264278497L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = A[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = B[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  A[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1231703264278497L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        A[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1231703264278497L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 240;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 251;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 229;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 239;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 112;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 192;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 240;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 251;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 229;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fx_C0318",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
