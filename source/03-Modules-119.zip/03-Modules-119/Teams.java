package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.CharacterVisitor;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;

public class Teams extends Module {
   private static volatile Set a = new HashSet();
   private static final long k = 124006223302374L;
   private static final Object[] l = new Object[41];
   private static final String[] m = new String[41];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public static boolean aReturningBoolean(Object[] var0) {
      String var3 = (String)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 124006223302374L ^ var1;
      int var27 = Event.bReturningInt();
      Set var7 = a;
      Iterator var5 = var7.iterator();
      int var4 = var27;

      byte var18;
      while (true) {
         Iterator var8 = var5;
         boolean var19 = var8.hasNext();
         if (var19) {
            Iterator var9 = var5;
            PlayerEntity var6 = (PlayerEntity)var9.next();
            PlayerEntity var10 = var6;
            Text var11 = var10.getName();
            String var28 = var11.getString();
            String var13 = var3;
            String var12 = var28;
            byte var29 = ((byte)((var12.equals(var13)) ? 1 : 0));
            int var21 = var4;
            byte var20 = var29;
            var18 = var20;
            byte var14 = var20;
            if (var21 != 0) {
               break;
            }

            int var23 = var4;
            byte var22 = var14;
            byte var17 = var22;
            byte var15 = var22;
            if (var23 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var17);
            }

            byte var24 = var15;
            byte var16 = var24;
            byte var25 = var16;
            if (var25 != 0) {
               var17 = 1;
               return dev.prestige.recovery.SourceSupport.asBoolean(var17);
            }

            int var26 = var4;
            if (var26 == 0) {
               continue;
            }
         }

         var18 = 0;
         break;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var18);
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      a = new HashSet();
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      a = new HashSet();
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 115883039051416L ^ 92665125196423L;
      int var10000 = Event.cReturningInt();
      HashSet var7 = new HashSet();
      int var6 = var10000;
      MinecraftClient var10 = b;
      ClientWorld var11 = var10.world;
      List var12 = var11.getPlayers();
      Iterator var8 = var12.iterator();

      while (true) {
         Iterator var13 = var8;
         boolean var25 = var13.hasNext();
         if (var25) {
            Iterator var14 = var8;
            PlayerEntity var9 = (PlayerEntity)var14.next();
            int var26 = var6;
            if (var26 == 0) {
               break;
            }

            MinecraftClient var15 = b;
            ClientPlayerEntity var28 = var15.player;
            PlayerEntity var27 = var9;
            if (var27 == var28) {
               int var29 = var6;
               if (var29 != 0) {
                  continue;
               }
            }

            Object[] var19 = new Object[]{var9, 67217727036447L};
            Teams var18 = this;
            boolean var35 = var18.dReturningBoolean(var19);
            int var31 = var6;
            boolean var30 = var35;
            boolean var23 = var30;
            if (var31 != 0) {
               boolean var32 = var23;
               if (var32) {
                  PlayerEntity var22 = var9;
                  HashSet var21 = var7;
                  boolean var33 = var21.add(var22);
               }
            }

            int var34 = var6;
            if (var34 != 0) {
               continue;
            }
         }

         a = var7;
         break;
      }
   }

   private boolean dReturningBoolean(Object[] var1) {
      PlayerEntity var2 = (PlayerEntity)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 124006223302374L ^ var3;
      boolean[] var5 = new boolean[]{false};
      PlayerEntity var6 = var2;
      Text var7 = var6.getDisplayName();
      OrderedText var10 = var7.asOrderedText();
      CharacterVisitor var9 = invokeBinding1(var5);
      OrderedText var8 = var10;
      var8.accept(var9);
      return var5[0];
   }

   private static boolean lambda$matchesLocalColor$1(boolean[] var0, int var1, Style var2, int var3) {
      MinecraftClient var6 = b;
      ClientPlayerEntity var7 = var6.player;
      Text var8 = var7.getDisplayName();
      OrderedText var10000 = var8.asOrderedText();
      CharacterVisitor var10 = invokeBinding2(var2, var0);
      OrderedText var9 = var10000;
      var9.accept(var10);
      return false;
   }

   private static boolean lambda$matchesLocalColor$0(Style var0, boolean[] var1, int var2, Style var3, int var4) {
      int var7 = Event.bReturningInt();
      int var28 = var7;
      Style var27 = var3;
      Style var20 = var27;
      Style var19 = var27;
      if (var28 == 0) {
         Style var29 = var19;
         if (var29 == null) {
            return false;
         }

         var20 = var3;
      }

      Style var9 = var20;
      TextColor var10000 = var9.getColor();
      int var31 = var7;
      TextColor var30 = var10000;
      TextColor var22 = var30;
      TextColor var21 = var30;
      if (var31 == 0) {
         TextColor var32 = var21;
         if (var32 == null) {
            return false;
         }

         Style var11 = var0;
         TextColor var33 = var11.getColor();
         var22 = var33;
      }

      int var35 = var7;
      TextColor var34 = var22;
      TextColor var24 = var34;
      TextColor var23 = var34;
      if (var35 == 0) {
         TextColor var36 = var23;
         if (var36 == null) {
            return false;
         }

         Style var14 = var0;
         TextColor var37 = var14.getColor();
         var24 = var37;
      }

      Style var16 = var3;
      TextColor var18 = var16.getColor();
      TextColor var17 = var24;
      boolean var41 = var17.equals(var18);
      int var39 = var7;
      boolean var38 = var41;
      boolean var26 = var38;
      boolean var25 = var38;
      if (var39 != 0) {
         return var26;
      }

      boolean var40 = var25;
      if (var40) {
         var1[0] = dev.prestige.recovery.SourceSupport.asBoolean(1);
      }

      return false;
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 63;
            yield var16;
         }
         case 2 -> {
            byte var17 = 34;
            yield var17;
         }
         case 3 -> {
            byte var18 = 19;
            yield var18;
         }
         case 4 -> {
            byte var19 = 26;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 17;
            yield var21;
         }
         case 7 -> {
            byte var22 = 30;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 2;
            yield var24;
         }
         case 10 -> {
            byte var25 = 53;
            yield var25;
         }
         case 11 -> {
            byte var26 = 8;
            yield var26;
         }
         case 12 -> {
            byte var27 = 47;
            yield var27;
         }
         case 13 -> {
            byte var28 = 52;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 42;
            yield var30;
         }
         case 16 -> {
            byte var31 = 21;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 16;
            yield var33;
         }
         case 19 -> {
            byte var34 = 60;
            yield var34;
         }
         case 20 -> {
            byte var35 = 4;
            yield var35;
         }
         case 21 -> {
            byte var36 = 36;
            yield var36;
         }
         case 22 -> {
            byte var37 = 28;
            yield var37;
         }
         case 23 -> {
            byte var38 = 40;
            yield var38;
         }
         case 24 -> {
            byte var39 = 23;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 39;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 14;
            yield var44;
         }
         case 30 -> {
            byte var45 = 3;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 10;
            yield var47;
         }
         case 33 -> {
            byte var48 = 22;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 59;
            yield var50;
         }
         case 36 -> {
            byte var51 = 62;
            yield var51;
         }
         case 37 -> {
            byte var52 = 61;
            yield var52;
         }
         case 38 -> {
            byte var53 = 45;
            yield var53;
         }
         case 39 -> {
            byte var54 = 54;
            yield var54;
         }
         case 40 -> {
            byte var55 = 35;
            yield var55;
         }
         case 41 -> {
            byte var56 = 51;
            yield var56;
         }
         case 42 -> {
            byte var57 = 41;
            yield var57;
         }
         case 43 -> {
            byte var58 = 27;
            yield var58;
         }
         case 44 -> {
            byte var59 = 13;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 58;
            yield var62;
         }
         case 48 -> {
            byte var63 = 37;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 38;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 9;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 55;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 31;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 44;
            yield var74;
         }
         case 60 -> {
            byte var75 = 48;
            yield var75;
         }
         case 61 -> {
            byte var76 = 25;
            yield var76;
         }
         case 62 -> {
            byte var77 = 15;
            yield var77;
         }
         default -> 5;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u0012[/|\f^\u0012[8 \u0000Q\b\u00108>\u0000D\u000fanfY\u0006";
      l[1] = "d5<A\u0012Yd5+\u001d\u001eV~~+\u0003\u001eCy\u000f}]M\u0004";
      l[2] = boolean.class;
      m[2] = "java/lang/Boolean";
      l[3] = "Bc%p\u001f,Bc2,\u0013#X(22\u00136_YckDt";
      l[4] = "zEvRE\u0011zEa\u000eI\u001e`\u000ea\u0010I\u000bg\u007f3J\u001dO";
      l[5] = "\u001atRG\u0003Y\u001atE\u001b\u000fV\u0000?E\u0005\u000fC\u0007N\u0014\\V\u0003";
      l[6] = "<Dv1X=<DamT2&\u000fasT'!~7-\u0000e";
      l[7] = "\u001f3 IC\u000f\t3%\u0013P\u0018\u001ex&\u0015\\\f\u000f?1\u0002\u0017\u001e>";
      l[8] = int.class;
      m[8] = "java/lang/Integer";
      l[9] = "\u0004g\"1f\f\u0012g'ku\u001b\u0005,$my\u000f\u0014k3z2\u001a\u0019";
      l[10] = "\u0001\u0010\u0013$f`\n\u001f\u0002k\u0005m\u001f\u0012\r\u00000o\u000e\u0001\u0011,'b";
      l[11] = "ROWcO\u0000Y@F,.\u000eRKBv";
      l[12] = "\r5]'\u001cV\u0006:LhaN\u0015=E!";
      l[13] = "t\u0007%{O#j\u000f?423j";
      l[14] = "Xf\u0017F%aFn\r\tB`Wu\u0000Sdf";
      l[15] = "VL5\u0005G^VL\"YKQL\u0007\"GKDKvv\u001f\u001c";
      l[16] = "I%\rV9(I%\u001a\n5'Sn\u001a\u001452T\u001fJId";
      l[17] = "y2$S\u0006!y23\u000f\n.cy3\u0011\n;d\bfNS";
      l[18] = "\u0003EI\u0005,\b\u001dMSJN\u0014\u001aP";
      l[19] = "Z(gFt\u001d/\blIeRN\u0006gBa\b:";
      l[20] = "&\b@\r\u00119xD\u001a\u0017, p\u0006K\u0011@\u0012$B\u001aI\u0017E!\u0002IJ\u0012t%\u0004L\u0016,";
      l[21] = "/{k\u0016l\u0003?)h\u000eS\t)m5\u0016?;}!iLml/h0Ln\u0000=n;\u001cS";
      l[22] = "1\u0015(\u000f;~b\u0014/V\u000bj\rWs\u0003bd7\u0007qCb\u0000";
      l[23] = "\u001b.~.znMtliK;R3w40V\u0014<n135Y0 lKoLsr/,hP$sP";
      l[24] = "?'$\u001aB>}u!\u001d{=\u0001!v[\u000bh{tz\u0006\u0017Q8*z\r\u00046?6-\f{";
      l[25] = "\u001f\u0001\u0002+nC\u0015\u001a\u0003G6LO\f\u0003;_^V\u0002\u0019}0M[\u001d{~8\u001aH\u001e\u001cy$MIa";
      l[26] = "V\u000bMX\u007f\u0007\u0005\u001c\u001bP\u000f\u000e\u0001\u000fA\\c<WK\u0010\u00000kW\u0013XW>\u000f]\bY;";
      l[27] = "X7|]i2\re~\u0010\f8\u00155~\tp>\u0013XmYah\ncf\\n$i";
      l[28] = "jrpZ\u0005\u000ext{\n8\u0003}fo\u000eD\u0005{\u000b|^USb0w[Z\u001f\u0001";
      l[29] = "fDRC\u0010&5EU\u001a 3Z\u0006\tOI<`V\u000b\u000fIX";
      l[30] = "19\u0005\u0006Ppc \u0006\f`.5'\u0017\u000f\f\u001cegHV`q 7\u0014\u0018\f\"7a\u001ch";
      l[31] = "\u0017K\u000f>\u001ajB\u0019\rs\u007fhJHw<\rqG\\\u0014q\u0001?\u001a$NdBmYCIx\u0015l&";
      l[32] = "Kv\u0013Jt]Nu\u0002\n\u001bW@&\bZL\u0000\u001f{S6pS\u001f,SY`\u0001\u001c4";
      l[33] = ";\u001c7+.q0\u00198gM,?U&\u001ar8\"D\"y?4l\u0019Z";
      l[34] = "x^\u007fA/u+I)I_v/ZH^%x$I\u0013\u0012?y<\u0017+Dek{&";
      l[35] = "n\fOU\fMk\u000f^\u0015cGe\\TE4\u0010;\u000b\f)\nKv_\u0000\u0012XRuU";
      l[36] = "cW\u007f!\u0005shRpmf(c\u0015T}\u00164\nWu-\n7mPiz\u000bH";
      l[37] = "\t\u0016j]u5XUk\u0019E=^\u0014i\u0003)\u000f\u000eT6ZEbK\u0004j\u0014)1\\Rbd";
      l[38] = "\u001eL\tZG\u0018O\u000f\b\u001ew\u0010IN\n\u0004\u001b\"\u0019\u000eU\\wO\\^\t\u0013\u001b\u001cK\b\u0001c";
      l[39] = "CF\u0018x5,\u0001\u0014\u001d\u007f\f*}\u0013\u0019gp?\u0012I\u001a\u007f=CBN\u001f\u007fp,\u0018M\u00072\f";
      l[40] = "\u001fa\t R\u001e\u001bg\f|lBZd\u0002x\u0017/\u001ck\u001b}\u0014LQgU l\u0016D$\u0007c\u000b\u0011Xs\u0006\u001c";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(812285289857164L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(812285289857164L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(812285289857164L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 99;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 111;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 199;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 105;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 181;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 84;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 99;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 111;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 199;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fy_C0320",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fy" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static CharacterVisitor invokeBinding1(boolean[] var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("([Z)Lnet/minecraft/text/CharacterVisitor;", MethodHandles.lookup()),
                  SourceSupport.methodType("(ILnet/minecraft/text/Style;I)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fy_C0320", "lambda$matchesLocalColor$1", "([ZILnet/minecraft/text/Style;I)Z"
                  ),
                  SourceSupport.methodType("(ILnet/minecraft/text/Style;I)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (CharacterVisitor)var2.invokeExact((boolean[])var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static CharacterVisitor invokeBinding2(Style var0, boolean[] var1) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Lnet/minecraft/text/Style;[Z)Lnet/minecraft/text/CharacterVisitor;", MethodHandles.lookup()),
                  SourceSupport.methodType("(ILnet/minecraft/text/Style;I)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/fy_C0320",
                     "lambda$matchesLocalColor$0",
                     "(Lnet/minecraft/text/Style;[ZILnet/minecraft/text/Style;I)Z"
                  ),
                  SourceSupport.methodType("(ILnet/minecraft/text/Style;I)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (CharacterVisitor)var3.invokeExact((Style)var0, (boolean[])var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
