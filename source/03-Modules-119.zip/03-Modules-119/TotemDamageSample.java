package dev.zprestige.prestige.client.modules.state;

public final class TotemDamageSample {
   private long a;
   private float b;

   public TotemDamageSample(long var1, float var3) {
      this.a = var1;
      this.b = var3;
   }

    public final long recoveryAccess_read_a() { return this.a; }

    public final float recoveryAccess_read_b() { return this.b; }
}
