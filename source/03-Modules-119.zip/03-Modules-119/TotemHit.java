package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public class TotemHit extends Module {
   private static final long k = 109985150482545L;
   private static final long l;
   private static final Object[] m = new Object[38];
   private static final String[] n = new String[38];
   private static volatile MethodHandle bindingCache1;

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 94197895555811L ^ 30566841584111L;
      var10001 = 94197895555811L ^ 74880959149407L;
      int var10000 = Event.bReturningInt();
      Object[] var13 = new Object[0];
      AttackEntityEvent var12 = var1;
      Entity var9 = var12.aReturningEntity(var13);
      int var8 = var10000;
      int var41 = var8;
      Entity var40 = var9;
      Entity var34 = var40;
      Entity var33 = var40;
      if (var41 == 0) {
         Entity var42 = var33;
         if (var42 == null) {
            return;
         }

         var34 = var9;
      }

      boolean var43 = var34 instanceof PlayerEntity;
      if (var43) {
         MinecraftClient var16 = b;
         ClientPlayerEntity var17 = var16.player;
         ItemStack var18 = var17.getMainHandStack();
         Item var56 = var18.getItem();
         Item var45 = Items.TOTEM_OF_UNDYING;
         Item var44 = var56;
         if (var44 == var45) {
            Integer var10 = null;
            while (true) {
               int var47 = (int)l;
               int var46 = var11;
               if (var46 > var47) {
                  break;
               }

               int var48 = var8;
               if (var48 != 0) {
                  return;
               }

               MinecraftClient var20 = b;
               ClientPlayerEntity var21 = var20.player;
               PlayerInventory var57 = var21.getInventory();
               int var23 = var11;
               PlayerInventory var22 = var57;
               Object[] var24 = new Object[]{var22.getStack(var23), 19476550655932L};
               byte var58 = ((byte)((InventoryUtil.aReturningBoolean(var24)) ? 1 : 0));
               int var50 = var8;
               byte var49 = var58;
               int var37 = var49;
               byte var35 = var49;
               if (var50 == 0) {
                  byte var51 = var35;
                  byte var36 = var51;
                  byte var52 = var36;
                  if (var52 == 0) {
                     var11++;
                     continue;
                  }

                  var37 = var11;
               }

               int var27 = var37;
               var10 = var27;
               break;
            }

            int var54 = var8;
            Integer var53 = var10;
            Integer var39 = var53;
            Integer var38 = var53;
            if (var54 == 0) {
               Integer var55 = var38;
               if (var55 == null) {
                  return;
               }

               Object[] var30 = new Object[0];
               AttackEntityEvent var29 = var1;
               var29.aReturningVoid(var30);
               var39 = var10;
            }

            Integer var31 = var39;
            var10000 = var31;
            Runnable var61 = invokeBinding1(var1);
            Object[] var10005 = new Object[]{null, null, null, 86177674060556L};
            var10005[2] = true;
            var10005[1] = var61;
            var10005[0] = var10000;
            Object[] var32 = var10005;
            InventoryUtil.bReturningVoid(var32);
         }
      }
   }

   private static void lambda$onAttackEntity$0(AttackEntityEvent var0) {
      long var10001 = 88445533163814L ^ 61144098498254L;
      Object[] var6 = new Object[0];
      AttackEntityEvent var5 = var0;
      Object[] var7 = new Object[]{var5.aReturningEntity(var6), 114267283224552L};
      ItemUseUtil.aReturningVoid(var7);
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(64457672436504L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -3000544153783955309L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)214L,
            (byte)54875L,
            (byte)14048236L,
            (byte)3596348669L,
            (byte)920665259356L,
            (byte)235690306395349L,
            (byte)60336718437209360L,
            (byte)-3000544153783955309L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 16;
            yield var15;
         }
         case 1 -> {
            byte var16 = 10;
            yield var16;
         }
         case 2 -> {
            byte var17 = 11;
            yield var17;
         }
         case 3 -> {
            byte var18 = 34;
            yield var18;
         }
         case 4 -> {
            byte var19 = 17;
            yield var19;
         }
         case 5 -> {
            byte var20 = 9;
            yield var20;
         }
         case 6 -> {
            byte var21 = 52;
            yield var21;
         }
         case 7 -> {
            byte var22 = 54;
            yield var22;
         }
         case 8 -> {
            byte var23 = 48;
            yield var23;
         }
         case 9 -> {
            byte var24 = 6;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 49;
            yield var26;
         }
         case 12 -> {
            byte var27 = 35;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 55;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 39;
            yield var32;
         }
         case 18 -> {
            byte var33 = 59;
            yield var33;
         }
         case 19 -> {
            byte var34 = 60;
            yield var34;
         }
         case 20 -> {
            byte var35 = 27;
            yield var35;
         }
         case 21 -> {
            byte var36 = 50;
            yield var36;
         }
         case 22 -> {
            byte var37 = 5;
            yield var37;
         }
         case 23 -> {
            byte var38 = 45;
            yield var38;
         }
         case 24 -> {
            byte var39 = 14;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 3;
            yield var42;
         }
         case 28 -> {
            byte var43 = 1;
            yield var43;
         }
         case 29 -> {
            byte var44 = 20;
            yield var44;
         }
         case 30 -> {
            byte var45 = 56;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 47;
            yield var47;
         }
         case 33 -> {
            byte var48 = 61;
            yield var48;
         }
         case 34 -> {
            byte var49 = 51;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 29;
            yield var51;
         }
         case 37 -> {
            byte var52 = 22;
            yield var52;
         }
         case 38 -> {
            byte var53 = 36;
            yield var53;
         }
         case 39 -> {
            byte var54 = 38;
            yield var54;
         }
         case 40 -> {
            byte var55 = 30;
            yield var55;
         }
         case 41 -> {
            byte var56 = 57;
            yield var56;
         }
         case 42 -> {
            byte var57 = 7;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 24;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 33;
            yield var61;
         }
         case 47 -> {
            byte var62 = 18;
            yield var62;
         }
         case 48 -> {
            byte var63 = 2;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 28;
            yield var65;
         }
         case 51 -> {
            byte var66 = 8;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 32;
            yield var68;
         }
         case 54 -> {
            byte var69 = 4;
            yield var69;
         }
         case 55 -> {
            byte var70 = 53;
            yield var70;
         }
         case 56 -> {
            byte var71 = 21;
            yield var71;
         }
         case 57 -> {
            byte var72 = 15;
            yield var72;
         }
         case 58 -> {
            byte var73 = 19;
            yield var73;
         }
         case 59 -> {
            byte var74 = 23;
            yield var74;
         }
         case 60 -> {
            byte var75 = 62;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 44;
            yield var77;
         }
         default -> 31;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "p\u001c 6/x{\u00131yHzn\u001812s";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "\u000fX90' \u0019X<j47\u000e\u0013?l8#\u001fT({s1.";
      m[3] = "]k1)\u0004F]k&u\bIG &k\b\\@Qr3_";
      m[4] = "<)f,\\\u0010<)qpP\u001f&bqnP\n!\u0013#4\u0007H";
      m[5] = "s\tw52Ns\t`i>AiB`w>Tn32,f\u001e";
      m[6] = "\u000eL,-\u0011\u001f\u000eL;q\u001d\u0010\u0014\u0007;o\u001d\u0005\u0013vi4ED";
      m[7] = "9\u007fHuRT/\u007fM/AC84N)MW)sY>\u0006B\u001c";
      m[8] = "%nz=w\u001f.akr\u0014\u0012;ld\u0019!\u0010*\u007fx56\u001d";
      m[9] = "7F4U$\u00167F#\t(\u0019-\r#\u0017(\f*|qCyM";
      m[10] = "mW\u0000x*\u0017{W\u0005\"9\u0000l\u001c\u0006$5\u0014}[\u00113~\u0004f";
      m[11] = "53P6o'@\u0013[9~h!\u001dP2z2U";
      m[12] = void.class;
      n[12] = "java/lang/Void";
      m[13] = "<QF)=u*QCs.b=\u001a@u\"v,]Wbid\u0010";
      m[14] = "cB>\u000b4\u001f\u0016b5\u0004%Pwl>\u000f!\n\u0003";
      m[15] = "FEYLLzFEN\u0010@u\\\u000eN\u000e@`[\u007f\u001cP\u0018$";
      m[16] = "!( \f\u0004\u000b!(7P\b\u0004;c7N\b\u0011<\u0012g\u0013Y";
      m[17] = "\u0007X.C`^rx%Lq\u0011\u0013v.GuKg";
      m[18] = "^FYf6\u0013+fRi'\\JhYb#\u0006>";
      m[19] = boolean.class;
      n[19] = "java/lang/Boolean";
      m[20] = "r'\u0007&,fd'\u0002|?qsl\u0001z3eb+\u0016mxuz";
      m[21] = "i#srn\u0001\u001c\u0003x}\u007fN}\rsv{\u0014\t";
      m[22] = "pM14\u0005\u000f{B {d\u0001pI$!";
      m[23] = "F\u001f\u0001A1tFO\u000f.2e\u0012]\u001ei\"\fO\u0018\u000e\u0012rh\rG\u001cDL<IR\u001cS4<\u0019\\s";
      m[24] = "\u0017]D^{RP\u001c\u0018_\u001e].\u001f\u0010\u0013\"\tJ]O\u0001t7";
      m[25] = "\u001b0\u0014F\b\r\\\"\bPxQL'\t]\u0014c\u001abT\u0006H4\u001a5X]\u0005^\u0019 \u000eUx";
      m[26] = "Xa\u0018onz\u0005i\u001e\u007fV$\u000ed\u0018w:\u0016\\)@!V}\u0019#\u001em91Z}\u0015\u0010";
      m[27] = "Q][A}g\\\bH\u0000\u001dvlXNC%'\u0001\u0019SE,\u001fQ\u0000\u0014D%r\u0010\u001d\u0012M\u001d";
      m[28] = "\rYUSp\u0017JKIE\u0000KZNHHly\t\n\u0014\u0010\u0000\u0015NRW\u0017;HFTG/";
      m[29] = "[Q'\u000bRP\u0001\u0001:X,\u0000\u0004V=]{^_\u000bi1\u0010\u0014^]$^\\W\u0000V";
      m[30] = "\u000b,/R\u001e{H0.B|~4!#\u0006\u0002+\b/,B\u001d\u0014\u0004*4\r\u001a{\u000e%>\u0005|";
      m[31] = "\u0011C\u0010%}:X@\b\"\u001b) C\u0004 e\u007f\u001cM\u000bdz@IL\u001a&*=A\u0010\rx\u001b";
      m[32] = "?V}\u001f\u0001\u001d<C+\u0017|\u0012iD,\u001f\u0010 9\u0004wH|N<EpF\u0018\fcW&xG\u000edGtC\u001a\u0006bWL";
      m[33] = "?c\u001b~{*\"1\u00002\u001a.Rc\u0002tdxnm\r0{Gbh\u0015\u007f|(hg\u001fw\u001a";
      m[34] = "}\u00109cw}}@7\fkc1q\"hwhM\u0016sq6;)T,c`\u0005";
      m[35] = "\u0015-c+\u0010%F%g>| \u001e+g#+w@|?OF%\u0002:sv\u00017\u001e,";
      m[36] = "9rJR3\u0016~3\u0016SV\u001a\u0000dVX(L<jY\u001c7s0oAS0\u001c:`K[V";
      m[37] = "\u0001,aj\f0B0`zn6>!m>\u0010`\u0002/bz\u000f_Rs|`R&\u000f dan";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1563112213570301L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1563112213570301L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1563112213570301L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 186;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 217;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 211;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 97;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 243;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 186;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 217;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 211;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fA_C0271",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fA" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(AttackEntityEvent var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/aH_C0017;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fA_C0271", "lambda$onAttackEntity$0", "(Ldev/zprestige/prestige/aH_C0017;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((AttackEntityEvent)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
