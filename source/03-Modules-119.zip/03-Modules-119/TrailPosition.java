package dev.zprestige.prestige.client.modules.state;

import net.minecraft.util.math.Vec3d;

public class TrailPosition {
   public Vec3d a;
   public boolean b = dev.prestige.recovery.SourceSupport.asBoolean(1);

   public TrailPosition() {
   }
}
