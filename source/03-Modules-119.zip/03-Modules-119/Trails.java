package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.client.modules.state.TrailPosition;
import dev.zprestige.prestige.client.modules.state.TrailPoint;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3d;

public class Trails extends Module {
   private BooleanSetting d;
   private ModeSetting a;
   private IntSetting c;
   private FloatSetting e;
   private BooleanSetting f;
   private ColorSetting g;
   private static ManagedGlTexture h;
   private static final int i;
   private Map j;
   private List k;
   private static final long l = 16167928597977L;
   private static final String[] m;
   private static final String[] n;
   private static final Map o = new HashMap(13);
   private static final long[] p;
   private static final Integer[] q;
   private static final Map r;
   private static final Object[] s = new Object[135];
   private static final String[] t = new String[135];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public Trails() {
      super();
      long var10001 = 85324462141622L ^ 114513082528758L;

      this.j = new HashMap();
      this.k = new ArrayList();
      ColorSetting var10000 = this.g;
      Object[] var6 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var5 = var10000;
      var5.aReturningColorSetting(var6);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 94559546467275L ^ 84293895037832L;
      int var6 = Event.bReturningInt();
      int var207 = var6;
      MinecraftClient var206 = b;
      MinecraftClient var136 = var206;
      MinecraftClient var135 = var206;
      if (var207 == 0) {
         MinecraftClient var36 = var135;
         ClientWorld var208 = var36.world;
         if (var208 == null) {
            return;
         }

         MinecraftClient var209 = b;
         var136 = var209;
      }

      MinecraftClient var39 = var136;
      ClientPlayerEntity var210 = var39.player;
      if (var210 != null) {
         HashSet var7;
         String var8;
         int var144;
         var7 = new HashSet();
         ModeSetting var41 = this.a;
         var8 = (String)var41.aReturningObject();
         String var11 = var8;
         
         int var10000 = var42.hashCode();
         int var212 = var6;
         int var211 = var10000;
         var144 = var211;
         int var137 = var211;
         label212:
         if (var212 == 0) {
            int var213 = var137;
            switch (var213) {
               case 203653773:
                  String var45 = "Particles";
                  String var44 = var11;
                  byte var317 = ((byte)((var44.equals(var45)) ? 1 : 0));
                  int var215 = var6;
                  byte var214 = var317;
                  var144 = var214;
                  byte var138 = var214;
                  if (var215 != 0) {
                     break label212;
                  }

                  byte var216 = var138;
                  byte var139 = var216;
                  byte var217 = var139;
                  if (var217 == 0) {
                     break;
                  }

                  var12 = 0;
                  int var218 = var6;
                  if (var218 == 0) {
                     break;
                  }
               case 2547280:
                  String var49 = "Ring";
                  String var48 = var11;
                  byte var318 = ((byte)((var48.equals(var49)) ? 1 : 0));
                  int var220 = var6;
                  byte var219 = var318;
                  var144 = var219;
                  byte var140 = var219;
                  if (var220 != 0) {
                     break label212;
                  }

                  byte var221 = var140;
                  byte var141 = var221;
                  byte var222 = var141;
                  if (var222 == 0) {
                     break;
                  }

                  var12 = 1;
                  int var223 = var6;
                  if (var223 == 0) {
                     break;
                  }
               case 1370061657:
                  String var53 = "Footsteps";
                  String var52 = var11;
                  byte var319 = ((byte)((var52.equals(var53)) ? 1 : 0));
                  int var225 = var6;
                  byte var224 = var319;
                  var144 = var224;
                  byte var142 = var224;
                  if (var225 != 0) {
                     break label212;
                  }

                  byte var226 = var142;
                  byte var143 = var226;
                  byte var227 = var143;
                  if (var227 != 0) {
                     var12 = 2;
                  }
            }

            var144 = var12;
         }

         int var228 = var144;

         double var9 = switch (var228) {
            case 0 -> {
               double var229 = 0.25;
               yield var229;
            }
            case 1 -> {
               double var231 = 0.65;
               yield var231;
            }
            case 2 -> {
               double var233 = 0.75;
               yield var233;
            }
            default -> 0.5;
         };
         IntSetting var57 = this.c;
         Integer var58 = (Integer)var57.aReturningObject();
         int var311 = var58;
         MinecraftClient var59 = b;
         ClientWorld var60 = var59.world;
         List var61 = var60.getPlayers();
         Iterator var312 = var61.iterator();

         while (true) {
            Iterator var62 = var312;
            boolean var235 = var62.hasNext();
            if (var235) {
               Iterator var63 = var312;
               PlayerEntity var13 = (PlayerEntity)var63.next();
               PlayerEntity var64 = var13;
               int var14 = var64.getId();
               int var65 = var14;
               Integer var67 = var65;
               HashSet var66 = var7;
               var66.add(var67);
               BooleanSetting var68 = this.d;
               Boolean var69 = (Boolean)var68.aReturningObject();
               int var320 = ((((java.lang.Boolean)(var69)).booleanValue() ? 1 : 0));
               int var237 = var6;
               boolean var236 = dev.prestige.recovery.SourceSupport.asBoolean(var320);
               boolean var147 = var236;
               if (var237 != 0) {
                  break;
               }

               Object var155;
               label225: {
                  int var239 = var6;
                  boolean var238 = var147;
                  boolean var154 = var238;
                  boolean var148 = var238;
                  if (var239 == 0) {
                     PlayerEntity var152;
                     label184: {
                        boolean var240 = var148;
                        boolean var149 = var240;
                        boolean var241 = var149;
                        if (var241) {
                           int var243 = var6;
                           PlayerEntity var242 = var13;
                           var152 = var242;
                           PlayerEntity var150 = var242;
                           if (var243 != 0) {
                              break label184;
                           }

                           PlayerEntity var244 = var150;
                           PlayerEntity var151 = var244;
                           MinecraftClient var73 = b;
                           ClientPlayerEntity var246 = var73.player;
                           PlayerEntity var245 = var151;
                           if (var245 != var246) {
                              continue;
                           }
                        }

                        var152 = var13;
                     }

                     int var248 = var6;
                     PlayerEntity var247 = var152;
                     var155 = var247;
                     PlayerEntity var153 = var247;
                     if (var248 != 0) {
                        break label225;
                     }

                     PlayerEntity var76 = var153;
                     boolean var249 = var76.isOnGround();
                     var154 = var249;
                  }

                  boolean var250 = var154;
                  if (!var250) {
                     continue;
                  }

                  Map var321 = this.j;
                  int var78 = var14;
                  Integer var80 = var78;
                  Map var79 = var321;
                  var155 = var79.get(var80);
               }

               TrailPosition var15;
               Vec3d var16;
               label175: {
                  var15 = (TrailPosition)var155;
                  PlayerEntity var81 = var13;
                  double var10002 = var81.getX();
                  PlayerEntity var82 = var13;
                  double var10003 = var82.getY();
                  PlayerEntity var83 = var13;
                  var16 = new Vec3d(var10002, var10003, var83.getZ());
                  int var252 = var6;
                  TrailPosition var251 = var15;
                  TrailPosition var156 = var251;
                  if (var252 == 0) {
                     TrailPosition var253 = var156;
                     if (var253 != null) {
                        break label175;
                     }

                     var15 = new TrailPosition();
                     var15.a = var16;
                     Map var322 = this.j;
                     int var85 = var14;
                     Integer var332 = var85;
                     TrailPosition var88 = var15;
                     Integer var87 = var332;
                     Map var86 = var322;
                     Object var157 = var86.put(var87, var88);
                  }

                  int var254 = var6;
                  if (var254 == 0) {
                     continue;
                  }
               }

               Vec3d var89 = var16;
               Vec3d var90 = var15.a;
               double var17 = var89.x - var90.x;
               Vec3d var91 = var16;
               Vec3d var92 = var15.a;
               double var19 = var91.z - var92.z;
               double var93 = var17 * var17 + var19 * var19;
               double var21 = Math.sqrt(var93);
               double var336;
               int var255 = (var336 = var21 - var9) == 0.0 ? 0 : (var336 < 0.0 ? -1 : 1);
               if (var255 < 0) {
                  continue;
               }

               float var23;
               int var163;
               PlayerEntity var96 = var13;
               var23 = var96.getYaw();
               String var24 = var8;
               
               var320 = var97.hashCode();
               int var257 = var6;
               int var256 = var320;
               var163 = var256;
               int var158 = var256;
               label159:
               if (var257 == 0) {
                  int var258 = var158;
                  switch (var258) {
                     case 1370061657:
                        String var100 = "Footsteps";
                        String var99 = var24;
                        byte var324 = ((byte)((var99.equals(var100)) ? 1 : 0));
                        int var260 = var6;
                        byte var259 = var324;
                        var163 = var259;
                        byte var159 = var259;
                        if (var260 != 0) {
                           break label159;
                        }

                        byte var261 = var159;
                        byte var160 = var261;
                        byte var262 = var160;
                        if (var262 == 0) {
                           break;
                        }

                        var25 = 0;
                        int var263 = var6;
                        if (var263 == 0) {
                           break;
                        }
                     case 203653773:
                        String var104 = "Particles";
                        String var103 = var24;
                        byte var325 = ((byte)((var103.equals(var104)) ? 1 : 0));
                        int var265 = var6;
                        byte var264 = var325;
                        var163 = var264;
                        byte var161 = var264;
                        if (var265 != 0) {
                           break label159;
                        }

                        byte var266 = var161;
                        byte var162 = var266;
                        byte var267 = var162;
                        if (var267 != 0) {
                           var25 = 1;
                        }
                  }

                  var163 = var25;
               }

               label234: {
                  int var269 = var6;
                  int var268 = var163;
                  int var164 = var268;
                  label151:
                  if (var269 == 0) {
                     int var270 = var164;
                     switch (var270) {
                        case 0:
                           byte var26;
                           double var27;
                           double var29;
                           double var177;
                           byte var179;
                           label146: {
                              var26 = ((byte)((var15.b) ? 1 : 0));
                              double var108 = var23;
                              var27 = Math.toRadians(var108);
                              var29 = 0.18;
                              double var110 = var27;
                              double var326 = Math.cos(var110) * var29;
                              int var274 = var6;
                              byte var273 = var26;
                              double var271 = var326;
                              double var172 = var271;
                              byte var174 = var273;
                              double var165 = var271;
                              byte var167 = var273;
                              if (var274 == 0) {
                                 byte var277 = var167;
                                 double var275 = var165;
                                 double var175 = var275;
                                 double var168 = var275;
                                 if (var277 == 0) {
                                    var179 = 1;
                                    var177 = var175;
                                    break label146;
                                 }

                                 double var278 = var168;
                                 double var170 = var278;
                                 var174 = -1;
                                 var172 = var170;
                              }

                              byte var282 = var174;
                              double var280 = var172;
                              var177 = var280;
                              var179 = var282;
                           }

                           double var31;
                           double var192;
                           byte var194;
                           label140: {
                              var31 = var177 * var179;
                              double var113 = var27;
                              double var327 = Math.sin(var113) * var29;
                              int var286 = var6;
                              byte var285 = var26;
                              double var283 = var327;
                              double var187 = var283;
                              byte var189 = var285;
                              double var180 = var283;
                              byte var182 = var285;
                              if (var286 == 0) {
                                 byte var289 = var182;
                                 double var287 = var180;
                                 double var190 = var287;
                                 double var183 = var287;
                                 if (var289 == 0) {
                                    var194 = 1;
                                    var192 = var190;
                                    break label140;
                                 }

                                 double var290 = var183;
                                 double var185 = var290;
                                 var189 = -1;
                                 var187 = var185;
                              }

                              byte var294 = var189;
                              double var292 = var187;
                              var192 = var292;
                              var194 = var294;
                           }

                           TrailPosition var202;
                           byte var203;
                           label134: {
                              double var33 = var192 * var194;
                              Vec3d var116 = var16;
                              double var333 = var116.x + var31;
                              Vec3d var117 = var16;
                              Vec3d var118 = var16;
                              Vec3d var35 = new Vec3d(var333, var117.y, var118.z + var33);
                              List var328 = this.k;
                              TrailPoint var120 = new TrailPoint(var35, var8, var311, var23, dev.prestige.recovery.SourceSupport.asBoolean(var26), null, 29319317864515L);
                              List var119 = var328;
                              var119.add(var120);
                              int var297 = var6;
                              byte var296 = var26;
                              TrailPosition var295 = var15;
                              TrailPosition var199 = var295;
                              byte var200 = var296;
                              TrailPosition var195 = var295;
                              byte var196 = var296;
                              if (var297 == 0) {
                                 byte var299 = var196;
                                 TrailPosition var298 = var195;
                                 TrailPosition var201 = var298;
                                 TrailPosition var197 = var298;
                                 if (var299 != 0) {
                                    var203 = 0;
                                    var202 = var201;
                                    break label134;
                                 }

                                 TrailPosition var300 = var197;
                                 TrailPosition var198 = var300;
                                 var200 = 1;
                                 var199 = var198;
                              }

                              byte var302 = var200;
                              TrailPosition var301 = var199;
                              var202 = var301;
                              var203 = var302;
                           }

                           var202.b = dev.prestige.recovery.SourceSupport.asBoolean(var203);
                           int var303 = var6;
                           if (var303 == 0) {
                              break label151;
                           }
                        case 1:
                           int var307;
                           do {
                              byte var305 = 4;
                              int var304 = var313;
                              if (var304 >= var305) {
                                 break;
                              }

                              double var314 = Math.random() * Math.PI * 2.0;
                              double var315 = 0.025 + Math.random() * 0.05;
                              double var122 = var314;
                              double var334 = Math.cos(var122) * var315;
                              double var335 = 0.05 + Math.random() * 0.05;
                              double var124 = var314;
                              Vec3d var316 = new Vec3d(var334, var335, Math.sin(var124) * var315);
                              List var329 = this.k;
                              TrailPoint var127 = new TrailPoint(var16, var8, var311, var23, false, var316, 29319317864515L);
                              List var126 = var329;
                              var126.add(var127);
                              var313++;
                              int var306 = var6;
                              if (var306 != 0) {
                                 break label234;
                              }

                              var307 = var6;
                           } while (var307 == 0);

                           int var308 = var6;
                           if (var308 == 0) {
                              break label151;
                           }
                     }

                     List var330 = this.k;
                     TrailPoint var130 = new TrailPoint(var16, var8, var311, var23, false, null, 29319317864515L);
                     List var129 = var330;
                     boolean var309 = var129.add(var130);
                  }

                  var15.a = var16;
               }

               int var310 = var6;
               if (var310 == 0) {
                  continue;
               }
            }

            Map var132 = this.j;
            Set var331 = var132.keySet();
            HashSet var134 = var7;
            Set var133 = var331;
            boolean var205 = var133.retainAll(var134);
            break;
         }
      }
   }

   @EventListener
   public void a(Render3DEvent var1) {
      int var18;
      long var19;
      Color var84;
      label111: {
         Object var83;
         label114: {
            long var10001 = 60351193797376L ^ 140275951239226L;
            var10001 = 60351193797376L ^ 749735210356L;
            var10001 = 60351193797376L ^ 135320450843790L;
            var10001 = 60351193797376L ^ 57733442122034L;
            var10001 = 60351193797376L ^ 31365568856311L;
            var10001 = 60351193797376L ^ 128333909629482L;
            var10001 = 60351193797376L ^ 123031185972220L;
            int var10000 = Event.cReturningInt();
            var19 = System.currentTimeMillis();
            var18 = var10000;
            List var139 = this.k;
            Predicate var34 = invokeBinding2(var19);
            List var33 = var139;
            var33.removeIf(var34);
            List var35 = this.k;
            boolean var140 = var35.isEmpty();
            int var100 = var18;
            boolean var99 = var140;
            boolean var82 = var99;
            boolean var80 = var99;
            if (var100 != 0) {
               boolean var101 = var80;
               if (var101) {
                  return;
               }

               BooleanSetting var37 = this.f;
               Boolean var141 = (Boolean)var37.aReturningObject();
               int var103 = var18;
               Boolean var102 = var141;
               var83 = var102;
               Boolean var81 = var102;
               if (var103 == 0) {
                  break label114;
               }

               Boolean var38 = var81;
               boolean var104 = var38;
               var82 = var104;
            }

            boolean var105 = var82;
            if (var105) {
               Object[] var40 = new Object[]{2617886958130L};
               Color var106 = ClientUiUtil.dReturningColor(var40);
               var84 = var106;
               break label111;
            }

            ColorSetting var42 = this.g;
            var83 = var42.aReturningObject();
         }

         var84 = (Color)var83;
      }

      Color var21 = var84;
      Color var43 = var21;
      Color var22 = var43.darker();
      Color var44 = var21;
      Color var23 = var44.brighter();
      FloatSetting var45 = this.e;
      Float var46 = (Float)var45.aReturningObject();
      float var24 = var46;
      List var47 = this.k;
      Iterator var25 = var47.iterator();

      while (true) {
         Iterator var48 = var25;
         boolean var107 = var48.hasNext();
         if (!var107) {
            break;
         }

         TrailPoint var26;
         float var27;
         float var89;
         float var90;
         label117: {
            Iterator var49 = var25;
            var26 = (TrailPoint)var49.next();
            var27 = (float)(var19 - var26.b) / var26.c;
            float var156;
            int var142 = (var156 = var27 - 0.0F) == 0.0F ? 0 : (var156 < 0.0F ? -1 : 1);
            int var109 = var18;
            int var108 = var142;
            int var88 = var108;
            int var85 = var108;
            if (var109 != 0) {
               int var110 = var85;
               if (var110 < 0) {
                  continue;
               }

               int var113 = var18;
               float var112 = 1.0F;
               float var111 = var27;
               var89 = var111;
               var90 = var112;
               float var86 = var111;
               float var87 = var112;
               if (var113 == 0) {
                  break label117;
               }

               float var157;
               int var114 = (var157 = var86 - var87) == 0.0F ? 0 : (var157 < 0.0F ? -1 : 1);
               var88 = var114;
            }

            int var115 = var88;
            if (var115 > 0) {
               continue;
            }

            Object[] var10004 = new Object[]{null, 46614469202935L};
            var10004[0] = var27;
            Object[] var52 = var10004;
            var90 = bReturningFloat(var52);
            var89 = 1.0F;
         }

         float var28;
         Color var29;
         Color var30;
         label89: {
            var28 = var89 - var90;
            String var54 = "Footsteps";
            String var53 = var26.d;
            boolean var116 = var53.equals(var54);
            if (var116) {
               var29 = var21;
               Object[] var153 = new Object[]{null, null, 80775739953978L};
               var153[1] = 0.3F;
               var153[0] = var21;
               Object[] var55 = var153;
               var30 = bReturningColor(var55);
               int var117 = var18;
               if (var117 != 0) {
                  break label89;
               }
            }

            float var10002 = var26.i;
            Object[] var10005 = new Object[]{null, null, null, 72960932006186L};
            var10005[2] = var10002;
            var10005[1] = var23;
            var10005[0] = var22;
            Object[] var56 = var10005;
            var29 = cReturningColor(var56);
            var10005 = new Object[]{null, null, null, 72960932006186L};
            var10005[2] = 0.6F;
            var10005[1] = var23;
            var10005[0] = var29;
            Object[] var57 = var10005;
            var30 = cReturningColor(var57);
         }

         int var98;
         String var31 = var26.d;
         
         int var143 = var58.hashCode();
         int var119 = var18;
         int var118 = var143;
         var98 = var118;
         int var91 = var118;
         label84:
         if (var119 != 0) {
            int var120 = var91;
            switch (var120) {
               case 1370061657:
                  String var61 = "Footsteps";
                  String var60 = var31;
                  byte var144 = ((byte)((var60.equals(var61)) ? 1 : 0));
                  int var122 = var18;
                  byte var121 = var144;
                  var98 = var121;
                  byte var92 = var121;
                  if (var122 == 0) {
                     break label84;
                  }

                  byte var123 = var92;
                  byte var93 = var123;
                  byte var124 = var93;
                  if (var124 == 0) {
                     break;
                  }

                  var32 = 0;
                  int var125 = var18;
                  if (var125 != 0) {
                     break;
                  }
               case 2547280:
                  String var65 = "Ring";
                  String var64 = var31;
                  byte var145 = ((byte)((var64.equals(var65)) ? 1 : 0));
                  int var127 = var18;
                  byte var126 = var145;
                  var98 = var126;
                  byte var94 = var126;
                  if (var127 == 0) {
                     break label84;
                  }

                  byte var128 = var94;
                  byte var95 = var128;
                  byte var129 = var95;
                  if (var129 == 0) {
                     break;
                  }

                  var32 = 1;
                  int var130 = var18;
                  if (var130 != 0) {
                     break;
                  }
               case 203653773:
                  String var69 = "Particles";
                  String var68 = var31;
                  byte var146 = ((byte)((var68.equals(var69)) ? 1 : 0));
                  int var132 = var18;
                  byte var131 = var146;
                  var98 = var131;
                  byte var96 = var131;
                  if (var132 == 0) {
                     break label84;
                  }

                  byte var133 = var96;
                  byte var97 = var133;
                  byte var134 = var97;
                  if (var134 != 0) {
                     var32 = 2;
                  }
            }

            var98 = var32;
         }

         int var135 = var98;
         switch (var135) {
            case 0:
               Object[] var10009 = new Object[]{null, null, null, null, null, null, 85698087524238L};
               var10009[5] = var24;
               var10009[4] = var28;
               var10009[3] = var30;
               var10009[2] = var29;
               var10009[1] = var26;
               var10009[0] = var1;
               Object[] var73 = var10009;
               Trails var72 = this;
               var72.jReturningVoid(var73);
               int var136 = var18;
               if (var136 != 0) {
                  break;
               }
            case 1:
               Object[] var10010 = new Object[]{null, null, null, null, null, null, null, 59704688819828L};
               var10010[6] = var27;
               var10010[5] = var24;
               var10010[4] = var28;
               var10010[3] = var30;
               var10010[2] = var29;
               var10010[1] = var26;
               var10010[0] = var1;
               Object[] var76 = var10010;
               Trails var75 = this;
               var75.kReturningVoid(var76);
               int var137 = var18;
               if (var137 != 0) {
                  break;
               }
            case 2:
               Object[] var155 = new Object[]{null, null, null, null, null, null, 97886420666620L};
               var155[5] = var27;
               var155[4] = var24;
               var155[3] = var28;
               var155[2] = var29;
               var155[1] = var26;
               var155[0] = var1;
               Object[] var79 = var155;
               Trails var78 = this;
               var78.lReturningVoid(var79);
         }

         int var138 = var18;
         if (var138 == 0) {
            break;
         }
      }
   }

   private void jReturningVoid(Object[] var1) {
      Render3DEvent var5 = (Render3DEvent)var1[0];
      TrailPoint var8 = (TrailPoint)var1[1];
      Color var2 = (Color)var1[2];
      Color var9 = (Color)var1[3];
      float var7 = (Float)var1[4];
      float var6 = (Float)var1[5];
      long var3 = (Long)var1[6];
      var3 = 16167928597977L ^ var3;
      long var10 = var3 ^ 120471197869924L;
      long var12 = var3 ^ 19181983459265L;
      long var14 = var3 ^ 38677732460778L;
      long var16 = var3 ^ 15210691465727L;
      Object[] var25 = new Object[]{var16};
      nReturningVoid(var25);
      double var29 = 0.02;
      Vec3d var26 = var8.a;
      Vec3d var18 = var26.add(var27, var29, var31);
      RenderContext var10000 = var5.b;
      Vec3d var33 = var18;
      double var10001 = var33.x;
      Vec3d var34 = var18;
      double var10002 = var34.y;
      Vec3d var35 = var18;
      double var10003 = var35.z;
      Object[] var10006 = new Object[]{null, null, null, null, var10};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var10000;
      Object[] var36 = var10006;
      Vector3d var19 = RenderThreadUtil.aReturningVector3d(var36);
      Matrix4f var20 = new Matrix4f();
      Vector3d var37 = var19;
      float var59 = (float)var37.x;
      Vector3d var38 = var19;
      float var62 = (float)var38.y;
      Vector3d var39 = var19;
      float var43 = (float)var39.z;
      float var42 = var62;
      float var41 = var59;
      Matrix4f var40 = var20;
      var40.translate(var41, var42, var43);
      float var45 = -var8.e;
      Matrix4f var44 = var20;
      var44.rotateY(var45);
      double var46 = 90.0;
      float var49 = (float)Math.toRadians(var46);
      Matrix4f var48 = var20;
      var48.rotateX(var49);
      float var51 = 0.04F;
      Matrix4f var50 = var20;
      var50.scale(var51);
      float var21 = 4.0F * var6;
      float var22 = 7.5F * var6;
      float var23 = var21 * 1.55F;
      float var24 = var22 * 1.4F;
      MeshBufferManager var57 = var5.a;
      RenderContext var60 = var5.b;
      ManagedGlTexture var63 = h;
      float var10004 = -var23;
      float var10005 = -var24;
      float var10011 = var7 * 0.45F;
      Object[] var10014 = new Object[]{null, null, var12};
      var10014[1] = var10011;
      var10014[0] = var2;
      Object[] var52 = var10014;
      Color var10010 = aReturningColor(var52);
      var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var14};
      var10014[11] = 0.0F;
      var10014[10] = var10010;
      var10014[9] = 0.0F;
      var10014[8] = var24;
      var10014[7] = var23;
      var10014[6] = 0.0F;
      var10014[5] = var10005;
      var10014[4] = var10004;
      var10014[3] = var63;
      var10014[2] = var20;
      var10014[1] = var60;
      var10014[0] = var57;
      Object[] var53 = var10014;
      TexturedRectangleRenderer.mReturningVoid(var53);
      MeshBufferManager var58 = var5.a;
      RenderContext var61 = var5.b;
      ManagedGlTexture var64 = h;
      var10004 = -var21;
      var10005 = -var22;
      var10014 = new Object[]{null, null, var12};
      var10014[1] = var7;
      var10014[0] = var9;
      Object[] var54 = var10014;
      var10010 = aReturningColor(var54);
      var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var14};
      var10014[11] = 0.0F;
      var10014[10] = var10010;
      var10014[9] = 0.0F;
      var10014[8] = var22;
      var10014[7] = var21;
      var10014[6] = 0.0F;
      var10014[5] = var10005;
      var10014[4] = var10004;
      var10014[3] = var64;
      var10014[2] = var20;
      var10014[1] = var61;
      var10014[0] = var58;
      Object[] var55 = var10014;
      TexturedRectangleRenderer.mReturningVoid(var55);
   }

   private void kReturningVoid(Object[] var1) {
      Render3DEvent var10 = (Render3DEvent)var1[0];
      TrailPoint var5 = (TrailPoint)var1[1];
      Color var4 = (Color)var1[2];
      Color var6 = (Color)var1[3];
      float var2 = (Float)var1[4];
      float var7 = (Float)var1[5];
      float var3 = (Float)var1[6];
      long var8 = (Long)var1[7];
      var8 = 16167928597977L ^ var8;
      long var11 = var8 ^ 117433391861307L;
      long var13 = var8 ^ 135113262608772L;
      Object[] var16 = new Object[]{var3};
      float var15 = (0.05F + 0.55F * cReturningFloat(var16)) * var7;
      RenderContext var10000 = var10.b;
      MeshBufferManager var10001 = var10.a;
      Vec3d var17 = var5.a;
      float var10002 = (float)var17.x;
      Vec3d var18 = var5.a;
      float var10003 = (float)var18.y + 0.01F;
      Vec3d var19 = var5.a;
      float var10004 = (float)var19.z;
      Object[] var10012 = new Object[]{null, null, var11};
      var10012[1] = var2;
      var10012[0] = var6;
      Object[] var20 = var10012;
      Color var10008 = aReturningColor(var20);
      Object[] var10013 = new Object[]{null, null, var11};
      var10013[1] = var2;
      var10013[0] = var4;
      Object[] var21 = var10013;
      var10012 = new Object[]{null, null, null, null, null, null, null, null, var10008, aReturningColor(var21), var13};
      var10012[7] = 0.12F;
      var10012[6] = 0.018F;
      var10012[5] = var15;
      var10012[4] = var10004;
      var10012[3] = var10003;
      var10012[2] = var10002;
      var10012[1] = var10001;
      var10012[0] = var10000;
      Object[] var22 = var10012;
      ShapeRenderer.fReturningVoid(var22);
   }

   private void lReturningVoid(Object[] var1) {
      Render3DEvent var7 = (Render3DEvent)var1[0];
      TrailPoint var3 = (TrailPoint)var1[1];
      Color var2 = (Color)var1[2];
      float var6 = (Float)var1[3];
      float var8 = (Float)var1[4];
      float var9 = (Float)var1[5];
      long var4 = (Long)var1[6];
      var4 = 16167928597977L ^ var4;
      long var10 = var4 ^ 6072916703411L;
      long var12 = var4 ^ 32992183524519L;
      long var14 = var4 ^ 27635205344909L;
      Object[] var22 = new Object[]{var14};
      nReturningVoid(var22);
      float var16 = var3.c * var9 / 50.0F;
      double var24 = var16;
      Vec3d var23 = var3.g;
      Vec3d var17 = var23.multiply(var24);
      double var18 = 9.0E-4 * var16 * var16;
      Vec3d var26 = var17;
      Vec3d var27 = var17;
      double var10002 = var27.y - var18 + 0.05;
      Vec3d var28 = var17;
      double var34 = var28.z;
      double var32 = var10002;
      double var30 = var26.x;
      Vec3d var29 = var3.a;
      Vec3d var20 = var29.add(var30, var32, var34);
      float var21 = (1.6F - 0.5F * var9) * 2.5F * var8;
      Object[] var10008 = new Object[]{null, null, var10};
      var10008[1] = var6;
      var10008[0] = var2;
      Object[] var36 = var10008;
      Object[] var10007 = new Object[]{null, null, null, aReturningColor(var36), var12};
      var10007[2] = var21;
      var10007[1] = var20;
      var10007[0] = var7;
      Object[] var38 = var10007;
      Trails var37 = this;
      var37.mReturningVoid(var38);
   }

   private void mReturningVoid(Object[] var1) {
      Render3DEvent var7 = (Render3DEvent)var1[0];
      Vec3d var6 = (Vec3d)var1[1];
      float var5 = (Float)var1[2];
      Color var2 = (Color)var1[3];
      long var3 = (Long)var1[4];
      var3 = 16167928597977L ^ var3;
      long var8 = var3 ^ 116356157860200L;
      long var10 = var3 ^ 43359724996326L;
      Color var14 = var2;
      int var42 = var14.getAlpha();
      if (var42 > 0) {
         RenderContext var10000 = var7.b;
         Vec3d var16 = var6;
         double var10001 = var16.x;
         Vec3d var17 = var6;
         double var10002 = var17.y;
         Vec3d var18 = var6;
         double var10003 = var18.z;
         Object[] var10006 = new Object[]{null, null, null, null, var8};
         var10006[3] = var10003;
         var10006[2] = var10002;
         var10006[1] = var10001;
         var10006[0] = var10000;
         Object[] var19 = var10006;
         Vector3d var12 = RenderThreadUtil.aReturningVector3d(var19);
         Matrix4f var13 = new Matrix4f();
         Vector3d var20 = var12;
         float var45 = (float)var20.x;
         Vector3d var21 = var12;
         float var47 = (float)var21.y;
         Vector3d var22 = var12;
         float var26 = (float)var22.z;
         float var25 = var47;
         float var24 = var45;
         Matrix4f var23 = var13;
         var23.translate(var24, var25, var26);
         float var28 = 0.04F;
         Matrix4f var27 = var13;
         var27.scale(var28);
         RenderContext var29 = var7.b;
         Camera var30 = var29.bo();
         double var31 = -var30.getYaw();
         float var34 = (float)Math.toRadians(var31);
         Matrix4f var33 = var13;
         var33.rotateY(var34);
         RenderContext var35 = var7.b;
         Camera var36 = var35.bo();
         double var37 = var36.getPitch();
         float var40 = (float)Math.toRadians(var37);
         Matrix4f var39 = var13;
         var39.rotateX(var40);
         MeshBufferManager var44 = var7.a;
         RenderContext var46 = var7.b;
         ManagedGlTexture var48 = h;
         Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var10};
         var10014[11] = 0.0F;
         var10014[10] = var2;
         var10014[9] = 0.0F;
         var10014[8] = var5;
         var10014[7] = var5;
         var10014[6] = 0.0F;
         var10014[5] = 0.0F;
         var10014[4] = 0.0F;
         var10014[3] = var48;
         var10014[2] = var13;
         var10014[1] = var46;
         var10014[0] = var44;
         Object[] var41 = var10014;
         TexturedRectangleRenderer.mReturningVoid(var41);
      }
   }

   private static void nReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 16167928597977L ^ var1;
      long var3 = var1 ^ 89024130826840L;
      int var5 = Event.bReturningInt();
      int var11 = var5;
      ManagedGlTexture var10 = h;
      ManagedGlTexture var9 = var10;
      ManagedGlTexture var8 = var10;
      if (var11 == 0) {
         ManagedGlTexture var12 = var8;
         if (var12 != null) {
            return;
         }

         short var10000 = 31509;
         long var10001 = 199622911236234152L ^ var1;
         Object[] var7 = new Object[]{"assets/prestige/particles/glow.png", var3};
         ManagedGlTexture var13 = TextureLoader.aReturningbT_C0095(var7);
         var9 = var13;
      }

      h = var9;
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      List var4 = this.k;
      var4.clear();
      Map var5 = this.j;
      var5.clear();
   }

   private static float bReturningFloat(Object[] var0) {
      float var3 = (Float)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 16167928597977L ^ var1;
      int var4 = Event.bReturningInt();
      float var21;
      int var19 = (var21 = var3 - 0.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
      int var12 = var4;
      int var11 = var19;
      int var8 = var11;
      int var5 = var11;
      if (var12 == 0) {
         int var13 = var5;
         if (var13 <= 0) {
            return 0.0F;
         }

         int var16 = var4;
         float var15 = 1.0F;
         float var14 = var3;
         float var9 = var14;
         float var10 = var15;
         float var6 = var14;
         float var7 = var15;
         if (var16 != 0) {
            return var9 * var10;
         }

         float var22;
         int var17 = (var22 = var6 - var7) == 0.0F ? 0 : (var22 < 0.0F ? -1 : 1);
         var8 = var17;
      }

      int var18 = var8;
      if (var18 >= 0) {
         return 1.0F;
      }

      float var20 = var3 * var3 * var3;
      float var24 = var3 * (var3 * 6.0F - 15.0F) + 10.0F;
      float var23 = var20;
      return var23 * var24;
   }

   private static float cReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      return 1.0F - (1.0F - var1) * (1.0F - var1);
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 16167928597977L ^ var2;
      byte var10000 = 0;
      short var10001 = 10264;
      long var10002 = 6708057722722551323L ^ var2;
      var10001 = 255;
      Color var6 = var1;
      int var8 = (int)(var6.getAlpha() * var4);
      int var10 = Math.min(255, var8);
      int var5 = Math.max(0, var10);
      Color var11 = var1;
      int var16 = var11.getRed();
      Color var12 = var1;
      int var10003 = var12.getGreen();
      Color var13 = var1;
      return new Color(var16, var10003, var13.getBlue(), var5);
   }

   private static Color bReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 16167928597977L ^ var2;
      long var5 = var2 ^ 105930920816090L;
      int var7 = Event.cReturningInt();
      float var42;
      int var10000 = (var42 = var4 - 0.0F) == 0.0F ? 0 : (var42 < 0.0F ? -1 : 1);
      int var28 = var7;
      int var27 = var10000;
      int var24 = var27;
      int var23 = var27;
      if (var28 != 0) {
         int var29 = var23;
         if (var29 < 0) {
            var4 = 0.0F;
         }

         float var43;
         var24 = (var43 = var4 - 1.0F) == 0.0F ? 0 : (var43 < 0.0F ? -1 : 1);
      }

      int var31 = var7;
      int var30 = var24;
      int var26 = var30;
      int var25 = var30;
      if (var31 != 0) {
         int var32 = var25;
         if (var32 > 0) {
            var4 = 1.0F;
         }

         Color var13 = var1;
         float var34 = var13.getRed();
         short var10001 = 27626;
         long var10002 = 474144698900212548L ^ var2;
         Color var14 = var1;
         var26 = (int)(var34 + (255 - var14.getRed()) * var4);
      }

      int var8 = var26;
      Color var15 = var1;
      float var35 = var15.getGreen();
      short var37 = 27626;
      long var39 = 474144698900212548L ^ var2;
      Color var16 = var1;
      int var9 = (int)(var35 + (255 - var16.getGreen()) * var4);
      Color var17 = var1;
      float var36 = var17.getBlue();
      var37 = 27626;
      var39 = 474144698900212548L ^ var2;
      Color var18 = var1;
      int var10 = (int)(var36 + (255 - var18.getBlue()) * var4);
      Object[] var10005 = new Object[]{null, var5};
      var10005[0] = var8;
      Object[] var19 = var10005;
      int var41 = aReturningInt(var19);
      Object[] var10006 = new Object[]{null, var5};
      var10006[0] = var9;
      Object[] var20 = var10006;
      int var10003 = aReturningInt(var20);
      Object[] var10007 = new Object[]{null, var5};
      var10007[0] = var10;
      Object[] var21 = var10007;
      int var10004 = aReturningInt(var21);
      Color var22 = var1;
      return new Color(var41, var10003, var10004, var22.getAlpha());
   }

   private static Color cReturningColor(Object[] var0) {
      float var1;
      Color var2;
      Color var3;
      long var6;
      float var32;
      float var33;
      label24: {
         var2 = (Color)var0[0];
         var3 = (Color)var0[1];
         var1 = (Float)var0[2];
         long var4 = (Long)var0[3];
         var4 = 16167928597977L ^ var4;
         var6 = var4 ^ 118177866577866L;
         int var8 = Event.bReturningInt();
         float var47;
         int var10000 = (var47 = var1 - 0.0F) == 0.0F ? 0 : (var47 < 0.0F ? -1 : 1);
         int var35 = var8;
         int var34 = var10000;
         int var31 = var34;
         int var28 = var34;
         if (var35 == 0) {
            int var36 = var28;
            if (var36 < 0) {
               var1 = 0.0F;
            }

            int var39 = var8;
            float var38 = 1.0F;
            float var37 = var1;
            var32 = var37;
            var33 = var38;
            float var29 = var37;
            float var30 = var38;
            if (var39 != 0) {
               break label24;
            }

            float var48;
            int var40 = (var48 = var29 - var30) == 0.0F ? 0 : (var48 < 0.0F ? -1 : 1);
            var31 = var40;
         }

         int var41 = var31;
         if (var41 > 0) {
            var1 = 1.0F;
         }

         var33 = var1;
         var32 = 1.0F;
      }

      float var9 = var32 - var33;
      Color var16 = var2;
      float var43 = var16.getRed() * var9;
      Color var17 = var3;
      int var10 = (int)(var43 + var17.getRed() * var1);
      Color var18 = var2;
      var43 = var18.getGreen() * var9;
      Color var19 = var3;
      int var11 = (int)(var43 + var19.getGreen() * var1);
      Color var20 = var2;
      var43 = var20.getBlue() * var9;
      Color var21 = var3;
      int var12 = (int)(var43 + var21.getBlue() * var1);
      Color var22 = var2;
      var43 = var22.getAlpha() * var9;
      Color var23 = var3;
      int var13 = (int)(var43 + var23.getAlpha() * var1);
      Object[] var10005 = new Object[]{null, var6};
      var10005[0] = var10;
      Object[] var24 = var10005;
      int var10002 = aReturningInt(var24);
      Object[] var10006 = new Object[]{null, var6};
      var10006[0] = var11;
      Object[] var25 = var10006;
      int var10003 = aReturningInt(var25);
      Object[] var10007 = new Object[]{null, var6};
      var10007[0] = var12;
      Object[] var26 = var10007;
      int var10004 = aReturningInt(var26);
      Object[] var10008 = new Object[]{null, var6};
      var10008[0] = var13;
      Object[] var27 = var10008;
      return new Color(var10002, var10003, var10004, aReturningInt(var27));
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 16167928597977L ^ var1;
      int var4 = Event.bReturningInt();
      int var11 = var4;
      int var10 = var3;
      int var6 = var10;
      int var5 = var10;
      if (var11 == 0) {
         int var12 = var5;
         if (var12 < 0) {
            byte var13 = 0;
            byte var22 = var13;
            return var22;
         }

         var6 = var3;
      }

      int var15 = var4;
      int var14 = var6;
      int var8 = var14;
      int var7 = var14;
      int var9;
      if (var15 == 0) {
         short var10001 = 27626;
         long var10002 = 474266596736961351L ^ var1;
         short var17 = 255;
         int var16 = var7;
         if (var16 > var17) {
            short var10000 = 27626;
            long var21 = 474266596736961351L ^ var1;
            short var18 = 255;
            var9 = var18;
         } else {
            var9 = var3;
         }
      } else {
         int var19 = var8;
         var9 = var19;
      }

      return var9;
   }

   private static boolean lambda$onRenderWorld$1(long var0, TrailPoint var2) {
      int var5 = Event.bReturningInt();
      long var13;
      int var10000 = (var13 = var0 - var2.b - var2.c) == 0L ? 0 : (var13 < 0L ? -1 : 1);
      int var10 = var5;
      int var9 = var10000;
      int var7 = var9;
      int var6 = var9;
      if (var10 == 0) {
         int var11 = var6;
         if (var11 < 0) {
            return false;
         }

         var7 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var7);
   }

   private boolean lambda$new$0(Color var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.f;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(8702180192301L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[7];
      String var17 = "\u001aí¥zR¼\u0000\u009ac-°(ù\u001aCz\u0003\u001d\u0093¼\u0098¯¡\u008c\u008c\u000fv\u0087hÖÛÙtHÆjÒ&òKE\u00adK\u0083\u0098¼:\f\u0005¾±\u0007.Ã§ký¬\u0016^Ë÷õ\u0085 \u0095(à/L ÷h°W'¬³·\u0007 ß8\bnû!\u0094Ù\tx\tOáï¦k \rËgÓå:*h9°TÖåPïô`9 ôÄ÷¿§Øì;\u0084}\u0094î¤ %ÄM£\u008d|ë\u008avp?M2\u008d\u0015`)\n]~óaôÈ\u001b\u0081óx\u009d©¾7 \u009aTØÔk?ìh+Tÿ)\u0080\u0094¹¦&µO@óuj\u0093\u0010¼Ç[ Q\u0085I";
      int var19 = "\u001aí¥zR¼\u0000\u009ac-°(ù\u001aCz\u0003\u001d\u0093¼\u0098¯¡\u008c\u008c\u000fv\u0087hÖÛÙtHÆjÒ&òKE\u00adK\u0083\u0098¼:\f\u0005¾±\u0007.Ã§ký¬\u0016^Ë÷õ\u0085 \u0095(à/L ÷h°W'¬³·\u0007 ß8\bnû!\u0094Ù\tx\tOáï¦k \rËgÓå:*h9°TÖåPïô`9 ôÄ÷¿§Øì;\u0084}\u0094î¤ %ÄM£\u008d|ë\u008avp?M2\u008d\u0015`)\n]~óaôÈ\u001b\u0081óx\u009d©¾7 \u009aTØÔk?ìh+Tÿ)\u0080\u0094¹¦&µO@óuj\u0093\u0010¼Ç[ Q\u0085I"
         .length();
      char var16 = '@';
      int var23 = -1;

      label45:
      while (true) {
         String var24 = var17.substring(++var23, var23 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var24.getBytes("ISO-8859-1"));
            String var33 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var33;
                  if ((var23 += var16) >= var19) {
                     m = var20;
                     n = new String[7];
                     r = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(8702180192301L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[3];
                     String var4 = ">xÒê5þ}ätèGws9Úáô\rCféÉ?J";
                     int var5 = ">xÒê5þ}ätèGws9Úáô\rCféÉ?J".length();
                     do {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        var10001 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        long var10004 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        
                     } while (var2 < var5);

                     p = var6;
                     q = new Integer[3];
                     i = 4;
                     break;
                  }

                  var16 = var17.charAt(var23);
                  break;
               default:
                  var20[var18++] = var33;
                  if ((var23 += var16) < var19) {
                     var16 = var17.charAt(var23);
                     continue label45;
                  }

                  var17 = "ÈùÈ\u000bâ8UB\u0091\\ë\u0091\u0091\u0080Æ\u0089\u0010VÀÇ®i÷ç]Å¿\u0094³Ý¯Ïd";
                  var19 = "ÈùÈ\u000bâ8UB\u0091\\ë\u0091\u0091\u0080Æ\u0089\u0010VÀÇ®i÷ç]Å¿\u0094³Ý¯Ïd".length();
                  var16 = 16;
                  var23 = -1;
            }

            var24 = var17.substring(++var23, var23 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9932;
      if (n[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])o.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               o.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fB", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = m[var5].getBytes("ISO-8859-1");
         n[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return n[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fB_C0273",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 24141;
      if (q[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = p[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])r.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fB", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         q[var3] = var15;
      }

      return q[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fB_C0273",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = t[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = s[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 32;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 35;
            yield var20;
         }
         case 6 -> {
            byte var21 = 39;
            yield var21;
         }
         case 7 -> {
            byte var22 = 59;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 55;
            yield var24;
         }
         case 10 -> {
            byte var25 = 24;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 38;
            yield var27;
         }
         case 13 -> {
            byte var28 = 25;
            yield var28;
         }
         case 14 -> {
            byte var29 = 3;
            yield var29;
         }
         case 15 -> {
            byte var30 = 9;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 42;
            yield var33;
         }
         case 19 -> {
            byte var34 = 49;
            yield var34;
         }
         case 20 -> {
            byte var35 = 10;
            yield var35;
         }
         case 21 -> {
            byte var36 = 52;
            yield var36;
         }
         case 22 -> {
            byte var37 = 44;
            yield var37;
         }
         case 23 -> {
            byte var38 = 19;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 15;
            yield var40;
         }
         case 26 -> {
            byte var41 = 51;
            yield var41;
         }
         case 27 -> {
            byte var42 = 5;
            yield var42;
         }
         case 28 -> {
            byte var43 = 0;
            yield var43;
         }
         case 29 -> {
            byte var44 = 61;
            yield var44;
         }
         case 30 -> {
            byte var45 = 13;
            yield var45;
         }
         case 31 -> {
            byte var46 = 36;
            yield var46;
         }
         case 32 -> {
            byte var47 = 31;
            yield var47;
         }
         case 33 -> {
            byte var48 = 1;
            yield var48;
         }
         case 34 -> {
            byte var49 = 28;
            yield var49;
         }
         case 35 -> {
            byte var50 = 6;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 34;
            yield var53;
         }
         case 39 -> {
            byte var54 = 27;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 60;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 56;
            yield var59;
         }
         case 45 -> {
            byte var60 = 16;
            yield var60;
         }
         case 46 -> {
            byte var61 = 21;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 63;
            yield var63;
         }
         case 49 -> {
            byte var64 = 2;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 37;
            yield var66;
         }
         case 52 -> {
            byte var67 = 14;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 46;
            yield var69;
         }
         case 55 -> {
            byte var70 = 40;
            yield var70;
         }
         case 56 -> {
            byte var71 = 4;
            yield var71;
         }
         case 57 -> {
            byte var72 = 12;
            yield var72;
         }
         case 58 -> {
            byte var73 = 23;
            yield var73;
         }
         case 59 -> {
            byte var74 = 41;
            yield var74;
         }
         case 60 -> {
            byte var75 = 11;
            yield var75;
         }
         case 61 -> {
            byte var76 = 47;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 62;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            t[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      s[0] = "e^o\"QQs^jxBFd\u0015i~NRuR~i\u0005@D";
      s[1] = int.class;
      t[1] = "java/lang/Integer";
      s[2] = "\u001fP=^\u0011\u0004\tP8\u0004\u0002\u0013\u001e\u001b;\u0002\u000e\u0007\u000f\\,\u0015E\u00129";
      s[3] = "\u0016\u001b*2\u001f-\u001d\u0014;}| \b\u00194\u0016I\"\u0019\n(:^/";
      s[4] = "!C^[]5#]\u00178V.<XAAQ";
      s[5] = float.class;
      t[5] = "java/lang/Float";
      s[6] = "0E~-\u0006k2[7U\tg+Xk0\b";
      s[7] = double.class;
      t[7] = "java/lang/Double";
      s[8] = " t\u001fL4\u000f t\b\u00108\u0000:?\b\u000e8\u0015=NYVj";
      s[9] = "\u0014UjTKN\u0002Uo\u000eXY\u0015\u001el\bTM\u0004Y{\u001f\u001fZ\u0017";
      s[10] = "T$^G!u!\u0004UH0:@\n^C4`4";
      s[11] = void.class;
      t[11] = "java/lang/Void";
      s[12] = "=XU\u0019xv M\r;9{8K";
      s[13] = "oF?!q}yF:{bjn\r9}n~\u007fJ.j%ia";
      s[14] = "\tQ\u0004$C3|q\u000f+R|\u001d\u007f\u0004 V&i";
      s[15] = "\u0012+RHXT\u0012+E\u0014T[\b`E\nTN\u000f\u0011\u0012W\r\t";
      s[16] = "e}!4@\u0017nr0{#\u001a{t";
      s[17] = "\\23;,vJ26a?a]y5g3uL>\"pxaB";
      s[18] = "\u001dy`#a$hYk,pk\tW`'t1}";
      s[19] = "(Mo \u0006M]md/\u0017\u0002<co$\u0013XH";
      s[20] = "\r\u0015Us%'x5^|4h\u0019;Uw02m";
      s[21] = "AX2]\u0006\u001aJW#\u0012j\u0019DU!]F";
      s[22] = boolean.class;
      t[22] = "java/lang/Boolean";
      s[23] = "O\u000f4P9;Y\u000f1\n*,ND2\f&8_\u0003%\u001bm/m";
      s[24] = "'7s\\\tr,8b\u0013h|'3fI";
      s[25] = "\u0016\u0005\u0010?_.\u0000\u0005\u0015eL9\u0017N\u0016c@-\u0006\t\u0001t\u000b:\u0004";
      s[26] = ")*#D;*\\\n(K*e=\u0004#@.?I";
      s[27] = "\u0000\u001a6\u0005\u0011Fu:=\n\u0000\t\u001446\u0001\u0004S`";
      s[28] = "\u0014)oX^\u0018a\tdWOW\u0000\u0007o\\K\rt";
      s[29] = "_\u0011bT*\u0015I\u0011g\u000e9\u0002^Zd\b5\u0016O\u001ds\u001f~\u0001r";
      s[30] = "\u001do\bYa.hO\u0003Vpa\tA\b]t;}";
      s[31] = "Hn&vH\u0005Vf<9*\u0019Q{";
      s[32] = "er\u001e_H.{z\u0004\u0010\u0000.ap\u001cW\t5!C\u001a[\u00022lr\u001c[";
      s[33] = "n=$6o\u001e\u001b\u001d/9~Qz\u0013$2z\u000b\u000e";
      s[34] = "u\u0015[V,5\u00005PY=za;[R9 \u0015";
      s[35] = "\u00039^^QR\b6O\u0011,J\u001b1FX";
      s[36] = ":f[59h,f^o*\u007f;-]i&k*jJ~my\u001c";
      s[37] = "\ny='\u00129\u007fY6(\u0003v\u001eW=#\u0007,j";
      s[38] = "\u0018$e/\u001fnm\u0004n \u000e!\f\ne+\n{x";
      s[39] = "~5ymtKu:h\"\t^g ja";
      s[40] = long.class;
      t[40] = "java/lang/Long";
      s[41] = "t/\u00045Q\\\u0001\u000f\u000f:@\u0013`\u0001\u00041DI\u0014";
      s[42] = ";J2\u000b\u0001\u001f%B(Df\u001e4Y%\u001e@\u0018";
      s[43] = "SFu+5u&f~$$:Ghu/ `3";
      s[44] = "\u007f\ro\u0011^7\n-d\u001eOxk#o\u0015K\"\u001f";
      s[45] = "\u0011\u0005Vo?]\u001a\nG W]\u0014\u0005T";
      s[46] = "\u0016f\u001d\r_\n\u0016f\nQS\u0005\f-\nOS\u0010\u000b\\X\u0015\u0007T";
      s[47] = "\rp,`\u0010k\u0013x6/m{\u0013";
      s[48] = "cR\u0000\u001f]Vh]\u0011P:T}V\u0011\u001b\u0001";
      s[49] = "\u0019H\u0017|ui\u0007@\r3\u0016}\u0003";
      s[50] = "yX[\u0018\nWyXLD\u0006Xc\u0013LZ\u0006Mdb\u001c\u0007W";
      s[51] = "O8\u0015@6mO8\u0002\u001c:bUs\u0002\u0002:wR\u0002VZm";
      s[52] = "\u001bu\u000bV'm\u001bu\u001c\n+b\u0001>\u001c\u0014+w\u0006OIKr";
      s[53] = "<C= k3\"K'o\u0006):N.\"1/9L";
      s[54] = "o?M1\u0011>y?Hk\u0002)ntKm\u000e=\u007f3\\zE*c";
      s[55] = "8\u0015?+=$M54$,k,;?/(1X";
      s[56] = "/N\u000b^+%9N\u000e\u000482.\u0005\r\u00024&?B\u001a\u0015\u007f7\u001f";
      s[57] = " zM7'?{c\u000f{Jk#rp?wr3`\u0015>2|#\u0002I;6w(gH~8gJ;Mz3l/:\bt#\u000e";
      s[58] = "aL6\u0003{Lo\u0006l\u001f\u0018Qi\u00130\u0013ujjv2\\|K{\u0011;\u0016\"Q\u0004\u00180\u000buZx\u0007g\u001d&+";
      s[59] = "I\"\u007f\u0005S@J2<\f5Ku~yZ[Y\u0013%$\u0016J";
      s[60] = "etUGu{<4\r\u0010D(8p~J<'<\f\u000e\u00138>7i\u000fV6.U";
      s[61] = "DT\u0011N\u0000\u0000J\u001e\r\u0017y\u0006J\u001e\u0010a\u001e\nNeI\u0017\u0005\u001fA\u0000HR\u000b\u000f#";
      s[62] = "\t9k\u0016dIPy3AU\u001fC f\u001f)\u0018CA9\u00077\u001c\b}`GoK9";
      s[63] = "U3\u0000~\u000bWS&Ckf\u0000R1Dj\u0000\u0017s*[j#\nK/_|f\u0010D/Nm\t\u0010\u0015)\u0004\u0007";
      s[64] = ":\u001aNdPVi\u0005\u001d\"4\u0002\u0003SD5[\u000ei\u0011\u0001=U\u0011\u0003SC%M\tfR\u0006+]k";
      s[65] = "\u0003 \f8>0\rjV$]6\u001aw\u0017?!0\u001c\u001a\u0011.fkYj\u0015*'*f";
      s[66] = "\u000ej1O)Y\u0003(,KI\u000fn-s\u0019&\u0004\u0004o6\u0011(\u001bn+2\b2\u0007\f./\f7a";
      s[67] = "D\u000b%\u0013\u0003NJ\u000buU8RR\tJ\u0001\\NYu-UDJV\u0010,\u0010JZ4";
      s[68] = "6h\u001aD\ndmqX\bg);JN\u0019\u0006<:k'H[e2rA\u0013\u0006)#\u0010\u001aIW;>vA\u0014\u001b*\\";
      s[69] = "\nD$UwF\u000e@e\u0014HP\u001bLci'QML/\u00107\n\u0012X\u001f";
      s[70] = "/V1Uxq|Ib\u0013\u001c'\u0016\u001f;\u0004s)|]~\f}6\u0016\u0016y\nu}*O9R\"L";
      s[71] = "I\u0004\fHfk\u0012\u001dN\u0004\u000b1D\u00071D7jM\u001eW\u001fj&\\|\fE;4A\u001aW\u0018w%#";
      s[72] = "\t\u0001\u001d\u001bO|Z\u001eN]+$0H\u0017JD$Z\nRBJ;0NV[P'RKK_UA";
      s[73] = "+/\u0010vgWp6R:\n\u001d8-QG7Zq9O!l\u0007=(-z6V/5K!k\u001a>W";
      s[74] = "|K\u0014\u001c:\rh\u0005\u000b\t\u0003\u0018xH\u0005\u0015o*,\u0005^H2}.T\tM{\u0006.X\n\u000f\u0003";
      s[75] = "H{\u001aH7x\u0011;B\u001f\u0006+\u0015\u007f\"LjDA>\u0004Xd!@{\nH\u0006";
      s[76] = "sQ\u0002LZuv\u0011YN>`2\u0005\u0000KZu4\u0001f\u000b^pw\u0014\u001d\u000bRs5l]PR#0\u0017]\\QaHW\u0006\\\u0001d3W\n_C\u001csQ\u0002LZuv\u0011YN>";
      s[77] = "Qm>\u0006z\u0012V8(\u0010ym\r8,\u0000!\u0001?l`\\{Sh0j\u0001(\u000e\u000f> [4m";
      s[78] = "NYm\u0018\u0005?MZg\rk&\\L7\u0004\u0007\u0014\u000b\fgY[C_W1\u000e\u001a?@\u0000']k";
      s[79] = ")\"TqP$'h\u000em3((u\\e3|7eNyQy*aK\u001f";
      s[80] = "C\u000euy\bADG~{e\u0017\u001f\u0013}q2@EC#\u001dXEN\u0010{{\u0003\u0018\u0002\u0001";
      s[81] = "9?B\n\u001c\u0019>vI\bqOe\"J\u0002&\u0018?r\u0017nL\u001d4!L\b\u0017@x0";
      s[82] = "e,\\8\u0017m63\u000f~s:\\eVi\u001c56'\u0013a\u0012*\\g\fiL('g\u0000j\u000eP";
      s[83] = "`fY1*pn,EhS{~*Q1(\u0016h0\u0003%coxk\\1Sx`1U$/g7'\u0006U";
      s[84] = "7\u007f\b+\u0017\u0015d`[msB\u000e6\u0002z\u001cMdtGr\u0012R\u000e?@t\u001a\u00192f\u0000,M(";
      s[85] = "\u0003\u0007 -q]P\u0018sk\u0015\u0006:N*|z\u0005P\fott\u001a:Hkmn\u0006XMvik`";
      s[86] = "\u001fZ\u0010t\u0011\fF\u001aH# \\FX\u0011pZ0\u001fZ\u0010t\u0011\fF\u001aH# ";
      s[87] = "6\rc@P6-\u0015f\u0010</$\t4NZ\u001c-\u0011]\u0016\u0005d3\u000f>DF4*\u0010]A[3$\u0004!^\f%wu";
      s[88] = "Zq[iF\u0016\u00043[t\u0019i\nH\u00041\u0017\u0006\u0006\"Ft\u001f\b\u0019H\u00040\u0016\u0002Z:Z7B\u000f\u0012H";
      s[89] = "ep[|2nx \ttHbv \u0000}\u001f5)}[\u0011q4y+Xnvao=[";
      s[90] = "U\fD>>\u001f\u0006\u0013\u0017xZKlF\u0013~\"IS\u0005\u001ei\"\"V\u001b\t{1\u001d\u0015\u0016\u001e{Z";
      s[91] = "70KG\bLb4_^a\u001c;\u000b\\]\u0010\u0018e{H\u0013\u000f\r\\";
      s[92] = "HCd\u000b\u0004~K@n\u001ejgZV>\u0017\u0006U\f\u0014bMV\u0002\fJ2O\u0012y\fF1\rj";
      s[93] = "3g$\u0017OMh~f[\"\u00060yuAG|d#)H@\u001a?~eY\"";
      s[94] = "eyQ#\u001b\u0014<9\tt*G8}|0GE3\u0001\nwVQ7d\u000b2XAU";
      s[95] = "v\u0007J:Xvu\u0004@/6od\u0012\u0010&Z]4PJq634\u0012\t#S2q\u001c\u0019A";
      s[96] = "\u001cA\u0013\r~/H\u0002\bc)]\u001f@\t\u001a!8\u001e\u0005\u0007\nC";
      s[97] = "\u0007p;\u001b}\u001c\u0004`x\u0012\u001b\u0015;,=Du\u0005]w`\bd";
      s[98] = "\u0001L\n\u00028\u0004ZUHNUN\nR7\u000ei\u0005\u0005VQU4I\u00144\n\u000fe[\tRQR)Jk";
      s[99] = "I\u001dU,\u00129\u001a\u0002\u0006jvgpT_}\u0019a\u001a\u0016\u001au\u0017~pR\u001el\rb\u0012W\u0003h\b\u0004";
      s[100] = "S\u000ejV1zP\r`C_cA\u001b0J3Q\u0016\\k\u0017f\u0006\u0011[`C=`J\u0006,R_";
      s[101] = "?P\u00154_\u00157\u0002\u0010m-A\u000e\u0004J1BMdF\u000f9LR\u000e\u0001\u0011gBNu\u0002\u0001$K(";
      s[102] = "r2a@n)wr:B\n;\"faQ\n{)c:Dq{%`x<1}-saU4=vq\u0005";
      s[103] = "BJ&D}r\u0016\t=*+\u0000AK<S\"e@\u000e2C@";
      s[104] = "\u000e\u000f(Op)\u0004\u0014*\u001f\t}\u0004\u0010)M`q=\u001e)]d\u0017\r\u0010+Mxk\u0012G=\u001e\t";
      s[105] = "A`\u001c\u000eS\u0016Zx\u0019^?\u001cRt\"\u000eXNN([\u001e\u0003\u0011Z\u0018L\u0006Y\u0018OdSQOK>";
      s[106] = "#,b.7\u0012$ei,ZD\u007f1j&\r\u0013%a6Jg\u0016.2l,<Kb#";
      s[107] = "S\u0003R~\ft\u0003\nZu} <\u0005O,\ryE\u0015\u0014s\u0019I";
      s[108] = "K9\u001eh3Y\u0018&M.W\u0000rp\u001498\u0001\u00182Q16\u001ervU(,\u0002\u0010sH,)d";
      s[109] = "\u0015\u001cT_<J\u001b\u000b\u0015T^\u0019\b\u0012-\u00009M\u0015^T\u0010b\u0012\u0001nB\be\u0006U\u0017RS:\u0012e";
      s[110] = "\u0014IfK=2\t\u00194CG>\u0007\u0019=J\u0010iYNe&50\u0000\u0010gM\"/Z\f";
      s[111] = "aB\u001dzUud\u0002Fx1f=\u0003\u0010z\\MZD\u0019j\u000ed!D\u0015iL\u001caB\u001dzUud\u0002Fx1";
      s[112] = ",R5\u000eD](VtO{M9QH_\u000bQPDiT\u0016\\,[>BE-";
      s[113] = "\u0016\u0006HF\u0019N\u0018L\u0012ZzH\bqLP\u0006XsRNN\u0017X\u000fM\u0019XD)";
      s[114] = "\u000fC\u001fs\t'TZ]?ds\u0004]\"{Yj\u001cYGz\u001cd\f;\u001b\u007f\u0018o\u0007^\u001a:\u0016\u007fe\u0002\u001f>\u001dt\u0000\u0003Z0\r\u0016";
      s[115] = "~g=\u0013\u0017\u0004pgmU,\u0007g}q\u0005k\u0017\u000e 1\u0014U\u001bk!t\u001aEy~g=\u0013\u0017\u0004pgmU,";
      s[116] = "\u001a*f\u007fF{I559\"$#cl.M#I!)&C<#e-?Y A`0;\\F";
      s[117] = "\u0015%?KZ}\u000evoH3rm hA\\{\u0007b-IRdm)*OZ/Qpj\u0017\r\u001e";
      s[118] = "$\u0011'QwMv\u0012,NN\u0012\u001aBmE!\u0012p\u0000(M/\r\u001aD,T5\u0011xA1P0w";
      s[119] = "fl,t\u0002u?,t#3&;h\u0004yN$V-saJ+3,6oZI";
      s[120] = "[ <7tX\b?oq\u0010\fbi6f\u007f\u0000\b+snq\u001fb`thyT^940.e";
      s[121] = "Y&m:\bVZ%g/fOK37&\n}\u001ctlxV*\u001bsg/\u0004L@.+>f";
      s[122] = "Z* \u001cg5\\+8\u0019Wg9ps\n8kS26\u00026t9**\u000f->\u0002,+\u0017(\u000e";
      s[123] = "U$\n.bhAj\u0015;[}Q'\u001b'7O\u0005j@{c\u0018\u0007;\u0017\u007f#c\u00077\u0014=[";
      s[124] = "O\u0018+\u001e\u0005VJXp\u001caE\u0013Y&\u001e\fot\u001e/\u000e^G\u000f\u001e#\r\u001c?O\u0018+\u001e\u0005VJXp\u001ca";
      s[125] = "MX0,\u0000\u0011C\u0012j0c\u001fD\u000eQ-\u0004MXR(=_\u0012Lb?%\u0005\u001bY\u001e r\u0013H(";
      s[126] = "\u0012\u0019\u001fiz\u0015\u001c\u000e^b\u0018J\u000f\u001a=4d)\u001d\u0013X6tJ\u0006\u000b]f\u0018";
      s[127] = "zx1\u001c2Dy{;\t\\]hmk\u00000o?*0^c88-;\t>^cpw\u0018\\";
      s[128] = "\u0012p\u0016X\u000b)\fp\u0005Xs<\bm\u0012U-;\bw\u0016)H2\u00005\u0003RH>\u0003w{";
      s[129] = "Kp~v$mEg?}F:_on<Fn@\u007f| $k]{yF";
      s[130] = "K\u001f'\u001d|^H\u000fd\u0014\u001aTwC!BtG\u0011\u0018|\u000ee";
      s[131] = "f!\\\u0015% ahW\u0017H}6-P\u0016$Obi\nHH%ga^\u0013.~:-Oquh75]Ir!<70";
      s[132] = "\u000fR}\u001d%1\b\u001bv\u001fHl_^q\u001e$^\u000b\u001a*@H4\u000e\u0012\u007f\u001b.oS^nyu5\u0002Ls\u001f.hN]\u0011Dt9\\@w\u001f)uM\",\t$m_\u001a+@/o2";
      s[133] = "ZLB(\u001cW\tS\u0011nx\u0001c\u0005Hy\u0017\u000f\tG\rq\u0019\u0010c\u0007\u0012yG\u0012\u0018\u0007\u001ez\u0005j";
      s[134] = "\u0019)l<Ee\u0017>-7'!\u0014'\u0015c@b\u0019kls\u001b=\r[zk\u001c)Y\"j0C=i4r7Wi\u0010$)hCY";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = s[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(t[var4]);
            s[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = s[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            s[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  s[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1692973399681353L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = s[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  s[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1692973399681353L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        s[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1692973399681353L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 221;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 201;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 229;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 243;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 106;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 90;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 221;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 201;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 229;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fB_C0273",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Trails var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fB_C0273;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fB_C0273", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Trails)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(long var0) {
         MethodHandle var6 = bindingCache2;
         MethodHandle var5 = bindingCache2;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(J)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/fB_C0273", "lambda$onRenderWorld$1", "(JLdev/zprestige/prestige/f1;)Z"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/f1;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var3.invokeExact((long)var0);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
