package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.RenderCommandList;
import dev.zprestige.prestige.api.util.projectile.ArrowTrajectoryProjectile;
import dev.zprestige.prestige.api.util.projectile.ThrownItemTrajectoryProjectile;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;
import org.joml.Quaternionfc;
import org.joml.Vector3f;

public class Trajectories extends Module {
   private static final float[] a;
   public ModeSetting c;
   public ColorSetting d;
   private ArrayList e = new ArrayList();
   private boolean i = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private ItemStack f;
   private String h;
   private boolean g;
   private boolean j;
   private int k;
   private float l;
   private float m;
   private double n;
   private double o;
   private double p;
   private static final float q = 12.0F;
   private static final float r = 7.0F;
   private static final float s = 20.0F;
   private float t = 0.0F;
   private float u = 0.0F;
   private float v = 0.0F;
   private boolean w = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private long x = 0L;
   private static final long y = 137987257276633L;
   private static final String[] z;
   private static final String[] A;
   private static final Map B = new HashMap(13);
   private static final long[] C;
   private static final Integer[] D;
   private static final Map E;
   private static final long[] F;
   private static final Long[] G;
   private static final Map H;
   private static final Object[] I = new Object[155];
   private static final String[] J = new String[155];

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.Mace;
      CombatProfile var4 = CombatProfile.Crystal;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 96513168821473L ^ 116556103598595L;
      var10001 = 96513168821473L ^ 61750763449638L;
      var10001 = 96513168821473L ^ 32947452796384L;
      var10001 = 96513168821473L ^ 132294115773344L;
      var10001 = 96513168821473L ^ 127632573913000L;
      int var14 = Event.cReturningInt();
      MinecraftClient var30 = b;
      int var196 = var14;
      ClientPlayerEntity var195 = var30.player;
      ClientPlayerEntity var118 = var195;
      ClientPlayerEntity var117 = var195;
      if (var196 != 0) {
         ClientPlayerEntity var197 = var117;
         if (var197 == null) {
            return;
         }

         MinecraftClient var32 = b;
         var118 = var32.player;
      }

      ItemStack var15;
      String var16;
      Vec3d var17;
      byte var18;
      int var19;
      byte var123;
      label237: {
         byte var122;
         label236: {
            label241: {
               ClientPlayerEntity var33 = var118;
               var15 = var33.getMainHandStack();
               ModeSetting var34 = this.c;
               String var35 = (String)var34.aReturningObject();
               var16 = var35.toString();
               MinecraftClient var36 = b;
               Object[] var37 = new Object[]{var36.player, 123069091094983L};
               var17 = GameRenderUtil.bReturningVec3d(var37);
               MinecraftClient var38 = b;
               ClientPlayerEntity var39 = var38.player;
               var18 = ((byte)((var39.isUsingItem()) ? 1 : 0));
               MinecraftClient var40 = b;
               ClientPlayerEntity var41 = var40.player;
               var19 = var41.getItemUseTime();
               Item var43 = Items.CROSSBOW;
               ItemStack var42 = var15;
               byte var10000 = ((byte)((var42.isOf(var43)) ? 1 : 0));
               int var199 = var14;
               byte var198 = var10000;
               byte var120 = var198;
               byte var119 = var198;
               if (var199 != 0) {
                  byte var200 = var119;
                  if (var200 == 0) {
                     break label241;
                  }

                  ItemStack var45 = var15;
                  byte var201 = ((byte)((CrossbowItem.isCharged(var45)) ? 1 : 0));
                  var120 = var201;
               }

               int var203 = var14;
               byte var202 = var120;
               var122 = var202;
               byte var121 = var202;
               if (var203 == 0) {
                  break label236;
               }

               byte var204 = var121;
               if (var204 != 0) {
                  var122 = 1;
                  break label236;
               }
            }

            var123 = 0;
            break label237;
         }

         byte var205 = var122;
         var123 = var205;
      }

      byte var20;
      long var21;
      float var132;
      label224: {
         var20 = var123;
         var21 = System.currentTimeMillis();
         int var210 = var14;
         long var206 = this.x;
         long var128 = var206;
         long var130 = var208;
         long var124 = var206;
         long var126 = var208;
         if (var210 != 0) {
            long var325;
            int var211 = (var325 = var124 - var126) == 0L ? 0 : (var325 < 0L ? -1 : 1);
            if (!((var211) != 0)) {
               float var212 = 0.016F;
               var132 = var212;
               break label224;
            }

            var130 = this.x;
            var128 = var21;
         }

         var132 = (float)(var128 - var130) / 1000.0F;
      }

      float var23;
      int var137;
      label218: {
         int var136;
         label217: {
            label242: {
               var23 = var132;
               long var326;
               int var313 = (var326 = this.x - 0L) == 0L ? 0 : (var326 < 0L ? -1 : 1);
               int var214 = var14;
               int var213 = var313;
               int var134 = var213;
               int var133 = var213;
               if (var214 != 0) {
                  int var215 = var133;
                  if (var215 == 0) {
                     break label242;
                  }

                  long var327;
                  int var216 = (var327 = var21 - this.x - 1000L) == 0L ? 0 : (var327 < 0L ? -1 : 1);
                  var134 = var216;
               }

               int var218 = var14;
               int var217 = var134;
               var136 = var217;
               int var135 = var217;
               if (var218 == 0) {
                  break label217;
               }

               int var219 = var135;
               if (var219 > 0) {
                  var136 = 1;
                  break label217;
               }
            }

            var137 = 0;
            break label218;
         }

         int var220 = var136;
         var137 = var220;
      }

      label205: {
         float var25;
         float var26;
         label204: {
            int var24 = var137;
            this.x = var21;
            float var54 = 0.1F;
            float var53 = var23;
            var23 = Math.min(var53, var54);
            MinecraftClient var55 = b;
            ClientPlayerEntity var56 = var55.player;
            var25 = var56.getPitch();
            MinecraftClient var57 = b;
            ClientPlayerEntity var58 = var57.player;
            var26 = var58.getYaw();
            int var222 = var14;
            Trajectories var221 = this;
            Trajectories var139 = var221;
            Trajectories var138 = var221;
            if (var222 != 0) {
               boolean var223 = var138.w;
               if (var223) {
                  int var224 = var24;
                  if (var224 == 0) {
                     break label204;
                  }
               }

               this.u = var25;
               this.v = var26;
               Trajectories var225 = this;
               var139 = var225;
            }

            var139.w = true;
            int var226 = var14;
            if (var226 != 0) {
               break label205;
            }
         }

         float var321 = this.u;
         Object[] var10007 = new Object[]{null, null, null, null, 81570356302081L};
         var10007[3] = 20.0F;
         var10007[2] = var23;
         var10007[1] = var25;
         var10007[0] = var321;
         Object[] var62 = var10007;
         this.u = bReturningFloat(var62);
         float var322 = this.v;
         float var10002 = this.v;
         Object[] var10005 = new Object[]{null, var26};
         var10005[0] = var10002;
         Object[] var63 = var10005;
         var10002 = cReturningFloat(var63);
         double var64 = -20.0F * var23;
         this.v = var322 + var10002 * (1.0F - (float)Math.exp(var64));
      }

      Object[] var68 = new Object[]{var15, var16, 39393425234761L};
      Trajectories var67 = this;
      byte var27 = ((byte)((var67.aReturningBoolean(var68)) ? 1 : 0));
      byte var229 = var27;
      float var228 = this.t;
      Trajectories var227 = this;
      Trajectories var142 = var227;
      float var143 = var228;
      Trajectories var140 = var227;
      float var141 = var228;
      Trajectories var144;
      float var145;
      float var146;
      if (var229 != 0) {
         float var232 = 1.0F;
         float var231 = var141;
         Trajectories var230 = var140;
         var144 = var230;
         var145 = var231;
         var146 = var232;
      } else {
         var146 = 0.0F;
         var145 = var143;
         var144 = var142;
      }

      byte var237 = var27;
      float var236 = var23;
      float var235 = var146;
      float var234 = var145;
      Trajectories var233 = var144;
      Trajectories var151 = var233;
      float var152 = var234;
      float var153 = var235;
      float var154 = var236;
      Trajectories var147 = var233;
      float var148 = var234;
      float var149 = var235;
      float var150 = var236;
      Trajectories var155;
      float var156;
      float var157;
      float var158;
      float var159;
      if (var237 != 0) {
         float var242 = 12.0F;
         float var241 = var150;
         float var240 = var149;
         float var239 = var148;
         Trajectories var238 = var147;
         var155 = var238;
         var156 = var239;
         var157 = var240;
         var158 = var241;
         var159 = var242;
      } else {
         var159 = 7.0F;
         var158 = var154;
         var157 = var153;
         var156 = var152;
         var155 = var151;
      }

      Trajectories var194;
      label243: {
         int var193;
         label244: {
            label245: {
               Object[] var324 = new Object[]{null, null, null, null, 81570356302081L};
               var324[3] = var159;
               var324[2] = var158;
               var324[1] = var157;
               var324[0] = var156;
               Object[] var71 = var324;
               var155.t = bReturningFloat(var71);
               int var244 = var14;
               byte var243 = var27;
               int var188 = var243;
               byte var160 = var243;
               if (var244 != 0) {
                  byte var245 = var160;
                  if (var245 != 0) {
                     Trajectories var187;
                     int var247 = var14;
                     Trajectories var246 = this;
                     var187 = var246;
                     Trajectories var161 = var246;
                     label187:
                     if (var247 != 0) {
                        Trajectories var248 = var161;
                        Trajectories var162 = var248;
                        boolean var249 = var162.i;
                        if (var249) {
                           ItemStack var251 = this.f;
                           ItemStack var250 = var15;
                           label184:
                           if (var250 == var251) {
                              String var77 = this.h;
                              String var76 = var16;
                              int var314 = (((var76.equals(var77)) ? 1 : 0));
                              int var253 = var14;
                              byte var252 = (byte)var314;
                              byte var165 = var252;
                              byte var163 = var252;
                              if (var253 != 0) {
                                 byte var254 = var163;
                                 byte var164 = var254;
                                 byte var255 = var164;
                                 if (var255 == 0) {
                                    break label184;
                                 }

                                 var165 = var18;
                              }

                              int var258 = var14;
                              byte var257 = ((byte)((this.g) ? 1 : 0));
                              byte var256 = var165;
                              byte var168 = var256;
                              byte var169 = var257;
                              byte var166 = var256;
                              byte var167 = var257;
                              if (var258 != 0) {
                                 byte var260 = var167;
                                 byte var259 = var166;
                                 if (var259 != var260) {
                                    break label184;
                                 }

                                 byte var262 = ((byte)((this.j) ? 1 : 0));
                                 byte var261 = var20;
                                 var168 = var261;
                                 var169 = var262;
                              }

                              int var178;
                              label248: {
                                 int var265 = var14;
                                 byte var264 = var169;
                                 byte var263 = var168;
                                 int var174 = var263;
                                 int var175 = var264;
                                 byte var170 = var263;
                                 byte var171 = var264;
                                 if (var265 != 0) {
                                    byte var267 = var171;
                                    byte var266 = var170;
                                    if (var266 != var267) {
                                       break label184;
                                    }

                                    int var269 = var14;
                                    int var268 = var19;
                                    var178 = var268;
                                    int var172 = var268;
                                    if (var269 == 0) {
                                       break label248;
                                    }

                                    int var270 = var172;
                                    int var173 = var270;
                                    int var272 = this.k;
                                    int var271 = var173;
                                    var174 = var271;
                                    var175 = var272;
                                 }

                                 int var274 = var175;
                                 int var273 = var174;
                                 if (var273 != var274) {
                                    break label184;
                                 }

                                 int var276 = var14;
                                 Trajectories var275 = this;
                                 var187 = var275;
                                 Trajectories var176 = var275;
                                 if (var276 == 0) {
                                    break label187;
                                 }

                                 Trajectories var277 = var176;
                                 Trajectories var177 = var277;
                                 float var328;
                                 int var278 = (var328 = var177.u - this.l) == 0.0F ? 0 : (var328 < 0.0F ? -1 : 1);
                                 var178 = var278;
                              }

                              int var279 = var178;
                              if (var279 == 0) {
                                 int var281 = var14;
                                 Trajectories var280 = this;
                                 var187 = var280;
                                 Trajectories var179 = var280;
                                 if (var281 == 0) {
                                    break label187;
                                 }

                                 Trajectories var282 = var179;
                                 Trajectories var180 = var282;
                                 float var329;
                                 int var283 = (var329 = var180.v - this.m) == 0.0F ? 0 : (var329 < 0.0F ? -1 : 1);
                                 label160:
                                 if (!((var283) != 0)) {
                                    Vec3d var89 = var17;
                                    double var330;
                                    var314 = (var330 = var89.x - this.n) == 0.0 ? 0 : (var330 < 0.0 ? -1 : 1);
                                    int var285 = var14;
                                    int var284 = var314;
                                    int var183 = var284;
                                    int var181 = var284;
                                    if (var285 != 0) {
                                       int var286 = var181;
                                       int var182 = var286;
                                       int var287 = var182;
                                       if (var287 != 0) {
                                          break label160;
                                       }

                                       Vec3d var92 = var17;
                                       double var331;
                                       int var288 = (var331 = var92.y - this.o) == 0.0 ? 0 : (var331 < 0.0 ? -1 : 1);
                                       var183 = var288;
                                    }

                                    int var290 = var14;
                                    int var289 = var183;
                                    int var185 = var289;
                                    int var184 = var289;
                                    if (var290 != 0) {
                                       int var291 = var184;
                                       if (var291 != 0) {
                                          break label160;
                                       }

                                       Vec3d var95 = var17;
                                       double var332;
                                       int var292 = (var332 = var95.z - this.p) == 0.0 ? 0 : (var332 < 0.0 ? -1 : 1);
                                       var185 = var292;
                                    }

                                    int var294 = var14;
                                    int var293 = var185;
                                    var193 = var293;
                                    int var186 = var293;
                                    if (var294 == 0) {
                                       break label244;
                                    }

                                    int var295 = var186;
                                    if (var295 == 0) {
                                       break label245;
                                    }
                                 }
                              }
                           }
                        }

                        Object[] var99 = new Object[]{var15, var16, 67924572376802L};
                        Trajectories var98 = this;
                        var98.jReturningVoid(var99);
                        this.f = var15;
                        this.h = var16;
                        this.g = dev.prestige.recovery.SourceSupport.asBoolean(var18);
                        this.j = dev.prestige.recovery.SourceSupport.asBoolean(var20);
                        this.k = var19;
                        this.l = this.u;
                        this.m = this.v;
                        Vec3d var100 = var17;
                        this.n = var100.x;
                        Vec3d var101 = var17;
                        this.o = var101.y;
                        Vec3d var102 = var17;
                        this.p = var102.z;
                        Trajectories var296 = this;
                        var187 = var296;
                     }

                     var187.i = true;
                     int var297 = var14;
                     if (var297 != 0) {
                        break label245;
                     }
                  }

                  float var333;
                  int var298 = (var333 = this.t - 0.005F) == 0.0F ? 0 : (var333 < 0.0F ? -1 : 1);
                  var188 = var298;
               }

               int var300 = var14;
               int var299 = var188;
               var193 = var299;
               int var189 = var299;
               if (var300 == 0) {
                  break label244;
               }

               int var301 = var189;
               if (var301 < 0) {
                  ArrayList var106 = this.e;
                  byte var316 = ((byte)((var106.isEmpty()) ? 1 : 0));
                  int var303 = var14;
                  byte var302 = var316;
                  var193 = var302;
                  byte var190 = var302;
                  if (var303 == 0) {
                     break label244;
                  }

                  byte var304 = var190;
                  byte var191 = var304;
                  byte var305 = var191;
                  if (var305 == 0) {
                     ArrayList var109 = this.e;
                     var109.clear();
                     this.i = false;
                  }
               }
            }

            int var307 = var14;
            Trajectories var306 = this;
            var194 = var306;
            Trajectories var192 = var306;
            if (var307 == 0) {
               break label243;
            }

            float var334;
            int var308 = (var334 = var192.t - 0.005F) == 0.0F ? 0 : (var334 < 0.0F ? -1 : 1);
            var193 = var308;
         }

         int var309 = var193;
         if (var309 < 0) {
            return;
         }

         var194 = this;
      }

      ArrayList var112 = var194.e;
      Iterator var28 = var112.iterator();

      int var311;
      do {
         Iterator var113 = var28;
         boolean var310 = var113.hasNext();
         if (!var310) {
            break;
         }

         Iterator var114 = var28;
         RenderCommandList var29 = (RenderCommandList)var114.next();
         Object[] var116 = new Object[]{var1, var29, 52317648979777L};
         Trajectories var115 = this;
         var115.kReturningVoid(var116);
         var311 = var14;
      } while (var311 != 0);
   }

   private boolean aReturningBoolean(Object[] var1) {
      String var4;
      ItemStack var5;
      int var6;
      byte var64;
      long var149;
      label141: {
         byte var63;
         var5 = (ItemStack)var1[0];
         var4 = (String)var1[1];
         long var2 = (Long)var1[2];
         var149 = 137987257276633L ^ var2;
         var6 = Event.cReturningInt();
         short var10001 = 28381;
         long var10002 = 2949201434659945429L ^ var149;
         String var11 = "Bows";
         String var10 = var4;
         byte var10000 = ((byte)((var10.equals(var11)) ? 1 : 0));
         int var93 = var6;
         byte var92 = var10000;
         var63 = var92;
         byte var58 = var92;
         label140:
         if (var93 != 0) {
            byte var94 = var58;
            if (var94 == 0) {
               var10001 = 15759;
               var10002 = 3738761330973223049L ^ var149;
               String var14 = "Crossbow";
               String var13 = var4;
               var10000 = ((byte)((var13.equals(var14)) ? 1 : 0));
               int var96 = var6;
               byte var95 = var10000;
               var63 = var95;
               byte var59 = var95;
               if (var96 == 0) {
                  break label140;
               }

               byte var97 = var59;
               byte var60 = var97;
               byte var98 = var60;
               if (var98 == 0) {
                  var10001 = 6443;
                  var10002 = 472281457633692716L ^ var149;
                  String var18 = "All";
                  String var17 = var4;
                  var10000 = ((byte)((var17.equals(var18)) ? 1 : 0));
                  int var100 = var6;
                  byte var99 = var10000;
                  var63 = var99;
                  byte var61 = var99;
                  if (var100 == 0) {
                     break label140;
                  }

                  byte var101 = var61;
                  byte var62 = var101;
                  byte var102 = var62;
                  if (var102 == 0) {
                     var64 = 0;
                     break label141;
                  }
               }
            }

            var63 = 1;
         }

         byte var103 = var63;
         var64 = var103;
      }

      byte var7;
      byte var71;
      label128: {
         byte var70;
         var7 = var64;
         short var161 = 12404;
         long var168 = 293097239202407793L ^ var149;
         String var22 = "Bows";
         String var21 = var4;
         byte var152 = ((byte)((var21.equals(var22)) ? 1 : 0));
         int var105 = var6;
         byte var104 = var152;
         var70 = var104;
         byte var65 = var104;
         label127:
         if (var105 != 0) {
            byte var106 = var65;
            if (var106 == 0) {
               var161 = 22934;
               var168 = 3657665053364636818L ^ var149;
               String var25 = "Bow";
               String var24 = var4;
               var152 = ((byte)((var24.equals(var25)) ? 1 : 0));
               int var108 = var6;
               byte var107 = var152;
               var70 = var107;
               byte var66 = var107;
               if (var108 == 0) {
                  break label127;
               }

               byte var109 = var66;
               byte var67 = var109;
               byte var110 = var67;
               if (var110 == 0) {
                  var161 = 30061;
                  var168 = 8650866225926201454L ^ var149;
                  String var29 = "All";
                  String var28 = var4;
                  var152 = ((byte)((var28.equals(var29)) ? 1 : 0));
                  int var112 = var6;
                  byte var111 = var152;
                  var70 = var111;
                  byte var68 = var111;
                  if (var112 == 0) {
                     break label127;
                  }

                  byte var113 = var68;
                  byte var69 = var113;
                  byte var114 = var69;
                  if (var114 == 0) {
                     var71 = 0;
                     break label128;
                  }
               }
            }

            var70 = 1;
         }

         byte var115 = var70;
         var71 = var115;
      }

      byte var8;
      byte var76;
      label115: {
         byte var75;
         var8 = var71;
         short var164 = 10794;
         long var171 = 2522578608022306595L ^ var149;
         String var33 = "Pearl";
         String var32 = var4;
         byte var155 = ((byte)((var32.equals(var33)) ? 1 : 0));
         int var117 = var6;
         byte var116 = var155;
         var75 = var116;
         byte var72 = var116;
         label114:
         if (var117 != 0) {
            byte var118 = var72;
            if (var118 == 0) {
               var164 = 30061;
               var171 = 8650866225926201454L ^ var149;
               String var36 = "All";
               String var35 = var4;
               var155 = ((byte)((var35.equals(var36)) ? 1 : 0));
               int var120 = var6;
               byte var119 = var155;
               var75 = var119;
               byte var73 = var119;
               if (var120 == 0) {
                  break label114;
               }

               byte var121 = var73;
               byte var74 = var121;
               byte var122 = var74;
               if (var122 == 0) {
                  var76 = 0;
                  break label115;
               }
            }

            var75 = 1;
         }

         byte var123 = var75;
         var76 = var123;
      }

      byte var9;
      byte var80;
      var9 = var76;
      Item var40 = Items.CROSSBOW;
      ItemStack var39 = var5;
      byte var157 = ((byte)((var39.isOf(var40)) ? 1 : 0));
      int var125 = var6;
      byte var124 = var157;
      var80 = var124;
      byte var77 = var124;
      label105:
      if (var125 != 0) {
         byte var126 = var77;
         if (var126 != 0) {
            int var128 = var6;
            byte var127 = var7;
            var80 = var127;
            byte var78 = var127;
            if (var128 == 0) {
               break label105;
            }

            byte var129 = var78;
            byte var79 = var129;
            byte var130 = var79;
            if (var130 != 0) {
               ItemStack var44 = var5;
               return CrossbowItem.isCharged(var44);
            }
         }

         Item var47 = Items.BOW;
         ItemStack var46 = var5;
         var80 = ((byte)((var46.isOf(var47)) ? 1 : 0));
      }

      byte var86;
      int var132 = var6;
      byte var131 = var80;
      var86 = var131;
      byte var81 = var131;
      label98:
      if (var132 != 0) {
         byte var133 = var81;
         if (var133 != 0) {
            MinecraftClient var49 = b;
            ClientPlayerEntity var50 = var49.player;
            var157 = ((byte)((var50.isUsingItem()) ? 1 : 0));
            int var135 = var6;
            byte var134 = var157;
            var86 = var134;
            byte var82 = var134;
            if (var135 == 0) {
               break label98;
            }

            byte var136 = var82;
            byte var83 = var136;
            byte var137 = var83;
            if (var137 != 0) {
               int var139 = var6;
               byte var138 = var8;
               var86 = var138;
               byte var84 = var138;
               if (var139 == 0) {
                  break label98;
               }

               byte var140 = var84;
               byte var85 = var140;
               byte var141 = var85;
               if (var141 != 0) {
                  return true;
               }
            }
         }

         Item var57 = Items.ENDER_PEARL;
         ItemStack var56 = var5;
         var86 = ((byte)((var56.isOf(var57)) ? 1 : 0));
      }

      int var143 = var6;
      byte var142 = var86;
      byte var88 = var142;
      byte var87 = var142;
      if (var143 != 0) {
         byte var144 = var87;
         if (var144 == 0) {
            return false;
         }

         var88 = var9;
      }

      int var146 = var6;
      byte var145 = var88;
      byte var90 = var145;
      byte var89 = var145;
      if (var146 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var90);
      } else {
         byte var147 = var89;
         if (var147 != 0) {
            var90 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var90);
         } else {
            return false;
         }
      }
   }

   private static float bReturningFloat(Object[] var0) {
      float var4 = (Float)var0[0];
      float var5 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var3 = (Float)var0[3];
      long var1 = (Long)var0[4];
      long var10000 = 137987257276633L ^ var1;
      float var10001 = var5 - var4;
      double var7 = -var3 * var6;
      return var4 + var10001 * (1.0F - (float)Math.exp(var7));
   }

   private static float cReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      float var2 = (Float)var0[1];
      return ((var2 - var1) % 360.0F + 540.0F) % 360.0F - 180.0F;
   }

   private void jReturningVoid(Object[] var1) {
      String var4;
      ItemStack var5;
      long var6;
      long var8;
      int var10;
      byte var123;
      long var232;
      label179: {
         byte var122;
         var5 = (ItemStack)var1[0];
         var4 = (String)var1[1];
         long var2 = (Long)var1[2];
         var232 = 137987257276633L ^ var2;
         var6 = var232 ^ 118943874418675L;
         var8 = var232 ^ 1310159598174L;
         int var10000 = Event.cReturningInt();
         ArrayList var16 = this.e;
         var16.clear();
         var10 = var10000;
         short var10001 = 12404;
         long var10002 = 293108324194496730L ^ var232;
         String var18 = "Bows";
         String var17 = var4;
         byte var233 = ((byte)((var17.equals(var18)) ? 1 : 0));
         int var159 = var10;
         byte var158 = var233;
         var122 = var158;
         byte var117 = var158;
         label178:
         if (var159 != 0) {
            byte var160 = var117;
            if (var160 == 0) {
               var10001 = 3465;
               var10002 = 394975631109786912L ^ var232;
               String var21 = "Crossbow";
               String var20 = var4;
               var233 = ((byte)((var20.equals(var21)) ? 1 : 0));
               int var162 = var10;
               byte var161 = var233;
               var122 = var161;
               byte var118 = var161;
               if (var162 == 0) {
                  break label178;
               }

               byte var163 = var118;
               byte var119 = var163;
               byte var164 = var119;
               if (var164 == 0) {
                  var10001 = 30061;
                  var10002 = 8650872733021599173L ^ var232;
                  String var25 = "All";
                  String var24 = var4;
                  var233 = ((byte)((var24.equals(var25)) ? 1 : 0));
                  int var166 = var10;
                  byte var165 = var233;
                  var122 = var165;
                  byte var120 = var165;
                  if (var166 == 0) {
                     break label178;
                  }

                  byte var167 = var120;
                  byte var121 = var167;
                  byte var168 = var121;
                  if (var168 == 0) {
                     var123 = 0;
                     break label179;
                  }
               }
            }

            var122 = 1;
         }

         byte var169 = var122;
         var123 = var169;
      }

      byte var11;
      byte var130;
      label166: {
         byte var129;
         var11 = var123;
         short var256 = 12404;
         long var263 = 293108324194496730L ^ var232;
         String var29 = "Bows";
         String var28 = var4;
         byte var236 = ((byte)((var28.equals(var29)) ? 1 : 0));
         int var171 = var10;
         byte var170 = var236;
         var129 = var170;
         byte var124 = var170;
         label165:
         if (var171 != 0) {
            byte var172 = var124;
            if (var172 == 0) {
               var256 = 4317;
               var263 = 1121548809777549430L ^ var232;
               String var32 = "Bow";
               String var31 = var4;
               var236 = ((byte)((var31.equals(var32)) ? 1 : 0));
               int var174 = var10;
               byte var173 = var236;
               var129 = var173;
               byte var125 = var173;
               if (var174 == 0) {
                  break label165;
               }

               byte var175 = var125;
               byte var126 = var175;
               byte var176 = var126;
               if (var176 == 0) {
                  var256 = 30061;
                  var263 = 8650872733021599173L ^ var232;
                  String var36 = "All";
                  String var35 = var4;
                  var236 = ((byte)((var35.equals(var36)) ? 1 : 0));
                  int var178 = var10;
                  byte var177 = var236;
                  var129 = var177;
                  byte var127 = var177;
                  if (var178 == 0) {
                     break label165;
                  }

                  byte var179 = var127;
                  byte var128 = var179;
                  byte var180 = var128;
                  if (var180 == 0) {
                     var130 = 0;
                     break label166;
                  }
               }
            }

            var129 = 1;
         }

         byte var181 = var129;
         var130 = var181;
      }

      byte var12;
      byte var135;
      label153: {
         byte var134;
         var12 = var130;
         short var259 = 6286;
         long var266 = 3456259009348114468L ^ var232;
         String var40 = "Pearl";
         String var39 = var4;
         byte var239 = ((byte)((var39.equals(var40)) ? 1 : 0));
         int var183 = var10;
         byte var182 = var239;
         var134 = var182;
         byte var131 = var182;
         label152:
         if (var183 != 0) {
            byte var184 = var131;
            if (var184 == 0) {
               var259 = 30061;
               var266 = 8650872733021599173L ^ var232;
               String var43 = "All";
               String var42 = var4;
               var239 = ((byte)((var42.equals(var43)) ? 1 : 0));
               int var186 = var10;
               byte var185 = var239;
               var134 = var185;
               byte var132 = var185;
               if (var186 == 0) {
                  break label152;
               }

               byte var187 = var132;
               byte var133 = var187;
               byte var188 = var133;
               if (var188 == 0) {
                  var135 = 0;
                  break label153;
               }
            }

            var134 = 1;
         }

         byte var189 = var134;
         var135 = var189;
      }

      byte var13;
      byte var147;
      var13 = var135;
      Item var47 = Items.CROSSBOW;
      ItemStack var46 = var5;
      int var241 = (((var46.isOf(var47)) ? 1 : 0));
      int var191 = var10;
      byte var190 = (byte)var241;
      var147 = var190;
      byte var136 = var190;
      label142:
      if (var191 != 0) {
         byte var192 = var136;
         if (var192 != 0) {
            int var194 = var10;
            byte var193 = var11;
            var147 = var193;
            byte var137 = var193;
            if (var194 == 0) {
               break label142;
            }

            byte var195 = var137;
            byte var138 = var195;
            byte var196 = var138;
            if (var196 != 0) {
               int var198 = var10;
               ItemStack var197 = var5;
               ItemStack var141 = var197;
               ItemStack var139 = var197;
               if (var198 != 0) {
                  ItemStack var199 = var139;
                  ItemStack var140 = var199;
                  ItemStack var52 = var140;
                  boolean var200 = CrossbowItem.isCharged(var52);
                  if (!var200) {
                     return;
                  }

                  var141 = var5;
               }

               int var144;
               label135: {
                  ItemStack var55 = var141;
                  CrossbowItem var242 = (CrossbowItem)var55.getItem();
                  MinecraftClient var56 = b;
                  ClientWorld var57 = var56.world;
                  DynamicRegistryManager var243 = var57.getRegistryManager();
                  RegistryKey var58 = Enchantments.MULTISHOT;
                  RegistryKey var60 = var58.getRegistryRef();
                  DynamicRegistryManager var59 = var243;
                  Optional var61 = var59.getOptional(var60);
                  Registry var244 = (Registry)var61.get();
                  RegistryKey var62 = Enchantments.MULTISHOT;
                  Identifier var64 = var62.getValue();
                  Registry var63 = var244;
                  Optional var65 = var63.getEntry(var64);
                  RegistryEntry var245 = (RegistryEntry)var65.get();
                  ItemStack var67 = var5;
                  RegistryEntry var66 = var245;
                  var241 = EnchantmentHelper.getLevel(var66, var67);
                  int var202 = var10;
                  int var201 = var241;
                  int var143 = var201;
                  int var142 = var201;
                  if (var202 != 0) {
                     int var203 = var142;
                     if (var203 <= 0) {
                        var144 = 0;
                        break label135;
                     }

                     var143 = 1;
                  }

                  int var204 = var143;
                  var144 = var204;
               }

               int var15 = var144;
               int var206 = var10;
               int var205 = var15;
               int var145 = var205;
               label128:
               if (var206 != 0) {
                  int var207 = var145;
                  if (var207 != 0) {
                     ArrayList var247 = this.e;
                     float var268 = a[0];
                     Item var70 = Items.ARROW;
                     Object[] var10007 = new Object[]{null, var70.getDefaultStack(), var5, var8};
                     var10007[0] = var268;
                     Object[] var72 = var10007;
                     Trajectories var71 = this;
                     RenderCommandList var74 = var71.bReturninggM_C0349(var72);
                     ArrayList var73 = var247;
                     var73.add(var74);
                     ArrayList var248 = this.e;
                     var268 = a[1];
                     Item var75 = Items.ARROW;
                     var10007 = new Object[]{null, var75.getDefaultStack(), var5, var8};
                     var10007[0] = var268;
                     Object[] var77 = var10007;
                     Trajectories var76 = this;
                     RenderCommandList var79 = var76.bReturninggM_C0349(var77);
                     ArrayList var78 = var248;
                     var78.add(var79);
                     ArrayList var249 = this.e;
                     var268 = a[2];
                     Item var80 = Items.ARROW;
                     var10007 = new Object[]{null, var80.getDefaultStack(), var5, var8};
                     var10007[0] = var268;
                     Object[] var82 = var10007;
                     Trajectories var81 = this;
                     RenderCommandList var84 = var81.bReturninggM_C0349(var82);
                     ArrayList var83 = var249;
                     var83.add(var84);
                     int var208 = var10;
                     if (var208 != 0) {
                        break label128;
                     }
                  }

                  ArrayList var250 = this.e;
                  Item var86 = Items.ARROW;
                  Object[] var273 = new Object[]{null, var86.getDefaultStack(), var5, var8};
                  var273[0] = 0.0F;
                  Object[] var88 = var273;
                  Trajectories var87 = this;
                  RenderCommandList var90 = var87.bReturninggM_C0349(var88);
                  ArrayList var89 = var250;
                  boolean var209 = var89.add(var90);
               }

               int var210 = var10;
               if (var210 != 0) {
                  return;
               }
            }
         }

         Item var93 = Items.BOW;
         ItemStack var92 = var5;
         byte var211 = ((byte)((var92.isOf(var93)) ? 1 : 0));
         var147 = var211;
      }

      byte var153;
      int var213 = var10;
      byte var212 = var147;
      var153 = var212;
      byte var148 = var212;
      label118:
      if (var213 != 0) {
         byte var214 = var148;
         if (var214 != 0) {
            MinecraftClient var96 = b;
            ClientPlayerEntity var97 = var96.player;
            byte var251 = ((byte)((var97.isUsingItem()) ? 1 : 0));
            int var216 = var10;
            byte var215 = var251;
            var153 = var215;
            byte var149 = var215;
            if (var216 == 0) {
               break label118;
            }

            byte var217 = var149;
            byte var150 = var217;
            byte var218 = var150;
            if (var218 != 0) {
               int var220 = var10;
               byte var219 = var12;
               var153 = var219;
               byte var151 = var219;
               if (var220 == 0) {
                  break label118;
               }

               byte var221 = var151;
               byte var152 = var221;
               byte var222 = var152;
               if (var222 != 0) {
                  ArrayList var252 = this.e;
                  Item var102 = Items.ARROW;
                  Object[] var274 = new Object[]{null, var102.getDefaultStack(), var5, var8};
                  var274[0] = 0.0F;
                  Object[] var104 = var274;
                  Trajectories var103 = this;
                  RenderCommandList var106 = var103.bReturninggM_C0349(var104);
                  ArrayList var105 = var252;
                  var105.add(var106);
                  int var223 = var10;
                  if (var223 != 0) {
                     return;
                  }
               }
            }
         }

         Item var109 = Items.ENDER_PEARL;
         ItemStack var108 = var5;
         byte var224 = ((byte)((var108.isOf(var109)) ? 1 : 0));
         var153 = var224;
      }

      int var226 = var10;
      byte var225 = var153;
      byte var155 = var225;
      byte var154 = var225;
      if (var226 != 0) {
         byte var227 = var154;
         if (var227 == 0) {
            return;
         }

         var155 = var13;
      }

      int var229 = var10;
      byte var228 = var155;
      byte var156 = var228;
      if (var229 != 0) {
         byte var230 = var156;
         if (var230 != 0) {
            ArrayList var253 = this.e;
            Object[] var114 = new Object[]{var6};
            Trajectories var113 = this;
            RenderCommandList var116 = var113.aReturninggM_C0349(var114);
            ArrayList var115 = var253;
            boolean var231 = var115.add(var116);
         }
      }
   }

   private void kReturningVoid(Object[] var1) {
      Render3DEvent var2 = (Render3DEvent)var1[0];
      RenderCommandList var3 = (RenderCommandList)var1[1];
      long var4 = (Long)var1[2];
      var4 = 137987257276633L ^ var4;
      long var6 = var4 ^ 21018401359352L;
      long var8 = var4 ^ 138945110418661L;
      int var10000 = Event.bReturningInt();
      ArrayList var11 = var3.recoveryAccess_read_bV();
      int var10 = var10000;
      int var29 = var10;
      ArrayList var28 = var11;
      Object var27 = var28;
      ArrayList var26 = var28;
      if (var29 == 0) {
         ArrayList var15 = var26;
         var10000 = var15.size();
         byte var31 = 1;
         int var30 = var10000;
         if (var30 <= var31) {
            return;
         }

         ColorSetting var18 = this.d;
         var27 = var18.aReturningObject();
      }

      Color var12 = (Color)var27;
      long var13 = System.currentTimeMillis();
      Object[] var10007 = new Object[]{null, null, null, null, var6};
      var10007[3] = var13;
      var10007[2] = var12;
      var10007[1] = var11;
      var10007[0] = var2;
      Object[] var20 = var10007;
      Trajectories var19 = this;
      var19.lReturningVoid(var20);
      ArrayList var21 = var11;
      int var23 = var21.size() - 1;
      ArrayList var22 = var11;
      Vec3d var10002 = (Vec3d)var22.get(var23);
      boolean var10004 = var3.recoveryAccess_read_bW();
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var13;
      var10008[3] = var10004;
      var10008[2] = var12;
      var10008[1] = var10002;
      var10008[0] = var2;
      Object[] var25 = var10008;
      Trajectories var24 = this;
      var24.mReturningVoid(var25);
   }

   private void lReturningVoid(Object[] var1) {
      Render3DEvent var6 = (Render3DEvent)var1[0];
      ArrayList var8 = (ArrayList)var1[1];
      Color var7 = (Color)var1[2];
      long var2 = (Long)var1[3];
      long var4 = (Long)var1[4];
      var4 = 137987257276633L ^ var4;
      long var9 = var4 ^ 39247707227900L;
      long var11 = var4 ^ 25761332828353L;
      long var13 = var4 ^ 125721677912264L;
      int var10000 = Event.bReturningInt();
      ArrayList var22 = var8;
      int var16 = var22.size() - 1;
      short var10001 = 20044;
      long var10002 = 840163021698186171L ^ var4;
      short var63 = 28;
      int var24 = var16;
      int var17 = Math.min(28, var24);
      int var15 = var10000;

      int var49;
      do {
         int var43 = var17;
         int var42 = var18;
         if (var42 >= var43) {
            break;
         }

         float var41;
         label44: {
            int var45 = var15;
            int var44 = var17;
            int var40 = var44;
            int var39 = var44;
            if (var45 == 0) {
               byte var47 = 1;
               int var46 = var39;
               if (var46 == var47) {
                  float var48 = 0.0F;
                  var41 = var48;
                  break label44;
               }

               var40 = var18;
            }

            var41 = (float)var40 / (var17 - 1);
         }

         float var19 = var41;
         float var27 = 255.0F - var19 * 175.0F;
         int var20 = Math.round(var27);
         RenderContext var61 = var6.b;
         MeshBufferManager var64 = var6.a;
         Object[] var10008 = new Object[]{null, null, null, null, var11};
         var10008[3] = var16;
         var10008[2] = var17;
         var10008[1] = var18;
         var10008[0] = var8;
         Object[] var28 = var10008;
         ArrayList var67 = aReturningArrayList(var28);
         var10008 = new Object[]{null, null, var13};
         var10008[1] = var20;
         var10008[0] = var7;
         Object[] var30 = var10008;
         Trajectories var29 = this;
         Object[] var31 = new Object[]{var61, var64, var67, var29.aReturningColor(var30), var9};
         ShapeRenderer.cReturningVoid(var31);
         var18++;
         var49 = var15;
      } while (var49 == 0);

      var63 = 12562;
      var10002 = 7290397476515137116L ^ var4;
      float var58 = (float)(var2 % 1200L) / 1200.0F;
      int var59 = (int)(var58 * var17);
      int var56;
      do {
         byte var51 = 4;
         int var50 = var60;
         if (var50 >= var51) {
            break;
         }

         int var21 = var59 - var60;
         int var52 = var15;
         if (var52 == 0) {
            int var53 = var21;
            if (var53 >= 0) {
               int var55 = var17;
               int var54 = var21;
               if (var54 < var55) {
                  RenderContext var62 = var6.b;
                  MeshBufferManager var66 = var6.a;
                  Object[] var72 = new Object[]{null, null, null, null, var11};
                  var72[3] = var16;
                  var72[2] = var17;
                  var72[1] = var21;
                  var72[0] = var8;
                  Object[] var35 = var72;
                  ArrayList var69 = aReturningArrayList(var35);
                  int var10005 = 2162;
                  long var10006 = 6299723057967005063L ^ var4;
                  short var10007 = 17885;
                  long var73 = 8636972631444598827L ^ var4;
                  var10005 = 255 - var60 * 55;
                  var72 = new Object[]{null, null, var13};
                  var72[1] = var10005;
                  var72[0] = var7;
                  Object[] var37 = var72;
                  Trajectories var36 = this;
                  Object[] var38 = new Object[]{var62, var66, var69, var36.aReturningColor(var37), var9};
                  ShapeRenderer.cReturningVoid(var38);
               }
            }

            var60++;
         }

         var56 = var15;
      } while (var56 == 0);
   }

   private static ArrayList aReturningArrayList(Object[] var0) {
      ArrayList var4 = (ArrayList)var0[0];
      int var3 = (Integer)var0[1];
      int var2 = (Integer)var0[2];
      int var1 = (Integer)var0[3];
      long var5 = (Long)var0[4];
      long var10000 = 137987257276633L ^ var5;
      int var23 = Event.bReturningInt();
      int var8 = var3 * var1 / var2;
      int var9 = (var3 + 1) * var1 / var2;
      ArrayList var10 = new ArrayList(var9 - var8 + 1);
      int var11 = var8;
      int var7 = var23;

      ArrayList var17;
      while (true) {
         int var19 = var9;
         int var18 = var11;
         if (var18 <= var19) {
            int var21 = var7;
            ArrayList var20 = var10;
            var17 = var20;
            ArrayList var16 = var20;
            if (var21 != 0) {
               break;
            }

            int var13 = var11;
            ArrayList var12 = var4;
            Vec3d var15 = (Vec3d)var12.get(var13);
            ArrayList var14 = var16;
            var14.add(var15);
            var11++;
            int var22 = var7;
            if (var22 == 0) {
               continue;
            }
         }

         var17 = var10;
         break;
      }

      return var17;
   }

   private void mReturningVoid(Object[] var1) {
      Render3DEvent var8 = (Render3DEvent)var1[0];
      Vec3d var2 = (Vec3d)var1[1];
      Color var7 = (Color)var1[2];
      boolean var9 = (Boolean)var1[3];
      long var3 = (Long)var1[4];
      long var5 = (Long)var1[5];
      var5 = 137987257276633L ^ var5;
      long var10 = var5 ^ 21786195665293L;
      long var12 = var5 ^ 34174188141013L;
      long var14 = var5 ^ 123033892479594L;
      Vec3d var28 = var2;
      float var16 = (float)var28.x;
      Vec3d var29 = var2;
      float var17 = (float)var29.y;
      Vec3d var30 = var2;
      float var18 = (float)var30.z;
      boolean var53 = var9;
      long var50;
      if (var53) {
         short var10000 = 9124;
         long var10001 = 3399665400510559731L ^ var5;
         long var54 = 700L;
         var50 = var54;
      } else {
         short var60 = 17633;
         long var64 = 2352555206395810487L ^ var5;
         var50 = 1500L;
      }

      long var19 = var50;
      float var21 = (float)(var3 % var19) / (float)var19;
      double var32 = var21 * (float) (Math.PI * 2);
      float var22 = 0.5F * (1.0F + (float)Math.sin(var32));
      boolean var56 = var9;
      float var52;
      if (var56) {
         float var57 = 0.45F;
         var52 = var57;
      } else {
         var52 = 0.25F;
      }

      float var23 = var52 + 0.1F * var22;
      short var10002 = 2162;
      long var10003 = 6299816787263233178L ^ var5;
      Object[] var10005 = new Object[]{null, null, var12};
      var10005[1] = 255;
      var10005[0] = var7;
      Object[] var36 = var10005;
      Trajectories var35 = this;
      Color var24 = var35.aReturningColor(var36);
      RenderContext var61 = var8.b;
      MeshBufferManager var65 = var8.a;
      Object[] var10012 = new Object[]{null, null, var12};
      var10012[1] = 0;
      var10012[0] = var7;
      Object[] var38 = var10012;
      Trajectories var37 = this;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, var24, var37.aReturningColor(var38), var14};
      var10010[5] = var23;
      var10010[4] = var18;
      var10010[3] = var17;
      var10010[2] = var16;
      var10010[1] = var65;
      var10010[0] = var61;
      Object[] var39 = var10010;
      ShapeRenderer.dReturningVoid(var39);
      var61 = var8.b;
      var65 = var8.a;
      float var70 = var23 + 0.08F;
      int var10011 = 30721;
      long var73 = 4645609290165120238L ^ var5;
      Object[] var10014 = new Object[]{null, null, var12};
      var10014[1] = 60;
      var10014[0] = var7;
      Object[] var41 = var10014;
      Trajectories var40 = this;
      var10012 = new Object[]{null, null, null, null, null, null, null, null, var24, var40.aReturningColor(var41), var10};
      var10012[7] = 0.06F;
      var10012[6] = 0.02F;
      var10012[5] = var70;
      var10012[4] = var18;
      var10012[3] = var17;
      var10012[2] = var16;
      var10012[1] = var65;
      var10012[0] = var61;
      Object[] var42 = var10012;
      ShapeRenderer.fReturningVoid(var42);
      boolean var58 = var9;
      if (var58) {
         short var67 = 31555;
         long var69 = 4030905181237275922L ^ var5;
         float var25 = (float)(var3 % 500L) / 500.0F;
         float var26 = 0.3F + var25 * 0.9F;
         float var27 = 1.0F - var25;
         var61 = var8.b;
         var65 = var8.a;
         float var43 = 255.0F * var27;
         int var71 = Math.round(var43);
         Object[] var10013 = new Object[]{null, null, var12};
         var10013[1] = var71;
         var10013[0] = var7;
         Object[] var45 = var10013;
         Trajectories var44 = this;
         Color var10008 = var44.aReturningColor(var45);
         float var46 = 60.0F * var27;
         var10011 = Math.round(var46);
         var10014 = new Object[]{null, null, var12};
         var10014[1] = var10011;
         var10014[0] = var7;
         Object[] var48 = var10014;
         Trajectories var47 = this;
         var10012 = new Object[]{null, null, null, null, null, null, null, null, var10008, var47.aReturningColor(var48), var10};
         var10012[7] = 0.05F;
         var10012[6] = 0.02F;
         var10012[5] = var26;
         var10012[4] = var18;
         var10012[3] = var17;
         var10012[2] = var16;
         var10012[1] = var65;
         var10012[0] = var61;
         Object[] var49 = var10012;
         ShapeRenderer.fReturningVoid(var49);
      }
   }

   private Color aReturningColor(Object[] var1) {
      Color var4 = (Color)var1[0];
      int var5 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 137987257276633L ^ var2;
      Color var6 = var4;
      int var10002 = var6.getRed();
      Color var7 = var4;
      int var10003 = var7.getGreen();
      Color var8 = var4;
      int var10004 = var8.getBlue();
      float var9 = var5 * this.t;
      int var10005 = Math.round(var9);
      byte var10006 = 0;
      short var10007 = 10634;
      long var10008 = 3136587615750986856L ^ var2;
      int var10 = var10005;
      return new Color(var10002, var10003, var10004, MathHelper.clamp(var10, 0, 255));
   }

   private RenderCommandList aReturninggM_C0349(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 137987257276633L ^ var2;
      long var4 = var2 ^ 68192975530198L;
      long var6 = var2 ^ 130472172058306L;
      long var8 = var2 ^ 42154679606140L;
      long var10 = var2 ^ 65039327413169L;
      ArrayList var13 = new ArrayList();
      MinecraftClient var22 = b;
      ClientPlayerEntity var14 = var22.player;
      MinecraftClient var23 = b;
      Object[] var24 = new Object[]{var23.player, var4};
      Vec3d var15 = GameRenderUtil.bReturningVec3d(var24);
      Object[] var25 = new Object[]{var6};
      Vec3d var16 = RaycastUtil.bReturningVec3d(var25);
      int var10000 = Event.cReturningInt();
      Vec3d var26 = var15;
      Vec3d var27 = var15;
      Vec3d var28 = var15;
      double var34 = var28.z;
      double var32 = var27.y;
      double var30 = var26.x;
      ClientPlayerEntity var29 = var14;
      ((LivingEntity)var29).setPosition(var30, var32, var34);
      int var12 = var10000;
      MinecraftClient var36 = b;
      ClientWorld var17 = var36.world;
      Item var37 = Items.ENDER_PEARL;
      ThrownItemTrajectoryProjectile var18 = new ThrownItemTrajectoryProjectile(var17, var14, var37.getDefaultStack(), var10);
      float var44 = 1.0F;
      float var43 = 1.5F;
      float var42 = 0.0F;
      float var41 = this.v;
      float var40 = this.u;
      ClientPlayerEntity var39 = var14;
      ThrownItemTrajectoryProjectile var38 = var18;
      var38.setVelocity((Entity)var39, var40, var41, var42, var43, var44);
      int var66;
      while (true) {
         boolean var67 = var18.a;
         if (!var67) {
            var10000 = var19++;
            int var69 = var12;
            int var68 = var10000;
            var66 = var68;
            int var63 = var68;
            if (var69 == 0) {
               break;
            }

            int var71 = var12;
            int var70 = var63;
            var66 = var70;
            int var64 = var70;
            if (var71 == 0) {
               break;
            }

            int var72 = var64;
            int var65 = var72;
            short var10001 = 19076;
            long var10002 = 6742821204672443613L ^ var2;
            short var74 = 1000;
            int var73 = var65;
            if (var73 < var74) {
               Object[] var47 = new Object[]{var18, var8};
               Vec3d var49 = RaycastUtil.aReturningVec3d(var47);
               ArrayList var48 = var13;
               var48.add(var49);
               ThrownItemTrajectoryProjectile var50 = var18;
               var50.tick();
               int var75 = var12;
               if (var75 != 0) {
                  continue;
               }
            }
         }

         Vec3d var53 = var16;
         ClientPlayerEntity var52 = var14;
         ((LivingEntity)var52).setPosition(var53);
         var66 = 0;
         break;
      }

      int var20 = var66;

      int var78;
      do {
         ArrayList var54 = var13;
         int var77 = var54.size() - 1;
         int var76 = var20;
         if (var76 >= var77) {
            break;
         }

         int var56 = var20;
         ArrayList var55 = var13;
         Vec3d var21 = (Vec3d)var55.get(var56);
         Vec3d var57 = var21;
         Vec3d var58 = var21;
         double var10005 = var58.y - 0.1F;
         Vec3d var59 = var21;
         Vec3d var62 = new Vec3d(var57.x, var10005, var59.z);
         int var61 = var20;
         ArrayList var60 = var13;
         var60.set(var61, var62);
         var20++;
         var78 = var12;
      } while (var78 != 0);

      return new RenderCommandList(var13, true);
   }

   private RenderCommandList bReturninggM_C0349(Object[] var1) {
      long var11;
      int var13;
      ArrayList var14;
      ClientPlayerEntity var16;
      Vec3d var18;
      float var19;
      float var20;
      ArrowTrajectoryProjectile var21;
      long var130;
      label43: {
         float var2 = (Float)var1[0];
         ItemStack var6 = (ItemStack)var1[1];
         ItemStack var5 = (ItemStack)var1[2];
         long var3 = (Long)var1[3];
         var130 = 137987257276633L ^ var3;
         long var7 = var130 ^ 91369640025467L;
         long var9 = var130 ^ 30464866583407L;
         var11 = var130 ^ 82781909479121L;
         var14 = new ArrayList();
         ItemStack var26 = var5;
         Item var15 = var26.getItem();
         MinecraftClient var27 = b;
         var16 = var27.player;
         MinecraftClient var28 = b;
         Object[] var29 = new Object[]{var28.player, var7};
         Vec3d var17 = GameRenderUtil.bReturningVec3d(var29);
         int var10000 = Event.bReturningInt();
         Object[] var30 = new Object[]{var9};
         var18 = RaycastUtil.bReturningVec3d(var30);
         ClientPlayerEntity var31 = var16;
         var19 = ((LivingEntity)var31).getPitch();
         var13 = var10000;
         ClientPlayerEntity var32 = var16;
         var20 = ((LivingEntity)var32).getYaw();
         Vec3d var33 = var17;
         Vec3d var34 = var17;
         Vec3d var35 = var17;
         double var41 = var35.z;
         double var39 = var34.y;
         double var37 = var33.x;
         ClientPlayerEntity var36 = var16;
         ((LivingEntity)var36).setPosition(var37, var39, var41);
         float var44 = this.u;
         ClientPlayerEntity var43 = var16;
         ((LivingEntity)var43).setPitch(var44);
         float var46 = this.v;
         ClientPlayerEntity var45 = var16;
         ((LivingEntity)var45).setYaw(var46);
         MinecraftClient var47 = b;
         var21 = new ArrowTrajectoryProjectile(EntityType.ARROW, var16, var47.world, var6);
         boolean var116 = var15 instanceof CrossbowItem;
         if (var116) {
            float var49 = 1.0F;
            ClientPlayerEntity var48 = var16;
            Vec3d var22 = ((LivingEntity)var48).getOppositeRotationVector(var49);
            Quaternionf var134 = new Quaternionf();
            double var10001 = var2 * (float) (Math.PI / 180.0);
            Vec3d var50 = var22;
            Vec3d var51 = var22;
            Vec3d var52 = var22;
            double var60 = var52.z;
            double var58 = var51.y;
            double var56 = var50.x;
            double var54 = var10001;
            Quaternionf var53 = var134;
            Quaternionf var23 = var53.setAngleAxis(var54, var56, var58, var60);
            float var63 = 1.0F;
            ClientPlayerEntity var62 = var16;
            Vec3d var24 = ((LivingEntity)var62).getRotationVec(var63);
            Vec3d var64 = var24;
            Vector3f var135 = var64.toVector3f();
            Quaternionf var66 = var23;
            Vector3f var65 = var135;
            Vector3f var25 = var65.rotate((Quaternionfc)var66);
            Vector3f var67 = var25;
            var10001 = var67.x();
            Vector3f var68 = var25;
            double var10002 = var68.y();
            Vector3f var69 = var25;
            double var10003 = var69.z();
            float var78 = 1.0F;
            float var77 = 3.15F;
            double var75 = var10003;
            double var73 = var10002;
            double var71 = var10001;
            ArrowTrajectoryProjectile var70 = var21;
            var70.setVelocity(var71, var73, var75, var77, var78);
            int var117 = var13;
            if (var117 == 0) {
               break label43;
            }
         }

         float var139 = this.u;
         float var141 = this.v;
         MinecraftClient var79 = b;
         ClientPlayerEntity var80 = var79.player;
         int var81 = var80.getItemUseTime();
         float var10005 = BowItem.getPullProgress(var81) * 3.0F;
         float var88 = 1.0F;
         float var87 = var10005;
         float var86 = 0.0F;
         float var85 = var141;
         float var84 = var139;
         ClientPlayerEntity var83 = var16;
         ArrowTrajectoryProjectile var82 = var21;
         var82.setVelocity((Entity)var83, var84, var85, var86, var87, var88);
      }

      var21.b = dev.prestige.recovery.SourceSupport.asBoolean(1);
      int var115;
      while (true) {
         boolean var118 = var21.b;
         if (var118) {
            int var136 = var131++;
            int var120 = var13;
            int var119 = var136;
            var115 = var119;
            int var112 = var119;
            if (var120 != 0) {
               break;
            }

            int var122 = var13;
            int var121 = var112;
            var115 = var121;
            int var113 = var121;
            if (var122 != 0) {
               break;
            }

            int var123 = var113;
            int var114 = var123;
            short var138 = 14117;
            long var140 = 2301297500850027728L ^ var130;
            short var125 = 1000;
            int var124 = var114;
            if (var124 < var125) {
               Object[] var92 = new Object[]{var21, var11};
               Vec3d var94 = RaycastUtil.aReturningVec3d(var92);
               ArrayList var93 = var14;
               var93.add(var94);
               ArrowTrajectoryProjectile var95 = var21;
               var95.tick();
               int var126 = var13;
               if (var126 == 0) {
                  continue;
               }
            }
         }

         Vec3d var98 = var18;
         ClientPlayerEntity var97 = var16;
         ((LivingEntity)var97).setPosition(var98);
         float var100 = var19;
         ClientPlayerEntity var99 = var16;
         ((LivingEntity)var99).setPitch(var100);
         float var102 = var20;
         ClientPlayerEntity var101 = var16;
         ((LivingEntity)var101).setYaw(var102);
         var115 = 0;
         break;
      }

      int var132 = var115;

      int var129;
      do {
         ArrayList var103 = var14;
         int var128 = var103.size() - 1;
         int var127 = var132;
         if (var127 >= var128) {
            break;
         }

         int var105 = var132;
         ArrayList var104 = var14;
         Vec3d var133 = (Vec3d)var104.get(var105);
         Vec3d var106 = var133;
         Vec3d var107 = var133;
         double var142 = var107.y - 0.1F;
         Vec3d var108 = var133;
         Vec3d var111 = new Vec3d(var106.x, var142, var108.z);
         int var110 = var132;
         ArrayList var109 = var14;
         var109.set(var110, var111);
         var132++;
         var129 = var13;
      } while (var129 == 0);

      return new RenderCommandList(var14, var21.a);
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(33038507021792L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[10];
      String var28 = "Iy@ð,ßH\fv\u00170[¹Ã.\n\u0010\u0003\u007f\u001b@\u0017\u0081a\u0095¨\u0018¬]\u007f©\tÂ\u0010\u0096µ\f|\\c°/Ç\u0097§2\u001f§i\u0012 \u001b\u009e]N\u0013{äà\u0005iÏùx\u0094¦¦nÕ¸15fîvz\u0084\u000fìT(\u0019'\u0010³dë´^äuóU§¤\fÒ\bøz\u0010\u009a¾¶Ã¹<ÇÎ\u0088°â´ëEnG\u0010â\u000by{\u0002Nd@5;\u0087L¿/ÿ\u0001 ÝX/\u007f,\u0092CéV£§(fZí2``cC¼\u0018\u0016ì¾\u00ad\u0001]W¸Õ\u0098";
      int var30 = "Iy@ð,ßH\fv\u00170[¹Ã.\n\u0010\u0003\u007f\u001b@\u0017\u0081a\u0095¨\u0018¬]\u007f©\tÂ\u0010\u0096µ\f|\\c°/Ç\u0097§2\u001f§i\u0012 \u001b\u009e]N\u0013{äà\u0005iÏùx\u0094¦¦nÕ¸15fîvz\u0084\u000fìT(\u0019'\u0010³dë´^äuóU§¤\fÒ\bøz\u0010\u009a¾¶Ã¹<ÇÎ\u0088°â´ëEnG\u0010â\u000by{\u0002Nd@5;\u0087L¿/ÿ\u0001 ÝX/\u007f,\u0092CéV£§(fZí2``cC¼\u0018\u0016ì¾\u00ad\u0001]W¸Õ\u0098"
         .length();
      char var27 = 16;
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     z = var31;
                     A = new String[10];
                     E = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(33038507021792L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[7];
                     String var15 = "Wéf\u009f\fÂ¡}\"Ü30µââ\u0085\u0007§¼âhÇF\u00010\u0014\u008fñ{\u0004Ó\u0018\u0016Xä\u0084æ±\u0004g";
                     int var16 = "Wéf\u009f\fÂ¡}\"Ü30µââ\u0085\u0007§¼âhÇF\u00010\u0014\u008fñ{\u0004Ó\u0018\u0016Xä\u0084æ±\u0004g".length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    C = var17;
                                    D = new Integer[7];
                                    H = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(33038507021792L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[7];
                                    String var4 = "êK\u008cjqþ\u001aça\u0093è*×:\u0011\u000f\u009c\u0006z}\u0094\u0086ð\u008eS ñ\u0001& ZÛ¥kÀ«\u0017¨\u001a\u008e";
                                    int var5 = "êK\u008cjqþ\u001aça\u0093è*×:\u0011\u000f\u009c\u0006z}\u0094\u0086ð\u008eS ñ\u0001& ZÛ¥kÀ«\u0017¨\u001a\u008e"
                                       .length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   F = var6;
                                                   G = new Long[7];
                                                   a = new float[]{0.0F, -10.0F, 10.0F};
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "x\u008d·Ç\u00989ý>\u0007m\u009a\u0015Å_?_";
                                                var5 = "x\u008d·Ç\u00989ý>\u0007m\u009a\u0015Å_?_".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "1L}'LÛ¯Ã/Ç©¥£\u0085¹\\";
                                 var16 = "1L}'LÛ¯Ã/Ç©¥£\u0085¹\\".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "JÊÒ\u009cÞê\u009d~í½\u000f®ä\u0012ë\u0090\u0010á\nbÒÀ±\u0096{é¹\u0099ÀÙ^\u009b\r";
                  var30 = "JÊÒ\u009cÞê\u009d~í½\u000f®ä\u0012ë\u0090\u0010á\nbÒÀ±\u0096{é¹\u0099ÀÙ^\u009b\r".length();
                  var27 = 16;
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5777;
      if (A[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])B.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               B.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fC", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = z[var5].getBytes("ISO-8859-1");
         A[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return A[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fC_C0275",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14154;
      if (D[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = C[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])E.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               E.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fC", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         D[var3] = var15;
      }

      return D[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fC_C0275",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 13814;
      if (G[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = F[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])H.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               H.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fC", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         G[var3] = var15;
      }

      return G[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fC_C0275",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = J[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = I[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 5;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 2;
            yield var17;
         }
         case 3 -> {
            byte var18 = 13;
            yield var18;
         }
         case 4 -> {
            byte var19 = 42;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 59;
            yield var22;
         }
         case 8 -> {
            byte var23 = 55;
            yield var23;
         }
         case 9 -> {
            byte var24 = 0;
            yield var24;
         }
         case 10 -> {
            byte var25 = 27;
            yield var25;
         }
         case 11 -> {
            byte var26 = 24;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 19;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 40;
            yield var30;
         }
         case 16 -> {
            byte var31 = 23;
            yield var31;
         }
         case 17 -> {
            byte var32 = 21;
            yield var32;
         }
         case 18 -> {
            byte var33 = 16;
            yield var33;
         }
         case 19 -> {
            byte var34 = 7;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 6;
            yield var38;
         }
         case 24 -> {
            byte var39 = 28;
            yield var39;
         }
         case 25 -> {
            byte var40 = 50;
            yield var40;
         }
         case 26 -> {
            byte var41 = 3;
            yield var41;
         }
         case 27 -> {
            byte var42 = 30;
            yield var42;
         }
         case 28 -> {
            byte var43 = 38;
            yield var43;
         }
         case 29 -> {
            byte var44 = 52;
            yield var44;
         }
         case 30 -> {
            byte var45 = 4;
            yield var45;
         }
         case 31 -> {
            byte var46 = 9;
            yield var46;
         }
         case 32 -> {
            byte var47 = 17;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 36;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 25;
            yield var51;
         }
         case 37 -> {
            byte var52 = 48;
            yield var52;
         }
         case 38 -> {
            byte var53 = 11;
            yield var53;
         }
         case 39 -> {
            byte var54 = 37;
            yield var54;
         }
         case 40 -> {
            byte var55 = 15;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 51;
            yield var58;
         }
         case 44 -> {
            byte var59 = 29;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 45;
            yield var63;
         }
         case 49 -> {
            byte var64 = 56;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 57;
            yield var66;
         }
         case 52 -> {
            byte var67 = 1;
            yield var67;
         }
         case 53 -> {
            byte var68 = 10;
            yield var68;
         }
         case 54 -> {
            byte var69 = 35;
            yield var69;
         }
         case 55 -> {
            byte var70 = 14;
            yield var70;
         }
         case 56 -> {
            byte var71 = 34;
            yield var71;
         }
         case 57 -> {
            byte var72 = 8;
            yield var72;
         }
         case 58 -> {
            byte var73 = 60;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 31;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 41;
            yield var77;
         }
         default -> 12;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            J[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      I[0] = "M_{}%fM_l!)iW\u0014l?)|Pe>kx=";
      I[1] = "AB4Q!CAB#\r-L[\t#\u0013-Y\\xqHu\u0018";
      I[2] = "\u0018\u000b^'\u007fb\u0018\u000bI{sm\u0002@Iesx\u00051\u001b>+2";
      I[3] = "\u001es*Z:T\bs/\u0000)C\u001f8,\u0006%W\u000e\u007f;\u0011nB9";
      I[4] = "\u0005=?):h\u000e2.fYe\u001b?!\rlg\n,=!{j";
      I[5] = "_\u0011\u001e7\\jI\u0011\u001bmO}^Z\u0018kCiO\u001d\u000f|\b{~";
      I[6] = int.class;
      J[6] = "java/lang/Integer";
      I[7] = "p\rd\u0001 \u0012p\rs],\u001djFsC,\bm7%\u001bxN";
      I[8] = "7\u0010:!\u001cf7\u0010-}\u0010i-[-c\u0010|**{<C>";
      I[9] = ">\u007fX\u001caH wBS\u0000M wA\u0013.Q";
      I[10] = "\u001aEIauF\u001aE^=yI\u0000\u000e^#y\\\u0007\u007f\u000b| ";
      I[11] = "uZ\u0010\u001fwJuZ\u0007C{Eo\u0011\u0007]{Ph`W\u0000*";
      I[12] = "hm/f3\u000fhm8:?\u0000r&8$?\u0015uWl|h";
      I[13] = "uhk'H\u0002uh|{D\ro#|eD\u0018hR.>\u0013_";
      I[14] = boolean.class;
      J[14] = "java/lang/Boolean";
      I[15] = "x\u00124;{\u0006x\u0012#gw\tbY#yw\u001ce(r&!W";
      I[16] = "\u0004\u0005Tqk^\u0004\u0005C-gQ\u001eNC3gD\u0019?\u0012f0\u0007";
      I[17] = "W,\u0006UR\u000bW,\u0011\t^\u0004Mg\u0011\u0017^\u0011J\u0016CC\u0006R";
      I[18] = "pF/[p\u0017pF8\u0007|\u0018j\r8\u0019|\rm|mM%N";
      I[19] = "\\#@`#\u000b)\u0003Ko2DH\r@d6\u001e<";
      I[20] = "\u001ef:d\u0003^\bf?>\u0010I\u001f-<8\u001c]\u000ej+/WI7";
      I[21] = "\bn7f#5\u0003a&)^-\u0010f/`";
      I[22] = "\u007f:BE\b\u0015t5S\ni\u001b\u007f>WP";
      I[23] = "Wz{+o\u001bIrad\u0000\u001cOzt\u0006(\u001dI";
      I[24] = "6'U{\u000e'6'B'\u0002(,lB9\u0002=+\u001d\u0010mZ}";
      I[25] = void.class;
      J[25] = "java/lang/Void";
      I[26] = "\u0004TSh<vqtXg-9\u0010zSl)cd";
      I[27] = "h'i\u0007r&v/sH\u000f6v";
      I[28] = "\u00133P$7\u000b\u0018<AkJ\u001e\n&C(";
      I[29] = long.class;
      J[29] = "java/lang/Long";
      I[30] = "9\r\u0006\u0014REL-\r\u001bC\n-#\u0006\u0010GPY";
      I[31] = "jr\u0006Y1\u007f|r\u0003\u0003\"hk9\u0000\u0005.|z~\u0017\u0012ekH";
      I[32] = "lB\u001be\b]\u0019b\u0010j\u0019\u0012xl\u001ba\u001dH\f";
      I[33] = float.class;
      J[33] = "java/lang/Float";
      I[34] = "[\u000e\u001b#nsP\u0001\nl\r~E\u0007";
      I[35] = double.class;
      J[35] = "java/lang/Double";
      I[36] = "\u0003X\u001f[X-vx\u0014TIb\u0017v\u001f_M8c";
      I[37] = "\u0006(UT\u0006H\u0006(B\b\nG\u001ccB\u0016\nR\u001b\u0012\u0013NX";
      I[38] = "\nw{\u00050s\u0014\u007faJWr\u0005dl\u0010qt";
      I[39] = "\u0003v\u0016d_cvV\u001dkN,\u0017X\u0016`Jvc";
      I[40] = "P#~cs?F#{9`(Qhx?l<@/o('+C";
      I[41] = "\u0003eo^4vvEdQ%9\u0017KoZ!cc";
      I[42] = "\u0005TnF\u0002\fpteI\u0013C\u0011znB\u0017\u0019e";
      I[43] = ">bx\n9\u001cKBs\u0005(S*Lx\u000e,\t^";
      I[44] = "%{<MJVP[7B[\u00191U<I_CE";
      I[45] = "\nq\u0007>s{\u007fQ\f1b4\u001e_\u0007:fnj";
      I[46] = " vw\u0013\">6vrI1)!=qO==0zfXv*2";
      I[47] = "!\u0001e;h#T!n4yl5/e?}6A";
      I[48] = "/s\\i\u001f\u0013ZSWf\u000e\\;]\\m\n\u0006O";
      I[49] = "\n\u0015h\u000fWe\u0017\u00000-\u0016h\u000f\u0006";
      I[50] = "\u0006]z\u001cG&s}q\u0013Vi\u0012sz\u0018R3f";
      I[51] = ":\u001e\u001e\u0007h\u0018O>\u0015\byW.0\u001e\u0003}\rZ";
      I[52] = "r\"\u0013h\\vr\"\u00044Pyhi\u0004*Plo\u0018Ts\u0002-";
      I[53] = "C1\u0017\u001bQ\u0018A/^c^\u0014X,\u0002\u0006]";
      I[54] = "(&6Tpm(&!\b|b2m!\u0016|w5\u001csI-=";
      I[55] = "\u0006\u000ba#)J\u0004\u0015(\\6D\u001d\u001ctc*J\u0007\u001f";
      I[56] = "[\u00127o\b7M\u001225\u001b ZY13\u00174K\u001e&$\\ j";
      I[57] = ")@(\u001d|\u001f)@?Ap\u00103\u000b?_p\u00054zm\u0001(A";
      I[58] = "3UjaCd3U}=Ok)\u001e}#O~.o/}\u00174";
      I[59] = "E\u001c\u0006X15E\u001c\u0011\u0004=:_W\u0011\u001a=/X&CAio";
      I[60] = "4y\u001d\u0003\u0012F\"y\u0018Y\u0001Q52\u001b_\rE$u\fHFUc";
      I[61] = "j{J>XX\u001f[A1I\u0017~UJ:MM\n";
      I[62] = "\u001f\u001b\u0013U`V\u001d\u0005Z*\u007fX\u0004\f\u0006\u0015cV\u001e\u000f\u0017";
      I[63] = "?i\u001f.\u0000rJI\u0014!\u0011=+G\u001f*\u0015g_";
      I[64] = "\u0011oS\u0016\u0003&\u0007oVL\u00101\u0010$UJ\u001c%\u0001cB]W1#";
      I[65] = "#%Aq\u0014!\u007fu\u000f5\u000bBh\u001c\u0019/\u0007-k \u0010?\u0019=\u001a";
      I[66] = ":\u000eW?<Uf^\u0019{#6s7\u000fa/Yr\u000b\u0006q1I\u0003";
      I[67] = "\u000e\"w\tnP\u0001dI\u000enQ\n4\u001eP6\u0004QX9\u001ei[\u00154r^`";
      I[68] = "^\t\u001alqGOOB-\u0018O!\u000fN-vYD\tN|$M!V\u0007n)\u001e\u001c[Ery#";
      I[69] = "\u0003ik8t7\t2v2\u0019&\u001d+o?\u007f1<0p?\\,\u00045t)\u0019.\u00197u)f$]lgR";
      I[70] = "L\u0002%2CCNT(g\u00112\u0010V)6\u0014^\"\u0006elC2\u0013[$9\u0002\u000e\u001aK:)sJ\u0012T$:IL\u0013I.V";
      I[71] = "\"[fYIi#_#X\u0002U`\f%*\u0016:\u007f\f\u0010\u0013\u0011.\u001b\u00069\u0004\u001a'\"]8\r\u0015U|\u0001>\t\u0002l'\u00007\u0006p2{\u00063\u0011Iiz\u000f<c\u00175|\u000b+ZL4u\u0004YZJj!Xe[N/ \u0013Y";
      I[72] = "i+6E\u001fB`ya\u0010tU48fL\u0018gbz:\u0016H0?$wD\u0005\f64iTt";
      I[73] = "\r7Bd%G\u000faO1w6QcN`rZc5\t=*\n4vUodZ\u000epTrn6TwJ1(\u000bY5Va\u0015";
      I[74] = "^z.B0<\u0007l`\u0019\\(Y{\u001e@<<Wl\"I,\"G\u001dxF-\"I!qV328{~W3<\u0004rnI#M";
      I[75] = "\u0007\u0004PF>0X\b\n\u0014Uf=Q\u000f\u0017;q\u0000ZGQk\u000f\u0006S\u000bD+2\r\u001bM\u0014U";
      I[76] = "b\u001f\u001fO@/0]\u0012\u0017NV>I\u0003OG:\f\u001eC\u001e\u0019g[\u001dC\u0016\\(5\u001c\u0002FI5[B\u001f^O'gK\u000f@_V=D\u000e@Qj4T\u0010P 0;U\u0010^\u001c9+K\u0000/F6*K\u000e\u0013O&4[\u007fI@'4UC@P9$$\u001fVXgf\u0019\u0012\u0014D7[";
      I[77] = "*V\u00035'\\w\u0016D*\u0017Fz\u001bX#{t+Y\u0007y&#*\u001fD#p\u001f)\u0005C<\u0017\u001dm^Q-pA,YZD";
      I[78] = "D<Cr~f\u0018`C{7Z\u0013aUzj\rC9\u0002$\u0006cA{Tf:?\u001d{]/";
      I[79] = "g\u000b\u007f\u0002M\u0001vM'C$\u000b\u0018\r+CJ\u001f}\u000b+\u0012\u0018\u000b\u0018Tb\u0000\u0015X%Y \u001cEe";
      I[80] = "W\u001c\u00180\u001f'\b\u0010BbtqmKNg\u001ab\bMN6HvmC\u0005%\b{\u0017\u0002\u0005bH\u0018";
      I[81] = "4kl\u0014mx=9;A\u0006oix<\u001dj]?:`G;\nbd-\u0015w6kt3\u0005\u0006";
      I[82] = "%^\u0010\nS\u0002-M\n\u0011<]1V\u000bmRP8\u001f\u001c\u0002B\u0003:Vw";
      I[83] = "1`\u0006\u001ek<plH\rT m,\u0017\u00168\u0012?oGHT|\u007f,\f\u001e6|q?Gqe>y,\u0014\u000b$>>lw";
      I[84] = "z|\u0001UHo+~\rT%h}r\u0002\nIZ 4XP%fb2\u0004P\u0018n.t_m\u001crlu\r\u000f\u001c|\u007f>bQDdovZ\u0011\\m`\u000e";
      I[85] = "V0\u0005]\u0014i\u001a(\u0012E*>J(6SFQ\u001b5\u0005ARi[-\fN*";
      I[86] = "\u001d\u0017x\u00075(MPfFxDABb\u0017\"(s\u0016#Ly|$\u0013\u007f\u001e:<\u001cSg\u00175D\u0018Nw\b=|XV~\u0007ExEFa\u000f}8]Onwy%MPfO9=D_\u001e";
      I[87] = "8^\rmd\u0002gRW?\u000fW\u0002\t[:aGg\u000f[k3S\u0002]\nfeE`\u0000\u000185=";
      I[88] = "%\u0003\u0002At\n4\u0002\u001aS\u0004\u00052F\u000eT\u007fh%P\u0003\to\u00075\u0003\u0001@\u0004Y0B\u001bS~\u00180\u0005[0";
      I[89] = "\u00188\u001cq;v\u001e9\u0001{W\"\u00012\u0017l\u0000u[bI\u00000,\u00075\u00019k-\u000e:";
      I[90] = "\u00103a\u0003\u001c<\u00162|\tph\t9j\u001e'?Si7r\u0017f\u000f>|KLg\u00061";
      I[91] = "/\u0007V4\u0006e-Q[aT\u0014sSZ0QxA\u0005\u0018l\u000b+\u0016XF!Ye*QV?I\u0014vG^a\u000b){\u0005B16";
      I[92] = "wV6;6B<\u0016?\\(C{H70\u001a\u00117\u0015l\\tQ{S?>t_h\u0018P";
      I[93] = "d\u007f66j\u000f=ixm\u0006\u0004ee`>\u0006\u0018bii#:\u0011rwyR:\u001fkg~jz\u0007bh\u0006";
      I[94] = "\"\u0010Sc~s~@\u001d'a\u0010aN\u00114`}\u001b\u0010Rl{ztWV$|i\u001b\u0010Tc\"rxL\u0004-fm\u001b";
      I[95] = "8X \bp11Ib\\J?*Gb[69,*aJ-99\u0013iY7\"V";
      I[96] = ". {RS\u0002q,!\u00008W\u0014w-\u0005VGqq-T\u0004S\u0014(}OWL(!mQG=";
      I[97] = "\u0003 <5^\u0014Qb1mPm_v 5Y\u0001m$`e\u0003m]{;?LT\u0006z20>\nZ|6'\u0007Q[u9UY\r]q.l\u0002\fT~\\3^\u001cUj`:N\u0002E\u001b:5O\u0002K'3%Q\u0012:{%-\u000fP\u0007vg1_m";
      I[98] = "\u0000S\ts+kSW\rqx\tSm\u000ex~gC\b\bx/5WmO/*xUWI.7r9";
      I[99] = "ylZu\u007f\bp}\u0018!E\bzbbs$\u000ehfZ3<\u0007g\u001e\f$!^|q\u001cw#\u0017\u0017";
      I[100] = "\u0010.@, u\u001emH&JrAx\u001d \u001d%\u001e%FLu&E~\u001cpt%\u001a~";
      I[101] = "\n.H1\u0015u\bxEdG\u0004VzD5Bhd,\u0006i\u0018:3qX$Ju\u000fxH:Z\u0004Sn@d\u00189^,\\4%";
      I[102] = "CT\u0017rY6\u0002TW _\t\u001f\t\u0013\u007fXe-YP \u0004\t\u001a\u001d\u0017.\u00024\u0017_\u000b~?";
      I[103] = "n\u001fC-[|1\u0013\u0019\u007f0*TH\u0015z^91N\u0015+\f-T\u0000A(S}lLY?KC";
      I[104] = "#C\u0015~$T|OO,O\u0002\u0019\u0014C)!\u0011|\u0012Cxs\u0005\u0019@\u0012u%\u0013{\u001d\u0019+uk";
      I[105] = "H}<\u0001F\u001fAl~U|\u0011]BaC\u0000\u0001&>\u007fB\u0000\u0013\\\u007f\u007f\u0005@p";
      I[106] = "\u0010\bF\u0007!B\u0012^KRs3L\\J\u0003v_~\f\u0006Z-3NQQ\tc\n\u0015PX\u0006\u0011TIV\\\u0011(\u000fH_ScvSN[DZ-RGT6\u0003hK\u0018\f\u000b\u000e*WH1";
      I[107] = "3$)O\u001e\u0011l(s\u001duL\ts\u007f\u0018\u001bTlu\u007fII@\t*6[D\u00134'tG\u0014.";
      I[108] = "'+?n\u001eT{j8ew\\t-\u0006i\u001cW :iyOUiQ";
      I[109] = "\u001eU&bO2RM1zqe\u0002M\u0000{\u001cg\t1s`\u0018u\u0017\t3x\u0011zo";
      I[110] = "Tzl'G_](;r,H\ti<.@zZ,et,\u001c\u001fl *V]\u001f+`I";
      I[111] = "\u0000\f/TwI_\u0000u\u0006\u001c\u001d:[y\u0003r\f_]yR \u0018:\u0004)Is\u0007\u0006\r9Wcv";
      I[112] = "P\u001eaz@?V\u001f|p,`E\u0005nl@R\u0014G23\u001d\u0005\u0011@05NfM\u0010~qQ\u0005";
      I[113] = "<PK.dP:\u0005\u001d6[\u0002\u0000W@\"$\u00108\u0017X++h";
      I[114] = "%-;^X@|;u\u00054J\",\u000b]TV)82\u0006U_&JlZS[1s7[ZTC";
      I[115] = "b\u0002GKEOb\fT\u0000*H6\u0001[WFzdL\u0003\u0001*]%\u001b\\KF\u0016e\u0012;";
      I[116] = "\t\u0007{\u0002(cUNt\u000eS>\u0005?q\u00057`\u0000PaV5)kQt\nj2\u0004A'\b#Y\t\u0007{\u0002(cUNt\u000eS";
      I[117] = "6\u001aG<p\u001bo\f\tg\u001c\u0007 \u0005w?|\r:\u000fNd}\u00045}\u00108{\u0000\"DK9r\u000fP";
      I[118] = "1J_\u000f3T8[\u001d[\t@>J\n55Z6G\u001f\ruB?Hg";
      I[119] = "n\u001aW$(\u0019hO\u0001<\u0017JR\u001d\\(hYj]D!g!";
      I[120] = "\nF7N\u0015\u001eUJm\u001c~E0\u0011a\u0019\u0010[U\u0017aHBO0H(ZO\u001c\rEjF\u001f!";
      I[121] = "K\fb\u000e\u001bQZJ:Or^4\n6O\u001cOQ\f6\u001eN[4S\u007f\fC\b\t^=\u0010\u00135";
      I[122] = "\u001f|h\r.[\u001e\u007f7\rK\u0002M:m\u0001'0\u001b~6Zzg\u001dw6\u0017{\u0018@7q\bK";
      I[123] = "c$oFf[eq9]ZC\u0006poYcAi`<[**";
      I[124] = "Ah>\u0003%9Gi#\tImXb5\u001e\u001e:\u00022ir.c^e#KubWj";
      I[125] = "\\|J2\u0005QR?B8oV\r*\u0017>8\u0001S}OR_W\\)\u0018 V\u0005\u000b|";
      I[126] = "!\u0005mI6\u0016}U#\r)ui<5\u0017%\u001ai\u0000<\u0007;\n\u0018";
      I[127] = "^X)S;@Q\u001e\u0017T;AZN@\nd\u0017\u0002\"gD<KEN,\u00045";
      I[128] = "rY\u000e2\u0010Z}\u001dG\"aXu\u001c\u001f?\rj!XEbZ=r\u0005C'\u001cEqZ\u0010ha\u0003bY\u00161\u0006_#^\u001dX";
      I[129] = "\u001c-\u000eB*&\r,\u0016PZ8\u0015N\u0017I;\"\u001d\u0015\u0005\u000b?5\u0002w\u0014\n''r";
      I[130] = "hQ9^}\\`B#E\u0012\u0005xR\u0018Tb\u0019\u0011\u0018%@n\u0006kY%\u0007.e";
      I[131] = "L\u0014\u001f<CE\u0015\u0002Qg/QK\u0015/dN]U\u000b\u0017$VTZs\u00139FKRKS!OD*ON1PL\u0012\u000fV8_4";
      I[132] = "1\u0015*=-\u001e8\u0004hi\u0017\n2\u001b\u0012;v\u0018 \u001f*{n\u0011/g|lsH4\bl?q\u0001_\tyc.\u001a0\u0019*agq";
      I[133] = "W\u0011]>,$\u0016R\f9lF\u000bA@?:*9\u0013\u0003egFRMU %~\u0012U\\/] \u000e]S.a)\u001eCC_";
      I[134] = "o\u001d\u001a[$\u0002mK\u0017\u000evs3I\u0016_s\u001f\u0001\u001dZ\u000f*OVB\nN{\u0002jK\u001aPks.C\u0005NxI(B\u0018D\u0014";
      I[135] = "\u0018P\b\u001ao~KT\f\u0018<\u001cHn\u000f\u0011:r[\u000b\t\u0011k OnNFnmMTHGsg!";
      I[136] = "?h2B'\u00020.\fE'\u0003;~[\u001b}_n\u0012|U \t$~7\u0015)";
      I[137] = "8~i7l\u0016:(db>gd*e3;\u000bV|'oa[\u0001!y\"3\u0016=(i<#g";
      I[138] = "<H\u0004S^\u0000pP\u0013K`W P'T\u001dUM\u0010\fY\u001f@uP\u0014P\u00108";
      I[139] = "\u0010\u0018)D\fZ\u0019J~\u0011gMM\u000byM\u000b\u007f\u001eO%\u0015g\u0011_\u000bbE\u0005\u0011Q\u0018)*";
      I[140] = "\fpEE`+^2H\u001dnRP&YEg>bv\u001a\u001a;RU2]\u0014=oXpAD\u0000";
      I[141] = "|r}^)\u001cww%\u001d\u0012\u0010\u0007p/[|\u0000bv/\n.\u0014\u00071x\u000fc\u0016=7y\u0012iz";
      I[142] = "4_I+qhkS\u0013y\u001a>\u000e\b\u001f|t-k\u000e\u001f-&9\u000e_]\u007f maVL=tW";
      I[143] = ">XQ\u0007jG1\u001eo\u0000jF:N8^2\u0013d\"\u001f\u0010mL%NTPd";
      I[144] = "'aE+^>.p\u0007\u007fd8%\u007f}\u007f\u000f5px\u0012o\\79\u0013Lj\u001d-*i\rjZmI";
      I[145] = "zqz\u0016_&(mf\\nwtg}J9(,2)&Saim~\u001aP{nr";
      I[146] = "\u0016C\u001cH]]\u001f\u0011K\u001d6JKPLAZx\u0018\u0014\u0010\u00166\u0013GES^\u000eS_L\\&";
      I[147] = ":b\"PT\u00063s`\u0004n\u00020}s\u0010n\t-h+WS\u0004ot{j";
      I[148] = ",e0\u001aS\rmepHU2p84\u0017R^BotF\f\u0003\u0015ltNIL{m5\u001e\\Q\u00153(\u0006ZC):8\u0018J2s59\u0018D\u000ez%'\b5Tu$'\u0006\t]e:7wSRd:9KZBz*H\u0011UCz$t\u0018E]jU(\u000eM\u0003(h%LQS\u0015";
      I[149] = "X\u00153\u001b\u001f\u0011\u0007\u0019iItMbBeL\u001aT\u0007De\u001dH@b\u001b,\u000fE\u0013_\u0016n\u0013\u0015.";
      I[150] = "\u00170l\u0002'O\u0017>\u007fIHHC3p\u001e$z\u0015v-Ft-^1v\u001e3A\u0015q\u007fyyVW3s\u00038V\u0010s\u0010";
      I[151] = "8j\u0011V\u001fF;p\u0016Ix\u001fhn\rV\u0014-?#T\u000eGzowQN\u0005\u0002l(\u0002\u0001x";
      I[152] = "k0X\u000e\u0003k4<\u0002\\h1Qg\u000eY\u0006.4a\u000e\bT:Q>G\u001aYil3\u0005\u0006\tT";
      I[153] = "\u001at2\u0003\u0004n\u0018\"?VV\u001fF >\u0007Sstv|[\t\"#+\"\u0016[n\u001f\"2\bK\u001f";
      I[154] = "U\u0016yO{TV\f~P\u001c\r\u0005\u0012eOp?U^?\u0017'hU\u0016yO{TV\f~P\u001c";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = I[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(J[var4]);
            I[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = I[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            I[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  I[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1558901247059229L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = I[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  I[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1558901247059229L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        I[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1558901247059229L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 186;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 111;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 194;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 239;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 69;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 83;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 186;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 111;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 194;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fC_C0275",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
