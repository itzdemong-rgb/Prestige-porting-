package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.accessor.MouseAccessor;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.PostAttackEvent;
import dev.zprestige.prestige.api.events.ExtendedTargetingEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.client.management.KeybindManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.util.DroppedItemUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.SocialsManager;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class Triggerbot extends Module {
   private MultiModeSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private MultiModeSetting e;
   private MultiModeSetting f;
   private BooleanSetting g;
   private BooleanSetting h;
   private BooleanSetting i;
   private MinMaxSetting j;
   private MinMaxSetting k;
   private BooleanSetting l;
   private FloatSetting m;
   private MinMaxSetting n;
   private ElapsedTimer o;
   private ElapsedTimer p;
   private int q;
   private int r;
   private boolean s;
   private boolean t;
   private long u;
   private double v;
   private static final long w = 64770974064563L;
   private static final String[] x;
   private static final String[] y;
   private static final Map z = new HashMap(13);
   private static final long A;
   private static final Object[] B = new Object[150];
   private static final String[] C = new String[150];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public Triggerbot() {
      super();
      long var10001 = 37294728448772L ^ 71338411080749L;
      var10001 = 37294728448772L ^ 118108804973011L;
      var10001 = 37294728448772L ^ 74771426202219L;
      var10001 = 37294728448772L ^ 68846341339603L;
      var10001 = 37294728448772L ^ 124425531015336L;

      this.o = new ElapsedTimer(106698256430889L);
      this.p = new ElapsedTimer(106698256430889L);
      this.q = -1;
      this.r = -1;
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.u = System.nanoTime();
      this.v = 20.0;
      MinMaxSetting var10000 = this.k;
      Object[] var14 = new Object[]{invokeBinding1(this), 112057026795887L};
      MinMaxSetting var13 = var10000;
      var13.aReturningMinMaxSetting(var14);
      FloatSetting var29 = this.m;
      Object[] var16 = new Object[]{invokeBinding2(this), 34595201528535L};
      FloatSetting var15 = var29;
      var15.aReturningFloatSetting(var16);
      MultiModeSetting var30 = this.f;
      Object[] var18 = new Object[]{invokeBinding3(this), 81913655528151L};
      MultiModeSetting var17 = var30;
      var17.aReturningMultiModeSetting(var18);
      BooleanSetting var31 = this.l;
      Object[] var20 = new Object[]{invokeBinding4(this), 88791076916140L};
      BooleanSetting var19 = var31;
      var19.aReturningBooleanSetting(var20);
      BooleanSetting var32 = this.d;
      Object[] var22 = new Object[]{invokeBinding5(this), 88791076916140L};
      BooleanSetting var21 = var32;
      var21.aReturningBooleanSetting(var22);
      FloatSetting var33 = this.c;
      Object[] var24 = new Object[]{invokeBinding6(this), 34595201528535L};
      FloatSetting var23 = var33;
      var23.aReturningFloatSetting(var24);
      var10000 = this.n;
      Object[] var26 = new Object[]{invokeBinding7(this), 112057026795887L};
      MinMaxSetting var25 = var10000;
      var25.aReturningMinMaxSetting(var26);
      MultiModeSetting var35 = this.e;
      Object[] var28 = new Object[]{invokeBinding8(this), 81913655528151L};
      MultiModeSetting var27 = var35;
      var27.aReturningMultiModeSetting(var28);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   public void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 64770974064563L ^ var2;
      int var18 = Event.bReturningInt();
      long var5 = System.nanoTime();
      int var4 = var18;
      long var7 = var5 - this.u;
      int var16 = var4;
      if (var16 == 0) {
         long var19;
         int var17 = (var19 = var7 - A) == 0L ? 0 : (var19 < 0L ? -1 : 1);
         if (var17 > 0) {
            double var9 = var7 / 1.0E9;
            double var14 = 1.0 / var9;
            double var12 = 20.0;
            this.v = Math.min(var12, var14);
         }

         this.u = var5;
      }
   }

   private double aReturningDouble(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 64770974064563L ^ var3;
      double var11 = 20.0;
      double var9 = 10.0;
      double var7 = this.v;
      double var5 = Math.clamp(var7, var9, var11);
      return var2 + (1.0F - var2) * ((20.0 - var5) / 10.0);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      this.q = -1;
      Object[] var5 = new Object[0];
      Triggerbot var4 = this;
      var4.kReturningVoid(var5);
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      this.q = -1;
      Object[] var5 = new Object[0];
      Triggerbot var4 = this;
      var4.kReturningVoid(var5);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var4 = Event.cReturningInt();
      int var11 = var4;
      if (var11 != 0) {
         Object[] var6 = new Object[0];
         PacketReceiveEvent var5 = var1;
         boolean var12 = var5.aReturningVoid(var6) instanceof PlayerRespawnS2CPacket;
         if (!var12) {
            return;
         }

         this.q = -1;
      }

      Object[] var10 = new Object[0];
      Triggerbot var9 = this;
      var9.kReturningVoid(var10);
   }

   private void kReturningVoid(Object[] var1) {
      this.r = -1;
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.t = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void lReturningVoid(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      byte var5 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[1]))))))))) ? 1 : 0);
      long var2 = (Long)var1[2];
      long var10000 = 64770974064563L ^ var2;
      int var6 = Event.bReturningInt();
      byte var33 = ((byte)((var4 instanceof PlayerEntity) ? 1 : 0));
      int var22 = var6;
      byte var21 = var33;
      int var16 = var21;
      byte var15 = var21;
      if (var22 == 0) {
         byte var23 = var15;
         if (var23 == 0) {
            Object[] var9 = new Object[0];
            Triggerbot var8 = this;
            var8.kReturningVoid(var9);
            return;
         }

         Entity var11 = var4;
         var16 = var11.getId();
      }

      label25: {
         int var26 = var6;
         int var25 = this.r;
         int var24 = var16;
         int var19 = var24;
         int var20 = var25;
         int var17 = var24;
         int var18 = var25;
         if (var26 == 0) {
            int var28 = var18;
            int var27 = var17;
            if (var27 != var28) {
               break label25;
            }

            byte var30 = ((byte)((this.t) ? 1 : 0));
            byte var29 = var5;
            var19 = var29;
            var20 = var30;
         }

         int var32 = var20;
         int var31 = var19;
         if (var31 == var32) {
            return;
         }
      }

      Entity var14 = var4;
      this.r = var14.getId();
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.t = dev.prestige.recovery.SourceSupport.asBoolean(var5);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 90961768720402L ^ 92812106445027L;
      var10001 = 90961768720402L ^ 28620151524305L;
      var10001 = 90961768720402L ^ 10861562340271L;
      var10001 = 90961768720402L ^ 139952123799382L;
      var10001 = 90961768720402L ^ 2078521141620L;
      var10001 = 90961768720402L ^ 25625979966986L;
      var10001 = 90961768720402L ^ 41412962644585L;
      var10001 = 90961768720402L ^ 100156301325861L;
      var10001 = 90961768720402L ^ 11139836472803L;
      var10001 = 90961768720402L ^ 54633404909206L;
      var10001 = 90961768720402L ^ 36769863194205L;
      var10001 = 90961768720402L ^ 63944323966034L;
      var10001 = 90961768720402L ^ 127886867349522L;
      var10001 = 90961768720402L ^ 53871026730875L;
      var10001 = 90961768720402L ^ 96459285440510L;
      var10001 = 90961768720402L ^ 20069731529340L;
      var10001 = 90961768720402L ^ 58644611391482L;
      var10001 = 90961768720402L ^ 73719138203566L;
      var10001 = 90961768720402L ^ 43656586407151L;
      int var10000 = Event.bReturningInt();
      Object[] var52 = new Object[]{5497601658860L};
      Triggerbot var51 = this;
      var51.jReturningVoid(var52);
      int var42 = var10000;
      int var503 = var42;
      if (var503 == 0) {
         MinecraftClient var53 = b;
         ClientPlayerEntity var504 = var53.player;
         if (var504 != null) {
            MinecraftClient var55 = b;
            ClientWorld var505 = var55.world;
            if (var505 != null) {
               MinecraftClient var353;
               label680: {
                  // int var506 = this.q;
                  label679:
                  if (var506 != var507) {
                     label688: {
                        MinecraftClient var60 = b;
                        int var62 = this.q;
                        ClientWorld var61 = var60.world;
                        Entity var43 = var61.getEntityById(var62);
                        int var509 = var42;
                        Entity var508 = var43;
                        Entity var348 = var508;
                        Entity var347 = var508;
                        if (var509 == 0) {
                           Entity var510 = var347;
                           if (var510 == null) {
                              break label688;
                           }

                           var348 = var43;
                        }

                        Entity var64 = var348;
                        byte var794 = ((byte)((var64.isAlive()) ? 1 : 0));
                        int var512 = var42;
                        byte var511 = var794;
                        int var352 = var511;
                        byte var349 = var511;
                        if (var512 == 0) {
                           byte var513 = var349;
                           if (var513 == 0) {
                              break label688;
                           }

                           int var515 = var42;
                           MinecraftClient var514 = b;
                           var353 = var514;
                           MinecraftClient var350 = var514;
                           if (var515 != 0) {
                              break label680;
                           }

                           MinecraftClient var516 = var350;
                           MinecraftClient var351 = var516;
                           MinecraftClient var67 = var351;
                           Entity var69 = var43;
                           ClientPlayerEntity var68 = var67.player;
                           float var795 = var68.distanceTo(var69);
                           FloatSetting var70 = this.c;
                           Float var71 = (Float)var70.aReturningObject();
                           float var871;
                           int var517 = (var871 = var795 - var71) == 0.0F ? 0 : (var871 < 0.0F ? -1 : 1);
                           var352 = var517;
                        }

                        int var518 = var352;
                        if (var518 <= 0) {
                           break label679;
                        }
                     }

                     this.q = -1;
                  }

                  var353 = b;
               }

               MinecraftClient var74 = var353;
               int var520 = var42;
               HitResult var519 = var74.crosshairTarget;
               Object var355 = var519;
               HitResult var354 = var519;
               if (var520 == 0) {
                  HitResult var521 = var354;
                  if (var521 == null) {
                     Object[] var77 = new Object[0];
                     Triggerbot var76 = this;
                     var76.kReturningVoid(var77);
                     return;
                  }

                  BooleanSetting var79 = this.h;
                  var355 = var79.aReturningObject();
               }

               Boolean var80 = (Boolean)var355;
               int var796 = ((((java.lang.Boolean)(var80)).booleanValue() ? 1 : 0));
               int var523 = var42;
               byte var522 = (byte)var796;
               byte var360 = var522;
               byte var356 = var522;
               if (var523 == 0) {
                  MinecraftClient var359;
                  label657: {
                     byte var524 = var356;
                     if (var524 != 0) {
                        int var526 = var42;
                        MinecraftClient var525 = b;
                        var359 = var525;
                        MinecraftClient var357 = var525;
                        if (var526 != 0) {
                           break label657;
                        }

                        MinecraftClient var527 = var357;
                        MinecraftClient var358 = var527;
                        MinecraftClient var83 = var358;
                        Screen var528 = var83.currentScreen;
                        if (var528 != null) {
                           return;
                        }
                     }

                     MinecraftClient var529 = b;
                     var359 = var529;
                  }

                  MinecraftClient var86 = var359;
                  var360 = ((byte)((var86.isWindowFocused()) ? 1 : 0));
               }

               int var531 = var42;
               byte var530 = var360;
               byte var362 = var530;
               byte var361 = var530;
               if (var531 == 0) {
                  byte var532 = var361;
                  if (var532 == 0) {
                     return;
                  }

                  MinecraftClient var88 = b;
                  ClientPlayerEntity var89 = var88.player;
                  byte var533 = ((byte)((var89.isUsingItem()) ? 1 : 0));
                  var362 = var533;
               }

               int var535 = var42;
               byte var534 = var362;
               byte var364 = var534;
               byte var363 = var534;
               if (var535 == 0) {
                  byte var536 = var363;
                  if (var536 != 0) {
                     return;
                  }

                  Object[] var92 = new Object[]{76915021413912L};
                  var364 = ((byte)((ItemUseUtil.dReturningBoolean(var92)) ? 1 : 0));
               }

               int var538 = var42;
               byte var537 = var364;
               byte var366 = var537;
               byte var365 = var537;
               if (var538 == 0) {
                  byte var539 = var365;
                  if (var539 != 0) {
                     return;
                  }

                  BooleanSetting var94 = this.g;
                  Boolean var95 = (Boolean)var94.aReturningObject();
                  var366 = ((byte)(((java.lang.Boolean)(var95)).booleanValue() ? 1 : 0));
               }

               label638: {
                  int var541 = var42;
                  byte var540 = var366;
                  int var368 = var540;
                  byte var367 = var540;
                  if (var541 == 0) {
                     byte var542 = var367;
                     if (var542 == 0) {
                        break label638;
                     }

                     MinecraftClient var97 = b;
                     Window var98 = var97.getWindow();
                     long var99 = var98.getHandle();
                     int var543 = GLFW.glfwGetMouseButton(var99, 0);
                     var368 = var543;
                  }

                  byte var545 = 1;
                  int var544 = var368;
                  if (var544 != var545) {
                     Object[] var104 = new Object[0];
                     Triggerbot var103 = this;
                     var103.kReturningVoid(var104);
                     return;
                  }
               }

               int var375;
               Entity var791;
               label632: {
                  label691: {
                     var791 = null;
                     int var547 = var42;
                     boolean var546 = this.s;
                     boolean var370 = var546;
                     boolean var369 = var546;
                     if (var547 == 0) {
                        boolean var548 = var369;
                        if (!var548) {
                           break label691;
                        }

                        boolean var549 = this.t;
                        var370 = var549;
                     }

                     boolean var550 = var370;
                     if (var550) {
                        Object[] var108 = new Object[]{114978914733120L};
                        var791 = ExtendedReach.aReturningEntity(var108);
                        int var551 = var42;
                        if (var551 == 0) {
                           Entity var552 = var791;
                           if (var552 != null) {
                              Entity var110 = var791;
                              var796 = var110.getId();
                              int var554 = var42;
                              int var553 = var796;
                              var375 = var553;
                              int var371 = var553;
                              if (var554 != 0) {
                                 break label632;
                              }

                              int var555 = var371;
                              int var372 = var555;
                              int var557 = this.r;
                              int var556 = var372;
                              if (var556 == var557) {
                                 break label691;
                              }
                           }

                           Object[] var114 = new Object[0];
                           Triggerbot var113 = this;
                           var113.kReturningVoid(var114);
                        }

                        var791 = null;
                        int var558 = var42;
                        if (var558 == 0) {
                           break label691;
                        }
                     }

                     label615: {
                        MinecraftClient var116 = b;
                        HitResult var45 = var116.crosshairTarget;
                        int var560 = var42;
                        HitResult var559 = var45;
                        HitResult var374 = var559;
                        HitResult var373 = var559;
                        if (var560 == 0) {
                           boolean var561 = var373 instanceof EntityHitResult;
                           if (!var561) {
                              break label615;
                           }

                           HitResult var562 = var45;
                           var374 = var562;
                        }

                        EntityHitResult var44 = (EntityHitResult)var374;
                        EntityHitResult var119 = var44;
                        Entity var120 = var119.getEntity();
                        var796 = var120.getId();
                        int var564 = this.r;
                        int var563 = var796;
                        if (var563 == var564) {
                           break label691;
                        }
                     }

                     Object[] var122 = new Object[0];
                     Triggerbot var121 = this;
                     var121.kReturningVoid(var122);
                  }

                  ElapsedTimer var799 = this.o;
                  Object[] var125 = new Object[]{this.j, 130913203968635L};
                  ElapsedTimer var124 = var799;
                  var375 = (((var124.bReturningBoolean(var125)) ? 1 : 0));
               }

               int var565 = var375;
               if (var565 == 0) {
                  return;
               }

               Entity var378;
               label604: {
                  int var567 = var42;
                  Entity var566 = var791;
                  Entity var377 = var566;
                  Entity var376 = var566;
                  if (var567 == 0) {
                     Entity var568 = var376;
                     if (var568 == null) {
                        Object[] var127 = new Object[]{114978914733120L};
                        var378 = ExtendedReach.aReturningEntity(var127);
                        break label604;
                     }

                     var377 = var791;
                  }

                  Entity var569 = var377;
                  var378 = var569;
               }

               Entity var383;
               Entity var792;
               HitResult var793;
               label598: {
                  label692: {
                     label596: {
                        var792 = var378;
                        MinecraftClient var128 = b;
                        var793 = var128.crosshairTarget;
                        int var571 = var42;
                        HitResult var570 = var793;
                        HitResult var380 = var570;
                        HitResult var379 = var570;
                        if (var571 == 0) {
                           HitResult var572 = var379;
                           if (var572 == null) {
                              break label596;
                           }

                           var380 = var793;
                        }

                        HitResult var130 = var380;
                        Type var800 = var130.getType();
                        Type var132 = Type.ENTITY;
                        Type var131 = var800;
                        boolean var573 = var131.equals(var132);
                        if (var573) {
                           break label692;
                        }
                     }

                     int var575 = var42;
                     Entity var574 = var792;
                     var383 = var574;
                     Entity var381 = var574;
                     if (var575 != 0) {
                        break label598;
                     }

                     Entity var576 = var381;
                     Entity var382 = var576;
                     Entity var577 = var382;
                     if (var577 == null) {
                        Object[] var136 = new Object[0];
                        Triggerbot var135 = this;
                        var135.kReturningVoid(var136);
                        MinMaxSetting var801 = this.j;
                        Object[] var138 = new Object[]{127318019014223L};
                        MinMaxSetting var137 = var801;
                        var137.bReturningVoid(var138);
                        ElapsedTimer var802 = this.o;
                        Object[] var140 = new Object[]{42835128969216L};
                        ElapsedTimer var139 = var802;
                        var139.aReturningVoid(var140);
                        return;
                     }
                  }

                  var383 = var792;
               }

               Entity var386;
               label585: {
                  int var579 = var42;
                  Entity var578 = var383;
                  Entity var385 = var578;
                  Entity var384 = var578;
                  if (var579 == 0) {
                     Entity var580 = var384;
                     if (var580 == null) {
                        EntityHitResult var143 = (EntityHitResult)var793;
                        var386 = var143.getEntity();
                        break label585;
                     }

                     var385 = var792;
                  }

                  Entity var581 = var385;
                  var386 = var581;
               }

               Entity var46 = var386;
               Entity var584 = var792;
               Entity var583 = var46;
               Triggerbot var582 = this;
               Triggerbot var389 = var582;
               Entity var390 = var583;
               Triggerbot var387 = var582;
               Entity var388 = var583;
               Triggerbot var391;
               Entity var392;
               boolean var393;
               if (var584 != null) {
                  boolean var587 = true;
                  Entity var586 = var388;
                  Triggerbot var585 = var387;
                  var391 = var585;
                  var392 = var586;
                  var393 = var587;
               } else {
                  var393 = false;
                  var392 = var390;
                  var391 = var389;
               }

               Object[] var10005 = new Object[]{null, null, 10642310995511L};
               var10005[1] = var393;
               var10005[0] = var392;
               Object[] var146 = var10005;
               Triggerbot var145 = var391;
               var145.lReturningVoid(var146);
               Object[] var148 = new Object[]{var46, 97423248016881L};
               Triggerbot var147 = this;
               int var803 = (((var147.aReturningBoolean(var148)) ? 1 : 0));
               int var589 = var42;
               byte var588 = (byte)var803;
               byte var395 = var588;
               byte var394 = var588;
               if (var589 == 0) {
                  byte var590 = var394;
                  if (var590 == 0) {
                     Object[] var151 = new Object[0];
                     Triggerbot var150 = this;
                     var150.kReturningVoid(var151);
                     return;
                  }

                  MinecraftClient var153 = b;
                  ClientPlayerEntity var154 = var153.player;
                  Object[] var155 = new Object[]{var154.getMainHandStack(), 19476550655932L};
                  var395 = ((byte)((InventoryUtil.aReturningBoolean(var155)) ? 1 : 0));
               }

               byte var402;
               label578: {
                  byte var401;
                  int var592 = var42;
                  byte var591 = var395;
                  var401 = var591;
                  byte var396 = var591;
                  label577:
                  if (var592 == 0) {
                     byte var593 = var396;
                     if (var593 == 0) {
                        MinecraftClient var157 = b;
                        ClientPlayerEntity var158 = var157.player;
                        ItemStack var159 = var158.getMainHandStack();
                        var803 = (((var159.getItem() instanceof AxeItem) ? 1 : 0));
                        int var595 = var42;
                        byte var594 = ((byte)(var803));
                        var401 = var594;
                        byte var397 = var594;
                        if (var595 != 0) {
                           break label577;
                        }

                        byte var596 = var397;
                        byte var398 = var596;
                        byte var597 = var398;
                        if (var597 == 0) {
                           MinecraftClient var162 = b;
                           ClientPlayerEntity var163 = var162.player;
                           Object[] var164 = new Object[]{var163.getMainHandStack(), 91643301200230L};
                           var803 = (((InventoryUtil.o(var164)) ? 1 : 0));
                           int var599 = var42;
                           byte var598 = ((byte)(var803));
                           var401 = var598;
                           byte var399 = var598;
                           if (var599 != 0) {
                              break label577;
                           }

                           byte var600 = var399;
                           byte var400 = var600;
                           byte var601 = var400;
                           if (var601 == 0) {
                              var402 = 0;
                              break label578;
                           }
                        }
                     }

                     var401 = 1;
                  }

                  byte var602 = var401;
                  var402 = var602;
               }

               byte var47;
               byte var412;
               label565: {
                  label693: {
                     var47 = var402;
                     var803 = (((var46 instanceof PlayerEntity) ? 1 : 0));
                     int var604 = var42;
                     byte var603 = ((byte)(var803));
                     byte var408 = var603;
                     byte var403 = var603;
                     if (var604 == 0) {
                        byte var605 = var403;
                        if (var605 == 0) {
                           MultiModeSetting var807 = this.a;
                           Object[] var169 = new Object[]{"Any", 71444480285294L};
                           MultiModeSetting var168 = var807;
                           var803 = (((var168.aReturningBoolean(var169)) ? 1 : 0));
                           int var607 = var42;
                           byte var606 = ((byte)(var803));
                           var412 = var606;
                           byte var404 = var606;
                           if (var607 != 0) {
                              break label565;
                           }

                           byte var608 = var404;
                           byte var405 = var608;
                           byte var609 = var405;
                           if (var609 == 0) {
                              break label693;
                           }

                           var803 = (((var46 instanceof EndCrystalEntity) ? 1 : 0));
                           int var611 = var42;
                           byte var610 = ((byte)(var803));
                           var412 = var610;
                           byte var406 = var610;
                           if (var611 != 0) {
                              break label565;
                           }

                           byte var612 = var406;
                           byte var407 = var612;
                           byte var613 = var407;
                           if (var613 != 0) {
                              break label693;
                           }
                        }

                        MultiModeSetting var810 = this.e;
                        Object[] var175 = new Object[]{"Weapon Only", 71444480285294L};
                        MultiModeSetting var174 = var810;
                        byte var614 = ((byte)((var174.aReturningBoolean(var175)) ? 1 : 0));
                        var408 = var614;
                     }

                     int var616 = var42;
                     byte var615 = var408;
                     var412 = var615;
                     byte var409 = var615;
                     if (var616 != 0) {
                        break label565;
                     }

                     byte var617 = var409;
                     if (var617 != 0) {
                        int var619 = var42;
                        byte var618 = var47;
                        var412 = var618;
                        byte var410 = var618;
                        if (var619 != 0) {
                           break label565;
                        }

                        byte var620 = var410;
                        byte var411 = var620;
                        byte var621 = var411;
                        if (var621 == 0) {
                           return;
                        }
                     }
                  }

                  var412 = ((byte)((var46 instanceof EndCrystalEntity) ? 1 : 0));
               }

               Triggerbot var417;
               label545: {
                  label544: {
                     int var623 = var42;
                     byte var622 = var412;
                     byte var416 = var622;
                     byte var413 = var622;
                     if (var623 == 0) {
                        byte var624 = var413;
                        if (var624 == 0) {
                           break label544;
                        }

                        int var626 = var42;
                        Triggerbot var625 = this;
                        var417 = var625;
                        Triggerbot var414 = var625;
                        if (var626 != 0) {
                           break label545;
                        }

                        Triggerbot var627 = var414;
                        Triggerbot var415 = var627;
                        MultiModeSetting var811 = var415.f;
                        Object[] var183 = new Object[]{"Crystal Only", 71444480285294L};
                        MultiModeSetting var182 = var811;
                        byte var628 = ((byte)((var182.aReturningBoolean(var183)) ? 1 : 0));
                        var416 = var628;
                     }

                     byte var629 = var416;
                     if (var629 != 0) {
                        MinecraftClient var185 = b;
                        ClientPlayerEntity var186 = var185.player;
                        ItemStack var187 = var186.getMainHandStack();
                        Item var812 = var187.getItem();
                        Item var631 = Items.END_CRYSTAL;
                        Item var630 = var812;
                        if (var630 != var631) {
                           return;
                        }
                     }
                  }

                  var417 = this;
               }

               MinMaxSetting var813 = var417.k;
               Object[] var191 = new Object[]{7504101316849L};
               MinMaxSetting var190 = var813;
               float var48 = var190.fReturningFloat(var191) / 100.0F;
               BooleanSetting var192 = this.l;
               Boolean var193 = (Boolean)var192.aReturningObject();
               var803 = ((((java.lang.Boolean)(var193)).booleanValue() ? 1 : 0));
               int var633 = var42;
               byte var632 = ((byte)(var803));
               byte var419 = var632;
               byte var418 = var632;
               if (var633 == 0) {
                  byte var634 = var418;
                  if (var634 != 0) {
                     Object[] var10004 = new Object[]{null, 79976755798979L};
                     var10004[0] = var48;
                     Object[] var196 = var10004;
                     Triggerbot var195 = this;
                     var48 = (float)var195.aReturningDouble(var196);
                  }

                  var419 = ((byte)((var46 instanceof EndCrystalEntity) ? 1 : 0));
               }

               int var427;
               int var636 = var42;
               byte var635 = var419;
               var427 = var635;
               byte var420 = var635;
               label534:
               if (var636 == 0) {
                  byte var637 = var420;
                  label532:
                  if (var637 == 0) {
                     MultiModeSetting var815 = this.e;
                     Object[] var199 = new Object[]{"Weapon Only", 71444480285294L};
                     MultiModeSetting var198 = var815;
                     var803 = (((var198.aReturningBoolean(var199)) ? 1 : 0));
                     int var639 = var42;
                     byte var638 = ((byte)(var803));
                     byte var425 = var638;
                     byte var421 = var638;
                     if (var639 == 0) {
                        byte var640 = var421;
                        byte var422 = var640;
                        byte var641 = var422;
                        if (var641 != 0) {
                           MinecraftClient var202 = b;
                           float var204 = 0.0F;
                           ClientPlayerEntity var203 = var202.player;
                           float var872;
                           var803 = (var872 = var203.getAttackCooldownProgress(var204) - var48) == 0.0F ? 0 : (var872 < 0.0F ? -1 : 1);
                           int var643 = var42;
                           int var642 = var803;
                           var427 = var642;
                           int var423 = var642;
                           if (var643 != 0) {
                              break label534;
                           }

                           int var644 = var423;
                           int var424 = var644;
                           int var645 = var424;
                           if (var645 < 0) {
                              return;
                           }
                           break label532;
                        }

                        ElapsedTimer var817 = this.p;
                        Object[] var208 = new Object[]{this.n, 130913203968635L};
                        ElapsedTimer var207 = var817;
                        var425 = ((byte)((var207.bReturningBoolean(var208)) ? 1 : 0));
                     }

                     int var647 = var42;
                     byte var646 = var425;
                     var427 = var646;
                     byte var426 = var646;
                     if (var647 != 0) {
                        break label534;
                     }

                     byte var648 = var426;
                     if (var648 == 0) {
                        return;
                     }
                  }

                  MultiModeSetting var819 = this.f;
                  Object[] var211 = new Object[]{"On Ground Only", 71444480285294L};
                  MultiModeSetting var210 = var819;
                  var427 = (((var210.aReturningBoolean(var211)) ? 1 : 0));
               }

               int var433;
               int var650 = var42;
               int var649 = var427;
               var433 = var649;
               int var428 = var649;
               label520:
               if (var650 == 0) {
                  int var651 = var428;
                  if (var651 != 0) {
                     byte var820 = ((byte)((var46 instanceof EndCrystalEntity) ? 1 : 0));
                     int var653 = var42;
                     byte var652 = var820;
                     var433 = var652;
                     byte var429 = var652;
                     if (var653 != 0) {
                        break label520;
                     }

                     byte var654 = var429;
                     byte var430 = var654;
                     byte var655 = var430;
                     if (var655 != 0) {
                        MinecraftClient var215 = b;
                        ClientPlayerEntity var216 = var215.player;
                        var820 = ((byte)((var216.isOnGround()) ? 1 : 0));
                        int var657 = var42;
                        byte var656 = var820;
                        var433 = var656;
                        byte var431 = var656;
                        if (var657 != 0) {
                           break label520;
                        }

                        byte var658 = var431;
                        byte var432 = var658;
                        byte var659 = var432;
                        if (var659 == 0) {
                           return;
                        }
                     }
                  }

                  var433 = (((var46 instanceof PlayerEntity) ? 1 : 0));
               }

               int var439;
               int var661 = var42;
               int var660 = var433;
               var439 = var660;
               int var434 = var660;
               label510:
               if (var661 == 0) {
                  int var662 = var434;
                  if (var662 != 0) {
                     Object[] var220 = new Object[]{(PlayerEntity)var46, 100443321076669L};
                     byte var822 = ((byte)((EntityUtil.aReturningBoolean(var220)) ? 1 : 0));
                     int var664 = var42;
                     byte var663 = var822;
                     var439 = var663;
                     byte var435 = var663;
                     if (var664 != 0) {
                        break label510;
                     }

                     byte var665 = var435;
                     byte var436 = var665;
                     byte var666 = var436;
                     if (var666 != 0) {
                        MinecraftClient var223 = b;
                        ClientPlayerEntity var224 = var223.player;
                        ItemStack var225 = var224.getMainHandStack();
                        var822 = ((byte)((var225.getItem() instanceof AxeItem) ? 1 : 0));
                        int var668 = var42;
                        byte var667 = var822;
                        var439 = var667;
                        byte var437 = var667;
                        if (var668 != 0) {
                           break label510;
                        }

                        byte var669 = var437;
                        byte var438 = var669;
                        byte var670 = var438;
                        if (var670 == 0) {
                           return;
                        }
                     }
                  }

                  var439 = (((var46 instanceof PlayerEntity) ? 1 : 0));
               }

               label499: {
                  label697: {
                     int var672 = var42;
                     int var671 = var439;
                     int var441 = var671;
                     int var440 = var671;
                     if (var672 == 0) {
                        int var673 = var440;
                        if (var673 == 0) {
                           break label697;
                        }

                        var441 = var47;
                     }

                     int var675 = var42;
                     int var674 = var441;
                     int var443 = var674;
                     int var442 = var674;
                     if (var675 == 0) {
                        int var676 = var442;
                        if (var676 == 0) {
                           break label697;
                        }

                        MinecraftClient var230 = b;
                        ClientPlayerEntity var231 = var230.player;
                        byte var677 = ((byte)((var231.isOnGround()) ? 1 : 0));
                        var443 = var677;
                     }

                     int var679 = var42;
                     int var678 = var443;
                     int var445 = var678;
                     int var444 = var678;
                     if (var679 == 0) {
                        int var680 = var444;
                        if (var680 != 0) {
                           break label697;
                        }

                        MinecraftClient var234 = b;
                        ClientPlayerEntity var235 = var234.player;
                        double var873;
                        int var681 = (var873 = var235.fallDistance - 0.0) == 0.0 ? 0 : (var873 < 0.0 ? -1 : 1);
                        var445 = var681;
                     }

                     int var683 = var42;
                     int var682 = var445;
                     int var447 = var682;
                     int var446 = var682;
                     if (var683 == 0) {
                        int var684 = var446;
                        if (var684 <= 0) {
                           break label697;
                        }

                        MinecraftClient var238 = b;
                        ClientPlayerEntity var239 = var238.player;
                        Vec3d var240 = var239.getVelocity();
                        double var874;
                        int var685 = (var874 = var240.y - 0.0) == 0.0 ? 0 : (var874 < 0.0 ? -1 : 1);
                        var447 = var685;
                     }

                     int var687 = var42;
                     int var686 = var447;
                     int var448 = var686;
                     if (var687 != 0) {
                        break label499;
                     }

                     int var688 = var448;
                     if (var688 <= 0) {
                        boolean var449 = true;
                        break label499;
                     }
                  }

                  boolean var450 = false;
               }

               int var462;
               MultiModeSetting var824 = this.e;
               Object[] var244 = new Object[]{"Criticals Timing", 71444480285294L};
               MultiModeSetting var243 = var824;
               int var825 = (((var243.aReturningBoolean(var244)) ? 1 : 0));
               int var691 = var42;
               byte var690 = (byte)var825;
               var462 = var690;
               byte var451 = var690;
               label473:
               if (var691 == 0) {
                  byte var692 = var451;
                  if (var692 != 0) {
                     var825 = (((var46 instanceof PlayerEntity) ? 1 : 0));
                     int var694 = var42;
                     byte var693 = ((byte)(var825));
                     var462 = var693;
                     byte var452 = var693;
                     if (var694 != 0) {
                        break label473;
                     }

                     byte var695 = var452;
                     byte var453 = var695;
                     byte var696 = var453;
                     if (var696 != 0) {
                        int var698 = var42;
                        byte var697 = var47;
                        var462 = var697;
                        byte var454 = var697;
                        if (var698 != 0) {
                           break label473;
                        }

                        byte var699 = var454;
                        byte var455 = var699;
                        byte var700 = var455;
                        if (var700 != 0) {
                           MinecraftClient var250 = b;
                           ClientPlayerEntity var251 = var250.player;
                           var825 = (((var251.isOnGround()) ? 1 : 0));
                           int var702 = var42;
                           byte var701 = ((byte)(var825));
                           var462 = var701;
                           byte var456 = var701;
                           if (var702 != 0) {
                              break label473;
                           }

                           byte var703 = var456;
                           byte var457 = var703;
                           byte var704 = var457;
                           if (var704 == 0) {
                              MinecraftClient var254 = b;
                              ClientPlayerEntity var255 = var254.player;
                              double var875;
                              var825 = (var875 = var255.fallDistance - 0.0) == 0.0 ? 0 : (var875 < 0.0 ? -1 : 1);
                              int var706 = var42;
                              int var705 = var825;
                              int var460 = var705;
                              int var458 = var705;
                              if (var706 == 0) {
                                 int var707 = var458;
                                 int var459 = var707;
                                 int var708 = var459;
                                 if (var708 <= 0) {
                                    return;
                                 }

                                 MinecraftClient var258 = b;
                                 ClientPlayerEntity var259 = var258.player;
                                 Vec3d var260 = var259.getVelocity();
                                 double var876;
                                 int var709 = (var876 = var260.y - 0.0) == 0.0 ? 0 : (var876 < 0.0 ? -1 : 1);
                                 var460 = var709;
                              }

                              int var711 = var42;
                              int var710 = var460;
                              var462 = var710;
                              int var461 = var710;
                              if (var711 != 0) {
                                 break label473;
                              }

                              int var712 = var461;
                              if (var712 >= 0) {
                                 return;
                              }
                           }
                        }
                     }
                  }

                  MultiModeSetting var829 = this.e;
                  Object[] var264 = new Object[]{"Crit Only", 71444480285294L};
                  MultiModeSetting var263 = var829;
                  var462 = (((var263.aReturningBoolean(var264)) ? 1 : 0));
               }

               int var474;
               int var714 = var42;
               int var713 = var462;
               var474 = var713;
               int var463 = var713;
               label448:
               if (var714 == 0) {
                  int var715 = var463;
                  if (var715 != 0) {
                     byte var830 = ((byte)((var46 instanceof PlayerEntity) ? 1 : 0));
                     int var717 = var42;
                     byte var716 = var830;
                     var474 = var716;
                     byte var464 = var716;
                     if (var717 != 0) {
                        break label448;
                     }

                     byte var718 = var464;
                     byte var465 = var718;
                     byte var719 = var465;
                     if (var719 != 0) {
                        int var721 = var42;
                        byte var720 = var47;
                        var474 = var720;
                        byte var466 = var720;
                        if (var721 != 0) {
                           break label448;
                        }

                        byte var722 = var466;
                        byte var467 = var722;
                        byte var723 = var467;
                        if (var723 != 0) {
                           MinecraftClient var270 = b;
                           ClientPlayerEntity var271 = var270.player;
                           var830 = ((byte)((var271.isOnGround()) ? 1 : 0));
                           int var725 = var42;
                           byte var724 = var830;
                           int var470 = var724;
                           byte var468 = var724;
                           if (var725 == 0) {
                              byte var726 = var468;
                              byte var469 = var726;
                              byte var727 = var469;
                              if (var727 != 0) {
                                 return;
                              }

                              MinecraftClient var274 = b;
                              ClientPlayerEntity var275 = var274.player;
                              double var877;
                              int var728 = (var877 = var275.fallDistance - 0.0) == 0.0 ? 0 : (var877 < 0.0 ? -1 : 1);
                              var470 = var728;
                           }

                           int var730 = var42;
                           int var729 = var470;
                           int var472 = var729;
                           int var471 = var729;
                           if (var730 == 0) {
                              int var731 = var471;
                              if (var731 <= 0) {
                                 return;
                              }

                              MinecraftClient var278 = b;
                              ClientPlayerEntity var279 = var278.player;
                              Vec3d var280 = var279.getVelocity();
                              double var878;
                              int var732 = (var878 = var280.y - 0.0) == 0.0 ? 0 : (var878 < 0.0 ? -1 : 1);
                              var472 = var732;
                           }

                           int var734 = var42;
                           int var733 = var472;
                           var474 = var733;
                           int var473 = var733;
                           if (var734 != 0) {
                              break label448;
                           }

                           int var735 = var473;
                           if (var735 >= 0) {
                              return;
                           }
                        }
                     }
                  }

                  MultiModeSetting var832 = this.f;
                  Object[] var284 = new Object[]{"Pause On Kill", 71444480285294L};
                  MultiModeSetting var283 = var832;
                  var474 = (((var283.aReturningBoolean(var284)) ? 1 : 0));
               }

               int var480;
               int var737 = var42;
               int var736 = var474;
               var480 = var736;
               int var475 = var736;
               label424:
               if (var737 == 0) {
                  int var738 = var475;
                  if (var738 != 0) {
                     byte var833 = ((byte)((var46 instanceof EndCrystalEntity) ? 1 : 0));
                     int var740 = var42;
                     byte var739 = var833;
                     var480 = var739;
                     byte var476 = var739;
                     if (var740 != 0) {
                        break label424;
                     }

                     byte var741 = var476;
                     byte var477 = var741;
                     byte var742 = var477;
                     if (var742 != 0) {
                        Entity var288 = var46;
                        Object[] var289 = new Object[]{var288.getBlockPos(), 108898817732228L};
                        var833 = ((byte)((DroppedItemUtil.aReturningBoolean(var289)) ? 1 : 0));
                        int var744 = var42;
                        byte var743 = var833;
                        var480 = var743;
                        byte var478 = var743;
                        if (var744 != 0) {
                           break label424;
                        }

                        byte var745 = var478;
                        byte var479 = var745;
                        byte var746 = var479;
                        if (var746 != 0) {
                           return;
                        }
                     }
                  }

                  BooleanSetting var292 = this.d;
                  Boolean var293 = (Boolean)var292.aReturningObject();
                  var480 = ((((java.lang.Boolean)(var293)).booleanValue() ? 1 : 0));
               }

               int var490;
               int var748 = var42;
               int var747 = var480;
               var490 = var747;
               int var481 = var747;
               label414:
               if (var748 == 0) {
                  int var749 = var481;
                  if (var749 != 0) {
                     byte var835 = ((byte)((var46 instanceof PlayerEntity) ? 1 : 0));
                     int var751 = var42;
                     byte var750 = var835;
                     var490 = var750;
                     byte var482 = var750;
                     if (var751 != 0) {
                        break label414;
                     }

                     byte var752 = var482;
                     byte var483 = var752;
                     byte var753 = var483;
                     label410:
                     if (var753 != 0) {
                        Entity var297 = var46;
                        int var50 = var297.getId();
                        int var756 = var42;
                        // int var754 = this.q;
                        int var488 = var754;
                        int var489 = var755;
                        int var484 = var754;
                        byte var485 = var755;
                        if (var756 == 0) {
                           byte var758 = var485;
                           int var757 = var484;
                           if (var757 == var758) {
                              this.q = var50;
                              int var759 = var42;
                              if (var759 == 0) {
                                 break label410;
                              }
                           }

                           int var761 = var42;
                           int var760 = var50;
                           var490 = var760;
                           int var486 = var760;
                           if (var761 != 0) {
                              break label414;
                           }

                           int var762 = var486;
                           int var487 = var762;
                           int var764 = this.q;
                           int var763 = var487;
                           var488 = var763;
                           var489 = var764;
                        }

                        int var766 = var489;
                        int var765 = var488;
                        if (var765 != var766) {
                           return;
                        }
                     }
                  }

                  var490 = (((var46 instanceof PlayerEntity) ? 1 : 0));
               }

               Entity var500;
               label705: {
                  int var499;
                  int var768 = var42;
                  int var767 = var490;
                  var499 = var767;
                  int var491 = var767;
                  label397:
                  if (var768 == 0) {
                     int var769 = var491;
                     label395:
                     if (var769 != 0) {
                        FloatSetting var303 = this.m;
                        Float var304 = (Float)var303.aReturningObject();
                        float var879;
                        var825 = (var879 = var304 - 0.0F) == 0.0F ? 0 : (var879 < 0.0F ? -1 : 1);
                        int var771 = var42;
                        int var770 = var825;
                        int var494 = var770;
                        int var492 = var770;
                        if (var771 == 0) {
                           int var772 = var492;
                           int var493 = var772;
                           int var773 = var493;
                           if (var773 <= 0) {
                              this.s = false;
                              int var774 = var42;
                              if (var774 == 0) {
                                 break label395;
                              }
                           }

                           byte var775 = ((byte)((this.s) ? 1 : 0));
                           var494 = var775;
                        }

                        int var777 = var42;
                        int var776 = var494;
                        int var496 = var776;
                        int var495 = var776;
                        if (var777 == 0) {
                           int var778 = var495;
                           if (var778 != 0) {
                              return;
                           }

                           Object[] var869 = new Object[]{null, null, 128703941739773L};
                           var869[1] = 100.0F;
                           var869[0] = 0.0F;
                           Object[] var310 = var869;
                           float var837 = RandomUtil.aReturningFloat(var310);
                           FloatSetting var311 = this.m;
                           Float var312 = (Float)var311.aReturningObject();
                           float var880;
                           var496 = (var880 = var837 - var312) == 0.0F ? 0 : (var880 < 0.0F ? -1 : 1);
                        }

                        int var780 = var42;
                        int var779 = var496;
                        var499 = var779;
                        int var497 = var779;
                        if (var780 != 0) {
                           break label397;
                        }

                        int var781 = var497;
                        if (var781 < 0) {
                           this.s = true;
                           MinMaxSetting var838 = this.j;
                           Object[] var315 = new Object[]{127318019014223L};
                           MinMaxSetting var314 = var838;
                           var314.bReturningVoid(var315);
                           ElapsedTimer var839 = this.o;
                           Object[] var317 = new Object[]{42835128969216L};
                           ElapsedTimer var316 = var839;
                           var316.aReturningVoid(var317);
                           return;
                        }
                     }

                     int var783 = var42;
                     Entity var782 = var46;
                     var500 = var782;
                     Entity var498 = var782;
                     if (var783 != 0) {
                        break label705;
                     }

                     byte var784 = ((byte)((var498 instanceof PlayerEntity) ? 1 : 0));
                     var499 = var784;
                  }

                  int var785 = var499;
                  if (var785 != 0) {
                     PostAttackEvent var840 = new PostAttackEvent();
                     Object[] var321 = new Object[]{50524040089412L};
                     PostAttackEvent var320 = var840;
                     var320.bReturningBoolean(var321);
                  }

                  var500 = var792;
               }

               label380: {
                  int var787 = var42;
                  Entity var786 = var500;
                  Entity var502 = var786;
                  Entity var501 = var786;
                  if (var787 == 0) {
                     Entity var788 = var501;
                     if (var788 != null) {
                        ExtendedTargetingEvent var841 = new ExtendedTargetingEvent();
                        Object[] var325 = new Object[]{50524040089412L};
                        ExtendedTargetingEvent var324 = var841;
                        var324.bReturningBoolean(var325);
                        MinecraftClient var326 = b;
                        MouseAccessor var842 = new MouseAccessor(var326.mouse);
                        MinecraftClient var327 = b;
                        Window var328 = var327.getWindow();
                        var10001 = var328.getHandle();
                        int var10002 = KeybindManager.e;
                        Object[] var10007 = new Object[]{null, null, null, null, 108046286118761L};
                        var10007[3] = 0;
                        var10007[2] = 1;
                        var10007[1] = var10002;
                        var10007[0] = var10001;
                        Object[] var330 = var10007;
                        MouseAccessor var329 = var842;
                        var329.aReturningVoid(var330);
                        MinecraftClient var331 = b;
                        MouseAccessor var843 = new MouseAccessor(var331.mouse);
                        MinecraftClient var332 = b;
                        Window var333 = var332.getWindow();
                        var10001 = var333.getHandle();
                        var10002 = KeybindManager.e;
                        var10007 = new Object[]{null, null, null, null, 108046286118761L};
                        var10007[3] = 0;
                        var10007[2] = 0;
                        var10007[1] = var10002;
                        var10007[0] = var10001;
                        Object[] var335 = var10007;
                        MouseAccessor var334 = var843;
                        var334.aReturningVoid(var335);
                        int var789 = var42;
                        if (var789 == 0) {
                           break label380;
                        }
                     }

                     Entity var790 = var46;
                     var502 = var790;
                  }

                  Object[] var338 = new Object[]{var502, 114267283224552L};
                  ItemUseUtil.aReturningVoid(var338);
               }

               MinMaxSetting var844 = this.j;
               Object[] var340 = new Object[]{127318019014223L};
               MinMaxSetting var339 = var844;
               var339.bReturningVoid(var340);
               ElapsedTimer var845 = this.o;
               Object[] var342 = new Object[]{42835128969216L};
               ElapsedTimer var341 = var845;
               var341.aReturningVoid(var342);
               MinMaxSetting var846 = this.n;
               Object[] var344 = new Object[]{127318019014223L};
               MinMaxSetting var343 = var846;
               var343.bReturningVoid(var344);
               ElapsedTimer var847 = this.p;
               Object[] var346 = new Object[]{42835128969216L};
               ElapsedTimer var345 = var847;
               var345.aReturningVoid(var346);
               return;
            }
         }

         Object[] var58 = new Object[0];
         Triggerbot var57 = this;
         var57.kReturningVoid(var58);
      }
   }

   private boolean aReturningBoolean(Object[] var1) {
      Entity var4;
      long var7;
      int var9;
      Object var71;
      long var154;
      label182: {
         boolean var62;
         var4 = (Entity)var1[0];
         long var2 = (Long)var1[1];
         var154 = 64770974064563L ^ var2;
         long var5 = var154 ^ 77904490293139L;
         var7 = var154 ^ 37975063756844L;
         var9 = Event.bReturningInt();
         BooleanSetting var11 = this.i;
         Boolean var12 = (Boolean)var11.aReturningObject();
         byte var10000 = ((byte)(((java.lang.Boolean)(var12)).booleanValue() ? 1 : 0));
         int var91 = var9;
         boolean var90 = dev.prestige.recovery.SourceSupport.asBoolean(var10000);
         var62 = var90;
         boolean var57 = var90;
         label146:
         if (var91 == 0) {
            boolean var92 = var57;
            if (var92) {
               var10000 = ((byte)((var4 instanceof PlayerEntity) ? 1 : 0));
               int var94 = var9;
               boolean var93 = ((((int)(var10000) & 1) != 0));
               var62 = var93;
               boolean var58 = var93;
               if (var94 != 0) {
                  break label146;
               }

               boolean var95 = var58;
               boolean var59 = var95;
               boolean var96 = var59;
               if (var96) {
                  PlayerEntity var10 = (PlayerEntity)var4;
                  SocialsManager var157 = Prestige.g;
                  PlayerEntity var16 = var10;
                  Text var17 = var16.getName();
                  Object[] var19 = new Object[]{var17.getString(), var5};
                  SocialsManager var18 = var157;
                  var10000 = ((byte)((var18.aReturningBoolean(var19)) ? 1 : 0));
                  int var98 = var9;
                  boolean var97 = ((((int)(var10000) & 1) != 0));
                  var62 = var97;
                  boolean var60 = var97;
                  if (var98 != 0) {
                     break label146;
                  }

                  boolean var99 = var60;
                  if (var99) {
                     return false;
                  }
               }
            }

            int var101 = var9;
            Entity var100 = var4;
            var71 = var100;
            Entity var61 = var100;
            if (var101 != 0) {
               break label182;
            }

            boolean var102 = var61 instanceof PlayerEntity;
            var62 = var102;
         }

         boolean var103 = var62;
         if (var103) {
            PlayerEntity var155 = (PlayerEntity)var4;
            PlayerEntity var23 = var155;
            var10000 = ((byte)((var23.isSpectator()) ? 1 : 0));
            int var105 = var9;
            byte var104 = var10000;
            byte var70 = var104;
            byte var63 = var104;
            if (var105 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var70);
            }

            byte var106 = var63;
            if (var106 != 0) {
               return false;
            }

            PlayerEntity var25 = var155;
            var10000 = ((byte)((var25.isDead()) ? 1 : 0));
            int var108 = var9;
            byte var107 = var10000;
            var70 = var107;
            byte var64 = var107;
            if (var108 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var70);
            }

            byte var109 = var64;
            byte var65 = var109;
            byte var110 = var65;
            if (var110 != 0) {
               return false;
            }

            PlayerEntity var28 = var155;
            var10000 = ((byte)((var28.isRemoved()) ? 1 : 0));
            int var112 = var9;
            byte var111 = var10000;
            var70 = var111;
            byte var66 = var111;
            if (var112 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var70);
            }

            byte var113 = var66;
            byte var67 = var113;
            byte var114 = var67;
            if (var114 != 0) {
               return false;
            }

            int var116 = var9;
            PlayerEntity var115 = var155;
            var71 = var115;
            PlayerEntity var68 = var115;
            if (var116 != 0) {
               break label182;
            }

            PlayerEntity var117 = var68;
            PlayerEntity var69 = var117;
            PlayerEntity var32 = var69;
            PlayerAbilities var33 = var32.getAbilities();
            boolean var118 = var33.invulnerable;
            if (var118) {
               return false;
            }
         }

         var71 = var4;
      }

      int var121 = var9;
      Object var120 = var71;
      Object var73 = var120;
      Object var72 = var120;
      if (var121 == 0) {
         Object var122 = var72;
         if (var122 == null) {
            return false;
         }

         var73 = var4;
      }

      MinecraftClient var37 = b;
      ClientPlayerEntity var124 = var37.player;
      Object var123 = var73;
      if (var123 != var124) {
         byte var78;
         MultiModeSetting var162 = this.e;
         short var10001 = 6144;
         long var10002 = 5977380194628733992L ^ var154;
         Object[] var39 = new Object[]{"Attack Invisibles", var7};
         MultiModeSetting var38 = var162;
         byte var163 = ((byte)((var38.aReturningBoolean(var39)) ? 1 : 0));
         int var126 = var9;
         byte var125 = var163;
         var78 = var125;
         byte var74 = var125;
         label103:
         if (var126 == 0) {
            byte var127 = var74;
            byte var75 = var127;
            byte var128 = var75;
            if (var128 == 0) {
               Entity var42 = var4;
               byte var164 = ((byte)((var42.isInvisible()) ? 1 : 0));
               int var130 = var9;
               byte var129 = var164;
               var78 = var129;
               byte var76 = var129;
               if (var130 != 0) {
                  break label103;
               }

               byte var131 = var76;
               byte var77 = var131;
               byte var132 = var77;
               if (var132 != 0) {
                  return false;
               }
            }

            var162 = this.a;
            var10001 = 18250;
            var10002 = 6965933753782948710L ^ var154;
            Object[] var46 = new Object[]{"Any", var7};
            MultiModeSetting var45 = var162;
            byte var133 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
            var78 = var133;
         }

         int var135 = var9;
         byte var134 = var78;
         byte var88 = var134;
         byte var79 = var134;
         if (var135 != 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var88);
         }

         byte var136 = var79;
         if (var136 == 0) {
            var162 = this.a;
            var10001 = 3450;
            var10002 = 2832403628488530256L ^ var154;
            Object[] var50 = new Object[]{"Players", var7};
            MultiModeSetting var49 = var162;
            byte var167 = ((byte)((var49.aReturningBoolean(var50)) ? 1 : 0));
            int var138 = var9;
            byte var137 = var167;
            byte var84 = var137;
            byte var80 = var137;
            if (var138 == 0) {
               byte var139 = var80;
               byte var81 = var139;
               byte var140 = var81;
               if (var140 != 0) {
                  byte var168 = ((byte)((var4 instanceof PlayerEntity) ? 1 : 0));
                  int var142 = var9;
                  byte var141 = var168;
                  var88 = var141;
                  byte var82 = var141;
                  if (var142 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var88);
                  }

                  byte var143 = var82;
                  byte var83 = var143;
                  byte var144 = var83;
                  if (var144 != 0) {
                     return true;
                  }
               }

               var162 = this.a;
               var10001 = 23536;
               var10002 = 2802517415918292951L ^ var154;
               Object[] var56 = new Object[]{"Crystals", var7};
               MultiModeSetting var55 = var162;
               byte var145 = ((byte)((var55.aReturningBoolean(var56)) ? 1 : 0));
               var84 = var145;
            }

            int var147 = var9;
            byte var146 = var84;
            byte var86 = var146;
            byte var85 = var146;
            if (var147 == 0) {
               byte var148 = var85;
               if (var148 == 0) {
                  return false;
               }

               byte var149 = ((byte)((var4 instanceof EndCrystalEntity) ? 1 : 0));
               var86 = var149;
            }

            int var151 = var9;
            byte var150 = var86;
            var88 = var150;
            byte var87 = var150;
            if (var151 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var88);
            }

            byte var152 = var87;
            if (var152 == 0) {
               return false;
            }
         }

         return true;
      } else {
         return false;
      }
   }

   private boolean lambda$new$7(Float var1) {
      int var6;
      byte var19;
      long var10001 = 128747955198214L ^ 59245030327144L;
      var6 = Event.cReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var35 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var24 = var6;
      byte var23 = var35;
      var19 = var23;
      byte var16 = var23;
      label31:
      if (var24 != 0) {
         byte var25 = var16;
         if (var25 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var37 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var27 = var6;
            byte var26 = var37;
            var19 = var26;
            byte var17 = var26;
            if (var27 == 0) {
               break label31;
            }

            byte var28 = var17;
            byte var18 = var28;
            byte var29 = var18;
            if (var29 == 0) {
               return false;
            }
         }

         var10000 = this.e;
         Object[] var15 = new Object[]{"Weapon Only", 71444480285294L};
         MultiModeSetting var14 = var10000;
         byte var30 = ((byte)((var14.aReturningBoolean(var15)) ? 1 : 0));
         var19 = var30;
      }

      int var32 = var6;
      byte var31 = var19;
      byte var21 = var31;
      byte var20 = var31;
      if (var32 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var21);
      } else {
         byte var33 = var20;
         if (var33 == 0) {
            var21 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var21);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$6(Float var1) {
      long var10001 = 76746207247397L ^ 5732316866123L;
      int var6 = Event.bReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$5(Boolean var1) {
      long var10001 = 138654608353342L ^ 69138176488016L;
      int var6 = Event.cReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$4(Float var1) {
      long var10001 = 19656642491279L ^ 89175834438113L;
      int var6 = Event.bReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$3(String var1) {
      long var10001 = 38466458714026L ^ 107779474138564L;
      int var6 = Event.bReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Crystals", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$2(String var1) {
      long var10001 = 73577972265633L ^ 2273148676303L;
      int var6 = Event.cReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   private boolean lambda$new$1(Float var1) {
      long var10001 = 6680526300875L ^ 77966956297381L;
      int var6 = Event.cReturningInt();
      BooleanSetting var7 = this.d;
      Boolean var8 = (Boolean)var7.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var8)).booleanValue() ? 1 : 0));
      int var24 = var6;
      byte var23 = var10000;
      byte var17 = var23;
      byte var16 = var23;
      if (var24 != 0) {
         byte var25 = var16;
         if (var25 == 0) {
            return false;
         }

         MultiModeSetting var35 = this.a;
         Object[] var11 = new Object[]{"Any", 71444480285294L};
         MultiModeSetting var10 = var35;
         byte var26 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
         var17 = var26;
      }

      int var28 = var6;
      byte var27 = var17;
      byte var21 = var27;
      byte var18 = var27;
      if (var28 == 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var21);
      }

      byte var29 = var18;
      if (var29 == 0) {
         MultiModeSetting var36 = this.a;
         Object[] var15 = new Object[]{"Players", 71444480285294L};
         MultiModeSetting var14 = var36;
         var10000 = ((byte)((var14.aReturningBoolean(var15)) ? 1 : 0));
         int var31 = var6;
         byte var30 = var10000;
         var21 = var30;
         byte var19 = var30;
         if (var31 == 0) {
            return dev.prestige.recovery.SourceSupport.asBoolean(var21);
         }

         byte var32 = var19;
         byte var20 = var32;
         byte var33 = var20;
         if (var33 == 0) {
            return false;
         }
      }

      var21 = 1;
      return dev.prestige.recovery.SourceSupport.asBoolean(var21);
   }

   private boolean lambda$new$0(Boolean var1) {
      long var10001 = 64299469401503L ^ 134692688246769L;
      int var6 = Event.cReturningInt();
      MultiModeSetting var10000 = this.a;
      Object[] var8 = new Object[]{"Any", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      byte var15 = var17;
      byte var12 = var17;
      if (var18 != 0) {
         byte var19 = var12;
         if (var19 == 0) {
            var10000 = this.a;
            Object[] var11 = new Object[]{"Players", 71444480285294L};
            MultiModeSetting var10 = var10000;
            byte var27 = ((byte)((var10.aReturningBoolean(var11)) ? 1 : 0));
            int var21 = var6;
            byte var20 = var27;
            var15 = var20;
            byte var13 = var20;
            if (var21 == 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var15);
            }

            byte var22 = var13;
            byte var14 = var22;
            byte var23 = var14;
            if (var23 == 0) {
               return false;
            }
         }

         var15 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var15);
   }

   static {

      {

      f();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(10938231193393L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[14];
      String var11 = "wvÃ\u0002{ã¬\u008d\u0019\"2n\u0013\u008f¡\u009f @Ù%\u000b'LÖx»\u0013]=_^Y8}õÝ\u0081ÔöHõ\u0000O\f|Wfº&(&]7Ó¢ÞÊ¦\u0006nÿ \u0004\u007f\u001c¤!3Â|ÎÜ\u001d¦Ã´Ý8Í^²{#\u008cNt]ß.Û\u0010ñá$ýd\u000e_\u008d\u007fo\u0007,\u0006£ÑÖ ÷óÃûÕ\"hH\u0010¥\u001f\u001c\u0083,\u0017H©¸\u0097]_Áßk\u008cÁÖÃ@1\u009bò\u0018¡f\u0095¶\u0014tXM3¬Ð6J\u009d&\u001em{×\u0092\u0003ºû\b\u0010\u0096áë -d ;Â1«/\u0002\u001eÖ\u008c\u0018\u0085W`r}\u0007áH\u0016\u0081d®ï³Ò¢\u0010\u008a\u000eG\u0091.{±(\n)aí9Ë\u0083³R\u0091D\u0094\u000b0eð\u0086U\u001f\u0094\u0095óF\u0007ª}>\u0094-ð{\u007f_k£br\u0005ñ\u0010\u0010C.C\u009e¹Ã0}Ô´}\u0098´¨\u0082\"\u00185»0êÐà\u009b¬èÉ«³@Z?!\u0094\u0012\u0083õEb±Ù «],\u0090½\u001fñîÐ\r\u009dÙÝ/^;V¥)²\u001c\u0081\u001aåîþ0Gs\bIr";
      int var13 = "wvÃ\u0002{ã¬\u008d\u0019\"2n\u0013\u008f¡\u009f @Ù%\u000b'LÖx»\u0013]=_^Y8}õÝ\u0081ÔöHõ\u0000O\f|Wfº&(&]7Ó¢ÞÊ¦\u0006nÿ \u0004\u007f\u001c¤!3Â|ÎÜ\u001d¦Ã´Ý8Í^²{#\u008cNt]ß.Û\u0010ñá$ýd\u000e_\u008d\u007fo\u0007,\u0006£ÑÖ ÷óÃûÕ\"hH\u0010¥\u001f\u001c\u0083,\u0017H©¸\u0097]_Áßk\u008cÁÖÃ@1\u009bò\u0018¡f\u0095¶\u0014tXM3¬Ð6J\u009d&\u001em{×\u0092\u0003ºû\b\u0010\u0096áë -d ;Â1«/\u0002\u001eÖ\u008c\u0018\u0085W`r}\u0007áH\u0016\u0081d®ï³Ò¢\u0010\u008a\u000eG\u0091.{±(\n)aí9Ë\u0083³R\u0091D\u0094\u000b0eð\u0086U\u001f\u0094\u0095óF\u0007ª}>\u0094-ð{\u007f_k£br\u0005ñ\u0010\u0010C.C\u009e¹Ã0}Ô´}\u0098´¨\u0082\"\u00185»0êÐà\u009b¬èÉ«³@Z?!\u0094\u0012\u0083õEb±Ù «],\u0090½\u001fñîÐ\r\u009dÙÝ/^;V¥)²\u001c\u0081\u001aåîþ0Gs\bIr"
         .length();
      char var10 = 16;
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     x = var14;
                     y = new String[14];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(10938231193393L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = -9040439291469007307L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)130L,
                           (byte)33417L,
                           (byte)8554984L,
                           (byte)2190075996L,
                           (byte)560659455194L,
                           (byte)143528820529793L,
                           (byte)36743378055627126L,
                           (byte)-9040439291469007307L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     A = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "\u0015[\u008fBÆõæ\u009b\bGËÒ\u0085Õêãý \u009cãã½$·^\u001f\u000b4Üì½8 ôðÇ3\u0007\u0017}\u0094\u008cNs\u0004 ôÏ2hòÎ\b}\u001b*M\b\u0084ù«\u008cðFn";
                  var13 = "\u0015[\u008fBÆõæ\u009b\bGËÒ\u0085Õêãý \u009cãã½$·^\u001f\u000b4Üì½8 ôðÇ3\u0007\u0017}\u0094\u008cNs\u0004 ôÏ2hòÎ\b}\u001b*M\b\u0084ù«\u008cðFn"
                     .length();
                  var10 = ' ';
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20072;
      if (y[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])z.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               z.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fD", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = x[var5].getBytes("ISO-8859-1");
         y[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return y[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fD_C0277",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fD" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = C[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = B[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 62;
            yield var15;
         }
         case 1 -> {
            byte var16 = 41;
            yield var16;
         }
         case 2 -> {
            byte var17 = 0;
            yield var17;
         }
         case 3 -> {
            byte var18 = 59;
            yield var18;
         }
         case 4 -> {
            byte var19 = 30;
            yield var19;
         }
         case 5 -> {
            byte var20 = 34;
            yield var20;
         }
         case 6 -> {
            byte var21 = 12;
            yield var21;
         }
         case 7 -> {
            byte var22 = 53;
            yield var22;
         }
         case 8 -> {
            byte var23 = 1;
            yield var23;
         }
         case 9 -> {
            byte var24 = 42;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 22;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 26;
            yield var30;
         }
         case 16 -> {
            byte var31 = 23;
            yield var31;
         }
         case 17 -> {
            byte var32 = 15;
            yield var32;
         }
         case 18 -> {
            byte var33 = 46;
            yield var33;
         }
         case 19 -> {
            byte var34 = 21;
            yield var34;
         }
         case 20 -> {
            byte var35 = 39;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 2;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 27;
            yield var39;
         }
         case 25 -> {
            byte var40 = 24;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 14;
            yield var42;
         }
         case 28 -> {
            byte var43 = 4;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 9;
            yield var45;
         }
         case 31 -> {
            byte var46 = 57;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 31;
            yield var49;
         }
         case 35 -> {
            byte var50 = 3;
            yield var50;
         }
         case 36 -> {
            byte var51 = 10;
            yield var51;
         }
         case 37 -> {
            byte var52 = 54;
            yield var52;
         }
         case 38 -> {
            byte var53 = 29;
            yield var53;
         }
         case 39 -> {
            byte var54 = 5;
            yield var54;
         }
         case 40 -> {
            byte var55 = 43;
            yield var55;
         }
         case 41 -> {
            byte var56 = 17;
            yield var56;
         }
         case 42 -> {
            byte var57 = 6;
            yield var57;
         }
         case 43 -> {
            byte var58 = 38;
            yield var58;
         }
         case 44 -> {
            byte var59 = 47;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 16;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 52;
            yield var63;
         }
         case 49 -> {
            byte var64 = 32;
            yield var64;
         }
         case 50 -> {
            byte var65 = 45;
            yield var65;
         }
         case 51 -> {
            byte var66 = 20;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 13;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 8;
            yield var71;
         }
         case 57 -> {
            byte var72 = 56;
            yield var72;
         }
         case 58 -> {
            byte var73 = 28;
            yield var73;
         }
         case 59 -> {
            byte var74 = 55;
            yield var74;
         }
         case 60 -> {
            byte var75 = 7;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 63;
            yield var77;
         }
         default -> 37;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            C[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      B[0] = "TZ\u0011M\u0019oBZ\u0014\u0017\nxU\u0011\u0017\u0011\u0006lDV\u0000\u0006M{~";
      B[1] = "x.1EPh\r\u000e:JA'l\u00001AE}\u0018";
      B[2] = boolean.class;
      C[2] = "java/lang/Boolean";
      B[3] = "1K\r\u0017g?'K\bMt(0\u0000\u000bKx<!G\u001c\\3)\u0011";
      B[4] = "9\u001ff0<g2\u0010w\u007f_j'\u001dx\u0014jh6\u000ed8}e";
      B[5] = "DmH=\u0000rRmMg\u0013eE&Na\u001fqTaYvTce";
      B[6] = int.class;
      C[6] = "java/lang/Integer";
      B[7] = "W &\u000109I(<NM)I";
      B[8] = " X\u001a[4 +W\u000b\u0014U. \\\u000fN";
      B[9] = "\u0012VX\u001cRJ\u0019YIS/_\u000bCK\u0010";
      B[10] = long.class;
      C[10] = "java/lang/Long";
      B[11] = "<npIU87aa\u000665\"g";
      B[12] = double.class;
      C[12] = "java/lang/Double";
      B[13] = "m|\u0005n\u001ah\u0018\\\u000ea\u000b'yR\u0005j\u000f}\r";
      B[14] = void.class;
      C[14] = "java/lang/Void";
      B[15] = ";\u0012\u0010d\u000f\\-\u0012\u0015>\u001cK:Y\u00168\u0010_+\u001e\u0001/[H\u0013";
      B[16] = "I,wI\u000b7<\f|F\u001ax]\u0002wM\u001e\")";
      B[17] = "|lz:Ti\tLq5E&hBz>A|\u001c";
      B[18] = "X\u0019%-%zX\u00192q)uBR2o)`E#b2x";
      B[19] = "$}+\u000b\u0004\r$}<W\b\u0002>6<I\b\u00179Gk\u0016^";
      B[20] = "d\u001aK|.\\d\u001a\\ \"S~Q\\>\"Fy \bfu";
      B[21] = "\n\u0019\u000fAR]\u001c\u0019\n\u001bAJ\u000bR\t\u001dM^\u001a\u0015\u001e\n\u0006N\u0002";
      B[22] = "8\bonZ\u0010M(daK_,&ojO\u0005X";
      B[23] = "=Aku\u000f.Ha`z\u001ea)okq\u001a;]";
      B[24] = ";\u0016\u0002,L,N6\t#]c/8\u0002(Y9[";
      B[25] = "\u001eWv=ir\u001eWaae}\u0004\u001ca\u007feh\u0003m4 <";
      B[26] = "?\u0019e\u0017p\"?\u0019rK|-%RrU|8\"# \u000b$|";
      B[27] = "L\u0012]i~\u0016L\u0012J5r\u0019VYJ+r\fQ(\u0018w'N";
      B[28] = ">KWh~\u0011(KR2m\u0006?\u0000Q4a\u0012.GF#*\u0006;";
      B[29] = "\u007fva=y\u0014\nVj2h[kXa9l\u0001\u001f";
      B[30] = "M\u0019\u0006\u0017\"FM\u0019\u0011K.IWR\u0011U.\\P#@\r|";
      B[31] = "x\u001b&&*?n\u001b#|9(yP z5<h\u00177m~*_";
      B[32] = "\u0019\u0002wV\fNl\"|Y\u001d\u0001\r,wR\u0019[y";
      B[33] = "SFB\u0012^.&fI\u001dOaGhB\u0016K;3";
      B[34] = "i:3T*\u0001i:$\b&\u000esq$\u0016&\u001bt\u0000uI~";
      B[35] = "l>A\"<\u001e\u0019\u001eJ--Qx\u0010A&)\u000b\f";
      B[36] = "\u00119@<\u001b,\u00119W`\u0017#\u000brW~\u00176\f\u0003\u0007+@s";
      B[37] = "*N!\"wF*N6~{I0\u00056`{\\7tg?#\u000b'G4\u007fipv\u001fe";
      B[38] = "\u0015C\u0006S\u001b+`c\r\\\nd\u0001m\u0006W\u000e>u";
      B[39] = float.class;
      C[39] = "java/lang/Float";
      B[40] = "}wSs?\u001dxbXs4\u0006tr\u001a\u001a\u001f,E";
      B[41] = ",%/\u0017#0:%*M0'-n)K<3<)>\\w#'";
      B[42] = "_fCd+-*FHk:bKHC`>8?";
      B[43] = "F\u000e\u007f \u001f F\u000eh|\u0013/\\Ehb\u0013:[4:9Kp";
      B[44] = ";6?\u0002yB;6(^uM!}(@uX&\fz\u001b-\u0019";
      B[45] = "`\u0002\u007feIW\u0015\"tjX\u0018t,\u007fa\\B\u0000";
      B[46] = "t&w\u001d\u0004\u0001\u007f)fRh\u0002q+d\u001dD";
      B[47] = "ao\u0014T`Xwo\u0011\u000esO`$\u0012\b\u007f[qc\u0005\u001f4N\\";
      B[48] = "qas\u00117\u0006\u0004Ax\u001e&IeOs\u0015\"\u0013\u0011";
      B[49] = "AJ\u00194\\\u007fAJ\u000ehPp[\u0001\u000evPe\\p_)\u0002.";
      B[50] = "G\"O8f\tQ\"Jbu\u001eFiIdy\nW.^s2\u001de";
      B[51] = "\u001a\b@\u0014fAo(K\u001bw\u000e\u000e&@\u0010sTz";
      B[52] = ".T\u0001\"?\u001c.T\u0016~3\u00134\u001f\u0016`3\u00063nF=`";
      B[53] = "0c\bGC@0c\u001f\u001bOO*(\u001f\u0005OZ-YMQ\u001e\u001b";
      B[54] = "Y 5\u0003tzO 0YgmXk3_kyI,$H E";
      B[55] = "uo\bns7\u0000O\u0003abxaA\bjf\"\u0015";
      B[56] = "q\u0007e@i,g\u0007`\u001az;pLc\u001cv/a\u000bt\u000b=8|";
      B[57] = "\u001co\"3\u001a\u0004iO)<\u000bK\bA\"7\u000f\u0011|";
      B[58] = "#IdU#:VioZ2u7gdQ6/C";
      B[59] = "N\u00031ls\bE\f #\u001b\bK\u00033";
      B[60] = "02_?97&2Ze* 1yYc&4 >Ntm!\u0001";
      B[61] = "t!*\t\r1\u0001\u0001!\u0006\u001c~`\u000f*\r\u0018$\u0014";
      B[62] = "QJK++\nGJNq8\u001dP\u0001Mw4\tAFZ`\u007f\u0019YFXk%Te]Xv%\u0013RJ";
      B[63] = "\u001d\nh\u0011RI\u000b\nmKA^\u001cAnMMJ\r\u0006yZ\u0006_6";
      B[64] = "k\nlzN@\u001e*gu_\u000f\u007f$l~[U\u000b";
      B[65] = "\u001dU\u0005^cn\u001dU\u0012\u0002oa\u0007\u001e\u0012\u001cot\u0000o@F;1";
      B[66] = "\u0014K\u001e\u0005\rg\u0014K\tY\u0001h\u000e\u0000\tG\u0001}\tqX\u001eV?";
      B[67] = "\u001byWW0\u0003\u0010vF\u0018M\u001b\u0003qOQ";
      B[68] = "\u000f\u0001V\u001c2\u0004\u000f\u0001A@>\u000b\u0015JA^>\u001e\u0012;\u0013\u0004jZ";
      B[69] = "\u007f^b4kGi^gnxP~\u0015dhtDoRs\u007f?U\u007f";
      B[70] = "\u00020\u0002U(\u0004w\u0010\tZ9K\u0016\u001e\u0002Q=\u0011b";
      B[71] = "sM44L,sM#h@#i\u0006#v@6nwr/\u0018s";
      B[72] = "F_g\u0007\u0018rP_b]\u000beG\u0014a[\u0007qVSvLLfj";
      B[73] = "JV\\\u001bz!?vW\u0014kn^x\\\u001fo4*";
      B[74] = "g\u0019\u0015*g-q\u0019\u0010pt:fR\u0013vx.w\u0015\u0004a39I";
      B[75] = "\\RS]\u001ci)rXR\r&H|SY\t|<";
      B[76] = "=J,p=7Hj'\u007f,x)d,t(\"]";
      B[77] = "f~WApd\u0013^\\Na+rPWEeq\u0006";
      B[78] = "S\u001dn\u0018d\\\u0018\t*\u001b\u0018DiHt\u0006%P\u0006\u0013{DhDi@o\u0001`M\u0016\u001fz\u0004u ";
      B[79] = "B@]\txmO\u0002\u000b_\u0016>\u0016\u0017\bI\u0016e\u0010\u001d\u001dL/i\f\u001f\u00171&7\u0011\u000e\u0010\b*+\u0013\u0004m\u0001t6\u0002\u0003T\rh4\b~]Su%\u000fGQOw/r";
      B[80] = "e*m\u0018D435*@$`\fpt\u0006\u0019zc+{DTn\fxo\u0001\\gs'z\u0004I\n";
      B[81] = "Y_*j@ \u0012Kni<5c\n0t\u0001,\fQ?6L8c\n,hLa\u0001T!bF\\";
      B[82] = "vQpp1*+Cbs\\4!J|\u0010=7%,$\"#>sIgw=/H";
      B[83] = "8HTG}Hp\u0006OI':nv\u001f\u0014e\u0003?\u001a\u001dP}J`";
      B[84] = "?\u0019CS)6i\u0004J@~Qot\u0013L1lv\u001bHCs!bt\u0013A'.a\u0013E\\.=6t";
      B[85] = "_\u0016v\u0002\u001di_Hr\u0001#9U\u0019m\u0011tn\u000bI4}O5F\fh\u0011RkW\u001f";
      B[86] = "x\u0016-Uo^x\u00199\u00118$/F+\ris~\u001bvQ\u0005\u001d=D6TgC0N<";
      B[87] = "\u001fF$\u0010k2\u001f\u0018 \u0013Ui\u0019X;\b9[M\u0019e^U5\bG+R7k\u0005M!o";
      B[88] = "h=)\f*,-k;XrB8S\u007f\\o\u007f!<$S-25S\u007fR\u007frk=:\u0004m&3S";
      B[89] = "\u0007.j4sK\u0012wg,\r^\u0007kn1alP+>l=;Skm&0Y\rfg,\r";
      B[90] = "Koly+\u007fF|qwD/&)aky6Irn)4\"&!zl<+Y~oi)F";
      B[91] = "~@&OH\u000e5TbL4\u001bD\u0015<Q\t\u0002+N3\u0013D\u0016D\u001c>MD\u000f}\u0010\"ONr";
      B[92] = "J\u0018wyS\\\u0001\f3z/CpMmg\u0012P\u001f\u0016b%_DpEv`WM\u000f\u001aceB ";
      B[93] = "r\\BgIw7\bHuGL$X\u0004EI6*S\u0017\u001e\f%%R\u001aqU+.W\u001e\u001e";
      B[94] = "5!p:\u0018f8c&lv;dy@2\u0014=uby>\b?\u007f\u001fp`\u0015.x&||\u0017$\u0005/\"a\u0006#<#>c\f^";
      B[95] = "\u0018.\u0003[wJH{\tQ\tN\u0015=\b\u0006e|H}VP\t\u0017\u0005-\u0004^8S\u001e'\rah\u0012\u00019Y\u0003yP\t%h";
      B[96] = "3Ga}mI3\u0019e~S\u00125Y~e? b\u001f 2hw:La=0\u00111\u001ezdS";
      B[97] = "rQ&\u0004=L P%\u00151}.V0\u0016(\u0011\u001c\u0004wLr}rG/\u0006r\u001f,J%\fO";
      B[98] = "ePd\u001b\"\u0001t\u0012l\u0007\u0013\u0006i\u0015}\u0004\u007f49V#\\\u0013Zx\nm^q\u0004u\u0000gc";
      B[99] = "\u0007t\r0g\b\u000fuM#\u0002\u0007e<\u00103?\u001e\ng\u001fqr\ne<\f/rS\u0007b\u0001%xn";
      B[100] = "Gb)?\b\r_rjnj\u001eE}v?=I\u001f-+SZ\u0012G`ojV\u000eEj";
      B[101] = "2^\u001aA84n\u0013]T\u00056V\u001aGA8/9AH\u0003u;VB\u001eG}n4S\\Oa_";
      B[102] = "E.% 4+H=8.[~(h(2fbG3'p+v(h4.+/J69$!\u0012";
      B[103] = "zrh6GOx6p\u007f\u0018#*M+o\u0006\u001e3\"p`DS'M+s\u001aS~/u~\u0010YC";
      B[104] = "%\u0007VjC\u0012%YRi}B/\bMy*\u0015q[\u0014\u0015\u001b^3\fK{C\u0013*\f";
      B[105] = "g]/\u0001T\u0010f\u0015/U/F\\\u00161C\u0012\\3M>\u0001_H\\\u0016-__\u0011>H UU,";
      B[106] = "iR$aJr-\b|dvh|J#8\u001aZ(\t|oL\rp\u000f:'GoaM2;v";
      B[107] = "\u001edjJFI\u001e:nIx\u0019\u0014kqY/NK6*5\u0018\u0018\u001e<kTHM\u00146";
      B[108] = "M#OM+A\u0015nVMIJF-RC%x\u0012n\r\u0014r/S*UF&MR4QGI";
      B[109] = "\u00049&,g\u0016R&at\u0007Fmc?2:X\u000280pwLm f&;T\u0000(o$8(";
      B[110] = "4ckVG\\.q(E:T*q.kWG\u000bx,_Wq3c-C\\;qq.H\u0001^2$0Y:\u00073s=\u001b\u000bC(y4$\u0006F\"sn\u0015B](zQ";
      B[111] = "ad\u0013+\u0011\"3e\u0010:\u001d\u0013=c\u00059\u0004\u007f\u000f5@d_\"X7H2_y\"7G&\u001b.X";
      B[112] = "\u0017\u007f\u0016$jB\u0010}\u000eT9\u007fB%\u000ei \u0010\u0019*L$4\u007f\u0017\u007f\u0016$jB\u0010}\u000eT";
      B[113] = "\u0019a\u001b>\u0005\u0002\u0018s\u0015\u007fc\rb!\u0004x^\u0014\rz\u000b:\u0013\u0000b!\u0018d\u0013Y\u0000\u007f\u0015n\u0019d";
      B[114] = "'o\u0004\u0005d\u001626\t\u001d\u001a\u0003'*\u0000\u0000v1toYZ\u001a_65\u0010Zx\u0001;?\u001ag";
      B[115] = "R8[\b\u001b<U:CxH\u0001\u0007bCEQn\\m\u0001\bE\u0001\u0007~_\b\u001ccYsU\u0002!";
      B[116] = "!D\u0013\u000b\u001aJ \f\u0013_a\u001c\u001a\n\u0010Z\rI+N\u000bP\u0004v";
      B[117] = "hb\u0001k\u00062lsP=?,xs[gS\u001e*>\u00031?7)sD|];q6A\u0000";
      B[118] = "l6U>K\\yoX&5B`bU0b\u001296\u000e\\\u0005Nb\u007fLe\tR`u";
      B[119] = "$Qu\u001dU;u\u0011$\u001ch&v!!\u001d\u0016!xG|U\u0015(\u0018\u001f&Z\b!~BnY\u0001A$Qu\u001dU;u\u0011$\u001ch";
      B[120] = "6BL\u0007\u0011$}V\b\u0004m:\f\u0017V\u0019P(cLY[\u001d<\f\u001fM\u001e\u00155s@X\u001b\u0000X";
      B[121] = "*eLLh\b;'DPY\u000f& US5=vb\u000f\u0004YV60Y\u000bh\u0012-:P4";
      B[122] = "^RI<JS\u0015F\r?6Fd\u0005\u000e4\nQ\u001a\u0000\u0003fI/_\u0003ZaHQZ\u000e\b\"6";
      B[123] = "jbChG/k|Gi( kdMnSM, ZjH+qhYc(tnzT7J*cp^\n";
      B[124] = "\nW\"\t\tY\u000b\u001f\"]r\u000e1\u0019!X\u001eZ\u0000]:R\u0017e";
      B[125] = "2W#^z\u0004|Gu\u0003\u0019\u0011*Y\u007fTp\u001d\u0013W\u007fDt{tBxI$\u0019*OrC\u0019";
      B[126] = "L~ \u0018lT]<(\u0004]S@;9\u00071a\u0010wa]]\u000fQ$)]?Q\\.#`";
      B[127] = "_\u0007iBf\u0013R\u0019z\u0016ZD Ee\rg^O\u001ejO*J Ey\u0011*\u0013B\u001bt\u001b .";
      B[128] = "L\u000b\u0015l!\u0016\u001a\u0014R4AA%Q\fr|XJ\n\u000301L%\u0001\u000ft H\u001bW\u00103x(";
      B[129] = "XL\u0012A&yI\u000e\u001a]\u0017~T\t\u000b^{L\u0003IV\u0000*\u001bI\u0007PX|{S\u001b\u000bA\u0017";
      B[130] = "ON\u0011:g&U_@4\u0015&>\u0000B#u/X]\n |O";
      B[131] = "-h_\u001a5/81R\u0002K:--[\u001f'\b}n\u0000IK>y(CI)/; _x1f+mG\u00159o)n;";
      B[132] = "<nbDJB)7o\\4W<+fAXenm8\u001f4Hh<:ZY@a>9&N\u000b:kzKF\u00028h\u0006";
      B[133] = "\u0007\u001f^U:\u0005\u0012FSMD\u0010\u0007ZZP(\"S\u0016\u0005\u0006tu\tT\u0001[&\b\u0011DB\nD";
      B[134] = "YmDg\u001b`Y3@d%0Sb_trg\r5\u0007\u0018HgVmEh]>[u";
      B[135] = "\u0000\u0006b+y0\r\u0018q\u007fEd\u007fDndx}\u0010\u001fa&5i\u007fLuc=`\u0000\u0013`f(\r";
      B[136] = "3&O2Eba'L#ISo!Y P?]w\u001c|\u0007j\nuY#Gnh+T)MS";
      B[137] = "\u0013\u001e**&^\u0013@.)\u0018\u000e\u0019\u001119OYGFdU!X\u0014\u0012mi%[\b\r4";
      B[138] = "\u0019[\u0004\u001auo\u0018E\u0000\u001b\u001ac\u0000M\u0007\u0014M4Z\u001bZxbv\u0006B\f\u001ach\u0002C";
      B[139] = "|\u0010@^\u0001&#\u0011\u0017\u0002UZ+H\u0010Z\u0000\ru\u0012E\u0007l$yU\u0002B\u000e(!\u0010\u0007";
      B[140] = "\btFg_3Q.\u0018q\u0019VXNF~\u001fkA!\u001dq]&UNNe\u0018.\\1\u0011p\u001d;1";
      B[141] = "\u0002\u0000=\u0004x\t\nFlJ}gR;5X9ZKTnW{\u0017_;v\u0001-[GV~\b/X;";
      B[142] = "B=$8Eq\u0010<')I@\u001e:2*P,,jru\b@B>t3K{\u0007j~!E@";
      B[143] = "\u00043\b0M\u0010\u000fa\u0013i.\u0013\u000b&\u0017hB!ZfF7.I\b%\u001b4K\n];\n\u000f";
      B[144] = "`\u00012cM\ta\u0013<\"+\b\u001bA-%\u0016\u001ft\u001a\"g[\u000b\u001bA19[Ry\u001f<3Qo";
      B[145] = "l\u001f$U2myF)MLxlZ P J?\u001e|\bL`l\u001c+\u000e7d}M}7";
      B[146] = "m\u0000\u0018q\u00107lD\u00143\fR:YB`\u000e\f=YXdr(mV\u0019u\u001f dT\u001a\t";
      B[147] = "ey*\u001awX&;*\u0006\"&5Du\u00026\u001b,+.\rtV8Du\u001e*Va&+\u0013 \\\\";
      B[148] = "9\u0006\u0003`WGk\u0007\u0000q[ve\u0001\u0015rB\u001aWVX/\u001dJ\u0000U\u0015qUKb\u000b\u0018{_v";
      B[149] = "yv\u001d?`8q'I72F)\u001dM%|{0r\u0016*>6$\u001dM){x/wEzi=;\u001d";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = B[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(C[var4]);
            B[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = B[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            B[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  B[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(614648211839074L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = B[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = C[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  B[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(614648211839074L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        B[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(614648211839074L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 115;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 253;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 235;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 207;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 212;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 72;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 115;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 253;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 235;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fD_C0277",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fD" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Triggerbot var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$4", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(Triggerbot var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$6", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(Triggerbot var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$3", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(Triggerbot var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(Triggerbot var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$0", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(Triggerbot var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(Triggerbot var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$7", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(Triggerbot var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fD_C0277;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fD_C0277", "lambda$new$2", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((Triggerbot)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
