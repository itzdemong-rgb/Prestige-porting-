package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.management.PlayerValidationTracker;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.FrustumEvent;
import dev.zprestige.prestige.api.events.EntityOverlayRenderEvent;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.client.modules.state.EntityScreenBounds;
import dev.zprestige.prestige.client.modules.state.ScreenBoundsAnimation;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.management.SocialsManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;

public class TwoDESP extends Module {
   private BooleanSetting d;
   private ModeSetting a;
   private FloatSetting c;
   private FloatSetting e;
   private MultiModeSetting f;
   private FloatSetting g;
   private FloatSetting h;
   private BooleanSetting i;
   private FloatSetting j;
   private ModeSetting k;
   private BooleanSetting l;
   private BooleanSetting m;
   private FloatSetting n;
   private IntSetting o;
   private IntSetting p;
   private BooleanSetting q;
   private ColorSetting r;
   private ColorSetting s;
   private ColorSetting t;
   private ColorSetting u;
   private ColorSetting v;
   private Frustum w;
   private long x;
   private long y;
   private Map z;
   private Map A;
   private static final long B = 95832993219536L;
   private static final String[] C;
   private static final String[] D;
   private static final Map E = new HashMap(13);
   private static final long[] F;
   private static final Integer[] G;
   private static final Map H;
   private static final long[] I;
   private static final Long[] J;
   private static final Map K;
   private static final Object[] L = new Object[205];
   private static final String[] M = new String[205];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;

   public TwoDESP() {
      super();
      long var10001 = 40841704751742L ^ 657978769726L;
      var10001 = 40841704751742L ^ 64131948310697L;
      var10001 = 40841704751742L ^ 83274308817338L;
      var10001 = 40841704751742L ^ 129624190519762L;

      this.x = 0L;
      this.y = 0L;
      this.z = new LinkedHashMap();
      this.A = new HashMap();
      BooleanSetting var10000 = this.l;
      Object[] var12 = new Object[]{invokeBinding1(this), 88791076916140L};
      BooleanSetting var11 = var10000;
      var11.aReturningBooleanSetting(var12);
      ColorSetting var33 = this.u;
      Object[] var14 = new Object[]{invokeBinding2(this), 41489415177024L};
      ColorSetting var13 = var33;
      var13.aReturningColorSetting(var14);
      var10000 = this.m;
      Object[] var16 = new Object[]{invokeBinding3(this), 88791076916140L};
      BooleanSetting var15 = var10000;
      var15.aReturningBooleanSetting(var16);
      FloatSetting var35 = this.j;
      Object[] var18 = new Object[]{invokeBinding4(this), 34595201528535L};
      FloatSetting var17 = var35;
      var17.aReturningFloatSetting(var18);
      ModeSetting var36 = this.k;
      Object[] var20 = new Object[]{invokeBinding5(this), 121607650890692L};
      ModeSetting var19 = var36;
      var19.aReturningModeSetting(var20);
      FloatSetting var37 = this.g;
      Object[] var22 = new Object[]{invokeBinding6(this), 34595201528535L};
      FloatSetting var21 = var37;
      var21.aReturningFloatSetting(var22);
      var10000 = this.i;
      Object[] var24 = new Object[]{invokeBinding7(this), 88791076916140L};
      BooleanSetting var23 = var10000;
      var23.aReturningBooleanSetting(var24);
      ColorSetting var39 = this.r;
      Object[] var26 = new Object[]{invokeBinding8(this), 41489415177024L};
      ColorSetting var25 = var39;
      var25.aReturningColorSetting(var26);
      ColorSetting var40 = this.s;
      Object[] var28 = new Object[]{invokeBinding9(this), 41489415177024L};
      ColorSetting var27 = var40;
      var27.aReturningColorSetting(var28);
      ColorSetting var41 = this.v;
      Object[] var30 = new Object[]{invokeBinding10(this), 41489415177024L};
      ColorSetting var29 = var41;
      var29.aReturningColorSetting(var30);
      FloatSetting var42 = this.h;
      Object[] var32 = new Object[]{invokeBinding11(this), 34595201528535L};
      FloatSetting var31 = var42;
      var31.aReturningFloatSetting(var32);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 13397636174234L ^ 95524926739294L;
      var10001 = 13397636174234L ^ 44557480881227L;
      int var8 = Event.cReturningInt();
      int var81 = var8;
      MinecraftClient var80 = b;
      MinecraftClient var71 = var80;
      MinecraftClient var70 = var80;
      if (var81 != 0) {
         MinecraftClient var16 = var70;
         ClientWorld var82 = var16.world;
         if (var82 == null) {
            return;
         }

         MinecraftClient var83 = b;
         var71 = var83;
      }

      MinecraftClient var19 = var71;
      int var85 = var8;
      ClientPlayerEntity var84 = var19.player;
      Object var73 = var84;
      ClientPlayerEntity var72 = var84;
      if (var85 != 0) {
         ClientPlayerEntity var86 = var72;
         if (var86 == null) {
            return;
         }

         Map var21 = this.z;
         var21.clear();
         IntSetting var22 = this.o;
         var73 = var22.aReturningObject();
      }

      Integer var23 = (Integer)var73;
      int var9 = var23;
      BooleanSetting var24 = this.d;
      Boolean var25 = (Boolean)var24.aReturningObject();
      byte var10 = ((byte)(((java.lang.Boolean)(var25)).booleanValue() ? 1 : 0));
      ArrayList var11 = new ArrayList();
      MinecraftClient var26 = b;
      ClientWorld var27 = var26.world;
      List var28 = var27.getPlayers();
      Iterator var12 = var28.iterator();

      while (true) {
         Iterator var29 = var12;
         boolean var87 = var29.hasNext();
         if (var87) {
            Iterator var30 = var12;
            PlayerEntity var13 = (PlayerEntity)var30.next();
            int var88 = var8;
            if (var88 == 0) {
               break;
            }

            MinecraftClient var31 = b;
            ClientPlayerEntity var90 = var31.player;
            PlayerEntity var89 = var13;
            if (var89 == var90) {
               continue;
            }

            PlayerValidationTracker var10000 = Prestige.i;
            Object[] var35 = new Object[]{var13, 99841884226244L};
            PlayerValidationTracker var34 = var10000;
            boolean var111 = var34.aReturningBoolean(var35);
            int var92 = var8;
            boolean var91 = var111;
            boolean var75 = var91;
            boolean var74 = var91;
            if (var92 != 0) {
               boolean var93 = var74;
               if (!var93) {
                  continue;
               }

               PlayerEntity var37 = var13;
               var75 = var37.isRemoved();
            }

            boolean var94 = var75;
            if (var94) {
               continue;
            }

            MinecraftClient var38 = b;
            PlayerEntity var40 = var13;
            ClientPlayerEntity var39 = var38.player;
            float var14 = var39.distanceTo((Entity)var40);
            float var118;
            int var112 = (var118 = var14 - var9) == 0.0F ? 0 : (var118 < 0.0F ? -1 : 1);
            int var96 = var8;
            int var95 = var112;
            int var77 = var95;
            int var76 = var95;
            if (var96 != 0) {
               int var97 = var76;
               if (var97 > 0) {
                  continue;
               }

               var77 = var10;
            }

            label70: {
               int var99 = var8;
               int var98 = var77;
               int var79 = var98;
               int var78 = var98;
               if (var99 != 0) {
                  int var100 = var78;
                  if (var100 != 0) {
                     break label70;
                  }

                  PlayerEntity var43 = var13;
                  byte var101 = ((byte)((var43.isInvisible()) ? 1 : 0));
                  var79 = var101;
               }

               int var102 = var79;
               if (var102 != 0) {
                  continue;
               }
            }

            EntityScreenBounds var15 = new EntityScreenBounds();
            var15.a = var13;
            PlayerEntity var45 = var13;
            Text var46 = var45.getName();
            var15.b = var46.getString();
            PlayerEntity var47 = var13;
            float var115 = var47.getHealth();
            PlayerEntity var48 = var13;
            var15.c = var115 + var48.getAbsorptionAmount();
            PlayerEntity var49 = var13;
            float var51 = var49.getMaxHealth();
            float var50 = 1.0F;
            var15.d = Math.max(var50, var51);
            PlayerEntity var52 = var13;
            var15.e = var52.getWidth();
            PlayerEntity var53 = var13;
            var15.f = var53.getHeight();
            var15.g = var14;
            SocialsManager var116 = Prestige.g;
            Object[] var55 = new Object[]{var15.b, 40309233401297L};
            SocialsManager var54 = var116;
            var15.h = var54.aReturningBoolean(var55);
            EntityScreenBounds var57 = var15;
            ArrayList var56 = var11;
            var56.add(var57);
            int var103 = var8;
            if (var103 != 0) {
               continue;
            }
         }

         ToDoubleFunction var58 = invokeBinding12();
         Comparator var60 = Comparator.comparingDouble(var58);
         ArrayList var59 = var11;
         var59.sort(var60);
         break;
      }

      int var108;
      do {
         ArrayList var61 = var11;
         int var105 = var61.size();
         int var104 = var109;
         if (var104 >= var105) {
            break;
         }

         IntSetting var62 = this.p;
         Integer var63 = (Integer)var62.aReturningObject();
         int var107 = var63;
         int var106 = var109;
         if (var106 >= var107) {
            break;
         }

         int var65 = var109;
         ArrayList var64 = var11;
         EntityScreenBounds var110 = (EntityScreenBounds)var64.get(var65);
         Map var113 = this.z;
         PlayerEntity var66 = var110.a;
         UUID var117 = var66.getUuid();
         EntityScreenBounds var69 = var110;
         UUID var68 = var117;
         Map var67 = var113;
         var67.put(var68, var69);
         var109++;
         var108 = var8;
      } while (var108 != 0);
   }

   @EventListener
   public void a(FrustumEvent var1) {
      Object[] var5 = new Object[0];
      FrustumEvent var4 = var1;
      this.w = var4.aReturningVoid(var5);
   }

   
   @EventListener
   public void a(EntityOverlayRenderEvent var1) {
      long var10001 = 61894776083123L ^ 60815108704210L;
      var10001 = 61894776083123L ^ 106019831582786L;
      var10001 = 61894776083123L ^ 25734485330892L;
      var10001 = 61894776083123L ^ 96367277077364L;
      var10001 = 61894776083123L ^ 132703600642269L;
      var10001 = 61894776083123L ^ 5859091541462L;
      var10001 = 61894776083123L ^ 17575504033709L;
      int var18 = Event.cReturningInt();
      int var164 = var18;
      MinecraftClient var163 = b;
      MinecraftClient var136 = var163;
      MinecraftClient var135 = var163;
      if (var164 != 0) {
         MinecraftClient var42 = var135;
         ClientWorld var165 = var42.world;
         if (var165 == null) {
            return;
         }

         MinecraftClient var166 = b;
         var136 = var166;
      }

      int var168 = var18;
      MinecraftClient var167 = var136;
      MinecraftClient var138 = var167;
      MinecraftClient var137 = var167;
      if (var168 != 0) {
         MinecraftClient var45 = var137;
         ClientPlayerEntity var169 = var45.player;
         if (var169 == null) {
            return;
         }

         var138 = b;
      }

      label184: {
         MinecraftClient var48 = var138;
         int var171 = var18;
         Screen var170 = var48.currentScreen;
         Screen var140 = var170;
         Screen var139 = var170;
         if (var171 != 0) {
            Screen var172 = var139;
            if (var172 == null) {
               break label184;
            }

            MinecraftClient var50 = b;
            Screen var173 = var50.currentScreen;
            var140 = var173;
         }

         boolean var174 = var140 instanceof ChatScreen;
         if (!var174) {
            return;
         }
      }

      this.y++;
      long var19 = System.currentTimeMillis();
      long var280;
      int var175 = (var280 = this.x - 0L) == 0L ? 0 : (var280 < 0L ? -1 : 1);
      float var141;
      if (!((var175) != 0)) {
         float var176 = 0.0F;
         var141 = var176;
      } else {
         float var55 = (float)(var19 - this.x) / 1000.0F;
         float var54 = 0.1F;
         var141 = Math.min(var54, var55);
      }

      float var22;
      int var23;
      int var24;
      MsdfFont var25;
      Matrix4f var26;
      Color var144;
      label177: {
         float var21 = var141;
         this.x = var19;
         float var262 = -var21;
         FloatSetting var56 = this.n;
         Float var57 = (Float)var56.aReturningObject();
         double var58 = var262 * var57;
         var22 = 1.0F - (float)Math.exp(var58);
         MinecraftClient var60 = b;
         Window var61 = var60.getWindow();
         var23 = var61.getScaledWidth();
         MinecraftClient var62 = b;
         Window var63 = var62.getWindow();
         var24 = var63.getScaledHeight();
         MsdfFontManager var10000 = Prestige.c;
         Object[] var65 = new Object[]{51869363673471L};
         MsdfFontManager var64 = var10000;
         var25 = var64.aReturningcx_C0158(var65);
         var26 = new Matrix4f();
         BooleanSetting var66 = this.q;
         Boolean var244 = (Boolean)var66.aReturningObject();
         int var178 = var18;
         Boolean var177 = var244;
         Object var143 = var177;
         Boolean var142 = var177;
         if (var178 != 0) {
            Boolean var67 = var142;
            boolean var179 = var67;
            if (var179) {
               ModuleManager var245 = Prestige.d;
               Object[] var70 = new Object[0];
               ModuleManager var69 = var245;
               MenuSettings var246 = var69.aReturningMenuSettings(var70);
               Object[] var72 = new Object[0];
               MenuSettings var71 = var246;
               ColorSetting var73 = var71.bReturningColorSetting(var72);
               Color var180 = (Color)var73.aReturningObject();
               var144 = var180;
               break label177;
            }

            ColorSetting var75 = this.r;
            var143 = var75.aReturningObject();
         }

         var144 = (Color)var143;
      }

      Color var27;
      Color var28;
      float var147;
      label171: {
         label170: {
            var27 = var144;
            ColorSetting var76 = this.s;
            var28 = (Color)var76.aReturningObject();
            MultiModeSetting var247 = this.f;
            Object[] var78 = new Object[]{"Gradient", 71444480285294L};
            MultiModeSetting var77 = var247;
            boolean var248 = var77.aReturningBoolean(var78);
            int var182 = var18;
            boolean var181 = var248;
            boolean var146 = var181;
            boolean var145 = var181;
            if (var182 != 0) {
               boolean var183 = var145;
               if (!var183) {
                  break label170;
               }

               BooleanSetting var80 = this.i;
               Boolean var81 = (Boolean)var80.aReturningObject();
               boolean var184 = var81;
               var146 = var184;
            }

            boolean var185 = var146;
            if (var185) {
               double var249 = var19 / 1000.0;
               FloatSetting var83 = this.j;
               Float var84 = (Float)var83.aReturningObject();
               double var85 = var249 * var84.floatValue();
               float var186 = (float)((Math.sin(var85) + 1.0) * 0.5);
               var147 = var186;
               break label171;
            }
         }

         var147 = 0.0F;
      }

      float var29 = var147;
      Map var88 = this.z;
      Set var89 = var88.entrySet();
      Iterator var30 = var89.iterator();

      Object var160;
      while (true) {
         Iterator var90 = var30;
         boolean var187 = var90.hasNext();
         if (var187) {
            Iterator var91 = var30;
            Entry var31 = (Entry)var91.next();
            Entry var92 = var31;
            UUID var32 = (UUID)var92.getKey();
            Entry var93 = var31;
            EntityScreenBounds var33 = (EntityScreenBounds)var93.getValue();
            PlayerEntity var34 = var33.a;
            int var189 = var18;
            PlayerEntity var188 = var34;
            var160 = var188;
            PlayerEntity var148 = var188;
            if (var189 == 0) {
               break;
            }

            int var191 = var18;
            PlayerEntity var190 = var148;
            PlayerEntity var151 = var190;
            PlayerEntity var149 = var190;
            if (var191 != 0) {
               PlayerEntity var192 = var149;
               PlayerEntity var150 = var192;
               PlayerEntity var193 = var150;
               if (var193 == null) {
                  continue;
               }

               var151 = var34;
               PlayerEntity var96 = var151;
               boolean var194 = var96.isRemoved();
               if (var194) {
                  continue;
               }
            } else {
               PlayerEntity var226 = var151;
               boolean var240 = var226.isRemoved();
               if (var240) {
                  continue;
               }
            }

            label120: {
               int var196 = var18;
               Frustum var195 = this.w;
               Frustum var153 = var195;
               Frustum var152 = var195;
               if (var196 != 0) {
                  Frustum var197 = var152;
                  if (var197 == null) {
                     break label120;
                  }

                  Frustum var198 = this.w;
                  var153 = var198;
               }

               PlayerEntity var100 = var34;
               Box var102 = var100.getBoundingBox();
               Frustum var101 = var153;
               boolean var199 = var101.isVisible(var102);
               if (!var199) {
                  continue;
               }
            }

            Object[] var104 = new Object[]{var34, 123069091094983L};
            Vec3d var35 = GameRenderUtil.bReturningVec3d(var104);
            float var10002 = var33.e;
            float var10003 = var33.f;
            Object[] var10006 = new Object[]{null, null, null, 67204111777637L};
            var10006[2] = var10003;
            var10006[1] = var10002;
            var10006[0] = var35;
            Object[] var106 = var10006;
            TwoDESP var105 = this;
            float[] var36 = var105.aReturningArrayOfFloat(var106);
            int var201 = var18;
            float[] var200 = var36;
            float[] var155 = var200;
            float[] var154 = var200;
            if (var201 != 0) {
               float[] var202 = var154;
               if (var202 == null) {
                  continue;
               }

               var155 = var36;
            }

            float var250 = var155[0];
            var10002 = var23 + 20;
            Object[] var10005 = new Object[]{null, null, null, 96927383470833L};
            var10005[2] = var10002;
            var10005[1] = -20.0F;
            var10005[0] = var250;
            Object[] var108 = var10005;
            float var37 = dReturningFloat(var108);
            var250 = var36[1];
            var10002 = var24 + 20;
            var10005 = new Object[]{null, null, null, 96927383470833L};
            var10005[2] = var10002;
            var10005[1] = -20.0F;
            var10005[0] = var250;
            Object[] var109 = var10005;
            float var38 = dReturningFloat(var109);
            var250 = var36[2];
            var10002 = var23 + 20;
            var10005 = new Object[]{null, null, null, 96927383470833L};
            var10005[2] = var10002;
            var10005[1] = -20.0F;
            var10005[0] = var250;
            Object[] var110 = var10005;
            float var39 = dReturningFloat(var110);
            var250 = var36[3];
            var10002 = var24 + 20;
            var10005 = new Object[]{null, null, null, 96927383470833L};
            var10005[2] = var10002;
            var10005[1] = -20.0F;
            var10005[0] = var250;
            Object[] var111 = var10005;
            float var40 = dReturningFloat(var111);
            float var281;
            int var254 = (var281 = var39 - var37 - 3.0F) == 0.0F ? 0 : (var281 < 0.0F ? -1 : 1);
            int var204 = var18;
            int var203 = var254;
            int var157 = var203;
            int var156 = var203;
            if (var204 != 0) {
               int var205 = var156;
               if (var205 < 0) {
                  continue;
               }

               float var282;
               var157 = (var282 = var40 - var38 - 3.0F) == 0.0F ? 0 : (var282 < 0.0F ? -1 : 1);
            }

            int var206 = var157;
            if (var206 < 0) {
               continue;
            }

            UUID var114 = var32;
            Map var113 = this.A;
            ScreenBoundsAnimation var41 = (ScreenBoundsAnimation)var113.get(var114);
            int var208 = var18;
            ScreenBoundsAnimation var207 = var41;
            ScreenBoundsAnimation var159 = var207;
            ScreenBoundsAnimation var158 = var207;
            if (var208 != 0) {
               ScreenBoundsAnimation var209 = var158;
               if (var209 == null) {
                  var41 = new ScreenBoundsAnimation();
                  var41.e = 0.0F;
                  ScreenBoundsAnimation var118 = var41;
                  UUID var117 = var32;
                  Map var116 = this.A;
                  var116.put(var117, var118);
               }

               var41.a = var37;
               var41.b = var38;
               var41.c = var39;
               var41.d = var40;
               float var263 = var41.e;
               var10006 = new Object[]{null, null, null, 16512519230817L};
               var10006[2] = var22;
               var10006[1] = 1.0F;
               var10006[0] = var263;
               Object[] var119 = var10006;
               var41.e = bReturningFloat(var119);
               var41.f = this.y;
               var159 = var41;
            }

            var159.g = var33;
            MeshBufferManager var264 = var1.a;
            RenderContext var271 = var1.b;
            Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, 61259614053662L};
            var10013[9] = var19;
            var10013[8] = var29;
            var10013[7] = var28;
            var10013[6] = var27;
            var10013[5] = var41;
            var10013[4] = var33;
            var10013[3] = var25;
            var10013[2] = var26;
            var10013[1] = var271;
            var10013[0] = var264;
            Object[] var121 = var10013;
            TwoDESP var120 = this;
            var120.jReturningVoid(var121);
            int var210 = var18;
            if (var210 != 0) {
               continue;
            }

            Map var122 = this.A;
            Set var123 = var122.entrySet();
            var30 = var123.iterator();
         } else {
            Map var227 = this.A;
            Set var228 = var227.entrySet();
            var30 = var228.iterator();
         }

         Iterator var124 = var30;
         boolean var211 = var124.hasNext();
         if (!var211) {
            return;
         }

         Iterator var125 = var30;
         Entry var221 = (Entry)var125.next();
         Entry var126 = var221;
         var160 = var126.getValue();
         break;
      }

      while (true) {
         ScreenBoundsAnimation var225;
         while (true) {
            label148: {
               var225 = (ScreenBoundsAnimation)var160;
               long var283;
               int var255 = (var283 = var225.f - this.y) == 0L ? 0 : (var283 < 0L ? -1 : 1);
               int var213 = var18;
               int var212 = var255;
               int var162 = var212;
               int var161 = var212;
               if (var213 != 0) {
                  int var214 = var161;
                  if (var214 == 0) {
                     Iterator var231 = var30;
                     boolean var243 = var231.hasNext();
                     if (!var243) {
                        return;
                     }

                     Iterator var234 = var30;
                     Entry var224 = (Entry)var234.next();
                     Entry var237 = var224;
                     var160 = var237.getValue();
                     continue;
                  }

                  float var265 = var225.e;
                  Object[] var278 = new Object[]{null, null, null, 16512519230817L};
                  var278[2] = var22;
                  var278[1] = 0.0F;
                  var278[0] = var265;
                  Object[] var128 = var278;
                  var225.e = bReturningFloat(var128);
                  int var215 = var18;
                  if (var215 == 0) {
                     break label148;
                  }

                  float var284;
                  int var216 = (var284 = var225.e - 0.02F) == 0.0F ? 0 : (var284 < 0.0F ? -1 : 1);
                  var162 = var216;
               }

               int var217 = var162;
               if (var217 >= 0) {
                  EntityScreenBounds var218 = var225.g;
                  if (var218 != null) {
                     break;
                  }

                  Iterator var131 = var30;
                  var131.remove();
               } else {
                  Iterator var238 = var30;
                  var238.remove();
               }
            }

            int var219 = var18;
            if (var219 == 0) {
               break;
            }

            Iterator var229 = var30;
            boolean var241 = var229.hasNext();
            if (!var241) {
               return;
            }

            Iterator var232 = var30;
            Entry var222 = (Entry)var232.next();
            Entry var235 = var222;
            var160 = var235.getValue();
         }

         MeshBufferManager var266 = var1.a;
         RenderContext var272 = var1.b;
         EntityScreenBounds var276 = var225.g;
         Object[] var279 = new Object[]{null, null, null, null, null, null, null, null, null, null, 61259614053662L};
         var279[9] = var19;
         var279[8] = var29;
         var279[7] = var28;
         var279[6] = var27;
         var279[5] = var225;
         var279[4] = var276;
         var279[3] = var25;
         var279[2] = var26;
         var279[1] = var272;
         var279[0] = var266;
         Object[] var134 = var279;
         TwoDESP var133 = this;
         var133.jReturningVoid(var134);
         int var220 = var18;
         if (var220 == 0) {
            break;
         }

         Iterator var230 = var30;
         boolean var242 = var230.hasNext();
         if (!var242) {
            break;
         }

         Iterator var233 = var30;
         Entry var223 = (Entry)var233.next();
         Entry var236 = var223;
         var160 = var236.getValue();
      }
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      Map var4 = this.A;
      var4.clear();
      Map var5 = this.z;
      var5.clear();
      short var10001 = 20037;
      long var10002 = 4266779403011168667L ^ var2;
      this.x = 0L;
   }

   private void jReturningVoid(Object[] var1) {
      MeshBufferManager var14 = (MeshBufferManager)var1[0];
      RenderContext var11 = (RenderContext)var1[1];
      Matrix4f var2 = (Matrix4f)var1[2];
      MsdfFont var10 = (MsdfFont)var1[3];
      EntityScreenBounds var8 = (EntityScreenBounds)var1[4];
      ScreenBoundsAnimation var12 = (ScreenBoundsAnimation)var1[5];
      Color var7 = (Color)var1[6];
      Color var9 = (Color)var1[7];
      float var13 = (Float)var1[8];
      long var3 = (Long)var1[9];
      long var5 = (Long)var1[10];
      var5 = 95832993219536L ^ var5;
      long var15 = var5 ^ 10594445946619L;
      long var17 = var5 ^ 93806601951521L;
      long var19 = var5 ^ 94320052125977L;
      long var21 = var5 ^ 67052248267020L;
      long var23 = var5 ^ 125972783309045L;
      long var25 = var5 ^ 356519620516L;
      long var27 = var5 ^ 28493205570533L;
      long var29 = var5 ^ 35621130370208L;
      long var31 = var5 ^ 70080902931643L;
      long var33 = var5 ^ 86795357518438L;
      long var35 = var5 ^ 81825695861278L;
      long var37 = var5 ^ 3573691985733L;
      int var10000 = Event.bReturningInt();
      float var10001 = var12.e;
      Object[] var10004 = new Object[]{null, var27};
      var10004[0] = var10001;
      Object[] var57 = var10004;
      float var40 = cReturningFloat(var57);
      int var39 = var10000;
      int var177 = var39;
      float var176 = var40;
      float var143 = var176;
      float var142 = var176;
      if (var177 == 0) {
         float var284;
         int var178 = (var284 = var142 - 0.02F) == 0.0F ? 0 : (var284 < 0.0F ? -1 : 1);
         if (var178 < 0) {
            return;
         }

         var143 = var12.a;
      }

      float var41;
      float var42;
      float var43;
      float var44;
      float var45;
      float var46;
      Color var146;
      label173: {
         var41 = var143;
         var42 = var12.b;
         var43 = var12.c;
         var44 = var12.d;
         var45 = var43 - var41;
         var46 = var44 - var42;
         int var180 = var39;
         EntityScreenBounds var179 = var8;
         Object var145 = var179;
         EntityScreenBounds var144 = var179;
         if (var180 == 0) {
            boolean var181 = var144.h;
            if (!var181) {
               var146 = var7;
               break label173;
            }

            ColorSetting var61 = this.t;
            Object var182 = var61.aReturningObject();
            var145 = var182;
         }

         Color var183 = (Color)var145;
         var146 = var183;
      }

      Color var47;
      boolean var48;
      Color var49;
      Color var149;
      label167: {
         label166: {
            var47 = var146;
            MultiModeSetting var245 = this.f;
            short var256 = 22728;
            long var10002 = 9126620729897755551L ^ var5;
            Object[] var64 = new Object[]{"Gradient", var29};
            MultiModeSetting var63 = var245;
            var48 = var63.aReturningBoolean(var64);
            var49 = var47;
            int var185 = var39;
            boolean var184 = var48;
            boolean var148 = var184;
            boolean var147 = var184;
            if (var185 == 0) {
               boolean var186 = var147;
               if (!var186) {
                  break label166;
               }

               boolean var187 = var8.h;
               var148 = var187;
            }

            boolean var188 = var148;
            if (!var188) {
               Color var189 = var9;
               var149 = var189;
               break label167;
            }
         }

         var149 = var47;
      }

      Color var50;
      label177: {
         var50 = var149;
         int var191 = var39;
         boolean var190 = var48;
         boolean var151 = var190;
         boolean var150 = var190;
         if (var191 == 0) {
            boolean var192 = var150;
            if (!var192) {
               break label177;
            }

            BooleanSetting var69 = this.i;
            Boolean var70 = (Boolean)var69.aReturningObject();
            boolean var193 = var70;
            var151 = var193;
         }

         int var195 = var39;
         boolean var194 = var151;
         boolean var153 = var194;
         boolean var152 = var194;
         if (var195 == 0) {
            boolean var196 = var152;
            if (!var196) {
               break label177;
            }

            boolean var197 = var8.h;
            var153 = var197;
         }

         boolean var198 = var153;
         if (!var198) {
            Object[] var10005 = new Object[]{null, null, null, var21};
            var10005[2] = var13;
            var10005[1] = var9;
            var10005[0] = var47;
            Object[] var74 = var10005;
            Color var51 = bReturningColor(var74);
            var10005 = new Object[]{null, null, null, var21};
            var10005[2] = var13;
            var10005[1] = var47;
            var10005[0] = var9;
            Object[] var75 = var10005;
            Color var52 = bReturningColor(var75);
            var49 = var51;
            var50 = var52;
         }
      }

      var10004 = new Object[]{null, null, var31};
      var10004[1] = var40;
      var10004[0] = var49;
      Object[] var76 = var10004;
      Color var242 = aReturningColor(var76);
      var10004 = new Object[]{null, null, var31};
      var10004[1] = var40;
      var10004[0] = var50;
      Object[] var77 = var10004;
      Color var243 = aReturningColor(var77);
      FloatSetting var78 = this.e;
      Float var79 = (Float)var78.aReturningObject();
      float var53 = var79;
      FloatSetting var80 = this.c;
      Float var81 = (Float)var80.aReturningObject();
      float var246 = var81;
      float var83 = var46;
      float var82 = var45;
      float var85 = Math.min(var82, var83) * 0.4F;
      float var84 = var246;
      float var54 = Math.min(var84, var85);
      float var285;
      var10000 = (var285 = var54 - 0.0F) == 0.0F ? 0 : (var285 < 0.0F ? -1 : 1);
      int var200 = var39;
      int var199 = var10000;
      int var155 = var199;
      int var154 = var199;
      if (var200 == 0) {
         int var201 = var154;
         if (var201 < 0) {
            var54 = 0.0F;
         }

         MultiModeSetting var248 = this.f;
         short var257 = 426;
         long var266 = 5418438827413109502L ^ var5;
         Object[] var88 = new Object[]{"Glow", var29};
         MultiModeSetting var87 = var248;
         var155 = (((var87.aReturningBoolean(var88)) ? 1 : 0));
      }

      Object var159;
      label178: {
         int var203 = var39;
         int var202 = var155;
         int var158 = var202;
         int var156 = var202;
         if (var203 == 0) {
            int var204 = var156;
            if (var204 != 0) {
               Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var17};
               var10011[7] = var54;
               var10011[6] = var40;
               var10011[5] = var47;
               var10011[4] = var44;
               var10011[3] = var43;
               var10011[2] = var42;
               var10011[1] = var41;
               var10011[0] = var2;
               Object[] var91 = var10011;
               TwoDESP var90 = this;
               var90.o(var91);
            }

            int var206 = var39;
            MultiModeSetting var205 = this.f;
            var159 = var205;
            MultiModeSetting var157 = var205;
            if (var206 != 0) {
               break label178;
            }

            short var258 = 5661;
            long var267 = 5069969552696569165L ^ var5;
            Object[] var94 = new Object[]{"Fill", var29};
            MultiModeSetting var93 = var157;
            byte var207 = ((byte)((var93.aReturningBoolean(var94)) ? 1 : 0));
            var158 = var207;
         }

         int var208 = var158;
         if (var208 != 0) {
            FloatSetting var96 = this.g;
            Float var97 = (Float)var96.aReturningObject();
            var10001 = var40 * var97;
            var10004 = new Object[]{null, null, var31};
            var10004[1] = var10001;
            var10004[0] = var47;
            Object[] var98 = var10004;
            Color var55 = aReturningColor(var98);
            Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var23};
            var10009[6] = var54;
            var10009[5] = var55;
            var10009[4] = var44;
            var10009[3] = var43;
            var10009[2] = var42;
            var10009[1] = var41;
            var10009[0] = var2;
            Object[] var99 = var10009;
            GameRenderUtil.nReturningVoid(var99);
         }

         ModeSetting var100 = this.a;
         var159 = var100.aReturningObject();
      }

      int var167;
      String var244 = (String)var159;
      // String var101 = var244;
      var10000 = var101.hashCode();
      int var210 = var39;
      int var209 = var10000;
      var167 = var209;
      int var160 = var209;
      label139:
      if (var210 == 0) {
         int var211 = var160;
         switch (var211) {
            case 66987:
               short var260 = 7345;
               long var268 = 7955968014137944047L ^ var5;
               String var104 = "Box";
               String var103 = var244;
               byte var250 = ((byte)((var103.equals(var104)) ? 1 : 0));
               int var213 = var39;
               byte var212 = var250;
               var167 = var212;
               byte var161 = var212;
               if (var213 != 0) {
                  break label139;
               }

               byte var214 = var161;
               byte var162 = var214;
               byte var215 = var162;
               if (var215 == 0) {
                  break;
               }

               var56 = 0;
               int var216 = var39;
               if (var216 == 0) {
                  break;
               }
            case -1675267938:
               short var261 = 29232;
               long var269 = 2236664286036756842L ^ var5;
               String var108 = "Corners";
               String var107 = var244;
               byte var251 = ((byte)((var107.equals(var108)) ? 1 : 0));
               int var218 = var39;
               byte var217 = var251;
               var167 = var217;
               byte var163 = var217;
               if (var218 != 0) {
                  break label139;
               }

               byte var219 = var163;
               byte var164 = var219;
               byte var220 = var164;
               if (var220 == 0) {
                  break;
               }

               var56 = 1;
               int var221 = var39;
               if (var221 == 0) {
                  break;
               }
            case 29314283:
               short var262 = 27097;
               long var270 = 7329238504877462149L ^ var5;
               String var112 = "Brackets";
               String var111 = var244;
               byte var252 = ((byte)((var111.equals(var112)) ? 1 : 0));
               int var223 = var39;
               byte var222 = var252;
               var167 = var222;
               byte var165 = var222;
               if (var223 != 0) {
                  break label139;
               }

               byte var224 = var165;
               byte var166 = var224;
               byte var225 = var166;
               if (var225 != 0) {
                  var56 = 2;
               }
         }

         var167 = var56;
      }

      int var227 = var39;
      int var226 = var167;
      int var169 = var226;
      int var168 = var226;
      if (var227 == 0) {
         int var228 = var168;
         switch (var228) {
            case 0:
               Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, var33};
               var10012[8] = var54;
               var10012[7] = var53;
               var10012[6] = var243;
               var10012[5] = var242;
               var10012[4] = var44;
               var10012[3] = var43;
               var10012[2] = var42;
               var10012[1] = var41;
               var10012[0] = var2;
               Object[] var117 = var10012;
               TwoDESP var116 = this;
               var116.kReturningVoid(var117);
               int var229 = var39;
               if (var229 == 0) {
                  break;
               }
            case 1:
               Object[] var280 = new Object[]{null, null, null, null, null, null, null, null, var25};
               var280[7] = var53;
               var280[6] = var243;
               var280[5] = var242;
               var280[4] = var44;
               var280[3] = var43;
               var280[2] = var42;
               var280[1] = var41;
               var280[0] = var2;
               Object[] var120 = var280;
               TwoDESP var119 = this;
               var119.lReturningVoid(var120);
               int var230 = var39;
               if (var230 == 0) {
                  break;
               }
            case 2:
               Object[] var281 = new Object[]{null, null, null, null, null, null, null, null, var35};
               var281[7] = var53;
               var281[6] = var243;
               var281[5] = var242;
               var281[4] = var44;
               var281[3] = var43;
               var281[2] = var42;
               var281[1] = var41;
               var281[0] = var2;
               Object[] var123 = var281;
               TwoDESP var122 = this;
               var122.mReturningVoid(var123);
         }

         MultiModeSetting var253 = this.f;
         short var263 = 29854;
         long var271 = 1546046407557517259L ^ var5;
         Object[] var126 = new Object[]{"Health Bar", var29};
         MultiModeSetting var125 = var253;
         var169 = (((var125.aReturningBoolean(var126)) ? 1 : 0));
      }

      int var232 = var39;
      int var231 = var169;
      int var171 = var231;
      int var170 = var231;
      if (var232 == 0) {
         int var233 = var170;
         if (var233 != 0) {
            float var10007 = var8.c;
            float var10008 = var8.d;
            Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, var15};
            var10013[9] = var3;
            var10013[8] = var40;
            var10013[7] = var10008;
            var10013[6] = var10007;
            var10013[5] = var44;
            var10013[4] = var43;
            var10013[3] = var42;
            var10013[2] = var41;
            var10013[1] = var10;
            var10013[0] = var2;
            Object[] var129 = var10013;
            TwoDESP var128 = this;
            var128.q(var129);
         }

         MultiModeSetting var254 = this.f;
         short var264 = 30995;
         long var272 = 5404049771736072791L ^ var5;
         Object[] var132 = new Object[]{"Name Tag", var29};
         MultiModeSetting var131 = var254;
         var171 = (((var131.aReturningBoolean(var132)) ? 1 : 0));
      }

      TwoDESP var175;
      label182: {
         int var235 = var39;
         int var234 = var171;
         int var174 = var234;
         int var172 = var234;
         if (var235 == 0) {
            int var236 = var172;
            if (var236 != 0) {
               String var278 = var8.b;
               Object[] var282 = new Object[]{null, null, null, null, null, null, null, null, null, var19};
               var282[8] = var40;
               var282[7] = var278;
               var282[6] = var43;
               var282[5] = var42;
               var282[4] = var41;
               var282[3] = var10;
               var282[2] = var2;
               var282[1] = var11;
               var282[0] = var14;
               Object[] var135 = var282;
               TwoDESP var134 = this;
               var134.r(var135);
            }

            int var238 = var39;
            TwoDESP var237 = this;
            var175 = var237;
            TwoDESP var173 = var237;
            if (var238 != 0) {
               break label182;
            }

            MultiModeSetting var255 = var173.f;
            short var265 = 16649;
            long var273 = 642502289094392404L ^ var5;
            Object[] var138 = new Object[]{"Distance", var29};
            MultiModeSetting var137 = var255;
            byte var239 = ((byte)((var137.aReturningBoolean(var138)) ? 1 : 0));
            var174 = var239;
         }

         int var240 = var174;
         if (var240 == 0) {
            return;
         }

         var175 = this;
      }

      float var279 = var8.g;
      Object[] var283 = new Object[]{null, null, null, null, null, null, null, null, null, var37};
      var283[8] = var40;
      var283[7] = var279;
      var283[6] = var43;
      var283[5] = var44;
      var283[4] = var41;
      var283[3] = var10;
      var283[2] = var2;
      var283[1] = var11;
      var283[0] = var14;
      Object[] var141 = var283;
      TwoDESP var140 = var175;
      var140.s(var141);
   }

   private void kReturningVoid(Object[] var1) {
      Matrix4f var5 = (Matrix4f)var1[0];
      float var3 = (Float)var1[1];
      float var12 = (Float)var1[2];
      float var6 = (Float)var1[3];
      float var10 = (Float)var1[4];
      Color var4 = (Color)var1[5];
      Color var11 = (Color)var1[6];
      float var7 = (Float)var1[7];
      float var2 = (Float)var1[8];
      long var8 = (Long)var1[9];
      var8 = 95832993219536L ^ var8;
      long var13 = var8 ^ 93799497838587L;
      long var15 = var8 ^ 38685086476627L;
      Object[] var19 = new Object[]{var4, var11, var13};
      Color var17 = cReturningColor(var19);
      Color var20 = var17;
      float var21 = 80.0F * (var20.getAlpha() / 255.0F);
      Color var18 = new Color(0, 0, 0, Math.round(var21));
      float var10001 = var3 - 0.5F;
      float var10002 = var12 - 0.5F;
      float var10003 = var6 + 0.5F;
      float var10004 = var10 + 0.5F;
      float var10006 = var2 + 0.5F;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, null, var15};
      var10010[7] = 1.0F;
      var10010[6] = var10006;
      var10010[5] = var18;
      var10010[4] = var10004;
      var10010[3] = var10003;
      var10010[2] = var10002;
      var10010[1] = var10001;
      var10010[0] = var5;
      Object[] var22 = var10010;
      p(var22);
      var10010 = new Object[]{null, null, null, null, null, null, null, null, var15};
      var10010[7] = var7;
      var10010[6] = var2;
      var10010[5] = var17;
      var10010[4] = var10;
      var10010[3] = var6;
      var10010[2] = var12;
      var10010[1] = var3;
      var10010[0] = var5;
      Object[] var23 = var10010;
      p(var23);
   }

   private void lReturningVoid(Object[] var1) {
      Matrix4f var7 = (Matrix4f)var1[0];
      float var4 = (Float)var1[1];
      float var9 = (Float)var1[2];
      float var2 = (Float)var1[3];
      float var8 = (Float)var1[4];
      Color var10 = (Color)var1[5];
      Color var3 = (Color)var1[6];
      float var11 = (Float)var1[7];
      long var5 = (Long)var1[8];
      var5 = 95832993219536L ^ var5;
      long var12 = var5 ^ 63335812415956L;
      long var14 = var5 ^ 122886361942091L;
      float var16 = var2 - var4;
      float var17 = var8 - var9;
      float var22 = var17;
      float var21 = var16;
      float var10000 = Math.min(var21, var22) * 0.28F;
      Object[] var10005 = new Object[]{null, null, null, var14};
      var10005[2] = 22.0F;
      var10005[1] = 4.0F;
      var10005[0] = var10000;
      Object[] var23 = var10005;
      float var18 = dReturningFloat(var23);
      float var19 = var11 * 0.5F;
      Color var24 = var10;
      float var25 = 120.0F * (var24.getAlpha() / 255.0F);
      Color var20 = new Color(0, 0, 0, Math.round(var25));
      float var10002 = var4 - var19;
      float var10003 = var9 - var19;
      float var10004 = var4 + var18;
      float var64 = var9 + var19;
      Object[] var10010 = new Object[]{null, null, null, null, null, var10, var20, var12};
      var10010[4] = var64;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var27 = var10010;
      TwoDESP var26 = this;
      var26.nReturningVoid(var27);
      var10002 = var4 - var19;
      var10003 = var9 - var19;
      var10004 = var4 + var19;
      float var65 = var9 + var18;
      var10010 = new Object[]{null, null, null, null, null, var10, var20, var12};
      var10010[4] = var65;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var29 = var10010;
      TwoDESP var28 = this;
      var28.nReturningVoid(var29);
      var10002 = var2 - var18;
      var10003 = var9 - var19;
      var10004 = var2 + var19;
      float var66 = var9 + var19;
      var10010 = new Object[]{null, null, null, null, null, var10, var20, var12};
      var10010[4] = var66;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var31 = var10010;
      TwoDESP var30 = this;
      var30.nReturningVoid(var31);
      var10002 = var2 - var19;
      var10003 = var9 - var19;
      var10004 = var2 + var19;
      float var67 = var9 + var18;
      var10010 = new Object[]{null, null, null, null, null, var10, var20, var12};
      var10010[4] = var67;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var33 = var10010;
      TwoDESP var32 = this;
      var32.nReturningVoid(var33);
      var10002 = var4 - var19;
      var10003 = var8 - var19;
      var10004 = var4 + var18;
      float var68 = var8 + var19;
      var10010 = new Object[]{null, null, null, null, null, var3, var20, var12};
      var10010[4] = var68;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var35 = var10010;
      TwoDESP var34 = this;
      var34.nReturningVoid(var35);
      var10002 = var4 - var19;
      var10003 = var8 - var18;
      var10004 = var4 + var19;
      float var69 = var8 + var19;
      var10010 = new Object[]{null, null, null, null, null, var3, var20, var12};
      var10010[4] = var69;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var37 = var10010;
      TwoDESP var36 = this;
      var36.nReturningVoid(var37);
      var10002 = var2 - var18;
      var10003 = var8 - var19;
      var10004 = var2 + var19;
      float var70 = var8 + var19;
      var10010 = new Object[]{null, null, null, null, null, var3, var20, var12};
      var10010[4] = var70;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var39 = var10010;
      TwoDESP var38 = this;
      var38.nReturningVoid(var39);
      var10002 = var2 - var19;
      var10003 = var8 - var18;
      var10004 = var2 + var19;
      float var71 = var8 + var19;
      var10010 = new Object[]{null, null, null, null, null, var3, var20, var12};
      var10010[4] = var71;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var7;
      Object[] var41 = var10010;
      TwoDESP var40 = this;
      var40.nReturningVoid(var41);
   }

   private void mReturningVoid(Object[] var1) {
      Matrix4f var4 = (Matrix4f)var1[0];
      float var2 = (Float)var1[1];
      float var9 = (Float)var1[2];
      float var10 = (Float)var1[3];
      float var6 = (Float)var1[4];
      Color var11 = (Color)var1[5];
      Color var3 = (Color)var1[6];
      float var5 = (Float)var1[7];
      long var7 = (Long)var1[8];
      var7 = 95832993219536L ^ var7;
      long var12 = var7 ^ 127139641386094L;
      long var14 = var7 ^ 89973059837827L;
      long var16 = var7 ^ 41760776728049L;
      float var18 = var6 - var9;
      float var10000 = var18 * 0.35F;
      Object[] var10005 = new Object[]{null, null, null, var16};
      var10005[2] = 26.0F;
      var10005[1] = 5.0F;
      var10005[0] = var10000;
      Object[] var23 = var10005;
      float var19 = dReturningFloat(var23);
      float var20 = var5 * 0.5F;
      float var21 = (var9 + var6) * 0.5F;
      Color var24 = var11;
      float var25 = 120.0F * (var24.getAlpha() / 255.0F);
      Color var22 = new Color(0, 0, 0, Math.round(var25));
      float var10002 = var2 - var20;
      float var10003 = var9 - var20;
      float var10004 = var2 + var20;
      float var56 = var9 + var19;
      Object[] var10010 = new Object[]{null, null, null, null, null, var11, var22, var12};
      var10010[4] = var56;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var27 = var10010;
      TwoDESP var26 = this;
      var26.nReturningVoid(var27);
      var10002 = var2 - var20;
      var10003 = var21 - var19 * 0.4F;
      var10004 = var2 + var20;
      float var57 = var21 + var19 * 0.4F;
      Object[] var28 = new Object[]{var11, var3, var14};
      var10010 = new Object[]{null, null, null, null, null, cReturningColor(var28), var22, var12};
      var10010[4] = var57;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var30 = var10010;
      TwoDESP var29 = this;
      var29.nReturningVoid(var30);
      var10002 = var2 - var20;
      var10003 = var6 - var19;
      var10004 = var2 + var20;
      float var58 = var6 + var20;
      var10010 = new Object[]{null, null, null, null, null, var3, var22, var12};
      var10010[4] = var58;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var32 = var10010;
      TwoDESP var31 = this;
      var31.nReturningVoid(var32);
      var10002 = var10 - var20;
      var10003 = var9 - var20;
      var10004 = var10 + var20;
      float var59 = var9 + var19;
      var10010 = new Object[]{null, null, null, null, null, var11, var22, var12};
      var10010[4] = var59;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var34 = var10010;
      TwoDESP var33 = this;
      var33.nReturningVoid(var34);
      var10002 = var10 - var20;
      var10003 = var21 - var19 * 0.4F;
      var10004 = var10 + var20;
      float var60 = var21 + var19 * 0.4F;
      Object[] var35 = new Object[]{var11, var3, var14};
      var10010 = new Object[]{null, null, null, null, null, cReturningColor(var35), var22, var12};
      var10010[4] = var60;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var37 = var10010;
      TwoDESP var36 = this;
      var36.nReturningVoid(var37);
      var10002 = var10 - var20;
      var10003 = var6 - var19;
      var10004 = var10 + var20;
      float var61 = var6 + var20;
      var10010 = new Object[]{null, null, null, null, null, var3, var22, var12};
      var10010[4] = var61;
      var10010[3] = var10004;
      var10010[2] = var10003;
      var10010[1] = var10002;
      var10010[0] = var4;
      Object[] var39 = var10010;
      TwoDESP var38 = this;
      var38.nReturningVoid(var39);
   }

   private void nReturningVoid(Object[] var1) {
      Matrix4f var8 = (Matrix4f)var1[0];
      float var6 = (Float)var1[1];
      float var10 = (Float)var1[2];
      float var5 = (Float)var1[3];
      float var7 = (Float)var1[4];
      Color var2 = (Color)var1[5];
      Color var9 = (Color)var1[6];
      long var3 = (Long)var1[7];
      var3 = 95832993219536L ^ var3;
      long var11 = var3 ^ 16063375514159L;
      float var10001 = var6 - 0.5F;
      float var10002 = var10 - 0.5F;
      float var10003 = var5 + 0.5F;
      float var10004 = var7 + 0.5F;
      Object[] var10008 = new Object[]{null, null, null, null, null, var9, var11};
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var10002;
      var10008[1] = var10001;
      var10008[0] = var8;
      Object[] var13 = var10008;
      GameRenderUtil.r(var13);
      var10008 = new Object[]{null, null, null, null, null, var2, var11};
      var10008[4] = var7;
      var10008[3] = var5;
      var10008[2] = var10;
      var10008[1] = var6;
      var10008[0] = var8;
      Object[] var14 = var10008;
      GameRenderUtil.r(var14);
   }

   private void o(Object[] var1) {
      Matrix4f var2 = (Matrix4f)var1[0];
      float var3 = (Float)var1[1];
      float var4 = (Float)var1[2];
      float var8 = (Float)var1[3];
      float var7 = (Float)var1[4];
      Color var6 = (Color)var1[5];
      float var5 = (Float)var1[6];
      float var11 = (Float)var1[7];
      long var9 = (Long)var1[8];
      var9 = 95832993219536L ^ var9;
      long var12 = var9 ^ 124156862216708L;
      long var14 = var9 ^ 108978254980161L;
      float var17 = 4.0F;
      int var10000 = Event.bReturningInt();
      FloatSetting var24 = this.h;
      Float var25 = (Float)var24.aReturningObject();
      float var18 = var25;
      int var16 = var10000;
      int var19 = 1;

      int var32;
      do {
         float var37;
         int var31 = (var37 = var19 - var17) == 0.0F ? 0 : (var37 < 0.0F ? -1 : 1);
         if (var31 > 0) {
            break;
         }

         float var20 = var19 / var17;
         float var21 = var18 * var20;
         float var22 = var5 * 0.14F * (1.0F - var20);
         Color var26 = var6;
         int var10002 = var26.getRed();
         Color var27 = var6;
         int var10003 = var27.getGreen();
         Color var28 = var6;
         int var10004 = var28.getBlue();
         Object[] var10008 = new Object[]{null, var14};
         var10008[0] = var22;
         Object[] var29 = var10008;
         Color var23 = new Color(var10002, var10003, var10004, aReturningInt(var29));
         float var10001 = var3 - var21;
         float var34 = var4 - var21;
         float var35 = var8 + var21;
         float var36 = var7 + var21;
         float var10006 = var11 + var21;
         Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var12};
         var10009[6] = var10006;
         var10009[5] = var23;
         var10009[4] = var36;
         var10009[3] = var35;
         var10009[2] = var34;
         var10009[1] = var10001;
         var10009[0] = var2;
         Object[] var30 = var10009;
         GameRenderUtil.nReturningVoid(var30);
         var19++;
         var32 = var16;
      } while (var32 == 0);
   }

   private static void p(Object[] var0) {
      Matrix4f var7 = (Matrix4f)var0[0];
      float var5 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var4 = (Float)var0[3];
      float var1 = (Float)var0[4];
      Color var2 = (Color)var0[5];
      float var6 = (Float)var0[6];
      float var10 = (Float)var0[7];
      long var8 = (Long)var0[8];
      var8 = 95832993219536L ^ var8;
      long var11 = var8 ^ 51589752696144L;
      MeshBufferManager var10000 = GameRenderUtil.g;
      RenderContext var10001 = GameRenderUtil.h;
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, null, var11};
      var10012[9] = var10;
      var10012[8] = var6;
      var10012[7] = var2;
      var10012[6] = var1;
      var10012[5] = var4;
      var10012[4] = var3;
      var10012[3] = var5;
      var10012[2] = var7;
      var10012[1] = var10001;
      var10012[0] = var10000;
      Object[] var13 = var10012;
      ShapeRenderer.C(var13);
   }

   private void q(Object[] var1) {
      float var2;
      float var3;
      long var4;
      float var8;
      float var9;
      float var10;
      MsdfFont var11;
      Matrix4f var13;
      float var14;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var27;
      long var31;
      long var33;
      int var35;
      float var36;
      Color var39;
      Color var40;
      Color var41;
      String var42;
      float var43;
      float var44;
      float var45;
      boolean var137;
      long var205;
      label142: {
         boolean var136;
         var13 = (Matrix4f)var1[0];
         var11 = (MsdfFont)var1[1];
         var14 = (Float)var1[2];
         var8 = (Float)var1[3];
         var2 = (Float)var1[4];
         var3 = (Float)var1[5];
         var10 = (Float)var1[6];
         float var12 = (Float)var1[7];
         var9 = (Float)var1[8];
         var4 = (Long)var1[9];
         long var6 = (Long)var1[10];
         var205 = 95832993219536L ^ var6;
         var15 = var205 ^ 113813884306427L;
         var17 = var205 ^ 52990886544064L;
         var19 = var205 ^ 116410269423988L;
         var21 = var205 ^ 93384837626328L;
         var23 = var205 ^ 134679972022364L;
         long var25 = var205 ^ 108240639317031L;
         var27 = var205 ^ 48482642234846L;
         long var29 = var205 ^ 78479702798030L;
         var31 = var205 ^ 106887088966032L;
         var33 = var205 ^ 70294675723163L;
         int var10000 = Event.cReturningInt();
         float var10001 = var10 / var12;
         Object[] var10004 = new Object[]{null, var29};
         var10004[0] = var10001;
         Object[] var59 = var10004;
         var36 = cReturningFloat(var59);
         ColorSetting var60 = this.u;
         Color var37 = (Color)var60.aReturningObject();
         ColorSetting var61 = this.v;
         Color var38 = (Color)var61.aReturningObject();
         Object[] var10006 = new Object[]{null, null, null, var25};
         var10006[2] = var36;
         var10006[1] = var37;
         var10006[0] = var38;
         Object[] var62 = var10006;
         var39 = bReturningColor(var62);
         var40 = var38;
         var35 = var10000;
         float var10005 = var9 * 0.63F;
         Object[] var10008 = new Object[]{null, var33};
         var10008[0] = var10005;
         Object[] var63 = var10008;
         var41 = new Color(0, 0, 0, aReturningInt(var63));
         ModeSetting var64 = this.k;
         var42 = (String)var64.aReturningObject();
         var43 = 2.6F;
         var44 = 3.0F;
         var45 = 1.6F;
         short var224 = 8863;
         long var10002 = 3484003270434780403L ^ var205;
         String var66 = "Left";
         String var65 = var42;
         boolean var218 = var65.equals(var66);
         int var157 = var35;
         boolean var156 = var218;
         var136 = var156;
         boolean var133 = var156;
         label141:
         if (var157 != 0) {
            boolean var158 = var133;
            if (!var158) {
               short var225 = 27716;
               var10002 = 508880822052764220L ^ var205;
               String var69 = "Right";
               String var68 = var42;
               var218 = var68.equals(var69);
               int var160 = var35;
               boolean var159 = var218;
               var136 = var159;
               boolean var134 = var159;
               if (var160 == 0) {
                  break label141;
               }

               boolean var161 = var134;
               boolean var135 = var161;
               boolean var162 = var135;
               if (!var162) {
                  var137 = false;
                  break label142;
               }
            }

            var136 = true;
         }

         boolean var163 = var136;
         var137 = var163;
      }

      float var46;
      float var47;
      float var48;
      float var49;
      boolean var50;
      label145: {
         var50 = var137;
         int var165 = var35;
         boolean var164 = var50;
         boolean var139 = var164;
         boolean var138 = var164;
         if (var165 != 0) {
            boolean var166 = var138;
            if (var166) {
               label127: {
                  short var226 = 7682;
                  long var235 = 2716741116566685810L ^ var205;
                  String var74 = "Left";
                  String var73 = var42;
                  boolean var167 = var73.equals(var74);
                  if (var167) {
                     var48 = var14 - var44;
                     var46 = var48 - var43;
                     int var168 = var35;
                     if (var168 != 0) {
                        break label127;
                     }
                  }

                  var46 = var2 + var44;
                  var48 = var46 + var43;
               }

               var47 = var8;
               var49 = var3;
               int var169 = var35;
               if (var169 != 0) {
                  break label145;
               }
            }

            short var227 = 1864;
            long var236 = 3792873415259476282L ^ var205;
            String var77 = "Top";
            String var76 = var42;
            boolean var170 = var76.equals(var77);
            var139 = var170;
         }

         label118: {
            boolean var171 = var139;
            if (var171) {
               var49 = var8 - var44;
               var47 = var49 - var43;
               int var172 = var35;
               if (var172 != 0) {
                  break label118;
               }
            }

            var47 = var3 + var44;
            var49 = var47 + var43;
         }

         var46 = var14;
         var48 = var2;
      }

      int var152;
      label113: {
         label147: {
            float var228 = var46 - 0.6F;
            float var237 = var47 - 0.6F;
            float var10003 = var48 + 0.6F;
            float var254 = var49 + 0.6F;
            Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var27};
            var10009[6] = var45;
            var10009[5] = var41;
            var10009[4] = var254;
            var10009[3] = var10003;
            var10009[2] = var237;
            var10009[1] = var228;
            var10009[0] = var13;
            Object[] var79 = var10009;
            GameRenderUtil.nReturningVoid(var79);
            boolean var173 = var50;
            if (var173) {
               float var51 = (var49 - var47) * var36;
               float var52 = var49 - var51;
               float var291;
               int var220 = (var291 = var51 - 1.0F) == 0.0F ? 0 : (var291 < 0.0F ? -1 : 1);
               int var175 = var35;
               int var174 = var220;
               int var141 = var174;
               int var140 = var174;
               if (var175 != 0) {
                  int var176 = var140;
                  if (var176 > 0) {
                     var10009 = new Object[]{null, null, var31};
                     var10009[1] = var9;
                     var10009[0] = var40;
                     Object[] var81 = var10009;
                     Color var264 = aReturningColor(var81);
                     Object[] var10010 = new Object[]{null, null, var31};
                     var10010[1] = var9;
                     var10010[0] = var40;
                     Object[] var82 = var10010;
                     Color var274 = aReturningColor(var82);
                     Object[] var10011 = new Object[]{null, null, var31};
                     var10011[1] = var9;
                     var10011[0] = var39;
                     Object[] var83 = var10011;
                     Color var10007 = aReturningColor(var83);
                     Object[] var10012 = new Object[]{null, null, var31};
                     var10012[1] = var9;
                     var10012[0] = var39;
                     Object[] var84 = var10012;
                     var10012 = new Object[]{null, null, null, null, null, var264, var274, var10007, aReturningColor(var84), new Vector4f(var45), var15};
                     var10012[4] = var49;
                     var10012[3] = var48;
                     var10012[2] = var52;
                     var10012[1] = var46;
                     var10012[0] = var13;
                     Object[] var85 = var10012;
                     ShapeRenderer.w(var85);
                  }

                  BooleanSetting var87 = this.m;
                  Boolean var88 = (Boolean)var87.aReturningObject();
                  var141 = ((((java.lang.Boolean)(var88)).booleanValue() ? 1 : 0));
               }

               label108: {
                  float var146;
                  label149: {
                     int var178 = var35;
                     int var177 = var141;
                     int var145 = var177;
                     int var142 = var177;
                     if (var178 != 0) {
                        int var179 = var142;
                        if (var179 == 0) {
                           break label108;
                        }

                        int var181 = var35;
                        float var180 = var51;
                        var146 = var180;
                        float var143 = var180;
                        if (var181 == 0) {
                           break label149;
                        }

                        float var182 = var143;
                        float var144 = var182;
                        float var292;
                        int var183 = (var292 = var144 - 4.0F) == 0.0F ? 0 : (var292 < 0.0F ? -1 : 1);
                        var145 = var183;
                     }

                     int var184 = var145;
                     if (var184 <= 0) {
                        break label108;
                     }

                     short var229 = 22631;
                     long var238 = 4396440409153461565L ^ var205;
                     float var185 = (float)(var4 % 1600L / 1600.0);
                     var146 = var185;
                  }

                  float var53 = var146;
                  float var54 = var52 + (var49 - var52) * var53;
                  float var94 = var51 * 0.35F;
                  float var93 = 8.0F;
                  float var55 = Math.min(var93, var94);
                  short var239 = 8174;
                  long var246 = 4784840005737286338L ^ var205;
                  short var247 = 8174;
                  long var255 = 4784840005737286338L ^ var205;
                  short var256 = 8174;
                  long var265 = 4784840005737286338L ^ var205;
                  float var266 = var9 * 0.28F;
                  float var95 = var53 - 0.5F;
                  float var267 = var266 * (1.0F - Math.abs(var95) * 2.0F);
                  Object[] var277 = new Object[]{null, var33};
                  var277[0] = var267;
                  Object[] var96 = var277;
                  Color var56 = new Color(255, 255, 255, aReturningInt(var96));
                  var237 = var54 - var55 * 0.5F;
                  var254 = var54 + var55 * 0.5F;
                  var277 = new Object[]{null, null, null, null, null, var56, var19};
                  var277[4] = var254;
                  var277[3] = var48;
                  var277[2] = var237;
                  var277[1] = var46;
                  var277[0] = var13;
                  Object[] var97 = var277;
                  GameRenderUtil.r(var97);
               }

               int var186 = var35;
               if (var186 != 0) {
                  break label147;
               }
            }

            float var206 = (var48 - var46) * var36;
            float var208 = var46 + var206;
            float var293;
            int var221 = (var293 = var206 - 1.0F) == 0.0F ? 0 : (var293 < 0.0F ? -1 : 1);
            int var188 = var35;
            int var187 = var221;
            int var148 = var187;
            int var147 = var187;
            if (var188 != 0) {
               int var189 = var147;
               if (var189 > 0) {
                  var10009 = new Object[]{null, null, var31};
                  var10009[1] = var9;
                  var10009[0] = var40;
                  Object[] var99 = var10009;
                  Color var268 = aReturningColor(var99);
                  Object[] var286 = new Object[]{null, null, var31};
                  var286[1] = var9;
                  var286[0] = var39;
                  Object[] var100 = var286;
                  Color var275 = aReturningColor(var100);
                  Object[] var287 = new Object[]{null, null, var31};
                  var287[1] = var9;
                  var287[0] = var39;
                  Object[] var101 = var287;
                  Color var276 = aReturningColor(var101);
                  Object[] var289 = new Object[]{null, null, var31};
                  var289[1] = var9;
                  var289[0] = var40;
                  Object[] var102 = var289;
                  var289 = new Object[]{null, null, null, null, null, var268, var275, var276, aReturningColor(var102), new Vector4f(var45), var15};
                  var289[4] = var49;
                  var289[3] = var208;
                  var289[2] = var47;
                  var289[1] = var46;
                  var289[0] = var13;
                  Object[] var103 = var289;
                  ShapeRenderer.w(var103);
               }

               BooleanSetting var105 = this.m;
               Boolean var106 = (Boolean)var105.aReturningObject();
               var148 = ((((java.lang.Boolean)(var106)).booleanValue() ? 1 : 0));
            }

            int var191 = var35;
            int var190 = var148;
            var152 = var190;
            int var149 = var190;
            if (var191 == 0) {
               break label113;
            }

            int var192 = var149;
            if (var192 != 0) {
               float var294;
               var221 = (var294 = var206 - 4.0F) == 0.0F ? 0 : (var294 < 0.0F ? -1 : 1);
               int var194 = var35;
               int var193 = var221;
               var152 = var193;
               int var150 = var193;
               if (var194 == 0) {
                  break label113;
               }

               int var195 = var150;
               int var151 = var195;
               int var196 = var151;
               if (var196 > 0) {
                  short var230 = 15311;
                  long var241 = 4516574659122806417L ^ var205;
                  float var210 = (float)(var4 % 1600L / 1600.0);
                  float var212 = var46 + var206 * var210;
                  float var111 = var206 * 0.35F;
                  float var110 = 8.0F;
                  float var214 = Math.min(var110, var111);
                  short var242 = 8174;
                  long var248 = 4784840005737286338L ^ var205;
                  short var249 = 8174;
                  long var258 = 4784840005737286338L ^ var205;
                  short var259 = 8174;
                  long var269 = 4784840005737286338L ^ var205;
                  float var270 = var9 * 0.28F;
                  float var112 = var210 - 0.5F;
                  float var271 = var270 * (1.0F - Math.abs(var112) * 2.0F);
                  Object[] var279 = new Object[]{null, var33};
                  var279[0] = var271;
                  Object[] var113 = var279;
                  Color var216 = new Color(255, 255, 255, aReturningInt(var113));
                  var228 = var212 - var214 * 0.5F;
                  var10003 = var212 + var214 * 0.5F;
                  var279 = new Object[]{null, null, null, null, null, var216, var19};
                  var279[4] = var49;
                  var279[3] = var10003;
                  var279[2] = var47;
                  var279[1] = var228;
                  var279[0] = var13;
                  Object[] var114 = var279;
                  GameRenderUtil.r(var114);
               }
            }
         }

         BooleanSetting var115 = this.l;
         Boolean var116 = (Boolean)var115.aReturningObject();
         var152 = ((((java.lang.Boolean)(var116)).booleanValue() ? 1 : 0));
      }

      int var198 = var35;
      int var197 = var152;
      int var154 = var197;
      int var153 = var197;
      if (var198 != 0) {
         int var199 = var153;
         if (var199 == 0) {
            return;
         }

         float var118 = var10;
         int var200 = Math.round(var118);
         var154 = var200;
      }

      float var57;
      String var207;
      Color var209;
      float var211;
      float var213;
      float var215;
      float var217;
      label152: {
         int var120 = var154;
         var207 = String.valueOf(var120);
         float var272 = var9 * 0.55F;
         Object[] var281 = new Object[]{null, var33};
         var281[0] = var272;
         Object[] var121 = var281;
         var209 = new Color(0, 0, 0, aReturningInt(var121));
         var211 = 0.5F;
         Object[] var123 = new Object[]{var207, var21};
         MsdfFont var122 = var11;
         var213 = var122.aReturningFloat(var123) * var211;
         Object[] var125 = new Object[]{var17};
         MsdfFont var124 = var11;
         var215 = var124.cReturningFloat(var125) * var211;
         boolean var201 = var50;
         if (var201) {
            var217 = (var46 + var48) * 0.5F - var213 * 0.5F;
            var57 = var49 + 2.0F;
            int var202 = var35;
            if (var202 != 0) {
               break label152;
            }
         }

         var217 = (var46 + var48) * 0.5F - var213 * 0.5F;
         short var232 = 30977;
         long var243 = 1234894017729310584L ^ var205;
         String var127 = "Top";
         String var126 = var42;
         boolean var203 = var126.equals(var127);
         float var155;
         if (var203) {
            float var204 = var47 - var215 - 2.0F;
            var155 = var204;
         } else {
            var155 = var49 + 2.0F;
         }

         var57 = var155;
      }

      float var233 = var217 - 2.0F;
      float var244 = var57 - 1.0F;
      float var251 = var217 + var213 + 2.0F;
      float var260 = var57 + var215 + 1.0F;
      Object[] var284 = new Object[]{null, null, null, null, null, null, null, var27};
      var284[6] = 1.5F;
      var284[5] = var209;
      var284[4] = var260;
      var284[3] = var251;
      var284[2] = var244;
      var284[1] = var233;
      var284[0] = var13;
      Object[] var129 = var284;
      GameRenderUtil.nReturningVoid(var129);
      short var245 = 5781;
      long var252 = 2633829393318937530L ^ var205;
      short var253 = 8561;
      long var261 = 5812760739235542097L ^ var205;
      short var262 = 17385;
      long var273 = 3998746348741252811L ^ var205;
      Color var223 = new Color(240, 240, 245);
      Object[] var263 = new Object[]{null, null, var31};
      var263[1] = var9;
      var263[0] = var223;
      Object[] var130 = var263;
      Color var58 = aReturningColor(var130);
      var284 = new Object[]{null, null, null, null, null, var58, var23};
      var284[4] = var211;
      var284[3] = var57;
      var284[2] = var217;
      var284[1] = var207;
      var284[0] = var13;
      Object[] var132 = var284;
      MsdfFont var131 = var11;
      var131.w(var132);
   }

   private void r(Object[] var1) {
      MeshBufferManager var4 = (MeshBufferManager)var1[0];
      RenderContext var2 = (RenderContext)var1[1];
      Matrix4f var3 = (Matrix4f)var1[2];
      MsdfFont var8 = (MsdfFont)var1[3];
      float var7 = (Float)var1[4];
      float var10 = (Float)var1[5];
      float var12 = (Float)var1[6];
      String var9 = (String)var1[7];
      float var11 = (Float)var1[8];
      long var5 = (Long)var1[9];
      var5 = 95832993219536L ^ var5;
      long var13 = var5 ^ 119141484997922L;
      long var15 = var5 ^ 9367140095546L;
      long var17 = var5 ^ 27579022409804L;
      long var19 = var5 ^ 117951082451588L;
      long var21 = var5 ^ 67468465022578L;
      Object[] var35 = new Object[]{var9, var15};
      MsdfFont var34 = var8;
      float var23 = var34.aReturningFloat(var35);
      Object[] var37 = new Object[]{var13};
      MsdfFont var36 = var8;
      float var24 = var36.cReturningFloat(var37);
      float var25 = 4.0F;
      float var26 = 1.5F;
      float var27 = var23 + var25 * 2.0F;
      float var28 = (var7 + var12) * 0.5F;
      float var29 = var28 - var27 * 0.5F;
      float var30 = var29 + var27;
      float var31 = var10 - 3.0F;
      float var32 = var31 - (var24 + var26 * 2.0F);
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var17};
      var10011[7] = var11;
      var10011[6] = var31;
      var10011[5] = var30;
      var10011[4] = var32;
      var10011[3] = var29;
      var10011[2] = var3;
      var10011[1] = var2;
      var10011[0] = var4;
      Object[] var39 = var10011;
      TwoDESP var38 = this;
      var38.t(var39);
      short var10002 = 8561;
      long var10003 = 5812827097200368563L ^ var5;
      short var44 = 8561;
      long var10004 = 5812827097200368563L ^ var5;
      short var46 = 20086;
      long var10005 = 7497179373273117882L ^ var5;
      Color var10000 = new Color(240, 240, 250);
      Object[] var47 = new Object[]{null, null, var21};
      var47[1] = var11;
      var47[0] = var10000;
      Object[] var40 = var47;
      Color var33 = aReturningColor(var40);
      float var45 = var29 + var25;
      float var48 = var32 + var26;
      Object[] var10008 = new Object[]{null, null, null, null, var33, var19};
      var10008[3] = var48;
      var10008[2] = var45;
      var10008[1] = var9;
      var10008[0] = var3;
      Object[] var42 = var10008;
      MsdfFont var41 = var8;
      var41.v(var42);
   }

   private void s(Object[] var1) {
      MeshBufferManager var10 = (MeshBufferManager)var1[0];
      RenderContext var9 = (RenderContext)var1[1];
      Matrix4f var6 = (Matrix4f)var1[2];
      MsdfFont var4 = (MsdfFont)var1[3];
      float var11 = (Float)var1[4];
      float var5 = (Float)var1[5];
      float var12 = (Float)var1[6];
      float var2 = (Float)var1[7];
      float var3 = (Float)var1[8];
      long var7 = (Long)var1[9];
      var7 = 95832993219536L ^ var7;
      long var13 = var7 ^ 64678993838974L;
      long var15 = var7 ^ 103407723034726L;
      long var17 = var7 ^ 87538752712208L;
      long var19 = var7 ^ 123829165738466L;
      long var21 = var7 ^ 118559090133038L;
      int var10000 = Event.cReturningInt();
      int var24 = (int)var2;
      int var23 = var10000;
      var10000 = (int)(var2 * 10.0F);
      short var10002 = 23042;
      long var10003 = 872075718952783510L ^ var7;
      int var25 = var10000 - var24 * 10;
      int var52 = var23;
      int var51 = var25;
      int var50 = var51;
      int var49 = var51;
      if (var52 != 0) {
         int var53 = var49;
         if (var53 < 0) {
            var25 = -var25;
         }

         var50 = var24;
      }

      String var26 = var50 + "." + var25 + "m";
      float var27 = 0.75F;
      Object[] var41 = new Object[]{var26, var15};
      MsdfFont var40 = var4;
      float var28 = var40.aReturningFloat(var41) * var27;
      Object[] var43 = new Object[]{var13};
      MsdfFont var42 = var4;
      float var29 = var42.cReturningFloat(var43) * var27;
      float var30 = 3.5F;
      float var31 = 1.5F;
      float var32 = var28 + var30 * 2.0F;
      float var33 = (var11 + var12) * 0.5F;
      float var34 = var33 - var32 * 0.5F;
      float var35 = var34 + var32;
      float var36 = var5 + 3.0F;
      float var37 = var36 + var29 + var31 * 2.0F;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var17};
      var10011[7] = var3;
      var10011[6] = var37;
      var10011[5] = var35;
      var10011[4] = var36;
      var10011[3] = var34;
      var10011[2] = var6;
      var10011[1] = var9;
      var10011[0] = var10;
      Object[] var45 = var10011;
      TwoDESP var44 = this;
      var44.t(var45);
      var10002 = 31290;
      var10003 = 7416357872487345837L ^ var7;
      short var59 = 28938;
      long var10004 = 4490161137383974289L ^ var7;
      short var61 = 28351;
      long var10005 = 4966631643859335722L ^ var7;
      Color var56 = new Color(200, 200, 220);
      Object[] var62 = new Object[]{null, null, var21};
      var62[1] = var3;
      var62[0] = var56;
      Object[] var46 = var62;
      Color var38 = aReturningColor(var46);
      float var60 = var34 + var30;
      float var63 = var36 + var31;
      Object[] var10009 = new Object[]{null, null, null, null, null, var38, var19};
      var10009[4] = var27;
      var10009[3] = var63;
      var10009[2] = var60;
      var10009[1] = var26;
      var10009[0] = var6;
      Object[] var48 = var10009;
      MsdfFont var47 = var4;
      var47.w(var48);
   }

   private void t(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      RenderContext var4 = (RenderContext)var1[1];
      Matrix4f var8 = (Matrix4f)var1[2];
      float var9 = (Float)var1[3];
      float var2 = (Float)var1[4];
      float var10 = (Float)var1[5];
      float var11 = (Float)var1[6];
      float var3 = (Float)var1[7];
      long var6 = (Long)var1[8];
      var6 = 95832993219536L ^ var6;
      long var12 = var6 ^ 39001299954022L;
      long var14 = var6 ^ 23817427597546L;
      long var16 = var6 ^ 119537868750325L;
      long var18 = var6 ^ 50272732741605L;
      float var20 = var10 - var9;
      float var21 = var11 - var2;
      MultiModeSetting var10000 = this.f;
      short var10001 = 18337;
      long var10002 = 6310499407990750642L ^ var6;
      Object[] var24 = new Object[]{"Blur Labels", var16};
      MultiModeSetting var23 = var10000;
      boolean var29 = var23.aReturningBoolean(var24);
      if (var29) {
         Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
         var10011[8] = 2.5F;
         var10011[7] = 5;
         var10011[6] = var21;
         var10011[5] = var20;
         var10011[4] = var2;
         var10011[3] = var9;
         var10011[2] = var8;
         var10011[1] = var4;
         var10011[0] = var5;
         Object[] var25 = var10011;
         BlurredRectangleRenderer.eReturningVoid(var25);
      }

      short var31 = 217;
      long var10003 = 5112474767340632451L ^ var6;
      short var32 = 29912;
      long var10004 = 1051858368290655630L ^ var6;
      short var33 = 32366;
      long var10005 = 7103787250427004727L ^ var6;
      float var34 = var3 * 0.72F;
      Object[] var10008 = new Object[]{null, var18};
      var10008[0] = var34;
      Object[] var27 = var10008;
      Color var22 = new Color(16, 16, 22, aReturningInt(var27));
      Object[] var35 = new Object[]{null, null, null, null, null, null, null, null, null, var14};
      var35[8] = 2.5F;
      var35[7] = var22;
      var35[6] = var21;
      var35[5] = var20;
      var35[4] = var2;
      var35[3] = var9;
      var35[2] = var8;
      var35[1] = var4;
      var35[0] = var5;
      Object[] var28 = var35;
      FilledRectangleRenderer.cReturningVoid(var28);
   }

   private float[] aReturningArrayOfFloat(Object[] var1) {
      Vec3d var6 = (Vec3d)var1[0];
      float var5 = (Float)var1[1];
      float var4 = (Float)var1[2];
      long var2 = (Long)var1[3];
      var2 = 95832993219536L ^ var2;
      long var7 = var2 ^ 29219677160480L;
      int var10000 = Event.cReturningInt();
      double var10 = var5 * 0.5;
      int var9 = var10000;
      double var12 = var4;
      float var14 = Float.POSITIVE_INFINITY;
      float var15 = Float.POSITIVE_INFINITY;
      float var16 = Float.NEGATIVE_INFINITY;
      float var17 = Float.NEGATIVE_INFINITY;
      int var129;
      do {
         short var10001 = 20001;
         long var10002 = 5124917556953558103L ^ var2;
         byte var84 = 8;
         int var83 = var18;
         if (var83 >= var84) {
            break;
         }

         Vec3d var28 = var6;
         int var87 = var18 & 1;
         double var85 = var28.x;
         double var45 = var85;
         double var43 = var85;
         double var47;
         double var49;
         if (var87 == 0) {
            double var90 = -var10;
            double var88 = var43;
            var47 = var88;
            var49 = var90;
         } else {
            var49 = var10;
            var47 = var45;
         }

         double var19 = var47 + var49;
         Vec3d var30 = var6;
         int var94 = var18 & 2;
         double var92 = var30.y;
         double var53 = var92;
         double var51 = var92;
         double var55;
         double var57;
         if (var94 == 0) {
            double var95 = var51;
            var55 = var95;
            var57 = var97;
         } else {
            var57 = var12;
            var55 = var53;
         }

         double var21 = var55 + var57;
         Vec3d var32 = var6;
         int var101 = var18 & 4;
         double var99 = var32.z;
         double var61 = var99;
         double var59 = var99;
         double var63;
         double var65;
         if (var101 == 0) {
            double var104 = -var10;
            double var102 = var59;
            var63 = var102;
            var65 = var104;
         } else {
            var65 = var10;
            var63 = var61;
         }

         Vec3d var25;
         double var73;
         label94: {
            double var23 = var63 + var65;
            Object[] var34 = new Object[]{new Vec3d(var19, var21, var23), var7};
            var25 = GameRenderUtil.aReturningVec3d(var34);
            Vec3d var35 = var25;
            double var133;
            var10000 = (var133 = var35.z - 0.0) == 0.0 ? 0 : (var133 < 0.0 ? -1 : 1);
            int var107 = var9;
            int var106 = var10000;
            int var72 = var106;
            int var67 = var106;
            if (var107 != 0) {
               int var108 = var67;
               if (var108 < 0) {
                  return null;
               }

               Vec3d var37 = var25;
               int var111 = var9;
               double var109 = var37.z;
               var73 = var109;
               double var68 = var109;
               if (var111 == 0) {
                  break label94;
               }

               double var112 = var68;
               double var70 = var112;
               double var134;
               int var114 = (var134 = var70 - 1.0) == 0.0 ? 0 : (var134 < 0.0 ? -1 : 1);
               var72 = var114;
            }

            int var115 = var72;
            if (var115 >= 0) {
               return null;
            }

            Vec3d var41 = var25;
            var73 = var41.x;
         }

         float var26 = (float)var73;
         Vec3d var42 = var25;
         float var27 = (float)var42.y;
         float var135;
         var10000 = (var135 = var26 - var14) == 0.0F ? 0 : (var135 < 0.0F ? -1 : 1);
         int var117 = var9;
         int var116 = var10000;
         int var76 = var116;
         int var75 = var116;
         if (var117 != 0) {
            int var118 = var75;
            if (var118 < 0) {
               var14 = var26;
            }

            float var136;
            var76 = (var136 = var26 - var16) == 0.0F ? 0 : (var136 < 0.0F ? -1 : 1);
         }

         int var120 = var9;
         int var119 = var76;
         int var78 = var119;
         int var77 = var119;
         if (var120 != 0) {
            int var121 = var77;
            if (var121 > 0) {
               var16 = var26;
            }

            float var137;
            var78 = (var137 = var27 - var15) == 0.0F ? 0 : (var137 < 0.0F ? -1 : 1);
         }

         label67: {
            float var82;
            label96: {
               int var123 = var9;
               int var122 = var78;
               int var81 = var122;
               int var79 = var122;
               if (var123 != 0) {
                  int var124 = var79;
                  if (var124 < 0) {
                     var15 = var27;
                  }

                  int var126 = var9;
                  float var125 = var27;
                  var82 = var125;
                  float var80 = var125;
                  if (var126 == 0) {
                     break label96;
                  }

                  float var138;
                  int var127 = (var138 = var80 - var17) == 0.0F ? 0 : (var138 < 0.0F ? -1 : 1);
                  var81 = var127;
               }

               int var128 = var81;
               if (var128 <= 0) {
                  break label67;
               }

               var82 = var27;
            }

            var17 = var82;
         }

         var18++;
         var129 = var9;
      } while (var129 != 0);

      return new float[]{var14, var15, var16, var17};
   }

   private static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 95832993219536L ^ var2;
      long var5 = var2 ^ 43787717954551L;
      long var7 = var2 ^ 124786914256014L;
      Color var10 = var1;
      float var10000 = var10.getAlpha();
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = var4;
      Object[] var11 = var10004;
      float var12 = var10000 * cReturningFloat(var11);
      int var9 = Math.round(var12);
      Color var13 = var1;
      int var10002 = var13.getRed();
      Color var14 = var1;
      int var10003 = var14.getGreen();
      Color var15 = var1;
      int var18 = var15.getBlue();
      Object[] var10008 = new Object[]{null, var5};
      var10008[0] = var9;
      Object[] var16 = var10008;
      return new Color(var10002, var10003, var18, cReturningInt(var16));
   }

   private static Color bReturningColor(Object[] var0) {
      Color var5 = (Color)var0[0];
      Color var1 = (Color)var0[1];
      float var4 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 95832993219536L ^ var2;
      long var6 = var2 ^ 40218971117120L;
      long var8 = var2 ^ 125589634758969L;
      Object[] var10003 = new Object[]{null, var8};
      var10003[0] = var4;
      Object[] var14 = var10003;
      var4 = cReturningFloat(var14);
      Color var15 = var5;
      float var10000 = var15.getRed();
      Color var16 = var1;
      int var10001 = var16.getRed();
      Color var17 = var5;
      float var18 = var10000 + (var10001 - var17.getRed()) * var4;
      int var10 = Math.round(var18);
      Color var19 = var5;
      var10000 = var19.getGreen();
      Color var20 = var1;
      var10001 = var20.getGreen();
      Color var21 = var5;
      float var22 = var10000 + (var10001 - var21.getGreen()) * var4;
      int var11 = Math.round(var22);
      Color var23 = var5;
      var10000 = var23.getBlue();
      Color var24 = var1;
      var10001 = var24.getBlue();
      Color var25 = var5;
      float var26 = var10000 + (var10001 - var25.getBlue()) * var4;
      int var12 = Math.round(var26);
      Color var27 = var5;
      var10000 = var27.getAlpha();
      Color var28 = var1;
      var10001 = var28.getAlpha();
      Color var29 = var5;
      float var30 = var10000 + (var10001 - var29.getAlpha()) * var4;
      int var13 = Math.round(var30);
      Object[] var10005 = new Object[]{null, var6};
      var10005[0] = var10;
      Object[] var31 = var10005;
      int var10002 = cReturningInt(var31);
      Object[] var10006 = new Object[]{null, var6};
      var10006[0] = var11;
      Object[] var32 = var10006;
      int var43 = cReturningInt(var32);
      Object[] var10007 = new Object[]{null, var6};
      var10007[0] = var12;
      Object[] var33 = var10007;
      int var10004 = cReturningInt(var33);
      Object[] var10008 = new Object[]{null, var6};
      var10008[0] = var13;
      Object[] var34 = var10008;
      return new Color(var10002, var43, var10004, cReturningInt(var34));
   }

   private static Color cReturningColor(Object[] var0) {
      Color var3 = (Color)var0[0];
      Color var4 = (Color)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 95832993219536L ^ var1;
      Color var5 = var3;
      int var10002 = var5.getRed();
      Color var6 = var4;
      var10002 = (var10002 + var6.getRed()) / 2;
      Color var7 = var3;
      int var10003 = var7.getGreen();
      Color var8 = var4;
      var10003 = (var10003 + var8.getGreen()) / 2;
      Color var9 = var3;
      int var10004 = var9.getBlue();
      Color var10 = var4;
      var10004 = (var10004 + var10.getBlue()) / 2;
      Color var11 = var3;
      int var10005 = var11.getAlpha();
      Color var12 = var4;
      return new Color(var10002, var10003, var10004, (var10005 + var12.getAlpha()) / 2);
   }

   private static float bReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var2 = (Float)var0[2];
      long var4 = (Long)var0[3];
      var4 = 95832993219536L ^ var4;
      long var6 = var4 ^ 36668622680986L;
      float var10001 = var3 - var1;
      Object[] var10005 = new Object[]{null, var6};
      var10005[0] = var2;
      Object[] var8 = var10005;
      return var1 + var10001 * cReturningFloat(var8);
   }

   private static float cReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 95832993219536L ^ var2;
      int var4 = Event.bReturningInt();
      float var20;
      int var19 = (var20 = var1 - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
      int var11 = var4;
      int var10 = var19;
      int var7 = var10;
      int var5 = var10;
      if (var11 == 0) {
         int var12 = var5;
         if (var12 < 0) {
            return 0.0F;
         }

         int var15 = var4;
         float var14 = var1;
         float var8 = var14;
         float var6 = var14;
         if (var15 != 0) {
            return var8;
         }

         float var21;
         int var16 = (var21 = var6 - 1.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
         var7 = var16;
      }

      int var17 = var7;
      return var17 <= 0 ? var1 : 1.0F;
   }

   private static float dReturningFloat(Object[] var0) {
      float var5 = (Float)var0[0];
      float var2 = (Float)var0[1];
      float var1 = (Float)var0[2];
      long var3 = (Long)var0[3];
      long var10000 = 95832993219536L ^ var3;
      int var6 = Event.cReturningInt();
      float var22;
      int var21 = (var22 = var5 - var2) == 0.0F ? 0 : (var22 < 0.0F ? -1 : 1);
      int var13 = var6;
      int var12 = var21;
      int var9 = var12;
      int var7 = var12;
      if (var13 != 0) {
         int var14 = var7;
         if (var14 < 0) {
            return var2;
         }

         int var17 = var6;
         float var16 = var5;
         float var10 = var16;
         float var8 = var16;
         if (var17 == 0) {
            return var10;
         }

         float var23;
         int var18 = (var23 = var8 - var1) == 0.0F ? 0 : (var23 < 0.0F ? -1 : 1);
         var9 = var18;
      }

      int var19 = var9;
      return var19 <= 0 ? var5 : var1;
   }

   private static int aReturningInt(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      var2 = 95832993219536L ^ var2;
      int var10000 = Event.bReturningInt();
      float var6 = var1 * 255.0F;
      int var5 = Math.round(var6);
      int var4 = var10000;
      int var13 = var4;
      int var12 = var5;
      int var8 = var12;
      int var7 = var12;
      if (var13 == 0) {
         int var14 = var7;
         if (var14 < 0) {
            byte var15 = 0;
            byte var25 = var15;
            return var25;
         }

         var8 = var5;
      }

      int var17 = var4;
      int var16 = var8;
      int var10 = var16;
      int var9 = var16;
      int var11;
      if (var17 == 0) {
         short var10001 = 8174;
         long var10002 = 4784866127637731977L ^ var2;
         short var19 = 255;
         int var18 = var9;
         if (var18 > var19) {
            short var23 = 8174;
            long var24 = 4784866127637731977L ^ var2;
            short var20 = 255;
            var11 = var20;
         } else {
            var11 = var5;
         }
      } else {
         int var21 = var10;
         var11 = var21;
      }

      return var11;
   }

   private static int cReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 95832993219536L ^ var2;
      int var4 = Event.bReturningInt();
      int var11 = var4;
      int var10 = var1;
      int var6 = var10;
      int var5 = var10;
      if (var11 == 0) {
         int var12 = var5;
         if (var12 < 0) {
            int var22 = var13;
            return var22;
         }

         var6 = var1;
      }

      int var15 = var4;
      int var14 = var6;
      int var8 = var14;
      int var7 = var14;
      int var9;
      if (var15 == 0) {
         short var10001 = 23232;
         long var10002 = 8351590359298542986L ^ var2;
         short var17 = 255;
         int var16 = var7;
         if (var16 > var17) {
            short var10000 = 8174;
            long var21 = 4784912184938023077L ^ var2;
            short var18 = 255;
            var9 = var18;
         } else {
            var9 = var1;
         }
      } else {
         int var19 = var8;
         var9 = var19;
      }

      return var9;
   }

   private static double lambda$onTick$11(EntityScreenBounds var0) {
      return var0.g;
   }

   private boolean lambda$new$10(Color var1) {
      long var10001 = 77234574998766L ^ 7442737292928L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Health Bar", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$9(Color var1) {
      long var10001 = 62227271106721L ^ 132362784316111L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Health Bar", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$8(Color var1) {
      long var10001 = 10091005959382L ^ 81187901867704L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Gradient", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$7(Color var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.q;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   private boolean lambda$new$6(Boolean var1) {
      long var10001 = 129326882889737L ^ 58708783823463L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Health Bar", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$5(Boolean var1) {
      long var10001 = 127976732651587L ^ 57855649393197L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Health Bar", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$4(String var1) {
      long var10001 = 18645628809765L ^ 88026173319243L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Health Bar", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$3(Float var1) {
      long var10001 = 115153297633483L ^ 44260740573861L;
      int var6 = Event.bReturningInt();
      MultiModeSetting var10000 = this.f;
      Object[] var8 = new Object[]{"Gradient", 71444480285294L};
      MultiModeSetting var7 = var10000;
      byte var25 = ((byte)((var7.aReturningBoolean(var8)) ? 1 : 0));
      int var18 = var6;
      byte var17 = var25;
      int var13 = var17;
      byte var12 = var17;
      if (var18 == 0) {
         byte var19 = var12;
         if (var19 == 0) {
            return false;
         }

         BooleanSetting var10 = this.i;
         Boolean var11 = (Boolean)var10.aReturningObject();
         byte var20 = ((byte)(((java.lang.Boolean)(var11)).booleanValue() ? 1 : 0));
         var13 = var20;
      }

      int var22 = var6;
      int var21 = var13;
      int var15 = var21;
      int var14 = var21;
      if (var22 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var15);
      } else {
         int var23 = var14;
         if (var23 != 0) {
            var15 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var15);
         } else {
            return false;
         }
      }
   }

   private boolean lambda$new$2(Boolean var1) {
      long var10001 = 21804747169191L ^ 91459834070985L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Gradient", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$1(Float var1) {
      long var10001 = 51819349749123L ^ 122987851380717L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Glow", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   private boolean lambda$new$0(Float var1) {
      long var10001 = 69170527545501L ^ 138621988860659L;
      MultiModeSetting var10000 = this.f;
      Object[] var7 = new Object[]{"Fill", 71444480285294L};
      MultiModeSetting var6 = var10000;
      return var6.aReturningBoolean(var7);
   }

   static {

      {

      f();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(125361417837955L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[19];
      String var28 = "S{%ýÌÙ\u0006/¢ú×\u001b\u0088?ª!\u0018ø¹@\u001bk\u0002ù¿\u001b«ñE©\u00adÁô=&w¿ÒßlÝ\u0010W_¥\r!\u0090û*Ï\u0095\nØb?_\u0084 \\-\u007fýð\rÕ\u0089fvh\u0084Q\u00825ÜLÛ\u008fu\u0099à ;\u008c%kJà\u0088P5\u0010U\u0000ßO\u00976Þ\u009c\b\u001f\u0004nÿG\u0096i\u0010ª\u0097ù\u0097õÙ(òF½\u00ad³¯0\u001dá\u00107Øç0\u0089\u0088ù²\u009dÇ\bô\u000f³s@\u0018máT/\u001e½Ñ^B7EÕ7\u0093ÊP\bê·\u0005¹ýn¾\u0010T\u001c'/EÁ²ÄÁ\u0019\u0015*ê\u0011>f -xzæ°ÄðËù+=µº\u0016|^\u000fÐC~ý\u0081çL«/U\u001f÷\u0001«.\u0018\u0002_ÑÆ¦\u0083\u0098\u0012\u0095àí|]è\u001aµ\u008dÊ\bÜ\u001fa¦ì d³r~\u0001õ©É;\u009c£\u0092\u0087(\u008eu\u0003çõ±\u008eLkï7Òuöå\u009f\u0005\u0011\u0010[\rCy.\u0018)&%\u0015þyÜ«é²\u0010k[î\u0089\u0014h=\u0015/¥\u008c5Î5z\u0094\u0010r\u0003â\u008cJÝÌ¬ÈT¡Û\u0091\u009c\u0018Û\u0010¬*\u0083\u009a\u001cæ\\}9ôÏ¥[\u0092±\u0080 ¤\u0013fªò&7B\u008cÃ) Põ\u0003{r5\r²\u0086\u0017Æq\u0087*ô\u009d\u0006^\u0016m";
      int var30 = "S{%ýÌÙ\u0006/¢ú×\u001b\u0088?ª!\u0018ø¹@\u001bk\u0002ù¿\u001b«ñE©\u00adÁô=&w¿ÒßlÝ\u0010W_¥\r!\u0090û*Ï\u0095\nØb?_\u0084 \\-\u007fýð\rÕ\u0089fvh\u0084Q\u00825ÜLÛ\u008fu\u0099à ;\u008c%kJà\u0088P5\u0010U\u0000ßO\u00976Þ\u009c\b\u001f\u0004nÿG\u0096i\u0010ª\u0097ù\u0097õÙ(òF½\u00ad³¯0\u001dá\u00107Øç0\u0089\u0088ù²\u009dÇ\bô\u000f³s@\u0018máT/\u001e½Ñ^B7EÕ7\u0093ÊP\bê·\u0005¹ýn¾\u0010T\u001c'/EÁ²ÄÁ\u0019\u0015*ê\u0011>f -xzæ°ÄðËù+=µº\u0016|^\u000fÐC~ý\u0081çL«/U\u001f÷\u0001«.\u0018\u0002_ÑÆ¦\u0083\u0098\u0012\u0095àí|]è\u001aµ\u008dÊ\bÜ\u001fa¦ì d³r~\u0001õ©É;\u009c£\u0092\u0087(\u008eu\u0003çõ±\u008eLkï7Òuöå\u009f\u0005\u0011\u0010[\rCy.\u0018)&%\u0015þyÜ«é²\u0010k[î\u0089\u0014h=\u0015/¥\u008c5Î5z\u0094\u0010r\u0003â\u008cJÝÌ¬ÈT¡Û\u0091\u009c\u0018Û\u0010¬*\u0083\u009a\u001cæ\\}9ôÏ¥[\u0092±\u0080 ¤\u0013fªò&7B\u008cÃ) Põ\u0003{r5\r²\u0086\u0017Æq\u0087*ô\u009d\u0006^\u0016m"
         .length();
      char var27 = 16;
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     C = var31;
                     D = new String[19];
                     H = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(125361417837955L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[16];
                     String var15 = "\u0005¼µÍ\u000eÓ¹¦+C\u0096µ,Ö\u001eÙFÎù¡\u009e»'eóì?+^\u008c\u009b\"\u0086þIèô:\u0081ñ\u008d-âÓ©\u0010\u0085ÖÏ\tä\u0007®1Ý\u001b\u0002ÕÝ\u0010VÏB+Â\u008f\u0092\u0000\u0019Sz\u008fÂé[3Iø4\u008f\u0000-Ó \u001d\u0006\u0084\u001bÇúT\u0098ë²µ¼ûwã¹.AÆÑÚ[4\u0098¶`c°";
                     int var16 = "\u0005¼µÍ\u000eÓ¹¦+C\u0096µ,Ö\u001eÙFÎù¡\u009e»'eóì?+^\u008c\u009b\"\u0086þIèô:\u0081ñ\u008d-âÓ©\u0010\u0085ÖÏ\tä\u0007®1Ý\u001b\u0002ÕÝ\u0010VÏB+Â\u008f\u0092\u0000\u0019Sz\u008fÂé[3Iø4\u008f\u0000-Ó \u001d\u0006\u0084\u001bÇúT\u0098ë²µ¼ûwã¹.AÆÑÚ[4\u0098¶`c°"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    F = var17;
                                    G = new Integer[16];
                                    K = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(125361417837955L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[5];
                                    String var4 = "\u0014\u0093ÖmÃ\u0093V:T@\u001bðÊ¾\u001dã§;ô|)\u0014½\u008c";
                                    int var5 = "\u0014\u0093ÖmÃ\u0093V:T@\u001bðÊ¾\u001dã§;ô|)\u0014½\u008c".length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   I = var6;
                                                   J = new Long[5];
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "ï\u008a!¦Þ\u00822\u001f\u0086¨r\u009f\u001f£\u0014£";
                                                var5 = "ï\u008a!¦Þ\u00822\u001f\u0086¨r\u009f\u001f£\u0014£".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "2\u0014jZ\u008e\\(GÆ\u009cA¹Ì&G\u0098";
                                 var16 = "2\u0014jZ\u008e\\(GÆ\u009cA¹Ì&G\u0098".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "»»\u0016x\u00855\u0098ÙIp&Q\u008aÖP+ V=\u0089Õ\u0011\u009fÁÉlqSlæ\u0006\u0088T*ä9&«)V¬i%^\u008c×G \u0014";
                  var30 = "»»\u0016x\u00855\u0098ÙIp&Q\u008aÖP+ V=\u0089Õ\u0011\u009fÁÉlqSlæ\u0006\u0088T*ä9&«)V¬i%^\u008c×G \u0014".length();
                  var27 = 16;
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23960;
      if (D[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])E.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               E.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fE", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = C[var5].getBytes("ISO-8859-1");
         D[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return D[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fE_C0279",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fE" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 7881;
      if (G[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = F[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])H.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               H.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fE", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         G[var3] = var15;
      }

      return G[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fE_C0279",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fE" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3775;
      if (J[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = I[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])K.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               K.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fE", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         J[var3] = var15;
      }

      return J[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fE_C0279",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fE" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = M[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = L[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 55;
            yield var15;
         }
         case 1 -> {
            byte var16 = 28;
            yield var16;
         }
         case 2 -> {
            byte var17 = 63;
            yield var17;
         }
         case 3 -> {
            byte var18 = 35;
            yield var18;
         }
         case 4 -> {
            byte var19 = 10;
            yield var19;
         }
         case 5 -> {
            byte var20 = 26;
            yield var20;
         }
         case 6 -> {
            byte var21 = 56;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 61;
            yield var24;
         }
         case 10 -> {
            byte var25 = 27;
            yield var25;
         }
         case 11 -> {
            byte var26 = 11;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 14;
            yield var28;
         }
         case 14 -> {
            byte var29 = 41;
            yield var29;
         }
         case 15 -> {
            byte var30 = 32;
            yield var30;
         }
         case 16 -> {
            byte var31 = 7;
            yield var31;
         }
         case 17 -> {
            byte var32 = 6;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 53;
            yield var34;
         }
         case 20 -> {
            byte var35 = 22;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 48;
            yield var37;
         }
         case 23 -> {
            byte var38 = 31;
            yield var38;
         }
         case 24 -> {
            byte var39 = 1;
            yield var39;
         }
         case 25 -> {
            byte var40 = 47;
            yield var40;
         }
         case 26 -> {
            byte var41 = 43;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 38;
            yield var43;
         }
         case 29 -> {
            byte var44 = 8;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 60;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 57;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 51;
            yield var52;
         }
         case 38 -> {
            byte var53 = 16;
            yield var53;
         }
         case 39 -> {
            byte var54 = 9;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 13;
            yield var56;
         }
         case 42 -> {
            byte var57 = 17;
            yield var57;
         }
         case 43 -> {
            byte var58 = 36;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 25;
            yield var60;
         }
         case 46 -> {
            byte var61 = 12;
            yield var61;
         }
         case 47 -> {
            byte var62 = 45;
            yield var62;
         }
         case 48 -> {
            byte var63 = 30;
            yield var63;
         }
         case 49 -> {
            byte var64 = 52;
            yield var64;
         }
         case 50 -> {
            byte var65 = 50;
            yield var65;
         }
         case 51 -> {
            byte var66 = 23;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 37;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 24;
            yield var70;
         }
         case 56 -> {
            byte var71 = 4;
            yield var71;
         }
         case 57 -> {
            byte var72 = 0;
            yield var72;
         }
         case 58 -> {
            byte var73 = 21;
            yield var73;
         }
         case 59 -> {
            byte var74 = 19;
            yield var74;
         }
         case 60 -> {
            byte var75 = 18;
            yield var75;
         }
         case 61 -> {
            byte var76 = 49;
            yield var76;
         }
         case 62 -> {
            byte var77 = 54;
            yield var77;
         }
         default -> 5;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            M[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      L[0] = "f\fn{R+p\fk!A<gGh'M(v\u0000\u007f0\u0006=G";
      L[1] = "\u0005\u001ae\u0007;Ep:n\b*\n\u00114e\u0003.Pe";
      L[2] = float.class;
      M[2] = "java/lang/Float";
      L[3] = "\tP>kDS\u0002_/$'^\u0017Y";
      L[4] = int.class;
      M[4] = "java/lang/Integer";
      L[5] = "4\" L\u000f@)7xnNM11";
      L[6] = "\fe\u001c\u001bI=yE\u0017\u0014Xr\u0018K\u001c\u001f\\(l";
      L[7] = void.class;
      M[7] = "java/lang/Void";
      L[8] = "e\"3q\u0003g\u0010\u00028~\u0012(q\f3u\u0016r\u0005";
      L[9] = "\b\u0006\\kFP}&WdW\u001f\u001c(\\oSEh";
      L[10] = "g^l\u000b>Tq^iQ-Cf\u0015jW!WwR}@j@M";
      L[11] = "00rf\u0007\u0007E\u0010yi\u0016H$\u001erb\u0012\u0012P";
      L[12] = boolean.class;
      M[12] = "java/lang/Boolean";
      L[13] = "\u0010\u001fL':\u0016e?G(+Y\u00041L#/\u0003p";
      L[14] = "xx\u0014%O\nsw\u0005j,\u0007fz\n\u0001\u0019\u0005wi\u0016-\u000e\b";
      L[15] = "\u000f\u0004\rlH>\u0019\u0004\b6[)\u000eO\u000b0W=\u001f\b\u001c'\u001c*\r";
      L[16] = "}^#U#x\b~(Z27ip#Q6m\u001d";
      L[17] = "WdQc1-AdT9\":V/W?..Gh@(e>\n";
      L[18] = "\u001bOO\u0004\u0003JnoD\u000b\u0012\u0005\u000faO\u0000\u0016_{";
      L[19] = "\r<NI4\u000ex\u001cEF%A\u0019\u0012NM!\u001bm";
      L[20] = "&1q9n\u001b01tc}\f'zweq\u00186=`r:\b:";
      L[21] = "t\u0017~N+=\u00017uA:r`9~J>(\u0014";
      L[22] = "L\u0003=\b7_Z\u00038R$HMH;T(\\\\\u000f,CcNm";
      L[23] = "-7k4\u0016[X\u0017`;\u0007\u00149\u0019k0\u0003NM";
      L[24] = ")\u0003N\r\u0000-\\#E\u0002\u0011b=-N\t\u00158I";
      L[25] = "+@SK|s^`XDm<?nSOifK";
      L[26] = "L8\u007f\u00117rG7n^JjT0g\u0017";
      L[27] = "v(VPd\u001f}'G\u001f\u0005\u0011v,CE";
      L[28] = "+IuZ'\u0001^i~U6N?gu^2\u0014K";
      L[29] = "}l\u001a'tI\bL\u0011(e\u0006iB\u001a#a\\\u001d";
      L[30] = "KoI\"?S>OB-.\u001c_AI&*F+";
      L[31] = ";\u001aFUy\u00050\u0015W\u001a\u0015\u0006>\u0017UU9";
      L[32] = "\u0015|\u0015j\u0018\u0010\u0003|\u00100\u000b\u0007\u00147\u00136\u0007\u0013\u0005p\u0004!L\u00047";
      L[33] = "d\f=w<3\u0011,6x-|p\"=s)&\u0004";
      L[34] = "-X{iNM&Wj&&M(Xy";
      L[35] = "\r`o\u000f\u0019,\u001b`jU\n;\f+iS\u0006/\u001dl~DM8\u001e";
      L[36] = "\u0001{\u0007EDGt[\fJU\b\u0015U\u0007AQRa";
      L[37] = "1F',C>Df,#Rq%h'(V+Q";
      L[38] = "\u0010}$\u0006\\ce]/\tM,\u0004S$\u0002Ivp";
      L[39] = "\u0006@%+\f\u000bs`.$\u001dD\u0012n%/\u0019\u001ef";
      L[40] = "7*&?\fyB\n-0\u001d6#\u0004&;\u0019lW";
      L[41] = "s84\u007fq/\u0006\u0018?p``g\u00164{d:\u0013";
      L[42] = double.class;
      M[42] = "java/lang/Double";
      L[43] = "TGkS@\u0013TG|\u000fL\u001cN\f|\u0011L\tI}.M\u0019K";
      L[44] = "(fS\u0012_\\#iB]\"I1s@\u001e";
      L[45] = long.class;
      M[45] = "java/lang/Long";
      L[46] = "UBI%\u001b1KJSjx%O\u0007z*A6F";
      L[47] = "n\u0000%d\u0018\u0012x\u0000 >\u000b\u0005oK#8\u0007\u0011~\f4/L\u0001f\f6$\u0016LZ\u001769\u0016\u000bm\u0000";
      L[48] = "l\u00007L\u0007Iz\u00002\u0016\u0014^mK1\u0010\u0018J|\f&\u0007SZr";
      L[49] = "\u0004\u0005\u0006>\u0014M\u0004\u0005\u0011b\u0018B\u001eN\u0011|\u0018W\u0019?A!I";
      L[50] = "5ul~PG5u{\"\\H/>{<\\](O,c\n";
      L[51] = "'\u0005+5FdR% :W+3++1SqG";
      L[52] = "\u0012z1g0S\u0004z4=#D\u001317;/P\u0002v ,d@1";
      L[53] = "0&F<j~E\u0006M3{1$\bF8\u007fkP";
      L[54] = "\u001c0L\u001a<T\n0I@/C\u001d{JF#W\f<]QhAK";
      L[55] = "@P\u0001\":)^X\u001bm](OC\u00167{.";
      L[56] = "LB^{LvRJD4/bV";
      L[57] = "dpA\u0012lXdpVN`W~;VP`ByJ\u0002\b7";
      L[58] = "\ftT5v \ftCiz/\u0016?Cwz:\u0011N\u0011-.~";
      L[59] = "N9Fz0kN9Q&<dTrQ8<qS\u0003\u0006bm6";
      L[60] = "HAN~^\u0011HAY\"R\u001eR\nY<R\u000bU{\bc\u000b";
      L[61] = "Ul+q\r\u0013 L ~\u001c\\AB+u\u0018\u00065";
      L[62] = "\u0004\bx\u000e$'\u001a\u0000bAY7\u001a";
      L[63] = "k5\u0013\u007f2\f\u001e\u0015\u0018p#C\u007f\u001b\u0013{'\u0019\u000b";
      L[64] = "\u0001$\u0015gp/\u0017$\u0010=c8\u0000o\u0013;o,\u0011(\u0004,$;,";
      L[65] = "^O>^\fr+o5Q\u001d=Ja>Z\u0019g>";
      L[66] = "gM\u001dW\u0003_\u0012m\u0016X\u0012\u0010sc\u001dS\u0016J\u0007";
      L[67] = "z\u000f\u001fw3\u000ez\u000f\b+?\u0001`D\b5?\u0014g5Ymm";
      L[68] = ".$6\u001a1\u001b.$!F=\u00144o!X=\u00013\u001et\u0007d";
      L[69] = "Q\u0014\u0011m1e$4\u001ab *E:\u0011i$p1";
      L[70] = "Z~";
      L[71] = "\u0019:LlF\u001e\u000f:I6U\t\u0018qJ0Y\u001d\t6]'\u0012\n\u000b";
      L[72] = "|<+\f6 \t\u001c \u0003'oh\u0012+\b#5\u001c";
      L[73] = "ZI5_\u000e&LI0\u0005\u001d1[\u00023\u0003\u0011%JE$\u0014Z4y";
      L[74] = "RXglT!'xlcEnFvghA42";
      L[75] = "\u001e\u00175r\u0013Ek7>}\u0002\n\n95v\u0006P~";
      L[76] = "RSYw\u0000\u0019'sRx\u0011VF}Ys\u0015\f2";
      L[77] = "s}Qm\u0007!muK\"|\u0001PX";
      L[78] = "~~s\u000b\t\u0016h~vQ\u001a\u0001\u007f5uW\u0016\u0015nrb@]\u0007|";
      L[79] = "+\u0005<caj^%7lp%?+<gt\u007fK";
      L[80] = "{3Q,5=m3Tv&*zxWp*>k?@ga+P";
      L[81] = "b\\\u001f:\u000bb|T\u0005ui~{I";
      L[82] = "\u001aQ\"udM\u0004Y8:\tW\u001d@5f+L\u001fB";
      L[83] = "L\\SkI\u000bL\\D7E\u0004V\u0017D)E\u0011Qf\u0016w\u001dU";
      L[84] = "\u007fv\u001bR,Qty\n\u001dKSar\nVp";
      L[85] = "UP!\u001aylUP6FucO\u001b6XuvHjg\u0001\"4";
      L[86] = "\u000f%(dp\u000fz\u0005#ka@\u001b\u000b(`e\u001ao";
      L[87] = "\u0010/zk9J\u000e'`$qJ\u0014-xcxQT\u001acNxJ\u0018\"iLbQ\u0019:eey";
      L[88] = "=8\\9\u001b\u0003H\u0018W6\nL)\u0016\\=\u000e\u0016]";
      L[89] = "\u001axCZ\u0006\u0001oXHU\u0017N\u000eVC^\u0013\u0014z";
      L[90] = "|'<\u0010\u0000\b\t\u00077\u001f\u0011Gh\t<\u0014\u0015\u001d\u001c";
      L[91] = "Qq\u0005m)^Gq\u00007:IP:\u000316]A}\u0014&}J}";
      L[92] = " D+3m\u0003Ud <|L4j+7x\u0016@";
      L[93] = "\u0015k\f?ey`K\u00070t6\u0001E\f;plu";
      L[94] = "xr8\u0017\u0005\u0003nr=M\u0016\u0014y9>K\u001a\u0000h~)\\Q\u0017V";
      L[95] = "\\P]\tz?)pV\u0006kpH~]\ro*<";
      L[96] = "V\f]xa\u0004@\fX\"r\u0013WG[$~\u0007F\u0000L35\u0010\u007f";
      L[97] = "U\u0003\u007f\u007f\u000eT #tp\u001f\u001bA-\u007f{\u001bA5";
      L[98] = "T$RD\\`Q0JF\f\u0006&H\u000eF_>\u001cr\u000f\t\nl\u0000H\u000bG\th\u00066Y\u0004\\}m";
      L[99] = "\u001b0O|\\,Zn\u0002-%*djS:X:\u0001*H.B9";
      L[100] = "haG\u00171=/r\u0003\u0017Cfxp\u001a\u0012/T)1BOC9epG\r|=%`\bu";
      L[101] = "e!\bp^o~6[$2je'\u001c#T}D<\u0003#w`|9\u000752\u007f~`\n.L1h3\u001eN";
      L[102] = "zk/M\u0004x\u007f95Ngqhy\bQ\u0016\u001egl,N\u0016l>{/\u0004g";
      L[103] = ">\fV\u001aLO?\u001bZ\u001a\u001c#nv\u000e\b\u001e\u001bvL\u000fGKIjv\u000e\f\u0013O9\u001a\u000f\u001b\u001fOiv";
      L[104] = "\u001a<ns~E[b#\"\u0007Ie/~-zS\n`r$d";
      L[105] = "/iPZmr,)\\P\u000ee?=[\\Y2am\u00020|1>;A\u0000a6$.";
      L[106] = "\u0003[\u00146\u0004KX\\\u001bt\u0014.A_\u000er\u007f\u0017^Q\u000f7OW\u0001B\u0018i\u007f\u0012E\u0002\u001ae\u0001@\u0006W\u000f\u000e";
      L[107] = "^tg\u00026t\b\u007fs\u0011\u000f33&h\u00107=\t''Ee!3#iFa'Mq*\u0013tL";
      L[108] = "\u0011?/d\f.K$!&@OAC) \u0012wYy(oG%EC)\"AuZ\"s9O7\u0016C";
      L[109] = "D\u000382\u000bV\u0003\u0006{~\t5\u0014;;1\u001f\r\f\u0001:~J_\u0010;;v\u001cJ\u001eCh#\nV\u0007;";
      L[110] = "\u0010jed\u0005K\u0012ik&\u0004sFa}\u0006\b\tHjn]\u0015\u001d\u00166j'O\fNf\u0001";
      L[111] = "c}~cKud h{J\u0019?,pxNu\r{7 \u0018\"Zx2\"E(6&ahW\u007fZqa!Ru?!`fE\u0019";
      L[112] = "\u001a\u0000wn\u001auJ\u0004q\u0004\u001dHC\u0014t<\brB[!n\u0014HF\u0015\"j\u00126\u0014Vw\u007fy";
      L[113] = "GE\u000b^%z\u0002\u0002\u0001\t^l\u0016\u0003a]2\u0003A\u000fG\r&<EOWB^";
      L[114] = "3{^2\f=*wSpg8T%Kc_3n$\u00046\r/T J5\t)*r\t`\u001cB";
      L[115] = "^2c?yZ\f`nu{#\u00025r-eO0a>q?\u001dgam-:X\u0002:j\"xHg";
      L[116] = "\f@,\u001dWgVQtM<p\u0014SzCG\u001d\u000fGtUMoVPw\u001f<-\u0000\u0017hKY}\u0001P\u007f'";
      L[117] = "\u0015*VS\u0007;E.P9\u0007\u0006L>U\u0001\u0015<Mq\u0000S\t\u0006I?\u0003W\u000fx\u001b|VBd";
      L[118] = "\u0017[h\u0019JYG_nsOdNOkKX^O\u0000>\u0019DdKN=\u001dB\u001a\u0019\rh\b)";
      L[119] = "t^?ORZ?\u0018nLE=,\u001d;K^A*\u001bV\b\rR=\u0018/TMT)\nV";
      L[120] = "6\u0013\u001eW-$?B\u001cY8JjB\u000e]!&X\u0011J\u0003}J5\u0015O\u0003y5sB\u001dOF";
      L[121] = "y:^i\u00100)>X\u0003\n\r .];\u00027!a\bi\u001e\r%/\u000bm\u0018swl^xs";
      L[122] = "OZsJF-F\u000bqDSC\u0013\u000bc@J/![/\u001a\u001cCOX%L\u001c/\u0011\u000bo^KC";
      L[123] = "b'#JQ1{|'J*:\t#`O\u0012&3\"/\u001a@:\t&a\u0019D<wt\"LQW";
      L[124] = "\u001e&rl\u0012rH-f\u007f+!st}~\u0013;Iu2+A'sw9/\u0015u\f1n}YJ";
      L[125] = "zj.5vW*n(_oj#~-gdP\"1x5xj&\u007f{1~\u0014t<.$\u0015";
      L[126] = "\rW\u0012%k@H\u0010\u0018r\u0010V\\\u0011m1}TWm\u0018;l\u0004IR\u001c{|K1";
      L[127] = "\tw^v04YsX\u001c(\tPc]$\"3Q,\bv>\tUb\u000br8w\u0007!^gS";
      L[128] = "Sz^nZe\t.\u0015 ;h\u0019lncV<\u0017v\u0004&\u0001\u007fT\u0014\u0012r\u0002{\u000b~W%A8i";
      L[129] = "O8Qe#w^9]gQ\"!yFrl1\u001e}\u0006b#I";
      L[130] = "Zw.\u001d\u00076\u0005w3\u001ai,Yl%J\u0000 `b%Z\u0004F\u000efx\\\u0005#^g?Ki";
      L[131] = "P\u007fE\b\u000bx\u001bfJ\n_\u0015\u0007wY\u0001\u0002BP-\t]ni\u0004/J\u0007\u0004,Sl\t";
      L[132] = "V-bGymUmnM\u001azFyiAM-\u0018.1-#/@z5K+pBho";
      L[133] = "w\u0018\u0005[vA+X\u0003Od8.K\u0011mbH2\"ZF6C\"G\nGqTN";
      L[134] = "=Hdk&\u001b8\\|iv}{$8i%Eu\u001e9&p\u0017i$=hs\u0013oZo+&\u0006\u0004";
      L[135] = "D;2pp\u0007\u0014?4\u001at:\u001d/1\"b\u0000\u001c`dp~:\u0018.gtxDJm2a\u0013";
      L[136] = "\u0014\nw\u001dA\rN^<S \bG\u0014GV\u001aP\u0010[8\u0010M\u0002\\d}V\u001dS\u0011\u001b;\u0001O\u001f.^}Q\u001eRQ\u0018*\u0003Rm";
      L[137] = "b\u0010_|\u0011\n2\u0014Y\u0016\u00197;\u0004\\.\u0003\r:K\t|\u001f78\nL+\n\b<J\\dr";
      L[138] = "C{\u001aS~\n\fw\u0013M\u000f\f3/\u0004B7\u0014\t.K\u0017e\b3{\u0011_q\\\u000b-\u001aKbe";
      L[139] = "k4\u001b1c7;0\u001d[i\n2 \u0018cq03oM1m\n7dD5{sr#Nb\u0000";
      L[140] = "\fK\u0016O1G\\O\u0010%7zU_\u0015\u001d#@T\u0010@O?zP^CK9\u0004\u0002\u001d\u0016^R";
      L[141] = "=\b6$\u001cQ$\u0004;fwGZV#uO_`Wl \u001dCZV4h\u001aK7\u001d-g\u0018\u001fZ";
      L[142] = "x&nP\u0002Ca*c\u0012iV\u001fx{\u0001QM%y4T\u0003Q\u001fxl\u001c\u0004Yr3u\u0013\u0006\r\u001f";
      L[143] = "i\u0003JJ<\bhT^\u0012?f93\u0016\bh^!\t\u0017G=\f=3\u0016FaZh]\u0017\u0011u\u0002k3";
      L[144] = "m[%Y\u0006S6\\*\u001b\u00166=T)a\u001f_3J4\u0013FH0\u0000EQ\u0010\u000f/T \u0001\u0011H88";
      L[145] = "\"\u001b\">\u00111y\u001c-|\u0001T`\u00190kjnk\u0004\u007f~Uj+\u00140\u0006";
      L[146] = "4\rgjoh/\f8f\u0003;6\u0017o+]<6\rkW9ooN9(\u007f8=\u0002\u0006";
      L[147] = "1KaW,l4\u0019{TOe#Y[O+w#%gO(x?W>X+2N";
      L[148] = "\u0015}J\u001fL=EyLuF\u0000LiIM^:M&\u001c\u001fB\u0000L|D\t]pI+F\u001eW\u0000";
      L[149] = "=\u000b\fM\r{yMP\u0011\u000bKoT\u0001\u001fJK8OV\u0018[5j\f\u0003\r0";
      L[150] = "\u0002T\u0002QU\u000eRP\u0004;]3[@\u0001\u0003G\tZ\u000fTQ[3X\u0004P\u0005\tL\u001eS\u0002I6";
      L[151] = "i\t}\u0006\u0012`d\u000e+\f(j\u0000]2\u001b\u0010p:\\}NBl\u0000X3MFj~\np\u0018S\u0001";
      L[152] = "K\u007fyi{`\u001b{\u007f\u0003d]\u0012kz;ig\u0013$/iu]\u0017j,ms#E)yx\u0018";
      L[153] = "Omec)G\u000b+9?/w\u000e+yXv\u001e\u0011$t*/\t\u0012n\u0005:}\u0010\u0004'wcj\u0013NVg1s\u0005\u0007$>&pOv";
      L[154] = "WJ5\u0016#o\u0017Q!\f \n\u0007+t\u0015>2\u001f\u0011uZk`\u0003+}\u0006kq\u0002N-\u0007,fn";
      L[155] = "@&\u0005\\\u007fS\u0005a\u000f\u000b\u0004E\u0011`|V|J\u0015\u001c\u000fBx\u0017\u0004#\u000b\u0002hX|";
      L[156] = "\u0018,\b5\u0017\u0018B=Pe|\u0002\u00109WD\u001b\u000e\u0014B\r\u007f\u0000_\u0001}\t?\u0010\u0010y";
      L[157] = "f(V+)u'v\u001bzP}\u0019rIu+()+\u0015mn+";
      L[158] = "=\u0005B\u0011$\u001em\u0001D{,#d\u0011AC6\u0019e^\u0014\u0011*#aU\u001d\u0015<Z$\u0012\u0017BG";
      L[159] = "#h\b\bs]\u007fg\u000eP1!s\u0005LN\"\u0019k?M\u0001wKw\u0005L\f<ZxiKQ*By\u0005";
      L[160] = "H\u0018ELW4\u0012L\u000e\u000261\u0013\u0010u\u0007\fiLI\nA[;\u0000vO\u0007\u000bjM\t\tPY&rLO\u0000\bk\r\n\u0018RDT";
      L[161] = "y&y<6t)\"\u007fV?I 2zn$s!}/<8I#v+hj6e!y$U";
      L[162] = "D\u0005r@Sn\u001f\u0002}\u0002C\u000b\u001c\u001a\u007f\u0002Aw\u001a\u001c\u0012A\u0012d\r\u001fk\u001dRb\u0019\r\u0012";
      L[163] = "YVKiFg\tRM\u0003IZ\u0000BH;T`\u0001\r\u001diHZ\u0003\u0006\u0019=\u001a%EQKq%";
      L[164] = "u\u0015?6)\n#\f?r#g-\u0016$\u0014z\u00031\u001dXpc\u001bq\bgt#\u000b>p";
      L[165] = "GdM\"\r8\u001b$K6\u001fA\u00183R.t#\u00179P#\u0006z\u0000:\u001aR";
      L[166] = "xGMZ\u001ca(CK0\u0016\\!SN\b\u000ef \u001c\u001bZ\u0012\\\"]^\r\u0007c&\u001dNB\u007f";
      L[167] = "\u0012pHZ\u0004\nBtN0\u00057KdK\b\u0016\rJ+\u001eZ\n7Ne\u001d^\fI\u001c&HKg";
      L[168] = "\t.-6Pi\u0001(4h\u0017YYSrs\u0001aAis<T3]Srp\u000bb\rczv\u0012<JS";
      L[169] = "\u001at\u001b\u001e\u0015B\u0013%\u0019\u0010\u0000,F%\u000b\u0014\u0019@tvOOD,\u0019rJJAS_%\u0018\u0006~";
      L[170] = "\u0004\u0006'p\u0001UT\u0002!\u001a\u000bhU\u001c5cX\u000f\bU1jbY\u0014\u00111 \u0005\u0004]\u00158\u001a";
      L[171] = "fB$zqs0I0iH\"\u000b\u0010+hp:1\u0011d=\"&\u000b\u0013o9vttU8k:K";
      L[172] = "3IKb?\u0007o\tMv-~p\u001eAu8\u0013\nO[((\u0015t\u001d\u0018}=~";
      L[173] = "y\u001fKt\u0013l#K\u0000:re)\n{?H1}N\u0004y\u001fc1qA?O2|\u000e\u0007h\u001d~C";
      L[174] = "\u0017<i[\u007f\u0004\u0014|eQ\u001c\u0018\u000byfVp*\\?8\u0001'}\u001bh;SnC\\{\u007fS\u001c";
      L[175] = "4-\u001ex5\u0011\u007f4\u0011za|c%\u0002q<+4\u007fR/P\u0000`}\u0011w:E7>R";
      L[176] = "H\u0007ONf<\u0003\u001e@L2Q\u001f\u000fSGo\u0006HU\u0003\u001a\u0003-\u001cW@AihK\u0014\u0003";
      L[177] = "EU\u000eS+\u0016\u001f\u0001E\u001dJ\f\u0018FXNJLE\u0006\u0000\u001d5\n\u0012TL\"p\u0006\u0003\u0006F\u001dtF\u0013I>";
      L[178] = "f0\u000e\b/Ioa\f\u0006:':a\u001e\u0002#K\b5]\\t\u001e_6X_z\u0018 p\u000f\r6'";
      L[179] = "n{B9[J7'Z|Xz>\u0019\u001b<\rB&#\u001asX\u0010:\u0019\u0012/X\u0001;|B.\u001f\u0016W";
      L[180] = "uD\u0014q\u00019v\u0004\u0018{b.e\u0010\u001fw5y:MD\u001b[*i\u000f\u0000b\txdE\u0002";
      L[181] = ".t\u0002wO?us\r5_Zxz\u001eO\u000e*k*\u001ap\nj{eb-]=ef\u0010tJ>/\u0017";
      L[182] = "\"JP\u00110LrNV{+q{^SC\"Kz\u0011\u0006\u0011>q~_\u0005\u00158\u000f,\u001cP\u0000S";
      L[183] = " GeDp#pCc.y\u001eySf\u0016b$x\u001c3D~\u001e|\u0017:@hg9P0\u0017\u0013";
      L[184] = "\u0011\u0013~\u0016\u001ezQLm\u0001@JC\u0010r\u0015N0I\u0011x!@7B\u0013zm\u001e-S\u0006u\u000eJ*YL*m\u001e.A\f.]^qR\u001bpm";
      L[185] = "am\u000e#'~h<\f-2\u0010=<\u001e)+|\u000fl\\ws\u0010a1\u001dtw|!5\u001e31\u0010";
      L[186] = "\u001bR\u001cV# \u001cYJU['$\u0005XZc?\u001e\u0004\u0017\u000f1#$\fK\u000f \"A\\JH7N";
      L[187] = "1j+OBc k'M07_+<X\r%`/|HB]";
      L[188] = "5c@RYoo7\u000b\u001c8tnkp_U6qo\u001a\u001a\u0002u2\r\fN\u0001qmgI\u0019B2\u000f";
      L[189] = "\u000f+\u000f)|\u007f\u0006z\r'i\u0011Sz\u001f#p}a)[}(\u0011\f-^}(nJz\f1\u0017";
      L[190] = ":\u001bn^dy3JlPq\u0017fJ~Th{T\u001e=\n?-\u0003\u001d8\t1(|[o[}\u0017";
      L[191] = ")\u000bd+\u0014(6\u0006`/~~L\brq\ff>QerF\u0017";
      L[192] = "e,1\u007fV\u001cms3m\fz9z*q\t\u0016\u000b*i*_zes3qW\u0010`h: Vzf-k/Q\u0005 z9cn";
      L[193] = "c\u0000o'V\u0012'F3{P\"5Vs\u001c\tK=I~nP\\>\u0003\u000f~\u0002E(J}'\u0015Fb;";
      L[194] = "y?Av0\u0005pnCx%k%nQ|<\u0007\u00178\u0014 kR@3@% \u0007%cAb7k";
      L[195] = "\u0014\u001d*?p\u001bUCgn\t\u0010kGo;t\u0004\b\u0000jx8\u0006";
      L[196] = "!Z\u0019`mQ(\u000b\u001bnx?}\u000b\tjaSO[I59?!\u0000\u00113w\u0007#\u0003\u001fqv?";
      L[197] = "qfm~^p5 1\"X@%;q?\u0012\u001b%!\r|\\)68j7\u001ax5/\r";
      L[198] = "H5J\u000574\u001b`\\\u0019.L\u001b\f\u001c\u00048t\u00006\u001dKm&\u001c\f\u001cJ1pIb\u001d\u001d%(J\f";
      L[199] = "W\b6\u0000\u0007K\u0012O<W|]\u0006NL\n\u0001_k\bv\u0012AJT\f6\u0002\u000e2";
      L[200] = "\neV\u0002h\u0013\u00034T\f}}V4F\bd\u0011dd\u0005V<}\u00034\u0003\u0013o\u0018S5D\u0004\u0003";
      L[201] = ":g|_7g`v$\u000f\\c2m>\b\u001bs[33\u0019aed7s\t.\u001d:g|_7g`v$\u000f\\";
      L[202] = "6\"H!al`)\\2X*[pG3`%aq\bf29[uFe6?%'\u00050#T";
      L[203] = ":\u0014xAyc#\u0018u\u0003\u0012z]Jm\u0010*mgK\"Exq]OlF|w#\u001d/\u0013i\u001c";
      L[204] = "t\n{Oh33\u0019?O\u001ahd\u001b&JvZ5[v\u0013\u001a7y\u001b{U%39\u000b4-";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = L[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(M[var4]);
            L[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = L[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = M[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            L[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  L[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1959809317911972L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = L[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = M[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  L[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1959809317911972L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        L[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1959809317911972L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 195;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 165;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 163;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 253;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 192;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 117;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 195;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 165;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 163;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite h(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fE_C0279",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fE" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(TwoDESP var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$5", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding2(TwoDESP var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$9", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding3(TwoDESP var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$6", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding4(TwoDESP var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$3", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding5(TwoDESP var0) {
         MethodHandle var5 = bindingCache5;
         MethodHandle var4 = bindingCache5;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache5 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$4", "(Ljava/lang/String;)Z"),
                  SourceSupport.methodType("(Ljava/lang/String;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding6(TwoDESP var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding7(TwoDESP var0) {
         MethodHandle var5 = bindingCache7;
         MethodHandle var4 = bindingCache7;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$2", "(Ljava/lang/Boolean;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Boolean;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding8(TwoDESP var0) {
         MethodHandle var5 = bindingCache8;
         MethodHandle var4 = bindingCache8;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache8 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$7", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding9(TwoDESP var0) {
         MethodHandle var5 = bindingCache9;
         MethodHandle var4 = bindingCache9;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$8", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding10(TwoDESP var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$10", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Predicate invokeBinding11(TwoDESP var0) {
         MethodHandle var5 = bindingCache11;
         MethodHandle var4 = bindingCache11;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fE_C0279;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fE_C0279", "lambda$new$1", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Predicate)var2.invokeExact((TwoDESP)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static ToDoubleFunction invokeBinding12() {
         MethodHandle var4 = bindingCache12;
         MethodHandle var3 = bindingCache12;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "applyAsDouble",
                  SourceSupport.methodType("()Ljava/util/function/ToDoubleFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)D", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fE_C0279", "lambda$onTick$11", "(Ldev/zprestige/prestige/f2;)D"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/f2;)D", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ToDoubleFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
