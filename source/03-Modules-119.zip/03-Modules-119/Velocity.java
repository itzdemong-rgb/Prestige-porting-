package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.api.events.VelocityEvent;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.util.math.Vec3d;

public class Velocity extends Module {
   private FloatSetting a;
   private BooleanSetting d;
   private MinMaxSetting c;
   private MinMaxSetting e;
   private ArrayList f = new ArrayList();
   private static final long k = 37387524113118L;
   private static final Object[] l = new Object[62];
   private static final String[] m = new String[62];
   private static volatile MethodHandle bindingCache1;

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(TickEvent var1) {
      ArrayList var10000 = new ArrayList(this.f);
      Consumer var5 = invokeBinding1(this);
      ArrayList var4 = var10000;
      var4.forEach(var5);
   }

   @EventListener
   public void a(VelocityEvent var1) {
      float var47;
      float var48;
      label34: {
         int var46;
         long var10001 = 11790380828105L ^ 13649510735160L;
         int var6 = Event.cReturningInt();
         ArrayList var9 = this.f;
         byte var10000 = ((byte)((var9.isEmpty()) ? 1 : 0));
         int var50 = var6;
         byte var49 = var10000;
         var46 = var49;
         byte var39 = var49;
         label30:
         if (var50 != 0) {
            byte var51 = var39;
            if (var51 == 0) {
               BooleanSetting var11 = this.d;
               Boolean var12 = (Boolean)var11.aReturningObject();
               var10000 = ((byte)(((java.lang.Boolean)(var12)).booleanValue() ? 1 : 0));
               int var53 = var6;
               byte var52 = var10000;
               var46 = var52;
               byte var40 = var52;
               if (var53 == 0) {
                  break label30;
               }

               byte var54 = var40;
               byte var41 = var54;
               byte var55 = var41;
               if (var55 != 0) {
                  return;
               }
            }

            Random var15 = RandomUtil.a;
            float var66 = var15.nextFloat() * 100.0F;
            FloatSetting var16 = this.a;
            Float var17 = (Float)var16.aReturningObject();
            float var70 = var17;
            int var58 = var6;
            float var57 = var70;
            float var56 = var66;
            var47 = var56;
            var48 = var57;
            float var42 = var56;
            float var43 = var57;
            if (var58 == 0) {
               break label34;
            }

            float var60 = var43;
            float var59 = var42;
            float var44 = var59;
            float var45 = var60;
            float var71;
            int var61 = (var71 = var44 - var45) == 0.0F ? 0 : (var71 < 0.0F ? -1 : 1);
            var46 = var61;
         }

         int var62 = var46;
         if (var62 > 0) {
            return;
         }

         MinMaxSetting var67 = this.c;
         Object[] var21 = new Object[]{7504101316849L};
         MinMaxSetting var20 = var67;
         float var68 = var20.fReturningFloat(var21);
         float var64 = 100.0F;
         float var63 = var68;
         var47 = var63;
         var48 = var64;
      }

      float var7 = var47 / var48;
      MinMaxSetting var69 = this.e;
      Object[] var24 = new Object[]{7504101316849L};
      MinMaxSetting var23 = var69;
      float var8 = var23.fReturningFloat(var24) / 100.0F;
      Object[] var26 = new Object[0];
      VelocityEvent var25 = var1;
      Object[] var28 = new Object[]{var25.aReturningDouble(var26) * var8};
      VelocityEvent var27 = var1;
      var27.bReturningVoid(var28);
      Object[] var30 = new Object[0];
      VelocityEvent var29 = var1;
      Object[] var32 = new Object[]{var29.bReturningDouble(var30) * var7};
      VelocityEvent var31 = var1;
      var31.cReturningVoid(var32);
      Object[] var34 = new Object[0];
      VelocityEvent var33 = var1;
      Object[] var36 = new Object[]{var33.cReturningDouble(var34) * var8};
      VelocityEvent var35 = var1;
      var35.dReturningVoid(var36);
      Object[] var38 = new Object[0];
      VelocityEvent var37 = var1;
      var37.aReturningVoid(var38);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var10000 = Event.bReturningInt();
      Object[] var8 = new Object[0];
      PacketReceiveEvent var7 = var1;
      Packet var6 = var7.aReturningVoid(var8);
      int var4 = var10000;
      int var28 = var4;
      Packet var27 = var6;
      Packet var22 = var27;
      Packet var21 = var27;
      if (var28 == 0) {
         boolean var29 = var21 instanceof ExplosionS2CPacket;
         if (!var29) {
            return;
         }

         Packet var30 = var6;
         var22 = var30;
      }

      ExplosionS2CPacket var5 = (ExplosionS2CPacket)var22;
      ExplosionS2CPacket var11 = var5;
      Optional var12 = var11.playerKnockback();
      byte var39 = ((byte)((var12.isPresent()) ? 1 : 0));
      int var32 = var4;
      byte var31 = var39;
      int var24 = var31;
      byte var23 = var31;
      if (var32 == 0) {
         byte var33 = var23;
         if (var33 == 0) {
            return;
         }

         ExplosionS2CPacket var14 = var5;
         Optional var15 = var14.playerKnockback();
         Vec3d var16 = (Vec3d)var15.get();
         double var40;
         int var34 = (var40 = var16.lengthSquared() - 0.0) == 0.0 ? 0 : (var40 < 0.0 ? -1 : 1);
         var24 = var34;
      }

      int var36 = var4;
      int var35 = var24;
      int var25 = var35;
      if (var36 == 0) {
         int var37 = var25;
         if (var37 > 0) {
            ExplosionS2CPacket var20 = var5;
            ArrayList var19 = this.f;
            boolean var38 = var19.add(var20);
         }
      }
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      ArrayList var4 = this.f;
      var4.clear();
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      ArrayList var4 = this.f;
      var4.clear();
   }

   private void lambda$onTick$0(ExplosionS2CPacket var1) {
      int var4 = Event.bReturningInt();
      MinecraftClient var5 = b;
      int var18 = var4;
      ClientPlayerEntity var17 = var5.player;
      ClientPlayerEntity var14 = var17;
      ClientPlayerEntity var13 = var17;
      if (var18 == 0) {
         ClientPlayerEntity var19 = var13;
         if (var19 == null) {
            return;
         }

         MinecraftClient var7 = b;
         ClientPlayerEntity var20 = var7.player;
         var14 = var20;
      }

      ClientPlayerEntity var9 = var14;
      boolean var10000 = var9.isOnGround();
      int var22 = var4;
      boolean var21 = var10000;
      boolean var15 = var21;
      if (var22 == 0) {
         boolean var23 = var15;
         if (var23) {
            ExplosionS2CPacket var12 = var1;
            ArrayList var11 = this.f;
            boolean var24 = var11.remove(var12);
         }
      }
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 14;
            yield var15;
         }
         case 1 -> {
            byte var16 = 35;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 42;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 50;
            yield var21;
         }
         case 7 -> {
            byte var22 = 47;
            yield var22;
         }
         case 8 -> {
            byte var23 = 2;
            yield var23;
         }
         case 9 -> {
            byte var24 = 11;
            yield var24;
         }
         case 10 -> {
            byte var25 = 10;
            yield var25;
         }
         case 11 -> {
            byte var26 = 45;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 5;
            yield var29;
         }
         case 15 -> {
            byte var30 = 49;
            yield var30;
         }
         case 16 -> {
            byte var31 = 55;
            yield var31;
         }
         case 17 -> {
            byte var32 = 28;
            yield var32;
         }
         case 18 -> {
            byte var33 = 58;
            yield var33;
         }
         case 19 -> {
            byte var34 = 18;
            yield var34;
         }
         case 20 -> {
            byte var35 = 61;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 63;
            yield var37;
         }
         case 23 -> {
            byte var38 = 15;
            yield var38;
         }
         case 24 -> {
            byte var39 = 52;
            yield var39;
         }
         case 25 -> {
            byte var40 = 33;
            yield var40;
         }
         case 26 -> {
            byte var41 = 3;
            yield var41;
         }
         case 27 -> {
            byte var42 = 51;
            yield var42;
         }
         case 28 -> {
            byte var43 = 57;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 1;
            yield var45;
         }
         case 31 -> {
            byte var46 = 17;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 12;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 4;
            yield var50;
         }
         case 36 -> {
            byte var51 = 20;
            yield var51;
         }
         case 37 -> {
            byte var52 = 46;
            yield var52;
         }
         case 38 -> {
            byte var53 = 44;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 62;
            yield var55;
         }
         case 41 -> {
            byte var56 = 43;
            yield var56;
         }
         case 42 -> {
            byte var57 = 31;
            yield var57;
         }
         case 43 -> {
            byte var58 = 30;
            yield var58;
         }
         case 44 -> {
            byte var59 = 16;
            yield var59;
         }
         case 45 -> {
            byte var60 = 6;
            yield var60;
         }
         case 46 -> {
            byte var61 = 54;
            yield var61;
         }
         case 47 -> {
            byte var62 = 26;
            yield var62;
         }
         case 48 -> {
            byte var63 = 25;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 38;
            yield var65;
         }
         case 51 -> {
            byte var66 = 23;
            yield var66;
         }
         case 52 -> {
            byte var67 = 0;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 59;
            yield var69;
         }
         case 55 -> {
            byte var70 = 9;
            yield var70;
         }
         case 56 -> {
            byte var71 = 56;
            yield var71;
         }
         case 57 -> {
            byte var72 = 41;
            yield var72;
         }
         case 58 -> {
            byte var73 = 8;
            yield var73;
         }
         case 59 -> {
            byte var74 = 13;
            yield var74;
         }
         case 60 -> {
            byte var75 = 29;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 22;
            yield var77;
         }
         default -> 53;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = ".SPxWy0[J78~6S_U\u0010\u007f0";
      l[1] = "FPWd\u000fiM_F+ngFTBq";
      l[2] = boolean.class;
      m[2] = "java/lang/Boolean";
      l[3] = "a\u001aH\u001743w\u001aMM'$`QNK+0q\u0016Y\\`\"@";
      l[4] = int.class;
      m[4] = "java/lang/Integer";
      l[5] = "D\u0015\u0002k\u001d\u0000R\u0015\u00071\u000e\u0017E^\u00047\u0002\u0003T\u0019\u0013 I\u0016f";
      l[6] = "{qr^ITp~c\u0011*Yeslz\u001f[t`pV\bV";
      l[7] = "EL#Wn^EL4\u000bbQ_\u00074\u0015bDXv`M5";
      l[8] = "\u001d{\u0003oU`\u001d{\u00143Yo\u00070\u0014-Yz\u0000ADp\b";
      l[9] = "g{\u0005V{^q{\u0000\fhIf0\u0003\nd]ww\u0014\u001d/LJ";
      l[10] = "\u0018l/\r9\u0016mL$\u0002(Y\fB/\t,\u0003x";
      l[11] = double.class;
      m[11] = "java/lang/Double";
      l[12] = "\u00031\u0010}=\u0014\b>\u00012Q\u0017\u0006<\u0003}}";
      l[13] = "A\u0013/V4\u000eW\u0013*\f'\u0019@X)\n+\rQ\u001f>\u001d`\u001ac";
      l[14] = "\u0000|/[%\\u\\$T4\u0013\u0014R/_0I`";
      l[15] = "~)JT\u001am\u000b\tA[\u000b\"j\u0007JP\u000fx\u001e";
      l[16] = "m\u0014\u000e+\u0018\u0003\u00184\u0005$\tLy:\u000e/\r\u0016\r";
      l[17] = void.class;
      m[17] = "java/lang/Void";
      l[18] = "r\u0015\u000eAkby\u001a\u001f\u000e\u0003bw\u0015\f";
      l[19] = float.class;
      m[19] = "java/lang/Float";
      l[20] = "\u0016$~j7\"\u0000${0$5\u0017ox6(!\u0006(o!c6>";
      l[21] = "1W\u0018CeLDw\u0013Lt\u0003%y\u0018GpYQ";
      l[22] = "\u001ei5DUekI>KD*\nG5@@p~";
      l[23] = "R|>#tI'\\5,e\u0006FR>'a\\2";
      l[24] = "W_\u0011qs\"\"\u007f\u001a~bmCq\u0011uf77";
      l[25] = "=re\u001e\u007f`#z\u007fQ\u0003t9w|\u0012";
      l[26] = "W\\\u0012k\u001e\bIT\b$V\bS^\u0010c_\u0013\u0013~\u000bdC\bPX\u0016";
      l[27] = "\u0003H^\u001d%_\u001d@DRXO\u001d";
      l[28] = "\t@2\u0005FV\t@%YJY\u0013\u000b%GJL\u0014zt\u001f\u0018";
      l[29] = "\u001bQRyI#\u001bQE%E,\u0001\u001aE;E9\u0006k\u0014a\u0012~";
      l[30] = "+Q\u001d1X%5Y\u0007~9 5Y\u0004>\u0017<";
      l[31] = "``\u0016bXMv`\u00138KZa+\u0010>GNpl\u0007)\f_`";
      l[32] = "lA\u0003\u001fY&\u0019a\b\u0010Hixo\u0003\u001bL3\f";
      l[33] = "\u001d`=K\u001dM\u001d`*\u0017\u0011B\u0007+*\t\u0011W\u0000Z{PI\u0012";
      l[34] = "FgCm/a\u0017v@=Eo|?F>=>\u0000f\u0006+)\u0005";
      l[35] = "7!6F/\u0005r\u007f7\u0011EQ\t&>R>\u000343?\u001a,;9~)Ju\u0003d,8NE";
      l[36] = "\"h=gtP)sw5\u000f\u0006\u00196bwq\u0014h;~tpo%m\u007fst\u001e(q|r\u000f";
      l[37] = "@ZUmok@\rI/\u000fcLc\u0017mp?A\u001eE1om\"Z\u001e\"4g_\bB=f\u0004@ZUmok@\rI/\u000f";
      l[38] = "\f.\u0001\u0014+\u0016Yf\u0000_S\u0003[0\u001f\t:\u000fb>\u001f\u0019>i\u00058C\n(\u0003]8\u0000YS";
      l[39] = "?\u0010\u001dG\u0003<n\u0001\u001e\u0017i3\u0005H\u0018\u0014\u0011cy\u0011X\u0001\u0005X";
      l[40] = "b`d\u001aPenr?^lr2q;F\u0000@e1k\u001b\\\u0017fbcO\u0017}>b \u001cl";
      l[41] = "\u001b)RS\u0012\fG/\u0016\u0013m\u0014*|\u001eVV\u001eW.BI\u0004}";
      l[42] = "\u00145\u001eI+\u0006Qk\u001f\u001eAQ*2\u0016]:\u0000\u0017'\u0017\u0015(8\u001aj\u0001Eq\u0000G8\u0010AA";
      l[43] = "u.i\u0016%s0phAO&K)a\u00024uv<`J&M{qv\u001a\u007fu&#g\u001eO";
      l[44] = "i|GNPI>#IK-]5s@Iz\nk$\u0018%\u0010^k%\u0018W\u001cL0a";
      l[45] = "np\u001fjh4?a\u001c:\u00029TvM'yhicLokP?(X0c;lhM+\u0002";
      l[46] = "?\u001fP6QrzAQa; \u0001\u0018X\"@t<\rYjRLjFM5Z'9\u0006X.;";
      l[47] = "{<\u000fzk?!s\u0014;\u000b:t1\u0014&g\b uN~\u000bo$7\u001eq32v&\u001aA";
      l[48] = "\u000f-,lw\u0015\u000f5}\t3\n\r62dI^X.wj4\f\u00041%\tp\bP?7c(\b\u0013lL";
      l[49] = "\u001a%1\u001fOm\u000282\u000b/7\u001e956\u0015lI`M\u0002_ \t82\u0019U\"I\\";
      l[50] = "\u0005a4\u0016B\u0001\u0005yes\u0015\u001f\u000e\u001dmC\u0003H\u0001`?\u001f\u001c\u001ab$;K\u0012\b\b|;\bAs";
      l[51] = "cCB3~VxI@s\u001aH{kD.aDfO>zu\u0011nHT\"uR=3";
      l[52] = "%\u001b}6}4`E|a\u0017`\u001b\u001cu\"l2&\ttj~\npB`5va#\u0002u.\u0017";
      l[53] = "\u0012^HP\\\b\u0012F\u00195\f\u001d\u000foA^\u0002z\u0014DRN\t\u001c\u0017\u001b\u0012Ob\u0011NZMT\tB\u000eOV5";
      l[54] = "\"<sN\u000b\u0010-!g\u00116\u0007-;d\fh\u0000-!`pZ\u0014020\u0013W\u001763\r";
      l[55] = "|2g[+F|*6>~Pv'}>~\u000fc+fU-Ov0\u0007";
      l[56] = "7EF\u0001?l4\u0014A\u001aCmZKF\n8;g^GB*\u00036SR\u0016~`;PT\u0017C";
      l[57] = "\u0017HGKo\u0003\u0017P\u0016.0\n=Q_R qI[\u001f@*\u001b\u0011[\\\u0013Q";
      l[58] = "t\u001eQaE\u001d-\u0019@b}\u0010\u0011FW.\u0006A,SVf\u0014ytRFl\u0012\u0018w\u001c\u00035}";
      l[59] = "wu6t\u0005G2+7#o\u0012Ir>`\u0014Atg?(\u0006y\",+w\u000e\u0012ql>lo";
      l[60] = "\u00023\t$$i\u00199\u000bd@y\f?umpiZ \b?,v\bC";
      l[61] = "\u0011N6LW \r\u0002mS7#\u001cO*dS\"\u0018CVFJ<\u001f\u00025KI:\u001e?";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(126644279815486L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(126644279815486L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(126644279815486L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 170;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 243;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 226;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 201;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 254;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 223;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 170;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 243;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 226;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fF_C0281",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fF" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Consumer invokeBinding1(Velocity var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fF_C0281;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/fF_C0281",
                     "lambda$onTick$0",
                     "(Lnet/minecraft/network/packet/s2c/play/ExplosionS2CPacket;)V"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/network/packet/s2c/play/ExplosionS2CPacket;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((Velocity)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
