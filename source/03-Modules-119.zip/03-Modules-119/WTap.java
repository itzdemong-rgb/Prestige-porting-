package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.AttackEntityEvent;
import dev.zprestige.prestige.api.events.Render2DEvent;
import dev.zprestige.prestige.api.util.RandomUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Random;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.Window;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

public class WTap extends Module {
   private FloatSetting a;
   private MinMaxSetting c;
   private MinMaxSetting d;
   private ElapsedTimer e;
   private ElapsedTimer f;
   private boolean i;
   private boolean g;
   private static final long k = 87075382273767L;
   private static final long l;
   private static final Object[] m = new Object[48];
   private static final String[] n = new String[48];

   public WTap() {
      super();
      long var10001 = 93118429510673L ^ 59074276592440L;

      this.e = new ElapsedTimer(106698256430889L);
      this.f = new ElapsedTimer(106698256430889L);
      this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var5 = CombatProfile.UHC;
      CombatProfile var4 = CombatProfile.Sword;
      return Set.of(var4, var5);
   }

   @EventListener
   public void a(AttackEntityEvent var1) {
      long var10001 = 76274459016110L ^ 60011451712993L;
      var10001 = 76274459016110L ^ 109583350469550L;
      int var8 = Event.cReturningInt();
      int var43 = var8;
      boolean var42 = this.i;
      boolean var33 = var42;
      boolean var32 = var42;
      if (var43 != 0) {
         boolean var44 = var32;
         if (var44) {
            return;
         }

         boolean var45 = this.g;
         var33 = var45;
      }

      boolean var46 = var33;
      if (!var46) {
         Object[] var13 = new Object[0];
         AttackEntityEvent var12 = var1;
         Entity var9 = var12.aReturningEntity(var13);
         int var48 = var8;
         Entity var47 = var9;
         Entity var35 = var47;
         Entity var34 = var47;
         if (var48 != 0) {
            Entity var49 = var34;
            if (var49 == null) {
               return;
            }

            var35 = var9;
         }

         byte var10000 = ((byte)((var35 instanceof PlayerEntity) ? 1 : 0));
         int var51 = var8;
         byte var50 = var10000;
         byte var37 = var50;
         byte var36 = var50;
         if (var51 != 0) {
            byte var52 = var36;
            if (var52 == 0) {
               return;
            }

            MinecraftClient var16 = b;
            GameOptions var17 = var16.options;
            KeyBinding var18 = var17.forwardKey;
            var37 = ((byte)((var18.isPressed()) ? 1 : 0));
         }

         int var54 = var8;
         byte var53 = var37;
         byte var39 = var53;
         byte var38 = var53;
         if (var54 != 0) {
            byte var55 = var38;
            if (var55 == 0) {
               return;
            }

            MinecraftClient var20 = b;
            ClientPlayerEntity var21 = var20.player;
            byte var56 = ((byte)((var21.isSprinting()) ? 1 : 0));
            var39 = var56;
         }

         int var58 = var8;
         byte var57 = var39;
         int var41 = var57;
         byte var40 = var57;
         if (var58 != 0) {
            byte var59 = var40;
            if (var59 == 0) {
               return;
            }

            Random var24 = RandomUtil.a;
            float var62 = var24.nextFloat() * 100.0F;
            FloatSetting var25 = this.a;
            Float var26 = (Float)var25.aReturningObject();
            float var66;
            int var60 = (var66 = var62 - var26) == 0.0F ? 0 : (var66 < 0.0F ? -1 : 1);
            var41 = var60;
         }

         int var61 = var41;
         if (var61 <= 0) {
            MinMaxSetting var63 = this.d;
            Object[] var29 = new Object[]{127318019014223L};
            MinMaxSetting var28 = var63;
            var28.bReturningVoid(var29);
            ElapsedTimer var64 = this.e;
            Object[] var31 = new Object[]{42835128969216L};
            ElapsedTimer var30 = var64;
            var30.aReturningVoid(var31);
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(1);
         }
      }
   }

   @EventListener
   public void a(Render2DEvent var1) {
      long var10001 = 112527352137044L ^ 23761261820699L;
      var10001 = 112527352137044L ^ 27305789150016L;
      var10001 = 112527352137044L ^ 71066751823188L;
      int var10 = Event.cReturningInt();
      MinecraftClient var11 = b;
      Window var12 = var11.getWindow();
      long var10000 = var12.getHandle();
      int var15 = (int)l;
      long var13 = var10000;
      int var79 = GLFW.glfwGetKey(var13, var15);
      int var59 = var10;
      int var58 = var79;
      int var48 = var58;
      int var47 = var58;
      if (var59 != 0) {
         byte var61 = 1;
         int var60 = var47;
         if (var60 != var61) {
            this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
            return;
         }

         var48 = (((this.i) ? 1 : 0));
      }

      int var52;
      int var63 = var10;
      int var62 = var48;
      var52 = var62;
      int var49 = var62;
      label53:
      if (var63 != 0) {
         int var64 = var49;
         if (var64 != 0) {
            ElapsedTimer var80 = this.e;
            MinMaxSetting var19 = this.d;
            Float var20 = (Float)var19.aReturningObject();
            float var87 = var20;
            Object[] var10004 = new Object[]{null, 139098136696340L};
            var10004[0] = var87;
            Object[] var22 = var10004;
            ElapsedTimer var21 = var80;
            byte var81 = ((byte)((var21.aReturningBoolean(var22)) ? 1 : 0));
            int var66 = var10;
            byte var65 = var81;
            var52 = var65;
            byte var50 = var65;
            if (var66 == 0) {
               break label53;
            }

            byte var67 = var50;
            byte var51 = var67;
            byte var68 = var51;
            if (var68 != 0) {
               MinecraftClient var25 = b;
               GameOptions var26 = var25.options;
               KeyBinding var27 = var26.forwardKey;
               var27.setPressed(false);
               ElapsedTimer var82 = this.f;
               Object[] var30 = new Object[]{42835128969216L};
               ElapsedTimer var29 = var82;
               var29.aReturningVoid(var30);
               MinMaxSetting var83 = this.c;
               Object[] var32 = new Object[]{127318019014223L};
               MinMaxSetting var31 = var83;
               var31.bReturningVoid(var32);
               this.g = dev.prestige.recovery.SourceSupport.asBoolean(1);
               this.i = dev.prestige.recovery.SourceSupport.asBoolean(0);
            }
         }

         var52 = (((this.g) ? 1 : 0));
      }

      int var70 = var10;
      int var69 = var52;
      int var54 = var69;
      int var53 = var69;
      if (var70 != 0) {
         int var71 = var53;
         if (var71 == 0) {
            return;
         }

         ElapsedTimer var84 = this.f;
         MinMaxSetting var35 = this.c;
         Float var36 = (Float)var35.aReturningObject();
         float var88 = var36;
         Object[] var89 = new Object[]{null, 139098136696340L};
         var89[0] = var88;
         Object[] var38 = var89;
         ElapsedTimer var37 = var84;
         byte var72 = ((byte)((var37.aReturningBoolean(var38)) ? 1 : 0));
         var54 = var72;
      }

      int var73 = var54;
      if (var73 != 0) {
         label39: {
            int var75 = var10;
            MinecraftClient var74 = b;
            MinecraftClient var57 = var74;
            MinecraftClient var55 = var74;
            if (var75 != 0) {
               MinecraftClient var76 = var55;
               MinecraftClient var56 = var76;
               MinecraftClient var41 = var56;
               Screen var77 = var41.currentScreen;
               if (var77 != null) {
                  break label39;
               }

               MinecraftClient var78 = b;
               var57 = var78;
            }

            MinecraftClient var44 = var57;
            GameOptions var45 = var44.options;
            KeyBinding var46 = var45.forwardKey;
            var46.setPressed(true);
         }

         this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
      }
   }

   public boolean dReturningBoolean(Object[] var1) {
      return this.i;
   }

   public boolean eReturningBoolean(Object[] var1) {
      return this.g;
   }

   static {

      f();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(108709824193078L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long var10001 = -2098115183886652991L;
      byte[] var6 = var2.doFinal(
         new byte[]{
            (byte)226L,
            (byte)58081L,
            (byte)14868991L,
            (byte)3806461787L,
            (byte)974454217542L,
            (byte)249460279690901L,
            (byte)63861831600870697L,
            (byte)-2098115183886652991L
         }
      );
      long var8 = (var6[0] & 255L) << 56
         | (var6[1] & 255L) << 48
         | (var6[2] & 255L) << 40
         | (var6[3] & 255L) << 32
         | (var6[4] & 255L) << 24
         | (var6[5] & 255L) << 16
         | (var6[6] & 255L) << 8
         | var6[7] & 255L;
      // l = var8;
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 59;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 5;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 58;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 56;
            yield var22;
         }
         case 8 -> {
            byte var23 = 55;
            yield var23;
         }
         case 9 -> {
            byte var24 = 4;
            yield var24;
         }
         case 10 -> {
            byte var25 = 53;
            yield var25;
         }
         case 11 -> {
            byte var26 = 20;
            yield var26;
         }
         case 12 -> {
            byte var27 = 44;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 3;
            yield var29;
         }
         case 15 -> {
            byte var30 = 21;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 61;
            yield var34;
         }
         case 20 -> {
            byte var35 = 16;
            yield var35;
         }
         case 21 -> {
            byte var36 = 1;
            yield var36;
         }
         case 22 -> {
            byte var37 = 32;
            yield var37;
         }
         case 23 -> {
            byte var38 = 26;
            yield var38;
         }
         case 24 -> {
            byte var39 = 54;
            yield var39;
         }
         case 25 -> {
            byte var40 = 17;
            yield var40;
         }
         case 26 -> {
            byte var41 = 22;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 33;
            yield var43;
         }
         case 29 -> {
            byte var44 = 36;
            yield var44;
         }
         case 30 -> {
            byte var45 = 27;
            yield var45;
         }
         case 31 -> {
            byte var46 = 7;
            yield var46;
         }
         case 32 -> {
            byte var47 = 8;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 24;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 40;
            yield var51;
         }
         case 37 -> {
            byte var52 = 31;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 49;
            yield var54;
         }
         case 40 -> {
            byte var55 = 60;
            yield var55;
         }
         case 41 -> {
            byte var56 = 35;
            yield var56;
         }
         case 42 -> {
            byte var57 = 47;
            yield var57;
         }
         case 43 -> {
            byte var58 = 50;
            yield var58;
         }
         case 44 -> {
            byte var59 = 12;
            yield var59;
         }
         case 45 -> {
            byte var60 = 42;
            yield var60;
         }
         case 46 -> {
            byte var61 = 63;
            yield var61;
         }
         case 47 -> {
            byte var62 = 38;
            yield var62;
         }
         case 48 -> {
            byte var63 = 15;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 23;
            yield var65;
         }
         case 51 -> {
            byte var66 = 52;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 37;
            yield var68;
         }
         case 54 -> {
            byte var69 = 28;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 34;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 43;
            yield var73;
         }
         case 59 -> {
            byte var74 = 46;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 57;
            yield var76;
         }
         case 62 -> {
            byte var77 = 25;
            yield var77;
         }
         default -> 62;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      m[0] = "i^BFl$wVX\t\u00114w";
      m[1] = ">\u0019r\u0000%.5\u0016cOD >\u001dg\u0015";
      m[2] = "#;lEM25;i\u001f^%\"pj\u0019R137}\u000e\u0019&\u000b";
      m[3] = "V]R!C\u0003#}Y.RLBsR%V\u00166";
      m[4] = void.class;
      n[4] = "java/lang/Void";
      m[5] = "\tP>\u0007\u001a\u0011\tP)[\u0016\u001e\u0013\u001b)E\u0016\u000b\u0014jy\u0018G";
      m[6] = "\u0004O{\b\u0006S\u0004OlT\n\\\u001e\u0004lJ\nI\u0019u<\u0017^";
      m[7] = "z\u0015\u0014(\u0001\u0006l\u0015\u0011r\u0012\u0011{^\u0012t\u001e\u0005j\u0019\u0005cU\u0017[";
      m[8] = int.class;
      n[8] = "java/lang/Integer";
      m[9] = "\u001f!\u0017X%{\t!\u0012\u00026l\u001ej\u0011\u0004:x\u000f-\u0006\u0013qj3";
      m[10] = "\rBN?;<xbE0*s\u0019lN;.)m";
      m[11] = "NS}Z.6NSj\u0006\"9T\u0018j\u0018\",Si8Fzh";
      m[12] = "y2\u001e\u0012QAo2\u001bHBVxy\u0018NNBi>\u000fY\u0005U[";
      m[13] = "z\u001fHIB\u0002z\u001f_\u0015N\r`T_\u000bN\u0018g%\u000bS\u0019";
      m[14] = "f>o=\u001aXm1~rrXc>m";
      m[15] = float.class;
      n[15] = "java/lang/Float";
      m[16] = "\u0003]M-%E\u0003]Zq)J\u0019\u0016Zo)_\u001eg\n3|";
      m[17] = "\u000f4e\u0017E^\u00194`MVI\u000e\u007fcKZ]\u001f8t\\\u0011H2";
      m[18] = "$ \u001e@\u007fkQ\u0000\u0015On$0\u000e\u001eDj~D";
      m[19] = "Q^W\u0000miG^RZ~~P\u0015Q\\rjARFK9\u007fr";
      m[20] = "T\u001a\"\u0012RM_\u00153]1@J\u0018<6\u0004B[\u000b \u001a\u0013O";
      m[21] = boolean.class;
      n[21] = "java/lang/Boolean";
      m[22] = "H\u0013E-=>V\u001b_bA*L\u0016\\!";
      m[23] = "\u0014c5\u001f?b\u0014c\"C3m\u000e(\"]3x\tYp\u0001f:";
      m[24] = long.class;
      n[24] = "java/lang/Long";
      m[25] = "6\t/\n:<C)$\u0005+s\"'/\u000e/)V";
      m[26] = "}x'x*[}x0$&Tg30:&A`Bgep";
      m[27] = "\u001dU=\u0001F!\u0018@6\u0001M:\u0014Pthf\u0010%";
      m[28] = "\u0015v~#D!\u0012g}.%!,{o:\u0019!Sze(\\K\u0016ixcG)N#j?%";
      m[29] = "!=F\u0004\u001a*q5^\bz.#-_\u0012\u0016\u001crm\u000eMz+~;M\u001b\u0000v,8@u";
      m[30] = "C\u0015\u001b&)zG\u0005\u001e`\u0015o(\u001e\u0016t)lW\u001f\u001cfl\u0006FD\u000bykaC\u0012\u0011b\u0015";
      m[31] = "qrcdNFszu4,K+oz5{\u001ct3&Y\u0010Cwx`+R\u0014vi";
      m[32] = "NP0$VE\u0018\t;_\rB(\u000eo`VO\u0013];\"V,\u0011\u000eic\t\u0017BZ+cjJOQ-c\u0003\u001c\u0016ZV";
      m[33] = "/K\u0005\u0003ml-C\u0013S\u000fauV\u001cRX6+\u0006E>n5{\u0004\u0007AeczT";
      m[34] = "59x\u0000L.o=w\u0019&90/g2K*\u0017,i}Ff>3v\u0007\u001b4=>\u0018@X=((}\u001aKk7A%\u0003M*=$\u007f\u0010\u001b5T";
      m[35] = "E\bl|{\u001b\u0016DkzG\u0019yD~};\u001b\u001c\u001em+$r";
      m[36] = "\u000b\u000b'3\u0014|\b\u00073,ne5\u0016/4RfJ\u0017%&\u0017\f\u0005\u001f3`SmVG{1n";
      m[37] = "y\u0016O&\u0010\u0012c\u0010\u0016y\u007f\n~T\u001fx\u00138)\u0013C/Fo}\u0012\u000e{\u0001\bxD\u0014`\u007fUaSO}\u001d\r+A\u0013\u001f";
      m[38] = "J\u0017#\u001a\u001c~G\u0010}L\"vz@#O\u001e|A\u0013w\r\u001e\u001f";
      m[39] = "\u001alC\u0011\u0016v\u0018dUAt{@qZ@#,\u001e&\u0002,E-DwZVE,\u0018$";
      m[40] = "Z(O#S'\u00109Kal'\u000f4]f2 \u000f.Y\u001a\u00059RhL%V&\u0006l4";
      m[41] = "|bz'\nL>5{6tP!i#1#\u0007p5{]\u001e\u0000p=( \u0004\u0006)b";
      m[42] = "?)(*S\u001b;9-lo\u000eT\"%xS\r+#/j\u0016gn02!\r\u00056z }o";
      m[43] = "\u0002OPM6]\u0014WG@I\nnB\fAv\\\tDZ@sc\u0003\u0015Z\u0012v\u0004\u0005C[\u0017I";
      m[44] = "*,^9R&0*\u0007f=>-n\u000egQ\fy.U<=5zc\n~Z0,y\u0011\u0000";
      m[45] = "}H4/z\u0018\u007f@\"\u007f\u0018\u001e+D)ut,|\u0002w\"#{)T0cx\u001ay\\(o\u0018";
      m[46] = "1}\u0003l:\n8k^9\\\u001e2`\u001f\u001e8\u001f6lc9,Adh\\j3\u0015`\u0010";
      m[47] = "t-<\u0001t[t,`R\u0010D(i9\r|vx+cV\u0010O\u007fd=\u0014wJ)~&j";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(104939537748700L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(104939537748700L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(104939537748700L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 73;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 170;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 241;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 235;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 107;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 77;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 73;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 170;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 241;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fG_C0283",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fG" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
