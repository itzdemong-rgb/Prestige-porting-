package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.api.events.Render3DEvent;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.util.ProjectileSimulationState;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap.Type;
import org.joml.Matrix4f;
import org.joml.Vector3d;

public class Weather extends Module {
   private ModeSetting a;
   private IntSetting c;
   private IntSetting d;
   private FloatSetting e;
   private FloatSetting f;
   private BooleanSetting g;
   private ColorSetting h;
   private static ManagedGlTexture i;
   private ArrayList j;
   private ElapsedTimer k;
   private Vec3d l;
   private static final long m = 78571978114648L;
   private static final String[] n;
   private static final String[] o;
   private static final Map p = new HashMap(13);
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final Object[] t = new Object[123];
   private static final String[] u = new String[123];
   private static volatile MethodHandle bindingCache1;

   public Weather() {
      super();
      long var10001 = 121980419416769L ^ 17567896671720L;
      var10001 = 121980419416769L ^ 82793116410241L;

      this.j = new ArrayList();
      this.k = new ElapsedTimer(106698256430889L);
      this.l = null;
      ColorSetting var10000 = this.h;
      Object[] var8 = new Object[]{invokeBinding1(this), 41489415177024L};
      ColorSetting var7 = var10000;
      var7.aReturningColorSetting(var8);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 67884488012130L;
      ArrayList var6 = this.j;
      var6.clear();
      ElapsedTimer var10000 = this.k;
      Object[] var8 = new Object[]{var4};
      ElapsedTimer var7 = var10000;
      var7.aReturningVoid(var8);
      this.l = null;
   }

   @EventListener
   public void a(Render3DEvent var1) {
      long var10001 = 136132167817107L ^ 100437903333522L;
      var10001 = 136132167817107L ^ 102507600953235L;
      var10001 = 136132167817107L ^ 101762767169600L;
      var10001 = 136132167817107L ^ 111457867113588L;
      var10001 = 136132167817107L ^ 125422381324543L;
      var10001 = 136132167817107L ^ 59842725435790L;
      int var16 = Event.cReturningInt();
      int var121 = var16;
      MinecraftClient var120 = b;
      MinecraftClient var103 = var120;
      MinecraftClient var102 = var120;
      if (var121 != 0) {
         MinecraftClient var26 = var102;
         ClientPlayerEntity var122 = var26.player;
         if (var122 == null) {
            return;
         }

         MinecraftClient var123 = b;
         var103 = var123;
      }

      MinecraftClient var29 = var103;
      ClientWorld var124 = var29.world;
      if (var124 != null) {
         float var17;
         String var18;
         int var19;
         int var20;
         Vec3d var21;
         int var110;
         label175: {
            int var109;
            ElapsedTimer var10000 = this.k;
            Object[] var32 = new Object[]{35831705079553L};
            ElapsedTimer var31 = var10000;
            float var181 = var31.aReturningFloat(var32) / 50.0F;
            float var34 = 4.0F;
            float var33 = var181;
            var17 = Math.min(var33, var34);
            var10000 = this.k;
            Object[] var36 = new Object[]{42835128969216L};
            ElapsedTimer var35 = var10000;
            var35.aReturningVoid(var36);
            ModeSetting var37 = this.a;
            var18 = (String)var37.aReturningObject();
            IntSetting var38 = this.c;
            Integer var39 = (Integer)var38.aReturningObject();
            var19 = var39;
            IntSetting var40 = this.d;
            Integer var41 = (Integer)var40.aReturningObject();
            var20 = var41;
            Object[] var42 = new Object[]{43167644123091L};
            var21 = RaycastUtil.bReturningVec3d(var42);
            ArrayList var43 = this.j;
            byte var183 = ((byte)((var43.isEmpty()) ? 1 : 0));
            int var126 = var16;
            byte var125 = var183;
            var109 = var125;
            byte var104 = var125;
            label138:
            if (var126 != 0) {
               byte var127 = var104;
               label143:
               if (var127 == 0) {
                  label165: {
                     int var129 = var16;
                     Vec3d var128 = this.l;
                     Vec3d var107 = var128;
                     Vec3d var105 = var128;
                     if (var129 != 0) {
                        Vec3d var130 = var105;
                        Vec3d var106 = var130;
                        Vec3d var131 = var106;
                        if (var131 == null) {
                           break label165;
                        }

                        Vec3d var132 = this.l;
                        var107 = var132;
                     }

                     Vec3d var49 = var21;
                     Vec3d var48 = var107;
                     double var198;
                     int var184 = (var198 = var48.squaredDistanceTo(var49) - 256.0) == 0.0 ? 0 : (var198 < 0.0 ? -1 : 1);
                     int var134 = var16;
                     int var133 = var184;
                     var109 = var133;
                     int var108 = var133;
                     if (var134 == 0) {
                        break label138;
                     }

                     int var135 = var108;
                     if (var135 > 0) {
                        break label143;
                     }
                  }

                  var110 = 0;
                  break label175;
               }

               var109 = 1;
            }

            int var136 = var109;
            var110 = var136;
         }

         label166: {
            int var22 = var110;
            this.l = var21;
            int var138 = var16;
            int var137 = var22;
            int var112 = var137;
            int var111 = var137;
            if (var138 != 0) {
               int var139 = var111;
               if (var139 != 0) {
                  int var24 = var19 * 6;

                  int var146;
                  do {
                     ArrayList var52 = this.j;
                     int var185 = var52.size();
                     int var141 = var19;
                     int var140 = var185;
                     if (var140 >= var141) {
                        break;
                     }

                     int var143 = var24;
                     int var142 = var23;
                     if (var142 >= var143) {
                        break;
                     }

                     Object[] var10006 = new Object[]{null, null, null, 85360426421789L};
                     var10006[2] = var20;
                     var10006[1] = var21;
                     var10006[0] = var18;
                     Object[] var54 = var10006;
                     Weather var53 = this;
                     ProjectileSimulationState var25 = var53.aReturningf_(var54);
                     int var144 = var16;
                     if (var144 != 0) {
                        ProjectileSimulationState var145 = var25;
                        if (var145 != null) {
                           ProjectileSimulationState var57 = var25;
                           ArrayList var56 = this.j;
                           var56.add(var57);
                        }

                        var23++;
                     }

                     var146 = var16;
                  } while (var146 != 0);

                  int var147 = var16;
                  if (var147 != 0) {
                     break label166;
                  }
               }

               byte var195 = 1;
               int var60 = var19 / 20;
               double var61 = var17 * Math.max(1, var60);
               int var148 = (int)Math.ceil(var61);
               var112 = var148;
            }

            int var175 = var112;
            int var155;
            do {
               ArrayList var64 = this.j;
               int var186 = var64.size();
               int var150 = var19;
               int var149 = var186;
               if (var149 >= var150) {
                  break;
               }

               int var152 = var175;
               int var151 = var177;
               if (var151 >= var152) {
                  break;
               }

               Object[] var197 = new Object[]{null, null, null, 85360426421789L};
               var197[2] = var20;
               var197[1] = var21;
               var197[0] = var18;
               Object[] var66 = var197;
               Weather var65 = this;
               ProjectileSimulationState var179 = var65.aReturningf_(var66);
               int var153 = var16;
               if (var153 != 0) {
                  ProjectileSimulationState var154 = var179;
                  if (var154 != null) {
                     ProjectileSimulationState var69 = var179;
                     ArrayList var68 = this.j;
                     var68.add(var69);
                  }

                  var177++;
               }

               var155 = var16;
            } while (var155 != 0);
         }

         ArrayList var71 = this.j;
         Iterator var176 = var71.iterator();

         while (true) {
            Iterator var72 = var176;
            boolean var156 = var72.hasNext();
            if (var156) {
               Iterator var73 = var176;
               ProjectileSimulationState var178 = (ProjectileSimulationState)var73.next();
               FloatSetting var74 = this.e;
               Float var75 = (Float)var74.aReturningObject();
               float var196 = var17 * var75;
               Object[] var10004 = new Object[]{null, 10847241703276L};
               var10004[0] = var196;
               Object[] var77 = var10004;
               ProjectileSimulationState var76 = var178;
               var76.aReturningVoid(var77);
               int var157 = var16;
               if (var157 == 0) {
                  break;
               }

               float var199;
               int var187 = (var199 = var178.c - var178.d) == 0.0F ? 0 : (var199 < 0.0F ? -1 : 1);
               int var159 = var16;
               int var158 = var187;
               int var115 = var158;
               int var113 = var158;
               if (var159 != 0) {
                  int var160 = var113;
                  int var114 = var160;
                  int var161 = var114;
                  if (var161 > 0) {
                     Iterator var80 = var176;
                     var80.remove();
                     int var162 = var16;
                     if (var162 != 0) {
                        continue;
                     }
                  }

                  Vec3d var83 = var21;
                  Vec3d var82 = var178.a;
                  double var200;
                  var115 = (var200 = var82.squaredDistanceTo(var83) - var20 * 1.6 * (var20 * 1.6)) == 0.0 ? 0 : (var200 < 0.0 ? -1 : 1);
               }

               int var163 = var115;
               if (var163 > 0) {
                  Iterator var84 = var176;
                  var84.remove();
                  int var164 = var16;
                  if (var164 != 0) {
                     continue;
                  }
               }

               label171: {
                  MinecraftClient var86 = b;
                  ClientWorld var188 = var86.world;
                  Vec3d var87 = var178.a;
                  BlockPos var89 = BlockPos.ofFloored((Position)var87);
                  ClientWorld var88 = var188;
                  BlockState var180 = var88.getBlockState(var89);
                  BlockState var90 = var180;
                  boolean var189 = var90.isAir();
                  int var166 = var16;
                  boolean var165 = var189;
                  boolean var117 = var165;
                  boolean var116 = var165;
                  if (var166 != 0) {
                     boolean var167 = var116;
                     if (var167) {
                        break label171;
                     }

                     BlockState var92 = var180;
                     boolean var168 = var92.isReplaceable();
                     var117 = var168;
                  }

                  int var170 = var16;
                  boolean var169 = var117;
                  boolean var119 = var169;
                  boolean var118 = var169;
                  if (var170 != 0) {
                     boolean var171 = var118;
                     if (var171) {
                        break label171;
                     }

                     BlockState var95 = var180;
                     FluidState var96 = var95.getFluidState();
                     boolean var172 = var96.isEmpty();
                     var119 = var172;
                  }

                  boolean var173 = var119;
                  if (var173) {
                     Iterator var98 = var176;
                     var98.remove();
                  }
               }

               int var174 = var16;
               if (var174 != 0) {
                  continue;
               }
            }

            Object[] var101 = new Object[]{var1, var18, 33610049713127L};
            Weather var100 = this;
            var100.jReturningVoid(var101);
            break;
         }
      }
   }

   private ProjectileSimulationState aReturningf_(Object[] var1) {
      net.minecraft.util.math.Vec3d var154;

      Vec3d var2;
      String var6;
      long var7;
      int var9;
      double var14;
      double var16;
      int var94;
      long var153;
      var6 = (String)var1[0];
      var2 = (Vec3d)var1[1];
      int var3 = (Integer)var1[2];
      long var4 = (Long)var1[3];
      var153 = 78571978114648L ^ var4;
      var7 = var153 ^ 72956847597910L;
      double var10 = Math.random() * Math.PI * 2.0;
      int var10000 = Event.bReturningInt();
      double var25 = Math.random();
      double var12 = Math.sqrt(var25) * var3;
      var9 = var10000;
      Vec3d var27 = var2;
      double var28 = var10;
      var14 = var27.x + Math.cos(var28) * var12;
      Vec3d var30 = var2;
      double var31 = var10;
      var16 = var30.z + Math.sin(var31) * var12;
      String var22 = var6;
      int var23 = -1;
      String var33 = var22;
      var10000 = var33.hashCode();
      int var107 = var9;
      int var106 = var10000;
      var94 = var106;
      int var85 = var106;
      label118:
      if (var107 == 0) {
         int var108 = var85;
         switch (var108) {
            case 2539444:
               short var10001 = 25419;
               long var10002 = 2434527425863140878L ^ var153;
               String var36 = "Rain";
               String var35 = var22;
               byte var158 = ((byte)((var35.equals(var36)) ? 1 : 0));
               int var110 = var9;
               byte var109 = var158;
               var94 = var109;
               byte var86 = var109;
               if (var110 != 0) {
                  break label118;
               }

               byte var111 = var86;
               byte var87 = var111;
               byte var112 = var87;
               if (var112 == 0) {
                  break;
               }

               var23 = 0;
               int var113 = var9;
               if (var113 == 0) {
                  break;
               }
            case 2581923:
               short var169 = 20937;
               long var179 = 7894644999824635021L ^ var153;
               String var40 = "Snow";
               String var39 = var22;
               byte var159 = ((byte)((var39.equals(var40)) ? 1 : 0));
               int var115 = var9;
               byte var114 = var159;
               var94 = var114;
               byte var88 = var114;
               if (var115 != 0) {
                  break label118;
               }

               byte var116 = var88;
               byte var89 = var116;
               byte var117 = var89;
               if (var117 == 0) {
                  break;
               }

               var23 = 1;
               int var118 = var9;
               if (var118 == 0) {
                  break;
               }
            case 1723967419:
               short var170 = 21426;
               long var180 = 5889551842665133818L ^ var153;
               String var44 = "Fireflies";
               String var43 = var22;
               byte var160 = ((byte)((var43.equals(var44)) ? 1 : 0));
               int var120 = var9;
               byte var119 = var160;
               var94 = var119;
               byte var90 = var119;
               if (var120 != 0) {
                  break label118;
               }

               byte var121 = var90;
               byte var91 = var121;
               byte var122 = var91;
               if (var122 == 0) {
                  break;
               }

               var23 = 2;
               int var123 = var9;
               if (var123 == 0) {
                  break;
               }
            case 2079095436:
               short var171 = 13600;
               long var181 = 2901546951483527270L ^ var153;
               String var48 = "Embers";
               String var47 = var22;
               byte var161 = ((byte)((var47.equals(var48)) ? 1 : 0));
               int var125 = var9;
               byte var124 = var161;
               var94 = var124;
               byte var92 = var124;
               if (var125 != 0) {
                  break label118;
               }

               byte var126 = var92;
               byte var93 = var126;
               byte var127 = var93;
               if (var127 != 0) {
                  var23 = 3;
               }
         }

         var94 = var23;
      }

      int var128 = var94;
      double var18;
      Vec3d var20;
      short var21;
      switch (var128) {
         case 0:
            Vec3d var51 = var2;
            var18 = var51.y - 4.0 + Math.random() * 28.0;
            short var162 = 1526;
            var20 = new Vec3d(0.0, -0.45, 0.0);
            long var172 = 9103337187195924672L ^ var153;
            var21 = 200;
            int var129 = var9;
            if (var129 == 0) {
               break;
            }
         case 1:
            Vec3d var52 = var2;
            var18 = var52.y - 3.0 + Math.random() * 23.0;
            short var163 = 7783;
            var20 = new Vec3d((Math.random() - 0.5) * 0.02, -0.06, (Math.random() - 0.5) * 0.02);
            long var173 = 1809228381932825429L ^ var153;
            var21 = 600;
            int var130 = var9;
            if (var130 == 0) {
               break;
            }
         case 2:
            Vec3d var53 = var2;
            var18 = var53.y - 1.0 + Math.random() * 6.0;
            short var164 = 1554;
            var20 = new Vec3d((Math.random() - 0.5) * 0.015, (Math.random() - 0.5) * 0.01, (Math.random() - 0.5) * 0.015);
            long var174 = 4005115230923567907L ^ var153;
            var21 = 400;
            int var131 = var9;
            if (var131 == 0) {
               break;
            }
         case 3:
            Vec3d var54 = var2;
            var18 = var54.y - 4.0 + Math.random() * 12.0;
            short var165 = 18431;
            var20 = new Vec3d((Math.random() - 0.5) * 0.01, 0.05 + Math.random() * 0.02, (Math.random() - 0.5) * 0.01);
            long var175 = 3896533270262477519L ^ var153;
            var21 = 300;
            int var132 = var9;
            if (var132 != 0) {
               return null;
            }
            break;
         default:
            return null;
      }

      ClientWorld var101;
      label83: {
         label82: {
            byte var100;
            var154 = new Vec3d(var14, var18, var16);
            short var176 = 25419;
            long var182 = 2434527425863140878L ^ var153;
            String var57 = "Rain";
            String var56 = var6;
            byte var166 = ((byte)((var56.equals(var57)) ? 1 : 0));
            int var134 = var9;
            byte var133 = var166;
            var100 = var133;
            byte var95 = var133;
            label81:
            if (var134 == 0) {
               byte var135 = var95;
               if (var135 == 0) {
                  var176 = 20937;
                  var182 = 7894644999824635021L ^ var153;
                  String var60 = "Snow";
                  String var59 = var6;
                  var166 = ((byte)((var59.equals(var60)) ? 1 : 0));
                  int var137 = var9;
                  byte var136 = var166;
                  var100 = var136;
                  byte var96 = var136;
                  if (var137 != 0) {
                     break label81;
                  }

                  byte var138 = var96;
                  byte var97 = var138;
                  byte var139 = var97;
                  if (var139 == 0) {
                     break label82;
                  }
               }

               MinecraftClient var63 = b;
               int var141 = var9;
               ClientWorld var140 = var63.world;
               var101 = var140;
               ClientWorld var98 = var140;
               if (var141 != 0) {
                  break label83;
               }

               ClientWorld var142 = var98;
               ClientWorld var99 = var142;
               Type var178 = Type.MOTION_BLOCKING;
               double var65 = var14;
               int var184 = MathHelper.floor(var65);
               double var67 = var16;
               int var72 = MathHelper.floor(var67);
               int var71 = var184;
               Type var70 = var178;
               ClientWorld var69 = var99;
               var23 = var69.getTopY(var70, var71, var72);
               double var185;
               var100 = (byte)((var185 = var18 - var23) == 0.0 ? 0 : (var185 < 0.0 ? -1 : 1));
            }

            byte var143 = var100;
            if (var143 < 0) {
               return null;
            }
         }

         MinecraftClient var74 = b;
         var101 = var74.world;
      }

      label126: {
         Vec3d var75 = var154;
         BlockPos var77 = BlockPos.ofFloored((Position)var75);
         ClientWorld var76 = var101;
         BlockState var156 = var76.getBlockState(var77);
         BlockState var78 = var156;
         boolean var168 = var78.isAir();
         int var145 = var9;
         boolean var144 = var168;
         boolean var103 = var144;
         boolean var102 = var144;
         if (var145 == 0) {
            boolean var146 = var102;
            if (var146) {
               break label126;
            }

            BlockState var80 = var156;
            boolean var147 = var80.isReplaceable();
            var103 = var147;
         }

         int var149 = var9;
         boolean var148 = var103;
         boolean var105 = var148;
         boolean var104 = var148;
         if (var149 == 0) {
            boolean var150 = var104;
            if (var150) {
               break label126;
            }

            BlockState var83 = var156;
            FluidState var84 = var83.getFluidState();
            boolean var151 = var84.isEmpty();
            var105 = var151;
         }

         boolean var152 = var105;
         if (var152) {
            return null;
         }
      }

      ProjectileSimulationState var24 = new ProjectileSimulationState(var154, var20, var21, var7);
      var24.c = (float)(Math.random() * var21 * 0.5);
      return var24;
   }

   private void jReturningVoid(Object[] var1) {
      Render3DEvent var2 = (Render3DEvent)var1[0];
      String var3 = (String)var1[1];
      long var4 = (Long)var1[2];
      var4 = 78571978114648L ^ var4;
      long var6 = var4 ^ 131050735552652L;
      long var8 = var4 ^ 100626854991757L;
      long var10 = var4 ^ 139252601801324L;
      long var12 = var4 ^ 122337538604313L;
      long var14 = var4 ^ 63276125726466L;
      long var16 = var4 ^ 80503419400598L;
      int var18 = Event.bReturningInt();
      ArrayList var40 = this.j;
      boolean var160 = var40.isEmpty();
      if (!var160) {
         int var162 = var18;
         ManagedGlTexture var161 = i;
         Object var136 = var161;
         ManagedGlTexture var135 = var161;
         if (var162 == 0) {
            ManagedGlTexture var163 = var135;
            if (var163 == null) {
               short var10000 = 16768;
               long var10001 = 4182528949910935865L ^ var4;
               Object[] var43 = new Object[]{"assets/prestige/particles/glow.png", var16};
               i = TextureLoader.aReturningbT_C0095(var43);
            }

            BooleanSetting var45 = this.g;
            var136 = var45.aReturningObject();
         }

         Boolean var46 = (Boolean)var136;
         boolean var19 = var46;
         boolean var164 = var19;
         Color var137;
         if (var164) {
            Object[] var47 = new Object[]{var8};
            Color var48 = ClientUiUtil.dReturningColor(var47);
            Color var165 = var48.darker();
            var137 = var165;
         } else {
            var137 = null;
         }

         Color var20 = var137;
         boolean var166 = var19;
         Color var138;
         if (var166) {
            Object[] var50 = new Object[]{var8};
            Color var51 = ClientUiUtil.dReturningColor(var50);
            Color var167 = var51.brighter();
            var138 = var167;
         } else {
            var138 = null;
         }

         Color var21 = var138;
         boolean var168 = var19;
         Color var139;
         if (var168) {
            Object var169 = null;
            var139 = (Color)var169;
         } else {
            ColorSetting var54 = this.h;
            var139 = (Color)var54.aReturningObject();
         }

         Color var22;
         float var23;
         boolean var26;
         int var149;
         var22 = var139;
         FloatSetting var55 = this.f;
         Float var56 = (Float)var55.aReturningObject();
         var23 = var56;
         var26 = true;
         String var27 = var3;
         int var28 = -1;
         String var57 = var27;
         int var228 = var57.hashCode();
         int var171 = var18;
         int var170 = var228;
         var149 = var170;
         int var140 = var170;
         label163:
         if (var171 == 0) {
            int var172 = var140;
            switch (var172) {
               case 2539444:
                  short var238 = 3852;
                  long var10002 = 4344369137208186806L ^ var4;
                  String var60 = "Rain";
                  String var59 = var27;
                  byte var229 = ((byte)((var59.equals(var60)) ? 1 : 0));
                  int var174 = var18;
                  byte var173 = var229;
                  var149 = var173;
                  byte var141 = var173;
                  if (var174 != 0) {
                     break label163;
                  }

                  byte var175 = var141;
                  byte var142 = var175;
                  byte var176 = var142;
                  if (var176 == 0) {
                     break;
                  }

                  var28 = 0;
                  int var177 = var18;
                  if (var177 == 0) {
                     break;
                  }
               case 2581923:
                  short var239 = 26266;
                  long var248 = 6976559915960122914L ^ var4;
                  String var64 = "Snow";
                  String var63 = var27;
                  byte var230 = ((byte)((var63.equals(var64)) ? 1 : 0));
                  int var179 = var18;
                  byte var178 = var230;
                  var149 = var178;
                  byte var143 = var178;
                  if (var179 != 0) {
                     break label163;
                  }

                  byte var180 = var143;
                  byte var144 = var180;
                  byte var181 = var144;
                  if (var181 == 0) {
                     break;
                  }

                  var28 = 1;
                  int var182 = var18;
                  if (var182 == 0) {
                     break;
                  }
               case 1723967419:
                  short var240 = 7312;
                  long var249 = 3036953609177383981L ^ var4;
                  String var68 = "Fireflies";
                  String var67 = var27;
                  byte var231 = ((byte)((var67.equals(var68)) ? 1 : 0));
                  int var184 = var18;
                  byte var183 = var231;
                  var149 = var183;
                  byte var145 = var183;
                  if (var184 != 0) {
                     break label163;
                  }

                  byte var185 = var145;
                  byte var146 = var185;
                  byte var186 = var146;
                  if (var186 == 0) {
                     break;
                  }

                  var28 = 2;
                  int var187 = var18;
                  if (var187 == 0) {
                     break;
                  }
               case 2079095436:
                  short var241 = 4390;
                  long var250 = 6229604784912058781L ^ var4;
                  String var72 = "Embers";
                  String var71 = var27;
                  byte var232 = ((byte)((var71.equals(var72)) ? 1 : 0));
                  int var189 = var18;
                  byte var188 = var232;
                  var149 = var188;
                  byte var147 = var188;
                  if (var189 != 0) {
                     break label163;
                  }

                  byte var190 = var147;
                  byte var148 = var190;
                  byte var191 = var148;
                  if (var191 != 0) {
                     var28 = 3;
                  }
            }

            var149 = var28;
         }

         int var192 = var149;
         float var24;
         float var25;
         switch (var192) {
            case 0:
               var24 = 0.5F;
               var25 = 4.5F;
               var26 = false;
               int var193 = var18;
               if (var193 == 0) {
                  break;
               }
            case 1:
               var24 = 1.6F;
               var25 = 1.6F;
               int var194 = var18;
               if (var194 == 0) {
                  break;
               }
            case 2:
               var24 = 2.5F;
               var25 = 2.5F;
               int var195 = var18;
               if (var195 == 0) {
                  break;
               }
            case 3:
               var24 = 1.4F;
               var25 = 1.4F;
               int var196 = var18;
               if (var196 == 0) {
                  break;
               }
            default:
               var24 = 2.0F;
               var25 = 2.0F;
         }

         var24 *= var23;
         var25 *= var23;
         Object[] var75 = new Object[]{var10};
         Vec3d var226 = RaycastUtil.bReturningVec3d(var75);
         IntSetting var76 = this.d;
         Integer var77 = (Integer)var76.aReturningObject();
         var28 = var77;
         ArrayList var78 = new ArrayList(this.j);
         Iterator var29 = var78.iterator();

         while (true) {
            Iterator var79 = var29;
            boolean var197 = var79.hasNext();
            if (!var197) {
               break;
            }

            Iterator var80 = var29;
            ProjectileSimulationState var30 = (ProjectileSimulationState)var80.next();
            Vec3d var82 = var226;
            Vec3d var81 = var30.a;
            double var31 = var81.distanceTo(var82);
            double var261;
            int var198 = (var261 = var31 - var28 * 1.5) == 0.0 ? 0 : (var261 < 0.0 ? -1 : 1);
            if (var198 <= 0) {
               float var34;
               label128: {
                  float var154;
                  label174: {
                     float var33 = var30.c / var30.d;
                     float var262;
                     var228 = (var262 = var33 - 0.1F) == 0.0F ? 0 : (var262 < 0.0F ? -1 : 1);
                     int var200 = var18;
                     int var199 = var228;
                     int var153 = var199;
                     int var150 = var199;
                     if (var200 == 0) {
                        int var201 = var150;
                        if (var201 < 0) {
                           var34 = var33 / 0.1F;
                           int var202 = var18;
                           if (var202 == 0) {
                              break label128;
                           }
                        }

                        int var204 = var18;
                        float var203 = var33;
                        var154 = var203;
                        float var151 = var203;
                        if (var204 != 0) {
                           break label174;
                        }

                        float var205 = var151;
                        float var152 = var205;
                        float var263;
                        int var206 = (var263 = var152 - 0.7F) == 0.0F ? 0 : (var263 < 0.0F ? -1 : 1);
                        var153 = var206;
                     }

                     int var207 = var153;
                     if (var207 > 0) {
                        var34 = (1.0F - var33) / 0.3F;
                        int var208 = var18;
                        if (var208 == 0) {
                           break label128;
                        }
                     }

                     float var209 = 1.0F;
                     var154 = var209;
                  }

                  var34 = var154;
               }

               int var158;
               label114: {
                  label176: {
                     short var242 = 21426;
                     long var251 = 5889502155504257792L ^ var4;
                     String var89 = "Fireflies";
                     String var88 = var3;
                     byte var234 = ((byte)((var88.equals(var89)) ? 1 : 0));
                     int var211 = var18;
                     byte var210 = var234;
                     byte var156 = var210;
                     byte var155 = var210;
                     if (var211 == 0) {
                        byte var212 = var155;
                        if (var212 != 0) {
                           double var91 = var30.c * 0.12 + var30.e;
                           var34 *= 0.35F + 0.65F * (float)(Math.sin(var91) * 0.5 + 0.5);
                           int var213 = var18;
                           if (var213 == 0) {
                              break label176;
                           }
                        }

                        var242 = 13600;
                        var251 = 2901460173455158684L ^ var4;
                        String var94 = "Embers";
                        String var93 = var3;
                        byte var214 = ((byte)((var93.equals(var94)) ? 1 : 0));
                        var156 = var214;
                     }

                     int var216 = var18;
                     byte var215 = var156;
                     var158 = var215;
                     byte var157 = var215;
                     if (var216 != 0) {
                        break label114;
                     }

                     byte var217 = var157;
                     if (var217 != 0) {
                        double var97 = var30.c * 0.4 + var30.e;
                        var34 *= 0.6F + 0.4F * (float)(Math.sin(var97) * 0.5 + 0.5);
                     }
                  }

                  var228 = (int)(255.0F * var34);
                  boolean var244 = false;
                  short var253 = 25181;
                  long var10003 = 5969757886276610708L ^ var4;
                  int var99 = var228;
                  var158 = MathHelper.clamp(var99, 0, 255);
               }

               int var35 = var158;
               boolean var218 = var19;
               Color var159;
               if (var218) {
                  float var254 = var30.f;
                  Object[] var10005 = new Object[]{null, null, null, var12};
                  var10005[2] = var254;
                  var10005[1] = var21;
                  var10005[0] = var20;
                  Object[] var102 = var10005;
                  Color var219 = aReturningColor(var102);
                  var159 = var219;
               } else {
                  var159 = var22;
               }

               Color var36 = var159;
               Color var104 = var36;
               int var255 = var104.getRed();
               Color var105 = var36;
               int var258 = var105.getGreen();
               Color var106 = var36;
               Color var37 = new Color(var255, var258, var106.getBlue(), var35);
               RenderContext var236 = var2.b;
               Vec3d var107 = var30.a;
               double var245 = var107.x;
               Vec3d var108 = var30.a;
               double var256 = var108.y;
               Vec3d var109 = var30.a;
               double var259 = var109.z;
               Object[] var10006 = new Object[]{null, null, null, null, var6};
               var10006[3] = var259;
               var10006[2] = var256;
               var10006[1] = var245;
               var10006[0] = var236;
               Object[] var110 = var10006;
               Vector3d var38 = RenderThreadUtil.aReturningVector3d(var110);
               Matrix4f var39 = new Matrix4f();
               Vector3d var111 = var38;
               float var246 = (float)var111.x;
               Vector3d var112 = var38;
               float var257 = (float)var112.y;
               Vector3d var113 = var38;
               float var117 = (float)var113.z;
               float var116 = var257;
               float var115 = var246;
               Matrix4f var114 = var39;
               var114.translate(var115, var116, var117);
               float var119 = 0.04F;
               Matrix4f var118 = var39;
               var118.scale(var119);
               RenderContext var120 = var2.b;
               Camera var121 = var120.bo();
               double var122 = -var121.getYaw();
               float var125 = (float)Math.toRadians(var122);
               Matrix4f var124 = var39;
               var124.rotateY(var125);
               int var220 = var18;
               if (var220 == 0) {
                  boolean var221 = var26;
                  if (var221) {
                     RenderContext var127 = var2.b;
                     Camera var128 = var127.bo();
                     double var129 = var128.getPitch();
                     float var132 = (float)Math.toRadians(var129);
                     Matrix4f var131 = var39;
                     var131.rotateX(var132);
                  }

                  MeshBufferManager var237 = var2.a;
                  RenderContext var247 = var2.b;
                  ManagedGlTexture var260 = i;
                  Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var14};
                  var10014[11] = 0.0F;
                  var10014[10] = var37;
                  var10014[9] = 0.0F;
                  var10014[8] = var25;
                  var10014[7] = var24;
                  var10014[6] = 0.0F;
                  var10014[5] = 0.0F;
                  var10014[4] = 0.0F;
                  var10014[3] = var260;
                  var10014[2] = var39;
                  var10014[1] = var247;
                  var10014[0] = var237;
                  Object[] var134 = var10014;
                  TexturedRectangleRenderer.mReturningVoid(var134);
               }

               int var222 = var18;
               if (var222 != 0) {
                  break;
               }
            }
         }
      }
   }

   private static Color aReturningColor(Object[] var0) {
      Color var2 = (Color)var0[0];
      Color var1 = (Color)var0[1];
      float var5 = (Float)var0[2];
      long var3 = (Long)var0[3];
      var3 = 78571978114648L ^ var3;
      float var12 = 1.0F;
      float var11 = 0.0F;
      float var10 = var5;
      var5 = MathHelper.clamp(var10, var11, var12);
      float var6 = 1.0F - var5;
      Color var13 = var2;
      float var10000 = var13.getRed() * var6;
      Color var14 = var1;
      int var7 = (int)(var10000 + var14.getRed() * var5);
      Color var15 = var2;
      var10000 = var15.getGreen() * var6;
      Color var16 = var1;
      int var8 = (int)(var10000 + var16.getGreen() * var5);
      Color var17 = var2;
      var10000 = var17.getBlue() * var6;
      Color var18 = var1;
      int var9 = (int)(var10000 + var18.getBlue() * var5);
      short var10004 = 8363;
      long var10005 = 4385673087354426148L ^ var3;
      int var19 = var7;
      int var10002 = MathHelper.clamp(var19, 0, 255);
      byte var31 = 0;
      short var32 = 8363;
      long var10006 = 4385673087354426148L ^ var3;
      int var22 = var8;
      var10003 = MathHelper.clamp(var22, 0, 255);
      byte var33 = 0;
      short var34 = 8363;
      long var10007 = 4385673087354426148L ^ var3;
      int var25 = var9;
      return new Color(var10002, var10003, MathHelper.clamp(var25, 0, 255));
   }

   private boolean lambda$new$0(Color var1) {
      int var4 = Event.bReturningInt();
      BooleanSetting var5 = this.g;
      Boolean var6 = (Boolean)var5.aReturningObject();
      byte var10000 = ((byte)(((java.lang.Boolean)(var6)).booleanValue() ? 1 : 0));
      int var11 = var4;
      byte var10 = var10000;
      byte var8 = var10;
      byte var7 = var10;
      if (var11 == 0) {
         byte var12 = var7;
         if (var12 != 0) {
            return false;
         }

         var8 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var8);
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(11311628348283L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[9];
      String var17 = "ß\f*1ÿF\u001d*êZië\u0003ä\u0085\u008f\u0010pÏqA\u0094\u008cîf1\u0085¢·\\Üi\u0006\u0010þ\u00815D\u001f¿G\u0081\u0004p\"d=mâÜ@\u0000\u0095ì?\u0095Ýa\u0014ß¼\u0004\u0000\u008bÉ¶øv\u009f¦^\u009e°\u0016¹G##Ùâ\u0000Ç¦}Âí\u001aj\u0017n-f\u0098Ñj,Fþ8>:>iÏþhÐ\u009aÒ\u0013¾ÒOQZ\u0010ô@³dÎL\u0082âÎò¯¯\u0094ö\u0018¡\u0010µ7\r\u0096ÒÆè){\u0090:ã\u009bÓ9Ú\u0010\\ç\u008cx\u0019Oá\u0081ÚÜÊ?\tH{»";
      int var19 = "ß\f*1ÿF\u001d*êZië\u0003ä\u0085\u008f\u0010pÏqA\u0094\u008cîf1\u0085¢·\\Üi\u0006\u0010þ\u00815D\u001f¿G\u0081\u0004p\"d=mâÜ@\u0000\u0095ì?\u0095Ýa\u0014ß¼\u0004\u0000\u008bÉ¶øv\u009f¦^\u009e°\u0016¹G##Ùâ\u0000Ç¦}Âí\u001aj\u0017n-f\u0098Ñj,Fþ8>:>iÏþhÐ\u009aÒ\u0013¾ÒOQZ\u0010ô@³dÎL\u0082âÎò¯¯\u0094ö\u0018¡\u0010µ7\r\u0096ÒÆè){\u0090:ã\u009bÓ9Ú\u0010\\ç\u008cx\u0019Oá\u0081ÚÜÊ?\tH{»"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     n = var20;
                     o = new String[9];
                     s = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(11311628348283L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "£Èv\u0084\u008cóÊÂ=ÿæ¿Á·XÊËk½£t\u001c³\u0014IÂ\u0004\u0090Å\u0002q\u0091¬\u0096Ó\u0083àû:f\u0016ão}/ôï&";
                     int var5 = "£Èv\u0084\u008cóÊÂ=ÿæ¿Á·XÊËk½£t\u001c³\u0014IÂ\u0004\u0090Å\u0002q\u0091¬\u0096Ó\u0083àû:f\u0016ão}/ôï&".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    q = var6;
                                    r = new Integer[8];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = ")3c\u0090×;\u0011\n)î¨\u0080Ìr\u0088\u0015";
                                 var5 = ")3c\u0090×;\u0011\n)î¨\u0080Ìr\u0088\u0015".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "Y3åÕßðÒ\u008a\u0096ðÕ\u000fXüzi\u0013RÁ\u0013Ãz\u000b»\u0018\fÊ÷OçèÕ¶ÄÀ¥\u0000P9º\u0095\u0092\u001fzÎçMÜÈ";
                  var19 = "Y3åÕßðÒ\u008a\u0096ðÕ\u000fXüzi\u0013RÁ\u0013Ãz\u000b»\u0018\fÊ÷OçèÕ¶ÄÀ¥\u0000P9º\u0095\u0092\u001fzÎçMÜÈ".length();
                  var16 = 24;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27909;
      if (o[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])p.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fH", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = n[var5].getBytes("ISO-8859-1");
         o[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return o[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fH_C0285",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fH" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32116;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fH", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fH_C0285",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fH" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = u[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = t[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 57;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 31;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 16;
            yield var21;
         }
         case 7 -> {
            byte var22 = 23;
            yield var22;
         }
         case 8 -> {
            byte var23 = 2;
            yield var23;
         }
         case 9 -> {
            byte var24 = 55;
            yield var24;
         }
         case 10 -> {
            byte var25 = 8;
            yield var25;
         }
         case 11 -> {
            byte var26 = 13;
            yield var26;
         }
         case 12 -> {
            byte var27 = 61;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 42;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 28;
            yield var32;
         }
         case 18 -> {
            byte var33 = 10;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 9;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 11;
            yield var41;
         }
         case 27 -> {
            byte var42 = 35;
            yield var42;
         }
         case 28 -> {
            byte var43 = 63;
            yield var43;
         }
         case 29 -> {
            byte var44 = 33;
            yield var44;
         }
         case 30 -> {
            byte var45 = 22;
            yield var45;
         }
         case 31 -> {
            byte var46 = 1;
            yield var46;
         }
         case 32 -> {
            byte var47 = 37;
            yield var47;
         }
         case 33 -> {
            byte var48 = 60;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 58;
            yield var50;
         }
         case 36 -> {
            byte var51 = 34;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 24;
            yield var53;
         }
         case 39 -> {
            byte var54 = 21;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 14;
            yield var56;
         }
         case 42 -> {
            byte var57 = 32;
            yield var57;
         }
         case 43 -> {
            byte var58 = 53;
            yield var58;
         }
         case 44 -> {
            byte var59 = 48;
            yield var59;
         }
         case 45 -> {
            byte var60 = 19;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 45;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 52;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 4;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 15;
            yield var68;
         }
         case 54 -> {
            byte var69 = 49;
            yield var69;
         }
         case 55 -> {
            byte var70 = 56;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 30;
            yield var72;
         }
         case 58 -> {
            byte var73 = 17;
            yield var73;
         }
         case 59 -> {
            byte var74 = 6;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 39;
            yield var76;
         }
         case 62 -> {
            byte var77 = 29;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            u[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      t[0] = "56X\r=v56OQ1y/}OO1l(\f\u001e\u0015h/";
      t[1] = ")F\nM\u0007_)F\u001d\u0011\u000bP3\r\u001d\u000f\u000bE4|MU[\u0006";
      t[2] = "x\u0010\\~e\u0003x\u0010K\"i\fb[K<i\u0019e*\u001ad;";
      t[3] = double.class;
      u[3] = "java/lang/Double";
      t[4] = "z\u0004^5%Rq\u000bOzXJb\fF3";
      t[5] = "\\eJJwCWj[\u0005\u0016M\\a__";
      t[6] = boolean.class;
      u[6] = "java/lang/Boolean";
      t[7] = "j`qMpd|`t\u0017csk+w\u0011ogzl`\u0006$uK";
      t[8] = int.class;
      u[8] = "java/lang/Integer";
      t[9] = "h8\twS#c7\u001880.v1";
      t[10] = "\u0018)*\b)\u001e\u000e)/R:\t\u0019b,T6\u001d\b%;C}\b4";
      t[11] = "g\u0000q@gQl\u000f`\u000f\u0004\\y\u0002od1^h\u0011sH&S";
      t[12] = "\u0002\u001apu!\u0019\u0002\u001ag)-\u0016\u0018Qg7-\u0003\u001f 6b|BH\u001ch:?\u00033M=k\u007f";
      t[13] = "\u0014pZx\"\t\u0014pM$.\u0006\u000e;M:.\u0013\tJ\u0018ew";
      t[14] = "Kgh\\U\u001cKg\u007f\u0000Y\u0013Q,\u007f\u001eY\u0006V]/C\b";
      t[15] = "6w&b\u0019|6w1>\u0015s,<1 \u0015f+M`\u007fG-";
      t[16] = "%8?%4f%8(y8i?s(g8|8\u0002y8n;";
      t[17] = " {L3'Q {[o+^:0[q+K=A\u000b(y\n";
      t[18] = "Y\t%\u001c=%G\u0001?SR\"A\t*1z#G";
      t[19] = void.class;
      u[19] = "java/lang/Void";
      t[20] = "w7f%g[a7c\u007ftLv|`yxXg;wn3MJ";
      t[21] = "+DG(d\u001b^dL'uT?jG,q\u000eK";
      t[22] = "?PUv,O4_D9@L:]Fvl";
      t[23] = "a>\u00186\u0012\tw>\u001dl\u0001\u001e`u\u001ej\r\nq2\t}F\u001dC";
      t[24] = "CP#u~\u0002ANj\rq\u000eXM6hp";
      t[25] = "\u0005\u001c<5\u000ek\u0018\td\u0017Of\u0000\u000f";
      t[26] = ":\u0014qs1\u0015,\u0014t)\"\u0002;_w/.\u0016*\u0018`8e\u00014";
      t[27] = "Qsh\u001f\"e$Sc\u00103*E]h\u001b7p1";
      t[28] = ",/Mf%;.1\u0004\u0005. 14R|)";
      t[29] = float.class;
      u[29] = "java/lang/Float";
      t[30] = "\u0018iRe;\u0018\u0013fC*\\\u001a\u0006mCag";
      t[31] = "s{yP\u00184msc\u001f\u007f5|hnEY3";
      t[32] = "U\u001bAf\b\u000eU\u001bV:\u0004\u0001OPV$\u0004\u0014H!\u0001y]S";
      t[33] = "\t)M)A(\u001f)HsR?\bbKu^+\u0019%\\b\u00159/";
      t[34] = "\u001c\u00109d\u00128i02k\u0003w\b>9`\u0007-|";
      t[35] = "|*q5aGj*torP}awi~Dl&`~5S\u007f";
      t[36] = "\u0002\u000fez\u007f\u0013w/nun\\\u0016!e~j\u0006b";
      t[37] = ">W\u007f@&\u0012KwtO7]*y\u007fD3\u0007^";
      t[38] = "\u0014\f\u0017+\u001c(\u0002\f\u0012q\u000f?\u0015G\u0011w\u0003+\u0004\u0000\u0006`H;C";
      t[39] = "ZRh/>P/rc /\u001fN|h++E:";
      t[40] = "4!%'\u0019Y\"! }\nN5j#{\u0006Z$-4lMM8";
      t[41] = "\bTH\u0007$\n}tC\b5E\u001czH\u00031\u001fh";
      t[42] = "< )&#6* ,|0!=k/z<5,,8mw$\f";
      t[43] = "=\u0015'iDw+\u0015\"3W`<^!5[t-\u00196\"\u0010`#";
      t[44] = "*_G\u0006RP!PVI:P/_E";
      t[45] = "b,6t\u0013\u0004t,3.\u0000\u0013cg0(\f\u0007r '?G\u0010O";
      t[46] = "B`/D\u0012K7@$K\u0003\u0004VN/@\u0007^\"";
      t[47] = "nW9Uj\u0012\u001bw2Z{]zy9Q\u007f\u0007\u000e";
      t[48] = "R^P{u('~[tdgFpP\u007f`=2";
      t[49] = "!FZ|_t!FM S{;\rM>Sn<|\u0019f\u0004";
      t[50] = " ;\u0007\u0004\u0006L6;\u0002^\u0015[!p\u0001X\u0019O07\u0016ORZ\u001b";
      t[51] = "L-1\u0003,Z9\r:\f=\u0015X\u00031\u00079O,";
      t[52] = "Y!$\fz\u001c,\u0001/\u0003kSM\u000f$\bo\t9";
      t[53] = "=\u0002\u001fDu;g\u001bR\u0019\u00155j\u0015.Ar.\u007f\u0007\u0015\u001ex7qe\u0013\u001bk,a^L\u0011r\"\u0003XI\u0002i28\u0007C\u001bgP";
      t[54] = "4d#:M@45o\u0007TJv:ukf\u001d4`(81\u001e6d#iU\u001ft+j\u0007";
      t[55] = "A_X\u0005\u000f\u0012\u0010Y\u000e\\\u007f\u001d.\u001d\u0007O\u0004\u0007LLZ@\u0001";
      t[56] = "J=\u0016@7yKn\u0000QXc\u0018w\u001f`?o\u001c\fBL&\u007f\u00137\u001dF?qq";
      t[57] = "W],x{[\u000fJ?!\u0014_MY.~hXM8!{ySXVylj\n7";
      t[58] = "A3LN?=\u001b*\u0001\u0013_3\u001e2}\u0015<+\u001c.GFf5\u0005T\u001e\u0015\"5\u0005nMO<,\u007f7\u001e\u000b<,EdD\u0015%V";
      t[59] = "IbO\u0017!=\u000b;\u001c\u0015\u0018?\u0018lDAOhB8\u0011\u0012\u0018a\u001an\u001a\u0014t#C=\u0018";
      t[60] = "^E/=\tG\u001d\u00142xrC\u0002T,a\u001eq_\u0016v:r\u0016\fGv?\u001eTU\u0014t\u0006OA\u0011T.=\u0010K\bZL;\u0015X\u0013Jwd\u001fA\u001d(qa\fZ\r\u0013.k\u0015To";
      t[61] = "/uO\u007fUouuEl?`-7z|[|&K\u0019rA})pFxXsK";
      t[62] = "FFo1\u0000\u007f\u001c_\"l`h\u001f{7e\u0001}\u001eZ^3Pf\u0003K<b\ri\u0006!d9\u0012o\u0012C5d\u001djx";
      t[63] = "\u0015$2/\rhLh\u007f1ah\u001c(sUZoJ=e3]4\f9\u000f";
      t[64] = "\"HTGl.%HUI\f>N\u000f\u0006Q|g#K_Sb)NU]Ho-t\u0006\u0007VvW";
      t[65] = "~'!\"S]$>l\u007f3]';\u0010 \u0003D;*rq^K>@**AM*\"{wNH@";
      t[66] = "..\u001dt!\u0010t7P)A\u0000i3PL{Kb2F.*\u0016m7,vq\tk#N',\u0006nI";
      t[67] = "\u0007!o\u000bM\u001a^m\"\u0015!\u0006\u000e85\u000fL|\u000f$ \u0013L\u0015\u0019:>J!";
      t[68] = "\u000en\u0014&\u0015\u001b\u0005k\u0004`n\u000e\u0006}\u001b8\u0002<R0@e_k\bb\u0006<\u0014Q[8\u0018%n";
      t[69] = "i\u001b;\u0014B61\f(M-7d\u0002\f\u001fAX4\u0019(\u000eOck\u00131\u0000-";
      t[70] = "gN9*x!r\u001f&(\u00046a^??h\u00045\u001fdd<S1E!$fhnO8*\u0004nk\\#:?1aE-X94r^=cf>kP_ec-p@d:i4~\"";
      t[71] = "Z}v&];Tx\u007fal:Btp'\b/Dp\u0016?\u000f;[g,lU%B\u001du?\u0011%B'&e\u000f<8~u!\u000f<\u0002-/?\u0016FZ}v&];Tx\u007fal";
      t[72] = " Z92|\u0003|U<>\u0003\rxW<;TZ\"\u0007bW9SkA25h\u000edD";
      t[73] = "}i\u000ee\u00143!f\u000bik=%d\u000bl<j\u007f4V\u0000Qc6r\u0005b\u0000>9w";
      t[74] = "_o:)Lf^<,8#q\u001d#:&X\u001c_?h'IzXd.## \u000eg09Js\u00150jB";
      t[75] = "(\"To\u0014\n/{\u0019x$S?*\\|XU9GBi\u0019H/!\u001b%TVC";
      t[76] = "\u001b9\u000b!P\"\u001cq\u0016+hr$9R&\u0007tTw\u0015/R\u001b\u00143\u0003\"\u0007kZt\nwh";
      t[77] = "\u0013m9Ndb\u0014%$D\\2,dbF,kA ;D2%,=?O:4Be(\\c[";
      t[78] = "]j^W \t\\wQL]\n$)\bU-PImQW3\u001e$)PP8\u001fDu_U4`";
      t[79] = "\n'\u0000;\u0011N\u000eo\t9hXq.]g\u0018\u0001\u001cj\u0004e\u0006Oqk\u0005bRL\u0003)\u0018j\u000f1";
      t[80] = "\u007fX\b,Dv'O\u001bu+tvG\u0006'Q\u0018\u007fX\b,Dv'O\u001bu+";
      t[81] = "s\"\u00153\u0005f=b\\u}x#3I */|n\u0012LL{!eV-\u000f*< ";
      t[82] = "&:\u0012\f;62<\u001d]^6<\u0004GS1% tLV!c[";
      t[83] = "X?\u0019!c6Mn\u0006#\u001f!^/\u001f4s\u0013\nnDm$DP0\u00020e~\u0003j\u001c)\u001f'P.\u001c)%t\n0\u0005S|'N0\u0005i/}P)\u007f0|9P)Ec&'IS";
      t[84] = "gWn.0\u0004?\bnlL_cEpw m2\b.+|:dVqt=^pB/tLS`G.lr\u000b?Gl\u0010";
      t[85] = "4_WmXB3\u0006\u001azh\u001b$w@o\u0014\u000b_\u0006O.\u000b\u00016UTyQz";
      t[86] = ">OW-\u0012[>\u001e\u001b\u0010\u000bQ|\u0011\u0001|9\u0006>K_-n\u0000jH\u0005k\u0007Sq\u001f_\u0010";
      t[87] = "\r\u001dD$\"\u0019\u0018L[&^\u000e\u000b\rB12<_L\u0019kak\\AP-4\t\r\u001c_(^V\u0001\u000f^4e\t\u000b\u0016PV";
      t[88] = "'t\u0000-1o{{\u0005!Njsh\u0001/\"X',[uN6~u\u00047.jqp\bHt?lo\u000b*%bcja";
      t[89] = "t\u0006I'XbsNT-`2K\u000f\u0012/\u0010k&KK-\u000e%KD\u0010t\u00125.ZH'^[";
      t[90] = "\u0016\u00112vIJL\b\u007f+)[A\u0010o)L!\u0012Fq5CCC\u001b~0)";
      t[91] = "*jjDd$r}y\u001d\u000b%'sHXf',\u000f:Eu6(4eOl8J";
      t[92] = "`O\u0003:cIa\rLs\rH4\u000f]laz`N\u00025<-e\u0019\u0004hvD6\u0002S2\r";
      t[93] = "S5\u0018ph;T}\u0005zP`l<Cx 2\u0001x\u001az>|li\u0002n2o\u0005\u007f\u001cpk\u0002";
      t[94] = "&YR\u0012`0r\\F\u0016P5\u001bZY\u000f,= \u0005S\u0016\"_";
      t[95] = "\b:mZ6\rR# \u0007V\u001dW;\\Xf\u0014M7>\t;\u001bH]fR$\u001d\\?7\u000f+\u00186";
      t[96] = "\u007f.iR!x.(?\u000bQu\u0010l6\u0018*mr=k\u0017/";
      t[97] = "3zUpc\\?mUj^IR)\u0007n.\u0010?m^l0^R\u007fGefP-.A3? ";
      t[98] = "@U1L:\nNP8\u000b\u000b\fI\\5[\u000b\u0014AH2L1G\u001bV+6i\u0017BO`Kg\u0012K\bQ";
      t[99] = "\u0005\u001f\u0003d\u0018\u000f\u0002FNs(L\u000f\b\u001c\u001e\u0015P\u0010\u0006\u0013%JZ\t\bq";
      t[100] = "\u0006VQG[H\u000bXIO1\u0013\u000fXW@X\u001f6VWP\\yTU\nNJ\u0010\u0007N]\u00141";
      t[101] = "V\u0001\u00198Zf\u0002\u0004\r<jbk\u0002\u0012%\u0016kP]\u0018<\u0018\t";
      t[102] = "\u0004^BK\b XQGGw.\\SGB y\u0006\u0003\u001b.MpOEIL\u001c-@@";
      t[103] = "N65C 8Df*\u0017\u00186!0.C}5G7u\u0005y_";
      t[104] = "0.R~.j7.SpNz\\i\u0000h>#1-Yj m\\<A~,~5*_`u\u0013";
      t[105] = "+P}>\u0011%e\u00104xi;{A!->l%\u0016yA\u0018>%F=y\u0003j{C";
      t[106] = "s\u000e\u0017j\u000b#}\u000b\u001e-:$v\u0012\u001elW\u000f\u0011\r\u0014mY$+^Ns@^s\u000e\u0017j\u000b#}\u000b\u001e-:";
      t[107] = "x6\tDEX!zDZ)^u1rSYB\u001cv^\u0007JEu%EP\u0010>";
      t[108] = "\u007f.r3&`#!w?Ye+2s15W\u007fv)lY9&/v)9e)*zVc045y42m;0\u0013";
      t[109] = "O/!D\u001e&O~my\u0007,\rqw\u00155}L-/Eb}\u001b(s\u0002\u000b.\u0000\u007f)y";
      t[110] = "\u000fC\u001cx\u001d\u000fL\u0012\u0001=f\u000bSR\u001f$\n9\u000e\u0015E{f\u0007PPA?X_\u000fP\u0003CXP\u000f\u0013\u0003$X\u0001C.";
      t[111] = "\u001f#?bn=B 4hT:y$ko$f\u0014`2m:(y}6f29\u0017%!ukV";
      t[112] = "D0D\u0010Os\u00196CJ!g#w\u001d\u001eQ2N3D\u001cO|#\"\\\bCoJ4B\u0016\u001a\u0002";
      t[113] = "GFS%:g\u001fQ@|UfJ_t'(d'\u001eY=)k\u001cAS$'\t";
      t[114] = "O{w\u0011\"'\u0015b:LB'\u001c}\")x|\u0003g,K)!\fbF\u0013r>\nv$B/1\u000f\u001c";
      t[115] = "\u00050j!.UB'7tR^{r4}\"\u0007\u00166m\u007f<I{5w\u007fjK\u0019r`\"?7";
      t[116] = "eJ>KE8nO.\r>-mY1UR\u001f9\u0014j\t\u0006HcF,QDr0\u001c2H>";
      t[117] = "/\u0016{\r\u000b\\!\u0013rJ:[*\nr\u000bWqM\u0015x\nY[wF\"\u0014@!/\u0016{\r\u000b\\!\u0013rJ:";
      t[118] = "\u001a& m0g\u001d\u007fmz\u00006\u001d/R,ad\u0014)4+:\"\u0010Cn}9<\n*=fnfq";
      t[119] = "RA%\u00144gU\u0018h\u0003\u00044]I>\u0014\u00043@V5\u0003m%^Hln";
      t[120] = "[\u00138,\u0001mX^>f\u007fiB\b0h!nB\u00124\u0014\u001cd[\f#.O>E\u0015Y";
      t[121] = "\u0002|^v\u0000D\u001c$\r:nHp\u007fY`\u001e\u0011\u001d;\u0000b\u0000_p*\u0018v\fL\u0019<\u0006hU!";
      t[122] = "\u001cNccw\u001fMH5:\u0007\u0011s\f<)|\n\u0011]a&y";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = t[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(u[var4]);
            t[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            t[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  t[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(355743533992554L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = t[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = u[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  t[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(355743533992554L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        t[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(355743533992554L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 241;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 73;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 200;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 252;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 75;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 98;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 241;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 73;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 200;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fH_C0285",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fH" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(Weather var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fH_C0285;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fH_C0285", "lambda$new$0", "(Ljava/awt/Color;)Z"),
                  SourceSupport.methodType("(Ljava/awt/Color;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((Weather)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
