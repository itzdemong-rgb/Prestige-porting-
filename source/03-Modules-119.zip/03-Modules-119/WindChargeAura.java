package dev.zprestige.prestige.client.modules;
import net.minecraft.entity.projectile.WindChargeEntity;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.util.ElapsedTimer;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Set;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class WindChargeAura extends Module implements RotationSource {
   private FloatSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private BooleanSetting e;
   private ElapsedTimer f;
   private static final long k = 20083408894211L;
   private static final Object[] l = new Object[90];
   private static final String[] m = new String[90];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;

   public WindChargeAura() {
      super();
      long var10001 = 22129446069921L ^ 67693863838657L;

      this.f = new ElapsedTimer(45841753605472L);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Mace;
      return Set.of(var4);
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 73608466808436L;
      long var6 = var2 ^ 29159961624672L;
      long var8 = var2 ^ 22268501812649L;
      long var10 = var2 ^ 77379818547405L;
      long var12 = var2 ^ 69681875233263L;
      long var14 = var2 ^ 101783648619701L;
      long var16 = var2 ^ 100729554575240L;
      int var18 = Event.bReturningInt();
      MinecraftClient var23 = b;
      ClientPlayerEntity var24 = var23.player;
      byte var10000 = ((byte)((var24.isUsingItem()) ? 1 : 0));
      int var128 = var18;
      byte var127 = var10000;
      byte var97 = var127;
      byte var96 = var127;
      if (var128 == 0) {
         byte var129 = var96;
         if (var129 != 0) {
            return null;
         }

         BooleanSetting var27 = this.e;
         Boolean var28 = (Boolean)var27.aReturningObject();
         var97 = ((byte)(((java.lang.Boolean)(var28)).booleanValue() ? 1 : 0));
      }

      byte var101;
      int var131 = var18;
      byte var130 = var97;
      var101 = var130;
      byte var98 = var130;
      label141:
      if (var131 == 0) {
         byte var132 = var98;
         if (var132 != 0) {
            MinecraftClient var30 = b;
            ClientPlayerEntity var31 = var30.player;
            var10000 = ((byte)((var31.isOnGround()) ? 1 : 0));
            int var134 = var18;
            byte var133 = var10000;
            var101 = var133;
            byte var99 = var133;
            if (var134 != 0) {
               break label141;
            }

            byte var135 = var99;
            byte var100 = var135;
            byte var136 = var100;
            if (var136 != 0) {
               return null;
            }
         }

         var101 = ((byte)((AutoObbyCrystal.R) ? 1 : 0));
      }

      int var138 = var18;
      byte var137 = var101;
      byte var103 = var137;
      byte var102 = var137;
      if (var138 == 0) {
         byte var139 = var102;
         if (var139 != 0) {
            return null;
         }

         RotationManager var178 = Prestige.o;
         Object[] var38 = new Object[0];
         RotationManager var37 = var178;
         var103 = ((byte)((var37.fReturningBoolean(var38)) ? 1 : 0));
      }

      int var141 = var18;
      byte var140 = var103;
      byte var105 = var140;
      byte var104 = var140;
      if (var141 == 0) {
         byte var142 = var104;
         if (var142 != 0) {
            return null;
         }

         ElapsedTimer var179 = this.f;
         Object[] var10004 = new Object[]{null, var4};
         var10004[0] = 100.0F;
         Object[] var42 = var10004;
         ElapsedTimer var41 = var179;
         var105 = ((byte)((var41.aReturningBoolean(var42)) ? 1 : 0));
      }

      byte var108;
      label131: {
         int var144 = var18;
         byte var143 = var105;
         byte var107 = var143;
         byte var106 = var143;
         if (var144 == 0) {
            byte var145 = var106;
            if (var145 != 0) {
               var108 = 0;
               break label131;
            }

            var107 = 1;
         }

         byte var146 = var107;
         var108 = var146;
      }

      byte var19 = var108;
      Object[] var45 = new Object[]{var8};
      WindChargeAura var44 = this;
      Entity var20 = var44.aReturningEntity(var45);
      int var148 = var18;
      Entity var147 = var20;
      Entity var110 = var147;
      Entity var109 = var147;
      if (var148 == 0) {
         Entity var149 = var109;
         if (var149 == null) {
            return null;
         }

         var110 = var20;
      }

      Rotation var22;
      int var114;
      Entity var48 = var110;
      Box var49 = var48.getBoundingBox();
      Vec3d var21 = var49.getCenter();
      RotationManager var180 = Prestige.o;
      Object[] var51 = new Object[]{var21, var10};
      RotationManager var50 = var180;
      var22 = var50.aReturningdx_C0210(var51);
      BooleanSetting var52 = this.d;
      Boolean var53 = (Boolean)var52.aReturningObject();
      var10000 = ((byte)(((java.lang.Boolean)(var53)).booleanValue() ? 1 : 0));
      int var151 = var18;
      byte var150 = var10000;
      var114 = var150;
      byte var111 = var150;
      label124:
      if (var151 == 0) {
         byte var152 = var111;
         if (var152 != 0) {
            Object[] var56 = new Object[0];
            Rotation var55 = var22;
            var10000 = ((byte)((var55.aReturningBoolean(var56)) ? 1 : 0));
            int var154 = var18;
            byte var153 = var10000;
            var114 = var153;
            byte var112 = var153;
            if (var154 != 0) {
               break label124;
            }

            byte var155 = var112;
            byte var113 = var155;
            byte var156 = var113;
            if (var156 == 0) {
               Object[] var59 = new Object[]{var22, var21, var14};
               var22 = RotationUtil.dReturningdx_C0210(var59);
            }
         }

         Object[] var61 = new Object[0];
         Rotation var60 = var22;
         float var183 = var60.aReturningFloat(var61);
         MinecraftClient var62 = b;
         ClientPlayerEntity var63 = var62.player;
         float var184 = var183 - var63.getYaw();
         FloatSetting var64 = this.c;
         Float var65 = (Float)var64.aReturningObject();
         float var189;
         var114 = (var189 = var184 - var65 * 2.0F) == 0.0F ? 0 : (var189 < 0.0F ? -1 : 1);
      }

      int var158 = var18;
      int var157 = var114;
      int var116 = var157;
      int var115 = var157;
      if (var158 == 0) {
         int var159 = var115;
         if (var159 > 0) {
            return null;
         }

         Object[] var68 = new Object[0];
         Rotation var67 = var22;
         float var185 = var67.aReturningFloat(var68);
         MinecraftClient var69 = b;
         ClientPlayerEntity var70 = var69.player;
         float var186 = var185 - var70.getYaw();
         FloatSetting var71 = this.c;
         Float var72 = (Float)var71.aReturningObject();
         float var190;
         int var160 = (var190 = var186 - -var72 * 2.0F) == 0.0F ? 0 : (var190 < 0.0F ? -1 : 1);
         var116 = var160;
      }

      int var162 = var18;
      int var161 = var116;
      int var118 = var161;
      int var117 = var161;
      if (var162 == 0) {
         int var163 = var117;
         if (var163 < 0) {
            return null;
         }

         MinecraftClient var76 = b;
         Entity var78 = var20;
         ClientPlayerEntity var77 = var76.player;
         var118 = (((var77.canSee(var78)) ? 1 : 0));
      }

      int var165 = var18;
      int var164 = var118;
      int var120 = var164;
      int var119 = var164;
      if (var165 == 0) {
         int var166 = var119;
         if (var166 == 0) {
            return null;
         }

         Object[] var82 = new Object[]{var20, var12};
         WindChargeAura var81 = this;
         double var187 = var81.aReturningDouble(var82);
         FloatSetting var83 = this.a;
         Float var84 = (Float)var83.aReturningObject();
         double var191;
         var120 = (var191 = var187 - var84.floatValue()) == 0.0 ? 0 : (var191 < 0.0 ? -1 : 1);
      }

      int var168 = var18;
      int var167 = var120;
      int var122 = var167;
      int var121 = var167;
      if (var168 == 0) {
         int var169 = var121;
         if (var169 > 0) {
            return null;
         }

         var122 = var19;
      }

      int var171 = var18;
      int var170 = var122;
      int var125 = var170;
      int var123 = var170;
      if (var171 == 0) {
         int var172 = var123;
         if (var172 != 0) {
            return null;
         }

         int var174 = var18;
         Rotation var173 = var22;
         Rotation var126 = var173;
         Rotation var124 = var173;
         if (var174 != 0) {
            return var126;
         }

         Object[] var90 = new Object[0];
         Rotation var89 = var124;
         byte var175 = ((byte)((var89.aReturningBoolean(var90)) ? 1 : 0));
         var125 = var175;
      }

      int var176 = var125;
      if (var176 != 0) {
         return var22;
      }

      Object[] var93 = new Object[]{var20, var16};
      ItemUseUtil.aReturningVoid(var93);
      ElapsedTimer var188 = this.f;
      Object[] var95 = new Object[]{var6};
      ElapsedTimer var94 = var188;
      var94.aReturningVoid(var95);
      return var22;
   }

    private Entity aReturningEntity(Object[] objectArray) {
        long l = (Long)objectArray[0];
        l = 0x12440873F903L ^ l;
        WindChargeEntity windChargeEntity = null;
        double d = Double.MAX_VALUE;
        Iterator iterator = WindChargeAura.invokeBinding4(WindChargeAura.invokeBinding3(WindChargeAura.invokeBinding2(b, 5086733924432836875L, l), 5086035976163182639L, l), 5084771714624148267L, l);
        int n = WindChargeAura.invokeBinding1(5084098258890612414L, l);
        while (WindChargeAura.invokeBinding5(iterator, 5085338387770473276L, l)) {
            block24: {
                double d2;
                double d3;
                double d4;
                WindChargeEntity windChargeEntity2;
                block23: {
                    WindChargeEntity windChargeEntity3;
                    block22: {
                        WindChargeEntity windChargeEntity4;
                        block20: {
                            Entity entity;
                            block19: {
                                Entity entity2 = (Entity)WindChargeAura.invokeBinding6(iterator, 5083692785672273260L, l);
                                try {
                                    entity = entity2;
                                    if (n == 0) break block19;
                                    if (!(entity instanceof WindChargeEntity)) continue;
                                }
                                catch (MatchException matchException) {
                                    throw WindChargeAura.invokeBinding7(matchException, 5085062395270665727L, l);
                                }
                                entity = entity2;
                            }
                            windChargeEntity2 = (WindChargeEntity)entity;
                            try {
                                try {
                                    windChargeEntity4 = windChargeEntity2;
                                    if (n == 0) break block20;
                                    if (!WindChargeAura.invokeBinding8(windChargeEntity4, 5082759205192554639L, l)) {
                                        continue;
                                    }
                                }
                                catch (MatchException matchException) {
                                    throw WindChargeAura.invokeBinding9(matchException, 5085062395270665727L, l);
                                }
                            }
                            catch (MatchException matchException) {
                                throw WindChargeAura.invokeBinding10(matchException, 5085062395270665727L, l);
                            }
                            try {
                                windChargeEntity3 = windChargeEntity2;
                                if (n == 0) break block22;
                                windChargeEntity4 = ((net.minecraft.entity.projectile.WindChargeEntity)(Object)(WindChargeAura.invokeBinding11(windChargeEntity3, 5086771588722523115L, l)));
                            }
                            catch (MatchException matchException) {
                                throw WindChargeAura.invokeBinding12(matchException, 5085062395270665727L, l);
                            }
                        }
                        try {
                            if ((Object)windChargeEntity4 == WindChargeAura.invokeBinding13(b, 5083582523172576966L, l)) {
                                continue;
                            }
                        }
                        catch (MatchException matchException) {
                            throw WindChargeAura.invokeBinding14(matchException, 5085062395270665727L, l);
                        }
                        windChargeEntity3 = windChargeEntity2;
                    }
                    Vec3d vec3d = WindChargeAura.invokeBinding16(WindChargeAura.invokeBinding15(windChargeEntity3, 5082859757685221510L, l), 5084865910732401277L, l);
                    d4 = WindChargeAura.invokeBinding21(WindChargeAura.invokeBinding17(b, 5083582523172576966L, l), WindChargeAura.invokeBinding18(vec3d, 5084676159874708142L, l), WindChargeAura.invokeBinding19(vec3d, 5084589753504010586L, l), WindChargeAura.invokeBinding20(vec3d, 5083936711055103577L, l), 5086596318561926013L, l);
                    try {
                        double d5 = WindChargeAura.invokeBinding22(d4, 5085579775506862829L, l) - 5.0;
                        d3 = d5 == 0.0 ? 0 : (d5 > 0.0 ? 1 : -1);
                        if (n == 0) break block23;
                        if (d3 > 0) {
                            continue;
                        }
                    }
                    catch (MatchException matchException) {
                        throw WindChargeAura.invokeBinding23(matchException, 5085062395270665727L, l);
                    }
                    try {
                        d2 = d4;
                        if (n == 0) break block24;
                        double d6 = d2 - d;
                        d3 = d6 == 0.0 ? 0 : (d6 < 0.0 ? -1 : 1);
                    }
                    catch (MatchException matchException) {
                        throw WindChargeAura.invokeBinding24(matchException, 5085062395270665727L, l);
                    }
                }
                if (d3 < 0) {
                    windChargeEntity = windChargeEntity2;
                    d2 = d = d4;
                }
            }
            if (n != 0) continue;
        }
        return windChargeEntity;
    }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 38266410274184L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.dReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
   }

   private double aReturningDouble(Object[] var1) {
      Entity var4 = (Entity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 20083408894211L ^ var2;
      Vec3d var5 = invokeBinding26(invokeBinding25(b, 777619145488175744L, var2), 781290129084788273L, var2);
      Box var6 = invokeBinding27(var4, 776921494699242289L, var2);
      double var7 = invokeBinding31(
         invokeBinding28(var5, 780896418690957032L, var2),
         invokeBinding29(var6, 779171359192861024L, var2),
         invokeBinding30(var6, 779482420580880650L, var2),
         781171975723347844L,
         var2
      );
      double var9 = invokeBinding35(
         invokeBinding32(var5, 780877907734748444L, var2),
         invokeBinding33(var6, 778605178953607014L, var2),
         invokeBinding34(var6, 777491460217036788L, var2),
         781171975723347844L,
         var2
      );
      double var11 = invokeBinding39(
         invokeBinding36(var5, 777977733262711327L, var2),
         invokeBinding37(var6, 780283887311228877L, var2),
         invokeBinding38(var6, 780383953519301239L, var2),
         781171975723347844L,
         var2
      );
      double var13 = invokeBinding40(var5, 780896418690957032L, var2) - var7;
      double var15 = invokeBinding41(var5, 780877907734748444L, var2) - var9;
      double var17 = invokeBinding42(var5, 777977733262711327L, var2) - var11;
      return invokeBinding43(var13 * var13 + var15 * var15 + var17 * var17, 780724709526806187L, var2);
   }

   static {
      f();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 12;
            yield var15;
         }
         case 1 -> {
            byte var16 = 6;
            yield var16;
         }
         case 2 -> {
            byte var17 = 1;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 39;
            yield var19;
         }
         case 5 -> {
            byte var20 = 13;
            yield var20;
         }
         case 6 -> {
            byte var21 = 30;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 54;
            yield var23;
         }
         case 9 -> {
            byte var24 = 60;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 34;
            yield var26;
         }
         case 12 -> {
            byte var27 = 49;
            yield var27;
         }
         case 13 -> {
            byte var28 = 35;
            yield var28;
         }
         case 14 -> {
            byte var29 = 57;
            yield var29;
         }
         case 15 -> {
            byte var30 = 42;
            yield var30;
         }
         case 16 -> {
            byte var31 = 11;
            yield var31;
         }
         case 17 -> {
            byte var32 = 43;
            yield var32;
         }
         case 18 -> {
            byte var33 = 62;
            yield var33;
         }
         case 19 -> {
            byte var34 = 45;
            yield var34;
         }
         case 20 -> {
            byte var35 = 2;
            yield var35;
         }
         case 21 -> {
            byte var36 = 32;
            yield var36;
         }
         case 22 -> {
            byte var37 = 15;
            yield var37;
         }
         case 23 -> {
            byte var38 = 22;
            yield var38;
         }
         case 24 -> {
            byte var39 = 24;
            yield var39;
         }
         case 25 -> {
            byte var40 = 0;
            yield var40;
         }
         case 26 -> {
            byte var41 = 17;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 56;
            yield var43;
         }
         case 29 -> {
            byte var44 = 50;
            yield var44;
         }
         case 30 -> {
            byte var45 = 5;
            yield var45;
         }
         case 31 -> {
            byte var46 = 38;
            yield var46;
         }
         case 32 -> {
            byte var47 = 41;
            yield var47;
         }
         case 33 -> {
            byte var48 = 19;
            yield var48;
         }
         case 34 -> {
            byte var49 = 55;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 3;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 26;
            yield var53;
         }
         case 39 -> {
            byte var54 = 58;
            yield var54;
         }
         case 40 -> {
            byte var55 = 63;
            yield var55;
         }
         case 41 -> {
            byte var56 = 53;
            yield var56;
         }
         case 42 -> {
            byte var57 = 31;
            yield var57;
         }
         case 43 -> {
            byte var58 = 7;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 18;
            yield var60;
         }
         case 46 -> {
            byte var61 = 14;
            yield var61;
         }
         case 47 -> {
            byte var62 = 36;
            yield var62;
         }
         case 48 -> {
            byte var63 = 10;
            yield var63;
         }
         case 49 -> {
            byte var64 = 16;
            yield var64;
         }
         case 50 -> {
            byte var65 = 47;
            yield var65;
         }
         case 51 -> {
            byte var66 = 23;
            yield var66;
         }
         case 52 -> {
            byte var67 = 51;
            yield var67;
         }
         case 53 -> {
            byte var68 = 48;
            yield var68;
         }
         case 54 -> {
            byte var69 = 40;
            yield var69;
         }
         case 55 -> {
            byte var70 = 28;
            yield var70;
         }
         case 56 -> {
            byte var71 = 9;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 37;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 20;
            yield var76;
         }
         case 62 -> {
            byte var77 = 27;
            yield var77;
         }
         default -> 25;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "Q\rLE\u000e>G\rI\u001f\u001d)PFJ\u0019\u0011=A\u0001]\u000eZ(|";
      l[1] = "/8+S\u001bi$7:\u001cxd1:5wMf ))[Zk";
      l[2] = "GO\u001e)VGQO\u001bsEPF\u0004\u0018uIDWC\u000fb\u0002Vf";
      l[3] = int.class;
      m[3] = "java/lang/Integer";
      l[4] = "\rZC=[|\u001bZFgHk\f\u0011EaD\u007f\u001dVRv\u000fj0";
      l[5] = "'o[R,0ROP]=\u007f3A[V9%G";
      l[6] = boolean.class;
      m[6] = "java/lang/Boolean";
      l[7] = "\fr?g\t yR4h\u0018o\u0018\\?c\u001c5l";
      l[8] = "X\u0019\u0017/3-X\u0019\u0000s?\"BR\u0000m?7E#R3gs";
      l[9] = "@sr9V'5Sy6GhT]r=C2 ";
      l[10] = double.class;
      m[10] = "java/lang/Double";
      l[11] = "\u0014\u000e\thGv\u0014\u000e\u001e4Ky\u000eE\u001e*Kl\t4Jr\u001c";
      l[12] = float.class;
      m[12] = "java/lang/Float";
      l[13] = "5kL\u0001O=>d]N#>0f_\u0001\u000f";
      l[14] = "\u001c.\\sd@\u001c.K/hO\u0006eK1hZ\u0001\u0014\u001an1";
      l[15] = "SdSO\r\u001fEdV\u0015\u001e\bR/U\u0013\u0012\u001cChB\u0004Y\f[";
      l[16] = "A0\u007f^A\\4\u0010tQP\u0013U\u001e\u007fZTI!";
      l[17] = void.class;
      m[17] = "java/lang/Void";
      l[18] = "\u001a\u0013\u001d/\fr\f\u0013\u0018u\u001fe\u001bX\u001bs\u0013q\n\u001f\fdXf\u0006";
      l[19] = "?:B\\*\u0016J\u001aIS;Y+\u0014BX?\u0003_";
      l[20] = "i\u0004hDgW\u007f\u0004m\u001et@hOn\u0018xTy\by\u000f3Ct";
      l[21] = ")\u000fB\u0014O-\\/I\u001b^b=!B\u0010Z8I";
      l[22] = "\u0011s%>vq\u0007s def\u00108#bir\u0001\u007f4u\"e3";
      l[23] = "0wt<#~;xesBp0sa)";
      l[24] = "\u0015rK0p\u0018\u0015r\\l|\u0017\u000f9\\r|\u0002\bH\f/-";
      l[25] = "G\b\\Z;6L\u0007M\u0015S6B\b^";
      l[26] = "=J\u0018+5rHj\u0013$$=)d\u0018/ g]";
      l[27] = "-S*z%1Xs!u4~9}*~0$M";
      l[28] = "*~\u0016\u0007?\u0001<~\u0013],\u0016+5\u0010[ \u0002:r\u0007Lk\u0012\"r\u0005G1_\u001ei\u0005Z1\u0018)~";
      l[29] = "D%A\b\u000fr1\u0005J\u0007\u001e=P\u000bA\f\u001ag$";
      l[30] = "'UP\u0006w31UU\\d$&\u001eVZh07YAM#'\u0001";
      l[31] = "=%$\u0001B\"H\u0005/\u000eSm)\u000b$\u0005W7]";
      l[32] = "X70+R?X7'w^0B|'i^%E\rv1\f";
      l[33] = "\u0019o}vLTlOvy]\u001b\rA}rYAy";
      l[34] = "ZW\u0006\t\u0003\u0012QX\u0017F`\u001fD^";
      l[35] = "u\u0002\u0001U\f\u0012u\u0002\u0016\t\u0000\u001doI\u0016\u0017\u0000\bh8FNRI";
      l[36] = "hMM?8\u000evEWpE\u001ev";
      l[37] = "m\u001a\u00009\u000b\tm\u001a\u0017e\u0007\u0006wQ\u0017{\u0007\u0013p L.SV";
      l[38] = "U:0^A{^5!\u0011&cZ)']\u0003r";
      l[39] = "[1l!;NE9vn\\OT\"{4zI";
      l[40] = "#gLfSe#g[:_j9,[$_\u007f>]\u000e{\u0006";
      l[41] = "\u0003~q.B9v^z!Sv\u0017Pq*W,c";
      l[42] = "\u0001$_8P:\u001b/I:;1\u0015bF-W\u0003E.\u001c{;e\u0003bZ3G+\u001a{AJ";
      l[43] = "?\u0015|e\u001c)%\u001ejgw\"+Sep\u001b\u0010{\u001f=*w{)D:h\u000e;)B=\u0017";
      l[44] = "B\u0014NSuC\u0017\t\u0006\u0004\u000fN{H\u0003\u000e0T\u0006\u001cZY2$";
      l[45] = "eI0\u0018R\u001f+P)\u0003+\r5_(\b|Zo\bvd\u0014Y*M|\u000f\u0017\u001e-\u0003";
      l[46] = "-d\"\\;^qbr7<&kfqG$\u001e,s/ZU\u001b`h \u000e,\u001d)sw7";
      l[47] = "Y{\u0012r]a\u0005}B\u0019Z\u0019\u001fyAiB!Xl\u001ft3&^b\u0006)X%\u0019eH\u0019";
      l[48] = "\r\u0011VA5\u0017\fMGA_\u0010\u001brX\u0005%\u001a\u0014NQ\u0007n\u0013u\nT_ \u001d\u0015\u000b\bN w";
      l[49] = "tF$\u0004/\u0018/\u0004\u007f\u0016\u0017C&G#\u001f{qp\u0005\u007fE+&{F|\u0013*X9C,\u0006\u0017";
      l[50] = "(E\u0006i{Y+\u0015\u0001)\u0016\\E^\u0001!fA}\u0019\u0014\u007f{0.H\u001f#)\u000f~D\u0005u\u0016";
      l[51] = "Lz0;gr\u001dxk.\u000e&\u001av0)g*#x09cLA~?{q5\u0001~9|\u000e";
      l[52] = "ab\\>^V4\u007f\u0014i$ZX>\u0011c\u001bA%jH4\u00191";
      l[53] = "em\u0018lp3c$\u0003;I/5a\u0013b%\u001de-I4I{#a\u000f|55:x\u0014\u0005";
      l[54] = "#5q~~Mxw*lF\u0016q4ve*$&t&8vs '}=9\n`'{:F";
      l[55] = "oFuU\u000b\noS|Oy\u0019\u0006At\u0014\t\u0001>\u0006aJ\u0014pmWj\u0016FO=[p@y";
      l[56] = "9.\u0017\u0016L.:~\u0010V!)T5\u0010^Q6lr\u0005\u0000LGh!\u001eY^>(!\u0018^!";
      l[57] = ":\u0014}\b\"$.\u0006\"V].T\u0010(O0&h\u0019*\u00049G";
      l[58] = ":\u000bI\u001b}\"=\u0007KN\u0007.>\fRHPyd\\\u000e$8z!\u001e\u0006O;=&P";
      l[59] = "!\u001b\u000fjhbzYTxP9s\u001a\bq<\u000b ^U)Pan\r\u0001/)g'\u0016V\u0016l3uY\u0017o,3s^h";
      l[60] = "%~\u0019c\u001e4&.\u001e#s0He\u001e+\u0003,p\"\u000bu\u001e]#s\u0000)Lbs\u007f\u001a\u007fs";
      l[61] = "\u0017W_\u007fS]YNFd*OGAGo}\u0018\u001d\u0016\u001e\u0003\u0015\u001bXS\u0013h\u0016\\_\u001d";
      l[62] = "\u000b6WA{^\u0012f\u001d\u0019KU\u001c*Y%$\b\u000b7D\u0019-\n@>%";
      l[63] = "nB?6g,4\u00062*\f\u007fo\u00160&[(1AhJ3li\u0007lth.2\u0015";
      l[64] = "C\u00040z>\u001f\u001bSp(\u0006\u001dxO-\u007fv\u0005@\b8!kt\u0013Y3}9KCU)+\u0006";
      l[65] = "\u000e\u001cHm\u0013+\u0001\\\u000eb~3e\u0016\u0012:\u000e+]Q\u0007d\u0013ZU\u0010HiC$\u0017\u0015\u0018|~";
      l[66] = "`\u0012\u0013|\u001b]p\n\t3'J\u0002\u001e\u0012 W@k\u001dB'\u0017";
      l[67] = "\u001b?F#\n#\r{\u001b}r3\u0005{]\u001eMr\u0002~\u0011uN5\u00050!!H6\u00031J\"\u000f1M\u0001";
      l[68] = "\u0010[c\u0019\n\b^Bz\u0002s\u001a@M{\t$M\u001a\u001a#eLN__/\u000eO\tX\u0011";
      l[69] = "\u000er\u0002}tw@k\u001bf\re^d\u001amZ2\u00043G\u000121AvNj1vF8";
      l[70] = "jq\u0010Exas!Z\u001dHlyf$L8p\u0010!\rJwsia\rLp\f";
      l[71] = "_\u0011O^<jNPY\u0019Bg<\u0017ZX2z\u0004PO\u0006/\u000bW\u001d\u0000\u000f/zX]F\u0000B";
      l[72] = "Kq\u0004<YVVj\u00114!MAv\u0000=M\u007f\u00157[g\u0019(\u00130\u001e%\u0011C\u0010w\u0019k!\u0017\u0016t\u001fjJ\u0014QsQZ\u001e\u0012RuP1\u001dUU;`e\u001bVS:\u000bf\\Q\u001d\n";
      l[73] = "K5\t/0\u0012\u0005,\u00104I\u000b\u00172\u00154%9CvMnI\u000b\u00101J)+\f\u001c3\u001fS";
      l[74] = "kio\fr\u001a7o?gubo6v[#]ot}\\\u001c[n|8X#[,w?g";
      l[75] = "\u001blGF+p@.\u001cT\u0013+Im@]\u007f\u0019\u001f*\u001d\u0005*NA{_\u0005i,Fw]P\u0013";
      l[76] = "a\u0016sq)Jf\u001aq$SFe\u0011h\"\u0004\u0011?A6Nl\u0012z\u0003<%oU}M";
      l[77] = "Z\u0002ND]3]\u000eL\u0011'?^\u0005U\u0017ph\u0004U\b{\u0018kA\u0017\u0001\u0010\u001b,FY";
      l[78] = "uOV@q\u001e-\u0018\u0016\u0012I\u001cN\u0004KE9\u0004vC^\u001b$ur\u0010EB6\f2\u0010CEI";
      l[79] = "\\\u0018NS~!Z\u001c\u001aL\u001cxY\u000eP@`~_cPEn}\u0015\u000eI\u0015$%%";
      l[80] = "\u00016L\u0005gZO/U\u001e\u001eHQ T\u0015I\u001f\u000bw\by!\u001cN2\u0000\u0012\"[I|";
      l[81] = " *xJ\rv{h#X5-r+\u007fQY\u001f\"i#\u00075w%)`\u0006^tb..6\nra(/]\t5ff\u001f\t\u000f6`gt\nH1.W \fK7/<#KLy\u001f";
      l[82] = "\u001a~Lg&U\u0000uZeM^\u000e8Ur!lYx\u0004/t;^4^|tBX}E+M";
      l[83] = "0*^@\fMjnS\\g\u001e1~QP0In#\n<\u001cJax\fU\u0005\u001c)z";
      l[84] = "o\u0003=!H\n`C{.%\u0012\u0004\tgvU\n<Nr(H{8\u001diqZ\u0002x\u001dov%";
      l[85] = "1I^?$\u0007\u007fPG$]\u0015a_F/\nB;\b\u0019CbA~M\u0012(a\u0006y\u0003";
      l[86] = "T\u001dA\u001e\u007f\u000eM\u001eAV\u0012\u001aP\u001eO\u001bL\u001dP\u0004Kg\"\t\u000b\u0012\u001b\u0019`\f[\u0007&";
      l[87] = "v:<\u0001x\u0012uj;A\u0015\u0012\u001b!;Ie\n#f.\u0017x{p+a\u001ex\n\u007fk'\u0011\u0015";
      l[88] = "\u00147awQSOu:ei\bF6fl\u0005:\u0015s?6iQD!9t\u0010\u0011D'>\u000b";
      l[89] = "0C#Yn\u000f)\u0015k[W\u0003&\u0005rU;1rI+\u000bmf2\u0002vH5^4\u0006\"WW";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(1635570039984681L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(1635570039984681L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(1635570039984681L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 239;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 110;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 192;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 216;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 208;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 239;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 110;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 192;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fI_C0287",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fI" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static ClientWorld invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = b(
                  MethodHandles.lookup(),
                  "ï",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/world/ClientWorld;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ClientWorld)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Iterable invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Iterable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Iterable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Iterator invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Iterator;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Iterator)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = b(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static boolean invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Entity invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/entity/Entity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Entity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = b(
                  MethodHandles.lookup(),
                  "ï",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Box invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Box;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Box)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = b(
                  MethodHandles.lookup(),
                  "ï",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding21(Object var0, double var1, double var3, double var5, long var7, long var9) {
         MethodHandle var15 = bindingCache21;
         MethodHandle var14 = bindingCache21;
         MethodHandle var12 = var14;
         if (var15 == null) {
            var12 = bindingCache21 = b(MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;DDDJJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var12.invokeExact((Object)var0, (double)var1, (double)var3, (double)var5, (long)var7, (long)var9);
      } catch (Throwable var16) {
         throw SourceSupport.rethrow(var16);
      }
   }

   private static double invokeBinding22(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = b(
                  MethodHandles.lookup(), "Ð", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static ClientPlayerEntity invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = b(
                  MethodHandles.lookup(),
                  "ï",
                  SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/network/ClientPlayerEntity;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ClientPlayerEntity)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vec3d invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Vec3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Vec3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Box invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = b(
                  MethodHandles.lookup(), "Ø", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/util/math/Box;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Box)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding31(double var0, double var2, double var4, long var6, long var8) {
         MethodHandle var14 = bindingCache31;
         MethodHandle var13 = bindingCache31;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache31 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(DDDJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var11.invokeExact((double)var0, (double)var2, (double)var4, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static double invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding35(double var0, double var2, double var4, long var6, long var8) {
         MethodHandle var14 = bindingCache35;
         MethodHandle var13 = bindingCache35;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache35 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(DDDJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var11.invokeExact((double)var0, (double)var2, (double)var4, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static double invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding39(double var0, double var2, double var4, long var6, long var8) {
         MethodHandle var14 = bindingCache39;
         MethodHandle var13 = bindingCache39;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache39 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(DDDJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var11.invokeExact((double)var0, (double)var2, (double)var4, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static double invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = b(MethodHandles.lookup(), "ï", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding43(double var0, long var2, long var4) {
         MethodHandle var10 = bindingCache43;
         MethodHandle var9 = bindingCache43;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache43 = b(MethodHandles.lookup(), "Ð", SourceSupport.methodType("(DJJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var7.invokeExact((double)var0, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
