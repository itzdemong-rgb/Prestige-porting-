package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.LightmapEvent;
import dev.zprestige.prestige.api.events.BlockVisibilityEvent;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.WorldRenderer;

public class XRay extends Module {
   private BooleanSetting d;
   public static List a;
   private static final long k = 127458100088230L;
   private static final Object[] l = new Object[91];
   private static final String[] m = new String[91];

   @Override
   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 70868749815782L;
      Object[] var7 = new Object[]{var4};
      XRay var6 = this;
      var6.jReturningVoid(var7);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 124782924579835L;
      Object[] var7 = new Object[]{var4};
      XRay var6 = this;
      var6.jReturningVoid(var7);
   }

   @EventListener
   public void a(LightmapEvent var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      boolean var8 = var5;
      if (var8) {
         Object[] var7 = new Object[0];
         LightmapEvent var6 = var1;
         var6.aReturningVoid(var7);
      }
   }

   @EventListener
   public void a(BlockVisibilityEvent var1) {
      long var10001 = 49759911918532L ^ 96432293991323L;
      int var6 = Event.bReturningInt();
      int var23 = var6;
      BlockVisibilityEvent var22 = var1;
      BlockVisibilityEvent var21 = var22;
      BlockVisibilityEvent var20 = var22;
      if (var23 == 0) {
         Object[] var8 = new Object[0];
         BlockVisibilityEvent var7 = var20;
         Block var24 = var7.aReturningBlock(var8);
         if (var24 != null) {
            Object[] var11 = new Object[0];
            BlockVisibilityEvent var10 = var1;
            Object[] var13 = new Object[]{var10.aReturningBlock(var11), 135195999037535L};
            XRay var12 = this;
            boolean var25 = var12.aReturningBoolean(var13);
            if (var25) {
               Object[] var16 = new Object[]{true};
               BlockVisibilityEvent var15 = var1;
               var15.bReturningVoid(var16);
            }
         }

         var21 = var1;
      }

      Object[] var19 = new Object[0];
      BlockVisibilityEvent var18 = var21;
      var18.aReturningVoid(var19);
   }

   public boolean aReturningBoolean(Object[] var1) {
      Block var2 = (Block)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 127458100088230L ^ var3;
      Block var6 = var2;
      List var5 = a;
      return var5.contains(var6);
   }

   public void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 127458100088230L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var5 = b;
      int var14 = var4;
      WorldRenderer var13 = var5.worldRenderer;
      WorldRenderer var12 = var13;
      WorldRenderer var11 = var13;
      if (var14 != 0) {
         WorldRenderer var15 = var11;
         if (var15 == null) {
            return;
         }

         MinecraftClient var7 = b;
         WorldRenderer var8 = var7.worldRenderer;
         var8.reload();
         MinecraftClient var9 = b;
         var12 = var9.worldRenderer;
      }

      WorldRenderer var10 = var12;
      var10.scheduleTerrainUpdate();
   }

   static {

      {

      f();
      Cipher var1;
      Cipher var10000 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(16969395133292L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[49];
      String var5 = "UÉýêß¨Y¾\u0099âÌö\u008f$\u001aÍ\u0085µ 4\u0016\u0087÷ó$þE»ùÁBå\u008fN\u0003ëÅýË\u0087\u0087¿mÚn²ÜN\u0085\u0088c°1í\u009f\u008ccÜ£\u0006tÌÈðØ\u009fëa\u0017Y\u0002ñÄ°·6\u001c\u0018ºpîw\u0085ò/¶Ï°È&FÔ¦#\u009ej´:2\u008bÇ\u001d\u0090)\u0016\u0015\u001d\u0005yúrÀ\u007fÍ;V@8\u0000øªOe\u0013»åB^\u00ad\u0090\u009e²-^ÉãÏF\u0081®&\u0018\u0098Gdê\u0098E,nÀ\u0097iïK\u0097¿\u0081çB`\u009eúÌÊê#º©\u0087y}Z*\nì4µI\u0084_²+h1ñ5Û8qÉÑO<\u0019,¿\u0006Âñ\u0087mÁ\u0002$\u000eÝÕ\u0090êF_à\u00ad\u0087}IEñ\tìÄk\u008eKT¯1\u009eä\u0084º=AMÿ1|ç\u0081L+\u001b.\u0003³±îÁÓAÆÄ\u00986b]*ë\u0018t©¨«\u0080ØD\u0018ùö(\u009dü*®«Â7\u0089¿ôìÏá \u008fUQö.-@F;Å(m)\u009a0\u0011(sÓåö=y]\u009d¶¤µ\\·[\u0010>\u0080\u0097.eD\u009dVÖÖM@p\u0015T2\u001fn!ÿùÖôc\u0099\nÂ\u0082|Ô©\u008d»y<\u001cÈ7Qù¦J¦ÆIªþ¯\u0010Ê\u0001\u0084ëø¹\u001bH\u009bX";
      int var6 = "UÉýêß¨Y¾\u0099âÌö\u008f$\u001aÍ\u0085µ 4\u0016\u0087÷ó$þE»ùÁBå\u008fN\u0003ëÅýË\u0087\u0087¿mÚn²ÜN\u0085\u0088c°1í\u009f\u008ccÜ£\u0006tÌÈðØ\u009fëa\u0017Y\u0002ñÄ°·6\u001c\u0018ºpîw\u0085ò/¶Ï°È&FÔ¦#\u009ej´:2\u008bÇ\u001d\u0090)\u0016\u0015\u001d\u0005yúrÀ\u007fÍ;V@8\u0000øªOe\u0013»åB^\u00ad\u0090\u009e²-^ÉãÏF\u0081®&\u0018\u0098Gdê\u0098E,nÀ\u0097iïK\u0097¿\u0081çB`\u009eúÌÊê#º©\u0087y}Z*\nì4µI\u0084_²+h1ñ5Û8qÉÑO<\u0019,¿\u0006Âñ\u0087mÁ\u0002$\u000eÝÕ\u0090êF_à\u00ad\u0087}IEñ\tìÄk\u008eKT¯1\u009eä\u0084º=AMÿ1|ç\u0081L+\u001b.\u0003³±îÁÓAÆÄ\u00986b]*ë\u0018t©¨«\u0080ØD\u0018ùö(\u009dü*®«Â7\u0089¿ôìÏá \u008fUQö.-@F;Å(m)\u009a0\u0011(sÓåö=y]\u009d¶¤µ\\·[\u0010>\u0080\u0097.eD\u009dVÖÖM@p\u0015T2\u001fn!ÿùÖôc\u0099\nÂ\u0082|Ô©\u008d»y<\u001cÈ7Qù¦J¦ÆIªþ¯\u0010Ê\u0001\u0084ëø¹\u001bH\u009bX"
         .length();
      label24:
      while (true) {
         int var10001 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var10001, var3).getBytes("ISO-8859-1");
         long[] var15 = var0;
         var10001 = var4++;
         long var19 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         
            long var8 = var19;
            byte[] var10 = var1.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var23 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var21) {
               case 0:
                  var15[var10001] = var23;
                  if (var3 >= var6) {
                     Block[] var16 = new Block[(int)var0[38]];
                     var16[0] = Blocks.EMERALD_ORE;
                     var16[1] = Blocks.EMERALD_BLOCK;
                     var16[2] = Blocks.DIAMOND_ORE;
                     var16[3] = Blocks.DIAMOND_BLOCK;
                     var16[4] = Blocks.GOLD_ORE;
                     var16[5] = Blocks.GOLD_BLOCK;
                     var16[(int)var0[7]] = Blocks.IRON_ORE;
                     var16[(int)var0[2]] = Blocks.IRON_BLOCK;
                     var16[(int)var0[0]] = Blocks.COAL_ORE;
                     var16[(int)var0[48]] = Blocks.COAL_BLOCK;
                     var16[(int)var0[39]] = Blocks.REDSTONE_ORE;
                     var16[(int)var0[35]] = Blocks.REDSTONE_BLOCK;
                     var16[(int)var0[32]] = Blocks.LAPIS_ORE;
                     var16[(int)var0[33]] = Blocks.LAPIS_BLOCK;
                     var16[(int)var0[17]] = Blocks.NETHER_QUARTZ_ORE;
                     var16[(int)var0[28]] = Blocks.NETHER_GOLD_ORE;
                     var16[(int)var0[10]] = Blocks.DEEPSLATE_EMERALD_ORE;
                     var16[(int)var0[40]] = Blocks.DEEPSLATE_DIAMOND_ORE;
                     var16[(int)var0[45]] = Blocks.DEEPSLATE_GOLD_ORE;
                     var16[(int)var0[26]] = Blocks.DEEPSLATE_IRON_ORE;
                     var16[(int)var0[3]] = Blocks.DEEPSLATE_COAL_ORE;
                     var16[(int)var0[23]] = Blocks.ANCIENT_DEBRIS;
                     var16[(int)var0[37]] = Blocks.WATER;
                     var16[(int)var0[5]] = Blocks.LAVA;
                     var16[(int)var0[46]] = Blocks.OBSIDIAN;
                     var16[(int)var0[34]] = Blocks.CRYING_OBSIDIAN;
                     var16[(int)var0[29]] = Blocks.BEACON;
                     var16[(int)var0[11]] = Blocks.ENDER_CHEST;
                     var16[(int)var0[25]] = Blocks.CHEST;
                     var16[(int)var0[44]] = Blocks.TRAPPED_CHEST;
                     var16[(int)var0[21]] = Blocks.BARREL;
                     var16[(int)var0[9]] = Blocks.HOPPER;
                     var16[(int)var0[1]] = Blocks.FURNACE;
                     var16[(int)var0[13]] = Blocks.BLAST_FURNACE;
                     var16[(int)var0[31]] = Blocks.SMOKER;
                     var16[(int)var0[12]] = Blocks.ANVIL;
                     var16[(int)var0[27]] = Blocks.ENCHANTING_TABLE;
                     var16[(int)var0[47]] = Blocks.BREWING_STAND;
                     var16[(int)var0[36]] = Blocks.DISPENSER;
                     var16[(int)var0[14]] = Blocks.DROPPER;
                     var16[(int)var0[30]] = Blocks.GLOWSTONE;
                     var16[(int)var0[19]] = Blocks.SEA_LANTERN;
                     var16[(int)var0[18]] = Blocks.TORCH;
                     var16[(int)var0[42]] = Blocks.SOUL_TORCH;
                     var16[(int)var0[15]] = Blocks.CAMPFIRE;
                     var16[(int)var0[24]] = Blocks.SOUL_CAMPFIRE;
                     var16[(int)var0[20]] = Blocks.SPAWNER;
                     var16[(int)var0[6]] = Blocks.END_PORTAL_FRAME;
                     var16[(int)var0[16]] = Blocks.END_GATEWAY;
                     var16[(int)var0[43]] = Blocks.NETHER_PORTAL;
                     var16[(int)var0[22]] = Blocks.MOSSY_COBBLESTONE;
                     var16[(int)var0[4]] = Blocks.STONE_BRICKS;
                     var16[(int)var0[8]] = Blocks.OAK_PLANKS;
                     var16[(int)var0[41]] = Blocks.NOTE_BLOCK;
                     Block[] var13 = var16;
                     a = Arrays.asList(var13);
                     break;
                  }
                  break;
               default:
                  var15[var10001] = var23;
                  if (var3 < var6) {
                     continue label24;
                  }

                  var5 = "\u0014\u0083\u0014Di¼\u0087\u0007A\u0015íÚL²\u0097w";
                  var6 = "\u0014\u0083\u0014Di¼\u0087\u0007A\u0015íÚL²\u0097w".length();
                  var3 = 0;
            }

            int var18 = var3;
            var3 += 8;
            var7 = var5.substring(var18, var3).getBytes("ISO-8859-1");
            var15 = var0;
            var10001 = var4++;
            var19 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var21 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 42;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 8;
            yield var18;
         }
         case 4 -> {
            byte var19 = 61;
            yield var19;
         }
         case 5 -> {
            byte var20 = 3;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 2;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 23;
            yield var24;
         }
         case 10 -> {
            byte var25 = 44;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 27;
            yield var27;
         }
         case 13 -> {
            byte var28 = 36;
            yield var28;
         }
         case 14 -> {
            byte var29 = 48;
            yield var29;
         }
         case 15 -> {
            byte var30 = 22;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 63;
            yield var32;
         }
         case 18 -> {
            byte var33 = 54;
            yield var33;
         }
         case 19 -> {
            byte var34 = 7;
            yield var34;
         }
         case 20 -> {
            byte var35 = 1;
            yield var35;
         }
         case 21 -> {
            byte var36 = 49;
            yield var36;
         }
         case 22 -> {
            byte var37 = 53;
            yield var37;
         }
         case 23 -> {
            byte var38 = 11;
            yield var38;
         }
         case 24 -> {
            byte var39 = 56;
            yield var39;
         }
         case 25 -> {
            byte var40 = 45;
            yield var40;
         }
         case 26 -> {
            byte var41 = 0;
            yield var41;
         }
         case 27 -> {
            byte var42 = 35;
            yield var42;
         }
         case 28 -> {
            byte var43 = 16;
            yield var43;
         }
         case 29 -> {
            byte var44 = 46;
            yield var44;
         }
         case 30 -> {
            byte var45 = 28;
            yield var45;
         }
         case 31 -> {
            byte var46 = 15;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 59;
            yield var48;
         }
         case 34 -> {
            byte var49 = 40;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 60;
            yield var52;
         }
         case 38 -> {
            byte var53 = 19;
            yield var53;
         }
         case 39 -> {
            byte var54 = 33;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 5;
            yield var56;
         }
         case 42 -> {
            byte var57 = 21;
            yield var57;
         }
         case 43 -> {
            byte var58 = 14;
            yield var58;
         }
         case 44 -> {
            byte var59 = 29;
            yield var59;
         }
         case 45 -> {
            byte var60 = 55;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 18;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 47;
            yield var65;
         }
         case 51 -> {
            byte var66 = 50;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 13;
            yield var69;
         }
         case 55 -> {
            byte var70 = 62;
            yield var70;
         }
         case 56 -> {
            byte var71 = 39;
            yield var71;
         }
         case 57 -> {
            byte var72 = 24;
            yield var72;
         }
         case 58 -> {
            byte var73 = 32;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 30;
            yield var75;
         }
         case 61 -> {
            byte var76 = 10;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      l[0] = "\u0019.\u000bQP}\u0007&\u0011\u001e2a\u0000;";
      l[1] = "C>1;X7H1 t99C:$.";
      l[2] = boolean.class;
      m[2] = "java/lang/Boolean";
      l[3] = "i$7tm\u0004\u007f$2.~\u0013ho1(r\u0007y(&?9\u0012G";
      l[4] = "8q|3\rx3~m|nu&sb\u0017[w7`~;Lz";
      l[5] = "T{Q/WvB{TuDaU0WsHuDw@d\u0003d{";
      l[6] = "G6\f`UD2\u0016\u0007oD\u000bS\u0018\fd@Q'";
      l[7] = "NU\u001ftz$NU\b(v+T\u001e\b6v>SoYh#u";
      l[8] = "H]:[6#^]?\u0001%4I\u0016<\u0007) XQ+\u0010b2i";
      l[9] = int.class;
      m[9] = "java/lang/Integer";
      l[10] = "gO\u0001H\u0003'\u0012o\nG\u0012hsa\u0001L\u00162\u0007";
      l[11] = "x8z35n\r\u0018q<$!l\u0016z7 {\u0018";
      l[12] = void.class;
      m[12] = "java/lang/Void";
      l[13] = "dI:8I7\u0011i17Xxpg:<\\\"\u0004";
      l[14] = "^j\u0000*5\u0017^j\u0017v9\u0018D!\u0017h9\rCPF6lH";
      l[15] = "f\u0005)\u0010P2x\r3_?5~\u0005&\u0002";
      l[16] = "A])\u001eR54}\"\u0011CzUs)\u001aG !";
      l[17] = "vk|\u0019D'}dmV($sfo\u0019\u0004";
      l[18] = "kE\b\u001cq_}E\rFbHj\u000e\u000e@n\\{I\u0019W%KI";
      l[19] = "\u0004\u0017kx\u001e q7`w\u000fo\u00109k|\u000b5d";
      l[20] = "j\\2(C\u001ej\\%tO\u0011p\u0017%jO\u0004wfq0\u001f";
      l[21] = "\u000fR@3UK\u000fRWoYD\u0015\u0019WqYQ\u0012h\u0007,\b";
      l[22] = "\u001fl\u0004lQ\u001a\u000fb\u001a(i\u0013\u0017m\u0005\u007f>DN>X(i@Ja\u0001#\f\u0017\u0010e\u0000";
      l[23] = "K\u0010\u0018_pv[\u001e\u0006\u001bH\u007fC\u0011\u0019L\u001f+\u0018EE\u0011H,\u001e\u001d\u001d\u0010-{D\u0019\u001c";
      l[24] = "vBvRG\nfLh\u0016\u007f\u0003~CwA(T'\u0017-\u0011\u007fP#Os\u001d\u001a\u0007yKr";
      l[25] = "^y|rP\rNwb6h\u0004Vx}a?S\u000f(%5hW\u000bty=\r\u0000Qpx";
      l[26] = "MYCmYI]W])a@EXB~6\u0017\u001c\u000f\u001c\"a\u0013\u0018TF\"\u0004DBPG";
      l[27] = "%$\u001aKF\\5*\u0004\u000f~U-%\u001bX)\u0001}rE\f~\u0006p)\u001f\u0004\u001bQ*-\u001e";
      l[28] = "2J jZ+\"D>.b\":K!y5uc\u001ay.bqgG%%\u0007&=C$";
      l[29] = "r!\u000eD\nSdg\u000fYq\bs#R]\u001d:%e\u0003\u0000q]x#L\u0004M\u0012z3N:";
      l[30] = "Rk\u0005\u00053ABe\u001bA\u000bHZj\u0004\u0016\\\u001c\u00007^B\u000b\u001b\u0007f\u0000JnL]b\u0001";
      l[31] = "D1\u0004\u0004r\u0016T?\u001a@J\u001fL0\u0005\u0017\u001dK\u001ce[JJL\u0011<\u0001K/\u001bK8\u0000";
      l[32] = "b>\u0016Bj\f%?\tC\u0012\u0004^i\u0017\u0019(\u000bg5\u001d@.nnc\n\u0007,R!a\u001a\u0005\u0012";
      l[33] = "RCB-\u0015F\rYIw,MoUSr\u0016AV\tY+\u0010$__Nl\u0012\u0018\u0010]^n,";
      l[34] = "lG\u001b\u0000\u000e*|I\u0005D6#dF\u001a\u0013at=\u0017BF6p9J\u001eOS'cN\u001f";
      l[35] = "\u0019I%Kl\u0012\u0010S*:gE\u0014^\"[jYrZ*\u0003nG\u0015\u001etH\f\u0018HE'UlIJ\u00134:";
      l[36] = "P\u0016R\u001f\u0017\u0000@\u0018L[/\tX\u0017S\fx^\u0001@\tX/Z\u0005\u001bWPJ\r_\u001fV";
      l[37] = "m~d\u0007!)}pzC\u0019 e\u007fe\u0014Nw<*0@\u0019s8saH|$bw`";
      l[38] = "\r;)s$E\u001d577\u001cL\u0005:(`K\u001b\\l|5\u001c\u001fX6,<yH\u00022-";
      l[39] = "\u0000~<\u0018\f$Qa0Nq?\u0012J1\f\rV\u0005o0M\u0014oYeiKq=\u0002`!\u0017A4\u0018oP";
      l[40] = "@1}b\u0018sP?c& zH0|qw-\u0011e#! )\u0015<x-E~O8y";
      l[41] = "\u0001\u007f5'[VDo*sa[;}%}[\\\u0002!/$]9\u000bw8c_\u0005Du(aa";
      l[42] = "D1uYR\fT?k\u001dj\u0005L0tJ=R\u0015f \u001cjV\u0011<p\u0016\u000f\u0001K8q";
      l[43] = "j\u000fG?;sz\u0001Y{\u0003zb\u000eF,T-;Y\u001bz\u0003)?\u0002Bpf~e\u0006C";
      l[44] = "T1aj5\u0012D?\u007f.\r\u001b\\0`yZD\fm5\u00150I\\=4pg\u0013X<";
      l[45] = "59B\u0002V\u000e%7\\Fn\u0007=8C\u00119Sfm\u0016GnT`4GM\u000b\u0003:0F";
      l[46] = "\u0002@?GQ\f\u0012N!\u0003i\u0005\nA>T>QZ\u0014`\u0007iVWM:\b\f\u0001\rI;";
      l[47] = "\u001f\u0005hkdXZ\u0015w?^^%Pu13VF\u000f\u007fin7\u001e\u0007y<?TA\r!a^";
      l[48] = "\u001ep\u0007y\u0002UYq\u0018xz^\"'\u0006\"@R\u001b{\f{F7\u001fw\u0006\"JRH-\u0002#z";
      l[49] = "W1<`8C\b+7:\u0001Kju*9=\u001c\n\"|.}!";
      l[50] = "\u0001!\u0005\u0001:0\u0017g\u0004\u001cAk\u0000#Y\u0018-YVe\u0006NA>\u000b#GA}q\t3E\u007f";
      l[51] = "t\br)Y\u0010d\u0006lma\u0019|\ts:6N%](gaJ!\u0005wf\u0004\u001d{\u0001v";
      l[52] = "fP=[]\rv^#\u001fe\u0004nQ<H2S7\u0001g\u001deW3]8\u0014\u0000\u0000iY9";
      l[53] = "_@\u0010\t{UON\u000eMC\\WA\u0011\u001a\u0014\u000b\u000e\u0014ENC\u000f\nM\u0015F&XPI\u0014";
      l[54] = ".O\u001d\\\u0000)>A\u0003\u00188 &N\u001cOow\u007f\u001eC\u001e8s{B\u0018\u0013]$!F\u0019";
      l[55] = "1H?11<!F!u\t59I>\"^ab\u0018`u\tfdE:~l1>A;";
      l[56] = "hr_.\u001a^x|Aj\"W`s^=u\u00009%\u0001o\"\u0004=\u007fZaGSg{[";
      l[57] = "\t[WG\u0006m\u0019UI\u0003>d\u0001ZVTi3^\f\t\u0003>7\\VR\b[`\u0006RS";
      l[58] = "?q\u0006\u0004\u0004\u007f/\u007f\u0018@<v7p\u0007\u0017k!n&YD<%j|\u0003KYr0x\u0002";
      l[59] = "C\u0004'8~?S\n9|F6K\u0005&+\u0011b\u001bR{vFe\u0016\t\"w#2L\r#";
      l[60] = "jT/\u0012\u0010szZ1V(zbU.\u0001\u007f-=\u0003qQ()?Y*]M~e]+";
      l[61] = "9-\u001fZ\u000eZ)#\u0001\u001e6S1,\u001eIa\u0004hzA\u001e6\u0000l \u001a\u0015SW6$\u001b";
      l[62] = "&\nIF5@#GN^IN*POI B\u0013^OY$$w\rLH&D&\u000f\u001a[I";
      l[63] = "zT\u000bFe\u001d%N\u0000\u001c\\\u0014G\u0010\u001d\u001f`B'GK\b \u007f";
      l[64] = "6\u001eig$1&\u0010w#\u001c8>\u001fhtKogI=(\u001ckc\u0013l(y<9\u0017m";
      l[65] = "\f^X|!,\u0007\u0006QtAy`\u001e\t*#u\u0007ZWaA";
      l[66] = "^K;I\u001e2NE%\r&;VJ:Zql\u000f\u001en\u000f&h\u000bF>\u0006C?QB?";
      l[67] = ",\u000fTP@\u0000<\u0001J\u0014x\t$\u000eUC/^}Z\u000f\u0016xZy\u0002Q\u001f\u001d\r#\u0006P";
      l[68] = "3!`RO\n#/~\u0016w\u0003; aA Tbw<\u0016wPf,e\u001d\u0012\u0007<(d";
      l[69] = ">DTzmb.JJ>Uk6EUi\u0002<o\u0011\u000e<U8kIQ50o1MP";
      l[70] = "?\u0012!0pK/\u001c?tHB7\u0013 #\u001f\u0015nB}\u007fH\u0011j\u001f$\u007f-F0\u001b%";
      l[71] = "o\n\fV&R\u007f\u0004\u0012\u0012\u001e[g\u000b\rEI\f>]P\u0017\u001e\b:\u0007\t\u0019{_`\u0003\b";
      l[72] = "BF\u0007\u0018bnRH\u0019\\ZgJG\u0006\u000b\r0\u0013\u0012[\\Z4\u0017K\u0002W?cMO\u0003";
      l[73] = "U\\2;QiER,\u007fi`]]3(>4\u0007\bh{i3\u0000Q7t\fdZU6";
      l[74] = "\u0013\u000e1qoY\u0003\u0000/5WP\u001b\u000f0b\u0000\u0007BZd3W\u0003F\u00034>2T\u001c\u00075";
      l[75] = "\u0014L)\u001c~QQ\\6HDW.N9F~[\u0017\u00123\u001fx>\u0014\u0018?J+^E\u001aiYD";
      l[76] = ":\u000e5R8R*\u0000+\u0016\u0000[2\u000f4AW\fkY`\u0015\u0000\bo\u00030\u001de_5\u00071";
      l[77] = ")\u0002&hkq9\f8,Sx!\u0003'{\u0004/xTx+S+|\u000f#'6|&\u000b\"";
      l[78] = "WW29\u007f[GY,}GR_V3*\u0010\u0005\u0001\u0000j~G\u0001\u0002Z7v\"VX^6";
      l[79] = "H\u0005>E$TX\u000b \u0001\u001c]@\u0004?VK\n\u0019Sc\u0002\u001c\u000e\u001d\b;\nyYG\f:";
      l[80] = "\u0013l\u0013m5)\u0003b\r)\r \u001bm\u0012~ZwB:N+\rsFa\u0016\"h$\u001ce\u0017";
      l[81] = "M~u1-R]pku\u0015[E\u007ft\"B\f\u001c((s\u0015\b\u0018sp~p_Bwq";
      l[82] = "m\"\u00014\u001a/},\u001fp\"&e#\u0000'uq<rTv\"u8/\u0004{G\"b+\u0005";
      l[83] = "|]\u00112\fHlS\u000fv4At\\\u0010!c\u0016-\tLw4\u0012)P\u0014}QEsT\u0015";
      l[84] = "\"\u0013\u0004^mR2\u001d\u001a\u001aU[*\u0012\u0005M\u0002\u000fzG[\u001fU\bw\u001e\u0001\u00110_-\u001a\u0000";
      l[85] = "x'hCO\bh)v\u0007w\u0001p&iP V)p4\u0006wR-*m\f\u0012\u0005w.l";
      l[86] = "\u0017[%dq\t\u0007U; I\u0000\u001fZ$w\u001eW@\fz+ISBV +,\u0004\u0018R!";
      l[87] = ".}\u0007`\b\u0003>s\u0019$0\n&|\u0006sg]\u007f-^%0Y{p\u0002/U\u000e!t\u0003";
      l[88] = "\u0003HiMu6\u0013Fw\tM?\u000bIh^\u001ahR\u001d3\u000eMlVEl\u0002(;\fAm";
      l[89] = "*\nW\u0005]Y:\u0004IAeP\"\u000bV\u00162\u0007{^\u000fDe\u0003\u007f\u0007RJ\u0000T%\u0003S";
      l[90] = "Frv\u0012\b\"M/&\u0015i!Jy\"E>v\u0014*w)\u00051\u0017j=\u0017\u0013w\u0016w";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(71941666356575L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(71941666356575L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(71941666356575L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 76;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 99;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 222;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 77;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 235;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 76;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 99;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fJ_C0289",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fJ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
