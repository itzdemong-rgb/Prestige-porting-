package dev.zprestige.prestige.client.modules;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.PacketQueueManager;
import dev.zprestige.prestige.api.util.ItemUseUtil;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.api.rotation.RotationSource;
import dev.zprestige.prestige.api.util.RotationUtil;
import dev.zprestige.prestige.api.rotation.Rotation;
import dev.zprestige.prestige.client.management.RotationManager;
import dev.zprestige.prestige.api.module.CombatProfile;
import dev.zprestige.prestige.client.modules.state.XbowCartState;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.client.Prestige;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.RaycastContext.FluidHandling;
import net.minecraft.world.RaycastContext.ShapeType;

public class XbowCart extends Module implements RotationSource {
   private IntSetting a;
   private BooleanSetting d;
   private FloatSetting c;
   private static final Item[] e;
   private XbowCartState f;
   private int g;
   private int h;
   private int i;
   private BlockPos j;
   private int k;
   private int l;
   private int m;
   private int n;
   private int o;
   private int p;
   private Rotation q;
   private static final long r = 91867885041948L;
   private static final long[] s;
   private static final Integer[] t;
   private static final Map u = new HashMap(13);
   private static final Object[] v = new Object[202];
   private static final String[] w = new String[202];
   private static volatile MethodHandle bindingCache1;

   public XbowCart() {
      super();
      long var10001 = 1432743531930L ^ 33239902840653L;

      this.f = XbowCartState.IDLE;
      this.k = -1;
      this.l = 0;
      this.m = 0;
      this.n = 0;
      this.o = 0;
      this.p = -1;
      FloatSetting var10000 = this.c;
      Object[] var6 = new Object[]{invokeBinding1(this), 34595201528535L};
      FloatSetting var5 = var10000;
      var5.aReturningFloatSetting(var6);
   }

   @Override
   public Set aReturningSet(Object[] var1) {
      SourceSupport.discard(var1[0]);
      CombatProfile var4 = CombatProfile.Cart;
      return Set.of(var4);
   }

   @Override
   public boolean bReturningBoolean(Object[] var1) {
      SourceSupport.discard(var1[0]);
      return false;
   }

   @Override
   public void dReturningVoid(Object[] var1) {
      long var4;
      long var8;
      long var10;
      long var16;
      int var18;
      XbowCart var53;
      label43: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 21727379543681L;
         long var6 = var2 ^ 46382170716389L;
         var8 = var2 ^ 48786600672541L;
         var10 = var2 ^ 19110427238687L;
         long var12 = var2 ^ 7987954750064L;
         long var14 = var2 ^ 52985857036862L;
         var16 = var2 ^ 38266410274184L;
         int var10000 = Event.cReturningInt();
         Object[] var20 = new Object[0];
         XbowCart var19 = this;
         var19.jReturningVoid(var20);
         Object[] var21 = new Object[]{var12};
         this.k = InventoryUtil.aReturningInt(var21);
         var18 = var10000;
         Object[] var23 = new Object[]{var6};
         XbowCart var22 = this;
         var10000 = var22.fReturningInt(var23);
         int var60 = var18;
         // int var58 = var10000;
         int var51 = var58;
         byte var52 = var59;
         int var48 = var58;
         byte var49 = var59;
         if (var60 != 0) {
            byte var62 = var49;
            int var61 = var48;
            if (var61 == var62) {
               Object[] var26 = new Object[]{var4};
               XbowCart var25 = this;
               var25.kReturningVoid(var26);
               return;
            }

            int var64 = var18;
            XbowCart var63 = this;
            var53 = var63;
            XbowCart var50 = var63;
            if (var64 == 0) {
               break label43;
            }

            Object[] var29 = new Object[]{var14};
            XbowCart var28 = var50;
            var10000 = var28.dReturningInt(var29);
            // int var65 = var10000;
            var51 = var65;
            var52 = var66;
         }

         byte var68 = var52;
         int var67 = var51;
         if (var67 == var68) {
            Object[] var32 = new Object[]{var4};
            XbowCart var31 = this;
            var31.kReturningVoid(var32);
            return;
         }

         var53 = this;
      }

      int var70 = var18;
      XbowCart var69 = var53;
      XbowCart var55 = var69;
      XbowCart var54 = var69;
      if (var70 != 0) {
         Object[] var35 = new Object[]{var10};
         XbowCart var34 = var54;
         Integer var71 = var34.aReturningBoxedInteger(var35);
         if (var71 == null) {
            Object[] var38 = new Object[]{var4};
            XbowCart var37 = this;
            var37.kReturningVoid(var38);
            return;
         }

         var55 = this;
      }

      int var73 = var18;
      XbowCart var72 = var55;
      XbowCart var57 = var72;
      XbowCart var56 = var72;
      if (var73 != 0) {
         Object[] var41 = new Object[]{var8};
         XbowCart var40 = var56;
         int var78 = var40.eReturningInt(var41);
         // int var74 = var78;
         if (var74 == var75) {
            Object[] var44 = new Object[]{var4};
            XbowCart var43 = this;
            var43.kReturningVoid(var44);
            return;
         }

         var57 = this;
      }

      var57.f = XbowCartState.SWITCH_RAIL;
      RotationManager var79 = Prestige.o;
      Object[] var47 = new Object[]{this, var16};
      RotationManager var46 = var79;
      var46.dReturningVoid(var47);
   }

   @Override
   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 64097829662901L;
      RotationManager var10000 = Prestige.o;
      Object[] var7 = new Object[]{this, var4};
      RotationManager var6 = var10000;
      var6.eReturningVoid(var7);
      Object[] var9 = new Object[0];
      XbowCart var8 = this;
      var8.jReturningVoid(var9);
   }

   private void jReturningVoid(Object[] var1) {
      this.f = XbowCartState.IDLE;
      this.j = null;
      this.k = -1;
      this.l = 0;
      this.m = 0;
      this.n = 0;
      this.o = 0;
      this.p = -1;
      this.q = null;
   }

   private void kReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      long var4 = var2 ^ 101733145310946L;
      Object[] var7 = new Object[]{var4};
      XbowCart var6 = this;
      var6.mReturningVoid(var7);
   }

   private void lReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      long var4 = var2 ^ 80834210621325L;
      long var6 = var2 ^ 69238398250747L;
      int var8 = Event.cReturningInt();
      int var17 = var8;
      XbowCart var16 = this;
      XbowCart var15 = var16;
      XbowCart var14 = var16;
      if (var17 != 0) {
         // int var18 = var14.k;
         if (var18 != var19) {
            int var10000 = this.k;
            Object[] var10003 = new Object[]{null, var4};
            var10003[0] = var10000;
            Object[] var10 = var10003;
            InventoryUtil.aReturningVoid(var10);
         }

         var15 = this;
      }

      Object[] var13 = new Object[]{var6};
      XbowCart var12 = var15;
      var12.mReturningVoid(var13);
   }

   private void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      long var4 = var2 ^ 26224611986756L;
      int var6 = Event.cReturningInt();
      int var15 = var6;
      XbowCart var14 = this;
      XbowCart var13 = var14;
      XbowCart var12 = var14;
      if (var15 != 0) {
         XbowCart var7 = var12;
         boolean var16 = var7.aReturningBoolean();
         if (!var16) {
            return;
         }

         XbowCart var17 = this;
         var13 = var17;
      }

      Object[] var11 = new Object[]{var4};
      XbowCart var10 = var13;
      var10.aReturningVoid(var11);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 54053644016392L ^ 9528215034102L;
      var10001 = 54053644016392L ^ 79546473265694L;
      var10001 = 54053644016392L ^ 64962821380909L;
      var10001 = 54053644016392L ^ 54183322269330L;
      var10001 = 54053644016392L ^ 60021121932027L;
      var10001 = 54053644016392L ^ 60712540091242L;
      var10001 = 54053644016392L ^ 11037115428712L;
      var10001 = 54053644016392L ^ 63781638905576L;
      var10001 = 54053644016392L ^ 47656995773513L;
      var10001 = 54053644016392L ^ 124095409544830L;
      var10001 = 54053644016392L ^ 117459571065071L;
      var10001 = 54053644016392L ^ 124685695869373L;
      int var28 = Event.cReturningInt();
      int var233 = var28;
      MinecraftClient var232 = b;
      MinecraftClient var184 = var232;
      MinecraftClient var183 = var232;
      if (var233 != 0) {
         MinecraftClient var32 = var183;
         ClientWorld var234 = var32.world;
         if (var234 == null) {
            return;
         }

         MinecraftClient var235 = b;
         var184 = var235;
      }

      MinecraftClient var35 = var184;
      ClientPlayerEntity var236 = var35.player;
      if (var236 != null) {
         int var238 = var28;
         XbowCart var237 = this;
         XbowCart var186 = var237;
         XbowCart var185 = var237;
         if (var238 != 0) {
            XbowCartState var240 = XbowCartState.IDLE;
            XbowCartState var239 = var185.f;
            if (var239 == var240) {
               return;
            }

            var186 = this;
         }

         int var10000 = ++var186.n;
         int var242 = var28;
         int var241 = var10000;
         int var188 = var241;
         int var187 = var241;
         if (var242 != 0) {
            byte var244 = 80;
            int var243 = var187;
            if (var243 > var244) {
               Object[] var41 = new Object[]{63235568911358L};
               XbowCart var40 = this;
               var40.kReturningVoid(var41);
               return;
            }

            XbowCartState var43 = this.f;
            var188 = var43.ordinal();
         }

         XbowCart var221;
         label323: {
            XbowCart var196;
            label324: {
               label287: {
                  int var195;
                  label288: {
                     label289: {
                        label290: {
                           label291: {
                              label292: {
                                 int var246 = var28;
                                 int var245 = var188;
                                 int var190 = var245;
                                 int var189 = var245;
                                 if (var246 != 0) {
                                    int var247 = var189;
                                    switch (var247) {
                                       case 1:
                                          Object[] var46 = new Object[]{29074144479041L};
                                          XbowCart var45 = this;
                                          int var248 = var45.dReturningInt(var46);
                                          var190 = var248;
                                          break;
                                       case 2:
                                          break label292;
                                       case 3:
                                          break label290;
                                       case 4:
                                          break label289;
                                       case 5:
                                          break label287;
                                       default:
                                          return;
                                    }
                                 }

                                 int var29 = var190;
                                 int var249 = var28;
                                 if (var249 == 0) {
                                    return;
                                 }

                                 // int var250 = var29;
                                 if (var250 == var251) {
                                    Object[] var50 = new Object[]{63235568911358L};
                                    XbowCart var49 = this;
                                    var49.kReturningVoid(var50);
                                    return;
                                 }

                                 MinecraftClient var52 = b;
                                 HitResult var31 = var52.crosshairTarget;
                                 byte var342 = ((byte)((var31 instanceof BlockHitResult) ? 1 : 0));
                                 int var253 = var28;
                                 byte var252 = var342;
                                 var195 = var252;
                                 byte var191 = var252;
                                 if (var253 == 0) {
                                    break label288;
                                 }

                                 byte var254 = var191;
                                 if (var254 == 0) {
                                    break label291;
                                 }

                                 BlockHitResult var30 = (BlockHitResult)var31;
                                 int var256 = var28;
                                 BlockHitResult var255 = var30;
                                 BlockHitResult var197 = var255;
                                 BlockHitResult var192 = var255;
                                 if (var256 != 0) {
                                    BlockHitResult var54 = var192;
                                    Direction var343 = var54.getSide();
                                    Direction var258 = Direction.UP;
                                    Direction var257 = var343;
                                    if (var257 != var258) {
                                       break label291;
                                    }

                                    var197 = var30;
                                 }

                                 BlockHitResult var61 = var197;
                                 BlockPos var341 = var61.getBlockPos();
                                 BlockPos var62 = var341;
                                 this.g = var62.getX();
                                 BlockPos var63 = var341;
                                 this.h = var63.getY() + 1;
                                 BlockPos var64 = var341;
                                 this.i = var64.getZ();
                                 MinecraftClient var65 = b;
                                 ClientWorld var344 = var65.world;
                                 BlockPos var66 = var341;
                                 BlockPos var68 = var66.up();
                                 ClientWorld var67 = var344;
                                 BlockState var69 = var67.getBlockState(var68);
                                 var342 = ((byte)((var69.isReplaceable()) ? 1 : 0));
                                 int var267 = var28;
                                 byte var266 = var342;
                                 byte var199 = var266;
                                 byte var198 = var266;
                                 if (var267 != 0) {
                                    byte var268 = var198;
                                    if (var268 == 0) {
                                       Object[] var72 = new Object[]{63235568911358L};
                                       XbowCart var71 = this;
                                       var71.kReturningVoid(var72);
                                       return;
                                    }

                                    double var365 = this.g + 0.5;
                                    double var10002 = this.h + 0.5;
                                    double var10003 = this.i + 0.5;
                                    Object[] var10006 = new Object[]{null, null, null, 133528436613398L};
                                    var10006[2] = var10003;
                                    var10006[1] = var10002;
                                    var10006[0] = var365;
                                    Object[] var75 = var10006;
                                    XbowCart var74 = this;
                                    var199 = ((byte)((var74.dReturningBoolean(var75)) ? 1 : 0));
                                 }

                                 int var270 = var28;
                                 byte var269 = var199;
                                 int var201 = var269;
                                 byte var200 = var269;
                                 if (var270 != 0) {
                                    byte var271 = var200;
                                    if (var271 == 0) {
                                       Object[] var78 = new Object[]{63235568911358L};
                                       XbowCart var77 = this;
                                       var77.kReturningVoid(var78);
                                       return;
                                    }

                                    var201 = var29;
                                 }

                                 Object[] var368 = new Object[]{null, 72518082610550L};
                                 var368[0] = var201;
                                 Object[] var80 = var368;
                                 InventoryUtil.aReturningVoid(var80);
                                 double var10005 = this.g + 0.5;
                                 BlockPos var81 = var341;
                                 Object[] var83 = new Object[]{
                                    new BlockHitResult(new Vec3d(var10005, var81.getY() + 1.0, this.i + 0.5), Direction.UP, var341, false), 70712322456245L
                                 };
                                 XbowCart var82 = this;
                                 var82.nReturningVoid(var83);
                                 IntSetting var84 = this.a;
                                 Integer var85 = (Integer)var84.aReturningObject();
                                 this.l = var85;
                                 this.f = XbowCartState.SWITCH_CART;
                                 int var272 = var28;
                                 if (var272 != 0) {
                                    return;
                                 }
                              }

                              int var274 = var28;
                              XbowCart var273 = this;
                              XbowCart var204 = var273;
                              XbowCart var202 = var273;
                              if (var274 != 0) {
                                 XbowCart var275 = var202;
                                 XbowCart var203 = var275;
                                 int var276 = var203.l;
                                 if (var276 > 0) {
                                    this.l--;
                                    return;
                                 }

                                 var204 = this;
                              }

                              Object[] var90 = new Object[]{65011294155872L};
                              XbowCart var89 = var204;
                              Integer var335 = var89.aReturningBoxedInteger(var90);
                              int var277 = var28;
                              if (var277 == 0) {
                                 return;
                              }

                              Integer var278 = var335;
                              if (var278 == null) {
                                 Object[] var93 = new Object[]{63235568911358L};
                                 XbowCart var92 = this;
                                 var92.kReturningVoid(var93);
                                 return;
                              }

                              MinecraftClient var95 = b;
                              ClientPlayerEntity var96 = var95.player;
                              PlayerInventory var346 = var96.getInventory();
                              Integer var97 = var335;
                              int var99 = var97;
                              PlayerInventory var98 = var346;
                              ItemStack var100 = var98.getStack(var99);
                              Item var347 = var100.getItem();
                              Item var280 = Items.TNT_MINECART;
                              Item var279 = var347;
                              if (var279 != var280) {
                                 return;
                              }

                              double var366 = this.g + 0.5;
                              double var367 = this.h + 0.5;
                              double var369 = this.i + 0.5;
                              Object[] var375 = new Object[]{null, null, null, 133528436613398L};
                              var375[2] = var369;
                              var375[1] = var367;
                              var375[0] = var366;
                              Object[] var103 = var375;
                              XbowCart var102 = this;
                              int var348 = (((var102.dReturningBoolean(var103)) ? 1 : 0));
                              int var282 = var28;
                              boolean var281 = dev.prestige.recovery.SourceSupport.asBoolean(var348);
                              boolean var205 = var281;
                              if (var282 != 0) {
                                 boolean var283 = var205;
                                 if (!var283) {
                                    Object[] var106 = new Object[]{63235568911358L};
                                    XbowCart var105 = this;
                                    var105.kReturningVoid(var106);
                                    return;
                                 }

                                 Integer var108 = var335;
                                 var348 = var108;
                                 Object[] var370 = new Object[]{null, 72518082610550L};
                                 var370[0] = var348;
                                 Object[] var109 = var370;
                                 InventoryUtil.aReturningVoid(var109);
                                 Object[] var110 = new Object[]{
                                    new BlockHitResult(
                                       new Vec3d(this.g + 0.5, this.h + 0.125, this.i + 0.5), Direction.UP, new BlockPos(this.g, this.h, this.i), false
                                    ),
                                    11253043183653L
                                 };
                                 boolean var206 = ItemUseUtil.aReturningBoolean(var110);
                              }

                              IntSetting var111 = this.a;
                              Integer var112 = (Integer)var111.aReturningObject();
                              this.l = var112;
                              this.f = XbowCartState.SWITCH_FIRE;
                              int var284 = var28;
                              if (var284 != 0) {
                                 return;
                              }
                              break label290;
                           }

                           int var260 = var28;
                           XbowCart var259 = this;
                           var196 = var259;
                           XbowCart var193 = var259;
                           if (var260 == 0) {
                              break label324;
                           }

                           XbowCart var261 = var193;
                           XbowCart var194 = var261;
                           int var262 = ++var194.m;
                           var195 = var262;
                           break label288;
                        }

                        int var286 = var28;
                        XbowCart var285 = this;
                        XbowCart var209 = var285;
                        XbowCart var207 = var285;
                        if (var286 != 0) {
                           XbowCart var287 = var207;
                           XbowCart var208 = var287;
                           int var288 = var208.l;
                           if (var288 > 0) {
                              this.l--;
                              return;
                           }

                           var209 = this;
                        }

                        XbowCart var213;
                        int var290 = var28;
                        XbowCart var289 = var209;
                        var213 = var289;
                        XbowCart var210 = var289;
                        label232:
                        if (var290 != 0) {
                           BlockPos var291 = var210.j;
                           if (var291 == null) {
                              Object[] var118 = new Object[]{12279473898976L};
                              XbowCart var117 = this;
                              this.j = var117.aReturningBlockPos(var118);
                              int var293 = var28;
                              XbowCart var292 = this;
                              var213 = var292;
                              XbowCart var211 = var292;
                              if (var293 == 0) {
                                 break label232;
                              }

                              XbowCart var294 = var211;
                              XbowCart var212 = var294;
                              BlockPos var295 = var212.j;
                              if (var295 == null) {
                                 Object[] var122 = new Object[]{63235568911358L};
                                 XbowCart var121 = this;
                                 var121.kReturningVoid(var122);
                                 return;
                              }
                           }

                           var213 = this;
                        }

                        Object[] var125 = new Object[]{6729763039330L};
                        XbowCart var124 = var213;
                        int var336 = var124.eReturningInt(var125);
                        int var296 = var28;
                        if (var296 == 0) {
                           return;
                        }

                        // int var297 = var336;
                        if (var297 == var298) {
                           Object[] var128 = new Object[]{63235568911358L};
                           XbowCart var127 = this;
                           var127.kReturningVoid(var128);
                           return;
                        }

                        BlockPos var130 = this.j;
                        BlockPos var340 = var130.down();
                        Object[] var371 = new Object[]{null, 72518082610550L};
                        var371[0] = var336;
                        Object[] var131 = var371;
                        InventoryUtil.aReturningVoid(var131);
                        BlockPos var132 = var340;
                        double var374 = var132.getX() + 0.5;
                        BlockPos var133 = var340;
                        double var376 = var133.getY() + 1.0;
                        BlockPos var134 = var340;
                        Object[] var136 = new Object[]{
                           new BlockHitResult(new Vec3d(var374, var376, var134.getZ() + 0.5), Direction.UP, var340, false), 70712322456245L
                        };
                        XbowCart var135 = this;
                        var135.nReturningVoid(var136);
                        IntSetting var137 = this.a;
                        Integer var138 = (Integer)var137.aReturningObject();
                        this.l = var138;
                        this.f = XbowCartState.SWITCH_XBOW;
                        int var299 = var28;
                        if (var299 != 0) {
                           return;
                        }
                     }

                     int var301 = var28;
                     int var300 = this.l;
                     int var216 = var300;
                     int var214 = var300;
                     if (var301 != 0) {
                        int var302 = var214;
                        int var215 = var302;
                        int var303 = var215;
                        if (var303 > 0) {
                           this.l--;
                           return;
                        }

                        Object[] var143 = new Object[]{475968384410L};
                        XbowCart var142 = this;
                        var216 = var142.fReturningInt(var143);
                     }

                     int var337 = var216;
                     int var305 = var28;
                     int var304 = var337;
                     int var218 = var304;
                     int var217 = var304;
                     if (var305 != 0) {
                        // int var306 = var217;
                        if (var306 == var307) {
                           Object[] var146 = new Object[]{63235568911358L};
                           XbowCart var145 = this;
                           var145.kReturningVoid(var146);
                           return;
                        }

                        var218 = var337;
                     }

                     Object[] var372 = new Object[]{null, 72518082610550L};
                     var372[0] = var218;
                     Object[] var148 = var372;
                     InventoryUtil.aReturningVoid(var148);
                     this.o = 0;
                     this.f = XbowCartState.FIRE;
                     int var308 = var28;
                     if (var308 != 0) {
                        return;
                     }
                     break label287;
                  }

                  byte var264 = 10;
                  int var263 = var195;
                  if (var263 <= var264) {
                     return;
                  }

                  XbowCart var265 = this;
                  var196 = var265;
                  break label324;
               }

               int var310 = var28;
               XbowCart var309 = this;
               var221 = var309;
               XbowCart var219 = var309;
               if (var310 == 0) {
                  break label323;
               }

               XbowCart var311 = var219;
               XbowCart var220 = var311;
               Rotation var312 = var220.q;
               if (var312 == null) {
                  XbowCart var313 = this;
                  var221 = var313;
                  break label323;
               }

               Object[] var154 = new Object[]{Items.CROSSBOW, 8519502184947L};
               byte var350 = ((byte)((InventoryUtil.lReturningBoolean(var154)) ? 1 : 0));
               int var315 = var28;
               byte var314 = var350;
               int var229 = var314;
               byte var222 = var314;
               if (var315 != 0) {
                  byte var316 = var222;
                  if (var316 != 0) {
                     RotationManager var351 = Prestige.o;
                     Object[] var157 = new Object[0];
                     RotationManager var156 = var351;
                     Rotation var338 = var156.cReturningdx_C0210(var157);
                     int var317 = var28;
                     if (var317 != 0) {
                        XbowCart var228;
                        label180: {
                           Rotation var318 = var338;
                           label179:
                           if (var318 != null) {
                              Object[] var160 = new Object[0];
                              Rotation var159 = var338;
                              var350 = ((byte)((var159.aReturningBoolean(var160)) ? 1 : 0));
                              int var320 = var28;
                              byte var319 = var350;
                              int var227 = var319;
                              byte var223 = var319;
                              if (var320 != 0) {
                                 byte var321 = var223;
                                 byte var224 = var321;
                                 byte var322 = var224;
                                 if (var322 == 0) {
                                    break label179;
                                 }

                                 int var324 = var28;
                                 XbowCart var323 = this;
                                 var228 = var323;
                                 XbowCart var225 = var323;
                                 if (var324 == 0) {
                                    break label180;
                                 }

                                 XbowCart var325 = var225;
                                 XbowCart var226 = var325;
                                 int var326 = var226.o++;
                                 var227 = var326;
                              }

                              byte var328 = 5;
                              int var327 = var227;
                              if (var327 < var328) {
                                 return;
                              }
                           }

                           MinecraftClient var166 = b;
                           MinecraftClient var167 = b;
                           Hand var170 = Hand.MAIN_HAND;
                           ClientPlayerEntity var169 = var167.player;
                           ClientPlayerInteractionManager var168 = var166.interactionManager;
                           var168.interactItem((PlayerEntity)var169, var170);
                           RotationManager var353 = Prestige.o;
                           Object[] var172 = new Object[]{true};
                           RotationManager var171 = var353;
                           var171.fReturningVoid(var172);
                           var228 = this;
                        }

                        Object[] var174 = new Object[]{101143934032871L};
                        XbowCart var173 = var228;
                        var173.lReturningVoid(var174);
                     }

                     int var329 = var28;
                     if (var329 != 0) {
                        return;
                     }
                  }

                  Object[] var176 = new Object[]{475968384410L};
                  XbowCart var175 = this;
                  int var330 = var175.fReturningInt(var176);
                  var229 = var330;
               }

               int var339 = var229;
               int var332 = var28;
               int var331 = var339;
               int var231 = var331;
               int var230 = var331;
               if (var332 != 0) {
                  // int var333 = var230;
                  if (var333 == var334) {
                     Object[] var180 = new Object[]{63235568911358L};
                     XbowCart var179 = this;
                     var179.kReturningVoid(var180);
                     return;
                  }

                  var231 = var339;
               }

               Object[] var373 = new Object[]{null, 72518082610550L};
               var373[0] = var231;
               Object[] var182 = var373;
               InventoryUtil.aReturningVoid(var182);
               return;
            }

            Object[] var60 = new Object[]{63235568911358L};
            XbowCart var59 = var196;
            var59.kReturningVoid(var60);
            return;
         }

         Object[] var153 = new Object[]{63235568911358L};
         XbowCart var152 = var221;
         var152.kReturningVoid(var153);
      }
   }

   private Vec3d aReturningVec3d(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 91867885041948L ^ var2;
      MinecraftClient var11 = b;
      ClientPlayerEntity var12 = var11.player;
      Vec3d var4 = var12.getEyePos();
      Vec3d var5 = new Vec3d(this.g + 0.5, this.h + 0.45, this.i + 0.5);
      Vec3d var14 = var5;
      Vec3d var13 = var4;
      double var6 = var13.distanceTo(var14);
      double var15 = var6 / 3.15;
      int var8 = (int)Math.ceil(var15);
      double var9 = 0.05 * var8 * (var8 + 1) / 2.0;
      double var20 = var9;
      Vec3d var17 = var5;
      return var17.add(var18, var20, var22);
   }

   private Rotation bReturningdx_C0210(Object[] var1) {
      Vec3d var2 = (Vec3d)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 91867885041948L ^ var3;
      MinecraftClient var17 = b;
      ClientPlayerEntity var18 = var17.player;
      Vec3d var6 = var18.getEyePos();
      Vec3d var19 = var2;
      Vec3d var20 = var6;
      double var7 = var19.x - var20.x;
      Vec3d var21 = var2;
      Vec3d var22 = var6;
      double var9 = var21.y - (var22.y - 0.1);
      Vec3d var23 = var2;
      Vec3d var24 = var6;
      double var11 = var23.z - var24.z;
      int var53 = Event.cReturningInt();
      double var25 = var7 * var7 + var9 * var9 + var11 * var11;
      double var13 = Math.sqrt(var25);
      int var5 = var53;
      int var51 = var5;
      double var49 = 1.0E-6;
      double var47 = var13;
      double var43 = var47;
      double var45 = var49;
      double var39 = var47;
      double var41 = var49;
      if (var51 != 0) {
         double var55;
         int var52 = (var55 = var39 - var41) == 0.0 ? 0 : (var55 < 0.0 ? -1 : 1);
         if (var52 < 0) {
            return null;
         }

         double var31 = var7;
         double var29 = var11;
         double var33 = Math.atan2(var29, var31);
         double var54 = Math.toDegrees(var33);
         var45 = 90.0;
         var43 = var54;
      }

      float var15 = (float)(var43 - var45);
      double var35 = var9 / var13;
      double var37 = Math.asin(var35);
      float var16 = (float)(-Math.toDegrees(var37));
      return new Rotation(var15, var16);
   }

   private boolean aReturningBoolean(Object[] var1) {
      BlockPos var3;
      int var7;
      double var9;
      double var11;
      double var13;
      long var178;
      double var180;
      double var181;
      double var182;
      label114: {
         float var2 = (Float)var1[0];
         float var4 = (Float)var1[1];
         var3 = (BlockPos)var1[2];
         var178 = (Long)var1[3];
         var178 = 91867885041948L ^ var178;
         MinecraftClient var37 = b;
         ClientPlayerEntity var38 = var37.player;
         Vec3d var8 = var38.getEyePos();
         int var10000 = Event.cReturningInt();
         Vec3d var39 = var8;
         var9 = var39.x;
         Vec3d var40 = var8;
         var11 = var40.y - 0.1;
         Vec3d var41 = var8;
         var13 = var41.z;
         var7 = var10000;
         double var42 = var2;
         double var15 = Math.toRadians(var42);
         double var44 = var4;
         double var17 = Math.toRadians(var44);
         double var46 = var15;
         double var184 = -Math.sin(var46);
         double var48 = var17;
         var180 = var184 * Math.cos(var48);
         double var50 = var17;
         var181 = -Math.sin(var50);
         double var52 = var15;
         double var185 = Math.cos(var52);
         double var54 = var17;
         double var23 = var185 * Math.cos(var54);
         double var56 = var180 * var180 + var181 * var181 + var23 * var23;
         double var25 = Math.sqrt(var56);
         var180 = var180 / var25 * 3.15;
         var181 = var181 / var25 * 3.15;
         var182 = var23 / var25 * 3.15;
         MinecraftClient var58 = b;
         ClientPlayerEntity var59 = var58.player;
         Vec3d var60 = var59.getVelocity();
         var180 += var60.x;
         MinecraftClient var61 = b;
         ClientPlayerEntity var62 = var61.player;
         Vec3d var63 = var62.getVelocity();
         double var186 = var182 + var63.z;
         int var135 = var7;
         double var133 = var186;
         double var107 = var133;
         double var105 = var133;
         if (var135 != 0) {
            var182 = var105;
            MinecraftClient var64 = b;
            ClientPlayerEntity var65 = var64.player;
            boolean var136 = var65.isOnGround();
            if (var136) {
               break label114;
            }

            MinecraftClient var66 = b;
            ClientPlayerEntity var67 = var66.player;
            Vec3d var68 = var67.getVelocity();
            double var137 = var181 + var68.y;
            var107 = var137;
         }

         var181 = var107;
      }

      Box var27 = new Box(this.g + 0.01, this.h + 0.0625, this.i + 0.01, this.g + 0.99, this.h + 0.7625, this.i + 0.99);
      BlockPos var28 = new BlockPos(this.g, this.h, this.i);
      byte var29 = 0;
      label108:
      while (true) {
         int var109 = var30;

         byte var132;
         label104:
         while (true) {
            short var10001 = 6701;
            long var10002 = 2366630823913974153L ^ var178;
            byte var140 = 60;
            int var139 = var109;
            if (var139 < var140) {
               Vec3d var31 = new Vec3d(var9, var11, var13);
               double var70 = var180 * var180 + var181 * var181 + var182 * var182;
               double var32 = Math.sqrt(var70);
               byte var187 = 1;
               double var72 = var32 / 0.25;
               int var75 = (int)Math.ceil(var72);
               int var34 = Math.max(1, var75);
               int var142 = var7;
               byte var141 = 0;
               var132 = var141;
               byte var110 = var141;
               if (var142 == 0) {
                  break;
               }

               int var35 = var110;

               int var158;
               do {
                  int var144 = var34;
                  int var143 = var35;
                  if (var143 >= var144) {
                     break;
                  }

                  var9 += var180 / var34;
                  var11 += var181 / var34;
                  var13 += var182 / var34;
                  int var146 = var7;
                  byte var145 = var29;
                  var109 = var145;
                  byte var111 = var145;
                  if (var146 == 0) {
                     continue label104;
                  }

                  byte var115;
                  int var148 = var7;
                  byte var147 = var111;
                  var115 = var147;
                  byte var112 = var147;
                  label96:
                  if (var148 != 0) {
                     byte var149 = var112;
                     if (var149 == 0) {
                        BlockPos var150 = var3;
                        if (var150 != null) {
                           Box var188 = new Box(var3);
                           double var83 = var13;
                           double var81 = var11;
                           double var79 = var9;
                           Box var78 = var188;
                           var187 = ((byte)((var78.contains(var79, var81, var83)) ? 1 : 0));
                           int var152 = var7;
                           byte var151 = var187;
                           var115 = var151;
                           byte var113 = var151;
                           if (var152 == 0) {
                              break label96;
                           }

                           byte var153 = var113;
                           byte var114 = var153;
                           byte var154 = var114;
                           if (var154 != 0) {
                              var29 = 1;
                           }
                        }
                     }

                     double var91 = var13;
                     double var89 = var11;
                     double var87 = var9;
                     Box var86 = var27;
                     var115 = ((byte)((var86.contains(var87, var89, var91)) ? 1 : 0));
                  }

                  int var156 = var7;
                  byte var155 = var115;
                  byte var117 = var155;
                  byte var116 = var155;
                  if (var156 == 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var117);
                  }

                  byte var157 = var116;
                  if (var157 != 0) {
                     var117 = var29;
                     return dev.prestige.recovery.SourceSupport.asBoolean(var117);
                  }

                  var35++;
                  var158 = var7;
               } while (var158 != 0);

               double var128;
               double var130;
               label120: {
                  int var127;
                  label121: {
                     label122: {
                        Vec3d var183 = new Vec3d(var9, var11, var13);
                        MinecraftClient var94 = b;
                        ClientWorld var190 = var94.world;
                        MinecraftClient var95 = b;
                        RaycastContext var97 = new RaycastContext(var31, var183, ShapeType.OUTLINE, FluidHandling.NONE, var95.player);
                        ClientWorld var96 = var190;
                        BlockHitResult var36 = var96.raycast(var97);
                        int var160 = var7;
                        BlockHitResult var159 = var36;
                        BlockHitResult var119 = var159;
                        BlockHitResult var118 = var159;
                        if (var160 != 0) {
                           BlockHitResult var161 = var118;
                           if (var161 == null) {
                              break label122;
                           }

                           var119 = var36;
                        }

                        int var163 = var7;
                        BlockHitResult var162 = var119;
                        BlockHitResult var121 = var162;
                        BlockHitResult var120 = var162;
                        if (var163 != 0) {
                           BlockHitResult var99 = var120;
                           Type var191 = var99.getType();
                           Type var165 = Type.BLOCK;
                           Type var164 = var191;
                           if (var164 != var165) {
                              break label122;
                           }

                           BlockHitResult var166 = var36;
                           var121 = var166;
                        }

                        BlockHitResult var102 = var121;
                        BlockPos var192 = var102.getBlockPos();
                        BlockPos var104 = var28;
                        BlockPos var103 = var192;
                        var187 = ((byte)((var103.equals(var104)) ? 1 : 0));
                        int var168 = var7;
                        byte var167 = var187;
                        var127 = var167;
                        byte var122 = var167;
                        if (var168 == 0) {
                           break label121;
                        }

                        byte var169 = var122;
                        if (var169 == 0) {
                           return false;
                        }
                     }

                     double var195 = this.h - 3;
                     int var174 = var7;
                     double var172 = var195;
                     double var170 = var11;
                     var128 = var170;
                     var130 = var172;
                     double var123 = var170;
                     double var125 = var172;
                     if (var174 == 0) {
                        break label120;
                     }

                     double var196;
                     int var175 = (var196 = var123 - var125) == 0.0 ? 0 : (var196 < 0.0 ? -1 : 1);
                     var127 = var175;
                  }

                  int var176 = var127;
                  if (var176 < 0) {
                     return false;
                  }

                  var180 *= 0.99;
                  var182 *= 0.99;
                  double var194 = var181 * 0.99;
                  var130 = 0.05;
                  var128 = var194;
               }

               var181 = var128 - var130;
               var30++;
               int var177 = var7;
               if (var177 != 0) {
                  continue label108;
               }
            }

            var132 = 0;
            break;
         }

         return dev.prestige.recovery.SourceSupport.asBoolean(var132);
      }
   }

   private BlockPos aReturningBlockPos(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      long var4 = var2 ^ 37207872200170L;
      long var6 = var2 ^ 132669168545801L;
      long var8 = var2 ^ 23816400660730L;
      int var10000 = Event.bReturningInt();
      Object[] var40 = new Object[]{var8};
      XbowCart var39 = this;
      Object[] var42 = new Object[]{var39.aReturningVec3d(var40), var6};
      XbowCart var41 = this;
      Rotation var11 = var41.bReturningdx_C0210(var42);
      int var10 = var10000;
      Rotation var147 = var11;
      if (var147 == null) {
         return null;
      }

      double var13;
      double var15;
      double var17;
      double var181;
      double var182;
      double var183;
      label94: {
         MinecraftClient var44 = b;
         ClientPlayerEntity var45 = var44.player;
         Vec3d var12 = var45.getEyePos();
         Vec3d var46 = var12;
         var13 = var46.x;
         Vec3d var47 = var12;
         var15 = var47.y - 0.1;
         Vec3d var48 = var12;
         var17 = var48.z;
         Object[] var50 = new Object[0];
         Rotation var49 = var11;
         double var51 = var49.aReturningFloat(var50);
         double var19 = Math.toRadians(var51);
         Object[] var54 = new Object[0];
         Rotation var53 = var11;
         double var55 = var53.bReturningFloat(var54);
         double var21 = Math.toRadians(var55);
         double var57 = var19;
         double var184 = -Math.sin(var57);
         double var59 = var21;
         var181 = var184 * Math.cos(var59);
         double var61 = var21;
         var182 = -Math.sin(var61);
         double var63 = var19;
         double var185 = Math.cos(var63);
         double var65 = var21;
         double var27 = var185 * Math.cos(var65);
         double var67 = var181 * var181 + var182 * var182 + var27 * var27;
         double var29 = Math.sqrt(var67);
         var181 = var181 / var29 * 3.15;
         var182 = var182 / var29 * 3.15;
         var183 = var27 / var29 * 3.15;
         MinecraftClient var69 = b;
         ClientPlayerEntity var70 = var69.player;
         Vec3d var71 = var70.getVelocity();
         var181 += var71.x;
         MinecraftClient var72 = b;
         ClientPlayerEntity var73 = var72.player;
         Vec3d var74 = var73.getVelocity();
         double var186 = var183 + var74.z;
         int var150 = var10;
         double var148 = var186;
         double var133 = var148;
         double var131 = var148;
         if (var150 == 0) {
            var183 = var131;
            MinecraftClient var75 = b;
            ClientPlayerEntity var76 = var75.player;
            boolean var151 = var76.isOnGround();
            if (var151) {
               break label94;
            }

            MinecraftClient var77 = b;
            ClientPlayerEntity var78 = var77.player;
            Vec3d var79 = var78.getVelocity();
            double var152 = var182 + var79.y;
            var133 = var152;
         }

         var182 = var133;
      }

      BlockPos var31 = new BlockPos(this.g, this.h, this.i);
      MinecraftClient var81 = b;
      ClientPlayerEntity var82 = var81.player;
      Box var187 = var82.getBoundingBox();
      double var84 = 0.3;
      Box var83 = var187;
      Box var32 = var83.expand(var84);
      while (true) {
         int var135 = var33;

         label85:
         while (true) {
            short var10001 = 31122;
            long var10002 = 8574556269220454500L ^ var2;
            byte var155 = 60;
            int var154 = var135;
            if (var154 < var155) {
               double var86 = var181 * var181 + var182 * var182 + var183 * var183;
               double var34 = Math.sqrt(var86);
               byte var188 = 1;
               double var88 = var34 / 0.25;
               int var91 = (int)Math.ceil(var88);
               int var36 = Math.max(1, var91);
               int var177;
               do {
                  int var157 = var36;
                  int var156 = var37;
                  if (var156 >= var157) {
                     break;
                  }

                  var13 += var181 / var36;
                  var15 += var182 / var36;
                  var17 += var183 / var36;
                  double var96 = var17;
                  double var94 = var15;
                  double var92 = var13;
                  BlockPos var38 = BlockPos.ofFloored(var92, var94, var96);
                  BlockPos var99 = var31;
                  BlockPos var98 = var38;
                  var188 = ((byte)((var98.equals(var99)) ? 1 : 0));
                  int var159 = var10;
                  byte var158 = var188;
                  var135 = var158;
                  byte var136 = var158;
                  if (var159 != 0) {
                     continue label85;
                  }

                  int var161 = var10;
                  byte var160 = var136;
                  byte var138 = var160;
                  byte var137 = var160;
                  if (var161 == 0) {
                     byte var162 = var137;
                     if (var162 != 0) {
                        return null;
                     }

                     BlockPos var101 = var31;
                     BlockPos var103 = var101.up();
                     BlockPos var102 = var38;
                     byte var163 = ((byte)((var102.equals(var103)) ? 1 : 0));
                     var138 = var163;
                  }

                  int var165 = var10;
                  byte var164 = var138;
                  byte var140 = var164;
                  byte var139 = var164;
                  if (var165 == 0) {
                     byte var166 = var139;
                     if (var166 != 0) {
                        return null;
                     }

                     Box var108 = new Box(var38);
                     Box var107 = var32;
                     var140 = ((byte)((var107.intersects(var108)) ? 1 : 0));
                  }

                  label101: {
                     int var168 = var10;
                     byte var167 = var140;
                     byte var142 = var167;
                     byte var141 = var167;
                     if (var168 == 0) {
                        byte var169 = var141;
                        if (var169 != 0) {
                           break label101;
                        }

                        BlockPos var110 = var38;
                        double var192 = var110.getX() + 0.5;
                        BlockPos var111 = var38;
                        double var194 = var111.getY();
                        BlockPos var112 = var38;
                        double var10003 = var112.getZ() + 0.5;
                        Object[] var10006 = new Object[]{null, null, null, var4};
                        var10006[2] = var10003;
                        var10006[1] = var194;
                        var10006[0] = var192;
                        Object[] var114 = var10006;
                        XbowCart var113 = this;
                        var142 = ((byte)((var113.dReturningBoolean(var114)) ? 1 : 0));
                     }

                     int var171 = var10;
                     byte var170 = var142;
                     byte var144 = var170;
                     byte var143 = var170;
                     if (var171 == 0) {
                        byte var172 = var143;
                        if (var172 == 0) {
                           break label101;
                        }

                        MinecraftClient var116 = b;
                        BlockPos var118 = var38;
                        ClientWorld var117 = var116.world;
                        BlockState var119 = var117.getBlockState(var118);
                        var144 = ((byte)((var119.isReplaceable()) ? 1 : 0));
                     }

                     int var174 = var10;
                     byte var173 = var144;
                     byte var146 = var173;
                     byte var145 = var173;
                     if (var174 == 0) {
                        byte var175 = var145;
                        if (var175 == 0) {
                           break label101;
                        }

                        MinecraftClient var121 = b;
                        ClientWorld var190 = var121.world;
                        BlockPos var122 = var38;
                        BlockPos var124 = var122.down();
                        ClientWorld var123 = var190;
                        BlockState var191 = var123.getBlockState(var124);
                        MinecraftClient var125 = b;
                        ClientWorld var193 = var125.world;
                        BlockPos var126 = var38;
                        BlockPos var195 = var126.down();
                        Direction var130 = Direction.UP;
                        BlockPos var129 = var195;
                        ClientWorld var128 = var193;
                        BlockState var127 = var191;
                        var146 = ((byte)((var127.isSideSolidFullSquare((BlockView)var128, var129, var130)) ? 1 : 0));
                     }

                     byte var176 = var146;
                     if (var176 != 0) {
                        return var38;
                     }
                  }

                  var37++;
                  var177 = var10;
               } while (var177 == 0);

               var181 *= 0.99;
               var183 *= 0.99;
               var182 = var182 * 0.99 - 0.05;
               var33++;
               int var178 = var10;
               if (var178 == 0) {
                  break;
               }
            }

            return null;
         }
      }
   }

   @Override
   public Rotation aReturningdx_C0210(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 138426539507609L;
      long var6 = var2 ^ 31335311893653L;
      long var8 = var2 ^ 77379818547405L;
      long var10 = var2 ^ 124792700304486L;
      long var12 = var2 ^ 110282490054611L;
      int var14 = Event.cReturningInt();
      int var98 = var14;
      MinecraftClient var97 = b;
      MinecraftClient var71 = var97;
      MinecraftClient var70 = var97;
      if (var98 != 0) {
         MinecraftClient var18 = var70;
         ClientPlayerEntity var99 = var18.player;
         if (var99 == null) {
            return null;
         }

         MinecraftClient var100 = b;
         var71 = var100;
      }

      XbowCart var76;
      label113: {
         MinecraftClient var21 = var71;
         int var102 = var14;
         ClientWorld var101 = var21.world;
         Object var75 = var101;
         ClientWorld var72 = var101;
         if (var102 != 0) {
            ClientWorld var103 = var72;
            if (var103 == null) {
               return null;
            }

            int var105 = var14;
            XbowCart var104 = this;
            var76 = var104;
            XbowCart var73 = var104;
            if (var105 == 0) {
               break label113;
            }

            XbowCart var106 = var73;
            XbowCart var74 = var106;
            BooleanSetting var24 = var74.d;
            Object var107 = var24.aReturningObject();
            var75 = var107;
         }

         Boolean var26 = (Boolean)var75;
         boolean var108 = var26;
         if (!var108) {
            return null;
         }

         var76 = this;
      }

      XbowCart var80;
      int var110 = var14;
      XbowCart var109 = var76;
      var80 = var109;
      XbowCart var77 = var109;
      label94:
      if (var110 != 0) {
         XbowCartState var112 = XbowCartState.SWITCH_XBOW;
         XbowCartState var111 = var77.f;
         if (var111 != var112) {
            int var114 = var14;
            XbowCart var113 = this;
            var80 = var113;
            XbowCart var78 = var113;
            if (var114 == 0) {
               break label94;
            }

            XbowCart var115 = var78;
            XbowCart var79 = var115;
            XbowCartState var117 = XbowCartState.FIRE;
            XbowCartState var116 = var79.f;
            if (var116 != var117) {
               Vec3d var15;
               label116: {
                  XbowCart var92;
                  label117: {
                     var15 = null;
                     int var131 = var14;
                     XbowCartState var130 = XbowCartState.SWITCH_CART;
                     XbowCartState var129 = this.f;
                     XbowCartState var90 = var129;
                     XbowCartState var91 = var130;
                     XbowCartState var87 = var129;
                     XbowCartState var88 = var130;
                     if (var131 != 0) {
                        XbowCartState var133 = var88;
                        XbowCartState var132 = var87;
                        if (var132 == var133) {
                           var15 = new Vec3d(this.g + 0.5, this.h + 0.5, this.i + 0.5);
                           break label116;
                        }

                        int var135 = var14;
                        XbowCart var134 = this;
                        var92 = var134;
                        XbowCart var89 = var134;
                        if (var135 == 0) {
                           break label117;
                        }

                        XbowCartState var137 = XbowCartState.SWITCH_FIRE;
                        XbowCartState var136 = var89.f;
                        var90 = var136;
                        var91 = var137;
                     }

                     XbowCartState var139 = var91;
                     XbowCartState var138 = var90;
                     if (var138 != var139) {
                        break label116;
                     }

                     var92 = this;
                  }

                  int var141 = var14;
                  BlockPos var140 = var92.j;
                  BlockPos var94 = var140;
                  BlockPos var93 = var140;
                  if (var141 != 0) {
                     BlockPos var142 = var93;
                     if (var142 == null) {
                        break label116;
                     }

                     BlockPos var143 = this.j;
                     var94 = var143;
                  }

                  BlockPos var58 = var94;
                  var15 = var58.toCenterPos();
               }

               Vec3d var144 = var15;
               if (var144 != null) {
                  RotationManager var10000 = Prestige.o;
                  Object[] var60 = new Object[]{var15, var8};
                  RotationManager var59 = var10000;
                  Rotation var16 = var59.aReturningdx_C0210(var60);
                  int var146 = var14;
                  Rotation var145 = var16;
                  Rotation var96 = var145;
                  Rotation var95 = var145;
                  if (var146 != 0) {
                     Rotation var147 = var95;
                     if (var147 == null) {
                        return null;
                     }

                     var96 = var16;
                  }

                  Object[] var63 = new Object[0];
                  Rotation var62 = var96;
                  float var151 = var62.aReturningFloat(var63);
                  MinecraftClient var64 = b;
                  ClientPlayerEntity var65 = var64.player;
                  float var152 = var151 - var65.getYaw();
                  Object[] var10003 = new Object[]{null, var4};
                  var10003[0] = var152;
                  Object[] var66 = var10003;
                  float var67 = RotationUtil.bReturningFloat(var66);
                  float var17 = Math.abs(var67);
                  FloatSetting var68 = this.c;
                  Float var69 = (Float)var68.aReturningObject();
                  float var156;
                  int var148 = (var156 = var17 - var69) == 0.0F ? 0 : (var156 < 0.0F ? -1 : 1);
                  if (var148 <= 0) {
                     return var16;
                  }
               }

               return null;
            }
         }

         XbowCart var118 = this;
         var80 = var118;
      }

      Object[] var33 = new Object[]{var10};
      XbowCart var32 = this;
      Object[] var35 = new Object[]{var32.aReturningVec3d(var33), var6};
      XbowCart var34 = var80;
      Rotation var149 = var34.bReturningdx_C0210(var35);
      Rotation var119 = var149;
      if (var119 != null) {
         int var122 = var14;
         Rotation var121 = var149;
         XbowCart var120 = this;
         XbowCart var85 = var120;
         Rotation var86 = var121;
         XbowCart var81 = var120;
         Rotation var82 = var121;
         if (var122 != 0) {
            Rotation var124 = var82;
            XbowCart var123 = var81;
            XbowCart var83 = var123;
            Rotation var84 = var124;
            Object[] var38 = new Object[0];
            Rotation var37 = var84;
            float var10001 = var37.aReturningFloat(var38);
            Object[] var40 = new Object[0];
            Rotation var39 = var149;
            float var10002 = var39.bReturningFloat(var40);
            Object[] var10006 = new Object[]{null, null, this.j, var12};
            var10006[1] = var10002;
            var10006[0] = var10001;
            Object[] var42 = var10006;
            XbowCart var41 = var83;
            boolean var125 = var41.aReturningBoolean(var42);
            if (!var125) {
               return null;
            }

            Rotation var127 = var149;
            XbowCart var126 = this;
            var85 = var126;
            var86 = var127;
         }

         var85.q = var86;
         Object[] var46 = new Object[0];
         Rotation var45 = var149;
         float var153 = var45.aReturningFloat(var46);
         MinecraftClient var47 = b;
         ClientPlayerEntity var48 = var47.player;
         var153 -= var48.getYaw();
         Object[] var155 = new Object[]{null, var4};
         var155[0] = var153;
         Object[] var49 = var155;
         float var50 = RotationUtil.bReturningFloat(var49);
         float var150 = Math.abs(var50);
         FloatSetting var51 = this.c;
         Float var52 = (Float)var51.aReturningObject();
         float var157;
         int var128 = (var157 = var150 - var52) == 0.0F ? 0 : (var157 < 0.0F ? -1 : 1);
         if (var128 <= 0) {
            return var149;
         }
      }

      return null;
   }

   private void nReturningVoid(Object[] var1) {
      BlockHitResult var2 = (BlockHitResult)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 91867885041948L ^ var3;
      int var5 = Event.cReturningInt();
      int var23 = var5;
      MinecraftClient var22 = b;
      MinecraftClient var21 = var22;
      MinecraftClient var20 = var22;
      if (var23 != 0) {
         MinecraftClient var6 = var20;
         MinecraftClient var7 = b;
         BlockHitResult var11 = var2;
         Hand var10 = Hand.MAIN_HAND;
         ClientPlayerEntity var9 = var7.player;
         ClientPlayerInteractionManager var8 = var6.interactionManager;
         ActionResult var12 = var8.interactBlock(var9, var10, var11);
         boolean var24 = var12.isAccepted();
         if (!var24) {
            return;
         }

         MinecraftClient var25 = b;
         var21 = var25;
      }

      MinecraftClient var15 = var21;
      Hand var17 = Hand.MAIN_HAND;
      ClientPlayerEntity var16 = var15.player;
      var16.swingHand(var17);
      RotationManager var26 = Prestige.o;
      Object[] var19 = new Object[]{true};
      RotationManager var18 = var26;
      var18.fReturningVoid(var19);
   }

   private boolean dReturningBoolean(Object[] var1) {
      double var2 = (Double)var1[0];
      double var4 = (Double)var1[1];
      double var6 = (Double)var1[2];
      long var8 = (Long)var1[3];
      var8 = 91867885041948L ^ var8;
      long var10 = var8 ^ 71734436680758L;
      MinecraftClient var22 = b;
      ClientPlayerEntity var23 = var22.player;
      Vec3d var13 = var23.getEyePos();
      Object[] var24 = new Object[]{var10};
      double var14 = ItemUseUtil.bReturningFloat(var24);
      int var10000 = Event.cReturningInt();
      Vec3d var25 = var13;
      double var16 = var2 - var25.x;
      int var12 = var10000;
      Vec3d var26 = var13;
      double var18 = var4 - var26.y;
      Vec3d var27 = var13;
      double var20 = var6 - var27.z;
      double var37;
      var10000 = (var37 = var16 * var16 + var18 * var18 + var20 * var20 - var14 * var14) == 0.0 ? 0 : (var37 < 0.0 ? -1 : 1);
      int var32 = var12;
      int var31 = var10000;
      int var29 = var31;
      int var28 = var31;
      if (var32 != 0) {
         int var33 = var28;
         if (var33 > 0) {
            return false;
         }

         var29 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var29);
   }

   private int dReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      while (true) {
         short var10001 = 27633;
         long var10002 = 4480675208301424804L ^ var2;
         byte var22 = 9;
         int var21 = var5;
         if (var21 < var22) {
            MinecraftClient var11 = b;
            ClientPlayerEntity var12 = var11.player;
            PlayerInventory var36 = var12.getInventory();
            int var14 = var5;
            PlayerInventory var13 = var36;
            ItemStack var15 = var13.getStack(var14);
            Item var16 = var15.getItem();

            label37:
            while (true) {
               Item var6 = var16;
               Item[] var7 = e;
               int var8 = var7.length;
               int var24 = var4;
               byte var23 = 0;
               byte var20 = var23;
               byte var17 = var23;
               if (var24 != 0) {
                  return var20;
               }

               int var9 = var17;

               while (true) {
                  int var26 = var8;
                  int var25 = var9;
                  if (var25 >= var26) {
                     break label37;
                  }

                  Item var10 = var7[var9];
                  int var27 = var4;
                  if (var27 == 0) {
                     int var29 = var4;
                     Item var28 = var6;
                     var16 = var28;
                     Item var18 = var28;
                     if (var29 != 0) {
                        break;
                     }

                     Item var30 = var18;
                     Item var19 = var30;
                     Item var32 = var10;
                     Item var31 = var19;
                     if (var31 == var32) {
                        return var5;
                     }

                     var9++;
                  }

                  int var33 = var4;
                  if (var33 != 0) {
                     break label37;
                  }
               }
            }

            var5++;
            int var34 = var4;
            if (var34 == 0) {
               continue;
            }
         }

         // return var37;
      }
   }

   private int eReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      int var15;
      do {
         short var10001 = 30879;
         long var10002 = 4892125413688364268L ^ var2;
         byte var12 = 9;
         int var11 = var5;
         if (var11 >= var12) {
            break;
         }

         MinecraftClient var6 = b;
         ClientPlayerEntity var7 = var6.player;
         PlayerInventory var17 = var7.getInventory();
         int var9 = var5;
         PlayerInventory var8 = var17;
         ItemStack var10 = var8.getStack(var9);
         Item var18 = var10.getItem();
         Item var14 = Items.FLINT_AND_STEEL;
         Item var13 = var18;
         if (var13 == var14) {
            return var5;
         }

         var5++;
         var15 = var4;
      } while (var15 != 0);

      return -1;
   }

   
   private int fReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      int var63;
      do {
         short var10001 = 30879;
         long var10002 = 4892127818529491220L ^ var2;
         byte var39 = 9;
         int var38 = var5;
         if (var38 >= var39) {
            break;
         }

         label63: {
            MinecraftClient var10 = b;
            ClientPlayerEntity var11 = var10.player;
            PlayerInventory var71 = var11.getInventory();
            int var13 = var5;
            PlayerInventory var12 = var71;
            ItemStack var6 = var12.getStack(var13);
            ItemStack var14 = var6;
            Item var72 = var14.getItem();
            int var41 = var4;
            Item var40 = var72;
            Object var29 = var40;
            Item var26 = var40;
            if (var41 != 0) {
               Item var43 = Items.CROSSBOW;
               Item var42 = var26;
               Item var27 = var42;
               Item var28 = var43;
               Item var45 = var28;
               Item var44 = var27;
               if (var44 != var45) {
                  break label63;
               }

               ComponentType var17 = DataComponentTypes.CHARGED_PROJECTILES;
               ItemStack var16 = var6;
               var29 = var16.get(var17);
            }

            label60:
            while (true) {
               ChargedProjectilesComponent var7 = (ChargedProjectilesComponent)var29;
               int var47 = var4;
               ChargedProjectilesComponent var46 = var7;
               ChargedProjectilesComponent var31 = var46;
               ChargedProjectilesComponent var30 = var46;
               if (var47 != 0) {
                  ChargedProjectilesComponent var48 = var30;
                  if (var48 == null) {
                     break;
                  }

                  var31 = var7;
               }

               ChargedProjectilesComponent var19 = var31;
               List var20 = var19.getProjectiles();
               Iterator var8 = var20.iterator();

               while (true) {
                  Iterator var21 = var8;
                  boolean var49 = var21.hasNext();
                  if (!var49) {
                     break label60;
                  }

                  Iterator var22 = var8;
                  ItemStack var9 = (ItemStack)var22.next();
                  ItemStack var23 = var9;
                  Item var73 = var23.getItem();
                  int var52 = var4;
                  Item var51 = Items.ARROW;
                  Item var50 = var73;
                  Item var67 = var50;
                  Item var68 = var51;
                  Item var32 = var50;
                  Item var33 = var51;
                  if (var52 == 0) {
                     Item var70 = var68;
                     Item var69 = var67;
                     if (var69 != var70) {
                        break label60;
                     }

                     ComponentType var66 = DataComponentTypes.CHARGED_PROJECTILES;
                     ItemStack var65 = var6;
                     var29 = var65.get(var66);
                     break;
                  }

                  int var55 = var4;
                  Item var54 = var33;
                  Item var53 = var32;
                  Item var36 = var53;
                  Item var37 = var54;
                  Item var34 = var53;
                  Item var35 = var54;
                  if (var55 != 0) {
                     Item var57 = var35;
                     Item var56 = var34;
                     if (var56 == var57) {
                        return var5;
                     }

                     ItemStack var25 = var9;
                     Item var74 = var25.getItem();
                     Item var59 = Items.SPECTRAL_ARROW;
                     Item var58 = var74;
                     var36 = var58;
                     var37 = var59;
                  }

                  Item var61 = var37;
                  Item var60 = var36;
                  if (var60 == var61) {
                     return var5;
                  }

                  int var62 = var4;
                  if (var62 == 0) {
                     break label60;
                  }
               }
            }
         }

         var5++;
         var63 = var4;
      } while (var63 != 0);

      return -1;
   }

   private Integer aReturningBoxedInteger(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 91867885041948L ^ var2;
      long var4 = var2 ^ 85888033877354L;
      long var6 = var2 ^ 68293942249210L;
      long var8 = var2 ^ 76617949497971L;
      long var10 = var2 ^ 121474838441313L;
      int var10000 = Event.cReturningInt();
      Object[] var18 = new Object[]{Items.TNT_MINECART, var6};
      Integer var13 = InventoryUtil.aReturningBoxedInteger(var18);
      int var12 = var10000;
      int var81 = var12;
      Integer var80 = var13;
      Integer var54 = var80;
      Integer var53 = var80;
      if (var81 != 0) {
         Integer var82 = var53;
         if (var82 == null) {
            int var14 = -1;
            short var131 = 30879;
            long var10001 = 4892157255336906990L ^ var2;
            int var15 = 9;

            int var56;
            label129: {
               while (true) {
                  short var136 = 6768;
                  long var10002 = 4377181703875080704L ^ var2;
                  byte var85 = 36;
                  int var84 = var15;
                  label126:
                  if (var84 < var85) {
                     int var86 = var12;
                     if (var86 == 0) {
                        break;
                     }

                     MinecraftClient var21 = b;
                     ClientPlayerEntity var22 = var21.player;
                     PlayerInventory var132 = var22.getInventory();
                     int var24 = var15;
                     PlayerInventory var23 = var132;
                     ItemStack var25 = var23.getStack(var24);
                     Item var133 = var25.getItem();
                     Item var88 = Items.TNT_MINECART;
                     Item var87 = var133;
                     if (var87 == var88) {
                        var14 = var15;
                        int var89 = var12;
                        if (var89 != 0) {
                           break label126;
                        }
                     }

                     var15++;
                     int var90 = var12;
                     if (var90 != 0) {
                        continue;
                     }
                  }

                  int var92 = var12;
                  int var91 = var14;
                  var56 = var91;
                  int var55 = var91;
                  if (var92 == 0) {
                     break label129;
                  }

                  // int var93 = var55;
                  if (var93 == var94) {
                     return null;
                  }

                  Object[] var30 = new Object[]{var8};
                  var15 = InventoryUtil.aReturningInt(var30);
                  break;
               }

               var56 = -1;
            }

            int var16 = var56;
            int var65;
            int var66;
            while (true) {
               short var137 = 30879;
               long var138 = 4892157255336906990L ^ var2;
               byte var96 = 9;
               int var95 = var17;
               label110:
               if (var95 < var96) {
                  label139: {
                     int var98 = var12;
                     int var97 = var17;
                     int var62 = var97;
                     int var57 = var97;
                     if (var98 != 0) {
                        int var101 = var12;
                        int var100 = var15;
                        int var99 = var57;
                        var65 = var99;
                        var66 = var100;
                        int var58 = var99;
                        int var59 = var100;
                        if (var101 == 0) {
                           break;
                        }

                        int var103 = var59;
                        int var102 = var58;
                        int var60 = var102;
                        int var61 = var103;
                        int var105 = var61;
                        int var104 = var60;
                        if (var104 == var105) {
                           break label139;
                        }

                        MinecraftClient var33 = b;
                        ClientPlayerEntity var34 = var33.player;
                        PlayerInventory var134 = var34.getInventory();
                        int var36 = var17;
                        PlayerInventory var35 = var134;
                        ItemStack var37 = var35.getStack(var36);
                        var62 = (((var37.isEmpty()) ? 1 : 0));
                     }

                     int var107 = var12;
                     int var106 = var62;
                     int var64 = var106;
                     int var63 = var106;
                     if (var107 != 0) {
                        int var108 = var63;
                        if (var108 == 0) {
                           break label139;
                        }

                        var64 = var17;
                     }

                     var16 = var64;
                     int var109 = var12;
                     if (var109 != 0) {
                        break label110;
                     }
                  }

                  var17++;
                  int var110 = var12;
                  if (var110 != 0) {
                     continue;
                  }
               }

               var66 = -1;
               var65 = var16;
               break;
            }

            int var113 = var12;
            int var112 = var66;
            int var111 = var65;
            int var69 = var111;
            int var70 = var112;
            int var67 = var111;
            int var68 = var112;
            if (var113 != 0) {
               int var115 = var68;
               int var114 = var67;
               if (var114 == var115) {
                  return null;
               }

               var70 = -1;
               var69 = this.p;
            }

            int var77;
            label146: {
               int var78;
               int var79;
               int var118 = var12;
               int var117 = var70;
               int var116 = var69;
               var78 = var116;
               var79 = var117;
               int var71 = var116;
               int var72 = var117;
               label71:
               if (var118 != 0) {
                  label147: {
                     int var120 = var72;
                     int var119 = var71;
                     if (var119 != var120) {
                        label143: {
                           int var122 = var12;
                           PacketQueueManager var121 = Prestige.u;
                           PacketQueueManager var75 = var121;
                           PacketQueueManager var73 = var121;
                           if (var122 != 0) {
                              PacketQueueManager var123 = var73;
                              PacketQueueManager var74 = var123;
                              PacketQueueManager var124 = var74;
                              if (var124 == null) {
                                 break label143;
                              }

                              var75 = Prestige.u;
                           }

                           Object[] var46 = new Object[]{var4};
                           PacketQueueManager var45 = var75;
                           byte var135 = ((byte)((var45.aReturningBoolean(var46)) ? 1 : 0));
                           int var126 = var12;
                           byte var125 = var135;
                           var77 = var125;
                           byte var76 = var125;
                           if (var126 == 0) {
                              break label146;
                           }

                           byte var127 = var76;
                           if (var127 != 0) {
                              break label147;
                           }
                        }

                        this.p = -1;
                        int var128 = var12;
                        if (var128 == 0) {
                           break label147;
                        }
                     }

                     var79 = var16;
                     var78 = var14;
                     break label71;
                  }

                  int var129 = this.p;
                  var77 = var129;
                  break label146;
               }

               Object[] var10004 = new Object[]{null, null, var10};
               var10004[1] = var79;
               var10004[0] = var78;
               Object[] var51 = var10004;
               InventoryUtil.fReturningBoolean(var51);
               this.p = var16;
               int var52 = var16;
               return var52;
            }

            int var50 = var77;
            return var50;
         }

         this.p = -1;
         Integer var83 = var13;
         var54 = var83;
      }

      return var54;
   }

   private boolean lambda$new$0(Float var1) {
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   static {

      {

      f();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(46103798996685L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[7];
      String var4 = "\u000fæ6&§C¦ \\Ömù\u0015Ã+¹R(8\u000fµç¡Cã}\b1àY\u009aÚ\u009b\u0006;`%\u0012&\u008c";
      int var5 = "\u000fæ6&§C¦ \\Ömù\u0015Ã+¹R(8\u000fµç¡Cã}\b1àY\u009aÚ\u009b\u0006;`%\u0012&\u008c".length();
      label23:
      while (true) {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var12 = var6;
         var10001 = var3++;
         long var15 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var15;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var19 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var17) {
               case 0:
                  var12[var10001] = var19;
                  if (var2 >= var5) {
                     s = var6;
                     t = new Integer[7];
                     e = new Item[]{Items.RAIL, Items.POWERED_RAIL, Items.DETECTOR_RAIL, Items.ACTIVATOR_RAIL};
                     break;
                  }
                  break;
               default:
                  var12[var10001] = var19;
                  if (var2 < var5) {
                     continue label23;
                  }

                  var4 = "¸X\u0006<Nxe²\u00199\u0092OñlT\u001a";
                  var5 = "¸X\u0006<Nxe²\u00199\u0092OñlT\u001a".length();
                  var2 = 0;
            }

            int var14 = var2;
            var2 += 8;
            var7 = var4.substring(var14, var2).getBytes("ISO-8859-1");
            var12 = var6;
            var10001 = var3++;
            var15 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var17 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25870;
      if (t[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = s[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])u.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               u.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fK", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         t[var3] = var15;
      }

      return t[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fK_C0291",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fK" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = w[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = v[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 28;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 24;
            yield var19;
         }
         case 5 -> {
            byte var20 = 46;
            yield var20;
         }
         case 6 -> {
            byte var21 = 56;
            yield var21;
         }
         case 7 -> {
            byte var22 = 17;
            yield var22;
         }
         case 8 -> {
            byte var23 = 62;
            yield var23;
         }
         case 9 -> {
            byte var24 = 51;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 21;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 27;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 53;
            yield var30;
         }
         case 16 -> {
            byte var31 = 26;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 47;
            yield var34;
         }
         case 20 -> {
            byte var35 = 43;
            yield var35;
         }
         case 21 -> {
            byte var36 = 34;
            yield var36;
         }
         case 22 -> {
            byte var37 = 15;
            yield var37;
         }
         case 23 -> {
            byte var38 = 13;
            yield var38;
         }
         case 24 -> {
            byte var39 = 7;
            yield var39;
         }
         case 25 -> {
            byte var40 = 11;
            yield var40;
         }
         case 26 -> {
            byte var41 = 25;
            yield var41;
         }
         case 27 -> {
            byte var42 = 5;
            yield var42;
         }
         case 28 -> {
            byte var43 = 42;
            yield var43;
         }
         case 29 -> {
            byte var44 = 9;
            yield var44;
         }
         case 30 -> {
            byte var45 = 18;
            yield var45;
         }
         case 31 -> {
            byte var46 = 30;
            yield var46;
         }
         case 32 -> {
            byte var47 = 39;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 48;
            yield var50;
         }
         case 36 -> {
            byte var51 = 12;
            yield var51;
         }
         case 37 -> {
            byte var52 = 8;
            yield var52;
         }
         case 38 -> {
            byte var53 = 60;
            yield var53;
         }
         case 39 -> {
            byte var54 = 6;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 0;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 52;
            yield var58;
         }
         case 44 -> {
            byte var59 = 44;
            yield var59;
         }
         case 45 -> {
            byte var60 = 54;
            yield var60;
         }
         case 46 -> {
            byte var61 = 45;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 22;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 1;
            yield var66;
         }
         case 52 -> {
            byte var67 = 41;
            yield var67;
         }
         case 53 -> {
            byte var68 = 49;
            yield var68;
         }
         case 54 -> {
            byte var69 = 57;
            yield var69;
         }
         case 55 -> {
            byte var70 = 59;
            yield var70;
         }
         case 56 -> {
            byte var71 = 38;
            yield var71;
         }
         case 57 -> {
            byte var72 = 32;
            yield var72;
         }
         case 58 -> {
            byte var73 = 33;
            yield var73;
         }
         case 59 -> {
            byte var74 = 31;
            yield var74;
         }
         case 60 -> {
            byte var75 = 23;
            yield var75;
         }
         case 61 -> {
            byte var76 = 35;
            yield var76;
         }
         case 62 -> {
            byte var77 = 55;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            w[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      v[0] = "wi'M\b\u0003ai\"\u0017\u001b\u0014v\"!\u0011\u0017\u0000ge6\u0006\\\u0017j";
      v[1] = "\u0012Gfl\u007ffggmcn)\u0006ifhjsr";
      v[2] = void.class;
      w[2] = "java/lang/Void";
      v[3] = "~a\u0013rMnha\u0016(^y\u007f*\u0015.Rmnm\u00029\u0019}vm\u00002C0Jv\u0000/Cw}a";
      v[4] = "~@8%Lfh@=\u007f_q\u007f\u000b>ySenL)n\u0018pQ";
      v[5] = "|t\u001d\\y\t\tT\u0016ShFhZ\u001dXl\u001c\u001c";
      v[6] = "\u000f8^5i\\\u00047Oz\u0005_\n5M5)";
      v[7] = boolean.class;
      w[7] = "java/lang/Boolean";
      v[8] = "!];L\u0011\"7]>\u0016\u00025 \u0016=\u0010\u000e!1Q*\u0007E6\u0003";
      v[9] = "V\n\u0000z|Q]\u0005\u00115\u001d_V\u000e\u0015o";
      v[10] = "[\u0014&A^u[\u00141\u001dRzA_1\u0003RoF.cX\n%";
      v[11] = ">7b\u000ew#>7uR{,$|uL{9#\r/\u0013){";
      v[12] = "\u001ar;-\u0006\"\u001ar,q\n-\u00009,o\n8\u0007H~;[y";
      v[13] = "~<N\u0016'V~<YJ+YdwYT+Lc\u0006\u000b\u000fs\r";
      v[14] = ")\u0018J|@>)\u0018] L13S]>L$4\"\tf\u001b";
      v[15] = "I\u000f~\u0014I\u0011I\u000fiHE\u001eSDiVE\u000bT5;\f\u0012I";
      v[16] = ":N_\"1N$FEmSR#[";
      v[17] = "AG\u0004: Y_O\u001euGXNT\u0013/a^";
      v[18] = "XQ#\u0013\rmNQ&I\u001ezY\u001a%O\u0012nH]2XY|y";
      v[19] = int.class;
      w[19] = "java/lang/Integer";
      v[20] = "HN\u000enHzHN\u00192DuR\u0005\u0019,D`UtCr\u0012+";
      v[21] = ",y/\u0013A.,y8OM!628QM41Ch\f\u001c";
      v[22] = "u+\u0010.9#~$\u0001aZ.k)\u000e\no,z:\u0012&x!";
      v[23] = "\u001b\u000e\u001b\u0004.1\u001b\u000e\fX\">\u0001E\fF\"+\u00064V\u0019pl";
      v[24] = "'\t!>,Z,\u00060qOW9\u0000";
      v[25] = "g{\u0006eSX\u0012[\rjB\u0017sU\u0006aFM\u0007";
      v[26] = "n\r\u001f\u001ddtx\r\u001aGwcoF\u0019A{w~\u0001\u000eV0`r";
      v[27] = double.class;
      w[27] = "java/lang/Double";
      v[28] = "\u0016t<]`\u0015\u0016t+\u0001l\u001a\f?+\u001fl\u000f\u000bNz@>D";
      v[29] = "tQ\n!VJtQ\u001d}ZEn\u001a\u001dcZPikL<\u0003";
      v[30] = "L{Y\u0006q\u007f9[R\t`0XUY\u0002dj,";
      v[31] = "\u0015\u001b\u0016}\u0012u\u0015\u001b\u0001!\u001ez\u000fP\u0001?\u001eo\b!PgL";
      v[32] = "EH'p\u0002f0h,\u007f\u0013)Qf't\u0017s%";
      v[33] = "\u0005P\u00066dYpp\r9u\u0016\u0011~\u00062qLe";
      v[34] = float.class;
      w[34] = "java/lang/Float";
      v[35] = "G>\u0004\u00024KG>\u0013^8D]u\u0013@8QZ\u0004B\u001aa\u0012";
      v[36] = "\u00141&%\"*\u001411y.%\u000ez1g.0\t\u000bd8w";
      v[37] = "\u0014&St]^a\u0006X{L\u0011\u0000\bSpHKt";
      v[38] = "xj\u0012\u0018-jxj\u0005D!eb!\u0005Z!pePT\u0005u3";
      v[39] = "\u00176m!{.\u00176z}w!\r}zcw4\n\f(6$u";
      v[40] = "k2\u0001CB\"}2\u0004\u0019Q5jy\u0007\u001f]!{>\u0010\b\u00161c";
      v[41] = "@?#m\u007f\u00185\u001f(bnWT\u0011#ij\r ";
      v[42] = ".\u0002)zb\u00130\n35\u001f\u00030";
      v[43] = "^\u0000qd8sU\u000f`+Ps[\u0000s";
      v[44] = "\u0005Z^?K\u0003\u0013Z[eX\u0014\u0004\u0011XcT\u0000\u0015VOt\u001f\u0017#";
      v[45] = "^\u0000\u0010\u0011rZ+ \u001b\u001ec\u0015J.\u0010\u0015gO>";
      v[46] = "F2`\u001e]w3\u0012k\u0011L8R\u001c`\u001aHb&";
      v[47] = "f&Q\u0015!\"\u0013\u0006Z\u001a0mr\bQ\u001147\u0006";
      v[48] = "wx)\u0015v?ax,Oe(v3/Ii<gt8^\"+B";
      v[49] = "V\u000e\u0010fX #.\u001biIoB \u0010bM56";
      v[50] = ":|{<_},|~fLj;7}`@~*pjw\u000bi\u0014";
      v[51] = "9^* FDL~!/W\u000b-p*$SQY";
      v[52] = "8\u0002]1ewM\"V>t8,,]5pbX";
      v[53] = "\u001a\u001egZ;J\u001a\u001ep\u00067E\u0000Up\u00187P\u0007$%G`";
      v[54] = " \u0016$XE\u001cU6/WTS48$\\P\t@";
      v[55] = "]pP\u0003BOKpUYQX\\;V_]LM|AH\u0016\\V";
      v[56] = "x2<d\fO\r\u00127k\u001d\u0000l\u001c<`\u0019Z\u0018";
      v[57] = "*>|(i\b!1mg\u000e\n4:m,5";
      v[58] = ",\f9w\"IY,2x3\u00068\"9s7\\L";
      v[59] = "#h\u0016\"HF#h\u0001~DI9#\u0001`D\\>RS:\u0010\u0018";
      v[60] = "M%i\fb\u000fM%~Pn\u0000Wn~Nn\u0015P\u001f,\u00109^";
      v[61] = "N<l1:)N<{m6&Tw{s63S\u0006)-ay";
      v[62] = "/\u0005CW~\u00109\u0005F\rm\u0007.NE\u000ba\u0013?\tR\u001c*\u001a";
      v[63] = "\\X\nb|P)x\u0001mm\u001fHv\nfiE<";
      v[64] = "O\u0013\u000fv\u001d6O\u0013\u0018*\u00119UX\u00184\u0011,R)HaFj";
      v[65] = ",\u0001RnizY!Yax58/Rj|oL";
      v[66] = "7h\u0000@h`BH\u000bOy/#F\u0000D}uW";
      v[67] = "\u00105zm;\u001de\u0015qb*R\u0004\u001bzi.\bp";
      v[68] = "ea/D\u0012 ea8\u0018\u001e/\u007f*8\u0006\u001e:x[iYF";
      v[69] = "t: [\u000e^\u0001\u001a+T\u001f\u0011`\u0014 _\u001bK\u0014";
      v[70] = "\u000biR'\u0019\u0017~IY(\bX\u001fGR#\f\u0002k";
      v[71] = "fu\\ \u001c`\u0013UW/\r/r[\\$\tu\u0006";
      v[72] = "f\u0001&&\u0003\u000e\u0013!-)\u0012Ar/&\"\u0016\u001b\u0006";
      v[73] = "z\bD 'D\u000f(O/6\u000bn&D$2Q\u001a";
      v[74] = "JIE\u001e\u000ee?iN\u0011\u001f*^gE\u001a\u001bp*";
      v[75] = ";!\u001e3\u000f\u000eN\u0001\u0015<\u001eA/\u000f\u001e7\u001a\u001b[";
      v[76] = "a,\fp;-w,\t*(:`g\n,$.q \u001d;o?S";
      v[77] = "<\bU\u001fbTI(^\u0010s\u001b(&U\u001bwA\\";
      v[78] = "lmWq\u0017s\u0019M\\~\u0006<xCWu\u0002f\f";
      v[79] = "\u0006];\u0003\u0015es}0\f\u0004*\u0012s;\u0007\u0000pf";
      v[80] = "u\u0000-D\u0012\u001d\u0000 &K\u0003Ra.-@\u0007\b\u0015";
      v[81] = "\u00036|z/&v\u0016wu>i\u0017\u0018|~:3c";
      v[82] = "\n\nc\u001e+4\n\ntB';\u0010At\\'.\u00170%\u0003\u007fy\u0007\u0003vC5\u0002V['";
      v[83] = "Xfh\rE~Xf\u007fQIqB-\u007fOIdE\\/\u001a\u001d.";
      v[84] = "|sXAW7|sO\u001d[8f8O\u0003[-aI\u001fV\u000fg6u@\u000eI-M%\u0015Y\n";
      v[85] = "hx\u0013[\u0003\u0003hx\u0004\u0007\u000f\fr3\u0004\u0019\u000f\u0019uBTL[S\"~\u000b\u0014\u001d\u0019Y/SG";
      v[86] = "IT>RJG\u0017\u00148\u0002uEO\\A\u0004\u0010\u0018\u0017Rx\u0006\rM[,-\rM\u0011X\u0015/\u0010\u0018]&@$PD^\u001fB9\u0005\b ";
      v[87] = "m>B\u000fQ%?\u007f\u001b\\\tW1mW\u0006\u000f;\u0003:\u0010XVjT=B\u001c\u0004l,p@[\u000bW";
      v[88] = "i5x5oo,!%3\fcRaw;5j-#v.v`R9},wtj d9w\t";
      v[89] = "_(NH(L\u0016,\u001dGC\u001d\u000e!\u0015U\u0014CVv@9r\u0016\u000e)\u001e\u0001x\u0017_<";
      v[90] = "f;$\n\u000f\"%iwl\u0005Ncc)U\n1!b<\u0016\u0000Nc}%R\u000053x#\u0016i";
      v[91] = "\u0010!wI\u0002_O*'\u0011hW\u001eg{\u0016\u0004eJ##NT2\u0010!wI\u0002_O*'\u0011h";
      v[92] = "Q_\bJS,\u0018O\f\u0016o%#\u000f\u0011CV/\\M\u0010V\u0015%#D\u001bW\bpC\r\u000bSTL";
      v[93] = "-G8\u000ejdzG+\u0001\u0007\u007fqD7\bkM&\u0004gU7\u001a!Q-\u0003<blSj\f\u0007";
      v[94] = "z|2z\u0016\u0001u9*}-\u0004t>/wA6 zw -\u0003py?-\u0012\u0007s,&\u0010O\b\"2r/K\u000bw+OrDZi\u007fpvG\u000fpBryW\r\":?{\u0010\u0002\u0019";
      v[95] = "Y\n\"Ar\rLFtG\u001f^WVyAH\f\u0007\u0005!\u001c\u001f\u000fM\u0002`HtV\u0006Ro";
      v[96] = "\u001bDVFn\u0002E\u0004P\u0016Q\u001e\rFU|3\fOL\u0014C7\u000f\u001aU)\u001e8^\u0004\u0001\u0016\u001a;\u000b\u001d<";
      v[97] = "RJ\u0012>oN\fI\u0001w63\u0002%Rdc\n\bZ\u0010evI\u0002%Vnw_P]\u001bl0Pk";
      v[98] = "?q\u001d2xLze@4\u001bL\u0004%\u0012<\"I{g\u0013)aC\u0004%\f0%C\u007fu\t6a*";
      v[99] = "\u001d\u0013\u0013\n=\u001bI\u0012\u001fA*$J\u0014\u001dW=s\u001dNL\u0003Q\u001dB\u0016I_nIC\u001a\u0002H";
      v[100] = "f^TPh\u00051^G_\u0005\u001e:][Vi,l\u001a\u0006\u000e<{3ZGL?\u001b%\\P\u000e\u0005";
      v[101] = "\u0004H|\u0003\u0018\u0018GB}\u0000D}X\u0015}\\@\u0011jA>\u0003\u0017F=Ae\u0003\u0016EZE}W@\u0017=";
      v[102] = "A\u0006:q\u0012#\u001e\rj)x+O@6.\u0014\u0019\u001b\u0004lw@NNYnx\u0006wLD;4x";
      v[103] = "+j$T\u0010`>t3\u000bth[?*\nMb$}+\u001f\u000eh[?4\u0006Jh o1\u0000\u000e\u0001";
      v[104] = "&BA\u001f%X%\u0018V[\u001a@\"\\K\u0005vrr\u001c\u0010R\u001aI*\u0018\u001a\u001c#K7MVb%F A@\u0007|\u0015\"@+";
      v[105] = "tq\u001cCGL+zL\u001b-Dz7\u0010\u001cAv.sHK\u0011!tq\u001cCGL+zL\u001b-";
      v[106] = "\u00192;4\u0018L\u0000+.4e\u001dxb!!\\\u0017\u0007  4\u001f\u001dxf+5\tO\u0000+)r\u0006t";
      v[107] = "@\u001bC^tL\u0005\u000f\u001eX\u0017I{OLP.I\u0004\rMEmC{OR\\)C\u0000\u001fWZm*";
      v[108] = "h#]o\u0011_a+R`-Cp/Xnz\u0014(z\u0007<-Tp#Q>_]x,^";
      v[109] = "_NkGdP\u001aZ6A\u0007_d\u001adI>U\u001bXe\\}_d\u001a<Y;J[M?CjDd";
      v[110] = "\\\u000fxn\u0004W\u000eB&3\u0001k\u000bSqgW<X\u0002$3;RXVq<\u0007\u0000\u0015\b,9";
      v[111] = "X]M\u0014(<W\u0018U\u0013\u00139V\u001fP\u0019\u007f\u000b\nR\f~pbF\t\u000b\u001e\u007f'^\u000e0Cz&WXH\u000exaXc";
      v[112] = "eh_\u0012\u001fV&:\ft\u0012:`0RM\u001aE\"1G\u000e\u0010:8:E\u000f\u0004\u0002!#P\u000fy";
      v[113] = " @7kEAg\u0017wk!\u0019[\u0015%g\u0018\u0013$W$r[\u0019[\u0011/sMK#\\-4Bp";
      v[114] = "\u0010-0:+\u0018N'b,xqG\u001777/HJhu6:\u000b@\u00173=;\u001d\u0012o~?|\u0012)";
      v[115] = "\u0003A6~\u0013[Z\u00124\u007fx[Q^9x\u0014i\u0003\u0013a.x\u000fYC<p@\u0005X\u0012)\u001f";
      v[116] = "@oN(\u0000\u0011\\mZscJR\u0004\u0002'[]_4\fq\u001cB<xW?\u0006N\u0000dU+]-";
      v[117] = "M_\u0005}dZ\u0013UWk73\u001de\u0002p`\n\u0017\u001a@quI\u001de\u0002nl\r\u001d\u001eRkjIt";
      v[118] = "<~\u001d_\r-yw\u0016^u+gp\u001d\\\u001c'^~\u001dL\u0018A=~\u0003]N9p|DRu";
      v[119] = "\u0010,C89NCj\r:DJ|xW~u_EzJ+9!";
      v[120] = "iFa\u0000Q_,R<\u00062\\R\u0012n\u000e\u000bZ-Po\u001bHPR\u0012p\u0002\fP)Bu\u0004H9";
      v[121] = "5\u0007@,\b^#\u0001Wn2P0\u0011X=e\u0007jA\u0004QPWj\f\u0001nTT?\u0015";
      v[122] = "\u0001H\u001as]$\u001d\u0000\nf%!\u000e\u001c\u0002mrvPKZ\u0001\u00140\u0000\u0010\u000b\u007fC0\u0013\u001f";
      v[123] = "@s\u0000NWu\u0017s\u0013A:n\u001cp\u000fHV\\H<P\u001e\n\u000b\u0015w\u0013R\u0000k\u0003q\u0004\u0010:";
      v[124] = ">JGP\"G'SRP_\u0016_\u001a]Ef\u001c X\\P%\u0016_ELB \u0002'\u001aXT&\u007f";
      v[125] = "\u000b\u000bA\u001fFGUKGOy\\\u0003?SJ\u0003M\t\b>G\u0010\u001b\u0014N\u0001C\u0013N\rs\\LBPYLXO\u0017Id";
      v[126] = "db9.y0rdwbH!gb\u000118=\u000e$.&$zvi,a+A";
      v[127] = "s\u0003E\tbQ0\tD\n>4/^DV:X\u001d\n\u0007\tb\u000bJP\u0002Ze^'\u000f\t\n=4";
      v[128] = "]X\u007fd\t\u0006\n[e5\u00079\u001a\ne%\u0018~\ncm=M\b\u001aZo \u0018DdZ:&IE[\r9<\u0018Kd";
      v[129] = "v\b<8X_?\fo73\u000e'\u0001g%dP}]2I\u0002\u0005'\tlq\b\u0004v\u001c";
      v[130] = "G\u0002\u001fz\r^\u0019B\u0019*2RE\u001b\u0004@PP\u0013\n]\u007fTSF\u0013`\"[\u0002XG_&XWAz";
      v[131] = "\u000e~gyu3Pt5o&ZSD`tqcT;\"ud ^Dd~e6\f<)|\"97";
      v[132] = "F*/^\"(_3:^_z'z5KfsX84^%y'%$L m_z0Z&\u0010";
      v[133] = "fw\u0011eFP/sBj-\u00017~Jxz_h.\u0013\u0014\u001c\n7vA,\u0016\u000bfc";
      v[134] = "\u001b0#)8Q^$~/[S d,'bT_&-2!^ d2+e^[47-!7";
      v[135] = "h\u0018\n\u0000?aa\b\n\rM|}\b\r\u0018!N)KRCw\u0019)\u0010\u000f\u0011s`sK\u0016Br\u0019)D\u0010@r|jN\u0011C.\u0019";
      v[136] = "L\u000fF\u0010<\u0001\u0013\u0004\u0016HV\tBIJO:;\u0013\u000b\u0017\u0015flKNVUl\f]HA\u0017V";
      v[137] = "\u0016O\u0005_\u001efZ\u000f\u0001Bfm\u000f\u0014\u0011O8j\u000f\u000e\u00153\u0000q\u0002\f\u0005K_e\u0014\nx";
      v[138] = "\u0011YYAh{R\u000b\n'g\u0017\u0014\u0001T\u001emhV\u0000A]g\u0017L\u000bC\\s/U\u0012V\\\u000e";
      v[139] = "0\u0004\u001b}\r_u\u0010F{nU\u000bP\u0014sWZt\u0012\u0015f\u0014P\u000b\u0005\u0012%_G2\u0007\u000fp\u00139";
      v[140] = "I1\u0001\u0017:D_7\u0016U\u0000A@6\u001d\rls\u0014rFS\u0000FDq\rW?BG$\u0014jbM\u0016:@UfNC#}\bi\u001f]wB\fjJDJ\u0019\u0011|Y\u0017*\u000f\u0017k\u001b-";
      v[141] = "\u0010n+VS\u0002I=)W8\u0002Bq$PT0\u0012=z\u0006\u0004g\u0010v}J]\fI=-E8YE54T\bW\u0013r+7";
      v[142] = "+\u000ekg\re/\u0016?1_\u0002|\u000b92YU+Qol5;vUenR?n\u00013<";
      v[143] = "\u0006\u0016U~\u000f\u0014Q\u0016Fqb\u000fZ\u0015Zx\u000e=\fP\u0007#Rj^\u000bPb]\u0017]QG&b";
      v[144] = "\u0005ry7\u000f\u001d@f$1l\u0016>&v9U\u0018Adw,\u0016\u0012>spo]\u0005\u0007qm:\u0011{";
      v[145] = "wo~}dv>k-r\u000f'&f%`Xy~3~\f>,&n.44-w{";
      v[146] = "\u0019\u000b so\u001cN\u000b3|\u0002\u0007E\b/un5\u0013Js/>bN\u0006&m\u007f\u001a\u0011\u00120k\u0002";
      v[147] = "\"Cn,zIuC}#\u0017R~@a*{`.\f;|\u0017T-Akvw[hYlM";
      v[148] = "8\u000b\u0019Q^5aX\u001bP55j\u0014\u0016WY\u00078YH\b5mn\u0012\u001a\u000bM lU\u00150";
      v[149] = "[?X_`\rH>\u0000H]QM+@F!WKFPT#B\u00007FRm\u000e1";
      v[150] = "v\u0017!|\u0016t3\u0003|zu{MC.rLq2\u0001/g\u000f{M\u001e6`\b(-\b0wJ\u0012";
      v[151] = "V#\u0016:\u0014D\u0001 \fk\u001a{\u000e~\u0014X\u0001\u001f\u0012uhj\rC^fQh\u0010\u0016\u0012\u0018";
      v[152] = "\u000b<\u001b:LAU|\u001djsZ\u0003\u001e\rl\u0012O\u0002?db\u001a\u001d\u0014y[f\u0019H\rD\u0006iHVY{\u0002j\u001dOd";
      v[153] = "\u0007`\n\u00028\u0017\u0011fDN\t\u0000\u0000k\bp7\fUk\u0017@9Z\u0012tt";
      v[154] = "\u0005dIyt-[$O)K!\rg6!\"q\u001a!\t%!$\u0003\u001cT*p:W#P)%#j";
      v[155] = "lh\u0006k\u0013\u00012/\u0003z\u0017m2-U`\u0016\u00041WUdH\\+nWy\u001d\u0010U";
      v[156] = "+=\u001d^|^u}\u001b\u000eCP.>b\u00021P;8\u001a]%F=E\u0004\u0016*F9=[\u0002<@D";
      v[157] = ".|@q#pgx\u0013~H!\u007fu\u001bl\u001f\u007f.$O\u0000y*\u007f}\u00108s+.h";
      v[158] = "\u0016\u0001z*U0\u001f\u0019xy\u001cTA\u0005w,\u0001\u0003\u0016['u\\T\u0016\u0001z*U0\u001f\u0019xy\u001c";
      v[159] = "EH*\u001c_\u0005\u0000\\w\u001a<\u0001~\u001c%\u0012\u0005\u0000\u0001^$\u0007F\n~\u001c;\u001e\u0002\n\u0005L>\u0018Fc";
      v[160] = "Z.\u0018\u0012Fu\u0006hX\u000eM\u0018\u0006{\u0019\u0016Kt4,UG\u0012\u0018Ri\n\u0017Af\u0005i\u0019\u0018,!^r\bI\u0010s\u0013,UL,!SkZIIbYjY\u0015,!]\u007f\fO^s\u001c&_\u0017,";
      v[161] = "YRX\u001dG$\u0010V\u000b\u0012,u\b[\u0003\u0000{+S\rYl\u001d~\bS\bT\u0017\u007fYF";
      v[162] = "s\u0013y\tx>e\u0015nKB0v\u0005a\u0018\u0015g,U?t 7,\u00188K$4y\u0001";
      v[163] = "WF/@\u00023A@8\u00028=RP7Qoj\b\u0000j=Z:\bMn\u0002^9]T";
      v[164] = ";$C7=M<$AbR[\u0001&H~kD|xKm\"\u001d";
      v[165] = "\u001bT'0)LE^u&z%Kn =-\u001cA\u0011b<8_Kn e=\u0019^Qwf'HPn";
      v[166] = "\b;W\u000b)M\u0014sG\u001eQH\u0007oO\u0015\u0006\u001fY<\u0016yhLXaNGh\u0019\u000b<A";
      v[167] = "^\u0004OM}u\u0001\u000f\u001f\u0015\u0017}PBC\u0012{O\u0001\u000f\u001dN(\u0018_W\u0018\u0005*'[TM\u001c\u0017zT\u0005SH(~WPJuuq\u0006N\u001eJqrSW#\u0016-t\u0005TNI&$]>";
      v[168] = "\u0015j/_\n)\u0003,{Mr1\u0015+#@\u001e\u0003Eh\u007f\u001cMT\u0012.!WOi\u0001/y@r";
      v[169] = "2z \u000eE_.20\u001b=Z=.8\u0010j\rbsc|EX;<.\u0004LH;1";
      v[170] = "<\n7h1\u001bc\u0001g0[\u00132L;77!f\ban`v3Uca%O1H6-[";
      v[171] = "*\u0016\\c\u0018?-Q\u001fhc,T\u0017\u00036Z%+U\u0002#\u0019/TH\u00121\u001c;,\u0017\u0006'\u001aF";
      v[172] = "g\u0011xUM2\"\u0005%S.=\\Ew[\u00177#\u0007vNT=\\A}OBo$\f\u007f\bMT";
      v[173] = "_\u0019j$\u0019j\u0007\u0018gv(eU\u0018:(DW\u0002Z`w\u0016\u0000B]g=Q<[\\$!(c\u0002\bb%E<\tX:OQaY\tf=XiV\u0006ZrAzT_\"?C=[d";
      v[174] = "M'vkwz\u001ea8i\n\u007f!sb-;k\u0018q\u007fxw\u0015";
      v[175] = "6_I~Xah\u001fO.g}8A6&\u000e=)\u001a\t\"\rh0'T-\\vd\u0018P.\toY";
      v[176] = "s;e\u0014;[osu\u0001C^|o}\n\u0014\t\"< fz\b`fs\u000b&N zx";
      v[177] = "\u0001[s%\u00011H_ *j`PR(8=>\u0001\u000fpT[kPZ#lQj\u0001O";
      v[178] = "q@{\u001b^x.K+C4p\u007f\u0006wDXB+B-\u001d\b\u0015~\u001f/\u0012J,|\u0002z^4";
      v[179] = "^o\u0001n,R\u0017kRaG\u0003\u000ffZs\u0010]V5\u000f\u001fv\b\u000fnQ'|\t^{";
      v[180] = "A$)\u0018AV\u001c (N ]|\u007f;IPWLqm\u000eO4";
      v[181] = "&e\u001d\u0018h\u001de7N~`q#=\u0010Gm\u000ea<\u0005\u0004gq##\u001c@g\ns&\u001a\u0004\u000e";
      v[182] = "/Q] OOl\u0003\u000eFD#*\tP\u007fJ\\h\bE<@#*\u0017\\x@Xz\u0012Z<)";
      v[183] = ">\u00056\u0018IM{\u0011k\u001e*G\u0005Q9\u0016\u0013Hz\u00138\u0003PB\u0005U3\u0002F\u0010}\u00181EI+";
      v[184] = "\u001a\u0016\u0013m\r`_\u0002Nkno!\u0015\u0006}\ff\u001d\u0015\u001er\u001c\u0006O\u0002\u000fo\u000e:O\u001a\u0000\u007fn";
      v[185] = "R%O\b'k\u000ec\u000f\u0014,\u0006\u000epN\f*j<'\u0003U|\u0006R _QpoTwC\f$\u0006R V\u0001r:\u0000m\b\\w\u0006R#[\u0005tt\u0000b\u0002V,\u0006";
      v[186] = "8\u00114p\u0013<g\u001ad(y<\"V1,\u0002QeA`8\u001aak\u0017''yl2Q4s\u0001!0\u0016;H";
      v[187] = ",cr^S}+cp\u000b<q\u0016d-\rZpz'\u007f^";
      v[188] = "~Ef \u000ex)Eu/cc\"Fi&\u000fQq\u00031}c?r^d~_m?\u00009{c?2X7(\u0018o7^sA";
      v[189] = "\u0002@m\u0004\f\r\\J?\u0012_dRzj\t\b]X\u0005(\b\u001d\u001eRz?\u000f^UEC=\u0012\u000b\u0019;";
      v[190] = "b\u001c5yist\u001a\";Svk\u001b)c?D?_s>Sw}\u001b4>3a{\fv\u00041z=\u0017t;5yh\u000eI";
      v[191] = "_R0]xG\u0007S=\u000fIHUS`Q%z\u0004\u0012<\tu-\u0005FzZrUHD=UI";
      v[192] = "KJrN1\f\u000e^/HR\u0003p\u001e}@k\t\u000f\\|U(\u0003pD$Bj\u0000\u001d\u001b/\u00122j";
      v[193] = "?'bho]67be\u001d@*7epqrwp?/\u001dF}'=}p\u0019vwe\u0017zXw 4}\"Yzr\u0005";
      v[194] = "#-jkn\bj)9d\u0005Yr$1vR\u0007)pl\u001a4Rr,:\">S#9";
      v[195] = "zznxS^$:h(lPncwB\u000eP.r,}\nS{k\u0011 \u0005\u0002e?.$\u0006W|\u0002";
      v[196] = "\u000f\u000b9g\u0000NJ\u001fdacF4_6iZKK\u001d7|\u0019A4\n0?RV\r\b-j\u001e(";
      v[197] = "j\u0018R\u001b \u001b4XTK\u001f\u0015y\tK\u001b\u001f\u001el[]\u001c \u001ao\u000eD!}\u0015>\u0010\u0010\u001ey\u0016k\t-CvGu]\u0012Gu\u0012l`";
      v[198] = "\t#B|ta\u001c=U#\u0010iyrF6|;\u0001?Dqs\u0000";
      v[199] = "\u0001^H\u0005\u001b#F\t\b\u0005\u007fxz\u000bZ\tFq\u0005I[\u001c\u0005{zTK\u000e\u0000o\u0002\u000b_\u0018\u0006\u0012";
      v[200] = "y\u0012\u0006\u0007\n+vW\u001e\u00001.wP\u001b\n]\u001c#\u0014BQ1)s\u0017\u000bP\u000e-pB\u0012mRugF@\r]0\u007fA{";
      v[201] = ".nU9XSmdT:\u00046r3Tf\u0000Z@g\u00179W\u000e\u0017'Ig\n\ne.Ah\u00056";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = v[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(w[var4]);
            v[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            v[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  v[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(640465005949648L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = v[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = w[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  v[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(640465005949648L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        v[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(640465005949648L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 229;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 164;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 98;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 65;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 198;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 83;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 229;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 164;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 98;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fK_C0291",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fK" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1(XbowCart var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/fK_C0291;)Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/fK_C0291", "lambda$new$0", "(Ljava/lang/Float;)Z"),
                  SourceSupport.methodType("(Ljava/lang/Float;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var2.invokeExact((XbowCart)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
