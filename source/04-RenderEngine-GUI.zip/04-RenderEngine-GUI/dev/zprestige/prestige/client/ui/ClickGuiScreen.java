package dev.zprestige.prestige.client.ui;

import dev.zprestige.prestige.client.ui.gui.ClickGui;
import dev.zprestige.prestige.client.ui.gui.MenuState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;

public class ClickGuiScreen extends ClientScreen {
   private static final ClickGui GUI = new ClickGui();

   public void aReturningVoid(Object[] var1) {
      MenuState.open();
   }

   @Override
   public void render(DrawContext context, int mouseX, int mouseY, float delta) {
      if (!MenuState.isOpen()) {
         close();
         return;
      }
      GUI.viewport(this.width, this.height);
      GUI.mouse(mouseX, mouseY);
   }

   @Override
   public boolean mouseClicked(Click click, boolean doubled) {
      if (!MenuState.isOpen()) {
         return false;
      }
      if (GUI.mouseClicked(scaledMouseX(), scaledMouseY(), click.button())) {
         return true;
      }
      return super.mouseClicked(click, doubled);
   }

   @Override
   public boolean mouseReleased(Click click) {
      GUI.mouseReleased(scaledMouseX(), scaledMouseY(), click.button());
      return super.mouseReleased(click);
   }

   @Override
   public boolean mouseDragged(Click click, double offsetX, double offsetY) {
      GUI.mouseDragged(scaledMouseX(), scaledMouseY(), click.button(), offsetX, offsetY);
      return true;
   }

   @Override
   public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      if (GUI.mouseScrolled(mouseX, mouseY, verticalAmount)) {
         return true;
      }
      return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   @Override
   public boolean keyPressed(KeyInput input) {
      if (GUI.keyPressed(input.key())) {
         return true;
      }
      if (input.isEscape()) {
         close();
         return true;
      }
      return super.keyPressed(input);
   }

   @Override
   public boolean charTyped(CharInput input) {
      if (input.isValidChar() && GUI.charTyped((char) input.codepoint())) {
         return true;
      }
      return super.charTyped(input);
   }

   @Override
   public boolean shouldPause() {
      return false;
   }

   @Override
   public void close() {
      MenuState.close();
      super.close();
   }

   private double scaledMouseX() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.mouse.getX() / client.getWindow().getScaleFactor();
   }

   private double scaledMouseY() {
      MinecraftClient client = MinecraftClient.getInstance();
      return client.mouse.getY() / client.getWindow().getScaleFactor();
   }
}
