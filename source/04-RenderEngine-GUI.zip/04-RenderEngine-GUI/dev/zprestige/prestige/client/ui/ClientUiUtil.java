package dev.zprestige.prestige.client.ui;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import dev.zprestige.prestige.client.ui.MenuSettings;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.MathHelper;

public class ClientUiUtil {
   protected float a;
   protected float b;
   protected float c;
   protected float d;
   protected String e;
   private static final long f = 8617489741088L;
   private static final String[] g;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[55];
   private static final String[] n = new String[55];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;

   public ClientUiUtil(float var1, float var2, float var3, float var4, String var5) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
   }

   public static Color aReturningColor(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 8617489741088L ^ var2;
      return new Color(
         invokeBinding1(15490, 1795564646195230140L ^ var2) + var1,
         invokeBinding2(23628, 4506225669446604144L ^ var2) + var1,
         invokeBinding3(23628, 4506225669446604144L ^ var2) + var1
      );
   }

   public static Color bReturningColor(Object[] var0) {
      Color var3 = (Color)var0[0];
      float var4 = (Float)var0[1];
      long var1 = (Long)var0[2];
      long var10000 = 8617489741088L ^ var1;
      Color var5 = var3;
      float var10002 = var5.getRed() / 255.0F;
      Color var6 = var3;
      float var10003 = var6.getGreen() / 255.0F;
      Color var7 = var3;
      float var10004 = var7.getBlue() / 255.0F;
      float var10 = 1.0F;
      float var9 = 0.0F;
      float var8 = var4;
      return new Color(var10002, var10003, var10004, MathHelper.clamp(var8, var9, var10));
   }

   public static Color cReturningColor(Object[] var0) {
      float var1 = (Float)var0[0];
      float var2 = (Float)var0[1];
      long var3 = (Long)var0[2];
      var3 = 8617489741088L ^ var3;
      return new Color(var1, var1, var1, invokeBinding4(var2, 0.0F, 1.0F, -9038256729436244514L, var3));
   }

   public static Color dReturningColor(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 8617489741088L ^ var1;
      ModuleManager var8 = Prestige.d;
      Object[] var4 = new Object[0];
      ModuleManager var3 = var8;
      MenuSettings var9 = var3.aReturningMenuSettings(var4);
      Object[] var6 = new Object[0];
      MenuSettings var5 = var9;
      ColorSetting var7 = var5.bReturningColorSetting(var6);
      return (Color)var7.aReturningObject();
   }

   public static float aReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      float var5 = (Float)var0[1];
      float var4 = (Float)var0[2];
      long var2 = (Long)var0[3];
      long var10000 = 8617489741088L ^ var2;
      int var6 = Event.cReturningInt();
      int var17 = var6;
      float var16 = var5;
      float var15 = var1;
      float var13 = var15;
      float var14 = var16;
      float var11 = var15;
      float var12 = var16;
      if (var17 != 0) {
         float var19;
         int var18 = (var19 = var11 - var12) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
         if (var18 < 0) {
            return var5;
         }

         var14 = var4;
         var13 = var1;
      }

      float var10 = var14;
      float var9 = var13;
      return Math.min(var9, var10);
   }

   public static float bReturningFloat(Object[] var0) {
      float var5 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var4 = (Float)var0[2];
      long var1 = (Long)var0[3];
      var1 = 8617489741088L ^ var1;
      long var6 = var1 ^ 105693862951822L;
      float var10001 = var5 - var3;
      Object[] var10007 = new Object[]{null, null, null, var6};
      var10007[2] = 1.0F;
      var10007[1] = 0.0F;
      var10007[0] = var4;
      Object[] var8 = var10007;
      return var5 - var10001 * aReturningFloat(var8);
   }

   public static float cReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      int var4 = (Integer)var0[1];
      long var2 = (Long)var0[2];
      long var10000 = 8617489741088L ^ var2;
      int var13 = var4;
      if (var13 < 0) {
         throw new IllegalArgumentException();
      }

      double var7 = var1;
      BigDecimal var5 = BigDecimal.valueOf(var7);
      RoundingMode var11 = RoundingMode.FLOOR;
      int var10 = var4;
      BigDecimal var9 = var5;
      var5 = var9.setScale(var10, var11);
      BigDecimal var12 = var5;
      return var12.floatValue();
   }

   public static String aReturningString(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 8617489741088L ^ var2;
      HashMap var4 = new HashMap();
      short var10001 = 31425;
      long var10002 = 6858321147028352969L ^ var2;
      Integer var53 = 9999;
      short var74 = 30382;
      long var10003 = 3728079849370024040L ^ var2;
      String var8 = "LMB";
      Integer var7 = var53;
      HashMap var6 = var4;
      var6.put(var7, var8);
      var10001 = 22083;
      var10002 = 7947995214053114697L ^ var2;
      Integer var55 = 9998;
      short var76 = 25224;
      var10003 = 6167305357840968770L ^ var2;
      String var12 = "RMB";
      Integer var11 = var55;
      HashMap var10 = var4;
      var10.put(var11, var12);
      var10001 = 27975;
      var10002 = 478221382914586690L ^ var2;
      Integer var57 = 9997;
      short var78 = 14861;
      var10003 = 8232427883278021828L ^ var2;
      String var16 = "MMB";
      Integer var15 = var57;
      HashMap var14 = var4;
      var14.put(var15, var16);
      short var58 = 56;
      var10002 = 2515234657122407732L ^ var2;
      Integer var59 = 9996;
      short var80 = 12176;
      var10003 = 3003336160972185944L ^ var2;
      String var20 = "MB4";
      Integer var19 = var59;
      HashMap var18 = var4;
      var18.put(var19, var20);
      var58 = 23632;
      var10002 = 1676050401857702239L ^ var2;
      Integer var61 = 9995;
      short var82 = 21066;
      var10003 = 3689448721166752904L ^ var2;
      String var24 = "MM5";
      Integer var23 = var61;
      HashMap var22 = var4;
      var22.put(var23, var24);
      var58 = 28261;
      var10002 = 5465609089862679395L ^ var2;
      Integer var63 = 345;
      short var84 = 26884;
      var10003 = 4844009380835256260L ^ var2;
      String var28 = "R-Ctrl";
      Integer var27 = var63;
      HashMap var26 = var4;
      var26.put(var27, var28);
      var58 = 10462;
      var10002 = 2337225947632991699L ^ var2;
      Integer var65 = 344;
      short var86 = 20932;
      var10003 = 7053448808161468167L ^ var2;
      String var32 = "Right Shift";
      Integer var31 = var65;
      HashMap var30 = var4;
      var30.put(var31, var32);
      var58 = 21390;
      var10002 = 2394777243785135753L ^ var2;
      Integer var67 = 342;
      short var88 = 32395;
      var10003 = 4924378993071288398L ^ var2;
      String var36 = "L-Alt";
      Integer var35 = var67;
      HashMap var34 = var4;
      var34.put(var35, var36);
      var58 = 12907;
      var10002 = 3327078517659985765L ^ var2;
      Integer var69 = 341;
      short var90 = 21245;
      var10003 = 8226825172655791164L ^ var2;
      String var40 = "L-Ctrl";
      Integer var39 = var69;
      HashMap var38 = var4;
      var38.put(var39, var40);
      var58 = 19006;
      var10002 = 4063720515012697914L ^ var2;
      Integer var71 = 340;
      short var92 = 24157;
      var10003 = 6215018210933690521L ^ var2;
      String var44 = "Shift";
      Integer var43 = var71;
      HashMap var42 = var4;
      var42.put(var43, var44);
      var58 = 4960;
      var10002 = 7862905975659677282L ^ var2;
      Integer var73 = 258;
      short var94 = 20513;
      var10003 = 5582179143991746278L ^ var2;
      String var48 = "Tab";
      Integer var47 = var73;
      HashMap var46 = var4;
      var46.put(var47, var48);
      int var49 = var1;
      Integer var51 = var49;
      HashMap var50 = var4;
      return (String)var50.get(var51);
   }

   public static void aReturningVoid(Object[] var0) {
      String var2 = (String)var0[0];
      float var4 = (Float)var0[1];
      float var1 = (Float)var0[2];
      Color var3 = (Color)var0[3];
      long var5 = (Long)var0[4];
      var5 = 8617489741088L ^ var5;
      long var7 = var5 ^ 107653246889208L;
      long var9 = var5 ^ 80606890670510L;
      MsdfFont var10000 = invokeBinding6(invokeBinding5(-6857064736457363939L, var5), new Object[]{var9}, -6856105853318260893L, var5);
      Object[] var10007 = new Object[]{null, null, null, var3, var7};
      var10007[2] = var1;
      var10007[1] = var4;
      var10007[0] = var2;
      invokeBinding7(var10000, var10007, -6855259272420286915L, var5);
   }

   public static void bReturningVoid(Object[] var0) {
      String var1 = (String)var0[0];
      float var6 = (Float)var0[1];
      float var5 = (Float)var0[2];
      Color var2 = (Color)var0[3];
      long var3 = (Long)var0[4];
      var3 = 8617489741088L ^ var3;
      long var7 = var3 ^ 30088129456243L;
      long var9 = var3 ^ 39190389608638L;
      MsdfFont var10000 = invokeBinding9(invokeBinding8(-5689280112868393024L, var3), new Object[]{var7}, -5690462920514992450L, var3);
      Object[] var10008 = new Object[]{null, null, null, null, var2, var9};
      var10008[3] = 0.8F;
      var10008[2] = var5;
      var10008[1] = var6;
      var10008[0] = var1;
      invokeBinding10(var10000, var10008, -5691014478322865007L, var3);
   }

   public static void cReturningVoid(Object[] var0) {
      String var2 = (String)var0[0];
      float var5 = (Float)var0[1];
      float var1 = (Float)var0[2];
      Color var6 = (Color)var0[3];
      long var3 = (Long)var0[4];
      var3 = 8617489741088L ^ var3;
      long var7 = var3 ^ 101471321604330L;
      long var9 = var3 ^ 110708873279527L;
      MsdfFont var10000 = invokeBinding12(invokeBinding11(6454461964840605529L, var3), new Object[]{var7}, 6457648442398010919L, var3);
      Object[] var10008 = new Object[]{null, null, null, null, var6, var9};
      var10008[3] = 0.9F;
      var10008[2] = var1;
      var10008[1] = var5;
      var10008[0] = var2;
      invokeBinding13(var10000, var10008, 6457092518208406536L, var3);
   }

   public static float dReturningFloat(Object[] var0) {
      String var1 = (String)var0[0];
      long var2 = (Long)var0[1];
      var2 = 8617489741088L ^ var2;
      long var4 = var2 ^ 15621104007004L;
      long var6 = var2 ^ 83436803988510L;
      return invokeBinding16(
         invokeBinding15(invokeBinding14(389224224404556717L, var2), new Object[]{var6}, 390188777973789395L, var2),
         new Object[]{var1, var4},
         389708216928319524L,
         var2
      );
   }

   public static float eReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 8617489741088L ^ var1;
      long var3 = var1 ^ 129386084588564L;
      long var5 = var1 ^ 93069797772366L;
      return invokeBinding19(
         invokeBinding18(invokeBinding17(6140326149276834813L, var1), new Object[]{var5}, 6141262717942817411L, var1),
         new Object[]{var3},
         6141924193139564347L,
         var1
      );
   }

   public void dReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      SourceSupport.discard(var1[1]);
      SourceSupport.discard(var1[2]);
      SourceSupport.discard(var1[3]);
   }

   public void eReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      SourceSupport.discard(var1[1]);
      SourceSupport.discard(var1[2]);
   }

   public void fReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      SourceSupport.discard(var1[1]);
      SourceSupport.discard(var1[2]);
   }

   public void gReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      SourceSupport.discard(var1[1]);
      SourceSupport.discard(var1[2]);
   }

   public void hReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
      SourceSupport.discard(var1[1]);
   }

   public void iReturningVoid(Object[] var1) {
      this.e = null;
   }

   public float fReturningFloat(Object[] var1) {
      return this.a;
   }

   public void jReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.a = var2;
   }

   public float gReturningFloat(Object[] var1) {
      return this.b;
   }

   public void kReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.b = var2;
   }

   public float hReturningFloat(Object[] var1) {
      return this.c;
   }

   public void lReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.c = var2;
   }

   public float iReturningFloat(Object[] var1) {
      return this.d;
   }

   public void mReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.d = var2;
   }

   public String bReturningString(Object[] var1) {
      return this.e;
   }

   public void nReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      this.e = var2;
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(93955872902709L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[11];
      String var17 = "Ü\u001cã»\u0080\u0000\u0004\u00adÔ\u001b\u0084°\u0007S-ô\u0010Âàòw\\\u009bó\u009c\n)ú_±M\u009e\u0096\u0010O©\u0019èÖLÁl\u0015ï\u0093gA1l\u0016 S?\u0015mx\u0012#¦éã>K\u0093 IÊ\\ÎmFìC§fsU\u0011\u0002È\u0018\u0013ø\u0010Ç\u0017?¯ÃrÃ-´6GÀ}³\b0\u0010Ô,I\\µ*8r¼Aâ\u0090X\u0090×\u0080\u0010O\u0013±Äô\t^y°2[\u0083¯aª3\u0010v\u0007mû\u0088Ñ\u0016æ÷À$pÚçH½\u0010Ü\u000fÑ¾\u0084\u008bM6²Ðþó\u008eb5ï";
      int var19 = "Ü\u001cã»\u0080\u0000\u0004\u00adÔ\u001b\u0084°\u0007S-ô\u0010Âàòw\\\u009bó\u009c\n)ú_±M\u009e\u0096\u0010O©\u0019èÖLÁl\u0015ï\u0093gA1l\u0016 S?\u0015mx\u0012#¦éã>K\u0093 IÊ\\ÎmFìC§fsU\u0011\u0002È\u0018\u0013ø\u0010Ç\u0017?¯ÃrÃ-´6GÀ}³\b0\u0010Ô,I\\µ*8r¼Aâ\u0090X\u0090×\u0080\u0010O\u0013±Äô\t^y°2[\u0083¯aª3\u0010v\u0007mû\u0088Ñ\u0016æ÷À$pÚçH½\u0010Ü\u000fÑ¾\u0084\u008bM6²Ðþó\u008eb5ï"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = a(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     g = var20;
                     h = new String[11];
                     l = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(93955872902709L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[13];
                     String var4 = "\u0099\u0081C\u009ac½9ÏÆ\u0018ËTÎ¤Ìsð\u009d\n\u0012)KÔ\u0005èËäk\u0081\u0097Dä,d\u0018¨\"\u009e1\u0007KU1\u0088ÆÙ>°¹\u009føH@ÅîÂ£Üª\u008fvèa³.\u0000«\u0014V\u000e\nÜD¿#ÆT´\u0084\u0091\u0095-G\u0013\u009fÚî³";
                     int var5 = "\u0099\u0081C\u009ac½9ÏÆ\u0018ËTÎ¤Ìsð\u009d\n\u0012)KÔ\u0005èËäk\u0081\u0097Dä,d\u0018¨\"\u009e1\u0007KU1\u0088ÆÙ>°¹\u009føH@ÅîÂ£Üª\u008fvèa³.\u0000«\u0014V\u000e\nÜD¿#ÆT´\u0084\u0091\u0095-G\u0013\u009fÚî³"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[13];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0096-$\u0092\u0013¿ñ`¤\u0086 \u0089\u008bà}\u000b";
                                 var5 = "\u0096-$\u0092\u0013¿ñ`¤\u0086 \u0089\u008bà}\u000b".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "\u0093\nV©Q\u0019âW>Å\\\u0007Ofh³\u0010Õyy¢\u0083\u0005ÏÃLucvÎ\u009b}¼";
                  var19 = "\u0093\nV©Q\u0019âW>Å\\\u0007Ofh³\u0010Õyy¢\u0083\u0005ÏÃLucvÎ\u009b}¼".length();
                  var16 = 16;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static IllegalArgumentException a(IllegalArgumentException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 22836;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/aB", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = g[var5].getBytes("ISO-8859-1");
         h[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/aB_C0005",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/aB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 762;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/aB", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/aB_C0005",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/aB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 42;
            yield var15;
         }
         case 1 -> {
            byte var16 = 32;
            yield var16;
         }
         case 2 -> {
            byte var17 = 3;
            yield var17;
         }
         case 3 -> {
            byte var18 = 50;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 35;
            yield var20;
         }
         case 6 -> {
            byte var21 = 55;
            yield var21;
         }
         case 7 -> {
            byte var22 = 40;
            yield var22;
         }
         case 8 -> {
            byte var23 = 25;
            yield var23;
         }
         case 9 -> {
            byte var24 = 43;
            yield var24;
         }
         case 10 -> {
            byte var25 = 47;
            yield var25;
         }
         case 11 -> {
            byte var26 = 59;
            yield var26;
         }
         case 12 -> {
            byte var27 = 45;
            yield var27;
         }
         case 13 -> {
            byte var28 = 41;
            yield var28;
         }
         case 14 -> {
            byte var29 = 61;
            yield var29;
         }
         case 15 -> {
            byte var30 = 27;
            yield var30;
         }
         case 16 -> {
            byte var31 = 58;
            yield var31;
         }
         case 17 -> {
            byte var32 = 12;
            yield var32;
         }
         case 18 -> {
            byte var33 = 22;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 34;
            yield var35;
         }
         case 21 -> {
            byte var36 = 28;
            yield var36;
         }
         case 22 -> {
            byte var37 = 8;
            yield var37;
         }
         case 23 -> {
            byte var38 = 14;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 37;
            yield var40;
         }
         case 26 -> {
            byte var41 = 18;
            yield var41;
         }
         case 27 -> {
            byte var42 = 53;
            yield var42;
         }
         case 28 -> {
            byte var43 = 39;
            yield var43;
         }
         case 29 -> {
            byte var44 = 16;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 51;
            yield var46;
         }
         case 32 -> {
            byte var47 = 57;
            yield var47;
         }
         case 33 -> {
            byte var48 = 4;
            yield var48;
         }
         case 34 -> {
            byte var49 = 46;
            yield var49;
         }
         case 35 -> {
            byte var50 = 31;
            yield var50;
         }
         case 36 -> {
            byte var51 = 63;
            yield var51;
         }
         case 37 -> {
            byte var52 = 6;
            yield var52;
         }
         case 38 -> {
            byte var53 = 38;
            yield var53;
         }
         case 39 -> {
            byte var54 = 23;
            yield var54;
         }
         case 40 -> {
            byte var55 = 7;
            yield var55;
         }
         case 41 -> {
            byte var56 = 33;
            yield var56;
         }
         case 42 -> {
            byte var57 = 0;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 20;
            yield var59;
         }
         case 45 -> {
            byte var60 = 10;
            yield var60;
         }
         case 46 -> {
            byte var61 = 11;
            yield var61;
         }
         case 47 -> {
            byte var62 = 1;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 5;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 17;
            yield var66;
         }
         case 52 -> {
            byte var67 = 26;
            yield var67;
         }
         case 53 -> {
            byte var68 = 48;
            yield var68;
         }
         case 54 -> {
            byte var69 = 56;
            yield var69;
         }
         case 55 -> {
            byte var70 = 21;
            yield var70;
         }
         case 56 -> {
            byte var71 = 54;
            yield var71;
         }
         case 57 -> {
            byte var72 = 60;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 24;
            yield var74;
         }
         case 60 -> {
            byte var75 = 2;
            yield var75;
         }
         case 61 -> {
            byte var76 = 9;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 19;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      m[0] = "K,6\u001aoH],3@|_Jg0FpK[ 'Q;]\u001c";
      m[1] = "<\\)\u007fB,I|\"pSc(r){W9\\";
      m[2] = "M_>i6f[_;3%qL\u001485)e]S/\"br`";
      m[3] = "D@r\u0016J\fR@wLY\u001bE\u000btJU\u000fTLc]\u001e\u0018f";
      m[4] = "\u0012\u0003]\u0010n\"\u0019\fL_\u000f,\u0012\u0007H\u0005";
      m[5] = "\rb1GS%\u001bb4\u001d@2\f)7\u001bL&\u001dn \f\u00076.";
      m[6] = "2!J\u000f8MG\u0001A\u0000)\u0002&\u000fJ\u000b-XR";
      m[7] = "wB{F\u0014)aB~\u001c\u0007>v\t}\u001a\u000b*gNj\r@:\u007fNh\u0006\u001awCUh\u001b\u001a0tB";
      m[8] = "{4J)/J{4]u#Ea\u007f]k#Pf\u000e\r2q\u0011";
      m[9] = float.class;
      n[9] = "java/lang/Float";
      m[10] = ",k\u0002~\u0000#:k\u0007$\u00134- \u0004\"\u001f <g\u00135T02";
      m[11] = "\u0003\"f\u0014Z=v\u0002m\u001bKr\u0017\ff\u0010O(c";
      m[12] = "F >:{yP ;`hnGk8fdzV,/q/jZ";
      m[13] = "`&&,FT\u0015\u0006-#W\u001bt\b&(SA\u0000";
      m[14] = "6N\u001aO r N\u001f\u00153e7\u0005\u001c\u0013?q&B\u000b\u0004tc\u0010";
      m[15] = "/V\u0018d=\u0013$Y\t+Z\u0013)R\td\u007f>7P\u001bhv\u00111r\u0016fv\u000f1^\u0001k";
      m[16] = "aV\rdEejC\u0013+)als\u001ef\u0002ej[";
      m[17] = "+j=\u0013H? \u007f#\\4=4e/\u001b\b5\fd/\u0017";
      m[18] = int.class;
      n[18] = "java/lang/Integer";
      m[19] = double.class;
      n[19] = "java/lang/Double";
      m[20] = "k\u0011(\f\u0004g\u001e1#\u0003\u0015(\u007f?(\b\u0011r\u000b";
      m[21] = void.class;
      n[21] = "java/lang/Void";
      m[22] = "5\"\u0003\u0018\bK>-\u0012WkF++";
      m[23] = "\u0002*\"\u0000#\r\u0014*'Z0\u001a\u0003a$\\<\u000e\u0012&3Kw\u001c#";
      m[24] = "\u0010Z\u000fu\u0013Iez\u0004z\u0002\u0006\u0004t\u000fq\u0006\\p";
      m[25] = "@\u001e\u0006*\u001a,K\u0011\u0017e}.^\u001a\u0017.F";
      m[26] = "\u00142\u001dT\u001d&\n:\u0007\u001b~2\u000e";
      m[27] = "v\u0019X\u001bD\u0011k\f\u00009\u0005\u001cs\n";
      m[28] = "\u0018z`\n\u0013\u0010mZk\u0005\u0002_\fT`\u000e\u0006\u0005x";
      m[29] = "sX\u007f\u000e2\u0004\u0006xt\u0001#Kgv\u007f\n'\u0011\u0013";
      m[30] = "\u00079e<ezGa}x\u0015/::p?-\"Jci})";
      m[31] = "u(\u007foTb%2w=&}z$\u001dmXyz#pn\\fqB#-Gyz/ )Xr\u001b|c2Gyv\u007fg-L\u0018";
      m[32] = "?\u0013/O+O*R K[[V@xRj\n3S2P*2<\u0010'\u0006cW/Z%F[";
      m[33] = "4^qQ%D2\u00006^@\u0017[\n3\u001bp\u001fj\tk\u0019-|";
      m[34] = "s7tVsO3mw\u000e\f]I=6\u0017fT$oh\u0006p4";
      m[35] = ";c5e/E9d:`\u0017F\u0007:&n.Ax>&es/adqcl\u0012c#2\u0004";
      m[36] = "]r)\u0012<bBmvHPlQnN\u0011i{Vr#C7j@\u0012u\u0013(i\\\u007f'M9\u007f<";
      m[37] = "\u007f\u0000)\tqT\u007f\u000e>\b\t\u0010O\u00014\u001d0\u00050\u00054\u0016mk\"\u0001b\u0019f\u000b$\u0012hG\t";
      m[38] = "NVM\b}P\u000e\u000eUL\r\u0002sV\t\u000elV\u0019T\u000e\u0001i";
      m[39] = "J90048J7'1Lnz8-$ui\u0005<-/(\u0007D% /-jG!?$L";
      m[40] = "vQ&Vk\u0018nW<\u0016P\\uX=\u0000\u0017L\u001cP9\u001c7^ V\"Vn\"vQ&Vk\u0018nW<\u0016P";
      m[41] = "N.\u007fVopCbd\u001a\n|AbF\nf\u0013@\"gWi\"Cze\n\n";
      m[42] = "Gu\u0017G\u0007`\u00183\u0015@j!Nk\u0015T-1'cTBZ<\u0016`\f@\u0007_Gu\u0017G\u0007`\u00183\u0015@j";
      m[43] = "%\u0018~`0K'_=\u0007!v I/>%\t$I$cKO3N+\u007fp\u00148U{\u0007";
      m[44] = "A=c\\K\u0011Lqx\u0010.\u001dNqJ\tS\u001f#a<\u0016\u001e\u0011\u0012bd\u0014Cr";
      m[45] = "\b6\f`\u000f\\Q/NdiE7>\u001a2PBH:\u001a9\r,\u0007?\u0007&\u0011\u0013\u00071\u0010'i";
      m[46] = "e[\u0003\u0006n=p\u001a\f\u0002\u001e)\f\u0001\u0002\u0014'.s\u0005\u0002\u001fz@2\u001c\u000f\u001f\u007f-1\u0018\u0010\u0014\u001e";
      m[47] = "Oh\u000f\u0018\u0014rWn\u0015X/&Ab\u0000_q!Ax\u0004#\u00116Dd\bN\u00122[oi";
      m[48] = "T)$f\u001dc\u0002/wf,\u001cz\u0012\u0001[,8B7!0\u001dnDd!";
      m[49] = "F\u001fIp\u001fiF\u0011^qg,v\u001eTd^8\t\u001aTo\u0003V\u001b\u001e\u0002`\b6\u001d\r\b>g";
      m[50] = " b\u001an\tqx{W(f.pl\u000bu\n\u001c$-P,]K#n\ns\u0007& j\u0015xfucq\ns\u000bvgn\u0001\u0012X5|q\n\u007f[1czk,\u0018*|q\u0006/\u001c5w\u0010";
      m[51] = "\u0007\u0018;F.\b\u001f\u001e!\u0006\u0015I\u0000\t\u0006\u0016|V\u0000u1An\u0002\u000eD2\u0019l_m\u001f!\u001fr\u0003\\I'Lr2\u0007\u0018;F.\b\u001f\u001e!\u0006\u0015";
      m[52] = "Yl$C\u0004]Yb3B|\tim9WE\f\u0016i9\\\u0018bWp4\\\u001d\u000fTt+W|";
      m[53] = "\u0018g\bzkz\u0007xW \u0007c\u0004{oy>c\u0013g\u0002+`r\u0005\u0007T{\u007fq\u0019j\u0006%ngy<V:m{\u0014n\b+{\u001b";
      m[54] = "2ki0i\u0011?'r|\f\u001d='E{a\u001f6[f=wB3jeeu\u001fP";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(309485080558469L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(309485080558469L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(309485080558469L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 76;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 108;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 237;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 113;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 72;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 220;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 76;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 108;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 237;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/aB_C0005",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/aB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = b(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = b(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = b(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static float invokeBinding4(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache4;
         MethodHandle var10 = bindingCache4;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache4 = c(MethodHandles.lookup(), "Ü", SourceSupport.methodType("(FFFJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static MsdfFontManager invokeBinding5(long var0, long var2) {
         MethodHandle var8 = bindingCache5;
         MethodHandle var7 = bindingCache5;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache5 = c(MethodHandles.lookup(), "í", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding7(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = c(MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MsdfFontManager invokeBinding8(long var0, long var2) {
         MethodHandle var8 = bindingCache8;
         MethodHandle var7 = bindingCache8;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache8 = c(MethodHandles.lookup(), "í", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding10(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache10;
         MethodHandle var9 = bindingCache10;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache10 = c(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MsdfFontManager invokeBinding11(long var0, long var2) {
         MethodHandle var8 = bindingCache11;
         MethodHandle var7 = bindingCache11;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache11 = c(MethodHandles.lookup(), "í", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = c(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = c(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MsdfFontManager invokeBinding14(long var0, long var2) {
         MethodHandle var8 = bindingCache14;
         MethodHandle var7 = bindingCache14;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache14 = c(MethodHandles.lookup(), "í", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = c(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = c(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MsdfFontManager invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = c(MethodHandles.lookup(), "í", SourceSupport.methodType("(JJ)Ldev/zprestige/prestige/cz_C0162;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (MsdfFontManager)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MsdfFont invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = c(
                  MethodHandles.lookup(),
                  "H",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cx_C0158;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MsdfFont)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = c(
                  MethodHandles.lookup(), "H", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
