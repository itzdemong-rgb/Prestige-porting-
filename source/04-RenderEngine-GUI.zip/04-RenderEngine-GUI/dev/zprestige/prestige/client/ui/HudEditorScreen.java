package dev.zprestige.prestige.client.ui;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.hud.CartHelperWidget;
import dev.zprestige.prestige.client.ui.hud.ClockWidget;
import dev.zprestige.prestige.client.ui.hud.CooldownIndicatorWidget;
import dev.zprestige.prestige.client.ui.hud.CrosshairWidget;
import dev.zprestige.prestige.client.ui.hud.FpsWidget;
import dev.zprestige.prestige.client.ui.hud.HudAnchor;
import dev.zprestige.prestige.client.ui.hud.HudAxis;
import dev.zprestige.prestige.client.ui.hud.HudElement;
import dev.zprestige.prestige.client.ui.hud.KeybindsWidget;
import dev.zprestige.prestige.client.ui.hud.LatencyWidget;
import dev.zprestige.prestige.client.ui.hud.ModuleListWidget;
import dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget;
import dev.zprestige.prestige.client.ui.hud.OffscreenArrowWidget;
import dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget;
import dev.zprestige.prestige.client.ui.hud.ResourcesWidget;
import dev.zprestige.prestige.client.ui.hud.SpeedWidget;
import dev.zprestige.prestige.client.ui.hud.TargetWidget;
import dev.zprestige.prestige.client.ui.hud.WatermarkWidget;
import dev.zprestige.prestige.client.ui.hud.WebsiteWidget;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.RenderEvents;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.modules.HudEditor;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;

public class HudEditorScreen extends ClientScreen {
   private final HudElement[] a;
   private final ArrayList b;
   private boolean c;
   private float d;
   private float e;
   private float f;
   private float g;
   private int h;
   private boolean i;
   private HudElement j;
   private static final int[] k;
   private final long[] l;
   private final boolean[] m;
   private float n;
   private long o;
   private static final float p = 140.0F;
   private static final float q = 24.0F;
   private static final float r = 20.0F;
   private static final long s = 68805146690709L;
   private static final String[] t;
   private static final String[] u;
   private static final Map v = new HashMap(13);
   private static final long[] w;
   private static final Integer[] x;
   private static final Map y;
   private static final long[] z;
   private static final Long[] A;
   private static final Map B;
   private static final Object[] C = new Object[133];
   private static final String[] D = new String[133];
   private static volatile MethodHandle bindingCache1;

   public static float aReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 68805146690709L ^ var1;
      long var3 = var1 ^ 19353493279895L;
      Object[] var5 = new Object[]{var3};
      return HudEditor.bReturningFloat(var5) / 100.0F;
   }

   public static float bReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 68805146690709L ^ var1;
      long var3 = var1 ^ 126566114049782L;
      Object[] var5 = new Object[]{var3};
      return 2.0F * aReturningFloat(var5);
   }

   public HudEditorScreen(long var1) {
      super();
      var1 = 68805146690709L ^ var1;
      long var3 = var1 ^ 90214904500797L;
      long var5 = var1 ^ 48080942508661L;
      long var7 = var1 ^ 12926760937302L;
      long var9 = var1 ^ 125293217885263L;
      long var11 = var1 ^ 121938442271006L;
      long var13 = var1 ^ 18507757927137L;
      long var15 = var1 ^ 54566938068142L;
      long var17 = var1 ^ 18638292308034L;
      long var19 = var1 ^ 110475567997613L;
      long var21 = var1 ^ 7095117041683L;
      long var23 = var1 ^ 20326783109321L;
      long var25 = var1 ^ 100761844742823L;
      long var27 = var1 ^ 48514159874500L;
      long var29 = var1 ^ 106302221383808L;
      long var31 = var1 ^ 28585531351572L;
      long var33 = var1 ^ 20622002793514L;

      short var10001 = 6077;
      long var10002 = 4968677495540872241L ^ var1;
      HudElement[] var38 = new HudElement[]{
         new CrosshairWidget(var25),
         new CooldownIndicatorWidget(var21),
         new OffscreenArrowWidget(var23),
         new ModuleNotificationsWidget(var3),
         new TargetWidget(var31),
         new FpsWidget(var17),
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null
      };
      short var10003 = 4107;
      long var10004 = 8919703227184640900L ^ var1;
      var38[6] = new SpeedWidget(var29);
      var10003 = 18369;
      var10004 = 2542272203089060954L ^ var1;
      var38[7] = new KeybindsWidget(var7);
      var10003 = 22967;
      var10004 = 4203360997698058815L ^ var1;
      var38[8] = new ModuleListWidget(var19);
      var10003 = 2229;
      var10004 = 214045994980043572L ^ var1;
      var38[9] = new LatencyWidget(var27);
      var10003 = 14662;
      var10004 = 2679050462163950275L ^ var1;
      var38[10] = new ClockWidget(var5);
      var10003 = 30141;
      var10004 = 2185446248713000510L ^ var1;
      var38[11] = new PotionDisplayWidget(var11);
      var10003 = 174;
      var10004 = 8578371850448757543L ^ var1;
      var38[12] = new ResourcesWidget(var9);
      var10003 = 17421;
      var10004 = 3348061637164115849L ^ var1;
      var38[13] = new CartHelperWidget(var13);
      var10003 = 20078;
      var10004 = 8545952200120774121L ^ var1;
      var38[14] = new WatermarkWidget(var33);
      var10003 = 12169;
      var10004 = 6593546145649413124L ^ var1;
      var38[15] = new WebsiteWidget(var15);
      this.a = var38;
      this.b = new ArrayList();
      this.c = false;
      this.d = 0.0F;
      this.e = 0.0F;
      this.f = -1.0F;
      this.g = -1.0F;
      this.h = 0;
      this.i = false;
      this.j = null;
      this.l = new long[k.length];
      this.m = new boolean[k.length];
      this.n = 0.0F;
      this.o = System.currentTimeMillis();
      Event var10000 = RenderEvents.a;
      RenderCallback var36 = invokeBinding1(this);
      Event var35 = var10000;
      var35.register(var36);
   }

   public void init() {
      int var7;
      label85: {
         HudEditorScreen var40;
         label86: {
            int var39;
            long var10001 = 14209639992501L ^ 62949972131247L;
            var10001 = 14209639992501L ^ 48098962496879L;
            int var10000 = dev.zprestige.prestige.api.eventbus.Event.cReturningInt();
            super.init();
            var7 = var10000;
            float var118;
            var10000 = (var118 = this.f - -1.0F) == 0.0F ? 0 : (var118 < 0.0F ? -1 : 1);
            int var64 = var7;
            int var63 = var10000;
            var39 = var63;
            int var35 = var63;
            label80:
            if (var64 != 0) {
               int var65 = var35;
               if (!((var65) != 0)) {
                  float var119;
                  var10000 = (var119 = this.g - -1.0F) == 0.0F ? 0 : (var119 < 0.0F ? -1 : 1);
                  int var67 = var7;
                  int var66 = var10000;
                  var39 = var66;
                  int var36 = var66;
                  if (var67 == 0) {
                     break label80;
                  }

                  int var68 = var36;
                  int var37 = var68;
                  int var69 = var37;
                  if (!((var69) != 0)) {
                     MinecraftClient var15 = MinecraftAccess.b;
                     Window var16 = var15.getWindow();
                     float var112 = var16.getFramebufferWidth();
                     Object[] var17 = new Object[]{43235709391322L};
                     float var8 = var112 / bReturningFloat(var17);
                     MinecraftClient var18 = MinecraftAccess.b;
                     Window var19 = var18.getWindow();
                     float var113 = var19.getFramebufferHeight();
                     Object[] var20 = new Object[]{43235709391322L};
                     float var9 = var113 / bReturningFloat(var20);
                     this.f = var8 / 2.0F - 70.0F;
                     float var117 = var9 / 2.0F;
                     Object[] var22 = new Object[0];
                     HudEditorScreen var21 = this;
                     this.g = var117 - var21.cReturningFloat(var22) / 2.0F;
                  }
               }

               int var71 = var7;
               HudEditorScreen var70 = this;
               var40 = var70;
               HudEditorScreen var38 = var70;
               if (var71 == 0) {
                  break label86;
               }

               byte var72 = ((byte)((var38.i) ? 1 : 0));
               var39 = var72;
            }

            int var73 = var39;
            if (((var73) != 0)) {
               break label85;
            }

            var40 = this;
         }

         HudElement[] var106 = var40.a;
         int var108 = var106.length;
         int var77;
         do {
            int var75 = var108;
            int var74 = var10;
            if (var74 >= var75) {
               break;
            }

            HudElement var11 = var106[var10];
            Object[] var25 = new Object[]{59016578429210L};
            HudElement var24 = var11;
            var24.mReturningVoid(var25);
            var10++;
            int var76 = var7;
            if (var76 == 0) {
               break label85;
            }

            var77 = var7;
         } while (var77 != 0);

         this.i = true;
      }

      HudEditorScreen var62;
      label57: {
         label89: {
            MinecraftClient var27 = MinecraftAccess.b;
            Window var114 = var27.getWindow();
            int var79 = var7;
            Window var78 = var114;
            Window var42 = var78;
            Window var41 = var78;
            if (var79 != 0) {
               Window var80 = var41;
               if (var80 == null) {
                  break label89;
               }

               MinecraftClient var29 = MinecraftAccess.b;
               Window var81 = var29.getWindow();
               var42 = var81;
            }

            Window var31 = var42;
            long var107 = var31.getHandle();
            int var105;
            do {
               int var83 = k.length;
               int var82 = var109;
               if (var82 >= var83) {
                  break;
               }

               int var85 = var7;
               HudEditorScreen var84 = this;
               var62 = var84;
               HudEditorScreen var43 = var84;
               if (var85 == 0) {
                  break label57;
               }

               boolean[] var115 = var43.m;
               int var34 = k[var109];
               long var32 = var107;
               int var10002 = GLFW.glfwGetKey(var32, var34);
               int var89 = var7;
               int var88 = var10002;
               int var87 = var109;
               boolean[] var86 = var115;
               boolean[] var54 = var86;
               int var55 = var87;
               int var56 = var88;
               boolean[] var44 = var86;
               int var45 = var87;
               int var46 = var88;
               boolean[] var59;
               int var60;
               int var61;
               if (var89 != 0) {
                  int var92 = var46;
                  int var91 = var45;
                  boolean[] var90 = var44;
                  boolean[] var47 = var90;
                  int var48 = var91;
                  int var49 = var92;
                  byte var96 = 1;
                  int var95 = var49;
                  int var94 = var48;
                  boolean[] var93 = var47;
                  boolean[] var57 = var93;
                  int var58 = var94;
                  boolean[] var50 = var93;
                  int var51 = var94;
                  if (var95 == var96) {
                     int var98 = var51;
                     boolean[] var97 = var50;
                     boolean[] var52 = var97;
                     int var53 = var98;
                     byte var101 = 1;
                     int var100 = var53;
                     boolean[] var99 = var52;
                     var59 = var99;
                     var60 = var100;
                     var61 = var101;
                  } else {
                     var61 = 0;
                     var60 = var58;
                     var59 = var57;
                  }
               } else {
                  int var104 = var56;
                  int var103 = var55;
                  boolean[] var102 = var54;
                  var59 = var102;
                  var60 = var103;
                  var61 = var104;
               }

               var59[var60] = dev.prestige.recovery.SourceSupport.asBoolean(var61);
               this.l[var109] = Long.MAX_VALUE;
               var109++;
               var105 = var7;
            } while (var105 != 0);
         }

         this.j = null;
         this.n = 0.0F;
         var62 = this;
      }

      var62.o = System.currentTimeMillis();
   }

   public void render(DrawContext var1, int var2, int var3, float var4) {
   }

   public void aReturningVoid(Object[] var1) {
      int var330;
      int var347;
      int var352;

      MeshBufferManager var4;
      RenderContext var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      long var33;
      long var35;
      long var37;
      long var39;
      long var41;
      long var43;
      int var45;
      float var48;
      float var49;
      float var50;
      float var51;
      float var52;
      long var295;
      float var323;
      float var368;
      var4 = (MeshBufferManager)var1[0];
      var7 = (RenderContext)var1[1];
      int var5 = (Integer)var1[2];
      int var8 = (Integer)var1[3];
      SourceSupport.discard(var1[4]);
      long var2 = (Long)var1[5];
      var295 = 68805146690709L ^ var2;
      var9 = var295 ^ 38177413226108L;
      var11 = var295 ^ 53435133248822L;
      var13 = var295 ^ 52654308127411L;
      var15 = var295 ^ 2949729421822L;
      var17 = var295 ^ 22441217347568L;
      var19 = var295 ^ 85220723594932L;
      long var21 = var295 ^ 11890993758555L;
      var23 = var295 ^ 132331591287156L;
      var25 = var295 ^ 63406934256149L;
      var27 = var295 ^ 39196982188452L;
      var29 = var295 ^ 29512373059851L;
      var31 = var295 ^ 48062948756611L;
      var33 = var295 ^ 134450797789712L;
      var35 = var295 ^ 78587144823484L;
      var37 = var295 ^ 80247364377887L;
      var39 = var295 ^ 40386307941890L;
      var41 = var295 ^ 110405636175634L;
      var43 = var295 ^ 25151185689102L;
      GameRenderUtil.g = var4;
      GameRenderUtil.h = var7;
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.cReturningInt();
      MinecraftClient var85 = MinecraftAccess.b;
      Window var86 = var85.getWindow();
      float var47 = var86.getScaleFactor();
      Object[] var87 = new Object[]{var21};
      var48 = bReturningFloat(var87) / var47;
      MinecraftClient var88 = MinecraftAccess.b;
      Window var89 = var88.getWindow();
      var368 = var89.getFramebufferWidth();
      Object[] var90 = new Object[]{var21};
      var49 = var368 / bReturningFloat(var90);
      MinecraftClient var91 = MinecraftAccess.b;
      Window var92 = var91.getWindow();
      var368 = var92.getFramebufferHeight();
      Object[] var93 = new Object[]{var21};
      var50 = var368 / bReturningFloat(var93);
      var368 = var5 * var47;
      Object[] var94 = new Object[]{var21};
      var51 = var368 / bReturningFloat(var94);
      var368 = var8 * var47;
      Object[] var95 = new Object[]{var21};
      var52 = var368 / bReturningFloat(var95);
      var45 = var10000;
      var323 = this.f;
      var368 = -1.0F;
      label278:
      if (var45 != 0) {
         if (this.f == -1.0F) {
            var323 = this.g;
            var368 = -1.0F;
            if (var45 == 0) {
               break label278;
            }

            if (this.g == -1.0F) {
               this.f = var49 / 2.0F - 70.0F;
               var368 = var50 / 2.0F;
               Object[] var100 = new Object[0];
               HudEditorScreen var99 = this;
               this.g = var368 - var99.cReturningFloat(var100) / 2.0F;
            }
         }

         var323 = (float)(System.currentTimeMillis() - this.o);
         var368 = 0.005F;
      }

      float var53 = var323 * var368;
      this.o = System.currentTimeMillis();
      var368 = this.n;
      Object[] var10006 = new Object[]{null, null, null, var31};
      var10006[2] = var53;
      var10006[1] = 1.0F;
      var10006[0] = var368;
      Object[] var102 = var10006;
      this.n = ClientUiUtil.bReturningFloat(var102);
      if (var45 != 0) {
         if (this.c) {
            var368 = this.f;
            float var10002 = var51 + this.d;
            Object[] var104 = new Object[]{var19};
            float var10003 = GameRenderUtil.aReturningFloat(var104) / 10.0F;
            var10006 = new Object[]{null, null, null, var31};
            var10006[2] = var10003;
            var10006[1] = var10002;
            var10006[0] = var368;
            Object[] var105 = var10006;
            this.f = ClientUiUtil.bReturningFloat(var105);
            var368 = this.g;
            var10002 = var52 + this.e;
            Object[] var106 = new Object[]{var19};
            var10003 = GameRenderUtil.aReturningFloat(var106) / 10.0F;
            var10006 = new Object[]{null, null, null, var31};
            var10006[2] = var10003;
            var10006[1] = var10002;
            var10006[0] = var368;
            Object[] var107 = var10006;
            this.g = ClientUiUtil.bReturningFloat(var107);
         }

         ArrayList var109 = this.b;
         var109.clear();
         ArrayList var324 = this.b;
         HudAnchor var111 = new HudAnchor(HudAxis.Y, 3);
         ArrayList var110 = var324;
         var110.add(var111);
         ArrayList var325 = this.b;
         HudAnchor var113 = new HudAnchor(HudAxis.X, 2);
         ArrayList var112 = var325;
         var112.add(var113);
         ArrayList var326 = this.b;
         HudAnchor var115 = new HudAnchor(HudAxis.Y, (int)(var50 - 3.0F));
         ArrayList var114 = var326;
         var114.add(var115);
         ArrayList var327 = this.b;
         HudAnchor var117 = new HudAnchor(HudAxis.X, (int)(var49 - 3.0F));
         ArrayList var116 = var327;
         var116.add(var117);
         ArrayList var328 = this.b;
         HudAnchor var119 = new HudAnchor(HudAxis.X, (int)(var49 / 2.0F));
         ArrayList var118 = var328;
         var118.add(var119);
         ArrayList var329 = this.b;
         HudAnchor var121 = new HudAnchor(HudAxis.Y, (int)(var50 / 2.0F));
         ArrayList var120 = var329;
         var120.add(var121);
      }

      HudElement[] var54 = this.a;
      int var55 = var54.length;
      while (true) {
         if (var56 < var55) {
            HudElement var57 = var54[var56];
            if (var45 != 0) {
               Object[] var123 = new Object[]{var43};
               HudElement var122 = var57;
               var330 = (((var122.eReturningBoolean(var123)) ? 1 : 0));
               if (var45 == 0) {
                  break;
               }

               label264:
               if (var330 != 0) {
                  HudElement var331 = var57;
                  if (var45 != 0) {
                     Object[] var128 = new Object[0];
                     HudElement var127 = var57;
                     if (var127.aReturningBoolean(var128)) {
                        break label264;
                     }

                     var331 = var57;
                  }

                  Object[] var132 = new Object[]{var23};
                  HudElement var131 = var331;
                  var131.eReturningVoid(var132);
               }

               var56++;
            }

            if (var45 != 0) {
               continue;
            }

            int var46 = SettingDefinition.bReturningInt();
            int var133 = ++var46;
            SettingDefinition.bReturningVoid(var133);
         }

         var54 = this.a;
         var55 = var54.length;
         var330 = 0;
         break;
      }

      var56 = var330;

      while (true) {
         if (var56 < var55) {
            HudElement var301 = var54[var56];
            if (var45 == 0) {
               break;
            }

            if (var45 != 0) {
               Object[] var136 = new Object[]{var43};
               HudElement var135 = var301;
               label242:
               if (var135.eReturningBoolean(var136)) {
                  Object[] var139 = new Object[0];
                  HudElement var138 = var301;
                  byte var332 = ((byte)((var138.aReturningBoolean(var139)) ? 1 : 0));
                  if (var45 != 0) {
                     if (var332 != 0) {
                        break label242;
                     }

                     float var536;
                     var332 = (byte)((var536 = var301.g - 0.0F) == 0.0F ? 0 : (var536 < 0.0F ? -1 : 1));
                  }

                  if (var45 != 0 && (var332 > 0 || var45 == 0)) {
                     ArrayList var333 = this.b;
                     HudAnchor var146 = new HudAnchor(HudAxis.X, (int)var301.e);
                     ArrayList var145 = var333;
                     var145.add(var146);
                     ArrayList var334 = this.b;
                     HudAnchor var148 = new HudAnchor(HudAxis.X, (int)(var301.e + var301.g));
                     ArrayList var147 = var334;
                     var147.add(var148);
                     ArrayList var335 = this.b;
                     HudAnchor var150 = new HudAnchor(HudAxis.X, (int)(var301.e + var301.g / 2.0F));
                     ArrayList var149 = var335;
                     var149.add(var150);
                     ArrayList var336 = this.b;
                     HudAnchor var152 = new HudAnchor(HudAxis.Y, (int)var301.f);
                     ArrayList var151 = var336;
                     var151.add(var152);
                     ArrayList var337 = this.b;
                     HudAnchor var154 = new HudAnchor(HudAxis.Y, (int)(var301.f + var301.h));
                     ArrayList var153 = var337;
                     var153.add(var154);
                     ArrayList var338 = this.b;
                     HudAnchor var156 = new HudAnchor(HudAxis.Y, (int)(var301.f + var301.h / 2.0F));
                     ArrayList var155 = var338;
                     var155.add(var156);
                  }
               }

               var56++;
            }

            if (var45 != 0) {
               continue;
            }
         }

         Object[] var159 = new Object[]{var41};
         HudEditorScreen var158 = this;
         var158.bReturningVoid(var159);
         break;
      }

      Matrix4f var339 = new Matrix4f();
      float var163 = 1.0F;
      float var162 = var48;
      float var161 = var48;
      Matrix4f var160 = var339;
      Matrix4f var297 = var160.scale(var161, var162, var163);
      Object[] var165 = new Object[0];
      HudEditorScreen var164 = this;
      float var298 = var164.cReturningFloat(var165);
      Object[] var166 = new Object[]{var13};
      Color var300 = ClientUiUtil.dReturningColor(var166);
      MsdfFontManager var340 = Prestige.c;
      Object[] var168 = new Object[]{var15};
      MsdfFontManager var167 = var340;
      MsdfFont var341 = var167.aReturningcx_C0158(var168);
      Object[] var170 = new Object[]{var27};
      MsdfFont var169 = var341;
      float var302 = var169.cReturningFloat(var170);
      Object[] var10008 = new Object[]{null, null, null, null, null, new Color(0, 0, 0, (int)(70.0F * this.n)), var33};
      var10008[4] = var50;
      var10008[3] = var49;
      var10008[2] = 0.0F;
      var10008[1] = 0.0F;
      var10008[0] = var297;
      Object[] var171 = var10008;
      GameRenderUtil.r(var171);
      int var389 = 23463;
      long var403 = 514214458826825543L ^ var295;
      short var404 = 2115;
      long var10004 = 5506909678163676348L ^ var295;
      short var426 = 2115;
      long var10005 = 5506909678163676348L ^ var295;
      Color var59 = new Color(255, 255, 255, (int)(6.0F * this.n));
      float var60 = 20.0F;

      while (true) {
         if (var60 < var49) {
            var368 = var60 - 0.25F;
            float var405 = var60 + 0.25F;
            var10008 = new Object[]{null, null, null, null, null, var59, var33};
            var10008[4] = var50;
            var10008[3] = var405;
            var10008[2] = 0.0F;
            var10008[1] = var368;
            var10008[0] = var297;
            Object[] var172 = var10008;
            GameRenderUtil.r(var172);
            var60 += 20.0F;
            if (var45 == 0) {
               break;
            }

            if (var45 != 0) {
               continue;
            }
         }

         var60 = 20.0F;
         break;
      }

      while (var60 < var50) {
         float var390 = var60 - 0.25F;
         float var427 = var60 + 0.25F;
         var10008 = new Object[]{null, null, null, null, null, var59, var33};
         var10008[4] = var427;
         var10008[3] = var49;
         var10008[2] = var390;
         var10008[1] = 0.0F;
         var10008[0] = var297;
         Object[] var174 = var10008;
         GameRenderUtil.r(var174);
         var60 += 20.0F;
         if (var45 == 0) {
            break;
         }
      }

      Color var175 = var300;
      var389 = var175.getRed();
      Color var176 = var300;
      int var406 = var176.getGreen();
      Color var177 = var300;
      Color var303 = new Color(var389, var406, var177.getBlue(), (int)(30.0F * this.n));
      short var342 = 22405;
      float var392 = var49 / 2.0F - 0.25F;
      float var428 = var49 / 2.0F + 0.25F;
      Object[] var10009 = new Object[]{null, null, null, null, null, var303, var33};
      var10009[4] = var50;
      var10009[3] = var428;
      var10009[2] = 0.0F;
      var10009[1] = var392;
      var10009[0] = var297;
      Object[] var178 = var10009;
      GameRenderUtil.r(var178);
      long var374 = 2637385781904166347L ^ var295;
      float var429 = var50 / 2.0F - 0.25F;
      float var449 = var50 / 2.0F + 0.25F;
      Object[] var10010 = new Object[]{null, null, null, null, null, var303, var33};
      var10010[4] = var449;
      var10010[3] = var49;
      var10010[2] = var429;
      var10010[1] = 0.0F;
      var10010[0] = var297;
      Object[] var179 = var10010;
      GameRenderUtil.r(var179);
      float var438 = var49 - 3.0F;
      float var450 = var50 - 3.0F;
      short var502 = 2115;
      long var512 = 5506909678163676348L ^ var295;
      short var513 = 2115;
      long var10011 = 5506909678163676348L ^ var295;
      short var521 = 2115;
      long var10012 = 5506909678163676348L ^ var295;
      Color var10007 = new Color(255, 255, 255, (int)(14.0F * this.n));
      Object[] var522 = new Object[]{null, null, null, null, null, null, null, var37};
      var522[6] = 0.0F;
      var522[5] = var10007;
      var522[4] = var450;
      var522[3] = var438;
      var522[2] = 3.0F;
      var522[1] = 2.0F;
      var522[0] = var297;
      Object[] var180 = var522;
      GameRenderUtil.lReturningVoid(var180);
      float var439 = this.f;
      float var451 = this.g;
      Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10013[8] = 4.0F;
      var10013[7] = 5;
      var10013[6] = var298;
      var10013[5] = 140.0F;
      var10013[4] = var451;
      var10013[3] = var439;
      var10013[2] = var297;
      var10013[1] = var7;
      var10013[0] = var4;
      Object[] var181 = var10013;
      BlurredRectangleRenderer.eReturningVoid(var181);
      float var440 = this.f;
      float var452 = this.g;
      Color var182 = UiMetrics.r;
      int var523 = var182.getRed();
      Color var183 = UiMetrics.r;
      int var531 = var183.getGreen();
      Color var184 = UiMetrics.r;
      int var534 = var184.getBlue();
      Color var185 = UiMetrics.r;
      Color var503 = new Color(var523, var531, var534, (int)(var185.getAlpha() * this.n));
      var10013 = new Object[]{null, null, null, null, null, null, null, null, null, var17};
      var10013[8] = 4.0F;
      var10013[7] = var503;
      var10013[6] = var298;
      var10013[5] = 140.0F;
      var10013[4] = var452;
      var10013[3] = var440;
      var10013[2] = var297;
      var10013[1] = var7;
      var10013[0] = var4;
      Object[] var186 = var10013;
      FilledRectangleRenderer.cReturningVoid(var186);
      float var407 = this.f;
      float var430 = this.g;
      float var441 = this.f + 140.0F;
      float var453 = this.g + 24.0F;
      short var504 = 27693;
      long var514 = 3849312634362636496L ^ var295;
      short var515 = 31449;
      var10011 = 6578359591164231216L ^ var295;
      short var525 = 6827;
      var10012 = 2841824181475401287L ^ var295;
      Object[] var526 = new Object[]{null, null, null, null, null, new Color(24, 24, 30, (int)(235.0F * this.n)), new Vector4f(4.0F, 4.0F, 0.0F, 0.0F), var25};
      var526[4] = var453;
      var526[3] = var441;
      var526[2] = var430;
      var526[1] = var407;
      var526[0] = var297;
      Object[] var187 = var526;
      ShapeRenderer.u(var187);
      double var188 = System.currentTimeMillis() / 600.0;
      float var61 = (float)(Math.sin(var188) * 0.5 + 0.5);
      float var62 = 1.0F;
      float var408 = this.f + 4.0F;
      float var431 = this.g + 24.0F - var62;
      float var442 = this.f + 140.0F - 4.0F;
      float var454 = this.g + 24.0F;
      Color var190 = var300;
      int var505 = var190.getRed();
      Color var191 = var300;
      int var516 = var191.getGreen();
      Color var192 = var300;
      var10010 = new Object[]{null, null, null, null, null, new Color(var505, var516, var192.getBlue(), (int)((150.0F + 90.0F * var61) * this.n)), var33};
      var10010[4] = var454;
      var10010[3] = var442;
      var10010[2] = var431;
      var10010[1] = var408;
      var10010[0] = var297;
      Object[] var193 = var10010;
      GameRenderUtil.r(var193);
      float var409 = this.f;
      float var432 = this.g;
      float var443 = this.f + 140.0F;
      float var455 = this.g + var298;
      Color var194 = var300;
      int var506 = var194.getRed();
      Color var195 = var300;
      int var518 = var195.getGreen();
      Color var196 = var300;
      var10007 = new Color(var506, var518, var196.getBlue(), (int)(70.0F * this.n));
      Object[] var527 = new Object[]{null, null, null, null, null, null, null, var37};
      var527[6] = 4.0F;
      var527[5] = var10007;
      var527[4] = var455;
      var527[3] = var443;
      var527[2] = var432;
      var527[1] = var409;
      var527[0] = var297;
      Object[] var197 = var527;
      GameRenderUtil.lReturningVoid(var197);
      String var63 = "HUD Editor";
      MsdfFontManager var343 = Prestige.c;
      Object[] var199 = new Object[]{var15};
      MsdfFontManager var198 = var343;
      MsdfFont var344 = var198.aReturningcx_C0158(var199);
      Object[] var201 = new Object[]{var63, var35};
      MsdfFont var200 = var344;
      float var64 = var200.aReturningFloat(var201);
      MsdfFontManager var345 = Prestige.c;
      Object[] var203 = new Object[]{var15};
      MsdfFontManager var202 = var345;
      MsdfFont var346 = var202.aReturningcx_C0158(var203);
      float var410 = this.f + 70.0F - var64 / 2.0F;
      float var433 = this.g + 12.0F - var302 / 2.0F;
      short var472 = 2115;
      long var493 = 5506909678163676348L ^ var295;
      short var494 = 2115;
      long var507 = 5506909678163676348L ^ var295;
      short var508 = 2115;
      long var519 = 5506909678163676348L ^ var295;
      var10008 = new Object[]{null, null, null, null, new Color(255, 255, 255, (int)(255.0F * this.n)), var39};
      var10008[3] = var433;
      var10008[2] = var410;
      var10008[1] = var63;
      var10008[0] = var297;
      Object[] var205 = var10008;
      MsdfFont var204 = var346;
      var204.v(var205);
      HudElement[] var66 = this.a;
      int var67 = var66.length;
      while (true) {
         if (var68 < var67) {
            HudElement var69 = var66[var68];
            if (var45 != 0) {
               Object[] var207 = new Object[]{var43};
               HudElement var206 = var69;
               var347 = (((var206.eReturningBoolean(var207)) ? 1 : 0));
               if (var45 == 0) {
                  break;
               }

               if (var347 != 0) {
                  var65++;
               }

               var68++;
            }

            if (var45 != 0) {
               continue;
            }
         }

         var347 = var65;
         break;
      }

      String var304 = var347 + "/" + this.a.length;
      MsdfFontManager var348 = Prestige.c;
      Object[] var211 = new Object[]{var15};
      MsdfFontManager var210 = var348;
      MsdfFont var349 = var210.aReturningcx_C0158(var211);
      Object[] var213 = new Object[]{var304, var35};
      MsdfFont var212 = var349;
      float var305 = var212.aReturningFloat(var213);
      MsdfFontManager var350 = Prestige.c;
      Object[] var215 = new Object[]{var15};
      MsdfFontManager var214 = var350;
      MsdfFont var351 = var214.aReturningcx_C0158(var215);
      float var411 = this.f + 140.0F - 5.5F - var305;
      float var434 = this.g + 12.0F - var302 / 2.0F;
      Color var216 = UiMetrics.u;
      int var473 = var216.getRed();
      Color var217 = UiMetrics.u;
      int var496 = var217.getGreen();
      Color var218 = UiMetrics.u;
      int var509 = var218.getBlue();
      Color var219 = UiMetrics.u;
      var10008 = new Object[]{null, null, null, null, new Color(var473, var496, var509, (int)(var219.getAlpha() * this.n)), var39};
      var10008[3] = var434;
      var10008[2] = var411;
      var10008[1] = var304;
      var10008[0] = var297;
      Object[] var221 = var10008;
      MsdfFont var220 = var351;
      var220.v(var221);
      float var306 = this.f + 5.5F;
      float var307 = this.g + 24.0F + 3.0F;
      HudElement[] var70 = this.a;
      int var71 = var70.length;
      while (true) {
         if (var72 < var71) {
            HudElement var73 = var70[var72];
            int var456 = (int)var51;
            int var474 = (int)var52;
            int var498 = this.h;
            Object[] var533 = new Object[]{null, null, null, null, null, null, null, null, this.b, var29};
            var533[7] = var498;
            var533[6] = var474;
            var533[5] = var456;
            var533[4] = 17.0F;
            var533[3] = 129.0F;
            var533[2] = var307;
            var533[1] = var306;
            var533[0] = var297;
            Object[] var223 = var533;
            HudElement var222 = var73;
            var222.nReturningVoid(var223);
            var307 += 20.0F;
            var72++;
            if (var45 == 0) {
               break;
            }

            if (var45 != 0) {
               continue;
            }
         }

         var70 = this.a;
         var71 = var70.length;
         break;
      }

      var72 = 0;

      while (true) {
         if (var72 < var71) {
            HudElement var312 = var70[var72];
            if (var45 != 0) {
               Object[] var226 = new Object[]{var43};
               HudElement var225 = var312;
               var352 = (((var225.eReturningBoolean(var226)) ? 1 : 0));
               if (var45 == 0) {
                  break;
               }

               if (var352 != 0) {
                  Object[] var230 = new Object[]{var297, var11};
                  HudElement var229 = var312;
                  var229.q(var230);
               }

               var72++;
            }

            if (var45 != 0) {
               continue;
            }
         }

         label289: {
            HudElement var353 = this.j;
            if (var45 != 0) {
               if (this.j == null) {
                  break label289;
               }

               var353 = this.j;
            }

            Object[] var235 = new Object[]{var43};
            HudElement var234 = var353;
            var352 = (((var234.eReturningBoolean(var235)) ? 1 : 0));
            if (var45 == 0) {
               break;
            }

            if (var352 != 0) {
               var368 = this.j.e - 1.5F;
               float var393 = this.j.f - 1.5F;
               float var412 = this.j.e + this.j.g + 1.5F;
               float var435 = this.j.f + this.j.h + 1.5F;
               Color var237 = var300;
               int var475 = var237.getRed();
               Color var238 = var300;
               int var499 = var238.getGreen();
               Color var239 = var300;
               Color var444 = new Color(var475, var499, var239.getBlue(), (int)(200.0F * this.n));
               var10009 = new Object[]{null, null, null, null, null, null, null, var37};
               var10009[6] = 0.0F;
               var10009[5] = var444;
               var10009[4] = var435;
               var10009[3] = var412;
               var10009[2] = var393;
               var10009[1] = var368;
               var10009[0] = var297;
               Object[] var240 = var10009;
               GameRenderUtil.lReturningVoid(var240);
            }
         }

         var352 = 5;
         break;
      }

      String[][] var354 = new String[var352][];
      String[] var413 = new String[2];
      short var457 = 8201;
      long var476 = 6991602831703226958L ^ var295;
      var413[0] = "Click";
      short var458 = 20995;
      long var477 = 8859128849459267650L ^ var295;
      var413[1] = "toggle";
      var354[0] = var413;
      String[] var414 = new String[2];
      short var459 = 26686;
      long var478 = 3612155639139529327L ^ var295;
      var414[0] = "Drag";
      short var460 = 26274;
      long var479 = 8354914697443015905L ^ var295;
      var414[1] = "move";
      var354[1] = var414;
      String[] var415 = new String[2];
      short var461 = 18727;
      long var480 = 7921416608957485930L ^ var295;
      var415[0] = "Shift";
      short var462 = 13916;
      long var481 = 1250902372581059600L ^ var295;
      var415[1] = "free move / big nudge";
      var354[2] = var415;
      String[] var416 = new String[2];
      short var463 = 836;
      long var482 = 1069221412168210689L ^ var295;
      var416[0] = "Arrows";
      short var464 = 27813;
      long var483 = 7108859546962261738L ^ var295;
      var416[1] = "nudge";
      var354[3] = var416;
      String[] var417 = new String[]{"R", null};
      short var465 = 5464;
      long var484 = 8365073658167529246L ^ var295;
      var417[1] = "reset layout";
      var354[4] = var417;
      String[][] var308 = var354;
      short var355 = 17934;
      long var376 = 101582589279951966L ^ var295;
      String var309 = "   ";
      MsdfFontManager var356 = Prestige.c;
      Object[] var243 = new Object[]{var15};
      MsdfFontManager var242 = var356;
      MsdfFont var357 = var242.aReturningcx_C0158(var243);
      Object[] var245 = new Object[]{var309, var35};
      MsdfFont var244 = var357;
      float var311 = var244.aReturningFloat(var245);
      float var313 = var311 * (var308.length - 1);
      String[][] var74 = var308;
      int var75 = var74.length;
      label168: {
         label167:
         while (true) {
            if (var76 < var75) {
               String[] var77 = var74[var76];
               MsdfFontManager var377 = Prestige.c;
               Object[] var247 = new Object[]{var15};
               MsdfFontManager var246 = var377;
               MsdfFont var378 = var246.aReturningcx_C0158(var247);
               Object[] var249 = new Object[]{var77[0], var35};
               MsdfFont var248 = var378;
               var368 = var248.aReturningFloat(var249);
               MsdfFontManager var394 = Prestige.c;
               Object[] var251 = new Object[]{var15};
               MsdfFontManager var250 = var394;
               MsdfFont var395 = var250.aReturningcx_C0158(var251);
               String var418 = var77[1];
               short var436 = 19843;
               var10005 = 4561893489732048839L ^ var295;
               Object[] var253 = new Object[]{" = " + var418, var35};
               MsdfFont var252 = var395;
               var313 += var368 + var252.aReturningFloat(var253);
               var76++;
               if (var45 == 0) {
                  break;
               }

               if (var45 != 0) {
                  continue;
               }
            }

            var323 = var313 + 16.0F;
            if (var45 == 0) {
               break label168;
            }

            if (var323 > var49 - 8.0F) {
               String[][] var359 = new String[3][];
               String[] var419 = new String[2];
               short var466 = 30095;
               long var485 = 1206272992505524166L ^ var295;
               var419[0] = "Drag";
               short var467 = 29621;
               long var486 = 4661625114964584959L ^ var295;
               var419[1] = "move";
               var359[0] = var419;
               String[] var420 = new String[2];
               short var468 = 31474;
               long var487 = 7178685236612587696L ^ var295;
               var420[0] = "Arrows";
               short var469 = 14815;
               long var488 = 9069817265181205399L ^ var295;
               var420[1] = "nudge";
               var359[1] = var420;
               String[] var421 = new String[]{"R", null};
               short var470 = 8563;
               long var489 = 5923716240083401528L ^ var295;
               var421[1] = "reset";
               var359[2] = var421;
               var308 = var359;
               var313 = var311 * (var308.length - 1);

               for (String[] var320 : var308) {
                  MsdfFontManager var380 = Prestige.c;
                  Object[] var257 = new Object[]{var15};
                  MsdfFontManager var256 = var380;
                  MsdfFont var381 = var256.aReturningcx_C0158(var257);
                  Object[] var259 = new Object[]{var320[0], var35};
                  MsdfFont var258 = var381;
                  var368 = var258.aReturningFloat(var259);
                  MsdfFontManager var396 = Prestige.c;
                  Object[] var261 = new Object[]{var15};
                  MsdfFontManager var260 = var396;
                  MsdfFont var397 = var260.aReturningcx_C0158(var261);
                  String var422 = var320[1];
                  short var437 = 16686;
                  var10005 = 2489500840613731182L ^ var295;
                  Object[] var263 = new Object[]{" = " + var422, var35};
                  MsdfFont var262 = var397;
                  var323 = var313 + (var368 + var262.aReturningFloat(var263));
                  if (var45 == 0) {
                     break label168;
                  }

                  var313 = var323;
                  if (var45 == 0) {
                     break label167;
                  }
               }
            }
            break;
         }

         var323 = 8.0F;
      }

      float var315 = var323;
      Object[] var423 = new Object[]{null, 1.0F};
      var423[0] = var302;
      Object[] var264 = var423;
      float var317 = UiMetrics.aReturningFloat(var264);
      float var319 = var313 + var315 * 2.0F;
      float var266 = var49 / 2.0F - var319 / 2.0F;
      float var265 = 4.0F;
      float var321 = Math.max(var265, var266);
      float var78 = var50 - var317 - 8.0F;
      Object[] var528 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var528[8] = 4.0F;
      var528[7] = 5;
      var528[6] = var317;
      var528[5] = var319;
      var528[4] = var78;
      var528[3] = var321;
      var528[2] = var297;
      var528[1] = var7;
      var528[0] = var4;
      Object[] var267 = var528;
      BlurredRectangleRenderer.eReturningVoid(var267);
      Color var268 = UiMetrics.r;
      int var511 = var268.getRed();
      Color var269 = UiMetrics.r;
      int var520 = var269.getGreen();
      Color var270 = UiMetrics.r;
      int var529 = var270.getBlue();
      Color var271 = UiMetrics.r;
      var10007 = new Color(var511, var520, var529, (int)(var271.getAlpha() * this.n));
      Object[] var530 = new Object[]{null, null, null, null, null, null, null, null, null, var17};
      var530[8] = 4.0F;
      var530[7] = var10007;
      var530[6] = var317;
      var530[5] = var319;
      var530[4] = var78;
      var530[3] = var321;
      var530[2] = var297;
      var530[1] = var7;
      var530[0] = var4;
      Object[] var272 = var530;
      FilledRectangleRenderer.cReturningVoid(var272);
      Color var273 = var300;
      var389 = var273.getRed();
      Color var274 = var300;
      int var424 = var274.getGreen();
      Color var275 = var300;
      Color var79 = new Color(var389, var424, var275.getBlue(), (int)(255.0F * this.n));
      Color var276 = UiMetrics.t;
      var389 = var276.getRed();
      Color var277 = UiMetrics.t;
      int var425 = var277.getGreen();
      Color var278 = UiMetrics.t;
      Color var80 = new Color(var389, var425, var278.getBlue(), (int)(230.0F * this.n));
      float var81 = var321 + var315;
      float var82 = var78 + (var317 - var302) / 2.0F;
      while (true) {
         if (var83 < var308.length) {
            MsdfFontManager var360 = Prestige.c;
            Object[] var280 = new Object[]{var15};
            MsdfFontManager var279 = var360;
            MsdfFont var361 = var279.aReturningcx_C0158(var280);
            String var400 = var308[var83][0];
            var10008 = new Object[]{null, null, null, null, var79, var39};
            var10008[3] = var82;
            var10008[2] = var81;
            var10008[1] = var400;
            var10008[0] = var297;
            Object[] var282 = var10008;
            MsdfFont var281 = var361;
            var281.v(var282);
            MsdfFontManager var383 = Prestige.c;
            Object[] var284 = new Object[]{var15};
            MsdfFontManager var283 = var383;
            MsdfFont var384 = var283.aReturningcx_C0158(var284);
            Object[] var286 = new Object[]{var308[var83][0], var35};
            MsdfFont var285 = var384;
            var81 += var285.aReturningFloat(var286);
            String var362 = var308[var83][1];
            short var385 = 16686;
            long var401 = 2489500840613731182L ^ var295;
            String var84 = " = " + var362;
            MsdfFontManager var363 = Prestige.c;
            Object[] var288 = new Object[]{var15};
            MsdfFontManager var287 = var363;
            MsdfFont var364 = var287.aReturningcx_C0158(var288);
            var10008 = new Object[]{null, null, null, null, var80, var39};
            var10008[3] = var82;
            var10008[2] = var81;
            var10008[1] = var84;
            var10008[0] = var297;
            Object[] var290 = var10008;
            MsdfFont var289 = var364;
            var289.v(var290);
            MsdfFontManager var386 = Prestige.c;
            Object[] var292 = new Object[]{var15};
            MsdfFontManager var291 = var386;
            MsdfFont var387 = var291.aReturningcx_C0158(var292);
            Object[] var294 = new Object[]{var84, var35};
            MsdfFont var293 = var387;
            var81 += var293.aReturningFloat(var294);
            if (var45 == 0) {
               break;
            }

            if (var45 != 0) {
               if (var83 < var308.length - 1) {
                  var81 += var311;
               }

               var83++;
            }

            if (var45 != 0) {
               continue;
            }
         }

         this.h = 0;
         break;
      }
   }

   private float cReturningFloat(Object[] var1) {
      return 24.0F + this.a.length * 20.0F + 6.0F;
   }

   private void bReturningVoid(Object[] var1) {
      long var4;
      long var6;
      long var8;
      int var10;
      long var11;
      long var13;
      int var80;
      long var174;
      label171: {
         label170: {
            long var2 = (Long)var1[0];
            var174 = 68805146690709L ^ var2;
            var4 = var174 ^ 134141270162247L;
            var6 = var174 ^ 115126020792118L;
            var8 = var174 ^ 83725380970889L;
            int var10000 = dev.zprestige.prestige.api.eventbus.Event.cReturningInt();
            MinecraftClient var22 = MinecraftAccess.b;
            Window var23 = var22.getWindow();
            var11 = var23.getHandle();
            var10 = var10000;
            var13 = System.currentTimeMillis();
            short var10001 = 4401;
            long var10002 = 5862590019696797278L ^ var174;
            long var24 = var11;
            var10000 = GLFW.glfwGetKey(var24, 340);
            int var106 = var10;
            int var105 = var10000;
            int var79 = var105;
            int var76 = var105;
            if (var106 != 0) {
               byte var108 = 1;
               int var107 = var76;
               if (var107 == var108) {
                  break label170;
               }

               var10001 = 6867;
               var10002 = 5325426173910035880L ^ var174;
               var10001 = 344;
               long var28 = var11;
               var10000 = GLFW.glfwGetKey(var28, 344);
               int var110 = var10;
               int var109 = var10000;
               var79 = var109;
               int var77 = var109;
               if (var110 != 0) {
                  int var111 = var77;
                  int var78 = var111;
                  byte var113 = 1;
                  int var112 = var78;
                  if (var112 != var113) {
                     var80 = 0;
                     break label171;
                  }
                  break label170;
               }
            }

            int var115 = var79;
            var80 = var115;
            break label171;
         }

         byte var114 = 1;
         var80 = var114;
      }

      int var15 = var80;
      int var173;
      do {
         int var117 = k.length;
         int var116 = var16;
         if (var116 >= var117) {
            break;
         }

         int var17 = k[var16];
         int var36 = var17;
         long var34 = var11;
         int var177 = GLFW.glfwGetKey(var34, var36);
         int var119 = var10;
         int var118 = var177;
         int var82 = var118;
         int var81 = var118;
         int var83;
         if (var119 != 0) {
            byte var121 = 1;
            int var120 = var81;
            if (var120 == var121) {
               byte var122 = 1;
               var83 = var122;
            } else {
               var83 = 0;
            }
         } else {
            int var123 = var82;
            var83 = var123;
         }

         int var18;
         int var88;
         label157: {
            int var87;
            label156: {
               label175: {
                  var18 = var83;
                  int var125 = var10;
                  int var124 = var18;
                  int var85 = var124;
                  int var84 = var124;
                  if (var125 != 0) {
                     int var126 = var84;
                     if (var126 == 0) {
                        break label175;
                     }

                     byte var127 = (byte)((this.m[var16]) ? 1 : 0);
                     var85 = var127;
                  }

                  int var129 = var10;
                  int var128 = var85;
                  var87 = var128;
                  int var86 = var128;
                  if (var129 == 0) {
                     break label156;
                  }

                  int var130 = var86;
                  if (var130 == 0) {
                     var87 = 1;
                     break label156;
                  }
               }

               var88 = 0;
               break label157;
            }

            int var131 = var87;
            var88 = var131;
         }

         int var19;
         int var94;
         label144: {
            byte var20;
            label176: {
               var19 = var88;
               var20 = 0;
               int var133 = var10;
               int var132 = var19;
               int var90 = var132;
               int var89 = var132;
               if (var133 != 0) {
                  int var134 = var89;
                  if (var134 != 0) {
                     var20 = 1;
                     short var10003 = 11573;
                     long var10004 = 6154901887210587134L ^ var174;
                     this.l[var16] = var13 + 300L;
                     int var135 = var10;
                     if (var135 != 0) {
                        break label176;
                     }
                  }

                  int var136 = var18;
                  var90 = var136;
               }

               int var138 = var10;
               int var137 = var90;
               var94 = var137;
               int var91 = var137;
               if (var138 == 0) {
                  break label144;
               }

               int var139 = var91;
               if (var139 != 0) {
                  long var196;
                  var177 = (var196 = var13 - this.l[var16]) == 0L ? 0 : (var196 < 0L ? -1 : 1);
                  int var141 = var10;
                  int var140 = var177;
                  var94 = var140;
                  int var92 = var140;
                  if (var141 == 0) {
                     break label144;
                  }

                  int var142 = var92;
                  int var93 = var142;
                  int var143 = var93;
                  if (var143 >= 0) {
                     var20 = 1;
                     short var191 = 15566;
                     long var192 = 5316251271003050502L ^ var174;
                     this.l[var16] = var13 + 45L;
                  }
               }
            }

            this.m[var16] = dev.prestige.recovery.SourceSupport.asBoolean(var18);
            var94 = var20;
         }

         label130: {
            label177: {
               int var145 = var10;
               int var144 = var94;
               int var96 = var144;
               int var95 = var144;
               if (var145 != 0) {
                  int var146 = var95;
                  if (var146 == 0) {
                     int var147 = var10;
                     if (var147 != 0) {
                        break label177;
                     }
                  }

                  int var148 = var17;
                  var96 = var148;
               }

               label178: {
                  int var150 = var10;
                  int var149 = var96;
                  int var98 = var149;
                  int var97 = var149;
                  if (var150 != 0) {
                     short var186 = 6968;
                     long var189 = 2120877048674167876L ^ var174;
                     byte var152 = 82;
                     int var151 = var97;
                     if (var151 != var152) {
                        break label178;
                     }

                     int var153 = var19;
                     var98 = var153;
                  }

                  int var154 = var98;
                  if (var154 == 0) {
                     break label177;
                  }

                  Object[] var53 = new Object[]{var6};
                  HudEditorScreen var52 = this;
                  var52.cReturningVoid(var53);
                  int var155 = var10;
                  if (var155 != 0) {
                     break label177;
                  }
               }

               int var157 = var10;
               HudElement var156 = this.j;
               HudElement var101 = var156;
               HudElement var99 = var156;
               if (var157 != 0) {
                  HudElement var158 = var99;
                  HudElement var100 = var158;
                  HudElement var159 = var100;
                  if (var159 == null) {
                     break label177;
                  }

                  HudElement var160 = this.j;
                  var101 = var160;
               }

               Object[] var59 = new Object[]{var8};
               HudElement var58 = var101;
               byte var179 = ((byte)((var58.eReturningBoolean(var59)) ? 1 : 0));
               int var162 = var10;
               byte var161 = var179;
               int var103 = var161;
               byte var102 = var161;
               if (var162 != 0) {
                  byte var163 = var102;
                  if (var163 == 0) {
                     int var164 = var10;
                     if (var164 != 0) {
                        break label177;
                     }
                  }

                  int var165 = var15;
                  var103 = var165;
               }

               int var166 = var103;
               float var104;
               if (var166 != 0) {
                  float var167 = 10.0F;
                  var104 = var167;
               } else {
                  var104 = 1.0F;
               }

               float var21 = var104;
               int var168 = var10;
               if (var168 == 0) {
                  break label130;
               }

               int var169 = var17;
               switch (var169) {
                  case 263:
                     HudElement var180 = this.j;
                     float var187 = -var21;
                     Object[] var10005 = new Object[]{null, null, var4};
                     var10005[1] = 0.0F;
                     var10005[0] = var187;
                     Object[] var66 = var10005;
                     HudElement var65 = var180;
                     var65.hReturningVoid(var66);
                     int var170 = var10;
                     if (var170 != 0) {
                        break;
                     }
                  case 262:
                     HudElement var181 = this.j;
                     Object[] var193 = new Object[]{null, null, var4};
                     var193[1] = 0.0F;
                     var193[0] = var21;
                     Object[] var69 = var193;
                     HudElement var68 = var181;
                     var68.hReturningVoid(var69);
                     int var171 = var10;
                     if (var171 != 0) {
                        break;
                     }
                  case 265:
                     HudElement var182 = this.j;
                     float var190 = -var21;
                     Object[] var194 = new Object[]{null, null, var4};
                     var194[1] = var190;
                     var194[0] = 0.0F;
                     Object[] var72 = var194;
                     HudElement var71 = var182;
                     var71.hReturningVoid(var72);
                     int var172 = var10;
                     if (var172 != 0) {
                        break;
                     }
                  case 264:
                     HudElement var183 = this.j;
                     Object[] var195 = new Object[]{null, null, var4};
                     var195[1] = var21;
                     var195[0] = 0.0F;
                     Object[] var75 = var195;
                     HudElement var74 = var183;
                     var74.hReturningVoid(var75);
               }
            }

            var16++;
         }

         var173 = var10;
      } while (var173 != 0);
   }

   private void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 68805146690709L ^ var2;
      long var4 = var2 ^ 23037608331711L;
      HudElement[] var7 = this.a;
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      int var8 = var7.length;
      int var6 = var10000;
      while (true) {
         int var14 = var8;
         int var13 = var9;
         if (var13 < var14) {
            HudElement var10 = var7[var9];
            Object[] var12 = new Object[]{var4};
            HudElement var11 = var10;
            var11.mReturningVoid(var12);
            var9++;
            int var15 = var6;
            if (var15 != 0) {
               break;
            }

            int var16 = var6;
            if (var16 == 0) {
               continue;
            }
         }

         this.j = null;
         break;
      }
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      int var13;
      double var14;
      double var16;
      int var18;
      int var73;
      long var10001 = 25132531839882L ^ 82635848029166L;
      var10001 = 25132531839882L ^ 99013216756210L;
      var10001 = 25132531839882L ^ 54464593027664L;
      var10001 = 25132531839882L ^ 50055288518917L;
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      Click var30 = var1;
      var14 = var30.x();
      Click var31 = var1;
      var16 = var31.y();
      var13 = var10000;
      Click var32 = var1;
      var18 = var32.button();
      float var157;
      var10000 = (var157 = this.f - -1.0F) == 0.0F ? 0 : (var157 < 0.0F ? -1 : 1);
      int var94 = var13;
      int var93 = var10000;
      var73 = var93;
      int var70 = var93;
      label132:
      if (var94 == 0) {
         int var95 = var70;
         if (var95 == 0) {
            float var158;
            var10000 = (var158 = this.g - -1.0F) == 0.0F ? 0 : (var158 < 0.0F ? -1 : 1);
            int var97 = var13;
            int var96 = var10000;
            var73 = var96;
            int var71 = var96;
            if (var97 != 0) {
               break label132;
            }

            int var98 = var71;
            int var72 = var98;
            int var99 = var72;
            if (var99 == 0) {
               HudEditorScreen var36 = this;
               var36.init();
            }
         }

         MinecraftClient var38 = MinecraftAccess.b;
         Window var39 = var38.getWindow();
         var73 = var39.getScaleFactor();
      }

      double var19 = var73;
      double var145 = var14 * var19;
      Object[] var40 = new Object[]{43235709391322L};
      double var21 = var145 / bReturningFloat(var40);
      double var146 = var16 * var19;
      Object[] var41 = new Object[]{43235709391322L};
      double var23 = var146 / bReturningFloat(var41);
      int var101 = var13;
      int var100 = var18;
      int var92 = var100;
      int var74 = var100;
      if (var101 == 0) {
         int var102 = var74;
         if (var102 == 0) {
            int var153 = (int)var21;
            int var10002 = (int)var23;
            Object[] var10005 = new Object[]{null, null, 84485500375672L};
            var10005[1] = var10002;
            var10005[0] = var153;
            Object[] var44 = var10005;
            HudEditorScreen var43 = this;
            byte var147 = ((byte)((var43.aReturningBoolean(var44)) ? 1 : 0));
            int var104 = var13;
            byte var103 = var147;
            int var77 = var103;
            byte var75 = var103;
            if (var104 == 0) {
               byte var105 = var75;
               byte var76 = var105;
               byte var106 = var76;
               if (var106 != 0) {
                  this.d = (float)(this.f - var21);
                  this.e = (float)(this.g - var23);
                  this.c = true;
               }

               double var159;
               var77 = (var159 = var21 - this.f) == 0.0 ? 0 : (var159 < 0.0 ? -1 : 1);
            }

            int var86;
            label120: {
               int var85;
               label119: {
                  label136: {
                     int var108 = var13;
                     int var107 = var77;
                     int var79 = var107;
                     int var78 = var107;
                     if (var108 == 0) {
                        int var109 = var78;
                        if (var109 < 0) {
                           break label136;
                        }

                        double var160;
                        int var110 = (var160 = var21 - (this.f + 140.0F)) == 0.0 ? 0 : (var160 < 0.0 ? -1 : 1);
                        var79 = var110;
                     }

                     int var112 = var13;
                     int var111 = var79;
                     int var81 = var111;
                     int var80 = var111;
                     if (var112 == 0) {
                        int var113 = var80;
                        if (var113 > 0) {
                           break label136;
                        }

                        double var161;
                        int var114 = (var161 = var23 - this.g) == 0.0 ? 0 : (var161 < 0.0 ? -1 : 1);
                        var81 = var114;
                     }

                     int var116 = var13;
                     int var115 = var81;
                     int var83 = var115;
                     int var82 = var115;
                     if (var116 == 0) {
                        int var117 = var82;
                        if (var117 < 0) {
                           break label136;
                        }

                        float var154 = this.g;
                        Object[] var54 = new Object[0];
                        HudEditorScreen var53 = this;
                        double var162;
                        int var118 = (var162 = var23 - (var154 + var53.cReturningFloat(var54))) == 0.0 ? 0 : (var162 < 0.0 ? -1 : 1);
                        var83 = var118;
                     }

                     int var120 = var13;
                     int var119 = var83;
                     var85 = var119;
                     int var84 = var119;
                     if (var120 != 0) {
                        break label119;
                     }

                     int var121 = var84;
                     if (var121 <= 0) {
                        var85 = 1;
                        break label119;
                     }
                  }

                  var86 = 0;
                  break label120;
               }

               int var122 = var85;
               var86 = var122;
            }

            int var25 = var86;
            int var123 = var25;
            if (var123 == 0) {
               HudElement[] var26 = this.a;
               int var27 = var26.length;
               byte var89;
               while (true) {
                  int var125 = var27;
                  int var124 = var28;
                  if (var124 < var125) {
                     HudElement var29 = var26[var28];
                     int var126 = var13;
                     if (var126 == 0) {
                        Object[] var58 = new Object[]{65274779863695L};
                        HudElement var57 = var29;
                        var147 = ((byte)((var57.eReturningBoolean(var58)) ? 1 : 0));
                        int var128 = var13;
                        byte var127 = var147;
                        var89 = var127;
                        byte var87 = var127;
                        if (var128 != 0) {
                           break;
                        }

                        byte var129 = var87;
                        byte var88 = var129;
                        byte var130 = var88;
                        if (var130 != 0) {
                           int var155 = (int)var21;
                           var10002 = (int)var23;
                           Object[] var10006 = new Object[]{null, null, null, 103301345435748L};
                           var10006[2] = false;
                           var10006[1] = var10002;
                           var10006[0] = var155;
                           Object[] var62 = var10006;
                           HudElement var61 = var29;
                           var61.o(var62);
                        }

                        var28++;
                     }

                     int var131 = var13;
                     if (var131 == 0) {
                        continue;
                     }
                  }

                  var26 = this.a;
                  var27 = var26.length;
                  var89 = 0;
                  break;
               }

               var28 = var89;

               int var140;
               do {
                  int var133 = var27;
                  int var132 = var28;
                  if (var132 >= var133) {
                     break;
                  }

                  HudElement var142 = var26[var28];
                  int var134 = var13;
                  if (var134 == 0) {
                     Object[] var65 = new Object[]{65274779863695L};
                     HudElement var64 = var142;
                     boolean var149 = var64.eReturningBoolean(var65);
                     int var136 = var13;
                     boolean var135 = var149;
                     boolean var163 = var135;
                     boolean var90 = var135;
                     if (var136 != 0) {
                        return var163;
                     }

                     boolean var137 = var90;
                     boolean var91 = var137;
                     boolean var138 = var91;
                     if (var138) {
                        Object[] var69 = new Object[0];
                        HudElement var68 = var142;
                        boolean var139 = var68.aReturningBoolean(var69);
                        if (var139) {
                           this.j = var142;
                        }
                     }

                     var28++;
                  }

                  var140 = var13;
               } while (var140 == 0);
            }

            this.h = 1;
         }

         var92 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var92);
   }

   public boolean mouseReleased(Click var1) {
      long var10001 = 65958405375068L ^ 112212809966648L;
      var10001 = 65958405375068L ^ 31541070337414L;
      var10001 = 65958405375068L ^ 690873405139L;
      Click var26 = var1;
      double var11 = var26.x();
      Click var27 = var1;
      double var13 = var27.y();
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      Click var28 = var1;
      int var15 = var28.button();
      MinecraftClient var29 = MinecraftAccess.b;
      Window var30 = var29.getWindow();
      double var16 = var30.getScaleFactor();
      double var58 = var11 * var16;
      Object[] var31 = new Object[]{43235709391322L};
      double var18 = var58 / bReturningFloat(var31);
      double var59 = var13 * var16;
      Object[] var32 = new Object[]{43235709391322L};
      double var20 = var59 / bReturningFloat(var32);
      int var10 = var10000;
      int var45 = var10;
      int var44 = var15;
      int var43 = var44;
      int var40 = var44;
      if (var45 == 0) {
         int var46 = var40;
         if (var46 == 0) {
            this.c = false;
            HudElement[] var22 = this.a;
            int var23 = var22.length;
            int var54;
            do {
               int var48 = var23;
               int var47 = var24;
               if (var47 >= var48) {
                  break;
               }

               HudElement var25 = var22[var24];
               int var49 = var10;
               if (var49 == 0) {
                  Object[] var35 = new Object[]{65274779863695L};
                  HudElement var34 = var25;
                  boolean var55 = var34.eReturningBoolean(var35);
                  int var51 = var10;
                  boolean var50 = var55;
                  boolean var61 = var50;
                  boolean var41 = var50;
                  if (var51 != 0) {
                     return var61;
                  }

                  boolean var52 = var41;
                  boolean var42 = var52;
                  boolean var53 = var42;
                  if (var53) {
                     int var60 = (int)var18;
                     int var10002 = (int)var20;
                     Object[] var10006 = new Object[]{null, null, null, 103301345435748L};
                     var10006[2] = true;
                     var10006[1] = var10002;
                     var10006[0] = var60;
                     Object[] var39 = var10006;
                     HudElement var38 = var25;
                     var38.o(var39);
                  }

                  var24++;
               }

               var54 = var10;
            } while (var54 == 0);
         }

         var43 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var43);
   }

   public boolean shouldPause() {
      return false;
   }

   public boolean shouldCloseOnEsc() {
      ClickGuiScreen var4 = Prestige.k;
      MinecraftClient var3 = MinecraftAccess.b;
      var3.setScreen(var4);
      ClickGuiScreen var10000 = Prestige.k;
      Object[] var6 = new Object[0];
      ClickGuiScreen var5 = var10000;
      var5.aReturningVoid(var6);
      return false;
   }

   private boolean aReturningBoolean(Object[] var1) {
      int var5 = (Integer)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      long var10000 = 68805146690709L ^ var3;
      int var6 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      float var33;
      int var32 = (var33 = var5 - this.f) == 0.0F ? 0 : (var33 < 0.0F ? -1 : 1);
      int var17 = var6;
      int var16 = var32;
      int var8 = var16;
      int var7 = var16;
      if (var17 == 0) {
         int var18 = var7;
         if (var18 < 0) {
            return false;
         }

         float var34;
         int var19 = (var34 = var5 - (this.f + 140.0F)) == 0.0F ? 0 : (var34 < 0.0F ? -1 : 1);
         var8 = var19;
      }

      int var21 = var6;
      int var20 = var8;
      int var10 = var20;
      int var9 = var20;
      if (var21 == 0) {
         int var22 = var9;
         if (var22 > 0) {
            return false;
         }

         float var35;
         int var23 = (var35 = var2 - this.g) == 0.0F ? 0 : (var35 < 0.0F ? -1 : 1);
         var10 = var23;
      }

      int var25 = var6;
      int var24 = var10;
      int var12 = var24;
      int var11 = var24;
      if (var25 == 0) {
         int var26 = var11;
         if (var26 < 0) {
            return false;
         }

         float var36;
         int var27 = (var36 = var2 - (this.g + 24.0F)) == 0.0F ? 0 : (var36 < 0.0F ? -1 : 1);
         var12 = var27;
      }

      int var29 = var6;
      int var28 = var12;
      int var14 = var28;
      int var13 = var28;
      if (var29 != 0) {
         return dev.prestige.recovery.SourceSupport.asBoolean(var14);
      } else {
         int var30 = var13;
         if (var30 <= 0) {
            byte var37 = 1;
            return dev.prestige.recovery.SourceSupport.asBoolean(var37);
         } else {
            return false;
         }
      }
   }

   public boolean bReturningBoolean(Object[] var1) {
      RenderContext var2;
      MeshBufferManager var5;
      long var6;
      long var8;
      long var10;
      long var12;
      long var16;
      int var18;
      byte var69;
      label98: {
         long var14;
         label101: {
            var5 = (MeshBufferManager)var1[0];
            var2 = (RenderContext)var1[1];
            long var3 = (Long)var1[2];
            var3 = 68805146690709L ^ var3;
            var6 = var3 ^ 11664975316800L;
            var8 = var3 ^ 31316861613512L;
            var10 = var3 ^ 15967635739912L;
            var12 = var3 ^ 136406253557031L;
            var14 = var3 ^ 85644935541537L;
            var16 = var3 ^ 20386603929181L;
            var18 = dev.zprestige.prestige.api.eventbus.Event.cReturningInt();
            MinecraftClient var27 = MinecraftAccess.b;
            int var81 = var18;
            Screen var80 = var27.currentScreen;
            Screen var65 = var80;
            Screen var64 = var80;
            if (var81 != 0) {
               Screen var82 = var64;
               if (var82 == null) {
                  break label101;
               }

               MinecraftClient var29 = MinecraftAccess.b;
               Screen var83 = var29.currentScreen;
               var65 = var83;
            }

            byte var10000 = ((byte)((var65 instanceof HudEditorScreen) ? 1 : 0));
            int var85 = var18;
            byte var84 = var10000;
            var69 = var84;
            byte var66 = var84;
            if (var85 == 0) {
               break label98;
            }

            byte var86 = var66;
            if (var86 == 0) {
               MinecraftClient var32 = MinecraftAccess.b;
               var10000 = ((byte)((var32.currentScreen instanceof ChatScreen) ? 1 : 0));
               int var88 = var18;
               byte var87 = var10000;
               var69 = var87;
               byte var67 = var87;
               if (var88 == 0) {
                  break label98;
               }

               byte var89 = var67;
               byte var68 = var89;
               byte var90 = var68;
               if (var90 == 0) {
                  return false;
               }
            }
         }

         Object[] var37 = new Object[]{var14};
         HudEditorScreen var36 = this;
         var69 = ((byte)((var36.dReturningBoolean(var37)) ? 1 : 0));
      }

      int var92 = var18;
      byte var91 = var69;
      int var71 = var91;
      byte var70 = var91;
      if (var92 != 0) {
         byte var93 = var70;
         if (var93 == 0) {
            return false;
         }

         MinecraftClient var40 = MinecraftAccess.b;
         Window var41 = var40.getWindow();
         var71 = var41.getScaleFactor();
      }

      float var19 = var71;
      Object[] var42 = new Object[]{var10};
      float var20 = bReturningFloat(var42) / var19;
      Matrix4f var119 = new Matrix4f();
      float var46 = 1.0F;
      float var45 = var20;
      float var44 = var20;
      Matrix4f var43 = var119;
      Matrix4f var21 = var43.scale(var44, var45, var46);
      int var95 = var18;
      boolean var94 = this.i;
      boolean var73 = var94;
      boolean var72 = var94;
      if (var95 != 0) {
         boolean var96 = var72;
         label73:
         if (!var96) {
            HudElement[] var22 = this.a;
            int var23 = var22.length;
            int var100;
            do {
               int var98 = var23;
               int var97 = var24;
               if (var97 >= var98) {
                  break;
               }

               HudElement var25 = var22[var24];
               Object[] var49 = new Object[]{var8};
               HudElement var48 = var25;
               var48.mReturningVoid(var49);
               var24++;
               int var99 = var18;
               if (var99 == 0) {
                  break label73;
               }

               var100 = var18;
            } while (var100 != 0);

            this.i = true;
         }

         var73 = false;
      }

      boolean var114 = var73;
      HudElement[] var115 = this.a;
      int var116 = var115.length;
      boolean var79;
      while (true) {
         int var102 = var116;
         int var101 = var117;
         if (var101 < var102) {
            HudElement var26 = var115[var117];
            int var103 = var18;
            if (var103 != 0) {
               Object[] var52 = new Object[]{var16};
               HudElement var51 = var26;
               boolean var120 = var51.eReturningBoolean(var52);
               int var105 = var18;
               boolean var104 = var120;
               var79 = var104;
               boolean var74 = var104;
               if (var105 == 0) {
                  break;
               }

               boolean var106 = var74;
               boolean var75 = var106;
               boolean var107 = var75;
               if (var107) {
                  Object[] var56 = new Object[0];
                  HudElement var55 = var26;
                  boolean var121 = var55.aReturningBoolean(var56);
                  int var109 = var18;
                  boolean var108 = var121;
                  boolean var78 = var108;
                  boolean var76 = var108;
                  if (var109 != 0) {
                     boolean var110 = var76;
                     boolean var77 = var110;
                     boolean var111 = var77;
                     if (!var111) {
                        Object[] var60 = new Object[]{var12};
                        HudElement var59 = var26;
                        var59.eReturningVoid(var60);
                     }

                     Object[] var63 = new Object[]{var5, var2, var21, var6};
                     HudElement var62 = var26;
                     var62.lReturningVoid(var63);
                     var78 = true;
                  }

                  var114 = var78;
               }

               var117++;
            }

            int var112 = var18;
            if (var112 != 0) {
               continue;
            }
         }

         var79 = var114;
         break;
      }

      return var79;
   }

   public boolean cReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 68805146690709L ^ var2;
      long var4 = var2 ^ 24278513565663L;
      int var6 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      MinecraftClient var7 = MinecraftAccess.b;
      int var25 = var6;
      Screen var24 = var7.currentScreen;
      Screen var19 = var24;
      Screen var18 = var24;
      if (var25 == 0) {
         HudEditorScreen var27 = this;
         Screen var26 = var18;
         if (var26 == var27) {
            return true;
         }

         MinecraftClient var10 = MinecraftAccess.b;
         var19 = var10.currentScreen;
      }

      label35: {
         int var29 = var6;
         Screen var28 = var19;
         Screen var21 = var28;
         Screen var20 = var28;
         if (var29 == 0) {
            Screen var30 = var20;
            if (var30 == null) {
               break label35;
            }

            MinecraftClient var12 = MinecraftAccess.b;
            Screen var31 = var12.currentScreen;
            var21 = var31;
         }

         boolean var10000 = var21 instanceof ChatScreen;
         int var33 = var6;
         boolean var32 = var10000;
         boolean var23 = var32;
         boolean var22 = var32;
         if (var33 != 0) {
            return var23;
         }

         boolean var34 = var22;
         if (!var34) {
            return false;
         }
      }

      Object[] var17 = new Object[]{var4};
      HudEditorScreen var16 = this;
      return var16.dReturningBoolean(var17);
   }

   private boolean dReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 68805146690709L ^ var2;
      long var4 = var2 ^ 107741703010793L;
      HudElement[] var7 = this.a;
      int var10000 = dev.zprestige.prestige.api.eventbus.Event.bReturningInt();
      int var8 = var7.length;
      int var6 = var10000;
      boolean var15;
      while (true) {
         int var17 = var8;
         int var16 = var9;
         if (var16 < var17) {
            HudElement var10 = var7[var9];
            int var18 = var6;
            if (var18 == 0) {
               Object[] var12 = new Object[]{var4};
               HudElement var11 = var10;
               boolean var25 = var11.eReturningBoolean(var12);
               int var20 = var6;
               boolean var19 = var25;
               var15 = var19;
               boolean var13 = var19;
               if (var20 != 0) {
                  break;
               }

               boolean var21 = var13;
               boolean var14 = var21;
               boolean var22 = var14;
               if (var22) {
                  return true;
               }

               var9++;
            }

            int var23 = var6;
            if (var23 == 0) {
               continue;
            }
         }

         var15 = false;
         break;
      }

      return var15;
   }

   public HudElement[] aReturningArrayOfb1(Object[] var1) {
      return this.a;
   }

   private void lambda$new$0(MeshBufferManager var1, RenderContext var2) {
      long var10001 = 88327048557087L ^ 73962615055883L;
      var10001 = 88327048557087L ^ 53149411013674L;
      int var9 = dev.zprestige.prestige.api.eventbus.Event.cReturningInt();
      int var31 = var9;
      MinecraftClient var30 = MinecraftAccess.b;
      MinecraftClient var29 = var30;
      MinecraftClient var28 = var30;
      if (var31 != 0) {
         MinecraftClient var11 = var28;
         HudEditorScreen var33 = this;
         Screen var32 = var11.currentScreen;
         if (var32 != var33) {
            return;
         }

         var29 = MinecraftAccess.b;
      }

      MinecraftClient var14 = var29;
      Mouse var10 = var14.mouse;
      Mouse var15 = var10;
      double var10003 = var15.getX();
      MinecraftClient var16 = MinecraftAccess.b;
      Window var17 = var16.getWindow();
      double var18 = var10003 / var17.getScaleFactor();
      int var35 = (int)Math.round(var18);
      Mouse var20 = var10;
      double var10004 = var20.getY();
      MinecraftClient var21 = MinecraftAccess.b;
      Window var22 = var21.getWindow();
      double var23 = var10004 / var22.getScaleFactor();
      int var36 = (int)Math.round(var23);
      Object[] var25 = new Object[]{105570054506037L};
      float var10005 = GameRenderUtil.aReturningFloat(var25);
      Object[] var10008 = new Object[]{null, null, null, null, null, 20967984190484L};
      var10008[4] = var10005;
      var10008[3] = var36;
      var10008[2] = var35;
      var10008[1] = var2;
      var10008[0] = var1;
      Object[] var27 = var10008;
      HudEditorScreen var26 = this;
      var26.aReturningVoid(var27);
   }

   static {

      {

      aReturningVoid();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(93704390959355L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[18];
      String var26 = "òë'8SWO\u009bq^1P6F\u0011û\u0010áíîFh>\u008b#ð\u0014\u000bËZ\u0087|L\u0010T®ÌÆ\u0086\u0006SvG\bùpó¸Òk\u0010U\u0080îæAáE\u0092·¥½å*²áÌ\u0010\u0017]-ââ¿l/>ºU\u0095\\\u00ad\u001c4\u0010T\u0085\"]_\u0013I¦5ÂS\u009a\u001a4÷\u0000\u0010\u0088\u0093\u00ad\u0016£Þ<\u0002\u0089gêä\nà\u008df B\u001f\u0088_\u0016\u0081°r\u001e6C/\u0085\u0011ÉÈ\u0014\u0000éÕ\u000fÌdq\u0095\u000e\bºx\u001f\u00042\u0010\u007f\u0088A\u0006O\u0093.\u0017\u0015\u0012s\b[\u0005ëð\u0010nHîÌ\u009dä¸{Aöö~Ãe¢L\u0010SÔ\u0001\u0000lS\u0090h.\u001f9FÓ\u0089Ä¨\u0010\u00adÝX¢Á\u009eµAêi=#òæ¯¯\u0010ÂÐQ3\u0012\u0082eÒ\u0095S\u008fÙ\u0016/\u0001g(¡[â\u0013¡\u0097bwùM\u0016\u0016Èº4>\n#\u0080\u0097¸-\rÖN¨D7\u008a¡\u0080^Ëªb1 J¯Y\u0010_»¾\u0005º0\u00849äb^sº'#±\u00182&[Ä~e\u001fû\u000bksÑ¼((È²\u008fI\u008e\u008eRGÉ";
      int var28 = "òë'8SWO\u009bq^1P6F\u0011û\u0010áíîFh>\u008b#ð\u0014\u000bËZ\u0087|L\u0010T®ÌÆ\u0086\u0006SvG\bùpó¸Òk\u0010U\u0080îæAáE\u0092·¥½å*²áÌ\u0010\u0017]-ââ¿l/>ºU\u0095\\\u00ad\u001c4\u0010T\u0085\"]_\u0013I¦5ÂS\u009a\u001a4÷\u0000\u0010\u0088\u0093\u00ad\u0016£Þ<\u0002\u0089gêä\nà\u008df B\u001f\u0088_\u0016\u0081°r\u001e6C/\u0085\u0011ÉÈ\u0014\u0000éÕ\u000fÌdq\u0095\u000e\bºx\u001f\u00042\u0010\u007f\u0088A\u0006O\u0093.\u0017\u0015\u0012s\b[\u0005ëð\u0010nHîÌ\u009dä¸{Aöö~Ãe¢L\u0010SÔ\u0001\u0000lS\u0090h.\u001f9FÓ\u0089Ä¨\u0010\u00adÝX¢Á\u009eµAêi=#òæ¯¯\u0010ÂÐQ3\u0012\u0082eÒ\u0095S\u008fÙ\u0016/\u0001g(¡[â\u0013¡\u0097bwùM\u0016\u0016Èº4>\n#\u0080\u0097¸-\rÖN¨D7\u008a¡\u0080^Ëªb1 J¯Y\u0010_»¾\u0005º0\u00849äb^sº'#±\u00182&[Ä~e\u001fû\u000bksÑ¼((È²\u008fI\u008e\u008eRGÉ"
         .length();
      char var25 = 16;
      int var33 = -1;

      label72:
      while (true) {
         String var34 = var26.substring(++var33, var33 + var25);
         int var10001 = -1;

         while (true) {
            byte[] var30 = var22.doFinal(var34.getBytes("ISO-8859-1"));
            String var48 = a(var30).intern();
            switch (var10001) {
               case 0:
                  var29[var27++] = var48;
                  if ((var33 += var25) >= var28) {
                     t = var29;
                     u = new String[18];
                     y = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(93704390959355L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[24];
                     String var15 = "*Wè±Ø\u00ad:\u0003ô\u0085\u009cÙÿ\u0093¶%kÝ=<\u0014Ø\u0086BLÉÌ\u0019¹\u000b\u0089\u0018\u001c[Íò\u0002.@Ç\u009ccÄ À\u000eÏüré\u001cJõ<ð¹kC&aJtcg¥%\u000faÃ±4¼¥â\u0099!\u00ad\u0086Iñ\u0097\u0083\u009dÞu\u0089u\u009e\u009cá\u0005´¤I$`&8îóÊuã|®PF«¤Q\u00958q\u001a\u0017E\u0013! 6\u0018'E/I*>\u008e@DzcnÞg'ßÀhv\u0005ã\u000eZM\u0017\u008dÚë\u008fò\u0016í&R\u0019yB\u000fb¥;Z\u001c)ðÔ;§X\u0000»LÏÔ\u0003";
                     int var16 = "*Wè±Ø\u00ad:\u0003ô\u0085\u009cÙÿ\u0093¶%kÝ=<\u0014Ø\u0086BLÉÌ\u0019¹\u000b\u0089\u0018\u001c[Íò\u0002.@Ç\u009ccÄ À\u000eÏüré\u001cJõ<ð¹kC&aJtcg¥%\u000faÃ±4¼¥â\u0099!\u00ad\u0086Iñ\u0097\u0083\u009dÞu\u0089u\u009e\u009cá\u0005´¤I$`&8îóÊuã|®PF«¤Q\u00958q\u001a\u0017E\u0013! 6\u0018'E/I*>\u008e@DzcnÞg'ßÀhv\u0005ã\u000eZM\u0017\u008dÚë\u008fò\u0016í&R\u0019yB\u000fb¥;Z\u001c)ðÔ;§X\u0000»LÏÔ\u0003"
                        .length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var37 = var17;
                        var10001 = var14++;
                        long var52 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var52;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var60 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var56) {
                              case 0:
                                 var37[var10001] = var60;
                                 if (var13 >= var16) {
                                    w = var17;
                                    x = new Integer[24];
                                    B = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(93704390959355L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[3];
                                    String var4 = "§vB¦wPSßÖ\u001d·ñq\u009d\u009b ä¨!ðu\u0018æ#";
                                    int var5 = "§vB¦wPSßÖ\u001d·ñq\u009d\u009b ä¨!ðu\u0018æ#".length();
                                    do {
                                       int var45 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var45, var2).getBytes("ISO-8859-1");
                                       var45 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var60 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       // var6[var45] = var60;
                                    } while (var2 < var5);

                                    z = var6;
                                    A = new Long[3];
                                    k = new int[]{263, 262, 265, 264, 82};
                                    break;
                                 }
                                 break;
                              default:
                                 var37[var10001] = var60;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "Ê¥U\u0084 Mà \u001dô\u0018=7¢¸\u009a";
                                 var16 = "Ê¥U\u0084 Mà \u001dô\u0018=7¢¸\u009a".length();
                                 var13 = 0;
                           }

                           int var44 = var13;
                           var13 += 8;
                           var18 = var15.substring(var44, var13).getBytes("ISO-8859-1");
                           var37 = var17;
                           var10001 = var14++;
                           var52 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var56 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var33);
                  break;
               default:
                  var29[var27++] = var48;
                  if ((var33 += var25) < var28) {
                     var25 = var26.charAt(var33);
                     continue label72;
                  }

                  var26 = "ò\u0084F\n9\u001b$\u0096Û5d\u008eÑ³æ\u0010\u0010þÂ¥âhQ\u00945îTà\tr\u0017å\u0017";
                  var28 = "ò\u0084F\n9\u001b$\u0096Û5d\u008eÑ³æ\u0010\u0010þÂ¥âhQ\u00945îTà\tr\u0017å\u0017".length();
                  var25 = 16;
                  var33 = -1;
            }

            var34 = var26.substring(++var33, var33 + var25);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2752;
      if (u[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])v.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/gX", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = t[var5].getBytes("ISO-8859-1");
         u[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return u[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gX_C0371",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21609;
      if (x[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = w[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])y.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/gX", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         x[var3] = var15;
      }

      return x[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gX_C0371",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19916;
      if (A[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = z[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])B.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               B.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/gX", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         A[var3] = var15;
      }

      return A[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gX_C0371",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = D[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = C[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 37;
            yield var15;
         }
         case 1 -> {
            byte var16 = 52;
            yield var16;
         }
         case 2 -> {
            byte var17 = 21;
            yield var17;
         }
         case 3 -> {
            byte var18 = 56;
            yield var18;
         }
         case 4 -> {
            byte var19 = 9;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 1;
            yield var21;
         }
         case 7 -> {
            byte var22 = 5;
            yield var22;
         }
         case 8 -> {
            byte var23 = 17;
            yield var23;
         }
         case 9 -> {
            byte var24 = 29;
            yield var24;
         }
         case 10 -> {
            byte var25 = 58;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 54;
            yield var27;
         }
         case 13 -> {
            byte var28 = 49;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 41;
            yield var31;
         }
         case 17 -> {
            byte var32 = 53;
            yield var32;
         }
         case 18 -> {
            byte var33 = 2;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 13;
            yield var37;
         }
         case 23 -> {
            byte var38 = 45;
            yield var38;
         }
         case 24 -> {
            byte var39 = 44;
            yield var39;
         }
         case 25 -> {
            byte var40 = 14;
            yield var40;
         }
         case 26 -> {
            byte var41 = 47;
            yield var41;
         }
         case 27 -> {
            byte var42 = 20;
            yield var42;
         }
         case 28 -> {
            byte var43 = 40;
            yield var43;
         }
         case 29 -> {
            byte var44 = 30;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 31;
            yield var47;
         }
         case 33 -> {
            byte var48 = 33;
            yield var48;
         }
         case 34 -> {
            byte var49 = 18;
            yield var49;
         }
         case 35 -> {
            byte var50 = 57;
            yield var50;
         }
         case 36 -> {
            byte var51 = 4;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 39;
            yield var53;
         }
         case 39 -> {
            byte var54 = 7;
            yield var54;
         }
         case 40 -> {
            byte var55 = 25;
            yield var55;
         }
         case 41 -> {
            byte var56 = 50;
            yield var56;
         }
         case 42 -> {
            byte var57 = 48;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 8;
            yield var59;
         }
         case 45 -> {
            byte var60 = 26;
            yield var60;
         }
         case 46 -> {
            byte var61 = 27;
            yield var61;
         }
         case 47 -> {
            byte var62 = 15;
            yield var62;
         }
         case 48 -> {
            byte var63 = 6;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 42;
            yield var65;
         }
         case 51 -> {
            byte var66 = 11;
            yield var66;
         }
         case 52 -> {
            byte var67 = 3;
            yield var67;
         }
         case 53 -> {
            byte var68 = 0;
            yield var68;
         }
         case 54 -> {
            byte var69 = 16;
            yield var69;
         }
         case 55 -> {
            byte var70 = 19;
            yield var70;
         }
         case 56 -> {
            byte var71 = 28;
            yield var71;
         }
         case 57 -> {
            byte var72 = 22;
            yield var72;
         }
         case 58 -> {
            byte var73 = 51;
            yield var73;
         }
         case 59 -> {
            byte var74 = 60;
            yield var74;
         }
         case 60 -> {
            byte var75 = 12;
            yield var75;
         }
         case 61 -> {
            byte var76 = 10;
            yield var76;
         }
         case 62 -> {
            byte var77 = 35;
            yield var77;
         }
         default -> 63;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            D[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      C[0] = "\u000b3u\u0018Ke\u001d3pBXr\nxsDTf\u001b?dS\u001fr7";
      C[1] = "\u001a\u001e\u0018q~\u0002o>\u0013~oM\u000e0\u0018uk\u0017z";
      C[2] = boolean.class;
      D[2] = "java/lang/Boolean";
      C[3] = "\u0007}'EcR\u0011}\"\u001fpE\u00066!\u0019|Q\u0017q6\u000e7C&";
      C[4] = int.class;
      D[4] = "java/lang/Integer";
      C[5] = "q\u0004r`o\u0004q\u0004e<c\u000bkOe\"c\u001el>5\u007f2";
      C[6] = "b)?\u001cTrb)(@X}xb(^Xh\u007f\u0013\u007f\u0001\u000e";
      C[7] = "*|S1dC!sB~\u0007N4~M\u00152L%mQ9%A";
      C[8] = "]fik]mVix$>`Co";
      C[9] = double.class;
      D[9] = "java/lang/Double";
      C[10] = long.class;
      D[10] = "java/lang/Long";
      C[11] = "S\u000f\u0019\u0003cHS\u000f\u000e_oGID\u000eAoRN5^\u001c<";
      C[12] = "Q\u0005gT\u0003\u001cG\u0005b\u000e\u0010\u000bPNa\b\u001c\u001fA\tv\u001fW\bB";
      C[13] = "r\u0002>X>q\u0007\"5W/>f,>\\+d\u0012";
      C[14] = float.class;
      D[14] = "java/lang/Float";
      C[15] = "\u001a{\u0013\u001d\u0018\u000fo[\u0018\u0012\t@\u000eU\u0013\u0019\r\u001az";
      C[16] = void.class;
      D[16] = "java/lang/Void";
      C[17] = "KGh\bUxKG\u007fTYwQ\f\u007fJYbV}-\u0016\f ";
      C[18] = "7HOn\u000e5<G^!s .]\\b";
      C[19] = "\u007f\u0016\u001fx\u0016;s\u0001\u00025\u001d9?\u0015\n4\u00023r]\n&\u0019tt\u0005\u000e8\u0004tT\u0005\u000e8\u0004";
      C[20] = "`]&\rP kR7B1.`Y3\u0018";
      C[21] = "\u000eVh\u001bk\u000b\u0013C09*\u0006\u000bE";
      C[22] = "np1Z\u00029xp4\u0000\u0011.o;7\u0006\u001d:~| \u0011V*f|\"\u001a\fgZg\"\u0007\f mp";
      C[23] = "5g\u00169I4#g\u0013cZ#4,\u0010eV7%k\u0007r\u001d'+";
      C[24] = "2\u0011wj\u00048$\u0011r0\u0017/3Zq6\u001b;\"\u001df!P*g";
      C[25] = "\u00177Mtk\u000fb\u0017F{z@\u0003\u0019Mp~\u001aw";
      C[26] = "\u0011\\;{\u0018d\u0013Br\u0018\u0013\u007f\fG$a\u0014";
      C[27] = "aY\u0002\u0012I>\u0014y\t\u001dXquw\u0002\u0016\\+\u0001";
      C[28] = "\u0006\u000e\u0010U vs.\u001bZ19\u0012 \u0010Q5cf";
      C[29] = "QBl\u0005\u0013xGBi_\u0000oP\tjY\f{AN}NGkM";
      C[30] = "}Z\u0000\u0014^\"\bz\u000b\u001bOmit\u0000\u0010K7\u001d";
      C[31] = "m\u007f\u007fvi=\u0018_tyxryQ\u007fr|(\r";
      C[32] = "\u0005D?WT;pd4XEt\u0011j?SA.e";
      C[33] = ";u\u0000\u000e3MNU\u000b\u0001\"\u0002/[\u0000\n&X[";
      C[34] = "cBM7$uuBHm7bb\tKk;vsN\\|pdE";
      C[35] = "|#0f1,\t\u0003;i ch\r0b$9\u001c";
      C[36] = ";>\u00173S\u0014->\u0012i@\u0003:u\u0011oL\u0017+2\u0006x\u0007\u0000\u0019";
      C[37] = "0\t3qRfE)8~C)$'3uGsP";
      C[38] = "p3i\u0014E|\u0005\u0013b\u001bT3d\u001di\u0010Pi\u0010";
      C[39] = "~FVF\u00027\u000bf]I\u0013xjhVB\u0017\"\u001e";
      C[40] = "\u001fhqr\u000bH\tht(\u0018_\u001e#w.\u0014K\u000fd`9_[\u0010";
      C[41] = "jD:\u007fn\u0019\u001fd1p\u007fV~j:{{\f\n";
      C[42] = "-<q\u0002\u0018\u000e34kMw\t5<~/_\b3";
      C[43] = "D!\u0016\u0006n4R!\u0013\\}#Ej\u0010Zq7T-\u0007M: V";
      C[44] = "\u00020a\n\u0013ow\u0010j\u0005\u0002 \u0016\u001ea\u000e\u0006zb";
      C[45] = "Dz}\u0011\u000f\u00111Zv\u001e\u001e^PT}\u0015\u001a\u0004$";
      C[46] = "F\u001a\u0006*aE3:\r%p\nR4\u0006.tP&";
      C[47] = "|C\u0003cOW\tc\bl^\u0018hm\u0003gZB\u001c";
      C[48] = "\b[h\tE\n}{c\u0006TE\u001cuh\rP\u001fh";
      C[49] = "4:t-\u001c\u0004\":qw\u000f\u00135qrq\u0003\u0007$6efH\u00106";
      C[50] = "X\u000bw\u0013U\u001a-+|\u001cDUL%w\u0017@\u000f8";
      C[51] = "\u0007q1[9M\u0011q4\u0001*Z\u0006:7\u0007&N\u0017} \u0010m^Z";
      C[52] = "Xc\n\u001fA\u0012-C\u0001\u0010P]LM\n\u001bT\u00078";
      C[53] = "c\u0011SeQf\u00161Xj@)w?SaDs\u0003";
      C[54] = "~c\u001eLSf~c\t\u0010_id(\t\u000e_|cY[S\u0007?)";
      C[55] = "*>[f}L_\u001ePil\u0003>\u0010[bhYJ";
      C[56] = "\u0015~$s<{`^/|-4\u0001P$w)nu";
      C[57] = "}\u001ds \tKk\u001dvz\u001a\\|Vu|\u0016Hm\u0011bk]\\@";
      C[58] = "Y#\\\u0002\bq,\u0003W\r\u0019>M\r\\\u0006\u001dd9";
      C[59] = "Kp\u0014ZFB>P\u001fUW\r_^\u0014^SW+";
      C[60] = "@h\u000b{6yVh\u000e!%nA#\r')zPd\u001a0blv";
      C[61] = "i\u0019B\"kH\u001c9I-z\u0007}7B&~]\t";
      C[62] = "W}\u0019bK9\"]\u0012mZvCS\u0019f^,7";
      C[63] = "`:7:$q\u0015\u001a<55>t\u00147>1d\u0000";
      C[64] = "3}f\u0000\\[F]m\u000fM\u0014'Sf\u0004INS";
      C[65] = "\u001a\u0007\u0001Sx\u0012\u001f\u0012\nSs\t\u0013\u0002H:X#\"";
      C[66] = "\u0003ltZ(4vL\u007fU9{\u0017Bt^=!c";
      C[67] = "I\u001a\u0002\u000b\u000frP\u001b\u0018a\u001e\n\u0016M\u0010\u0005\u001bzH\r\u0007\u000b\u001e\n\u0016\u0018\u001b\u0000\u0002h\u0011\u0015\u000b\nr";
      C[68] = "0HHQL\u001db\rZZ=\u00030Nb\u000fE\f42\u0010P\u0007\\=VE\u001bL\u0014]";
      C[69] = "U@ 8\u0002vQKp~{\u007f\u0007M)f\u0017MS\u000fq={$\u0010\n68\u0002+\u0013Ps\u0001";
      C[70] = "\u0015H>\u0010\u0017?\u0003Z?Joi\u0003Q\u007fF\t~\"J`F*c\u001aOdPo=BGz\u0014\r\u007fB\u00135+";
      C[71] = "4RZ-\u0001\u000b%B\u0001$a\u0012ZP\u0005y\u0005\u001cg[\r\"Y";
      C[72] = "|\u000bu=8Ry\f4jC\u0014\u001c\u000ft '\u0004lQ47)\u0001\u001c\\=l'P&\u000e  2m";
      C[73] = "\u0011\u0013+1Fb\u0014\u0014jf=:q\u0017*,Y4\u0001Ij;W1qDc`Y`K\u0016~,L]";
      C[74] = "g-\u0014S|\u001dd(\b\u0007\u0017\r:{\u0014S@Zd+M?+]d/\n[-\u0012:w";
      C[75] = "TU\u0001(p\u0000QR@\u007f\u000b[4Q\u00005oVD\u000f@\"aS4\u0002Iyo\u0002\u000ePT5z?";
      C[76] = "\u0018GNw\u0000\f\u0001FT\u001d\u0014tG\u0010\\y\u0014\u0004\u0019PKw\u0011t\u0014Y\u0010y@NFD\\l}";
      C[77] = "a_\tK0\ra^\u001e@\rSfS\u0019Iaa7\u0012A\u0010\r\r0\u0015INiX{^\u0001.";
      C[78] = "$\u0016L\u000fV\u0018vP\u000e\u001a\u0014xt-\u000fZ^\u001ct]Q\u001aI\u0012q-\\\u0013\u0012\u001c \u0017\u000e\u000e^\t\u001d";
      C[79] = "#A|NCT:@f$W,|\u0016n@W\\\"VyNR,|CeENN{NuO>";
      C[80] = "P\u001f\u000ekr.U\u0018O<\tt0\u001b\u000fvmx@EOac}0HF:m,\n\u001a[vx\u0011";
      C[81] = "\u001f+A<YW\u0006*[VO/@|S2M_\u001e<D<H/\u0010pAn\u001fAC-Cn$";
      C[82] = "+\bYl\u001e$,\fRs\u0011\u0018w\\Wu\u001atE\u000e\u0017/A%\u0012\n\u0010/Mxv_[d\u0005\u0018";
      C[83] = "1\u001b`:530\u0011g;OgRK3v+g\"\u0015sa%bR\u001b?dw5<Hbfw\u000e";
      C[84] = "oIo7i\u0011jN.`\u0012H\u000fMn*vG\u007f\u0013.=xB\u000f\u001e'fv\u00135L:*c.";
      C[85] = "RqQk*E\r&Qa</\u0001OU*3K\u0002?\u000bj$E\u0007O\u0005&!\u0017P!V{#\u0017k";
      C[86] = "{\u0013oAG'x\u0016s\u0015,<*TkJ@\u000e}\u00125\u001d\u0017Y-X{H\u0011b-YlC,";
      C[87] = "\f^otUt^\u001b}\u007f$j\fXV#H\u0005Z\u001f6~Da\u000fT}6$";
      C[88] = "\u0010/\u0001\u0016McP2A\u000f1( {\r\u001aU;P%M\r[> (DVUo\u001azY\u001a@R";
      C[89] = ",!,I\u0016<5 6#\u0000Dsv>G\u00024-6)I\u0007D ?rGV~r\">Rk";
      C[90] = "dfhvEiaa)!>;\u0004bikZ?t<)|T:\u00041 'Zk>c=kOV";
      C[91] = "%Q3Q\\yeLsH !\u0015\u0005?]D!e[\u007fJJ$\u0015U3O\u0018s{\u0006nM\u0018H";
      C[92] = "\u0003\rU%^\u001fAE\u00148nZ~\u0005Z,\nN\u000e[\u001a;\u0004K~V\u0013`\n\u001aD\u0004\u000e,\u001f'";
      C[93] = "\u001a%\u00177&\u0013\u001a$\u0000<\u001bM\u001d)\u00075w\u007fLiVo\u001b\u0013KoW2\u007fF\u0000$\u001fR";
      C[94] = "?\u0016lq\u0005S)\u0005zm\u007fJ>\u001acm\u0003])uov\u001dLkD|m\u0004VS\u001fz(\u001b\riMgd\u000e0";
      C[95] = "EA[h\u0001s@F\u001a?z!%EZu\u001e%U\u001b\u001ab\u0010 %E\u000f~\u001b<GB\u0002n\u0011L";
      C[96] = "z]EY\f5-@OXt#\u001c\u001f\u0019R\u0010 lAYE\u001e%\u001cO\u0015@Lrr\u001cHBLI";
      C[97] = "\u0016p\u001f\tZJ\u000fq\u0005cN2M*\u000f\u0019ABI/\rX'\u000fLf\u0005\u0005W\u000bIdDc";
      C[98] = "!\"Qx'Q3w\u0013qUFSw\u001dx1B#)]o?GS$T41\u0016ivIx$+";
      C[99] = "\u0014*w4\u0014\u0005\u0015 p5nSwz$x\nQ\u0007$do\u0004Tw*(jV\u0003\u0019yuhV8";
      C[100] = "\u0019PF{)\u001cK\u0015TpX\u0002\u0019Vj;5\u0000\u0012*\u001ezb]\u0014NK1)\u0015t";
      C[101] = "h`\u0018J8\u0013i9\u000eSF\u0007Rk^\u0015v\r6>\u0015^>m";
      C[102] = "n\"G-J\u0006n#P&wXi.W/\u001bj8n\u0007yw\u0006?h\u0007(\u0013St#OH";
      C[103] = "\u001cdxdRqFlua>u@g\u0016bD5^8omGo\u001b\u0001(&\u0005q\u0018x'%_4!";
      C[104] = "z\u001c\u0003\b\u0011@}\u0018\b\u0017\u001e|(B\u0014\t%@|\u0014@qL\u0006xZH\bC\u0005\"\u001fq";
      C[105] = "\u0003\u000f:}$F\u0012\u001fatDWm[0k N\r\tv)5\f";
      C[106] = "Rit]z;Khn7b.Hos[Py\t3.\t\u0007)L1p\n={Q}e7";
      C[107] = "~?'\u00183D<4&\u0000\u007f6(j\"\u0001\u000e[;M!\u000fA\t{b3A#K{6|~z\r}>,\u001a/F6vLEz\fwn(\u00101G?\u000e";
      C[108] = "|rC\u0018y\u0010}+U\u0001\u0007\u0005Fy\u0005G7\u000e\",N\f\u007fn";
      C[109] = ",d?W)\u000412&RX@&d0ZXRpml\f6\u0001-ol71\u0006-5oYb[/5T^e[u6:\r8Yu\r5^3[<2(\b*^M";
      C[110] = "}W UG=dV:?PE\"\u00002[S5|@%UVEqI~[\u0007\u007f#T2N:";
      C[111] = "\u00010\u0010VE^\u0005;@\u0010<WS=\u0019\bPe\u0007\u007fAT<\fDz\u0006VE\u0003G Co";
      C[112] = "\\(N\u000fb\f_-R[\t\u001c\u0001~N\u000f^K_)\u001bc6\u0003\t*S\u000f2\bYl";
      C[113] = "b\u0012S+=\u00025\u000fY*E\u0012\u0004P\u000f !\u0017t\u000eO7/\u0012\u0004\u0004D1\u007f\u000fuV\u0001#t~";
      C[114] = "~;%\u001d+w~:2\u0016\u0016)y75\u001fz\u001b(wd@\u0016s('*Gt1(sex";
      C[115] = "K+\u0013G5G\u0011#\u001eBY]\u001f>}\u0016dXNu\u0013E9ZNN\u0014B9\u0000M G\u001f;\u0000v'@\u001fa\u0003\u0018t\u001d\u001da8";
      C[116] = "\\2~\u0010x_B*<\u0014\u0019P;x}R)Z_-6\u0019a:";
      C[117] = "*q\\\u000bb\u000bpyQ\u000e\u000e\u000epiT_\u000eJm/M\nwEnu\b31H{k\rQsH/$2";
      C[118] = "$Sl\u001bPVv\u0016~\u0010!H$UEE\\JI\u00124\u001b\u0011G-G\u007fPY'";
      C[119] = "\fMk\u0015b]\u0015Lq\u007fu%S\u001ay\u001bvU\rZn\u0015s%\u0003\u0016kG$KPKiG\u001f";
      C[120] = "\u000f\u0015\u0019\u0010\tG\u0004\u001dBLl\u0013`B\u0010\u0006\b\u0013\u0010\u001cP\u0011\u0006\u0016`\u0018H\u0016R\u0000]\u0019B\u0011Sz";
      C[121] = "s#*\u00117\u0002j\"0{#z,t8\u001f#\nr4/\u0011&z|x*Cq\u0014/%(CJ";
      C[122] = "\u001f,\u000e\t<p\u001a+O^G&\u007f(\u000f\u0014#&\u000fvO\u0003-#\u007f(Z\u001f&?\u001d/W\u000f,O";
      C[123] = "BG\u0004\u0013D\u0016AB\u0018G/\r\u0013\u0000\u0000\u0018C?GAX@/T@CY\u0005KR\u000f\u001d\u0001\u007fE\u0010@\u0018]E\u0017\r\f\r`";
      C[124] = "\u0015NdT\r2\u0012JoK\u0002\u000eG\u0010sU92\u0013F&-Pt\u0017\b/T_wMM\u0016";
      C[125] = "\u0018\\oq\r)\fM2!}:c\t<i\u0019:\u0013W|~\u0017?cY0{Eh\r\nmyES";
      C[126] = "X\u0019b>AlC^v4 `HJ\u001f=@kX\u001e..[rB&&4YhTD!9Ib$";
      C[127] = "t.H\u0015>rq)\tBE-\u0014*I\b!$dt\t\u001f/!\u0014y\u0000D!p.+\u001d\b4M";
      C[128] = "Y\\EoGDXVBn=\u0007:\f\u0016#Y\u0010JRV4W\u0015:__oYD\u0000\rB#Ly";
      C[129] = "D&n| V_azvAX\\tzhAY@'w/{\u000b]kb\u0012";
      C[130] = "+\u0012\tGz^5\nKC\u001bQLX\n\u0005+[(\rANc;&\u001b\u000f[&\u0001t\u0006CN\u001b";
      C[131] = "\u0015\u0012E9#TU\u000f\u0005 _\u0001%FI5;\fU\u0018\t\"5\t%\u0015\u0000y;X\u001fG\u001d5.e";
      C[132] = "w]V-&\u0018a\u001c[(FJ\u0006[\u0004?\"Hv\u0005D(,M\u0006\bMs\"\u001c<ZP?7!";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = C[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(D[var4]);
            C[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = C[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            C[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  C[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1471350324190343L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = C[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  C[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1471350324190343L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        C[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1471350324190343L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 237;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 78;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 192;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 207;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 111;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 250;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 237;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 78;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 192;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gX_C0371",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gX" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static RenderCallback invokeBinding1(HudEditorScreen var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gX_C0371;)Ldev/zprestige/prestige/dm_C0190;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/gX_C0371",
                     "lambda$new$0",
                     "(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;Ldev/zprestige/prestige/gz_C0376;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (RenderCallback)var2.invokeExact((HudEditorScreen)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
