package dev.zprestige.prestige.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.entity.player.PlayerEntity;

public class InventoryInputScreen extends InventoryScreen {
   public InventoryInputScreen(PlayerEntity var1) {
      super(var1);
   }

   protected boolean handleHotbarKeyPressed(KeyInput var1) {
      return false;
   }

   public boolean mouseClicked(Click var1, boolean var2) {
      return false;
   }
}
