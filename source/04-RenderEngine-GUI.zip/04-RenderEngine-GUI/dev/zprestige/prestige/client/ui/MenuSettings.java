package dev.zprestige.prestige.client.ui;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class MenuSettings extends Module {
   private final BindSetting f;
   private final ModeSetting b;
   private final BooleanSetting d;
   private final ColorSetting c;
   private static final long k = 105665601855112L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q;
   private static final Object[] r = new Object[14];
   private static final String[] s = new String[14];

   public MenuSettings() {
      super();
      long var10001 = 50856372589717L ^ 11550781880092L;
      var10001 = 50856372589717L ^ 7933353608202L;
      var10001 = 50856372589717L ^ 100853410221684L;
      var10001 = 50856372589717L ^ 93140402780566L;

      Object[] var10006 = new Object[]{null, null, 45594512756895L};
      var10006[1] = 161;
      var10006[0] = "Menu Key";
      Object[] var12 = var10006;
      MenuSettings var11 = this;
      this.f = var11.aReturningBindSetting(var12);
      Object[] var14 = new Object[]{"Descriptions", "Mouse", new String[]{"Mouse", "Search Bar"}, 40413700678537L};
      MenuSettings var13 = this;
      this.b = var13.aReturningModeSetting(var14);
      var10006 = new Object[]{null, null, 135193165491459L};
      var10006[1] = false;
      var10006[0] = "Rounded";
      Object[] var16 = var10006;
      MenuSettings var15 = this;
      this.d = var15.aReturningBooleanSetting(var16);
      Object[] var18 = new Object[]{"Menu Color", new Color(131, 118, 252), 129713107704545L};
      MenuSettings var17 = this;
      this.c = var17.aReturningColorSetting(var18);
   }

   public BindSetting c(Object[] var1) {
      return this.f;
   }

   public ModeSetting bReturningModeSetting(Object[] var1) {
      return this.b;
   }

   public BooleanSetting bReturningBooleanSetting(Object[] var1) {
      return this.d;
   }

   public ColorSetting bReturningColorSetting(Object[] var1) {
      return this.c;
   }

   static {

      {

      f();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(3108912739895L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[7];
      String var17 = "2%5ZM4W:ô!\u0010Ä3\u0012»Ô\u0018N\nfå 2÷\u007fÉ¹¨×\u008b\u001dHÜk±ñ8P<è³\u0010\u001e\u008a\u009búq¼y\u001aß±\u0011µãPî©\u0018iÝ¨\u009d¯\næ\u001cÂ\u0012×´HjÙ\bbÿN*zC}ú\u0018\u0084GÇÇ¢õ2°üG>×Jv\u0015\"À'¨A0\u001dÞT";
      int var19 = "2%5ZM4W:ô!\u0010Ä3\u0012»Ô\u0018N\nfå 2÷\u007fÉ¹¨×\u008b\u001dHÜk±ñ8P<è³\u0010\u001e\u008a\u009búq¼y\u001aß±\u0011µãPî©\u0018iÝ¨\u009d¯\næ\u001cÂ\u0012×´HjÙ\bbÿN*zC}ú\u0018\u0084GÇÇ¢õ2°üG>×Jv\u0015\"À'¨A0\u001dÞT"
         .length();
      char var16 = 16;
      int var24 = -1;

      label54:
      while (true) {
         String var25 = var17.substring(++var24, var24 + var16);
         int var10001 = -1;

         while (true) {
            byte[] var21 = var13.doFinal(var25.getBytes("ISO-8859-1"));
            String var36 = b(var21).intern();
            switch (var10001) {
               case 0:
                  var20[var18++] = var36;
                  if ((var24 += var16) >= var19) {
                     l = var20;
                     m = new String[7];
                     q = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(3108912739895L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[4];
                     String var4 = "\tÛ\u0016n\u0017x¢71\u0092\u0002ª\u008b^\u0080é";
                     int var5 = "\tÛ\u0016n\u0017x¢71\u0092\u0002ª\u008b^\u0080é".length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var28 = var6;
                        var10001 = var3++;
                        long var40 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var40;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var45 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var43) {
                              case 0:
                                 var28[var10001] = var45;
                                 if (var2 >= var5) {
                                    o = var6;
                                    p = new Integer[4];
                                    break;
                                 }
                                 break;
                              default:
                                 var28[var10001] = var45;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "ÌVñé\u0002Û÷ÏüÑÒ\u0080Aþ\u0091\u0094";
                                 var5 = "ÌVñé\u0002Û÷ÏüÑÒ\u0080Aþ\u0091\u0094".length();
                                 var2 = 0;
                           }

                           int var34 = var2;
                           var2 += 8;
                           var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
                           var28 = var6;
                           var10001 = var3++;
                           var40 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var43 = 0;
                        }
                     }
                  }

                  var16 = var17.charAt(var24);
                  break;
               default:
                  var20[var18++] = var36;
                  if ((var24 += var16) < var19) {
                     var16 = var17.charAt(var24);
                     continue label54;
                  }

                  var17 = "\u0098\rÉ\u001a\u001d\u0091[ ô\u0087\u0019\f\u0084@\u0011\u008b\u0018³\t\u0017ç) \u001f÷}ö£6.CÒ\u0086³àGÞ_s8\u0089";
                  var19 = "\u0098\rÉ\u001a\u001d\u0091[ ô\u0087\u0019\f\u0084@\u0011\u008b\u0018³\t\u0017ç) \u001f÷}ö£6.CÒ\u0086³àGÞ_s8\u0089".length();
                  var16 = 16;
                  var24 = -1;
            }

            var25 = var17.substring(++var24, var24 + var16);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String b(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28873;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/e3", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e3",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14938;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/e3", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e3",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int m(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 8;
            yield var15;
         }
         case 1 -> {
            byte var16 = 48;
            yield var16;
         }
         case 2 -> {
            byte var17 = 1;
            yield var17;
         }
         case 3 -> {
            byte var18 = 14;
            yield var18;
         }
         case 4 -> {
            byte var19 = 18;
            yield var19;
         }
         case 5 -> {
            byte var20 = 62;
            yield var20;
         }
         case 6 -> {
            byte var21 = 31;
            yield var21;
         }
         case 7 -> {
            byte var22 = 9;
            yield var22;
         }
         case 8 -> {
            byte var23 = 23;
            yield var23;
         }
         case 9 -> {
            byte var24 = 27;
            yield var24;
         }
         case 10 -> {
            byte var25 = 21;
            yield var25;
         }
         case 11 -> {
            byte var26 = 24;
            yield var26;
         }
         case 12 -> {
            byte var27 = 58;
            yield var27;
         }
         case 13 -> {
            byte var28 = 60;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 3;
            yield var30;
         }
         case 16 -> {
            byte var31 = 52;
            yield var31;
         }
         case 17 -> {
            byte var32 = 11;
            yield var32;
         }
         case 18 -> {
            byte var33 = 33;
            yield var33;
         }
         case 19 -> {
            byte var34 = 63;
            yield var34;
         }
         case 20 -> {
            byte var35 = 4;
            yield var35;
         }
         case 21 -> {
            byte var36 = 6;
            yield var36;
         }
         case 22 -> {
            byte var37 = 37;
            yield var37;
         }
         case 23 -> {
            byte var38 = 42;
            yield var38;
         }
         case 24 -> {
            byte var39 = 28;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 51;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 56;
            yield var43;
         }
         case 29 -> {
            byte var44 = 10;
            yield var44;
         }
         case 30 -> {
            byte var45 = 54;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 15;
            yield var47;
         }
         case 33 -> {
            byte var48 = 49;
            yield var48;
         }
         case 34 -> {
            byte var49 = 61;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 19;
            yield var51;
         }
         case 37 -> {
            byte var52 = 57;
            yield var52;
         }
         case 38 -> {
            byte var53 = 13;
            yield var53;
         }
         case 39 -> {
            byte var54 = 40;
            yield var54;
         }
         case 40 -> {
            byte var55 = 32;
            yield var55;
         }
         case 41 -> {
            byte var56 = 38;
            yield var56;
         }
         case 42 -> {
            byte var57 = 17;
            yield var57;
         }
         case 43 -> {
            byte var58 = 35;
            yield var58;
         }
         case 44 -> {
            byte var59 = 26;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 22;
            yield var61;
         }
         case 47 -> {
            byte var62 = 7;
            yield var62;
         }
         case 48 -> {
            byte var63 = 30;
            yield var63;
         }
         case 49 -> {
            byte var64 = 59;
            yield var64;
         }
         case 50 -> {
            byte var65 = 53;
            yield var65;
         }
         case 51 -> {
            byte var66 = 46;
            yield var66;
         }
         case 52 -> {
            byte var67 = 55;
            yield var67;
         }
         case 53 -> {
            byte var68 = 50;
            yield var68;
         }
         case 54 -> {
            byte var69 = 25;
            yield var69;
         }
         case 55 -> {
            byte var70 = 0;
            yield var70;
         }
         case 56 -> {
            byte var71 = 20;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 5;
            yield var73;
         }
         case 59 -> {
            byte var74 = 44;
            yield var74;
         }
         case 60 -> {
            byte var75 = 12;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 39;
            yield var77;
         }
         default -> 47;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void f() {
      r[0] = "8<D\u0004eN.<A^vY9wBXzM(0UO1Z\f";
      r[1] = "w\u0016\u00148g\u0014\u00026\u001f7v[c8\u0014<r\u0001\u0017";
      r[2] = "*_M\u0004>N<_H^-Y+\u0014KX!M:S\\OjZ\u0006";
      r[3] = "ej6koP\u0010J=d~\u001fqD6ozE\u0005";
      r[4] = "Y\bOx\tNO\bJ\"\u001aYXCI$\u0016MI\u0004^3]Zp";
      r[5] = "<b\u0015L7gIB\u001eC&((L\u0015H\"r\\";
      r[6] = "U\u0004d>cSC\u0004adpDTObb|PE\buu7Gx";
      r[7] = "g\u000b`lQ$\u0012+kc@ks%`hD1\u0007";
      r[8] = "hN.;\u0012E~N+a\u0001Ri\u0005(g\rFxB?pFQK";
      r[9] = "|rMHP\rw}\\\u00071\u0003|vX]";
      r[10] = "st_w95.h\u001fG6Xsh\u0005;-&s<Z9_btl\tx4>09\u0018G";
      r[11] = "KvaxU\u0015\u0016j!HZxKj;4A\u0006K>d63C\u001ae9+L\t\u0013x`H";
      r[12] = "'7L#%az+\f\u0013*\f'+\u0016o1r'\u007fImC0z#\ni9ab<\u0011\u0013";
      r[13] = ":\"G{-Ug>\u0007K\"8:>\u001d79F:jB5K\u00068l\u0013,0Xf-\u0007K";
   }

   private static Class n(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field g(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field h(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = g(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = h(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field o(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = n(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = g(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = h(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = n(679826446293140L, 0L);
         }
      }
   }

   private static Method g(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method h(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = g(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = h(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method p(long var0, long var2) {
      int var4 = m(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = n(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = g(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  n(679826446293140L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = h(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = n(679826446293140L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = n(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 74;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 107;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 81;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 117;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = p(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 235;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = o(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 74;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 107;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 81;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object d(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = d(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/e3",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/e3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
