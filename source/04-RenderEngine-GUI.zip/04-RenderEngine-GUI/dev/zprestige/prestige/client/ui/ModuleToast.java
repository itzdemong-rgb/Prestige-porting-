package dev.zprestige.prestige.client.ui;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;

public class ModuleToast {
   private final String a;
   private final String b;
   private final long c;
   public final long d;
   public float e;
   public boolean f;
   public boolean g;
   private boolean h;
   private ManagedGlTexture i;
   private final String j;
   private final Color k;
   private static final long l = 56980838304244L;
   private static final String[] m;
   private static final String[] n;
   private static final Map o = new HashMap(13);
   private static final long[] p;
   private static final Integer[] q;
   private static final Map r;
   private static final Object[] s = new Object[48];
   private static final String[] t = new String[48];

   public ModuleToast(String var1, String var2, long var3, NotificationType var5, long var6) {
      super();
      var6 = 56980838304244L ^ var6;

      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = System.currentTimeMillis();
      this.e = 0.0F;
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(1);
      this.g = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.h = dev.prestige.recovery.SourceSupport.asBoolean(0);
      NotificationType var8 = var5;
      String var9 = var8.name();
      String var10001 = var9.toLowerCase();
      short var10002 = 18566;
      long var10003 = 4289757195968939550L ^ var6;
      short var11 = 19009;
      long var10004 = 3615047402396812504L ^ var6;
      this.j = "assets/prestige/icons/notifications/" + var10001 + ".png";
      this.k = var5.recoveryAccess_read_a();
   }

   public float aReturningFloat(Object[] var1) {
      Matrix4f var4 = (Matrix4f)var1[0];
      MeshBufferManager var6 = (MeshBufferManager)var1[1];
      RenderContext var2 = (RenderContext)var1[2];
      float var7 = (Float)var1[3];
      float var11 = (Float)var1[4];
      float var3 = (Float)var1[5];
      float var10 = (Float)var1[6];
      byte var5 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[7]))))))))) ? 1 : 0);
      long var8 = (Long)var1[8];
      var8 = 56980838304244L ^ var8;
      long var12 = var8 ^ 34895163198190L;
      long var14 = var8 ^ 24957787904017L;
      long var16 = var8 ^ 27329247800495L;
      long var18 = var8 ^ 60081871867795L;
      long var20 = var8 ^ 35610378865053L;
      long var22 = var8 ^ 103216991524181L;
      long var24 = var8 ^ 133347213695818L;
      long var26 = var8 ^ 12668900626647L;
      long var28 = var8 ^ 10286650331845L;
      int var30 = Event.cReturningInt();
      int var87 = var30;
      ModuleToast var86 = this;
      ModuleToast var69 = var86;
      ModuleToast var68 = var86;
      if (var87 != 0) {
         ManagedGlTexture var88 = var68.i;
         if (var88 == null) {
            Object[] var33 = new Object[]{this.j, var28};
            this.i = TextureLoader.aReturningbT_C0095(var33);
         }

         var7 += (var3 + 30.0F) * (1.0F - this.e);
         var69 = this;
      }

      int var73;
      int var90 = var30;
      byte var89 = ((byte)((var69.f) ? 1 : 0));
      var73 = var89;
      byte var70 = var89;
      label75:
      if (var90 != 0) {
         byte var91 = var70;
         if (var91 != 0) {
            float var10001 = this.e;
            float var10003 = NotificationManager.recoveryAccess_read_d();
            Object[] var10006 = new Object[]{null, null, null, var12};
            var10006[2] = var10003;
            var10006[1] = 1.0F;
            var10006[0] = var10001;
            Object[] var36 = var10006;
            this.e = ClientUiUtil.bReturningFloat(var36);
            float var152;
            int var10000 = (var152 = this.e - 0.99F) == 0.0F ? 0 : (var152 < 0.0F ? -1 : 1);
            int var93 = var30;
            int var92 = var10000;
            var73 = var92;
            int var71 = var92;
            if (var93 == 0) {
               break label75;
            }

            int var94 = var71;
            int var72 = var94;
            int var95 = var72;
            if (var95 >= 0) {
               this.e = 1.0F;
               this.f = false;
            }
         }

         var73 = (((this.g) ? 1 : 0));
      }

      int var77;
      int var97 = var30;
      int var96 = var73;
      var77 = var96;
      int var74 = var96;
      label68:
      if (var97 != 0) {
         int var98 = var74;
         if (var98 != 0) {
            float var122 = this.e;
            float var127 = NotificationManager.recoveryAccess_read_d() * 2.0F;
            Object[] var134 = new Object[]{null, null, null, var12};
            var134[2] = var127;
            var134[1] = 0.0F;
            var134[0] = var122;
            Object[] var41 = var134;
            this.e = ClientUiUtil.bReturningFloat(var41);
            float var153;
            int var116 = (var153 = this.e - 0.01F) == 0.0F ? 0 : (var153 < 0.0F ? -1 : 1);
            int var100 = var30;
            int var99 = var116;
            var77 = var99;
            int var75 = var99;
            if (var100 == 0) {
               break label68;
            }

            int var101 = var75;
            int var76 = var101;
            int var102 = var76;
            if (var102 <= 0) {
               this.e = 0.0F;
               this.h = true;
               return this.e * (var10 + 10.0F);
            }
         }

         long var154;
         var77 = (var154 = System.currentTimeMillis() - this.d - this.c) == 0L ? 0 : (var154 < 0L ? -1 : 1);
      }

      int var81;
      int var104 = var30;
      int var103 = var77;
      var81 = var103;
      int var78 = var103;
      label61:
      if (var104 != 0) {
         int var105 = var78;
         if (var105 >= 0) {
            int var107 = var30;
            byte var106 = ((byte)((this.g) ? 1 : 0));
            var81 = var106;
            byte var79 = var106;
            if (var107 == 0) {
               break label61;
            }

            byte var108 = var79;
            byte var80 = var108;
            byte var109 = var80;
            if (var109 == 0) {
               this.g = true;
            }
         }

         var81 = var5;
      }

      int var110 = var81;
      if (var110 == 0) {
         return this.e * (var10 + 10.0F);
      }

      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var14};
      var10011[8] = 5.0F;
      var10011[7] = 5;
      var10011[6] = var10;
      var10011[5] = var3;
      var10011[4] = var11;
      var10011[3] = var7;
      var10011[2] = var4;
      var10011[1] = var2;
      var10011[0] = var6;
      Object[] var50 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var50);
      Color var10007 = new Color(0.05490196F, 0.05490196F, 0.05490196F, 150.0F * this.e / 255.0F);
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var20};
      var10011[8] = 5.0F;
      var10011[7] = var10007;
      var10011[6] = var10;
      var10011[5] = var3;
      var10011[4] = var11;
      var10011[3] = var7;
      var10011[2] = var4;
      var10011[1] = var2;
      var10011[0] = var6;
      Object[] var51 = var10011;
      FilledRectangleRenderer.cReturningVoid(var51);
      float var117 = var7 + 5.0F;
      float var123 = var11 + 6.0F;
      ManagedGlTexture var10005 = this.i;
      Color var135 = this.k;
      float var138 = this.e;
      Object[] var10010 = new Object[]{null, null, var16};
      var10010[1] = var138;
      var10010[0] = var135;
      Object[] var52 = var10010;
      Object[] var10009 = new Object[]{null, null, null, null, var4, var10005, ClientUiUtil.bReturningColor(var52), var24};
      var10009[3] = 16.0F;
      var10009[2] = 16.0F;
      var10009[1] = var123;
      var10009[0] = var117;
      Object[] var53 = var10009;
      GameRenderUtil.v(var53);
      MsdfFontManager var118 = Prestige.c;
      Object[] var55 = new Object[]{var18};
      MsdfFontManager var54 = var118;
      MsdfFont var119 = var54.aReturningcx_C0158(var55);
      String var10002 = this.a;
      float var128 = var7 + 30.0F;
      float var10004 = var11 + 2.0F;
      var135 = Color.WHITE;
      float var139 = this.e;
      var10010 = new Object[]{null, null, var16};
      var10010[1] = var139;
      var10010[0] = var135;
      Object[] var56 = var10010;
      var10009 = new Object[]{null, null, null, null, null, ClientUiUtil.bReturningColor(var56), var22};
      var10009[4] = 0.9F;
      var10009[3] = var10004;
      var10009[2] = var128;
      var10009[1] = var10002;
      var10009[0] = var4;
      Object[] var58 = var10009;
      MsdfFont var57 = var119;
      var57.w(var58);
      MsdfFontManager var120 = Prestige.c;
      Object[] var60 = new Object[]{var18};
      MsdfFontManager var59 = var120;
      MsdfFont var121 = var59.aReturningcx_C0158(var60);
      var10002 = this.b;
      var128 = var7 + 30.0F;
      var10004 = var11 + 12.0F;
      short var10008 = 31917;
      long var142 = 2925982080341906667L ^ var8;
      short var143 = 29845;
      long var147 = 1425521781663702226L ^ var8;
      short var148 = 29845;
      long var151 = 1425521781663702226L ^ var8;
      var135 = new Color(150, 150, 150);
      float var140 = this.e;
      var10010 = new Object[]{null, null, var16};
      var10010[1] = var140;
      var10010[0] = var135;
      Object[] var61 = var10010;
      var10009 = new Object[]{null, null, null, null, null, ClientUiUtil.bReturningColor(var61), var22};
      var10009[4] = 0.8F;
      var10009[3] = var10004;
      var10009[2] = var128;
      var10009[1] = var10002;
      var10009[0] = var4;
      Object[] var63 = var10009;
      MsdfFont var62 = var121;
      var62.w(var63);
      float var65 = (float)(this.c - (System.currentTimeMillis() - this.d));
      float var64 = 0.0F;
      float var31 = 1.0F - Math.max(var64, var65) / (float)this.c;
      int var113 = var30;
      float var112 = 1.0F;
      float var111 = var31;
      float var84 = var111;
      float var85 = var112;
      float var82 = var111;
      float var83 = var112;
      if (var113 != 0) {
         float var155;
         int var114 = (var155 = var82 - var83) == 0.0F ? 0 : (var155 < 0.0F ? -1 : 1);
         if (var114 < 0) {
            var123 = var7 + 2.0F;
            float var126 = var11 + var10 - 6.0F;
            var128 = var7 + 8.0F + (var3 - 4.0F - (var3 - 4.0F) * var31 - 4.0F);
            var10004 = var11 + var10 - 1.0F;
            Color var133 = this.k;
            var10009 = new Object[]{null, null, null, null, null, null, null, var26};
            var10009[6] = 3.0F;
            var10009[5] = var133;
            var10009[4] = var10004;
            var10009[3] = var128;
            var10009[2] = var126;
            var10009[1] = var123;
            var10009[0] = var4;
            Object[] var67 = var10009;
            GameRenderUtil.nReturningVoid(var67);
         }

         var85 = var10 + 10.0F;
         var84 = this.e;
      }

      return var84 * var85;
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(127169552422258L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[2];
      String var17 = "¿\u0015BW$\u008bn-»f\u008aÚÌ8¼k@»-¯\u0086\fýº0»e\u008c\u0017Ù5¹'¿ªúÇÈ\u0096\u0090ý\u0090\u0087¼Ù\u0005.\u0011<mÅ\u0017#K\u0013qª\tþ¤Áël§\u0010I\u0003\u008eºk\u0080·¢=iÌQ\u0090Çïð";
      int var19 = "¿\u0015BW$\u008bn-»f\u008aÚÌ8¼k@»-¯\u0086\fýº0»e\u008c\u0017Ù5¹'¿ªúÇÈ\u0096\u0090ý\u0090\u0087¼Ù\u0005.\u0011<mÅ\u0017#K\u0013qª\tþ¤Áël§\u0010I\u0003\u008eºk\u0080·¢=iÌQ\u0090Çïð"
         .length();
      char var16 = 16;
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var27 = a(var21).intern();
         int var10001 = -1;
         var20[var18++] = var27;
         if ((var15 += var16) >= var19) {
            m = var20;
            n = new String[2];
            r = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(127169552422258L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[2];
            String var4 = "hÄ'\rH\u008aÊÁ\u0006Ý\f\u0013BÍ\u0097X";
            int var5 = "hÄ'\rH\u008aÊÁ\u0006Ý\f\u0013BÍ\u0097X".length();
            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var10001] = var10004;
            } while (var2 < var5);

            p = var6;
            q = new Integer[2];
            break;
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9468;
      if (n[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])o.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               o.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cP", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = m[var5].getBytes("ISO-8859-1");
         n[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return n[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cP_C0141",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16042;
      if (q[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = p[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])r.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cP", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         q[var3] = var15;
      }

      return q[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cP_C0141",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = t[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = s[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 52;
            yield var15;
         }
         case 1 -> {
            byte var16 = 34;
            yield var16;
         }
         case 2 -> {
            byte var17 = 14;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 56;
            yield var19;
         }
         case 5 -> {
            byte var20 = 47;
            yield var20;
         }
         case 6 -> {
            byte var21 = 43;
            yield var21;
         }
         case 7 -> {
            byte var22 = 58;
            yield var22;
         }
         case 8 -> {
            byte var23 = 49;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 6;
            yield var25;
         }
         case 11 -> {
            byte var26 = 50;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 30;
            yield var28;
         }
         case 14 -> {
            byte var29 = 11;
            yield var29;
         }
         case 15 -> {
            byte var30 = 23;
            yield var30;
         }
         case 16 -> {
            byte var31 = 55;
            yield var31;
         }
         case 17 -> {
            byte var32 = 25;
            yield var32;
         }
         case 18 -> {
            byte var33 = 62;
            yield var33;
         }
         case 19 -> {
            byte var34 = 16;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 27;
            yield var36;
         }
         case 22 -> {
            byte var37 = 28;
            yield var37;
         }
         case 23 -> {
            byte var38 = 21;
            yield var38;
         }
         case 24 -> {
            byte var39 = 2;
            yield var39;
         }
         case 25 -> {
            byte var40 = 45;
            yield var40;
         }
         case 26 -> {
            byte var41 = 44;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 15;
            yield var44;
         }
         case 30 -> {
            byte var45 = 42;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 38;
            yield var47;
         }
         case 33 -> {
            byte var48 = 48;
            yield var48;
         }
         case 34 -> {
            byte var49 = 12;
            yield var49;
         }
         case 35 -> {
            byte var50 = 46;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 9;
            yield var52;
         }
         case 38 -> {
            byte var53 = 33;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 32;
            yield var57;
         }
         case 43 -> {
            byte var58 = 51;
            yield var58;
         }
         case 44 -> {
            byte var59 = 19;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 41;
            yield var61;
         }
         case 47 -> {
            byte var62 = 3;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 57;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 8;
            yield var66;
         }
         case 52 -> {
            byte var67 = 17;
            yield var67;
         }
         case 53 -> {
            byte var68 = 22;
            yield var68;
         }
         case 54 -> {
            byte var69 = 18;
            yield var69;
         }
         case 55 -> {
            byte var70 = 35;
            yield var70;
         }
         case 56 -> {
            byte var71 = 54;
            yield var71;
         }
         case 57 -> {
            byte var72 = 39;
            yield var72;
         }
         case 58 -> {
            byte var73 = 4;
            yield var73;
         }
         case 59 -> {
            byte var74 = 5;
            yield var74;
         }
         case 60 -> {
            byte var75 = 26;
            yield var75;
         }
         case 61 -> {
            byte var76 = 10;
            yield var76;
         }
         case 62 -> {
            byte var77 = 37;
            yield var77;
         }
         default -> 60;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            t[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      s[0] = "HB\u001b{]rCM\n4 gQW\bw";
      s[1] = long.class;
      t[1] = "java/lang/Long";
      s[2] = "W\u001a\u001a\u0004dq\\\u0015\u000bK\u0019iO\u0012\u0002\u0002";
      s[3] = "\u000b~:'\u0007R\u001d~?}\u0014E\n5<{\u0018Q\u001br+lST";
      s[4] = " T\u007f|\u0000N+[n3cC>]";
      s[5] = float.class;
      t[5] = "java/lang/Float";
      s[6] = "{0\u0014\u0012{\u007fm0\u0011Hhhz{\u0012Nd|k<\u0005Y/kh";
      s[7] = "X\u0005\u0004uAx-%\u000fzP7L+\u0004qTm8";
      s[8] = void.class;
      t[8] = "java/lang/Void";
      s[9] = "(i\u0019E>\u001b5|Ag\u007f\u0016-z";
      s[10] = "E1u< \rS1pf3\u001aDzs`?\u000eU=dwt\u001e[";
      s[11] = "^>!43\u0006+\u001e*;\"IJ\u0010!0&\u0013>";
      s[12] = "OTW#,3YTRy?$N\u001fQ\u007f30_XFhx S";
      s[13] = "\u0016\u000bCV3{\u0000\u000bF\f l\u0017@E\n,x\u0006\u0007R\u001dgh\u001e\u0007P\u0016=%\"\u001cP\u000b=b\u0015\u000b";
      s[14] = "2H&E<2Gh-J-}&f&A)'R";
      s[15] = "xMBdy^nMG>jIy\u0006D8f]hAS/-ML";
      s[16] = "\nW3;zp\u0001X\"t\u0019}\u0014U-\u001f,\u007f\u0005F13;r";
      s[17] = "L#\u0018\u007fMMZ#\u001d%^ZMh\u001e#RN\\/\t4\u0019\\m";
      s[18] = int.class;
      t[18] = "java/lang/Integer";
      s[19] = "D>ky'\bR>n#4\u001fEum%8\u000bT2z2s\u001cH";
      s[20] = "p79A\u001dW\u0005\u00172N\f\u0018d\u00199E\bB\u0010";
      s[21] = "(p\f\u0015\n\u000b>p\tO\u0019\u001c);\nI\u0015\b8|\u001d^^\u0019\u0018";
      s[22] = "\u001a\u007f\u0012\u00121!\f\u007f\u0017H\"6\u001b4\u0014N.\"\ns\u0003Ye0<";
      s[23] = "zo\u000b\rS^\u000fO\u0000\u0002B\u0011nA\u000b\tFK\u001a";
      s[24] = "xt9P\u000b'\rT2_\u001ahlZ9T\u001e2\u0018";
      s[25] = "Ptsp\u000fw%Tx\u007f\u001e8DZst\u001ab0";
      s[26] = "y\u0007g0\u0000+o\u0007bj\u0013<xLal\u001f(i\u000bv{T?{";
      s[27] = "\u0014'5D\t\u0000a\u0007>K\u0018O\u0000\t5@\u001c\u0015t";
      s[28] = "\f[a\u0015Xh\u001a[dOK\u007f\r\u0010gIGk\u001cWp^\f{Q";
      s[29] = "\u0016\re?\u0001~c-n0\u00101\u0002#e;\u0014kv";
      s[30] = "B\t\\\u000e[\u0019I\u0006MA:\u0017B\rI\u001b";
      s[31] = "\f\u0016ge/)\u000bV&>J6_\u0017^;38[\\'or1Sgey!>\r\u001e18(66\\'k'hO\bfb/S";
      s[32] = "5\u0019\u0003\u0004[]oGF\u001e \u0012\tJ^\u0006J\u001cg\u0019\u0002\fGl4N^\f\\\u0016iT\u0004P ";
      s[33] = "?-W\u0004\\5j,F\f,\u0000A\u0017`;,az=N\u0006F4{,F";
      s[34] = "BS-dz\fGRb:\u0005Y}[\u007f3o@\u0013\b#9b0MDyieB\u0002Wb-\u0005";
      s[35] = "~^\u00176&3~\t\rQt<mM\u00007c\u001dvR\u0000\u0014~%sV\u0016Qo?oQ]!n#r7";
      s[36] = "0YS8(Y=G^~BN\u0001\u0005[2sZ=\u0000Z}-";
      s[37] = "tU\u000e|>M,K\u0014/\u000f\u000b*s\u0017ob\r\u0006^\u000b}\u000fN/I\u001c!5\u00161SO\u0010";
      s[38] = "Q|\u000e&_\u0004\u001eo\u0015b?\tac\b|U\u0006\u000f0TvXv\\g\bvC\f\u0001}R*?";
      s[39] = "W\u00132GF;E\u0007)P'4>\u0016/Q@mNLwLZ]T\u001b7I\u0017-\u000eC*S'";
      s[40] = "kUAbr2nX\u001da\u0015)\u0000Q\u000b`.,r\u0007\u0000xiB";
      s[41] = "\u0010-\bA}\u0015\u0010:\t\u000b\u001a\u0002|%\u0011\\p\u001b\u0012vMV}k\u0012\u007fHH V\u0019(\u000fU\u001a";
      s[42] = "\t\\T\u00154\n\u001b[\r\u0012\u000b\u001bg[\b\u0010a\u0001\t\bT\u001alqYC\u0000\u0004{\u001b\fB\u0011\f\u000b";
      s[43] = "Eo\t\u00044[\u001f1L\u001eO\fy<T\u0006%\u001a\u0017o\b\f(jD8T\f3\u0010\u0019\"\u000ePO";
      s[44] = "\u000b\u0002k\u000e\u0000F\u0019\u00052\t?We\u00057\u000bUM\u000bVk\u0001X=^\u001f?\u0000\u0004D\n^6\b?";
      s[45] = "D\u0002Ps.\nUE\u0010t\u0016\f%_\u000fv|\u0017K\fS|qg\u0018[\u000f|j\u001dEAU \u0016";
      s[46] = "E\u0010.>\u00047X\u0006$&d?'\u00027!\u000e\"IQk+\u0003R\u001a\u00067+\u0018(G\u001cmwd";
      s[47] = "/\u0011(@*;-L+GLb|\u0013:%ufk\u001af\u001f-xqIW";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = s[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(t[var4]);
            s[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = s[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            s[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  s[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(2175422853156638L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = s[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = t[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  s[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(2175422853156638L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        s[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(2175422853156638L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 69;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 205;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 213;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 86;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 237;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 108;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 69;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 205;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 213;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cP_C0141",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

    public final boolean recoveryAccess_read_h() { return this.h; }

    public final java.lang.String recoveryAccess_read_a() { return this.a; }

    public final java.lang.String recoveryAccess_read_b() { return this.b; }
}
