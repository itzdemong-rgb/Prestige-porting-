package dev.zprestige.prestige.client.ui;

public class MouseClickState {
   private final int a;
   private final long b;
   private final float c;
   private final float d;
   private boolean e;

   public MouseClickState(int var1, long var2, float var4, float var5, boolean var6) {
      this.a = var1;
      this.b = var2;
      this.c = var4;
      this.d = var5;
      this.e = var6;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   public long aReturningLong(Object[] var1) {
      return this.b;
   }

   public float aReturningFloat(Object[] var1) {
      return this.c;
   }

   public float bReturningFloat(Object[] var1) {
      return this.d;
   }

   public boolean aReturningBoolean(Object[] var1) {
      return this.e;
   }

   public void aReturningVoid(Object[] var1) {
      boolean var2 = (Boolean)var1[0];
      this.e = var2;
   }
}
