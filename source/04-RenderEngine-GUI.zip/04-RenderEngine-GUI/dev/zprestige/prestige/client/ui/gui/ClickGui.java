package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderCallback;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.RenderEvents;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;

public final class ClickGui {

    private final Panel panel = new Panel();
    private float mouseX;
    private float mouseY;
    private int viewportWidth;
    private int viewportHeight;
    private float fit = 1.0f;

    public ClickGui() {
        RenderEvents.a.register((RenderCallback) this::render);
    }

    public Panel panel() {
        return panel;
    }

    public void viewport(int width, int height) {
        this.viewportWidth = width;
        this.viewportHeight = height;
    }

    public void mouse(float x, float y) {
        this.mouseX = x;
        this.mouseY = y;
    }

    private void render(MeshBufferManager mb, RenderContext rc) {
        if (!MenuState.isOpen() || mb == null || rc == null || viewportWidth <= 0 || viewportHeight <= 0) {
            return;
        }
        double scale = MinecraftClient.getInstance().getWindow().getScaleFactor();
        float local = Math.min(1.0f, Math.min(viewportWidth / 1100.0f, viewportHeight / 700.0f));
        this.fit = local <= 0.0f ? 1.0f : local;
        Matrix4f matrix = new Matrix4f().scale((float) (scale * fit), (float) (scale * fit), 1.0f);
        panel.viewport(Math.round(viewportWidth / fit), Math.round(viewportHeight / fit));
        panel.render(mb, rc, matrix, mouseX / fit, mouseY / fit);
    }

    public boolean mouseClicked(double x, double y, int button) {
        return panel.mouseClicked(x / fit, y / fit, button);
    }

    public void mouseReleased(double x, double y, int button) {
        panel.mouseReleased(x / fit, y / fit, button);
    }

    public void mouseDragged(double x, double y, int button, double offsetX, double offsetY) {
        panel.mouseDragged(x / fit, y / fit, button, offsetX, offsetY);
    }

    public boolean mouseScrolled(double x, double y, double amount) {
        return panel.mouseScrolled(x / fit, y / fit, amount);
    }

    public boolean keyPressed(int key) {
        return panel.keyPressed(key);
    }

    public boolean charTyped(char character) {
        return panel.charTyped(character);
    }
}
