package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.api.setting.BindSetting;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.api.setting.ColorSetting;
import dev.zprestige.prestige.api.setting.FloatSetting;
import dev.zprestige.prestige.api.setting.IntSetting;
import dev.zprestige.prestige.api.setting.MinMaxSetting;
import dev.zprestige.prestige.api.setting.ModeSetting;
import dev.zprestige.prestige.api.setting.MultiModeSetting;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.api.setting.StringSetting;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.joml.Matrix4f;

public final class DetailPage extends Page {

    private static final float ROW_HEIGHT = 54.0f;
    private static final float HEADER = 86.0f;
    private static final float GAP = 6.0f;
    private static final int BIND = 0;
    private static final int BOOL = 1;
    private static final int COLOR = 2;
    private static final int FLOAT = 3;
    private static final int INT = 4;
    private static final int RANGE = 5;
    private static final int MODE = 6;
    private static final int MULTI = 7;
    private static final int TEXT = 8;

    private final Module module;
    private final List<Row> rows = new ArrayList<>();
    private float scroll;
    private Row dragging;
    private int dragKnob;
    private Row listening;
    private Row editing;
    private Row expanded;

    public DetailPage(Module module) {
        this.module = module;
        rebuild();
    }

    public Module module() {
        return module;
    }

    @Override
    public String title() {
        return module.bReturningString();
    }

    private void rebuild() {
        rows.clear();
        List raw = module.bReturningList();
        if (raw == null) {
            return;
        }
        for (Object entry : raw) {
            if (entry instanceof SettingDefinition definition) {
                rows.add(new Row(definition));
            }
        }
    }

    private boolean visible(Row row) {
            return row.setting.aReturningBoolean();
        } catch (Throwable ignored) {
            return true;
        }
    }

    private float expandedHeight(Row row) {
        if (expanded != row) {
            return 0.0f;
        }
        if (row.type == COLOR) {
            return 130.0f;
        }
        if (row.type == MODE) {
            String[] options = options(row);
            return options.length * 26.0f + 8.0f;
        }
        if (row.type == MULTI) {
            String[] options = options(row);
            return options.length * 26.0f + 8.0f;
        }
        return 0.0f;
    }

    @Override
    public void layout(float x, float y, float w, float h) {
        super.layout(x, y, w, h);
        float cursor = y + HEADER - scroll;
        for (Row row : rows) {
            if (!visible(row)) {
                continue;
            }
            row.bounds = new Rect(x, cursor, w, ROW_HEIGHT + expandedHeight(row));
            control(row);
            cursor += row.bounds.hReturningVoid() + GAP;
        }
    }

    private void control(Row row) {
        float top = row.bounds.y();
        float right = row.bounds.right();
        switch (row.type) {
            case BIND -> {
                row.pill = new Rect(right - 228.0f, top + 13.0f, 96.0f, 28.0f);
                row.box = new Rect(right - 120.0f, top + 13.0f, 120.0f, 28.0f);
            }
            case BOOL -> row.toggle = new Rect(right - 64.0f, top + 16.0f, 44.0f, 22.0f);
            case COLOR -> row.swatch = new Rect(right - 76.0f, top + 13.0f, 28.0f, 28.0f);
            case FLOAT, INT -> {
                row.track = new Rect(right - 360.0f, top + 24.0f, 200.0f, 6.0f);
                row.value = new Rect(right - 96.0f, top + 15.0f, 96.0f, 24.0f);
            }
            case RANGE -> {
                row.track = new Rect(right - 360.0f, top + 24.0f, 200.0f, 6.0f);
                row.value = new Rect(right - 96.0f, top + 15.0f, 96.0f, 24.0f);
            }
            case MODE -> row.combo = new Rect(right - 160.0f, top + 13.0f, 140.0f, 28.0f);
            case MULTI -> row.combo = new Rect(right - 160.0f, top + 13.0f, 140.0f, 28.0f);
            case TEXT -> row.box = new Rect(right - 260.0f, top + 13.0f, 240.0f, 28.0f);
            default -> {
            }
        }
        row.hovered = false;
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        UiRender.rect(mb, rc, matrix, bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid(), Theme.surface(), 14.0f);
        rowHover = null;
        for (Row row : rows) {
            if (visible(row) && row.bounds.contains(mouseX, mouseY)) {
                rowHover = row;
            }
        }

        Rect back = backBounds();
        boolean backHot = back.contains(mouseX, mouseY);
        UiRender.rect(mb, rc, matrix, back.x(), back.y(), back.w(), back.hReturningVoid(), backHot ? Theme.hover() : Theme.card(), 8.0f);
        UiRender.text(matrix, "<", back.centerX() - UiRender.textWidth("<", 7.0f) * 0.5f, back.y() + 20.0f, 7.0f, Theme.accent());

        UiRender.text(matrix, module.bReturningString(), bounds.x() + 46.0f, bounds.y() + 30.0f, 9.0f, Theme.text());
        String description = module.cReturningString();
        if (description != null && !description.isEmpty()) {
            UiRender.text(matrix, ellipsize(description, bounds.w() - 140.0f, 4.6f), bounds.x() + 46.0f, bounds.y() + 52.0f, 4.6f, Theme.muted());
        }

        Rect enable = enableBounds();
        boolean enabled = module.aReturningBoolean();
        boolean enableHot = enable.contains(mouseX, mouseY);
        UiRender.rect(mb, rc, matrix, enable.x(), enable.y(), enable.w(), enable.hReturningVoid(), enabled ? Theme.accent() : (enableHot ? Theme.hover() : Theme.card()), 11.0f);
        float knobX = enabled ? enable.right() - 13.0f : enable.x() + 13.0f;
        UiRender.rect(mb, rc, matrix, knobX - 8.0f, enable.centerY() - 8.0f, 16.0f, 16.0f, new Color(255, 255, 255, 240), 8.0f);

        UiRender.rect(mb, rc, matrix, bounds.x() + 20.0f, bounds.y() + HEADER - 12.0f, bounds.w() - 40.0f, 1.0f, Theme.withAlpha(Theme.border(), 0.5f));

        for (Row row : rows) {
            if (!visible(row)) {
                continue;
            }
            renderRow(mb, rc, matrix, row, mouseX, mouseY);
        }
    }

    private Rect backBounds() {
        return new Rect(bounds.x() + 12.0f, bounds.y() + 12.0f, 28.0f, 28.0f);
    }

    private Rect enableBounds() {
        return new Rect(bounds.right() - 68.0f, bounds.y() + 14.0f, 48.0f, 22.0f);
    }

    private void renderRow(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, float mouseX, float mouseY) {
        boolean hot = row == rowHover;
        if (hot) {
            UiRender.rect(mb, rc, matrix, row.bounds.x(), row.bounds.y(), row.bounds.w(), ROW_HEIGHT, Theme.withAlpha(Theme.hover(), 0.5f), 8.0f);
            UiRender.rect(mb, rc, matrix, row.bounds.x() + 2.0f, row.bounds.y() + 14.0f, 2.0f, ROW_HEIGHT - 28.0f, Theme.accent(), 1.0f);
        }
        String name = row.setting.aReturningString();
        String description = row.setting.bReturningString();
        float controlWidth = controlWidth(row);
        float textMax = row.bounds.w() - controlWidth - 60.0f;
        UiRender.text(matrix, ellipsize(name, textMax, 6.0f), row.bounds.x() + 22.0f, row.bounds.y() + (description == null || description.isEmpty() ? 34.0f : 24.0f), 6.0f, Theme.text());
        if (description != null && !description.isEmpty()) {
            UiRender.text(matrix, ellipsize(description, textMax, 4.4f), row.bounds.x() + 22.0f, row.bounds.y() + 42.0f, 4.4f, Theme.muted());
        }

        switch (row.type) {
            case BIND -> renderBind(mb, rc, matrix, row, hot);
            case BOOL -> renderBool(mb, rc, matrix, row);
            case COLOR -> renderColor(mb, rc, matrix, row, hot);
            case FLOAT -> renderSlider(mb, rc, matrix, row, floatValue(row), ((FloatSetting) row.setting).aReturningVoid(), ((FloatSetting) row.setting).bReturningVoid(), hot);
            case INT -> renderSlider(mb, rc, matrix, row, intValue(row), ((IntSetting) row.setting).aReturningVoid(), ((IntSetting) row.setting).dReturningVoid(), hot);
            case RANGE -> renderRange(mb, rc, matrix, row, hot);
            case MODE -> renderCombo(mb, rc, matrix, row, currentMode(row), hot);
            case MULTI -> renderCombo(mb, rc, matrix, row, selectedCount(row), hot);
            case TEXT -> renderText(mb, rc, matrix, row, hot);
            default -> {
            }
        }

        if (expanded == row) {
            renderExpanded(mb, rc, matrix, row, mouseX, mouseY);
        }
    }

    private float controlWidth(Row row) {
        return switch (row.type) {
            case BIND -> 248.0f;
            case BOOL -> 64.0f;
            case COLOR -> 76.0f;
            case FLOAT, INT, RANGE -> 372.0f;
            case TEXT -> 260.0f;
            case MODE, MULTI -> 160.0f;
            default -> 160.0f;
        };
    }

    private void renderBind(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, boolean hot) {
        BindSetting setting = (BindSetting) row.setting;
        boolean toggleMode = setting.bReturningVoid();
        UiRender.rect(mb, rc, matrix, row.pill.x(), row.pill.y(), row.pill.w(), row.pill.hReturningVoid(), Theme.card(), 14.0f);
        UiRender.rect(mb, rc, matrix, toggleMode ? row.pill.x() + row.pill.w() * 0.5f : row.pill.x(), row.pill.y(), row.pill.w() * 0.5f, row.pill.hReturningVoid(), Theme.accent(), 14.0f);
        UiRender.textCentered(matrix, "Hold", row.pill.x() + row.pill.w() * 0.25f, row.pill.y() + 19.0f, 4.6f, toggleMode ? Theme.muted() : Theme.text());
        UiRender.textCentered(matrix, "Toggle", row.pill.x() + row.pill.w() * 0.75f, row.pill.y() + 19.0f, 4.6f, toggleMode ? Theme.text() : Theme.muted());

        boolean listeningNow = listening == row;
        UiRender.rect(mb, rc, matrix, row.box.x(), row.box.y(), row.box.w(), row.box.hReturningVoid(), listeningNow ? Theme.withAlpha(Theme.accent(), 0.25f) : Theme.card(), 6.0f);
        UiRender.outline(mb, rc, matrix, row.box.x(), row.box.y(), row.box.w(), row.box.hReturningVoid(), listeningNow ? Theme.accent() : Theme.withAlpha(Theme.border(), 0.7f), 1.0f);
        String label = listeningNow ? "..." : GlfwKeyMap.name(intValue(row));
        UiRender.textCentered(matrix, label, row.box.centerX(), row.box.y() + 19.0f, 4.6f, Theme.text());
    }

    private void renderBool(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row) {
        boolean value = boolValue(row);
        UiRender.rect(mb, rc, matrix, row.toggle.x(), row.toggle.y(), row.toggle.w(), row.toggle.hReturningVoid(), value ? Theme.accent() : Theme.card(), 11.0f);
        float knobX = value ? row.toggle.right() - 13.0f : row.toggle.x() + 13.0f;
        UiRender.rect(mb, rc, matrix, knobX - 8.0f, row.toggle.centerY() - 8.0f, 16.0f, 16.0f, new Color(255, 255, 255, 240), 8.0f);
    }

    private void renderColor(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, boolean hot) {
        Color color = colorValue(row);
        UiRender.rect(mb, rc, matrix, row.swatch.x(), row.swatch.y(), row.swatch.w(), row.swatch.hReturningVoid(), color, 6.0f);
        UiRender.outline(mb, rc, matrix, row.swatch.x(), row.swatch.y(), row.swatch.w(), row.swatch.hReturningVoid(), hot ? Theme.accent() : Theme.withAlpha(Theme.border(), 0.8f), 1.0f);
    }

    private void renderSlider(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, float value, float min, float max, boolean hot) {
        float ratio = max > min ? clamp01((value - min) / (max - min)) : 0.0f;
        UiRender.rect(mb, rc, matrix, row.track.x(), row.track.y(), row.track.w(), row.track.hReturningVoid(), new Color(255, 255, 255, 26), 3.0f);
        UiRender.rect(mb, rc, matrix, row.track.x(), row.track.y(), row.track.w() * ratio, row.track.hReturningVoid(), Theme.accent(), 3.0f);
        UiRender.rect(mb, rc, matrix, row.track.x() + row.track.w() * ratio - 6.0f, row.track.centerY() - 6.0f, 12.0f, 12.0f, Theme.accent(), 6.0f);
        UiRender.rect(mb, rc, matrix, row.value.x(), row.value.y(), row.value.w(), row.value.hReturningVoid(), Theme.card(), 6.0f);
        String text = row.type == INT || row.type == RANGE
                ? Integer.toString(Math.round(value))
                : String.format(Locale.ROOT, "%.2f", value);
        UiRender.textCentered(matrix, text, row.value.centerX(), row.value.y() + 17.0f, 4.6f, Theme.text());
    }

    private void renderRange(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, boolean hot) {
        MinMaxSetting setting = (MinMaxSetting) row.setting;
        float min = setting.cReturningVoid();
        float max = setting.dReturningVoid();
        float lo = setting.aReturningVoid();
        float hi = setting.bReturningVoid();
        float span = max - min;
        if (!(span > 0.0f)) {
            span = 1.0f;
        }
        float loRatio = clamp01((lo - min) / span);
        float hiRatio = clamp01((hi - min) / span);
        UiRender.rect(mb, rc, matrix, row.track.x(), row.track.y(), row.track.w(), row.track.hReturningVoid(), new Color(255, 255, 255, 26), 3.0f);
        float x1 = row.track.x() + row.track.w() * loRatio;
        float x2 = row.track.x() + row.track.w() * hiRatio;
        UiRender.rect(mb, rc, matrix, x1, row.track.y(), Math.max(0.0f, x2 - x1), row.track.hReturningVoid(), Theme.accent(), 3.0f);
        UiRender.rect(mb, rc, matrix, x1 - 6.0f, row.track.centerY() - 6.0f, 12.0f, 12.0f, Theme.accent(), 6.0f);
        UiRender.rect(mb, rc, matrix, x2 - 6.0f, row.track.centerY() - 6.0f, 12.0f, 12.0f, Theme.accent(), 6.0f);
        UiRender.rect(mb, rc, matrix, row.value.x(), row.value.y(), row.value.w(), row.value.hReturningVoid(), Theme.card(), 6.0f);
        UiRender.textCentered(matrix, String.format(Locale.ROOT, "%.1f-%.1f", lo, hi), row.value.centerX(), row.value.y() + 17.0f, 4.2f, Theme.text());
    }

    private void renderCombo(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, String label, boolean hot) {
        UiRender.rect(mb, rc, matrix, row.combo.x(), row.combo.y(), row.combo.w(), row.combo.hReturningVoid(), hot ? Theme.hover() : Theme.card(), 6.0f);
        UiRender.outline(mb, rc, matrix, row.combo.x(), row.combo.y(), row.combo.w(), row.combo.hReturningVoid(), expanded == row ? Theme.accent() : Theme.withAlpha(Theme.border(), 0.7f), 1.0f);
        UiRender.textCentered(matrix, ellipsize(label, row.combo.w() - 24.0f, 4.6f), row.combo.centerX(), row.combo.y() + 19.0f, 4.6f, Theme.text());
        UiRender.text(matrix, expanded == row ? "v" : ">", row.combo.right() - 14.0f, row.combo.y() + 19.0f, 4.6f, Theme.muted());
    }

    private void renderText(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, boolean hot) {
        boolean focused = editing == row;
        UiRender.rect(mb, rc, matrix, row.box.x(), row.box.y(), row.box.w(), row.box.hReturningVoid(), Theme.card(), 6.0f);
        UiRender.outline(mb, rc, matrix, row.box.x(), row.box.y(), row.box.w(), row.box.hReturningVoid(), focused ? Theme.accent() : Theme.withAlpha(Theme.border(), 0.7f), 1.0f);
        String value = stringValue(row);
        String shown = value == null || value.isEmpty() ? placeholder(row) : value;
        Color color = value == null || value.isEmpty() ? Theme.muted() : Theme.text();
        UiRender.text(matrix, ellipsize(shown, row.box.w() - 16.0f, 4.6f), row.box.x() + 8.0f, row.box.y() + 19.0f, 4.6f, color);
    }

    private void renderExpanded(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, Row row, float mouseX, float mouseY) {
        float top = row.bounds.y() + ROW_HEIGHT + 2.0f;
        float x = row.bounds.x() + 20.0f;
        float w = row.bounds.w() - 40.0f;
        if (row.type == COLOR) {
            UiRender.rect(mb, rc, matrix, x, top, w, 126.0f, Theme.card(), 8.0f);
            renderColorSlider(mb, rc, matrix, "R", x, top + 8.0f, w, colorValue(row).getRed(), 0);
            renderColorSlider(mb, rc, matrix, "G", x, top + 38.0f, w, colorValue(row).getGreen(), 1);
            renderColorSlider(mb, rc, matrix, "B", x, top + 68.0f, w, colorValue(row).getBlue(), 2);
            renderColorSlider(mb, rc, matrix, "A", x, top + 98.0f, w, colorValue(row).getAlpha(), 3);
            return;
        }
        String[] options = options(row);
        UiRender.rect(mb, rc, matrix, x, top, w, options.length * 26.0f + 4.0f, Theme.card(), 8.0f);
        for (int index = 0; index < options.length; index++) {
            float oy = top + 2.0f + index * 26.0f;
            Rect option = new Rect(x + 4.0f, oy, w - 8.0f, 24.0f);
            boolean hot = option.contains(mouseX, mouseY);
            boolean selected = row.type == MODE ? options[index].equals(currentMode(row)) : multiSelected(row, options[index]);
            if (hot) {
                UiRender.rect(mb, rc, matrix, option.x(), option.y(), option.w(), option.hReturningVoid(), Theme.hover(), 6.0f);
            }
            if (selected) {
                UiRender.rect(mb, rc, matrix, option.x() + 4.0f, option.y() + 7.0f, 10.0f, 10.0f, Theme.accent(), 3.0f);
            }
            UiRender.text(matrix, options[index], option.x() + 22.0f, option.y() + 17.0f, 4.8f, selected ? Theme.accent() : Theme.text());
        }
    }

    private void renderColorSlider(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, String label, float x, float y, float w, int value, int channel) {
        UiRender.text(matrix, label, x + 8.0f, y + 16.0f, 4.6f, Theme.muted());
        float trackX = x + 26.0f;
        float trackW = w - 34.0f;
        UiRender.rect(mb, rc, matrix, trackX, y + 9.0f, trackW, 6.0f, new Color(255, 255, 255, 26), 3.0f);
        float ratio = clamp01(value / 255.0f);
        UiRender.rect(mb, rc, matrix, trackX, y + 9.0f, trackW * ratio, 6.0f, Theme.accent(), 3.0f);
        UiRender.rect(mb, rc, matrix, trackX + trackW * ratio - 5.0f, y + 4.0f, 10.0f, 16.0f, Theme.accent(), 5.0f);
        UiRender.text(matrix, Integer.toString(value), trackX + trackW + 4.0f - UiRender.textWidth(Integer.toString(value), 4.2f), y + 16.0f, 4.2f, Theme.text());
    }

    private Row rowHover;

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float mx = (float) mouseX;
        float my = (float) mouseY;
        if (backBounds().contains(mx, my)) {
            panel.openPage(new ModulesPage(module.aReturningCategory()));
            return true;
        }
        if (enableBounds().contains(mx, my)) {
            module.aReturningVoid(new Object[]{0L});
            return true;
        }
        if (listening != null) {
            listening = null;
        }
        if (editing != null) {
            editing = null;
        }

        for (Row row : rows) {
            if (!visible(row) || !row.bounds.contains(mx, my)) {
                continue;
            }
            if (expanded == row && handleExpandedClick(row, mx, my)) {
                return true;
            }
            switch (row.type) {
                case BIND -> {
                    if (row.pill.contains(mx, my)) {
                        BindSetting setting = (BindSetting) row.setting;
                        setting.aReturningVoid(!setting.bReturningVoid());
                        return true;
                    }
                    if (row.box.contains(mx, my)) {
                        listening = row;
                        expanded = null;
                        return true;
                    }
                }
                case BOOL -> {
                    if (row.toggle.contains(mx, my)) {
                        row.setting.aReturningVoid(!boolValue(row));
                        return true;
                    }
                }
                case COLOR -> {
                    if (row.swatch.contains(mx, my)) {
                        expanded = expanded == row ? null : row;
                        return true;
                    }
                }
                case FLOAT, INT -> {
                    if (row.track.inset(-6.0f).contains(mx, my) || row.value.contains(mx, my)) {
                        dragging = row;
                        dragKnob = 0;
                        applySlider(row, mx);
                        return true;
                    }
                }
                case RANGE -> {
                    if (row.track.inset(-8.0f).contains(mx, my) || row.value.contains(mx, my)) {
                        dragging = row;
                        applySlider(row, mx);
                        return true;
                    }
                }
                case MODE, MULTI -> {
                    if (row.combo.contains(mx, my)) {
                        expanded = expanded == row ? null : row;
                        return true;
                    }
                }
                case TEXT -> {
                    if (row.box.contains(mx, my)) {
                        editing = row;
                        expanded = null;
                        return true;
                    }
                }
                default -> {
                }
            }
            return true;
        }
        expanded = null;
        return false;
    }

    private boolean handleExpandedClick(Row row, float mx, float my) {
        float top = row.bounds.y() + ROW_HEIGHT + 4.0f;
        float w = row.bounds.w() - 48.0f;
        if (row.type == COLOR) {
            for (int channel = 0; channel < 4; channel++) {
                float y = top + 8.0f + channel * 30.0f;
                if (mx >= row.bounds.x() + 20.0f && mx <= row.bounds.x() + 20.0f + w && my >= y && my <= y + 26.0f) {
                    dragging = row;
                    dragKnob = 100 + channel;
                    applyColorSlider(row, mx, channel);
                    return true;
                }
            }
            return false;
        }
        String[] options = options(row);
        for (int index = 0; index < options.length; index++) {
            float oy = top + 2.0f + index * 26.0f;
            Rect option = new Rect(row.bounds.x() + 24.0f, oy, w - 8.0f, 24.0f);
            if (option.contains(mx, my)) {
                if (row.type == MODE) {
                    ((ModeSetting) row.setting).aReturningVoid(options[index]);
                    expanded = null;
                } else {
                    MultiModeSetting setting = (MultiModeSetting) row.setting;
                    setting.aReturningVoid(options[index], !multiSelected(row, options[index]));
                }
                return true;
            }
        }
        return false;
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double offsetX, double offsetY) {
        if (dragging == null) {
            return;
        }
        if (dragKnob >= 100) {
            applyColorSlider(dragging, (float) mouseX, dragKnob - 100);
        } else {
            applySlider(dragging, (float) mouseX);
        }
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = null;
    }

    private void applySlider(Row row, float mouseX) {
        float min;
        float max;
        if (row.type == FLOAT) {
            min = ((FloatSetting) row.setting).aReturningVoid();
            max = ((FloatSetting) row.setting).bReturningVoid();
        } else if (row.type == INT) {
            min = ((IntSetting) row.setting).aReturningVoid();
            max = ((IntSetting) row.setting).dReturningVoid();
        } else {
            MinMaxSetting setting = (MinMaxSetting) row.setting;
            min = setting.cReturningVoid();
            max = setting.dReturningVoid();
        }
        float ratio = row.track.w() > 0.0f ? clamp01((mouseX - row.track.x()) / row.track.w()) : 0.0f;
        float value = min + (max - min) * ratio;
        if (row.type == FLOAT) {
            row.setting.aReturningVoid(value);
        } else if (row.type == INT) {
            row.setting.aReturningVoid(Math.round(value));
        } else {
            MinMaxSetting setting = (MinMaxSetting) row.setting;
            float span = max - min;
            if (Math.abs(value - setting.aReturningVoid()) <= Math.abs(value - setting.bReturningVoid())) {
                setting.aReturningVoid(Math.min(value, setting.bReturningVoid()));
            } else {
                setting.bReturningVoid(Math.max(value, setting.aReturningVoid()));
            }
            if (!(span > 0.0f)) {
                setting.aReturningVoid(min);
                setting.bReturningVoid(max);
            }
        }
    }

    private void applyColorSlider(Row row, float mouseX, int channel) {
        Color color = colorValue(row);
        float w = row.bounds.w() - 60.0f;
        float x = row.bounds.x() + 46.0f;
        float ratio = w > 0.0f ? clamp01((mouseX - x) / w) : 0.0f;
        int value = Math.round(ratio * 255.0f);
        int r = color.getRed();
        int g = color.getGreen();
        int b = color.getBlue();
        int a = color.getAlpha();
        switch (channel) {
            case 0 -> r = value;
            case 1 -> g = value;
            case 2 -> b = value;
            default -> a = value;
        }
        row.setting.aReturningVoid(new Color(r, g, b, a));
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!bounds.contains((float) mouseX, (float) mouseY)) {
            return false;
        }
        scroll += (float) amount * 30.0f;
        float content = 0.0f;
        for (Row row : rows) {
            if (visible(row)) {
                content += ROW_HEIGHT + expandedHeight(row) + GAP;
            }
        }
        float max = Math.min(0.0f, bounds.hReturningVoid() - HEADER - content);
        scroll = Math.max(max, Math.min(0.0f, scroll));
        layout(bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid());
        return true;
    }

    @Override
    public boolean keyPressed(int key) {
        if (listening != null) {
            if (key != 256 && key != 261) {
                listening.setting.aReturningVoid(GlfwKeyMap.toVk(key));
            }
            listening = null;
            return true;
        }
        if (editing != null) {
            if (key == 259) {
                String value = stringValue(editing);
                if (value != null && !value.isEmpty()) {
                    editing.setting.aReturningVoid(value.substring(0, value.length() - 1));
                }
                return true;
            }
            if (key == 257 || key == 335 || key == 256) {
                editing = null;
                return true;
            }
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char character) {
        if (editing == null) {
            return false;
        }
        if (character >= 32 && character != 127) {
            String value = stringValue(editing);
            editing.setting.aReturningVoid((value == null ? "" : value) + character);
        }
        return true;
    }

    private String[] options(Row row) {
        if (row.type == MODE) {
            return ((ModeSetting) row.setting).aReturningArrayOfString();
        }
        if (row.type == MULTI) {
            return ((MultiModeSetting) row.setting).aReturningArrayOfString();
        }
        return new String[0];
    }

    private String currentMode(Row row) {
        Object value = row.setting.aReturningObject();
        return value == null ? "" : value.toString();
    }

    private String selectedCount(Row row) {
        MultiModeSetting setting = (MultiModeSetting) row.setting;
        boolean[] selected = setting.aReturningArrayOfBoolean();
        int count = 0;
        if (selected != null) {
            for (boolean flag : selected) {
                if (flag) {
                    count++;
                }
            }
        }
        return count + " selected";
    }

    private boolean multiSelected(Row row, String option) {
        MultiModeSetting setting = (MultiModeSetting) row.setting;
        String[] options = setting.aReturningArrayOfString();
        boolean[] selected = setting.aReturningArrayOfBoolean();
        if (options == null || selected == null) {
            return false;
        }
        for (int index = 0; index < options.length && index < selected.length; index++) {
            if (options[index].equals(option)) {
                return selected[index];
            }
        }
        return false;
    }

    private boolean boolValue(Row row) {
        return Boolean.TRUE.equals(row.setting.aReturningObject());
    }

    private float floatValue(Row row) {
        Object value = row.setting.aReturningObject();
        return value instanceof Number number ? number.floatValue() : 0.0f;
    }

    private int intValue(Row row) {
        Object value = row.setting.aReturningObject();
        return value instanceof Number number ? number.intValue() : 0;
    }

    private String stringValue(Row row) {
        Object value = row.setting.aReturningObject();
        return value == null ? "" : value.toString();
    }

    private String placeholder(Row row) {
            return ((StringSetting) row.setting).cReturningString(new Object[]{0L});
        } catch (Throwable ignored) {
            return "";
        }
    }

    private Color colorValue(Row row) {
        Object value = row.setting.aReturningObject();
        return value instanceof Color color ? color : Color.WHITE;
    }

    private String ellipsize(String text, float maxWidth, float scale) {
        if (text == null) {
            return "";
        }
        if (UiRender.textWidth(text, scale) <= maxWidth) {
            return text;
        }
        String result = text;
        while (result.length() > 3 && UiRender.textWidth(result + "...", scale) > maxWidth) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "...";
    }

    private static float clamp01(float value) {
        return value < 0.0f ? 0.0f : Math.min(value, 1.0f);
    }

    private static final class Row {
        final SettingDefinition setting;
        final int type;
        Rect bounds = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect track = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect toggle = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect swatch = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect combo = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect pill = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect box = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        Rect value = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
        boolean hovered;

        Row(SettingDefinition setting) {
            this.setting = setting;
            this.type = classify(setting);
        }

        private static int classify(SettingDefinition setting) {
            if (setting instanceof BindSetting) {
                return BIND;
            }
            if (setting instanceof BooleanSetting) {
                return BOOL;
            }
            if (setting instanceof ColorSetting) {
                return COLOR;
            }
            if (setting instanceof FloatSetting) {
                return FLOAT;
            }
            if (setting instanceof IntSetting) {
                return INT;
            }
            if (setting instanceof MinMaxSetting) {
                return RANGE;
            }
            if (setting instanceof ModeSetting) {
                return MODE;
            }
            if (setting instanceof MultiModeSetting) {
                return MULTI;
            }
            if (setting instanceof StringSetting) {
                return TEXT;
            }
            return -1;
        }
    }
}
