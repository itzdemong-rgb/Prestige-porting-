package dev.zprestige.prestige.client.ui.gui;

public final class GlfwKeyMap {

    private static final String[] NAMES = new String[349];

    public static int toVk(int glfwKey) {
        return switch (glfwKey) {
            case 256 -> 27;
            case 257, 335 -> 10;
            case 258 -> 9;
            case 259 -> 8;
            case 260 -> 45;
            case 261 -> 46;
            case 262 -> 39;
            case 263 -> 37;
            case 264 -> 40;
            case 265 -> 38;
            case 266 -> 33;
            case 267 -> 34;
            case 268 -> 36;
            case 269 -> 35;
            case 280 -> 20;
            case 281 -> 144;
            case 283 -> 112;
            case 284 -> 113;
            case 285 -> 114;
            case 286 -> 115;
            case 287 -> 116;
            case 288 -> 117;
            case 289 -> 118;
            case 290 -> 119;
            case 291 -> 120;
            case 292 -> 121;
            case 293 -> 122;
            case 294 -> 123;
            case 295 -> 124;
            case 296 -> 123;
            case 297 -> 121;
            case 298 -> 120;
            case 299 -> 122;
            case 300 -> 123;
            case 301 -> 121;
            case 302 -> 119;
            case 303 -> 118;
            case 304 -> 117;
            case 305 -> 116;
            case 306 -> 115;
            case 307 -> 114;
            case 308 -> 113;
            case 309 -> 112;
            case 310 -> 20;
            case 311 -> 91;
            case 312 -> 92;
            case 313 -> 93;
            case 314, 315 -> 44;
            case 316, 318 -> 19;
            case 317 -> 145;
            case 319 -> 92;
            case 320 -> 96;
            case 321 -> 97;
            case 322 -> 98;
            case 323 -> 99;
            case 324 -> 100;
            case 325 -> 101;
            case 326 -> 102;
            case 327 -> 103;
            case 328 -> 104;
            case 329 -> 105;
            case 330 -> 106;
            case 331 -> 107;
            case 332 -> 108;
            case 333 -> 109;
            case 334 -> 110;
            case 336 -> 186;
            case 337 -> 187;
            case 338 -> 189;
            case 339 -> 192;
            case 340 -> 160;
            case 341 -> 162;
            case 342 -> 164;
            case 343 -> 165;
            case 344 -> 161;
            case 345 -> 163;
            case 346 -> 165;
            case 347 -> 161;
            case 348 -> 93;
            default -> glfwKey;
        };
    }

    public static String name(int key) {
        if (key < 0) {
            return "MOUSE " + (-key);
        }
        if (key >= 0 && key < NAMES.length && NAMES[key] != null) {
            return NAMES[key];
        }
        String resolved = resolve(key);
        if (key >= 0 && key < NAMES.length) {
            NAMES[key] = resolved;
        }
        return resolved;
    }

    private static String resolve(int key) {
        if (key >= 65 && key <= 90) {
            return String.valueOf((char) key);
        }
        if (key >= 48 && key <= 57) {
            return String.valueOf((char) key);
        }
        return switch (key) {
            case 32 -> "SPACE";
            case 160 -> "LSHIFT";
            case 161 -> "RSHIFT";
            case 162 -> "LCTRL";
            case 163 -> "RCTRL";
            case 164 -> "LALT";
            case 165 -> "RALT";
            case 27 -> "ESC";
            case 9 -> "TAB";
            case 8 -> "BACKSPACE";
            case 10 -> "ENTER";
            case 45 -> "INSERT";
            case 46 -> "DELETE";
            case 36 -> "HOME";
            case 35 -> "END";
            case 33 -> "PGUP";
            case 34 -> "PGDN";
            case 37 -> "LEFT";
            case 38 -> "UP";
            case 39 -> "RIGHT";
            case 40 -> "DOWN";
            case 112 -> "F1";
            case 113 -> "F2";
            case 114 -> "F3";
            case 115 -> "F4";
            case 116 -> "F5";
            case 117 -> "F6";
            case 118 -> "F7";
            case 119 -> "F8";
            case 120 -> "F9";
            case 121 -> "F10";
            case 122 -> "F11";
            case 123 -> "F12";
            default -> "KEY " + key;
        };
    }

    private GlfwKeyMap() {
    }
}
