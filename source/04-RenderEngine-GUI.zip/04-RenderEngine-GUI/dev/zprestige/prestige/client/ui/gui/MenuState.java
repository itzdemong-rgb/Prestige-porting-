package dev.zprestige.prestige.client.ui.gui;

public final class MenuState {

    private static final long OPEN_DURATION_NANOS = 220_000_000L;

    private static boolean open;
    private static long changedAt;

    public static boolean isOpen() {
        return open;
    }

    public static void open() {
        if (!open) {
            open = true;
            changedAt = System.nanoTime();
        }
    }

    public static void close() {
        if (open) {
            open = false;
            changedAt = System.nanoTime();
        }
    }

    public static void toggle() {
        if (open) {
            close();
        } else {
            open();
        }
    }

    public static float progress() {
        if (!open) {
            return 0.0f;
        }
        long elapsed = System.nanoTime() - changedAt;
        if (elapsed <= 0L) {
            return 1.0f;
        }
        float ratio = elapsed / (float) OPEN_DURATION_NANOS;
        return ratio >= 1.0f ? 1.0f : ratio;
    }

    private MenuState() {
    }
}
