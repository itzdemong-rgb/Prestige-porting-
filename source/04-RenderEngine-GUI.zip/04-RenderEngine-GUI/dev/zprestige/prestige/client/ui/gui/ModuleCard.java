package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import org.joml.Matrix4f;

public final class ModuleCard extends Widget {

    private static final float SIZE = 120.0f;
    private static final float LIST_HEIGHT = 74.0f;

    private final Module module;
    private final boolean listMode;
    private final Panel panel;

    public ModuleCard(Module module, boolean listMode, Panel panel) {
        this.module = module;
        this.listMode = listMode;
        this.panel = panel;
        this.bounds = new Rect(0.0f, 0.0f, listMode ? 0.0f : SIZE, listMode ? LIST_HEIGHT : SIZE);
    }

    public Module module() {
        return module;
    }

    public void place(float x, float y, float width) {
        float w = listMode ? width : SIZE;
        float h = listMode ? LIST_HEIGHT : SIZE;
        this.bounds = new Rect(x, y, w, h);
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        boolean enabled = module.aReturningBoolean();
        boolean hovered = hovered(mouseX, mouseY);
        UiRender.rect(mb, rc, matrix, bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid(), hovered ? Theme.hover() : Theme.card(), 10.0f);
        if (enabled) {
            UiRender.outline(mb, rc, matrix, bounds.x() - 0.5f, bounds.y() - 0.5f, bounds.w() + 1.0f, bounds.hReturningVoid() + 1.0f, Theme.accent(), 1.5f);
            UiRender.rect(mb, rc, matrix, bounds.x() + 2.0f, bounds.y() + 2.0f, 3.0f, bounds.hReturningVoid() - 4.0f, Theme.accent(), 1.5f);
        }
        UiRender.text(matrix, module.bReturningString(), bounds.x() + 14.0f, bounds.y() + 28.0f, 6.2f, enabled ? Theme.accent() : Theme.text());
        String description = module.cReturningString();
        if (description != null && !description.isEmpty()) {
            UiRender.text(matrix, trim(description), bounds.x() + 14.0f, listMode ? bounds.y() + 50.0f : bounds.y() + bounds.hReturningVoid() - 22.0f, 4.6f, Theme.muted());
        }
    }

    private String trim(String text) {
        float max = bounds.w() - 28.0f;
        if (UiRender.textWidth(text, 4.6f) <= max) {
            return text;
        }
        String result = text;
        while (result.length() > 3 && UiRender.textWidth(result + "...", 4.6f) > max) {
            result = result.substring(0, result.length() - 1);
        }
        return result + "...";
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!hovered((float) mouseX, (float) mouseY)) {
            return false;
        }
        if (button == 0) {
            module.aReturningVoid(new Object[]{0L});
            return true;
        }
        if (button == 1) {
            panel.openPage(new DetailPage(module));
            return true;
        }
        return false;
    }
}
