package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.api.module.Category;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import java.util.ArrayList;
import java.util.List;
import org.joml.Matrix4f;

public final class ModulesPage extends Page {

    private static final float CARD_SIZE = 120.0f;
    private static final float CARD_GAP = 12.0f;

    private final Category category;
    private final List<ModuleCard> cards = new ArrayList<>();
    private boolean listMode;
    private float scroll;

    public ModulesPage(Category category) {
        this.category = category;
        rebuild();
    }

    @Override
    public String title() {
        return category.name();
    }

    private void rebuild() {
        cards.clear();
        if (Prestige.d == null) {
            return;
        }
        List raw = Prestige.d.aReturningVoid();
        if (raw == null) {
            return;
        }
        for (Object entry : raw) {
            if (entry instanceof Module module && module.aReturningCategory() == category) {
                cards.add(new ModuleCard(module, listMode, panel));
            }
        }
    }

    @Override
    public void layout(float x, float y, float w, float h) {
        super.layout(x, y, w, h);
        if (listMode) {
            float cursor = y + 56.0f + scroll;
            for (ModuleCard card : cards) {
                card.place(x, cursor, w);
                cursor += 74.0f + 8.0f;
            }
        } else {
            float step = CARD_SIZE + CARD_GAP;
            int perRow = Math.max(1, (int) ((w + CARD_GAP) / step));
            for (int index = 0; index < cards.size(); index++) {
                float cardX = x + (index % perRow) * step;
                float cardY = y + 56.0f + scroll + (index / perRow) * step;
                cards.get(index).place(cardX, cardY, CARD_SIZE);
            }
        }
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        UiRender.text(matrix, category.name(), bounds.x(), bounds.y() + 30.0f, 10.0f, Theme.text());
        UiRender.text(matrix, cards.size() + " modules", bounds.x() + UiRender.textWidth(category.name(), 10.0f) + 14.0f, bounds.y() + 28.0f, 4.8f, Theme.muted());
        Rect toggle = toggleBounds();
        boolean hovered = toggle.contains(mouseX, mouseY);
        UiRender.rect(mb, rc, matrix, toggle.x(), toggle.y(), toggle.w(), toggle.hReturningVoid(), hovered ? Theme.hover() : Theme.card(), 8.0f);
        UiRender.textCentered(matrix, listMode ? "LIST" : "GRID", toggle.centerX(), toggle.y() + 19.0f, 4.8f, Theme.accent());
        for (ModuleCard card : cards) {
            card.render(mb, rc, matrix, mouseX, mouseY);
        }
    }

    private Rect toggleBounds() {
        return new Rect(bounds.x() + bounds.w() - 70.0f, bounds.y() + 8.0f, 70.0f, 28.0f);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (toggleBounds().contains((float) mouseX, (float) mouseY)) {
            listMode = !listMode;
            rebuild();
            layout(bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid());
            return true;
        }
        for (ModuleCard card : cards) {
            if (card.mouseClicked(mouseX, mouseY, button)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!bounds.contains((float) mouseX, (float) mouseY)) {
            return false;
        }
        scroll += (float) amount * 30.0f;
        scroll = Math.min(0.0f, scroll);
        layout(bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid());
        return true;
    }
}
