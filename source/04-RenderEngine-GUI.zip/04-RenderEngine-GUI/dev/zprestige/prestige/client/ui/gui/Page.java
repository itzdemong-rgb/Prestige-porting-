package dev.zprestige.prestige.client.ui.gui;

public abstract class Page extends Widget {

    protected Panel panel;

    public void attach(Panel panel) {
        this.panel = panel;
    }

    public String title() {
        return "";
    }

    public void layout(float x, float y, float w, float h) {
        this.bounds = new Rect(x, y, w, h);
    }
}
