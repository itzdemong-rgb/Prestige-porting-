package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import java.util.ArrayDeque;
import java.util.Deque;
import org.joml.Matrix4f;

public final class Panel extends Widget {

    private static final float WIDTH = 1100.0f;
    private static final float HEIGHT = 700.0f;
    private static final float RADIUS = 25.0f;
    private static final float HEADER = 30.0f;
    private static final float PADDING = 14.0f;
    private static final float GAP = 18.0f;

    private final Sidebar sidebar = new Sidebar(this);
    private final Deque<Widget> popups = new ArrayDeque<>();

    private Page page;
    private float x;
    private float y;
    private boolean centered;
    private boolean dragging;
    private float dragX;
    private float dragY;

    public Panel() {
        this.bounds = new Rect(0.0f, 0.0f, WIDTH, HEIGHT);
    }

    public Sidebar sidebar() {
        return sidebar;
    }

    public Page page() {
        return page;
    }

    public void openPage(Page next) {
        this.page = next;
        next.attach(this);
        layout();
    }

    public void pushPopup(Widget popup) {
        popups.push(popup);
    }

    public void popPopup() {
        if (!popups.isEmpty()) {
            popups.pop();
        }
    }

    public boolean hasPopup() {
        return !popups.isEmpty();
    }

    public void viewport(float viewportWidth, float viewportHeight) {
        if (!centered) {
            this.x = (viewportWidth - WIDTH) * 0.5f;
            this.y = (viewportHeight - HEIGHT) * 0.5f;
            this.centered = true;
        }
        this.x = Math.max(0.0f, Math.min(this.x, viewportWidth - WIDTH));
        this.y = Math.max(0.0f, Math.min(this.y, viewportHeight - HEIGHT));
        layout();
    }

    private void layout() {
        this.bounds = new Rect(x, y, WIDTH, HEIGHT);
        float sidebarWidth = sidebar.width();
        sidebar.layout(x + PADDING, y + PADDING, sidebarWidth, HEIGHT - PADDING * 2.0f);
        if (page != null) {
            page.layout(x + PADDING + sidebarWidth + GAP, y + PADDING, WIDTH - sidebarWidth - GAP - PADDING * 2.0f, HEIGHT - PADDING * 2.0f);
        }
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        UiRender.blur(mb, rc, matrix, x, y, WIDTH, HEIGHT, 8, 6.0f);
        UiRender.rect(mb, rc, matrix, x, y, WIDTH, HEIGHT, Theme.background(), RADIUS);
        UiRender.outline(mb, rc, matrix, x, y, WIDTH, HEIGHT, Theme.withAlpha(Theme.border(), 0.8f), 1.0f);
        sidebar.render(mb, rc, matrix, mouseX, mouseY);
        if (page != null) {
            page.render(mb, rc, matrix, mouseX, mouseY);
        }
        for (Widget popup : popups) {
            popup.render(mb, rc, matrix, mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!popups.isEmpty()) {
            return popups.peek().mouseClicked(mouseX, mouseY, button);
        }
        float mx = (float) mouseX;
        float my = (float) mouseY;
        if (new Rect(x, y, WIDTH, HEADER).contains(mx, my)) {
            dragging = true;
            dragX = mx - x;
            dragY = my - y;
            return true;
        }
        if (sidebar.mouseClicked(mx, my, button)) {
            return true;
        }
        return page != null && page.mouseClicked(mx, my, button);
    }

    @Override
    public void mouseReleased(double mouseX, double mouseY, int button) {
        dragging = false;
        sidebar.mouseReleased(mouseX, mouseY, button);
        if (page != null) {
            page.mouseReleased(mouseX, mouseY, button);
        }
        if (!popups.isEmpty()) {
            popups.peek().mouseReleased(mouseX, mouseY, button);
        }
    }

    @Override
    public void mouseDragged(double mouseX, double mouseY, int button, double offsetX, double offsetY) {
        if (dragging) {
            this.x = (float) mouseX - dragX;
            this.y = (float) mouseY - dragY;
            layout();
            return;
        }
        sidebar.mouseDragged(mouseX, mouseY, button, offsetX, offsetY);
        if (page != null) {
            page.mouseDragged(mouseX, mouseY, button, offsetX, offsetY);
        }
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (!popups.isEmpty()) {
            return popups.peek().mouseScrolled(mouseX, mouseY, amount);
        }
        return page != null && page.mouseScrolled(mouseX, mouseY, amount);
    }

    @Override
    public boolean keyPressed(int key) {
        if (!popups.isEmpty()) {
            return popups.peek().keyPressed(key);
        }
        if (page != null && page.keyPressed(key)) {
            return true;
        }
        return sidebar.keyPressed(key);
    }

    @Override
    public boolean charTyped(char character) {
        if (!popups.isEmpty()) {
            return popups.peek().charTyped(character);
        }
        return page != null && page.charTyped(character);
    }
}
