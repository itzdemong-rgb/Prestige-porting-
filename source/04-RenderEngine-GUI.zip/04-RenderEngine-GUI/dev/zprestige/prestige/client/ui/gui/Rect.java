package dev.zprestige.prestige.client.ui.gui;

public record Rect(float x, float y, float w, float h) {

    public boolean contains(float px, float py) {
        return px >= x && px < x + w && py >= y && py < y + h;
    }

    public float right() {
        return x + w;
    }

    public float bottom() {
        return y + h;
    }

    public float centerX() {
        return x + w * 0.5f;
    }

    public float centerY() {
        return y + h * 0.5f;
    }

    public Rect offset(float dx, float dy) {
        return new Rect(x + dx, y + dy, w, h);
    }

    public Rect inset(float amount) {
        return new Rect(x + amount, y + amount, w - amount * 2.0f, h - amount * 2.0f);
    }
}
