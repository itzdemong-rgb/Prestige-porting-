package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.api.module.Category;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import java.util.ArrayList;
import java.util.List;
import org.joml.Matrix4f;

public final class Sidebar extends Widget {

    private static final float WIDTH = 230.0f;
    private static final float ROW_HEIGHT = 38.0f;
    private static final float ROW_STEP = 42.0f;

    private final Panel panel;
    private final List<Category> categories = new ArrayList<>();
    private final List<String> general = List.of("Settings", "Theme", "Configs", "Socials", "Keybinds");
    private int selected = -1;

    public Sidebar(Panel panel) {
        this.panel = panel;
        for (Category category : Category.values()) {
            if (category != Category.Menu) {
                categories.add(category);
            }
        }
    }

    public float width() {
        return WIDTH;
    }

    private float modulesTop() {
        return bounds.y() + 92.0f;
    }

    private float generalTop() {
        return modulesTop() + categories.size() * ROW_STEP + 22.0f;
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        UiRender.rect(mb, rc, matrix, bounds.x(), bounds.y(), bounds.w(), bounds.hReturningVoid(), Theme.surface(), 16.0f);
        UiRender.text(matrix, "Prestige", bounds.x() + 18.0f, bounds.y() + 34.0f, 8.0f, Theme.text());
        UiRender.text(matrix, "Client", bounds.x() + 18.0f + UiRender.textWidth("Prestige ", 8.0f), bounds.y() + 34.0f, 8.0f, Theme.accent());
        UiRender.text(matrix, "MODULES", bounds.x() + 18.0f, bounds.y() + 78.0f, 4.6f, Theme.muted());

        float rowY = modulesTop();
        for (int index = 0; index < categories.size(); index++) {
            drawRow(mb, rc, matrix, mouseX, mouseY, rowY, selected == index, categories.get(index).name());
            rowY += ROW_STEP;
        }

        UiRender.text(matrix, "GENERAL", bounds.x() + 18.0f, generalTop() - 16.0f, 4.6f, Theme.muted());
        rowY = generalTop();
        for (int index = 0; index < general.size(); index++) {
            int key = categories.size() + index;
            drawRow(mb, rc, matrix, mouseX, mouseY, rowY, selected == key, general.get(index));
            rowY += ROW_STEP;
        }
    }

    private void drawRow(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY, float y, boolean active, String label) {
        Rect row = new Rect(bounds.x() + 10.0f, y, WIDTH - 20.0f, ROW_HEIGHT);
        boolean hovered = row.contains(mouseX, mouseY);
        if (active) {
            UiRender.rect(mb, rc, matrix, row.x(), row.y(), row.w(), row.hReturningVoid(), Theme.withAlpha(Theme.accent(), 0.22f), 10.0f);
        } else if (hovered) {
            UiRender.rect(mb, rc, matrix, row.x(), row.y(), row.w(), row.hReturningVoid(), Theme.hover(), 10.0f);
        }
        if (active) {
            UiRender.rect(mb, rc, matrix, row.x() + 2.0f, row.y() + 9.0f, 3.0f, row.hReturningVoid() - 18.0f, Theme.accent(), 1.5f);
        }
        UiRender.text(matrix, label, row.x() + 18.0f, row.y() + 24.0f, 6.0f, active ? Theme.accent() : Theme.text());
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        float rowY = modulesTop();
        for (int index = 0; index < categories.size(); index++) {
            if (new Rect(bounds.x() + 10.0f, rowY, WIDTH - 20.0f, ROW_HEIGHT).contains((float) mouseX, (float) mouseY)) {
                selected = index;
                panel.openPage(new ModulesPage(categories.get(index)));
                return true;
            }
            rowY += ROW_STEP;
        }
        rowY = generalTop();
        for (int index = 0; index < general.size(); index++) {
            int key = categories.size() + index;
            if (new Rect(bounds.x() + 10.0f, rowY, WIDTH - 20.0f, ROW_HEIGHT).contains((float) mouseX, (float) mouseY)) {
                selected = key;
                panel.openPage(generalPage(index));
                return true;
            }
            rowY += ROW_STEP;
        }
        return false;
    }

    private Page generalPage(int index) {
        return switch (index) {
            case 0 -> new SimpleTextPage("Settings", "Client and menu preferences");
            case 1 -> new SimpleTextPage("Theme", "Menu colour and styling");
            case 2 -> new SimpleTextPage("Configs", "Save and load configurations");
            case 3 -> new SimpleTextPage("Socials", "Friends and enemies");
            default -> new SimpleTextPage("Keybinds", "Module key bindings");
        };
    }
}
