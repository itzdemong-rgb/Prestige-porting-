package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import org.joml.Matrix4f;

public final class SimpleTextPage extends Page {

    private final String heading;
    private final String description;

    public SimpleTextPage(String heading, String description) {
        this.heading = heading;
        this.description = description;
    }

    @Override
    public String title() {
        return heading;
    }

    @Override
    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
        UiRender.text(matrix, heading, bounds.x(), bounds.y() + 30.0f, 10.0f, Theme.text());
        UiRender.text(matrix, description, bounds.x(), bounds.y() + 58.0f, 5.0f, Theme.muted());
        UiRender.rect(mb, rc, matrix, bounds.x(), bounds.y() + 80.0f, bounds.w(), 1.0f, Theme.withAlpha(Theme.border(), 0.6f));
    }
}
