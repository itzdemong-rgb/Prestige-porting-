package dev.zprestige.prestige.client.ui.gui;

import java.awt.Color;

public final class Theme {

    private static final Color BACKGROUND = new Color(16, 16, 22, 236);
    private static final Color SURFACE = new Color(26, 26, 36, 240);
    private static final Color CARD = new Color(32, 32, 44, 245);
    private static final Color HOVER = new Color(46, 46, 62, 250);
    private static final Color TEXT = new Color(235, 235, 245);
    private static final Color MUTED = new Color(148, 148, 168);
    private static final Color BORDER = new Color(64, 64, 84, 180);
    private static final Color ACCENT = new Color(131, 118, 252);

    public static Color background() {
        return BACKGROUND;
    }

    public static Color surface() {
        return SURFACE;
    }

    public static Color card() {
        return CARD;
    }

    public static Color hover() {
        return HOVER;
    }

    public static Color text() {
        return TEXT;
    }

    public static Color muted() {
        return MUTED;
    }

    public static Color border() {
        return BORDER;
    }

    public static Color accent() {
        return ACCENT;
    }

    public static Color withAlpha(Color color, float alpha) {
        float clamped = Math.max(0.0f, Math.min(1.0f, alpha));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int) (clamped * 255.0f));
    }

    public static Color mix(Color first, Color second, float amount) {
        float t = Math.max(0.0f, Math.min(1.0f, amount));
        int r = (int) (first.getRed() + (second.getRed() - first.getRed()) * t);
        int g = (int) (first.getGreen() + (second.getGreen() - first.getGreen()) * t);
        int b = (int) (first.getBlue() + (second.getBlue() - first.getBlue()) * t);
        int a = (int) (first.getAlpha() + (second.getAlpha() - first.getAlpha()) * t);
        return new Color(r, g, b, a);
    }

    private Theme() {
    }
}
