package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;
import java.awt.Color;
import org.joml.Matrix4f;

public final class UiRender {

    private static final long SALT = 0L;
    private static final float TEXT_BASE_SCALE = 1.0f;

    private static MsdfFont font;

    public static MsdfFont font() {
        if (font == null && Prestige.c != null) {
            font = Prestige.c.aReturningcx_C0158(new Object[]{SALT});
        }
        return font;
    }

    public static void rect(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float x, float y, float w, float h, Color color) {
        rect(mb, rc, matrix, x, y, w, h, color, 0.0f);
    }

    public static void rect(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float x, float y, float w, float h, Color color, float radius) {
        FilledRectangleRenderer.cReturningVoid(new Object[]{mb, rc, matrix, x, y, w, h, color, radius, SALT});
    }

    public static void outline(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float x, float y, float w, float h, Color color, float thickness) {
        rect(mb, rc, matrix, x, y, w, thickness, color);
        rect(mb, rc, matrix, x, y + h - thickness, w, thickness, color);
        rect(mb, rc, matrix, x, y + thickness, thickness, h - thickness * 2.0f, color);
        rect(mb, rc, matrix, x + w - thickness, y + thickness, thickness, h - thickness * 2.0f, color);
    }

    public static void line(Matrix4f matrix, float x1, float y1, float x2, float y2, Color color) {
        ShapeRenderer.lReturningVoid(new Object[]{matrix, x1, y1, x2, y2, color, SALT});
    }

    public static void blur(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float x, float y, float w, float h, int quality, float radius) {
        BlurredRectangleRenderer.eReturningVoid(new Object[]{mb, rc, matrix, x, y, w, h, quality, radius, SALT});
    }

    public static void text(Matrix4f matrix, String text, float x, float y, float scale, Color color) {
        MsdfFont resolved = font();
        if (resolved == null || text == null || text.isEmpty()) {
            return;
        }
        resolved.w(new Object[]{matrix, text, x, y, TEXT_BASE_SCALE * scale, color, SALT});
    }

    public static void textCentered(Matrix4f matrix, String text, float centerX, float y, float scale, Color color) {
        text(matrix, text, centerX - textWidth(text, scale) * 0.5f, y, scale, color);
    }

    public static float textWidth(String text, float scale) {
        MsdfFont resolved = font();
        if (resolved == null || text == null || text.isEmpty()) {
            return 0.0f;
        }
        return resolved.aReturningFloat(new Object[]{text, SALT}) * TEXT_BASE_SCALE * scale;
    }

    public static float textHeight(float scale) {
        MsdfFont resolved = font();
        if (resolved == null) {
            return scale;
        }
        return resolved.cReturningFloat(new Object[]{SALT}) * scale;
    }

    private UiRender() {
    }
}
