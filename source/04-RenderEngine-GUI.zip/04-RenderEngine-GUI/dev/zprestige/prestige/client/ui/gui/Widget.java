package dev.zprestige.prestige.client.ui.gui;

import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import org.joml.Matrix4f;

public abstract class Widget {

    protected Rect bounds = new Rect(0.0f, 0.0f, 0.0f, 0.0f);
    protected boolean visible = true;

    public Rect bounds() {
        return bounds;
    }

    public boolean visible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }

    public void layout(float x, float y, float w, float h) {
        this.bounds = new Rect(x, y, w, h);
    }

    public boolean hovered(float mouseX, float mouseY) {
        return visible && bounds.contains(mouseX, mouseY);
    }

    public void render(MeshBufferManager mb, RenderContext rc, Matrix4f matrix, float mouseX, float mouseY) {
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return false;
    }

    public void mouseReleased(double mouseX, double mouseY, int button) {
    }

    public void mouseDragged(double mouseX, double mouseY, int button, double offsetX, double offsetY) {
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return false;
    }

    public boolean keyPressed(int key) {
        return false;
    }

    public boolean charTyped(char character) {
        return false;
    }
}
