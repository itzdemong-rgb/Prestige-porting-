package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

public class CartHelperWidget extends HudElement {
   private static final int a;
   private static final float m = 0.6F;
   private static final float c = 9.6F;
   private static final float d = 4.0F;
   private static final float g = 30.0F;
   private static final float h = 3.0F;
   private static final Color i;
   private static final Color j;
   private static final Color k;
   private static final Set l;
   private static final int n = 0;
   private static final int o = 1;
   private static final int p;
   private static final int q;
   private String r;
   private boolean s;
   private int t;
   private float u;
   private int v;
   private final ItemStack[] w;
   private boolean x;
   private static final long y = 10251036501468L;
   private static final String[] B;
   private static final String[] C;
   private static final Map D = new HashMap(13);
   private static final long[] H;
   private static final Integer[] I;
   private static final Map J;
   private static final Object[] K = new Object[115];
   private static final String[] L = new String[115];

   public CartHelperWidget(long var1) {
      super("Cart Helper", "Cart PvP at a glance — trigger readiness, crossbow charge, and TNT cart stock.", ((10251036501468L ^ (10251036501468L ^ var1)) ^ 36833642200868L));
      var1 = 10251036501468L ^ var1;
      long var3 = var1 ^ 36833642200868L;
      short var10001 = 28345;
      long var10002 = 1365282957350674511L ^ var1;
      short var7 = 21005;
      long var10003 = 5051987364006010109L ^ var1;

      var10001 = 15894;
      var10002 = 3223147644679581925L ^ var1;
      this.r = "Ready";
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(1);
      this.t = 0;
      this.u = 0.0F;
      this.v = 0;
      this.w = new ItemStack[2];
      this.x = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 340.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      CartHelperWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   private void r(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 10251036501468L ^ var2;
      int var4 = Event.bReturningInt();
      int var15 = var4;
      CartHelperWidget var14 = this;
      CartHelperWidget var13 = var14;
      CartHelperWidget var12 = var14;
      if (var15 == 0) {
         boolean var16 = var12.x;
         if (var16) {
            return;
         }

         this.w[0] = new ItemStack(Items.CROSSBOW);
         ItemStack var10000 = this.w[0];
         ComponentType var10001 = DataComponentTypes.ITEM_MODEL;
         short var10002 = 9876;
         long var10003 = 7436873296320973687L ^ var2;
         short var18 = 1955;
         long var10004 = 3892153554392279628L ^ var2;
         String var8 = "crossbow_standby";
         String var7 = "minecraft";
         Identifier var11 = Identifier.of(var7, var8);
         ComponentType var10 = var10001;
         ItemStack var9 = var10000;
         var9.set(var10, var11);
         this.w[1] = new ItemStack(Items.TNT_MINECART);
         var13 = this;
      }

      var13.x = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 44497476817693L ^ 79695564870952L;
      int var6 = Event.cReturningInt();
      int var150 = var6;
      MinecraftClient var149 = b;
      MinecraftClient var77 = var149;
      MinecraftClient var76 = var149;
      if (var150 != 0) {
         MinecraftClient var16 = var76;
         ClientPlayerEntity var151 = var16.player;
         if (var151 == null) {
            return;
         }

         MinecraftClient var152 = b;
         var77 = var152;
      }

      MinecraftClient var19 = var77;
      ClientWorld var153 = var19.world;
      if (var153 != null) {
         byte var8 = 0;
         byte var9 = 0;
         byte var10 = 0;
         ItemStack var89;
         while (true) {
            byte var155 = 35;
            int var154 = var12;
            if (var154 <= var155) {
               MinecraftClient var21 = b;
               ClientPlayerEntity var22 = var21.player;
               PlayerInventory var10000 = var22.getInventory();
               int var24 = var12;
               PlayerInventory var23 = var10000;
               ItemStack var13 = var23.getStack(var24);
               int var157 = var6;
               ItemStack var156 = var13;
               var89 = var156;
               ItemStack var78 = var156;
               if (var157 == 0) {
                  break;
               }

               ItemStack var25 = var78;
               Item var257 = var25.getItem();
               Item var159 = Items.TNT_MINECART;
               Item var158 = var257;
               if (var158 == var159) {
                  ItemStack var27 = var13;
                  var11 += var27.getCount();
               }

               label197: {
                  label214: {
                     int var161 = var6;
                     int var160 = var12;
                     int var80 = var160;
                     int var79 = var160;
                     if (var161 != 0) {
                        byte var163 = 8;
                        int var162 = var79;
                        if (var162 > var163) {
                           break label214;
                        }

                        Set var258 = l;
                        ItemStack var29 = var13;
                        Item var31 = var29.getItem();
                        Set var30 = var258;
                        byte var164 = ((byte)((var30.contains(var31)) ? 1 : 0));
                        var80 = var164;
                     }

                     label190: {
                        int var166 = var6;
                        int var165 = var80;
                        int var82 = var165;
                        int var81 = var165;
                        if (var166 != 0) {
                           int var167 = var81;
                           if (var167 == 0) {
                              break label190;
                           }

                           var82 = 1;
                        }

                        var7 = var82;
                     }

                     ItemStack var88;
                     label215: {
                        ItemStack var34 = var13;
                        Item var259 = var34.getItem();
                        int var170 = var6;
                        Item var169 = Items.BOW;
                        Item var168 = var259;
                        Item var86 = var168;
                        Item var87 = var169;
                        Item var83 = var168;
                        Item var84 = var169;
                        if (var170 != 0) {
                           Item var172 = var84;
                           Item var171 = var83;
                           if (var171 == var172) {
                              var8 = 1;
                           }

                           int var174 = var6;
                           ItemStack var173 = var13;
                           var88 = var173;
                           ItemStack var85 = var173;
                           if (var174 == 0) {
                              break label215;
                           }

                           ItemStack var36 = var85;
                           Item var260 = var36.getItem();
                           Item var176 = Items.CROSSBOW;
                           Item var175 = var260;
                           var86 = var175;
                           var87 = var176;
                        }

                        Item var178 = var87;
                        Item var177 = var86;
                        if (var177 != var178) {
                           break label214;
                        }

                        var10 = 1;
                        int var179 = var6;
                        if (var179 == 0) {
                           break label197;
                        }

                        ItemStack var180 = var13;
                        var88 = var180;
                     }

                     ItemStack var39 = var88;
                     boolean var181 = CrossbowItem.isCharged(var39);
                     if (var181) {
                        var9 = 1;
                     }
                  }

                  var12++;
               }

               int var182 = var6;
               if (var182 != 0) {
                  continue;
               }
            }

            MinecraftClient var40 = b;
            ClientPlayerEntity var41 = var40.player;
            var89 = var41.getOffHandStack();
            break;
         }

         ItemStack var255 = var89;
         int var183 = var6;
         if (var183 != 0) {
            ItemStack var42 = var255;
            Item var261 = var42.getItem();
            Item var185 = Items.TNT_MINECART;
            Item var184 = var261;
            if (var184 == var185) {
               ItemStack var44 = var255;
               var11 += var44.getCount();
            }

            this.v = var11;
         }

         byte var94;
         label166: {
            byte var93;
            int var187 = var6;
            byte var186 = var8;
            var93 = var186;
            byte var90 = var186;
            label165:
            if (var187 != 0) {
               byte var188 = var90;
               if (var188 == 0) {
                  int var190 = var6;
                  byte var189 = var9;
                  var93 = var189;
                  byte var91 = var189;
                  if (var190 == 0) {
                     break label165;
                  }

                  byte var191 = var91;
                  byte var92 = var191;
                  byte var192 = var92;
                  if (var192 == 0) {
                     var94 = 0;
                     break label166;
                  }
               }

               var93 = 1;
            }

            byte var193 = var93;
            var94 = var193;
         }

         CartHelperWidget var114;
         int var115;
         byte var256;
         label156: {
            CartHelperWidget var111;
            int var112;
            label155: {
               CartHelperWidget var113;
               label217: {
                  var256 = var94;
                  int var196 = var6;
                  int var195 = var7;
                  CartHelperWidget var194 = this;
                  CartHelperWidget var99 = var194;
                  int var100 = var195;
                  CartHelperWidget var95 = var194;
                  int var96 = var195;
                  if (var196 != 0) {
                     int var198 = var96;
                     CartHelperWidget var197 = var95;
                     var113 = var197;
                     CartHelperWidget var97 = var197;
                     if (var198 == 0) {
                        break label217;
                     }

                     CartHelperWidget var199 = var97;
                     CartHelperWidget var98 = var199;
                     var100 = var11;
                     var99 = var98;
                  }

                  int var202 = var6;
                  int var201 = var100;
                  CartHelperWidget var200 = var99;
                  CartHelperWidget var105 = var200;
                  int var106 = var201;
                  CartHelperWidget var101 = var200;
                  int var102 = var201;
                  if (var202 != 0) {
                     int var204 = var102;
                     CartHelperWidget var203 = var101;
                     var113 = var203;
                     CartHelperWidget var103 = var203;
                     if (var204 <= 0) {
                        break label217;
                     }

                     CartHelperWidget var205 = var103;
                     CartHelperWidget var104 = var205;
                     var106 = var256;
                     var105 = var104;
                  }

                  int var208 = var6;
                  int var207 = var106;
                  CartHelperWidget var206 = var105;
                  var111 = var206;
                  var112 = var207;
                  CartHelperWidget var107 = var206;
                  int var108 = var207;
                  if (var208 == 0) {
                     break label155;
                  }

                  int var210 = var108;
                  CartHelperWidget var209 = var107;
                  var113 = var209;
                  CartHelperWidget var109 = var209;
                  if (var210 != 0) {
                     CartHelperWidget var211 = var109;
                     CartHelperWidget var110 = var211;
                     var112 = 1;
                     var111 = var110;
                     break label155;
                  }
               }

               var115 = 0;
               var114 = var113;
               break label156;
            }

            int var213 = var112;
            CartHelperWidget var212 = var111;
            var114 = var212;
            var115 = var213;
         }

         CartHelperWidget var132;
         String var133;
         label218: {
            var114.s = dev.prestige.recovery.SourceSupport.asBoolean(var115);
            int var216 = var6;
            int var215 = var7;
            CartHelperWidget var214 = this;
            CartHelperWidget var121 = var214;
            int var122 = var215;
            CartHelperWidget var116 = var214;
            int var117 = var215;
            if (var216 != 0) {
               int var218 = var117;
               CartHelperWidget var217 = var116;
               CartHelperWidget var120 = var217;
               CartHelperWidget var118 = var217;
               if (var218 == 0) {
                  CartHelperWidget var219 = var118;
                  CartHelperWidget var119 = var219;
                  String var221 = "No Rail";
                  CartHelperWidget var220 = var119;
                  var132 = var220;
                  var133 = var221;
                  break label218;
               }

               var122 = var11;
               var121 = var120;
            }

            int var224 = var6;
            int var223 = var122;
            CartHelperWidget var222 = var121;
            CartHelperWidget var128 = var222;
            int var129 = var223;
            CartHelperWidget var123 = var222;
            int var124 = var223;
            if (var224 != 0) {
               int var226 = var124;
               CartHelperWidget var225 = var123;
               CartHelperWidget var127 = var225;
               CartHelperWidget var125 = var225;
               if (var226 == 0) {
                  CartHelperWidget var227 = var125;
                  CartHelperWidget var126 = var227;
                  String var229 = "No Carts";
                  CartHelperWidget var228 = var126;
                  var132 = var228;
                  var133 = var229;
                  break label218;
               }

               var129 = var256;
               var128 = var127;
            }

            int var231 = var129;
            CartHelperWidget var230 = var128;
            CartHelperWidget var131 = var230;
            CartHelperWidget var130 = var230;
            if (var231 == 0) {
               String var233 = "No Weapon";
               CartHelperWidget var232 = var130;
               var132 = var232;
               var133 = var233;
            } else {
               var133 = "Ready";
               var132 = var131;
            }
         }

         byte var137;
         var132.r = var133;
         MinecraftClient var56 = b;
         ClientPlayerEntity var57 = var56.player;
         byte var262 = ((byte)((var57.isUsingItem()) ? 1 : 0));
         int var235 = var6;
         byte var234 = var262;
         var137 = var234;
         byte var134 = var234;
         label127:
         if (var235 != 0) {
            byte var236 = var134;
            if (var236 != 0) {
               MinecraftClient var59 = b;
               ClientPlayerEntity var60 = var59.player;
               ItemStack var61 = var60.getActiveItem();
               var262 = ((byte)((var61.getItem() instanceof CrossbowItem) ? 1 : 0));
               int var238 = var6;
               byte var237 = var262;
               var137 = var237;
               byte var135 = var237;
               if (var238 == 0) {
                  break label127;
               }

               byte var239 = var135;
               byte var136 = var239;
               byte var240 = var136;
               if (var240 != 0) {
                  MinecraftClient var64 = b;
                  ClientPlayerEntity var65 = var64.player;
                  ItemStack var14 = var65.getActiveItem();
                  var262 = 1;
                  MinecraftClient var66 = b;
                  ClientPlayerEntity var68 = var66.player;
                  ItemStack var67 = var14;
                  int var70 = CrossbowItem.getPullTime(var67, (LivingEntity)var68);
                  int var15 = Math.max(1, var70);
                  this.t = 2;
                  MinecraftClient var71 = b;
                  ClientPlayerEntity var72 = var71.player;
                  float var10002 = var72.getItemUseTime();
                  Object[] var73 = new Object[]{105570054506037L};
                  float var75 = (var10002 + GameRenderUtil.aReturningFloat(var73)) / var15;
                  float var74 = 1.0F;
                  this.u = Math.min(var74, var75);
                  int var241 = var6;
                  if (var241 != 0) {
                     return;
                  }
               }
            }

            byte var242 = var9;
            var137 = var242;
         }

         byte var243 = var137;
         if (var243 != 0) {
            this.t = 3;
            this.u = 1.0F;
            int var244 = var6;
            if (var244 != 0) {
               return;
            }
         }

         CartHelperWidget var147;
         byte var148;
         label113: {
            int var247 = var6;
            byte var246 = var10;
            CartHelperWidget var245 = this;
            CartHelperWidget var144 = var245;
            byte var145 = var246;
            CartHelperWidget var138 = var245;
            byte var139 = var246;
            if (var247 != 0) {
               byte var249 = var139;
               CartHelperWidget var248 = var138;
               CartHelperWidget var140 = var248;
               byte var141 = var249;
               byte var251 = var141;
               CartHelperWidget var250 = var140;
               CartHelperWidget var146 = var250;
               CartHelperWidget var142 = var250;
               if (var251 == 0) {
                  var148 = 0;
                  var147 = var146;
                  break label113;
               }

               CartHelperWidget var252 = var142;
               CartHelperWidget var143 = var252;
               var145 = 1;
               var144 = var143;
            }

            byte var254 = var145;
            CartHelperWidget var253 = var144;
            var147 = var253;
            var148 = var254;
         }

         var147.t = var148;
         this.u = 0.0F;
      }
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var2;
      long var3;
      Matrix4f var5;
      RenderContext var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var25;
      long var27;
      long var29;
      long var31;
      int var33;
      String var34;
      float var35;
      float var36;
      float var37;
      float var38;
      byte var219;
      label215: {
         label214: {
            var2 = (MeshBufferManager)var1[0];
            var6 = (RenderContext)var1[1];
            var5 = (Matrix4f)var1[2];
            var3 = (Long)var1[3];
            var7 = var3 ^ 48887442607471L;
            var9 = var3 ^ 36477842301344L;
            var11 = var3 ^ 13608202459885L;
            var13 = var3 ^ 29307267718371L;
            var15 = var3 ^ 113406911627307L;
            var17 = var3 ^ 61991993207385L;
            var19 = var3 ^ 13896657865640L;
            long var21 = var3 ^ 126098851360132L;
            long var23 = var3 ^ 49928519994039L;
            var25 = var3 ^ 124694493719688L;
            var27 = var3 ^ 81054074941871L;
            var29 = var3 ^ 126879126745269L;
            var31 = var3 ^ 46684315333905L;
            Object[] var75 = new Object[]{var21};
            CartHelperWidget var74 = this;
            var74.r(var75);
            int var10000 = Event.cReturningInt();
            short var10001 = 32029;
            long var10002 = 1404678182439213225L ^ var3;
            var34 = "Cart Helper";
            var33 = var10000;
            MsdfFontManager var359 = Prestige.c;
            Object[] var77 = new Object[]{var11};
            MsdfFontManager var76 = var359;
            MsdfFont var360 = var76.aReturningcx_C0158(var77);
            Object[] var79 = new Object[]{var23};
            MsdfFont var78 = var360;
            var35 = var78.cReturningFloat(var79);
            Object[] var10003 = new Object[]{null, 1.0F};
            var10003[0] = var35;
            Object[] var80 = var10003;
            var36 = UiMetrics.aReturningFloat(var80);
            var10003 = new Object[]{null, 0.9F};
            var10003[0] = var35;
            Object[] var81 = var10003;
            var37 = UiMetrics.aReturningFloat(var81);
            MsdfFontManager var361 = Prestige.c;
            Object[] var83 = new Object[]{var11};
            MsdfFontManager var82 = var361;
            MsdfFont var362 = var82.aReturningcx_C0158(var83);
            Object[] var85 = new Object[]{var34, var27};
            MsdfFont var84 = var362;
            var38 = var84.aReturningFloat(var85);
            int var259 = var33;
            MinecraftClient var258 = b;
            MinecraftClient var218 = var258;
            MinecraftClient var217 = var258;
            if (var259 != 0) {
               MinecraftClient var86 = var217;
               ClientPlayerEntity var260 = var86.player;
               if (var260 == null) {
                  break label214;
               }

               MinecraftClient var261 = b;
               var218 = var261;
            }

            MinecraftClient var89 = var218;
            ClientWorld var262 = var89.world;
            if (var262 != null) {
               var219 = 0;
               break label215;
            }
         }

         byte var263 = 1;
         var219 = var263;
      }

      byte var39 = var219;
      byte var264 = var39;
      String var220;
      if (var264 != 0) {
         short var363 = 2858;
         long var392 = 1447907206672395924L ^ var3;
         String var265 = "Ready";
         var220 = var265;
      } else {
         var220 = this.r;
      }

      String var40;
      byte var225;
      label205: {
         byte var224;
         var40 = var220;
         int var267 = var33;
         byte var266 = var39;
         var224 = var266;
         byte var221 = var266;
         label204:
         if (var267 != 0) {
            byte var268 = var221;
            if (var268 == 0) {
               int var270 = var33;
               byte var269 = ((byte)((this.s) ? 1 : 0));
               var224 = var269;
               byte var222 = var269;
               if (var270 == 0) {
                  break label204;
               }

               byte var271 = var222;
               byte var223 = var271;
               byte var272 = var223;
               if (var272 == 0) {
                  var225 = 0;
                  break label205;
               }
            }

            var224 = 1;
         }

         byte var273 = var224;
         var225 = var273;
      }

      byte var41;
      int var228;
      label195: {
         var41 = var225;
         int var275 = var33;
         byte var274 = var39;
         byte var227 = var274;
         byte var226 = var274;
         if (var275 != 0) {
            byte var276 = var226;
            if (var276 == 0) {
               var228 = this.t;
               break label195;
            }

            var227 = 2;
         }

         byte var277 = var227;
         var228 = var277;
      }

      int var42 = var228;
      byte var278 = var39;
      float var229;
      if (var278 != 0) {
         float var279 = 0.65F;
         var229 = var279;
      } else {
         var229 = this.u;
      }

      float var43;
      int var232;
      label188: {
         var43 = var229;
         int var281 = var33;
         byte var280 = var39;
         byte var231 = var280;
         byte var230 = var280;
         if (var281 != 0) {
            byte var282 = var230;
            if (var282 == 0) {
               var232 = this.v;
               break label188;
            }

            short var364 = 16965;
            long var393 = 3777447679385192984L ^ var3;
            var231 = 24;
         }

         byte var283 = var231;
         var232 = var283;
      }

      int var44;
      String var237;
      label182: {
         var44 = var232;
         int var286 = var33;
         byte var285 = 3;
         int var284 = var42;
         int var235 = var284;
         byte var236 = var285;
         int var233 = var284;
         byte var234 = var285;
         if (var286 != 0) {
            byte var288 = var234;
            int var287 = var233;
            if (var287 == var288) {
               short var367 = 15894;
               long var396 = 3223045601145723817L ^ var3;
               String var289 = "Ready";
               var237 = var289;
               break label182;
            }

            var236 = 1;
            var235 = var42;
         }

         byte var291 = var236;
         int var290 = var235;
         if (var290 == var291) {
            short var365 = 2533;
            long var394 = 4309873143571426396L ^ var3;
            String var292 = "Uncharged";
            var237 = var292;
         } else {
            short var366 = 17729;
            long var395 = 8375479185041219833L ^ var3;
            var237 = "None";
         }
      }

      String var45 = var237;
      int var101 = var44;
      String var46 = String.valueOf(var101);
      float var47 = 5.5F + var38 + 5.5F;
      MsdfFontManager var397 = Prestige.c;
      Object[] var103 = new Object[]{var11};
      MsdfFontManager var102 = var397;
      MsdfFont var398 = var102.aReturningcx_C0158(var103);
      Object[] var105 = new Object[]{var40, var27};
      MsdfFont var104 = var398;
      float var48 = 12.5F + var104.aReturningFloat(var105) * 0.9F + 5.5F;
      byte var295 = 2;
      int var294 = var42;
      float var293 = 18.1F;
      float var239 = var293;
      float var238 = var293;
      float var240;
      float var241;
      if (var294 == var295) {
         float var297 = 30.0F;
         float var296 = var238;
         var240 = var296;
         var241 = var297;
      } else {
         var397 = Prestige.c;
         Object[] var108 = new Object[]{var11};
         MsdfFontManager var107 = var397;
         MsdfFont var400 = var107.aReturningcx_C0158(var108);
         Object[] var110 = new Object[]{var45, var27};
         MsdfFont var109 = var400;
         var241 = var109.aReturningFloat(var110) * 0.9F;
         var240 = var239;
      }

      float var49 = var240 + var241 + 5.5F;
      var397 = Prestige.c;
      Object[] var112 = new Object[]{var11};
      MsdfFontManager var111 = var397;
      MsdfFont var402 = var111.aReturningcx_C0158(var112);
      Object[] var114 = new Object[]{var46, var27};
      MsdfFont var113 = var402;
      float var50 = 18.1F + var113.aReturningFloat(var114) * 0.9F + 5.5F;
      float var116 = var50;
      float var115 = var49;
      float var118 = Math.max(var115, var116);
      float var117 = var48;
      float var120 = Math.max(var117, var118);
      float var119 = var47;
      var47 = Math.max(var119, var120);
      float var51 = var36 + 3.0F + var37 * 3.0F + 3.0F;
      Object[] var122 = new Object[0];
      CartHelperWidget var121 = this;
      byte var52 = ((byte)((var121.cReturningBoolean(var122)) ? 1 : 0));
      Object[] var10004 = new Object[]{null, var51};
      var10004[0] = var47;
      Object[] var124 = var10004;
      CartHelperWidget var123 = this;
      var123.iReturningVoid(var124);
      float var53 = this.e;
      float var54 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var7};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var51;
      var10011[5] = var47;
      var10011[4] = var54;
      var10011[3] = var53;
      var10011[2] = var5;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var125 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var125);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var13};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var51;
      var10011[5] = var47;
      var10011[4] = var54;
      var10011[3] = var53;
      var10011[2] = var5;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var126 = var10011;
      FilledRectangleRenderer.cReturningVoid(var126);
      float var55 = var54 + 3.0F;
      byte var298 = var52;
      float var242;
      if (var298 != 0) {
         float var299 = var53 + var47 - 5.5F - var38;
         var242 = var299;
      } else {
         var242 = var53 + 5.5F;
      }

      float var56 = var242;
      float var57 = var56;
      int var307;
      do {
         String var128 = var34;
         int var301 = var128.length();
         int var300 = var58;
         if (var300 >= var301) {
            break;
         }

         int var130 = var58;
         String var129 = var34;
         char var131 = var129.charAt(var130);
         String var59 = String.valueOf(var131);
         int var303 = var33;
         byte var302 = var52;
         byte var244 = var302;
         byte var243 = var302;
         int var245;
         if (var303 != 0) {
            byte var304 = var243;
            if (var304 != 0) {
               String var133 = var34;
               int var305 = var133.length() - 1 - var58;
               var245 = var305;
            } else {
               var245 = var58;
            }
         } else {
            byte var306 = var244;
            var245 = var306;
         }

         int var60 = var245;
         MsdfFontManager var368 = Prestige.c;
         Object[] var136 = new Object[]{var11};
         MsdfFontManager var135 = var368;
         MsdfFont var369 = var135.aReturningcx_C0158(var136);
         Object[] var137 = new Object[]{var9};
         Color var10005 = ClientUiUtil.dReturningColor(var137);
         short var10006 = 28031;
         long var422 = 2131723283822961979L ^ var3;
         short var423 = 31995;
         long var10008 = 6212166710454416570L ^ var3;
         int var424 = 10 + var60;
         Object[] var10010 = new Object[]{null, null, null, var29};
         var10010[2] = var424;
         var10010[1] = 10;
         var10010[0] = var10005;
         Object[] var138 = var10010;
         Object[] var429 = new Object[]{null, null, null, null, GameRenderUtil.bReturningColor(var138), var31};
         var429[3] = var55;
         var429[2] = var57;
         var429[1] = var59;
         var429[0] = var5;
         Object[] var140 = var429;
         MsdfFont var139 = var369;
         var139.v(var140);
         var397 = Prestige.c;
         Object[] var142 = new Object[]{var11};
         MsdfFontManager var141 = var397;
         MsdfFont var404 = var141.aReturningcx_C0158(var142);
         Object[] var144 = new Object[]{var59, var27};
         MsdfFont var143 = var404;
         var57 += var143.aReturningFloat(var144);
         var58++;
         var307 = var33;
      } while (var307 != 0);

      float var345 = var54 + var36 - 0.5F;
      float var405 = var53 + 5.5F;
      float var411 = var53 + var47 - 5.5F;
      float var419 = var345 + 0.5F;
      Object[] var430 = new Object[]{null, null, null, null, null, UiMetrics.v, var25};
      var430[4] = var419;
      var430[3] = var411;
      var430[2] = var345;
      var430[1] = var405;
      var430[0] = var5;
      Object[] var145 = var430;
      ShapeRenderer.lReturningVoid(var145);
      long var346 = System.currentTimeMillis();
      double var146 = var346 * 0.012;
      double var150 = 170.0 + 85.0 * Math.sin(var146);
      double var148 = 255.0;
      int var61 = (int)Math.min(var148, var150);
      float var62 = var54 + var36 + 3.0F;
      float var63 = var62 + (var37 - var35 * 0.9F) / 2.0F;
      float var64 = var62 + (var37 - 4.0F) / 2.0F;
      byte var308 = var41;
      Color var246;
      if (var308 != 0) {
         Color var309 = i;
         var246 = var309;
      } else {
         Color var153 = j;
         int var407 = var153.getRed();
         Color var154 = j;
         int var412 = var154.getGreen();
         Color var155 = j;
         var246 = new Color(var407, var412, var155.getBlue(), var61);
      }

      label167: {
         Color var65 = var246;
         MsdfFontManager var370 = Prestige.c;
         Object[] var157 = new Object[]{var11};
         MsdfFontManager var156 = var370;
         MsdfFont var371 = var156.aReturningcx_C0158(var157);
         Object[] var159 = new Object[]{var40, var27};
         MsdfFont var158 = var371;
         float var66 = var158.aReturningFloat(var159) * 0.9F;
         byte var310 = var52;
         if (var310 != 0) {
            float var67 = var53 + var47 - 5.5F - 4.0F;
            float var68 = var67 - 3.0F - var66;
            var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var13};
            var10011[8] = 1.5F;
            var10011[7] = var65;
            var10011[6] = 4.0F;
            var10011[5] = 4.0F;
            var10011[4] = var64;
            var10011[3] = var67;
            var10011[2] = var5;
            var10011[1] = var6;
            var10011[0] = var2;
            Object[] var160 = var10011;
            FilledRectangleRenderer.cReturningVoid(var160);
            var370 = Prestige.c;
            Object[] var162 = new Object[]{var11};
            MsdfFontManager var161 = var370;
            MsdfFont var373 = var161.aReturningcx_C0158(var162);
            Object[] var10009 = new Object[]{null, null, null, null, null, UiMetrics.s, var15};
            var10009[4] = 0.9F;
            var10009[3] = var63;
            var10009[2] = var68;
            var10009[1] = var40;
            var10009[0] = var5;
            Object[] var164 = var10009;
            MsdfFont var163 = var373;
            var163.w(var164);
            int var311 = var33;
            if (var311 != 0) {
               break label167;
            }
         }

         float var351 = var53 + 5.5F;
         var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var13};
         var10011[8] = 1.5F;
         var10011[7] = var65;
         var10011[6] = 4.0F;
         var10011[5] = 4.0F;
         var10011[4] = var64;
         var10011[3] = var351;
         var10011[2] = var5;
         var10011[1] = var6;
         var10011[0] = var2;
         Object[] var165 = var10011;
         FilledRectangleRenderer.cReturningVoid(var165);
         var370 = Prestige.c;
         Object[] var167 = new Object[]{var11};
         MsdfFontManager var166 = var370;
         MsdfFont var375 = var166.aReturningcx_C0158(var167);
         var411 = var351 + 4.0F + 3.0F;
         Object[] var431 = new Object[]{null, null, null, null, null, UiMetrics.s, var15};
         var431[4] = 0.9F;
         var431[3] = var63;
         var431[2] = var411;
         var431[1] = var40;
         var431[0] = var5;
         Object[] var169 = var431;
         MsdfFont var168 = var375;
         var168.w(var169);
      }

      Color var251;
      float var352;
      float var354;
      label162: {
         var62 += var37;
         var63 = var62 + (var37 - var35 * 0.9F) / 2.0F;
         var352 = var62 + (var37 - 9.6F) / 2.0F;
         var354 = var62 + (var37 - 3.0F) / 2.0F;
         int var314 = var33;
         byte var313 = 3;
         int var312 = var42;
         int var249 = var312;
         byte var250 = var313;
         int var247 = var312;
         byte var248 = var313;
         if (var314 != 0) {
            byte var316 = var248;
            int var315 = var247;
            if (var315 == var316) {
               Color var317 = i;
               var251 = var317;
               break label162;
            }

            var250 = 1;
            var249 = var42;
         }

         byte var319 = var250;
         int var318 = var249;
         if (var318 == var319) {
            Color var320 = UiMetrics.t;
            var251 = var320;
         } else {
            var251 = UiMetrics.u;
         }
      }

      label219: {
         Color var69 = var251;
         byte var321 = var52;
         if (var321 != 0) {
            label153: {
               float var70;
               label152: {
                  var70 = var53 + var47 - 5.5F - 9.6F;
                  ItemStack var376 = this.w[0];
                  Object[] var425 = new Object[]{null, null, null, null, var5, var17};
                  var425[3] = 0.6F;
                  var425[2] = var352;
                  var425[1] = var70;
                  var425[0] = var376;
                  Object[] var173 = var425;
                  GameRenderUtil.aReturningBoolean(var173);
                  int var322 = var33;
                  if (var322 != 0) {
                     byte var324 = 2;
                     int var323 = var42;
                     if (var323 != var324) {
                        break label152;
                     }

                     float var420 = var70 - 3.0F - 30.0F;
                     Object[] var432 = new Object[]{null, null, null, null, null, null, var19};
                     var432[5] = var43;
                     var432[4] = var354;
                     var432[3] = var420;
                     var432[2] = var5;
                     var432[1] = var6;
                     var432[0] = var2;
                     Object[] var176 = var432;
                     CartHelperWidget var175 = this;
                     var175.s(var176);
                  }

                  int var325 = var33;
                  if (var325 != 0) {
                     break label153;
                  }
               }

               MsdfFontManager var377 = Prestige.c;
               Object[] var179 = new Object[]{var11};
               MsdfFontManager var178 = var377;
               MsdfFont var378 = var178.aReturningcx_C0158(var179);
               Object[] var181 = new Object[]{var45, var27};
               MsdfFont var180 = var378;
               float var71 = var180.aReturningFloat(var181) * 0.9F;
               var377 = Prestige.c;
               Object[] var183 = new Object[]{var11};
               MsdfFontManager var182 = var377;
               MsdfFont var380 = var182.aReturningcx_C0158(var183);
               var411 = var70 - 3.0F - var71;
               Object[] var433 = new Object[]{null, null, null, null, null, var69, var15};
               var433[4] = 0.9F;
               var433[3] = var63;
               var433[2] = var411;
               var433[1] = var45;
               var433[0] = var5;
               Object[] var185 = var433;
               MsdfFont var184 = var380;
               var184.w(var185);
            }

            int var326 = var33;
            if (var326 != 0) {
               break label219;
            }
         }

         float var355;
         label142: {
            var355 = var53 + 5.5F;
            ItemStack var381 = this.w[0];
            Object[] var426 = new Object[]{null, null, null, null, var5, var17};
            var426[3] = 0.6F;
            var426[2] = var352;
            var426[1] = var355;
            var426[0] = var381;
            Object[] var186 = var426;
            GameRenderUtil.aReturningBoolean(var186);
            int var327 = var33;
            if (var327 != 0) {
               byte var329 = 2;
               int var328 = var42;
               if (var328 != var329) {
                  break label142;
               }

               float var421 = var355 + 9.6F + 3.0F;
               Object[] var434 = new Object[]{null, null, null, null, null, null, var19};
               var434[5] = var43;
               var434[4] = var354;
               var434[3] = var421;
               var434[2] = var5;
               var434[1] = var6;
               var434[0] = var2;
               Object[] var189 = var434;
               CartHelperWidget var188 = this;
               var188.s(var189);
            }

            int var330 = var33;
            if (var330 != 0) {
               break label219;
            }
         }

         MsdfFontManager var382 = Prestige.c;
         Object[] var192 = new Object[]{var11};
         MsdfFontManager var191 = var382;
         MsdfFont var383 = var191.aReturningcx_C0158(var192);
         var411 = var355 + 9.6F + 3.0F;
         Object[] var435 = new Object[]{null, null, null, null, null, var69, var15};
         var435[4] = 0.9F;
         var435[3] = var63;
         var435[2] = var411;
         var435[1] = var45;
         var435[0] = var5;
         Object[] var194 = var435;
         MsdfFont var193 = var383;
         var193.w(var194);
      }

      int var256;
      label134: {
         label220: {
            var62 += var37;
            var63 = var62 + (var37 - var35 * 0.9F) / 2.0F;
            var352 = var62 + (var37 - 9.6F) / 2.0F;
            int var332 = var33;
            byte var331 = var39;
            int var253 = var331;
            byte var252 = var331;
            if (var332 != 0) {
               byte var333 = var252;
               if (var333 != 0) {
                  break label220;
               }

               var253 = var44;
            }

            int var335 = var33;
            int var334 = var253;
            int var255 = var334;
            int var254 = var334;
            if (var335 == 0) {
               int var339 = var255;
               var256 = var339;
               break label134;
            }

            short var406 = 24071;
            long var408 = 705758227155998277L ^ var3;
            byte var337 = 8;
            int var336 = var254;
            if (var336 < var337) {
               byte var338 = 1;
               var256 = var338;
               break label134;
            }
         }

         var256 = 0;
      }

      int var356 = var256;
      int var340 = var356;
      Color var257;
      if (var340 != 0) {
         Color var199 = j;
         int var409 = var199.getRed();
         Color var200 = j;
         int var416 = var200.getGreen();
         Color var201 = j;
         Color var341 = new Color(var409, var416, var201.getBlue(), var61);
         var257 = var341;
      } else {
         var257 = UiMetrics.s;
      }

      Color var357 = var257;
      MsdfFontManager var384 = Prestige.c;
      Object[] var204 = new Object[]{var11};
      MsdfFontManager var203 = var384;
      MsdfFont var385 = var203.aReturningcx_C0158(var204);
      Object[] var206 = new Object[]{var46, var27};
      MsdfFont var205 = var385;
      float var72 = var205.aReturningFloat(var206) * 0.9F;
      byte var342 = var52;
      if (var342 != 0) {
         float var73 = var53 + var47 - 5.5F - 9.6F;
         ItemStack var386 = this.w[1];
         Object[] var427 = new Object[]{null, null, null, null, var5, var17};
         var427[3] = 0.6F;
         var427[2] = var352;
         var427[1] = var73;
         var427[0] = var386;
         Object[] var207 = var427;
         GameRenderUtil.aReturningBoolean(var207);
         var384 = Prestige.c;
         Object[] var209 = new Object[]{var11};
         MsdfFontManager var208 = var384;
         MsdfFont var388 = var208.aReturningcx_C0158(var209);
         var411 = var73 - 3.0F - var72;
         Object[] var436 = new Object[]{null, null, null, null, null, var357, var15};
         var436[4] = 0.9F;
         var436[3] = var63;
         var436[2] = var411;
         var436[1] = var46;
         var436[0] = var5;
         Object[] var211 = var436;
         MsdfFont var210 = var388;
         var210.w(var211);
         int var343 = var33;
         if (var343 != 0) {
            return;
         }
      }

      float var358 = var53 + 5.5F;
      ItemStack var389 = this.w[1];
      Object[] var428 = new Object[]{null, null, null, null, var5, var17};
      var428[3] = 0.6F;
      var428[2] = var352;
      var428[1] = var358;
      var428[0] = var389;
      Object[] var212 = var428;
      GameRenderUtil.aReturningBoolean(var212);
      var384 = Prestige.c;
      Object[] var214 = new Object[]{var11};
      MsdfFontManager var213 = var384;
      MsdfFont var391 = var213.aReturningcx_C0158(var214);
      var411 = var358 + 9.6F + 3.0F;
      Object[] var437 = new Object[]{null, null, null, null, null, var357, var15};
      var437[4] = 0.9F;
      var437[3] = var63;
      var437[2] = var411;
      var437[1] = var46;
      var437[0] = var5;
      Object[] var216 = var437;
      MsdfFont var215 = var391;
      var215.w(var216);
   }

   private void s(Object[] var1) {
      MeshBufferManager var2 = (MeshBufferManager)var1[0];
      RenderContext var7 = (RenderContext)var1[1];
      Matrix4f var6 = (Matrix4f)var1[2];
      float var3 = (Float)var1[3];
      float var5 = (Float)var1[4];
      float var4 = (Float)var1[5];
      long var8 = (Long)var1[6];
      var8 = 10251036501468L ^ var8;
      long var10 = var8 ^ 40529340239828L;
      long var12 = var8 ^ 34458278343319L;
      float var15 = 1.5F;
      Color var10007 = k;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
      var10011[8] = var15;
      var10011[7] = var10007;
      var10011[6] = 3.0F;
      var10011[5] = 30.0F;
      var10011[4] = var5;
      var10011[3] = var3;
      var10011[2] = var6;
      var10011[1] = var7;
      var10011[0] = var2;
      Object[] var19 = var10011;
      FilledRectangleRenderer.cReturningVoid(var19);
      int var10000 = Event.bReturningInt();
      float var21 = var4;
      float var20 = 0.0F;
      float var23 = Math.max(var20, var21);
      float var22 = 1.0F;
      float var16 = Math.min(var22, var23);
      float var17 = 30.0F * var16;
      int var14 = var10000;
      int var29 = var14;
      if (var29 == 0) {
         float var39;
         int var30 = (var39 = var17 - 3.0F) == 0.0F ? 0 : (var39 < 0.0F ? -1 : 1);
         if (var30 <= 0) {
            return;
         }

         Object[] var25 = new Object[]{var10};
         var10007 = ClientUiUtil.dReturningColor(var25);
         var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
         var10011[8] = var15;
         var10011[7] = var10007;
         var10011[6] = 3.0F;
         var10011[5] = var17;
         var10011[4] = var5;
         var10011[3] = var3;
         var10011[2] = var6;
         var10011[1] = var7;
         var10011[0] = var2;
         Object[] var26 = var10011;
         FilledRectangleRenderer.cReturningVoid(var26);
      }

      short var10002 = 5760;
      long var10003 = 2597363771056468136L ^ var8;
      short var32 = 5760;
      long var10004 = 2597363771056468136L ^ var8;
      short var34 = 5760;
      long var10005 = 2597363771056468136L ^ var8;
      short var35 = 32338;
      long var10006 = 2544339464437487715L ^ var8;
      Color var18 = new Color(255, 255, 255, 200);
      float var33 = var3 + var17 - 1.5F;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
      var10011[8] = var15;
      var10011[7] = var18;
      var10011[6] = 3.0F;
      var10011[5] = 1.5F;
      var10011[4] = var5;
      var10011[3] = var33;
      var10011[2] = var6;
      var10011[1] = var7;
      var10011[0] = var2;
      Object[] var28 = var10011;
      FilledRectangleRenderer.cReturningVoid(var28);
   }

   static {

      {

      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(32585787711040L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[12];
      String var15 = "\u0006\u0010±¼º]®.¢=Ñ#\u0018½>!ÆB\tï`\u0082\u008b \u00883j\u0010\u0094dê\u0091-8ç¬yî|p\u0010\u009b@DÕJ\u0011!¡ÊÑXf4\u0000\u0090ÝW\u00031È0g¸Ï¶(Jé[É\u0095½Î\u008e\b\\â§\u009bÄ@sª\fñ\u0087ÞÛ¿4ë¾0?hÒ\u001a\u0098_å\u001e¦IR9¹\u008dÐV\u001d»m \u0004QÜªÄCIL\u0005aï\u0019;m«ÿÉ\u0089Ç\u00898\u008b¼hºHè»¶1§\u0002Í\u0016©õ\u0015}Ssñ\fj$Ú|{\u0010©ÙY\\*o\u0083f\u001aÂ ËXzÐJ\u0010å×Ù®Ùä\u0092\b\u000e\u009ekÇXÁ¼\u0018\u0018#u\u001dî/9N\u008eÓÈÀ\u008bÚ!±øý\u0094\"¡p9rM\u0010òR\u008eí\u0092úôòÏ\fª\u00ad\r:0G yà1² \u001bh\u008241Ê\u0003¢Ö\u0099\u0015gNY\u00adà\u000b[ñ÷ù\u001e¹fÏOD\u0018~½Aê\u0001ïñW\u0006Ðy\u0018ºdms\u009cµ¸ì\u000fÖÜf\u00105_$Épõuó\u0095iêmÇøß\u0096\u0018\u0084¤=ç[j°sºN\u001fYP\u0018!xYnò \u001aÄMv";
      int var17 = "\u0006\u0010±¼º]®.¢=Ñ#\u0018½>!ÆB\tï`\u0082\u008b \u00883j\u0010\u0094dê\u0091-8ç¬yî|p\u0010\u009b@DÕJ\u0011!¡ÊÑXf4\u0000\u0090ÝW\u00031È0g¸Ï¶(Jé[É\u0095½Î\u008e\b\\â§\u009bÄ@sª\fñ\u0087ÞÛ¿4ë¾0?hÒ\u001a\u0098_å\u001e¦IR9¹\u008dÐV\u001d»m \u0004QÜªÄCIL\u0005aï\u0019;m«ÿÉ\u0089Ç\u00898\u008b¼hºHè»¶1§\u0002Í\u0016©õ\u0015}Ssñ\fj$Ú|{\u0010©ÙY\\*o\u0083f\u001aÂ ËXzÐJ\u0010å×Ù®Ùä\u0092\b\u000e\u009ekÇXÁ¼\u0018\u0018#u\u001dî/9N\u008eÓÈÀ\u008bÚ!±øý\u0094\"¡p9rM\u0010òR\u008eí\u0092úôòÏ\fª\u00ad\r:0G yà1² \u001bh\u008241Ê\u0003¢Ö\u0099\u0015gNY\u00adà\u000b[ñ÷ù\u001e¹fÏOD\u0018~½Aê\u0001ïñW\u0006Ðy\u0018ºdms\u009cµ¸ì\u000fÖÜf\u00105_$Épõuó\u0095iêmÇøß\u0096\u0018\u0084¤=ç[j°sºN\u001fYP\u0018!xYnò \u001aÄMv"
         .length();
      char var14 = 24;
      int var28 = -1;

      label54:
      while (true) {
         String var29 = var15.substring(++var28, var28 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var29.getBytes("ISO-8859-1"));
            String var40 = b(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var40;
                  if ((var28 += var14) >= var17) {
                     B = var18;
                     C = new String[12];
                     J = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(32585787711040L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[21];
                     String var4 = "0xAYo.\u001c<\u0088\u00adò¬ïd=XA\u0095\u0014\u008ac5\u0090·g\u001boöº\u009b5¾&ò¾Út\u001d@:ìæÐ,&\tj¨\u008eiÑ¯vk\u0004Q\u0015×%\u0017ä\u0006\u001fÕÞA0\u0012#oZäMbñ\u009c¶\u00ad¡¯ÊØøÁ\u0013\u0017H¯k3\u009a\u0089&í¤ÎH9\u000f\u001b\u009b\u0094\u009c\u0081P*YÍM©^¡z\bÍ\u0084+XPfçpM\u0015¹Ûe*nÙT\u0088@\u0007\u0014å\u0082yÿ¡\u009e\u008eh9)Eâ£ºÆ\u0010\u000b";
                     int var5 = "0xAYo.\u001c<\u0088\u00adò¬ïd=XA\u0095\u0014\u008ac5\u0090·g\u001boöº\u009b5¾&ò¾Út\u001d@:ìæÐ,&\tj¨\u008eiÑ¯vk\u0004Q\u0015×%\u0017ä\u0006\u001fÕÞA0\u0012#oZäMbñ\u009c¶\u00ad¡¯ÊØøÁ\u0013\u0017H¯k3\u009a\u0089&í¤ÎH9\u000f\u001b\u009b\u0094\u009c\u0081P*YÍM©^¡z\bÍ\u0084+XPfçpM\u0015¹Ûe*nÙT\u0088@\u0007\u0014å\u0082yÿ¡\u009e\u008eh9)Eâ£ºÆ\u0010\u000b"
                        .length();
                     label36:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var32 = var6;
                        var10001 = var3++;
                        long var44 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        // while (true) {
                           long var8 = var44;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var49 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var47) {
                              case 0:
                                 var32[var10001] = var49;
                                 if (var2 >= var5) {
                                    H = var6;
                                    I = new Integer[21];
                                    p = 2;
                                    q = 3;
                                    a = 8;
                                    i = new Color(80, 220, 120);
                                    j = new Color(235, 64, 64);
                                    k = new Color(255, 255, 255, 30);
                                    Item var25 = Items.ACTIVATOR_RAIL;
                                    Item var24 = Items.DETECTOR_RAIL;
                                    Item var23 = Items.POWERED_RAIL;
                                    Item var22 = Items.RAIL;
                                    l = Set.of(var22, var23, var24, var25);
                                    break;
                                 }
                                 break;
                              default:
                                 var32[var10001] = var49;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "q\u0003¥åÔ:ù\u008e\u008d\u0015)=M¡à>";
                                 var5 = "q\u0003¥åÔ:ù\u008e\u008d\u0015)=M¡à>".length();
                                 var2 = 0;
                           }

                           int var38 = var2;
                           var2 += 8;
                           var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                           var32 = var6;
                           var10001 = var3++;
                           var44 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var47 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var28);
                  break;
               default:
                  var18[var16++] = var40;
                  if ((var28 += var14) < var17) {
                     var14 = var15.charAt(var28);
                     continue label54;
                  }

                  var15 = "%ë\u0013\u0016<\u0016R\u0003û\nmÅ7Å÷X\u009f\u001eûáG°\n_ò\u0003ÑsYm\b\\Aa8\u0019Ìß\u0091®\u0018Å×t\u0086\u001dHµ»\u0016\u0093m·\u00869÷ãã>\u00adã²oMà";
                  var17 = "%ë\u0013\u0016<\u0016R\u0003û\nmÅ7Å÷X\u009f\u001eûáG°\n_ò\u0003ÑsYm\b\\Aa8\u0019Ìß\u0091®\u0018Å×t\u0086\u001dHµ»\u0016\u0093m·\u00869÷ãã>\u00adã²oMà"
                     .length();
                  var14 = '(';
                  var28 = -1;
            }

            var29 = var15.substring(++var28, var28 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 26159;
      if (C[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])D.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b2", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = B[var5].getBytes("ISO-8859-1");
         C[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return C[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b2",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19422;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b2", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b2",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 6;
            yield var15;
         }
         case 1 -> {
            byte var16 = 12;
            yield var16;
         }
         case 2 -> {
            byte var17 = 59;
            yield var17;
         }
         case 3 -> {
            byte var18 = 2;
            yield var18;
         }
         case 4 -> {
            byte var19 = 51;
            yield var19;
         }
         case 5 -> {
            byte var20 = 62;
            yield var20;
         }
         case 6 -> {
            byte var21 = 57;
            yield var21;
         }
         case 7 -> {
            byte var22 = 26;
            yield var22;
         }
         case 8 -> {
            byte var23 = 60;
            yield var23;
         }
         case 9 -> {
            byte var24 = 16;
            yield var24;
         }
         case 10 -> {
            byte var25 = 14;
            yield var25;
         }
         case 11 -> {
            byte var26 = 34;
            yield var26;
         }
         case 12 -> {
            byte var27 = 28;
            yield var27;
         }
         case 13 -> {
            byte var28 = 42;
            yield var28;
         }
         case 14 -> {
            byte var29 = 1;
            yield var29;
         }
         case 15 -> {
            byte var30 = 36;
            yield var30;
         }
         case 16 -> {
            byte var31 = 53;
            yield var31;
         }
         case 17 -> {
            byte var32 = 9;
            yield var32;
         }
         case 18 -> {
            byte var33 = 7;
            yield var33;
         }
         case 19 -> {
            byte var34 = 47;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 35;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 52;
            yield var38;
         }
         case 24 -> {
            byte var39 = 20;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 17;
            yield var42;
         }
         case 28 -> {
            byte var43 = 15;
            yield var43;
         }
         case 29 -> {
            byte var44 = 19;
            yield var44;
         }
         case 30 -> {
            byte var45 = 63;
            yield var45;
         }
         case 31 -> {
            byte var46 = 18;
            yield var46;
         }
         case 32 -> {
            byte var47 = 43;
            yield var47;
         }
         case 33 -> {
            byte var48 = 31;
            yield var48;
         }
         case 34 -> {
            byte var49 = 58;
            yield var49;
         }
         case 35 -> {
            byte var50 = 24;
            yield var50;
         }
         case 36 -> {
            byte var51 = 29;
            yield var51;
         }
         case 37 -> {
            byte var52 = 10;
            yield var52;
         }
         case 38 -> {
            byte var53 = 8;
            yield var53;
         }
         case 39 -> {
            byte var54 = 50;
            yield var54;
         }
         case 40 -> {
            byte var55 = 3;
            yield var55;
         }
         case 41 -> {
            byte var56 = 48;
            yield var56;
         }
         case 42 -> {
            byte var57 = 11;
            yield var57;
         }
         case 43 -> {
            byte var58 = 40;
            yield var58;
         }
         case 44 -> {
            byte var59 = 23;
            yield var59;
         }
         case 45 -> {
            byte var60 = 41;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 45;
            yield var62;
         }
         case 48 -> {
            byte var63 = 38;
            yield var63;
         }
         case 49 -> {
            byte var64 = 39;
            yield var64;
         }
         case 50 -> {
            byte var65 = 44;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 56;
            yield var67;
         }
         case 53 -> {
            byte var68 = 5;
            yield var68;
         }
         case 54 -> {
            byte var69 = 13;
            yield var69;
         }
         case 55 -> {
            byte var70 = 37;
            yield var70;
         }
         case 56 -> {
            byte var71 = 61;
            yield var71;
         }
         case 57 -> {
            byte var72 = 27;
            yield var72;
         }
         case 58 -> {
            byte var73 = 54;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 33;
            yield var75;
         }
         case 61 -> {
            byte var76 = 21;
            yield var76;
         }
         case 62 -> {
            byte var77 = 0;
            yield var77;
         }
         default -> 4;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = ";l?xm*-l:\"~=:'9$r)+`.39;\u001a";
      K[1] = int.class;
      L[1] = "java/lang/Integer";
      K[2] = "\u0014\u0006\u001a\b\u001e\u0004\u0014\u0006\rT\u0012\u000b\u000eM\rJ\u0012\u001e\t<_\u001eC_";
      K[3] = "r/QiQhr/F5]ghdF+]ro\u0015\u0014p\u00053";
      K[4] = "\u0010Cv; F\u0010Cag,I\n\bay,\\\ry0,{\u001f";
      K[5] = "bvW7f0iyFx\u001b(z~O1";
      K[6] = ".E%/@Q.E2sL^4\u000e2mLK3\u007fh2\u001e\f";
      K[7] = "\u0010\u001a'/\bY\u0010\u001a0s\u0004V\nQ0m\u0004C\r j2V\u0001";
      K[8] = "gzrE0Lgze\u0019<C}1e\u0007<Vz@7\\d\u001c";
      K[9] = "\u0002GxoH!\tHi )/\u0002Cmz";
      K[10] = "<9H\b`@*9MRsW=rNT\u007fC,5YC4Rj";
      K[11] = "OH]-c:DGLb\u00007QJC\t55@Y_%\"8";
      K[12] = "mgc \t\u001d{gfz\u001a\nl,e|\u0016\u001e}krk]\fK";
      K[13] = "0Y?\u001cg/Ey4\u0013v`$w?\u0018r:P";
      K[14] = "O>u<TQR+-\u001e\u0015\\J-";
      K[15] = "6qQlBe=~@#!h(x";
      K[16] = float.class;
      L[16] = "java/lang/Float";
      K[17] = "%\rwsS33\rr)@$$Fq/L05\u0001f8\u0007''";
      K[18] = "\u0012\u001b\u000e\u0013M?g;\u0005\u001c\\p\u00065\u000e\u0017X*r";
      K[19] = void.class;
      L[19] = "java/lang/Void";
      K[20] = "f5]t#\u0014x=G;^\u0004x";
      K[21] = "~?\u0007\u0015g\u0006~?\u0010Ik\tdt\u0010Wk\u001cc\u0005D\u000f<";
      K[22] = ":v-LA`:v:\u0010Mo =:\u000eMz'LhU\u001a=";
      K[23] = "\u0011k<hl`\u0011k+4`o\u000b +*`z\fQyu10";
      K[24] = "\u001bO1D\u001a\u007f\u001bO&\u0018\u0016p\u0001\u0004&\u0006\u0016e\u0006ut\\A'";
      K[25] = "VRQ\\6F@RT\u0006%QW\u0019W\u0000)EF^@\u0017bRE";
      K[26] = ".Ik#@\u000e[i`,QA:gk'U\u001bN";
      K[27] = "\u0004\"bteh\u0004\"u(ig\u001eiu6ir\u0019\u0018%k8";
      K[28] = "AfBuY|AfU)Us[-U7Uf\\\\\u0000h\f";
      K[29] = boolean.class;
      L[29] = "java/lang/Boolean";
      K[30] = "(\u001et\u001f/?>\u001eqE<()UrC0<8\u0012eT{-}";
      K[31] = "\u001eM 5\u0004$km+:\u0015k\nc 1\u00111~";
      K[32] = double.class;
      L[32] = "java/lang/Double";
      K[33] = "2\u000e.\"qv9\u0001?m\fc+\u001b=.";
      K[34] = long.class;
      L[34] = "java/lang/Long";
      K[35] = ")V+jOg?V.0\\p(\u001d-6Pd9Z:!\u001bt!Z8*A9\u001dA87A~*V";
      K[36] = "#\u0002\u0001^MR5\u0002\u0004\u0004^E\"I\u0007\u0002RQ3\u000e\u0010\u0015\u0019A=";
      K[37] = "\u0000#\nrN\u0002\u0016#\u000f(]\u0015\u0001h\f.Q\u0001\u0010/\u001b9\u001a\u0011\u001c";
      K[38] = "dopAGi\u0011O{NV&pApER|\u0004";
      K[39] = "3_\u0001 g\u001dF\u007f\n/vR'q\u0001$r\bS";
      K[40] = "BN0\u0007oVTN5]|AC\u00056[pURB!L;BP";
      K[41] = "I|XDr<<\\SKcs]RX@g))";
      K[42] = "51rI}k@\u0011yFl$!\u001frMh~U";
      K[43] = "\u001c,n40\u0015i\fe;!Z\b\u0002n0%\u0000|";
      K[44] = "'?\u0011Z\u0003oR\u001f\u001aU\u0012 3\u0011\u0011^\u0016zG";
      K[45] = "(\u0015\u0010|\u001f\u0010]5\u001bs\u000e_<;\u0010x\n\u0005H";
      K[46] = "GSQ\u0014\u0012U2sZ\u001b\u0003\u001aS}Q\u0010\u0007@'";
      K[47] = "O_\u001b,\u000f=Y_\u001ev\u001c*N\u0014\u001dp\u0010>_S\ng[.@";
      K[48] = "\u007f#\u001b0X`\n\u0003\u0010?I/k\r\u001b4Mu\u001f";
      K[49] = "&+u8iRS\u000b~7x\u001d2\u0005u<|GF";
      K[50] = char.class;
      L[50] = "java/lang/Character";
      K[51] = "\u001eqw\u0015\u000f%kQ|\u001a\u001ej\n_w\u0011\u001a0~";
      K[52] = "y\u0010So\u0016\u0000\f0X`\u0007Om>Sk\u0003\u0015\u0019";
      K[53] = "eJ\"\u001cJ\\sJ'FYKd\u0001$@U_uF3W\u001eO8";
      K[54] = "{Ho'o!\u000ehd(~nofo#z4\u001b";
      K[55] = "_r \u0000JT*R+\u000f[\u001bK\\ \u0004_A?";
      K[56] = "\".u\f\u0007I95`\u0016fM\"\"\u0004EZ\u0014'cf\u001c\r\u0015rR=@ZDz0d\u0017[\u0011Kk8@\n\u0019)2oA_(";
      K[57] = "\bG0BPP\u0017\u001emC3Q\u000b\u00045D_c]Ah\u001f\u00034\u0006G<XXO\u0017\u0016(D3";
      K[58] = "O-N_d\u0014J?T\u0016\u0000\u000b\u00198UJl9J|\u000b\u0010=nO:XSfRL>ZT\u0000U\n)KK<V\u000e+L-;\u0007\u000f6QW>\u0015\u0015\u007f5";
      K[59] = "ak[:*\u0018bvC!E\bz~Y4#\u001f[eF4\u0000\u0002c`B\"E\u0005cjO+=\u000eenIY";
      K[60] = "\u001eL\u0014W\u0003\u0014IFB\\qDy_I\u0000\u000b\u001f\u0015JJ\u0017\u001c";
      K[61] = "Fwh}!\u0017\u0011uu5X\u0006\u001edc!\u000fXF36Mb\u0002F8\u007f5<\u0016\u0019p";
      K[62] = "\u0004\u0007Lg\u000eo\u001f\u001cY}ok\f\u001d=}^6\b\u001fVe\u0010>Q{W&Wk\t\u0010Oh_2m\u0011\f/\nj\u0006\tB'S\u000e";
      K[63] = "67\u0010ZfH&4NK\u001eVO7\u0014V$G,pU\b#XObEKc[u7GP`)";
      K[64] = "\u0007rO%\r7\u001a\u007fM(v+c\"\u000b,L$\u0000eJrK;cwZ1\u000b8Y\"X*\bJ";
      K[65] = "BQA\u0000tK\u001cS_W\n\u000e|\u0018\u001b_0\u001a\u001f_Z\u00017\u0005|MJBw\u0006F\u0018HYtt";
      K[66] = "C\u0014Ao^$@\u0010Ch8|\u0015\fCmX\u0018AV\u0010}\tz\u0018\u0001\u0011(8";
      K[67] = "Pg'p6{K|2jW\u007fX}Veg}Ux3<iqT\u001b300vZ~j><w9~fg;y\\'hk:\u001a";
      K[68] = "c\u0018[\u0013GY=\u0005P\u0015)M`\u000bW\u0017E\u007f2H\u0007I)\u0015i\u001b\u0007\u000eEH6\u0018\u000epJ\u0016v\u0011Z\u0017R\u0011n\u001b7";
      K[69] = "-\u0015n\u001bi\u0007=\u00160\n\u0011\u000fT\u0015j\u0017+\b7R+I,\u0017TFaIt\u0002?^/A-f";
      K[70] = "A6Oz'[\u00164R2^J\u0019%D&\t\u0014Ht\u0010JdNAyX2:Z\u001e1";
      K[71] = "P\u0006\u0013r\"\u0006\u000fFZe\u001d\u0013\f\u0005xpq|XE\u001eq,\u001e\u0001\u0012\u001f$\u001d";
      K[72] = "vU&,D\u0002d\u000e:\"\u007f\u0005\u0016\u0007a6E\u0002u@ hB\u001d\u0016Tjh\u001a\b}L$`Cl";
      K[73] = "(G>@F/5J<M=9L\u0017zI\u0007</P;\u0017\u0000#LM~T[?+UyLQR";
      K[74] = "=\u0017].<`oJI+\u0001e>v\u001e=oa1\u001bL5;\u007fPHJ9bc=\u001aBm|\u0002n\u001cN4`o<\u0014\u001a*\u0001<:\u0018C6ln2L]Wlc-\u000f\u001d5>>9\n ";
      K[75] = "\u0002E&N\u0018c\u001fH$Ccwf\u0015bGYp\u0005R#\u0019^of@3Z\u001el\\\u00151A\u001d\u001e";
      K[76] = "o\u00011\\ia~P%@\u0002\u007fbB8@nM2\u0002c\u0017\u0002#3\u00024\u0016`zd\u0003a'?~c\u000e&Kb!`\u0007X";
      K[77] = ")/a*g.6)?\"\u0017#)=8\u007f@tv`c\u0013tw43ma,52,";
      K[78] = "\u0016\u0014[\u000fNeKKX\u00060lF\fWX\\^\u0016O\f\u0000\u0001\t\u0017\u000e\u000eGT{\u0017\u000fMV07A\u001eT^]eIJJ?\u000ecE\u0013VR\\k\u0011\r7";
      K[79] = ")+I\u0006Qr{v]\u0003l{#,H\u0016\rv?J\n\u0015\u0002s%'X\u001dVmD)\n\u0004\n}#1\r\u001c\u0000\u0010";
      K[80] = "\u0014\u0002pAlY\u000b[-@\u000fX\u0017AuGcjD\u0005*\u0011\u000f\u0000\u001eQ%^c]AR, ";
      K[81] = "D\tTSheB\rRSq\u0015\u00100W\u0010p/\u0013S\u0010Q.(\f0\u0002Amh\u000f\nWCvk}";
      K[82] = "\u0010\u000fX~\ft\u0000\f\u0006ot~i\u000f\\rN{\nH\u001d,Idi\\W,\u0011q\u0002D\u0019$H\u0015";
      K[83] = "\u001ejs\u0018\u001d7A*:\u000f\"\"Bi\r\rO I\u0015{K\u001e!\u001ew\"\u001c\u001ft/";
      K[84] = "\u0003\u0000 ,M%\u001cY}-.$\u0000C%*B\u0016S\u0006|p.\"SD# I:T\\)M";
      K[85] = "<!2_96h?r$7\fjm5Hln3:4\u001d]";
      K[86] = "\u000ec^\u0015\rm\u0015xK\u000flw\u0006y/\u0000\\k\u000b|JYRg\n\u001fJU\u000b`\u0004z\u0013[\u0007ag";
      K[87] = "z7Y\ftV'hZ\u0005\n_*/U[fmxb\r\r\n\u0000-j\u0004Dr^95L<";
      K[88] = "\u0015bW\u0016I\u0001A|\u0017mF;C.P\u0001\u001cY\u001ayQT-";
      K[89] = "<\u0019\u0012>\bpk\u001b\u000fvqad\n\u0019b&?=YL\u000eKe<V\u0005v\u0015qc\u001e";
      K[90] = "oh\\3\u00162en\u001ei,?\u0014n\u001dl\u00165w)\\2\u0011*\u0014;LqQ).nNjR[";
      K[91] = "kpDAr:tv\u001aI\u00027kb\u001d\u0014U`55Exlfon\u001a\u001cs?2o";
      K[92] = "Ho\u0000\u0004>,\u0016m\u001eS@zv/\\Q\"rN'\u000bS9\u0013F#\f_!+Nt\u000eD@";
      K[93] = "V9&?Q2\u0001;;w(#\u000e*-c\u007f}U~p\u000f\u0012'Vv1wL3\t>";
      K[94] = "\u0002*,z\u0011i\u001dsq{rh\u0001i)|\u001eZR-r#r0\byye\u001emWzp\u001b";
      K[95] = "6f\u0006o:u$=\u001aa\u0001rV4Au;u5s\u0000+<jVnEhgv1vBpm\u001b";
      K[96] = "Z82n\fg\r:/&uv\u0002+92\"(Xwl^OrZw%&\u0011f\u0005?";
      K[97] = "M\u0017WW0t\u001f\u0016\u000f\u001fY&}@\\Ac$\u001e\u0007\u001d\u001fd;}H\u0019\u00166u\u0007\u0017Y_!J";
      K[98] = "? HPsO$;]J\u0012K?,9J#\u001638RRm\u001ej\\S\u0011*K27K_\"\u0012V6\b\u0018wJ=.F\u0010..";
      K[99] = "O`~l\u0010=\u0011}uj~)Lsrh\u0012\u001b\u001e0-2~qEc\"q\u0012,\u001a`+\u000f\u0011'\u0018}|eA-\u0018p\u00126BpM>po\u0015q\u0018\u000f";
      K[100] = "\f,Wpl7Sl\u001egS\"P/,{. =jZ#?|_3\r\"jM";
      K[101] = ">y;aY\f+z,vi\tF%g}S\u000e%b&#T\u0011Fed%\u0003\u0018'ug{\u0012`";
      K[102] = "\u0018\u0010|;^tSI+1>~h\u0014+>\u0004y\u000bSj`\u0003fhG `[s\u0003_nh\u0002\u0017";
      K[103] = "pYO&\u0019WpM\u001a\"\"S-LE,u\u0000p\u0018\u0010q\"\u00012\u0018Y$P\u00013[H";
      K[104] = "CH\u0019m\u001az\u001dJ\u0007:d>}\u0001C2^+\u001eF\u0002lY4}T\u0012/\u00197G\u0001\u00104\u001aE";
      K[105] = "\u001e1i7R\u0010\u001d5k04GE&~\u0000H,\u001cs8%\u0005NE$9p4]Z2=,\u000fMI2tI";
      K[106] = ",k<&Zm{i!n#|tx7zt\"+(n\u0016\u0019x,$+nGlsl";
      K[107] = "\u001b\f>|\u000e'L\u000e#4w6C\u001f5  h\u001bJkLM2\u001bC)4\u0013&D\u000b";
      K[108] = "Jab312Ie`4Wp\u0018{r \u0010`q&3q;?\u0013\u007fdpn\u000eJab312Ie`4W";
      K[109] = "8f+'.)'?v&M(;%.!!\u001aharvMtje\"w/-=dwF";
      K[110] = "'_\u007fIV/7\\!X.0^_{E\u0014 =\u0018:\u001b\u0013?^\n*XS<d_(CPN";
      K[111] = "s4B\u0018g\u0001ao^\u0016\\\u0005\u0013f\u0005\u0002f\u0001p!D\\a\u001e\u0013n@U3Pi1\u0000\u001c$o";
      K[112] = "e\u0001@DtpdF\u0012\b\f`\u000e\u0005\u0019\u001c6emBXB1z\u000ePH\u0001qy4\u0005J\u001ar\u000b";
      K[113] = "z\u0002}HKT']~A5]*\u001aq\u001fYoxW-G5\u0001{Z}IWX,[(x";
      K[114] = "\\x+\tq-_|)\u000e\u0017o\u000eb;\u001aP\u007fgw9\n.t\\g*\ng\u0011\\x+\tq-_|)\u000e\u0017";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(641612059637718L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(641612059637718L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(641612059637718L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 236;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 192;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 101;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 195;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 111;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 98;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 236;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 192;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 101;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b2",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b2" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
