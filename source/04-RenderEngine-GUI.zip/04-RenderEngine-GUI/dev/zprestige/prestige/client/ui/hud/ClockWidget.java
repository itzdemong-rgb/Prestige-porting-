package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.setting.SettingDefinition;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.TextStyle;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;

public class ClockWidget extends HudElement {
   private ManagedGlTexture a;
   private static final long v = 121347117689080L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long H;
   private static final Object[] I = new Object[90];
   private static final String[] J = new String[90];

   public ClockWidget(long var1) {
      super("Time", "Show the client's time", ((121347117689080L ^ (121347117689080L ^ var1)) ^ 138401189372564L));
      var1 = 121347117689080L ^ var1;
      long var3 = var1 ^ 138401189372564L;
      short var10001 = 27626;
      long var10002 = 4654163094828317597L ^ var1;
      short var6 = 6692;
      long var10003 = 5461569899920460368L ^ var1;

   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 3.0F;
      var10005[0] = 85.0F;
      Object[] var7 = var10005;
      ClockWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      Matrix4f var2;
      long var3;
      MeshBufferManager var5;
      RenderContext var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var27;
      int var29;
      label62: {
         var5 = (MeshBufferManager)var1[0];
         var6 = (RenderContext)var1[1];
         var2 = (Matrix4f)var1[2];
         var3 = (Long)var1[3];
         var7 = var3 ^ 49928519994039L;
         var9 = var3 ^ 48887442607471L;
         var11 = var3 ^ 124694493719688L;
         var13 = var3 ^ 81054074941871L;
         var15 = var3 ^ 36477842301344L;
         var17 = var3 ^ 13608202459885L;
         var19 = var3 ^ 29307267718371L;
         var21 = var3 ^ 113406911627307L;
         var23 = var3 ^ 17083579563515L;
         long var25 = var3 ^ 56760183293883L;
         var27 = var3 ^ 97348647772693L;
         var29 = Event.bReturningInt();
         int var163 = var29;
         ClockWidget var162 = this;
         ClockWidget var153 = var162;
         ClockWidget var152 = var162;
         if (var163 == 0) {
            ManagedGlTexture var164 = var152.a;
            if (var164 != null) {
               break label62;
            }

            ClockWidget var165 = this;
            var153 = var165;
         }

         short var10001 = 25088;
         long var10002 = 7662418695662994574L ^ var3;
         Object[] var78 = new Object[]{"assets/prestige/icons/hud/clock.png", var25};
         var153.a = TextureLoader.aReturningbT_C0095(var78);
      }

      MsdfFontManager var10000 = Prestige.c;
      Object[] var80 = new Object[]{var17};
      MsdfFontManager var79 = var10000;
      MsdfFont var30 = var79.aReturningcx_C0158(var80);
      short var189 = 7685;
      short var192 = 27346;
      LocalTime var31 = LocalTime.now();
      long var195 = 6307411666460871768L ^ var3;
      Object[] var196 = new Object[1];
      LocalTime var81 = var31;
      int var82 = var81.getHour();
      var196[0] = var82;
      Object[] var84 = var196;
      String var83 = "%02d";
      String var32 = String.format(var83, var84);
      long var193 = 1516325891382655312L ^ var3;
      short var197 = 16481;
      long var10003 = 277537436552144616L ^ var3;
      Object[] var206 = new Object[1];
      LocalTime var85 = var31;
      int var86 = var85.getMinute();
      var206[0] = var86;
      Object[] var88 = var206;
      String var87 = "%02d";
      String var33 = String.format(var87, var88);
      short var198 = 16481;
      var10003 = 277537436552144616L ^ var3;
      Object[] var208 = new Object[1];
      LocalTime var89 = var31;
      int var90 = var89.getSecond();
      var208[0] = var90;
      Object[] var92 = var208;
      String var91 = "%02d";
      String var34 = String.format(var91, var92);
      LocalDate var93 = LocalDate.now();
      DayOfWeek var199 = var93.getDayOfWeek();
      Locale var96 = Locale.ENGLISH;
      TextStyle var95 = TextStyle.FULL;
      DayOfWeek var94 = var199;
      String var35 = var94.getDisplayName(var95, var96);
      String var97 = var35;
      String var200 = var97.substring(0, 1);
      Locale var101 = Locale.ENGLISH;
      String var100 = var200;
      String var201 = var100.toUpperCase(var101);
      String var102 = var35;
      String var209 = var102.substring(1);
      Locale var105 = Locale.ENGLISH;
      String var104 = var209;
      String var36 = var201 + var104.toLowerCase(var105);
      float var37 = 0.0F;
      char var38 = '0';

      float var155;
      while (true) {
         var192 = 2517;
         var195 = 2632333413244382849L ^ var3;
         byte var167 = 57;
         char var166 = var38;
         if (var166 <= var167) {
            char var106 = var38;
            Object[] var108 = new Object[]{String.valueOf(var106), var13};
            MsdfFont var107 = var30;
            float var110 = var107.aReturningFloat(var108);
            float var109 = var37;
            float var190 = Math.max(var109, var110);
            int var169 = var29;
            float var168 = var190;
            var155 = var168;
            float var154 = var168;
            if (var169 != 0) {
               break;
            }

            var37 = var154;
            var38++;
            int var170 = var29;
            if (var170 == 0) {
               continue;
            }
         }

         var155 = var37 * 1.0F;
         break;
      }

      float var185 = var155;
      float var39 = var37 * 0.65F;
      Object[] var112 = new Object[]{":", var13};
      MsdfFont var111 = var30;
      float var40 = var111.aReturningFloat(var112) * 1.0F + 1.6F;
      Object[] var114 = new Object[]{var7};
      MsdfFont var113 = var30;
      float var41 = var113.cReturningFloat(var114);
      float var42 = var41 * 0.65F;
      float var43 = var41 * 1.0F;
      float var44 = var41 * 0.65F;
      float var45 = var185 * 2.0F + var40 + var185 * 2.0F + 3.0F + var39 * 2.0F;
      Object[] var116 = new Object[]{var36, var13};
      MsdfFont var115 = var30;
      float var46 = var115.aReturningFloat(var116) * 0.65F;
      float var118 = var46;
      float var117 = var45;
      float var47 = Math.max(var117, var118);
      float var48 = 7.5F;
      float var49 = 5.5F + var48 + 5.5F;
      float var50 = var49 + 0.5F + 5.5F;
      float var51 = var50 + var47 + 5.5F;
      float var52 = 3.0F + var42 + 1.0F + var43 + 1.0F + 4.0F + 3.0F;
      float var53 = this.e;
      float var54 = this.f;
      Object[] var120 = new Object[0];
      ClockWidget var119 = this;
      boolean var55 = var119.cReturningBoolean(var120);
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var52;
      var10011[5] = var51;
      var10011[4] = var54;
      var10011[3] = var53;
      var10011[2] = var2;
      var10011[1] = var6;
      var10011[0] = var5;
      Object[] var121 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var121);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var19};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var52;
      var10011[5] = var51;
      var10011[4] = var54;
      var10011[3] = var53;
      var10011[2] = var2;
      var10011[1] = var6;
      var10011[0] = var5;
      Object[] var122 = var10011;
      FilledRectangleRenderer.cReturningVoid(var122);
      Object[] var123 = new Object[]{var15};
      Color var56 = ClientUiUtil.dReturningColor(var123);
      boolean var171 = var55;
      float var156;
      if (var171) {
         float var172 = var53 + var51 - 5.5F - var48;
         var156 = var172;
      } else {
         var156 = var53 + 5.5F;
      }

      float var57 = var156;
      boolean var173 = var55;
      float var157;
      if (var173) {
         float var174 = var53 + var51 - var49 - 0.5F;
         var157 = var174;
      } else {
         var157 = var53 + var49;
      }

      float var58 = var157;
      ManagedGlTexture var210 = this.a;
      float var10005 = var54 + var52 / 2.0F - var48 / 2.0F;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, var56, var23};
      var10011[7] = var48;
      var10011[6] = var48;
      var10011[5] = var10005;
      var10011[4] = var57;
      var10011[3] = var210;
      var10011[2] = var2;
      var10011[1] = var6;
      var10011[0] = var5;
      Object[] var126 = var10011;
      TexturedRectangleRenderer.cReturningVoid(var126);
      float var203 = var54 + 3.0F;
      float var211 = var58 + 0.5F;
      float var10004 = var54 + var52 - 3.0F;
      Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var11};
      var10008[4] = var10004;
      var10008[3] = var211;
      var10008[2] = var203;
      var10008[1] = var58;
      var10008[0] = var2;
      Object[] var127 = var10008;
      ShapeRenderer.lReturningVoid(var127);
      float var59 = var54 + 3.0F;
      boolean var175 = var55;
      float var158;
      if (var175) {
         float var176 = var53 + var51 - var50 - var46;
         var158 = var176;
      } else {
         var158 = var53 + var50;
      }

      float var60 = var158;
      Object[] var10009 = new Object[]{null, null, null, null, null, var56, var21};
      var10009[4] = 0.65F;
      var10009[3] = var59;
      var10009[2] = var60;
      var10009[1] = var36;
      var10009[0] = var2;
      Object[] var130 = var10009;
      MsdfFont var129 = var30;
      var129.w(var130);
      float var61 = var59 + var42 + 1.0F;
      float var62 = var61 + (var43 - var44) - 0.5F;
      boolean var177 = var55;
      float var159;
      if (var177) {
         float var178 = var53 + var51 - var50 - var45;
         var159 = var178;
      } else {
         var159 = var53 + var50;
      }

      float var63 = var159;
      float var64 = (float)(System.currentTimeMillis() % H) / 1000.0F;
      double var132 = var64 * (float) (Math.PI * 2);
      float var65 = 0.5F + 0.5F * (float)Math.sin(var132);
      short var204 = 2390;
      var10003 = 4830217019885334016L ^ var3;
      short var213 = 25001;
      long var216 = 2037115776540559096L ^ var3;
      short var217 = 25001;
      long var223 = 2037115776540559096L ^ var3;
      short var224 = 20160;
      long var10006 = 1731556502259820944L ^ var3;
      Color var66 = new Color(255, 255, 255, 70 + (int)(170.0F * var65));
      float var67 = var63;
      var10004 = var185 * 2.0F;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, UiMetrics.s, var27};
      var10010[6] = 1.0F;
      var10010[5] = var61;
      var10010[4] = var10004;
      var10010[3] = var67;
      var10010[2] = var32;
      var10010[1] = var2;
      var10010[0] = var30;
      Object[] var134 = var10010;
      r(var134);
      var67 += var185 * 2.0F;
      var10010 = new Object[]{null, null, null, null, null, null, null, var66, var27};
      var10010[6] = 1.0F;
      var10010[5] = var61;
      var10010[4] = var40;
      var10010[3] = var67;
      var10010[2] = ":";
      var10010[1] = var2;
      var10010[0] = var30;
      Object[] var135 = var10010;
      r(var135);
      var67 += var40;
      var10004 = var185 * 2.0F;
      var10010 = new Object[]{null, null, null, null, null, null, null, UiMetrics.s, var27};
      var10010[6] = 1.0F;
      var10010[5] = var61;
      var10010[4] = var10004;
      var10010[3] = var67;
      var10010[2] = var33;
      var10010[1] = var2;
      var10010[0] = var30;
      Object[] var136 = var10010;
      r(var136);
      var67 += var185 * 2.0F + 3.0F;
      var10004 = var39 * 2.0F;
      var10010 = new Object[]{null, null, null, null, null, null, null, UiMetrics.u, var27};
      var10010[6] = 0.65F;
      var10010[5] = var62;
      var10010[4] = var10004;
      var10010[3] = var67;
      var10010[2] = var34;
      var10010[1] = var2;
      var10010[0] = var30;
      Object[] var137 = var10010;
      r(var137);
      float var68 = var61 + var43 + 1.0F;
      float var69 = var68;
      float var70 = var68 + 1.5F;
      boolean var179 = var55;
      float var160;
      if (var179) {
         float var180 = var53 + 5.5F;
         var160 = var180;
      } else {
         var160 = var53 + var50;
      }

      float var71 = var160;
      boolean var181 = var55;
      float var161;
      if (var181) {
         float var182 = var53 + var51 - var50;
         var161 = var182;
      } else {
         var161 = var53 + var51 - 5.5F;
      }

      float var72 = var161;
      var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var11};
      var10008[4] = var70;
      var10008[3] = var72;
      var10008[2] = var69;
      var10008[1] = var71;
      var10008[0] = var2;
      Object[] var140 = var10008;
      ShapeRenderer.lReturningVoid(var140);
      LocalTime var141 = var31;
      float var191 = var141.getSecond();
      LocalTime var142 = var31;
      float var73 = (var191 + var142.getNano() / 1.0E9F) / 60.0F;
      double var143 = System.currentTimeMillis() * 0.0031415926535897933;
      float var74 = (float)(Math.sin(var143) * 0.5 + 0.5);
      Color var145 = var56;
      int var205 = var145.getRed();
      Color var146 = var56;
      int var214 = var146.getGreen();
      Color var147 = var56;
      int var221 = var147.getBlue();
      short var225 = 6249;
      var10006 = 438429834989223742L ^ var3;
      Color var75 = new Color(var205, var214, var221, 150 + (int)(70.0F * var74));
      float var215 = var71 + (var72 - var71) * var73;
      var10008 = new Object[]{null, null, null, null, null, var75, var11};
      var10008[4] = var70;
      var10008[3] = var215;
      var10008[2] = var69;
      var10008[1] = var71;
      var10008[0] = var2;
      Object[] var148 = var10008;
      ShapeRenderer.lReturningVoid(var148);
      Object[] var222 = new Object[]{null, var52};
      var222[0] = var51;
      Object[] var150 = var222;
      ClockWidget var149 = this;
      var149.iReturningVoid(var150);
      int var183 = SettingDefinition.cReturningInt();
      if (var183 == 0) {
         int var151 = ++var29;
         Event.bReturningVoid(var151);
      }
   }

   private static void r(Object[] var0) {
      MsdfFont var6 = (MsdfFont)var0[0];
      Matrix4f var7 = (Matrix4f)var0[1];
      String var5 = (String)var0[2];
      float var10 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var2 = (Float)var0[5];
      float var3 = (Float)var0[6];
      Color var4 = (Color)var0[7];
      long var8 = (Long)var0[8];
      var8 = 121347117689080L ^ var8;
      long var11 = var8 ^ 140064035306306L;
      long var13 = var8 ^ 90093228853958L;
      Object[] var17 = new Object[]{var5, var11};
      MsdfFont var16 = var6;
      float var15 = var16.aReturningFloat(var17) * var3;
      float var10003 = var10 + (var1 - var15) / 2.0F;
      Object[] var10009 = new Object[]{null, null, null, null, null, var4, var13};
      var10009[4] = var3;
      var10009[3] = var2;
      var10009[2] = var10003;
      var10009[1] = var5;
      var10009[0] = var7;
      Object[] var19 = var10009;
      MsdfFont var18 = var6;
      var18.w(var19);
   }

   static {

      {

      b();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(120192534414146L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[5];
      String var22 = "äÎ\u008d!q\u0081- ä×á\u0082¤êû\u0004\u0010o¼l\u0094\n³Ò(\u00817<ö¾\u001cÎ0(\u0098L~_Ò\u0007\u001d9<öR\u0083¾<Z\u0087\u0087%\u0003Ð\u000eq\u0089hLb\u0013\u0091öÅE²\u0087|t\u0089Õypq";
      int var24 = "äÎ\u008d!q\u0081- ä×á\u0082¤êû\u0004\u0010o¼l\u0094\n³Ò(\u00817<ö¾\u001cÎ0(\u0098L~_Ò\u0007\u001d9<öR\u0083¾<Z\u0087\u0087%\u0003Ð\u000eq\u0089hLb\u0013\u0091öÅE²\u0087|t\u0089Õypq"
         .length();
      char var21 = 16;
      int var29 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var29, var29 + var21);
         int var10001 = -1;

         while (true) {
            byte[] var26 = var18.doFinal(var30.getBytes("ISO-8859-1"));
            String var44 = b(var26).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var44;
                  if ((var29 += var21) >= var24) {
                     w = var25;
                     x = new String[5];
                     D = new HashMap(13);
                     Cipher var5;
                     var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(120192534414146L << var6 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[6];
                     String var9 = "þ}]\u0019\n\u0001\u009cÝ¡±\u000eÙ\u00ad\u0001 ¯\u0018\tÝ¿q¥=ÿs\u008aí\u001feÀøÏ";
                     int var10 = "þ}]\u0019\n\u0001\u009cÝ¡±\u000eÙ\u00ad\u0001 ¯\u0018\tÝ¿q¥=ÿs\u008aí\u001feÀøÏ".length();
                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var48 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        // while (true) {
                           long var13 = var48;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var56 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var33[var10001] = var56;
                                 if (var7 >= var10) {
                                    B = var11;
                                    C = new Integer[6];
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(120192534414146L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long var41 = 1996379163307440311L;
                                    byte[] var4 = var0.doFinal(
                                       new byte[]{
                                          (byte)27L,
                                          (byte)7092L,
                                          (byte)1815696L,
                                          (byte)464818245L,
                                          (byte)118993470865L,
                                          (byte)30462328541678L,
                                          (byte)7798356106669688L,
                                          (byte)1996379163307440311L
                                       }
                                    );
                                    long var51 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    // H = var51;
                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var56;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "f\"h\u0086];\u0091\u00143\u000eY\rô\u0099\u001eC";
                                 var10 = "f\"h\u0086];\u0091\u00143\u000eY\rô\u0099\u001eC".length();
                                 var7 = 0;
                           }

                           int var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var48 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var29);
                  break;
               default:
                  var25[var23++] = var44;
                  if ((var29 += var21) < var24) {
                     var21 = var22.charAt(var29);
                     continue label64;
                  }

                  var22 = "0RÍ_1\u0005\u0004\u0090?3±\u0099¼öo2@Ä\u0014JÚ¼TÓ\u0084¦ùµåG;«°¾¶ó\u001fT®\u0010V\u009d?r\u001ao\u0001ý\u0086\u0093Â:»õ6Ä±L¢m®ö¹4æy}Ç?\fëÏ.¬£~Ç`\u0007AQ";
                  var24 = "0RÍ_1\u0005\u0004\u0090?3±\u0099¼öo2@Ä\u0014JÚ¼TÓ\u0084¦ùµåG;«°¾¶ó\u001fT®\u0010V\u009d?r\u001ao\u0001ý\u0086\u0093Â:»õ6Ä±L¢m®ö¹4æy}Ç?\fëÏ.¬£~Ç`\u0007AQ"
                     .length();
                  var21 = 16;
                  var29 = -1;
            }

            var30 = var22.substring(++var29, var29 + var21);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 9496;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ce", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ce_C0120",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ce" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25799;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ce", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ce_C0120",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ce" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = J[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = I[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 16;
            yield var15;
         }
         case 1 -> {
            byte var16 = 38;
            yield var16;
         }
         case 2 -> {
            byte var17 = 13;
            yield var17;
         }
         case 3 -> {
            byte var18 = 36;
            yield var18;
         }
         case 4 -> {
            byte var19 = 4;
            yield var19;
         }
         case 5 -> {
            byte var20 = 25;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 5;
            yield var22;
         }
         case 8 -> {
            byte var23 = 43;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 20;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 54;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 29;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 0;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 42;
            yield var34;
         }
         case 20 -> {
            byte var35 = 50;
            yield var35;
         }
         case 21 -> {
            byte var36 = 35;
            yield var36;
         }
         case 22 -> {
            byte var37 = 1;
            yield var37;
         }
         case 23 -> {
            byte var38 = 57;
            yield var38;
         }
         case 24 -> {
            byte var39 = 33;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 61;
            yield var41;
         }
         case 27 -> {
            byte var42 = 58;
            yield var42;
         }
         case 28 -> {
            byte var43 = 3;
            yield var43;
         }
         case 29 -> {
            byte var44 = 15;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 48;
            yield var46;
         }
         case 32 -> {
            byte var47 = 37;
            yield var47;
         }
         case 33 -> {
            byte var48 = 51;
            yield var48;
         }
         case 34 -> {
            byte var49 = 45;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 21;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 24;
            yield var54;
         }
         case 40 -> {
            byte var55 = 30;
            yield var55;
         }
         case 41 -> {
            byte var56 = 2;
            yield var56;
         }
         case 42 -> {
            byte var57 = 34;
            yield var57;
         }
         case 43 -> {
            byte var58 = 27;
            yield var58;
         }
         case 44 -> {
            byte var59 = 22;
            yield var59;
         }
         case 45 -> {
            byte var60 = 39;
            yield var60;
         }
         case 46 -> {
            byte var61 = 9;
            yield var61;
         }
         case 47 -> {
            byte var62 = 23;
            yield var62;
         }
         case 48 -> {
            byte var63 = 7;
            yield var63;
         }
         case 49 -> {
            byte var64 = 41;
            yield var64;
         }
         case 50 -> {
            byte var65 = 49;
            yield var65;
         }
         case 51 -> {
            byte var66 = 28;
            yield var66;
         }
         case 52 -> {
            byte var67 = 14;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 31;
            yield var69;
         }
         case 55 -> {
            byte var70 = 17;
            yield var70;
         }
         case 56 -> {
            byte var71 = 44;
            yield var71;
         }
         case 57 -> {
            byte var72 = 19;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 10;
            yield var74;
         }
         case 60 -> {
            byte var75 = 32;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 18;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            J[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      I[0] = "_APw%VIAU-6A^\nV+:UOMA<qEC";
      I[1] = "\u0013QL aVfqG/p\u0019\u0007\u007fL$tCs";
      I[2] = void.class;
      J[2] = "java/lang/Void";
      I[3] = "Z\u0001l\n0\u0019/!g\u0005!VN/l\u000e%\f:";
      I[4] = float.class;
      J[4] = "java/lang/Float";
      I[5] = "\bG7:{f\u001eG2`hq\t\f1fde\u0018K&q/t]";
      I[6] = "^;>xww+\u001b5wf8J\u0015>|bb>";
      I[7] = "(; \u0003mY>;%Y~N)p&_rZ871H9H\t";
      I[8] = int.class;
      J[8] = "java/lang/Integer";
      I[9] = "!5\u00142D\u0014*:\u0005}'\u0019?<";
      I[10] = double.class;
      J[10] = "java/lang/Double";
      I[11] = "<\t\u0015F}\u001e?\u0005\u0006\t\u0017\u000b/'\u0005p6\u000f=";
      I[12] = "YZsV)1ZV`\u0019a*AVdC)\u0011VCqds<_^";
      I[13] = "}3l0adc;v\u007f\u0003~t3v4";
      I[14] = "@L\u0018%QcKC\tj,{XD\u0000#";
      I[15] = "\u0004+\u0018#nJ\u000f$\tl\u0013_\u001d>\u000b/";
      I[16] = long.class;
      J[16] = "java/lang/Long";
      I[17] = "b4]\u0015$#t4XO74c\u007f[I; r8L^p0j8NU*}V#NH*:a4";
      I[18] = "3\u0013pE3\"%\u0013u\u001f 52Xv\u0019,!#\u001fa\u000eg1-";
      I[19] = "\u001e1\u001b02\u0012\u001d=\b\u007fP\t\u00171\u0001\u0005u\u000b\u0011";
      I[20] = "z}E5L\u000f\u000f]N:]@nSE1Y\u001a\u001a";
      I[21] = "iy; _E\u007fy>zLRh2=|@Fyu*k\u000bQ{";
      I[22] = "PP\b?'@%p\u000306\u000fD~\b;2U0";
      I[23] = "?vQ\u0014\u001f=JVZ\u001b\u000er+XQ\u0010\n(_";
      I[24] = " ievD\"#ev9&9)i\u007fS\u000b\"/";
      I[25] = "D#,\u000bJOY6t)\u000bBA0";
      I[26] = "kl^\rT\u007f}l[WGhj'XQK|{`OF\u0000lj";
      I[27] = "\u0003\u0012\u0016u3,\b\u001d\u0007:P!\u001d\u0010\bQe#\f\u0003\u0014}r.";
      I[28] = "[!g\u001ctEP.vS\u0013GE%v\u0018(";
      I[29] = "\u0015\u00132kb\u0002`39dsM\u0001=2ow\u0017u";
      I[30] = "U\t/rt,C\t*(g;TB).k/E\u0005>9 =s";
      I[31] = "#oR!F\fVOY.WC7AR%S\u0019C";
      I[32] = "2uz],WGUqR=\u0018&[zY9BR";
      I[33] = "X~\f\bK0-^\u0007\u0007Z\u007fLP\f\f^%8";
      I[34] = boolean.class;
      J[34] = "java/lang/Boolean";
      I[35] = ";~r[%d-~w\u00016s:5t\u0007:g+rc\u0010qp7";
      I[36] = "rGU{\"\u001f\u0007g^t3PfiU\u007f7\n\u0012";
      I[37] = "`\u0012\u001amahv\u0012\u001f7r\u007faY\u001c1~kp\u001e\u000b&5zP";
      I[38] = "*oC\u0003\b~<oFY\u001bi+$E_\u0017}:cRH\\j)";
      I[39] = "RZ\u0005)0\u0017'z\u000e&!XFt\u0005-%\u00022";
      I[40] = "\u00109P(0\u0018\u00069Ur#\u000f\u0011rVt/\u001b\u00005Acd\f\u0012";
      I[41] = "AVI\u0018 _4vB\u00171\u0010UxI\u001c5J!";
      I[42] = ",<9py\u0010:<<*j\u0007-w?,f\u0013<0(;-\u0003q";
      I[43] = "(\u0003_/U\u0014]#T D[<-_+@\u0001H";
      I[44] = "!t7oM\\TT<`\\\u00135Z7kXIA";
      I[45] = char.class;
      J[45] = "java/lang/Character";
      I[46] = "\u0006\u0012bKJj\u0010\u0012g\u0011Y}\u0007Yd\u0017Ui\u0016\u001es\u0000\u001e~$";
      I[47] = "Eo!0twN`0\u007f\u0015yEk4%";
      I[48] = "HB\u0013\u0007ZiOG\u000fU1yt\u0002F\bM|\u0019@\u0013ZA\u0013";
      I[49] = "I&\u0000\u0016iUK0TE\u0002B\u0016'>KnE\nxX\u0015iXFA\u0001\u0018~DN'_\u001fc\bw";
      I[50] = "<t\u00118u\"91\u001ea\rwnp=;v`ge\u0000\u001cd}n\fA=|'ia\u000ecbg\u0003=\u001c<tiem\u00160g\u00182rH+gie<\n9\r";
      I[51] = "\u0001.QN\u007f2U3BB\u0011i\u0015&TRw~4=KRTc\f8OD\u0011h\r6\u001eYre\u000e9G?";
      I[52] = "B\u0016h\r,~\u0015X*\u001fFs\u0014,6\u0003+u8\u0001*\u0011F>\u001e\u000e(\r n\u0014\u0002;|wqJ\u0019;\r ?\b\u000bQ";
      I[53] = "H3\f^*|\u0013bRU\u001b)#3\u0010\u0004#;Gd\u001eAp";
      I[54] = "tlG\u0005\u0002t.(QwC\u0012j5]H\u0001~lf[\u0011<+nj\u0003\u000eQtq2@w";
      I[55] = " _\bA-NqPN\u0017GZ!J2\u0017!RL\bD\u0013;Z!J\u0011A75";
      I[56] = "ud(T5 ~b5\u0004_$N~2]`x\"xa[9Ewzm\u0003&((e5@_";
      I[57] = "Y.j*FfP&!9{<4\"2;DeX$a=\u001dX\r&me\u00025R95&{";
      I[58] = "\nCN{H*]\r\fi\"5\\G\u0012c^[\nCN{H*]\r\fi\"&Y]H7N \n[\u0011\n\u0013%\u0002L\u001d{Dk@^w";
      I[59] = "\u0005wk25MR9) _GIc)?%]RfR}oQHf??:\u0003D\tc=fM^x4s$_4";
      I[60] = "\fNqix\u001a]\u0003v+\n\u0011\u0001\u0002^z{9\u0002!\u007f~i~S\u0006rqrDVC}(\n";
      I[61] = "C,LyNv\u0019hZ\u000b\u0019\u0010]uV4M|[&Pmp+\u0019~Kb\u0014t_-\n\u000b";
      I[62] = ".w\u0003\u000bR'~}\u000f\u0018#\fYU!3x\u0001\u001f+\b\u0014Z0y{\u0002\u0018I";
      I[63] = "\u0005!a\u0011e\u0006Ro#\u0003\u000f\u000bS\u0002 \u0018b\r\u007f6#\r\u000fFY9!\u0011i\u0016S52`>\t\r.2\u0011iGO<X";
      I[64] = "p>\u0006t\fw!1@\"fcq+?*\u0000q`:zuVa`8\u00177\u00033lW";
      I[65] = "[\u0017\u0000,R\u001cT\u001e\u000b*\"JV\r 9N%\u0005A\u0017(MHG\u0014E$\"";
      I[66] = "b8\rK&r3>\n\u000bJt\u0003c^\u0018r\u007fhpWKt\u001dal_L(vre\fJJ";
      I[67] = "\u000eIR,|-_F\u0014z\u00169\u000f\\ntk,b\u001e\u001e~j9\u000f\\K,fV";
      I[68] = "8\\`J\u001e^dN{P/C3DaZhSZ\u001e,ZSR7\\y\b_=8\\`J\u001e^dN{P/";
      I[69] = "kcMLIklfQ\u001e\"{W#\u0018C^~:aM\u0011R\u0011nd\u0015\u0010[|1{MS\"";
      I[70] = "54R2$\u0001d2UrH\u0014Tp\u000emwS8v]k.nmtQ31\u00032k\tpH";
      I[71] = "aTcp\rC{Q\u007f7}\u001e\u0005C\u007fiBOiE,o\u001breXgq\rKjQlw}";
      I[72] = "76\u0014b6\u00155 @1]\u001c`!*;d\u0010t8Nd\"C5Q\u001194\u0004`5N\u007fgE\tj\u0013i \u0010m5U:ay";
      I[73] = "5v}jq=:\u007fvl\u0001k8lMv|iU.7\u007f}k8lb-q\u0004";
      I[74] = "#\u0019Cl[\u0001t\u0017\u0006?\"\fH\u001b\u001d4\u001dX$\u001dN2De+]\u0005&\u001c\u0003q\u0019\u0013T";
      I[75] = "o\u0004<rxb>\u000bz$\u0012\u007fd\u0012@!{e<\u0007;pt#jm";
      I[76] = "XpgTy\u001bSvz\u0004\u0013\u0015cj}],C\u000fl.[u~\u0005iaW)N\u0003'\u007f\r\u0013";
      I[77] = "$\u0011^Am)/\u0017C\u0011\u0007%\u001f\u000bDH8qs\r\u0017NaL&\u000f\u001b\u0016~!y\u0010CU\u0007";
      I[78] = "Y<S\u001cf!\u00016G_\u001d#>%[G\"wR#\bA{JGiWLz3O>HD\u001d";
      I[79] = "f}b%I]y-9j+Y\u001fo`t\u0014\u000fsi3rM2&k?*R_ytgi+";
      I[80] = "l7\"\u0013\u0015P;y`\u0001\u007fZ #`\u001e\u0005@;&\u001b\\OL!&v\u001e\u001a\u001e-I%R\u0012]2$g\u0007@Q]xe[\u000eK,/+\u0019\u001c!";
      I[81] = "n\u001cJ[\u001d6?\u0013\f\rw\"o\tm\t\u001c*d\u00196ZG ~\u001a[\u0018\u0012rru";
      I[82] = "*sT5=5=q\u001exEnPvM$z8<p\u001e\"#\u0005ir\u0012z<h6mJ9E";
      I[83] = "\u0019aSpj.\n*\u0001eP%eg\u000fwou\ta\\q6H\\cP))%\u0003|\bjP";
      I[84] = "=n\u001fg\u0007xr0\u0001'm[PM*X]r|6\u00045\u0012,bv";
      I[85] = "\u001eKXAO\u001dD\u000fN3\u001a{\u0000\u0012B\fL\u0017\u0006ADUq@D\u0019_Z\u0015\u001f\u0002J\u001e3";
      I[86] = "t$\u0006A)R%i\u0001\u0003[Pske[kUnf\u0001\n&R,\u0014";
      I[87] = "1<Ipm\u0001fr\u000bb\u0007\u000ei&\rl@\u001e\u0000<\rjc\u00151~\u0017~ip1<Ipm\u0001fr\u000bb\u0007";
      I[88] = "><jvXo15ap(93&_tE;8Z.>E*17lk\u0017&^";
      I[89] = "kt;MX\u0012k(<M;\u000b\u0014uw\u001aG\u000fy7\"HK`";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = I[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(J[var4]);
            I[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            I[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  I[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3336411643919546L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  I[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3336411643919546L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        I[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3336411643919546L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 77;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 107;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 109;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 81;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 103;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 77;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 107;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ce_C0120",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ce" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
