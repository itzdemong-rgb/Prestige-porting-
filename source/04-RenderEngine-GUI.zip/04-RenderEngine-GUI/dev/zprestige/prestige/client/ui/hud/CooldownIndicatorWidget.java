package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.util.InventoryUtil;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ScaleValue;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.AttackIndicator;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.TridentItem;
import org.joml.Matrix4f;

public class CooldownIndicatorWidget extends HudElement {
   private static final float m = 28.0F;
   private static final float a = 3.0F;
   private static final float c = 0.5F;
   private static final float d = 220.0F;
   private static final float g = 350.0F;
   private static final float h = 16.0F;
   private static final float i = 280.0F;
   private AttackIndicator j;
   private boolean n;
   private long k;
   private long l;
   private boolean q;
   private float o;
   private float p;
   private float t;
   private float u;
   private long r;
   private static final long v = 98877397057116L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[114];
   private static final String[] L = new String[114];

   public CooldownIndicatorWidget(long var1) {
      super("Cooldown Indicator", "Themed cooldown bar - covers attack, projectiles, and bow/crossbow/trident charge", ((98877397057116L ^ (98877397057116L ^ var1)) ^ 113909660110422L));
      var1 = 98877397057116L ^ var1;
      long var3 = var1 ^ 113909660110422L;
      short var10001 = 10211;
      long var10002 = 5173757901037802831L ^ var1;
      short var9 = 4034;
      long var10003 = 2030247518697176431L ^ var1;

      this.j = null;
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      var10001 = 3027;
      var10002 = 900102193653734775L ^ var1;
      this.k = 0L;
      var10001 = 9404;
      var10002 = 9206135962157740569L ^ var1;
      this.l = 0L;
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.o = 0.0F;
      this.p = 0.0F;
      this.t = 0.0F;
      this.u = 0.0F;
      var10001 = 13148;
      var10002 = 7272474312437818874L ^ var1;
      this.r = -100000L;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var4;
      label17: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 101393985901669L;
         long var6 = var2 ^ 20883324854464L;
         int var8 = Event.bReturningInt();
         MinecraftClient var11 = b;
         Window var10000 = var11.getWindow();
         int var27 = var8;
         Window var26 = var10000;
         Window var25 = var26;
         Window var24 = var26;
         if (var27 == 0) {
            Window var28 = var24;
            if (var28 == null) {
               break label17;
            }

            MinecraftClient var13 = b;
            Window var29 = var13.getWindow();
            var25 = var29;
         }

         Window var15 = var25;
         float var31 = var15.getFramebufferWidth();
         Object[] var16 = new Object[]{var6};
         float var9 = var31 / HudEditorScreen.bReturningFloat(var16);
         MinecraftClient var17 = b;
         Window var18 = var17.getWindow();
         float var32 = var18.getFramebufferHeight();
         Object[] var19 = new Object[]{var6};
         float var10 = var32 / HudEditorScreen.bReturningFloat(var19);
         float var10001 = var9 / 2.0F - 14.0F;
         float var10002 = var10 / 2.0F + 14.0F;
         Object[] var10005 = new Object[]{null, null, var4};
         var10005[1] = var10002;
         var10005[0] = var10001;
         Object[] var21 = var10005;
         CooldownIndicatorWidget var20 = this;
         var20.aReturningVoid(var21);
         int var30 = var8;
         if (var30 == 0) {
            return;
         }
      }

      Object[] var33 = new Object[]{null, null, var4};
      var33[1] = 110.0F;
      var33[0] = 150.0F;
      Object[] var23 = var33;
      CooldownIndicatorWidget var22 = this;
      var22.aReturningVoid(var23);
   }

   @Override
   public void jReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 100892260204356L;
      long var6 = var2 ^ 0L;
      long var8 = var2 ^ 80320279967827L;
      long var10 = var2 ^ 55588640037348L;
      int var10000 = Event.bReturningInt();
      super.jReturningVoid(new Object[]{var6});
      int var12 = var10000;
      int var25 = var12;
      CooldownIndicatorWidget var24 = this;
      CooldownIndicatorWidget var23 = var24;
      CooldownIndicatorWidget var22 = var24;
      if (var25 == 0) {
         Object[] var14 = new Object[]{var10};
         CooldownIndicatorWidget var13 = var22;
         boolean var26 = var13.eReturningBoolean(var14);
         if (var26) {
            Object[] var17 = new Object[]{var4};
            CooldownIndicatorWidget var16 = this;
            var16.r(var17);
            int var27 = var12;
            if (var27 == 0) {
               return;
            }
         }

         CooldownIndicatorWidget var28 = this;
         var23 = var28;
      }

      Object[] var21 = new Object[]{var8};
      CooldownIndicatorWidget var20 = var23;
      var20.s(var21);
   }

   
   
   private void r(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 98877397057116L ^ var2;
      int var4 = Event.bReturningInt();
      MinecraftClient var6 = b;
      GameOptions var21 = var6.options;
      if (var21 != null) {
         int var23 = var4;
         CooldownIndicatorWidget var22 = this;
         CooldownIndicatorWidget var19 = var22;
         CooldownIndicatorWidget var17 = var22;
         if (var23 == 0) {
            CooldownIndicatorWidget var24 = var17;
            CooldownIndicatorWidget var18 = var24;
            boolean var25 = var18.n;
            if (var25) {
               return;
            }

            try {
               MinecraftClient var10 = b;
               GameOptions var11 = var10.options;
               SimpleOption var12 = var11.getAttackIndicator();
               this.j = (AttackIndicator)var12.getValue();
               MinecraftClient var13 = b;
               GameOptions var14 = var13.options;
               SimpleOption var28 = var14.getAttackIndicator();
               AttackIndicator var16 = AttackIndicator.OFF;
               SimpleOption var15 = var28;
               var15.setValue(var16);
               var19 = this;
            } catch (Throwable var27) {
               return;
            }
         }

         try {
            var19.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
         } catch (Throwable var26) {
         }
      }
   }

   private void s(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 98877397057116L ^ var2;
      int var4 = Event.cReturningInt();
      MinecraftClient var6 = b;
      GameOptions var19 = var6.options;
      if (var19 != null) {
         int var21 = var4;
         CooldownIndicatorWidget var20 = this;
         CooldownIndicatorWidget var17 = var20;
         CooldownIndicatorWidget var15 = var20;
         if (var21 != 0) {
            CooldownIndicatorWidget var22 = var15;
            CooldownIndicatorWidget var16 = var22;
            boolean var23 = var16.n;
            if (!var23) {
               return;
            }

            CooldownIndicatorWidget var24 = this;
            var17 = var24;
         }

         AttackIndicator var25 = var17.j;
         if (var25 != null) {
               MinecraftClient var11 = b;
               GameOptions var12 = var11.options;
               SimpleOption var27 = var12.getAttackIndicator();
               AttackIndicator var14 = this.j;
               SimpleOption var13 = var27;
               var13.setValue(var14);
            } catch (Throwable var26) {
            }

            this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
            this.j = null;
            return;
         }
      }
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      RenderContext var2;
      long var3;
      Matrix4f var5;
      MeshBufferManager var6;
      long var7;
      long var9;
      long var13;
      long var15;
      long var17;
      long var19;
      int var21;
      label142: {
         var6 = (MeshBufferManager)var1[0];
         var2 = (RenderContext)var1[1];
         var5 = (Matrix4f)var1[2];
         var3 = (Long)var1[3];
         var7 = var3 ^ 41315979767267L;
         var9 = var3 ^ 2461400139638L;
         long var11 = var3 ^ 124644859064253L;
         var13 = var3 ^ 108743048490537L;
         var15 = var3 ^ 82290774353645L;
         var17 = var3 ^ 10358397256065L;
         var19 = var3 ^ 4527834288712L;
         var21 = Event.cReturningInt();
         int var118 = var21;
         CooldownIndicatorWidget var117 = this;
         CooldownIndicatorWidget var95 = var117;
         CooldownIndicatorWidget var94 = var117;
         if (var118 != 0) {
            boolean var119 = var94.n;
            if (var119) {
               break label142;
            }

            CooldownIndicatorWidget var120 = this;
            var95 = var120;
         }

         Object[] var34 = new Object[]{var11};
         CooldownIndicatorWidget var33 = var95;
         var33.r(var34);
      }

      label136: {
         label135: {
            MinecraftClient var35 = b;
            Window var10000 = var35.getWindow();
            int var122 = var21;
            Window var121 = var10000;
            Window var97 = var121;
            Window var96 = var121;
            if (var122 != 0) {
               Window var123 = var96;
               if (var123 == null) {
                  break label135;
               }

               MinecraftClient var37 = b;
               Window var124 = var37.getWindow();
               var97 = var124;
            }

            Window var39 = var97;
            float var168 = var39.getFramebufferWidth();
            Object[] var40 = new Object[]{var19};
            float var22 = var168 / HudEditorScreen.bReturningFloat(var40);
            MinecraftClient var41 = b;
            Window var42 = var41.getWindow();
            float var169 = var42.getFramebufferHeight();
            Object[] var43 = new Object[]{var19};
            float var23 = var169 / HudEditorScreen.bReturningFloat(var43);
            float var10001 = var22 / 2.0F - 14.0F;
            float var10002 = var23 / 2.0F + 14.0F;
            Object[] var10005 = new Object[]{null, null, var15};
            var10005[1] = var10002;
            var10005[0] = var10001;
            Object[] var45 = var10005;
            CooldownIndicatorWidget var44 = this;
            var44.aReturningVoid(var45);
            int var125 = var21;
            if (var125 != 0) {
               break label136;
            }
         }

         Object[] var182 = new Object[]{null, null, var15};
         var182[1] = 110.0F;
         var182[0] = 150.0F;
         Object[] var47 = var182;
         CooldownIndicatorWidget var46 = this;
         var46.aReturningVoid(var47);
      }

      byte var165;
      label127: {
         Object[] var10004 = new Object[]{null, 3.0F};
         var10004[0] = 28.0F;
         Object[] var50 = var10004;
         CooldownIndicatorWidget var49 = this;
         var49.iReturningVoid(var50);
         MinecraftClient var51 = b;
         var165 = ((byte)((var51.currentScreen instanceof HudEditorScreen) ? 1 : 0));
         int var127 = var21;
         MinecraftClient var126 = b;
         MinecraftClient var99 = var126;
         MinecraftClient var98 = var126;
         if (var127 != 0) {
            MinecraftClient var52 = var98;
            ClientPlayerEntity var128 = var52.player;
            if (var128 == null) {
               break label127;
            }

            MinecraftClient var129 = b;
            var99 = var129;
         }

         MinecraftClient var55 = var99;
         ClientWorld var130 = var55.world;
         if (var130 != null) {
            long var166 = System.currentTimeMillis();
            short var172 = 9404;
            long var177 = 9206167606603114535L ^ var3;
            long var188;
            int var132 = (var188 = this.k - 0L) == 0L ? 0 : (var188 < 0L ? -1 : 1);
            float var100;
            if (!((var132) != 0)) {
               float var133 = 0.0F;
               var100 = var133;
            } else {
               float var62 = (float)(var166 - this.k) / 1000.0F;
               float var61 = 0.1F;
               var100 = Math.min(var61, var62);
            }

            float var25;
            ScaleValue var26;
            int var105;
            label119: {
               int var104;
               label118: {
                  label146: {
                     var25 = var100;
                     this.k = var166;
                     Object[] var64 = new Object[]{var17};
                     CooldownIndicatorWidget var63 = this;
                     var26 = var63.aReturningav_C0046(var64);
                     int var135 = var21;
                     ScaleValue var134 = var26;
                     ScaleValue var102 = var134;
                     ScaleValue var101 = var134;
                     if (var135 != 0) {
                        ScaleValue var136 = var101;
                        if (var136 == null) {
                           break label146;
                        }

                        var102 = var26;
                     }

                     float var189;
                     int var170 = (var189 = var102.a - 0.999F) == 0.0F ? 0 : (var189 < 0.0F ? -1 : 1);
                     int var138 = var21;
                     int var137 = var170;
                     var104 = var137;
                     int var103 = var137;
                     if (var138 == 0) {
                        break label118;
                     }

                     int var139 = var103;
                     if (var139 < 0) {
                        var104 = 1;
                        break label118;
                     }
                  }

                  var105 = 0;
                  break label119;
               }

               int var140 = var104;
               var105 = var140;
            }

            int var27 = var105;
            ScaleValue var141 = var26;
            if (var141 != null) {
               double var67 = -var25 * 16.0F;
               float var28 = 1.0F - (float)Math.exp(var67);
               this.t = this.t + (var26.a - this.t) * var28;
            }

            label105: {
               CooldownIndicatorWidget var112;
               label147: {
                  int var143 = var21;
                  int var142 = var27;
                  int var109 = var142;
                  int var106 = var142;
                  if (var143 != 0) {
                     byte var145 = ((byte)((this.q) ? 1 : 0));
                     int var144 = var106;
                     if (var144 == var145) {
                        break label105;
                     }

                     this.o = this.p;
                     int var147 = var21;
                     CooldownIndicatorWidget var146 = this;
                     var112 = var146;
                     CooldownIndicatorWidget var107 = var146;
                     if (var147 == 0) {
                        break label147;
                     }

                     CooldownIndicatorWidget var148 = var107;
                     CooldownIndicatorWidget var108 = var148;
                     var108.l = var166;
                     int var149 = var27;
                     var109 = var149;
                  }

                  int var150 = var109;
                  if (var150 == 0) {
                     int var152 = var21;
                     CooldownIndicatorWidget var151 = this;
                     var112 = var151;
                     CooldownIndicatorWidget var110 = var151;
                     if (var152 == 0) {
                        break label147;
                     }

                     CooldownIndicatorWidget var153 = var110;
                     CooldownIndicatorWidget var111 = var153;
                     float var190;
                     int var154 = (var190 = var111.u - 0.8F) == 0.0F ? 0 : (var190 < 0.0F ? -1 : 1);
                     if (var154 > 0) {
                        this.r = var166;
                     }
                  }

                  var112 = this;
               }

               var112.q = dev.prestige.recovery.SourceSupport.asBoolean(var27);
            }

            ScaleValue var155 = var26;
            if (var155 != null) {
               this.u = var26.a;
            }

            float var30;
            label89: {
               long var167 = var166 - this.l;
               int var156 = var27;
               if (var156 != 0) {
                  float var77 = (float)var167 / 220.0F;
                  float var76 = 1.0F;
                  var30 = Math.min(var76, var77);
                  float var173 = this.o;
                  float var178 = 1.0F - this.o;
                  Object[] var10006 = new Object[]{null, var13};
                  var10006[0] = var30;
                  Object[] var78 = var10006;
                  this.p = var173 + var178 * dReturningFloat(var78);
                  int var157 = var21;
                  if (var157 != 0) {
                     break label89;
                  }
               }

               float var80 = (float)var167 / 350.0F;
               float var79 = 1.0F;
               var30 = Math.min(var79, var80);
               float var174 = this.o;
               Object[] var185 = new Object[]{null, var13};
               var185[0] = var30;
               Object[] var81 = var185;
               this.p = var174 * (1.0F - dReturningFloat(var81));
            }

            CooldownIndicatorWidget var116;
            label149: {
               float var175 = this.p;
               var10004 = new Object[]{null, var7};
               var10004[0] = var175;
               Object[] var82 = var10004;
               this.p = eReturningFloat(var82);
               int var159 = var21;
               byte var158 = var165;
               int var115 = var158;
               byte var113 = var158;
               if (var159 != 0) {
                  byte var160 = var113;
                  if (var160 != 0) {
                     float var85 = 0.5F;
                     float var84 = this.t;
                     float var184 = Math.max(var84, var85);
                     Object[] var186 = new Object[]{null, null, null, null, null, null, var9};
                     var186[5] = 0.0F;
                     var186[4] = var184;
                     var186[3] = 1.0F;
                     var186[2] = var5;
                     var186[1] = var2;
                     var186[0] = var6;
                     Object[] var87 = var186;
                     CooldownIndicatorWidget var86 = this;
                     var86.t(var87);
                     return;
                  }

                  float var176 = (float)(var166 - this.r) / 280.0F;
                  var10004 = new Object[]{null, var7};
                  var10004[0] = var176;
                  Object[] var89 = var10004;
                  float var171 = 1.0F - eReturningFloat(var89);
                  Object[] var10003 = new Object[]{null, var13};
                  var10003[0] = var171;
                  Object[] var90 = var10003;
                  var30 = dReturningFloat(var90);
                  int var162 = var21;
                  CooldownIndicatorWidget var161 = this;
                  var116 = var161;
                  CooldownIndicatorWidget var114 = var161;
                  if (var162 == 0) {
                     break label149;
                  }

                  float var191;
                  int var163 = (var191 = var114.p - 0.01F) == 0.0F ? 0 : (var191 < 0.0F ? -1 : 1);
                  var115 = var163;
               }

               int var164 = var115;
               if (var164 <= 0) {
                  return;
               }

               var116 = this;
            }

            float var181 = this.p;
            float var183 = this.t;
            Object[] var10009 = new Object[]{null, null, null, null, null, null, var9};
            var10009[5] = var30;
            var10009[4] = var183;
            var10009[3] = var181;
            var10009[2] = var5;
            var10009[1] = var2;
            var10009[0] = var6;
            Object[] var93 = var10009;
            CooldownIndicatorWidget var92 = var116;
            var92.t(var93);
            return;
         }
      }

      byte var131 = var165;
      if (var131 != 0) {
         Object[] var187 = new Object[]{null, null, null, null, null, null, var9};
         var187[5] = 0.0F;
         var187[4] = 0.5F;
         var187[3] = 1.0F;
         var187[2] = var5;
         var187[1] = var2;
         var187[0] = var6;
         Object[] var58 = var187;
         CooldownIndicatorWidget var57 = this;
         var57.t(var58);
      }
   }

   private void t(Object[] var1) {
      MeshBufferManager var7 = (MeshBufferManager)var1[0];
      RenderContext var4 = (RenderContext)var1[1];
      Matrix4f var2 = (Matrix4f)var1[2];
      float var3 = (Float)var1[3];
      float var6 = (Float)var1[4];
      float var5 = (Float)var1[5];
      long var8 = (Long)var1[6];
      var8 = 98877397057116L ^ var8;
      long var10 = var8 ^ 131558478951493L;
      long var12 = var8 ^ 70616055625170L;
      long var14 = var8 ^ 117331355417139L;
      long var16 = var8 ^ 71979483342281L;
      long var18 = var8 ^ 136636588678065L;
      int var10000 = Event.cReturningInt();
      float var21 = 1.5F;
      int var20 = var10000;
      float var22 = 28.0F * var3;
      int var81 = var20;
      float var80 = 0.5F;
      float var79 = var22;
      float var62 = var79;
      float var63 = var80;
      float var60 = var79;
      float var61 = var80;
      if (var81 != 0) {
         float var141;
         int var82 = (var141 = var60 - var61) == 0.0F ? 0 : (var141 < 0.0F ? -1 : 1);
         if (var82 < 0) {
            return;
         }

         var63 = (28.0F - var22) * 0.5F;
         var62 = this.e;
      }

      float var23 = var62 + var63;
      Color var113 = UiMetrics.r;
      Object[] var10004 = new Object[]{null, null, var12};
      var10004[1] = var3;
      var10004[0] = var113;
      Object[] var34 = var10004;
      Color var24 = cReturningColor(var34);
      int var85 = var20;
      float var84 = 0.7F;
      float var83 = var3;
      float var66 = var83;
      float var67 = var84;
      float var64 = var83;
      float var65 = var84;
      if (var85 != 0) {
         float var142;
         int var86 = (var142 = var64 - var65) == 0.0F ? 0 : (var142 < 0.0F ? -1 : 1);
         if (var86 > 0) {
            float var126 = this.f;
            Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var10};
            var10011[8] = var21;
            var10011[7] = 5;
            var10011[6] = 3.0F;
            var10011[5] = var22;
            var10011[4] = var126;
            var10011[3] = var23;
            var10011[2] = var2;
            var10011[1] = var4;
            var10011[0] = var7;
            Object[] var36 = var10011;
            BlurredRectangleRenderer.eReturningVoid(var36);
         }

         float var127 = this.f;
         Object[] var134 = new Object[]{null, null, null, null, null, null, null, null, null, var16};
         var134[8] = var21;
         var134[7] = var24;
         var134[6] = 3.0F;
         var134[5] = var22;
         var134[4] = var127;
         var134[3] = var23;
         var134[2] = var2;
         var134[1] = var4;
         var134[0] = var7;
         Object[] var38 = var134;
         FilledRectangleRenderer.cReturningVoid(var38);
         var67 = 1.0F;
         var66 = var22;
      }

      int var76;
      float var25 = var66 - var67;
      float var26 = 2.0F;
      float var27 = var26 * 0.5F;
      float var143;
      var10000 = (var143 = var6 - 0.001F) == 0.0F ? 0 : (var143 < 0.0F ? -1 : 1);
      int var88 = var20;
      int var87 = var10000;
      var76 = var87;
      int var68 = var87;
      label68:
      if (var88 != 0) {
         int var89 = var68;
         if (var89 > 0) {
            float var144;
            var10000 = (var144 = var25 - 1.0F) == 0.0F ? 0 : (var144 < 0.0F ? -1 : 1);
            int var91 = var20;
            int var90 = var10000;
            var76 = var90;
            int var69 = var90;
            if (var91 == 0) {
               break label68;
            }

            int var92 = var69;
            int var70 = var92;
            int var93 = var70;
            if (var93 > 0) {
               float var43 = var6;
               float var42 = 1.0F;
               float var28 = Math.min(var42, var43);
               Object[] var10003 = new Object[]{null, var14};
               var10003[0] = var28;
               Object[] var44 = var10003;
               Color var29 = aReturningColor(var44);
               float var30 = var25 * var28;
               float var145;
               var10000 = (var145 = var30 - var26) == 0.0F ? 0 : (var145 < 0.0F ? -1 : 1);
               int var95 = var20;
               int var94 = var10000;
               var76 = var94;
               int var71 = var94;
               if (var95 == 0) {
                  break label68;
               }

               int var96 = var71;
               if (var96 > 0) {
                  float var124 = var23 + 0.5F;
                  float var128 = this.f + 0.5F;
                  Object[] var135 = new Object[]{null, null, var12};
                  var135[1] = var3;
                  var135[0] = var29;
                  Object[] var46 = var135;
                  Color var10007 = cReturningColor(var46);
                  var135 = new Object[]{null, null, null, null, null, null, null, null, null, var16};
                  var135[8] = var27;
                  var135[7] = var10007;
                  var135[6] = var26;
                  var135[5] = var30;
                  var135[4] = var128;
                  var135[3] = var124;
                  var135[2] = var2;
                  var135[1] = var4;
                  var135[0] = var7;
                  Object[] var47 = var135;
                  FilledRectangleRenderer.cReturningVoid(var47);
                  float var146;
                  var10000 = (var146 = var28 - 0.995F) == 0.0F ? 0 : (var146 < 0.0F ? -1 : 1);
                  int var98 = var20;
                  int var97 = var10000;
                  var76 = var97;
                  int var72 = var97;
                  if (var98 == 0) {
                     break label68;
                  }

                  int var99 = var72;
                  int var73 = var99;
                  int var100 = var73;
                  if (var100 < 0) {
                     float var147;
                     var10000 = (var147 = var30 - 3.0F) == 0.0F ? 0 : (var147 < 0.0F ? -1 : 1);
                     int var102 = var20;
                     int var101 = var10000;
                     var76 = var101;
                     int var74 = var101;
                     if (var102 == 0) {
                        break label68;
                     }

                     int var103 = var74;
                     int var75 = var103;
                     int var104 = var75;
                     if (var104 > 0) {
                        Color var10001 = Color.WHITE;
                        Object[] var10005 = new Object[]{null, null, null, var18};
                        var10005[2] = 0.75F;
                        var10005[1] = var10001;
                        var10005[0] = var29;
                        Object[] var52 = var10005;
                        Color var119 = bReturningColor(var52);
                        float var122 = var3 * 0.9F;
                        var10004 = new Object[]{null, null, var12};
                        var10004[1] = var122;
                        var10004[0] = var119;
                        Object[] var53 = var10004;
                        Color var31 = cReturningColor(var53);
                        float var125 = var23 + 0.5F + var30 - 1.5F;
                        float var130 = this.f + 0.5F;
                        var135 = new Object[]{null, null, null, null, null, null, null, null, null, var16};
                        var135[8] = var27;
                        var135[7] = var31;
                        var135[6] = var26;
                        var135[5] = 1.5F;
                        var135[4] = var130;
                        var135[3] = var125;
                        var135[2] = var2;
                        var135[1] = var4;
                        var135[0] = var7;
                        Object[] var54 = var135;
                        FilledRectangleRenderer.cReturningVoid(var54);
                     }
                  }
               }
            }
         }

         float var148;
         var76 = (var148 = var5 - 0.01F) == 0.0F ? 0 : (var148 < 0.0F ? -1 : 1);
      }

      int var106 = var20;
      int var105 = var76;
      int var78 = var105;
      int var77 = var105;
      if (var106 != 0) {
         int var107 = var77;
         if (var107 <= 0) {
            return;
         }

         short var120 = 4653;
         long var123 = 2003490111715599698L ^ var8;
         var120 = 255;
         int var57 = (int)(170.0F * var5 * var3);
         int var108 = Math.min(255, var57);
         var78 = var108;
      }

      int var112 = var78;
      byte var110 = 2;
      int var109 = var112;
      if (var109 > var110) {
         float var131 = this.f;
         short var10009 = 16200;
         long var10010 = 2884398813442426934L ^ var8;
         short var133 = 16200;
         long var138 = 2884398813442426934L ^ var8;
         short var139 = 16200;
         long var10012 = 2884398813442426934L ^ var8;
         Color var132 = new Color(255, 255, 255, var112);
         Object[] var140 = new Object[]{null, null, null, null, null, null, null, null, null, var16};
         var140[8] = var21;
         var140[7] = var132;
         var140[6] = 3.0F;
         var140[5] = var22;
         var140[4] = var131;
         var140[3] = var23;
         var140[2] = var2;
         var140[1] = var4;
         var140[0] = var7;
         Object[] var59 = var140;
         FilledRectangleRenderer.cReturningVoid(var59);
      }
   }

   private static Color aReturningColor(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      var2 = 98877397057116L ^ var2;
      long var4 = var2 ^ 84769290260646L;
      long var6 = var2 ^ 80979124690149L;
      long var8 = var2 ^ 11467393192812L;
      long var10 = var2 ^ 86993668595678L;
      Object[] var16 = new Object[]{var6};
      Color var12 = ClientUiUtil.dReturningColor(var16);
      float var10002 = var1 / 0.75F;
      Object[] var10005 = new Object[]{null, var4};
      var10005[0] = var10002;
      Object[] var17 = var10005;
      var10002 = eReturningFloat(var17);
      var10005 = new Object[]{null, var8};
      var10005[0] = var10002;
      Object[] var18 = var10005;
      float var13 = 0.55F + 0.45F * dReturningFloat(var18);
      Color var19 = var12;
      int var28 = (int)(var19.getRed() * var13);
      Color var20 = var12;
      int var10003 = (int)(var20.getGreen() * var13);
      Color var21 = var12;
      Color var14 = new Color(var28, var10003, (int)(var21.getBlue() * var13));
      float var10000 = (var1 - 0.88F) / 0.12F;
      Object[] var30 = new Object[]{null, var4};
      var30[0] = var10000;
      Object[] var22 = var30;
      var10000 = eReturningFloat(var22);
      Object[] var31 = new Object[]{null, var8};
      var31[0] = var10000;
      Object[] var23 = var31;
      float var15 = dReturningFloat(var23);
      Color var10001 = Color.WHITE;
      var10002 = var15 * 0.65F;
      var10005 = new Object[]{null, null, null, var10};
      var10005[2] = var10002;
      var10005[1] = var10001;
      var10005[0] = var14;
      Object[] var24 = var10005;
      return bReturningColor(var24);
   }

   private static Color bReturningColor(Object[] var0) {
      Color var5 = (Color)var0[0];
      Color var4 = (Color)var0[1];
      float var1 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 98877397057116L ^ var2;
      long var6 = var2 ^ 101067458703652L;
      Object[] var10003 = new Object[]{null, var6};
      var10003[0] = var1;
      Object[] var8 = var10003;
      var1 = eReturningFloat(var8);
      Color var9 = var5;
      float var10002 = var9.getRed();
      Color var10 = var4;
      int var21 = var10.getRed();
      Color var11 = var5;
      int var20 = (int)(var10002 + (var21 - var11.getRed()) * var1);
      Color var12 = var5;
      float var22 = var12.getGreen();
      Color var13 = var4;
      int var10004 = var13.getGreen();
      Color var14 = var5;
      int var23 = (int)(var22 + (var10004 - var14.getGreen()) * var1);
      Color var15 = var5;
      float var24 = var15.getBlue();
      Color var16 = var4;
      int var10005 = var16.getBlue();
      Color var17 = var5;
      return new Color(var20, var23, (int)(var24 + (var10005 - var17.getBlue()) * var1));
   }

   private ScaleValue aReturningav_C0046(Object[] var1) {
      long var4;
      long var8;
      int var10;
      float var11;
      label70: {
         long var2 = (Long)var1[0];
         var2 = 98877397057116L ^ var2;
         var4 = var2 ^ 38239536564399L;
         long var6 = var2 ^ 21754810645114L;
         var8 = var2 ^ 131518371179647L;
         int var10000 = Event.cReturningInt();
         Object[] var17 = new Object[]{var6};
         var11 = GameRenderUtil.aReturningFloat(var17);
         var10 = var10000;
         MinecraftClient var18 = b;
         int var81 = var10;
         ClientPlayerEntity var80 = var18.player;
         ClientPlayerEntity var69 = var80;
         ClientPlayerEntity var68 = var80;
         if (var81 != 0) {
            ClientPlayerEntity var19 = var68;
            boolean var82 = var19.isUsingItem();
            if (!var82) {
               break label70;
            }

            MinecraftClient var21 = b;
            ClientPlayerEntity var83 = var21.player;
            var69 = var83;
         }

         ClientPlayerEntity var23 = var69;
         ItemStack var12 = var23.getActiveItem();
         int var85 = var10;
         ItemStack var84 = var12;
         ItemStack var71 = var84;
         ItemStack var70 = var84;
         if (var85 != 0) {
            ItemStack var86 = var70;
            if (var86 == null) {
               break label70;
            }

            var71 = var12;
         }

         ItemStack var25 = var71;
         byte var110 = ((byte)((var25.isEmpty()) ? 1 : 0));
         int var88 = var10;
         boolean var87 = dev.prestige.recovery.SourceSupport.asBoolean(var110);
         boolean var73 = var87;
         boolean var72 = var87;
         if (var88 != 0) {
            boolean var89 = var72;
            if (var89) {
               break label70;
            }

            ItemStack var27 = var12;
            boolean var90 = var27.getItem() instanceof BowItem;
            var73 = var90;
         }

         int var92 = var10;
         boolean var91 = var73;
         boolean var75 = var91;
         boolean var74 = var91;
         if (var92 != 0) {
            boolean var93 = var74;
            if (var93) {
               ScaleValue var106 = new ScaleValue();
               MinecraftClient var30 = b;
               ClientPlayerEntity var31 = var30.player;
               float var33 = (var31.getItemUseTime() + var11) / 20.0F;
               float var32 = 1.0F;
               var106.a = Math.min(var32, var33);
               return var106;
            }

            ItemStack var34 = var12;
            var75 = var34.getItem() instanceof CrossbowItem;
         }

         int var95 = var10;
         boolean var94 = var75;
         boolean var77 = var94;
         boolean var76 = var94;
         if (var95 != 0) {
            boolean var96 = var76;
            if (var96) {
               ScaleValue var105 = new ScaleValue();
               var110 = 1;
               MinecraftClient var36 = b;
               ClientPlayerEntity var38 = var36.player;
               ItemStack var37 = var12;
               int var40 = CrossbowItem.getPullTime(var37, (LivingEntity)var38);
               int var14 = Math.max(1, var40);
               MinecraftClient var41 = b;
               ClientPlayerEntity var42 = var41.player;
               float var44 = (var42.getItemUseTime() + var11) / var14;
               float var43 = 1.0F;
               var105.a = Math.min(var43, var44);
               return var105;
            }

            ItemStack var45 = var12;
            var77 = var45.getItem() instanceof TridentItem;
         }

         boolean var97 = var77;
         if (var97) {
            ScaleValue var13 = new ScaleValue();
            MinecraftClient var46 = b;
            ClientPlayerEntity var47 = var46.player;
            float var49 = (var47.getItemUseTime() + var11) / 10.0F;
            float var48 = 1.0F;
            var13.a = Math.min(var48, var49);
            return var13;
         }
      }

      MinecraftClient var50 = b;
      ClientPlayerEntity var51 = var50.player;
      ItemStack var10001 = var51.getMainHandStack();
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = var11;
      var10005[0] = var10001;
      Object[] var53 = var10005;
      CooldownIndicatorWidget var52 = this;
      float var104 = var52.cReturningFloat(var53);
      MinecraftClient var54 = b;
      ClientPlayerEntity var55 = var54.player;
      var10001 = var55.getOffHandStack();
      var10005 = new Object[]{null, null, var4};
      var10005[1] = var11;
      var10005[0] = var10001;
      Object[] var57 = var10005;
      CooldownIndicatorWidget var56 = this;
      float var107 = var56.cReturningFloat(var57);
      float var59 = var107;
      float var58 = var104;
      float var108 = Math.max(var58, var59);
      float var115;
      int var112 = (var115 = var108 - 0.001F) == 0.0F ? 0 : (var115 < 0.0F ? -1 : 1);
      int var99 = var10;
      int var98 = var112;
      int var79 = var98;
      int var78 = var98;
      if (var99 != 0) {
         int var100 = var78;
         if (var100 > 0) {
            ScaleValue var109 = new ScaleValue();
            var109.a = 1.0F - var108;
            return var109;
         }

         MinecraftClient var61 = b;
         ClientPlayerEntity var62 = var61.player;
         Object[] var64 = new Object[]{var62.getMainHandStack(), var8};
         CooldownIndicatorWidget var63 = this;
         var79 = (((var63.fReturningBoolean(var64)) ? 1 : 0));
      }

      int var101 = var79;
      if (var101 != 0) {
         MinecraftClient var65 = b;
         float var67 = var11;
         ClientPlayerEntity var66 = var65.player;
         float var15 = var66.getAttackCooldownProgress(var67);
         float var116;
         int var102 = (var116 = var15 - 1.0F) == 0.0F ? 0 : (var116 < 0.0F ? -1 : 1);
         if (var102 < 0) {
            ScaleValue var16 = new ScaleValue();
            var16.a = var15;
            return var16;
         }
      }

      return null;
   }

   private boolean fReturningBoolean(Object[] var1) {
      ItemStack var2 = (ItemStack)var1[0];
      long var3 = (Long)var1[1];
      var3 = 98877397057116L ^ var3;
      long var5 = var3 ^ 93619886387714L;
      long var7 = var3 ^ 16371104263946L;
      long var9 = var3 ^ 83615821246928L;
      int var11 = Event.bReturningInt();
      int var39 = var11;
      ItemStack var38 = var2;
      ItemStack var26 = var38;
      ItemStack var25 = var38;
      if (var39 == 0) {
         ItemStack var40 = var25;
         if (var40 == null) {
            return false;
         }

         var26 = var2;
      }

      ItemStack var13 = var26;
      byte var10000 = ((byte)((var13.isEmpty()) ? 1 : 0));
      int var42 = var11;
      byte var41 = var10000;
      byte var28 = var41;
      byte var27 = var41;
      if (var42 == 0) {
         byte var43 = var27;
         if (var43 != 0) {
            return false;
         }

         Object[] var16 = new Object[]{var2, var9};
         var28 = ((byte)((InventoryUtil.aReturningBoolean(var16)) ? 1 : 0));
      }

      int var45 = var11;
      byte var44 = var28;
      byte var36 = var44;
      byte var29 = var44;
      if (var45 == 0) {
         byte var46 = var29;
         if (var46 == 0) {
            Object[] var18 = new Object[]{var2, var5};
            byte var61 = ((byte)((InventoryUtil.bReturningBoolean(var18)) ? 1 : 0));
            int var48 = var11;
            boolean var47 = dev.prestige.recovery.SourceSupport.asBoolean(var61);
            byte var64 = ((byte)((var47) ? 1 : 0));
            boolean var30 = var47;
            if (var48 != 0) {
               return dev.prestige.recovery.SourceSupport.asBoolean(var64);
            }

            boolean var49 = var30;
            boolean var31 = var49;
            boolean var50 = var31;
            if (!var50) {
               Object[] var21 = new Object[]{var2, var7};
               var61 = ((byte)((InventoryUtil.o(var21)) ? 1 : 0));
               int var52 = var11;
               boolean var51 = ((((int)(var61) & 1) != 0));
               var64 = ((byte)((var51) ? 1 : 0));
               boolean var32 = var51;
               if (var52 != 0) {
                  return ((((int)(var64) & 1) != 0));
               }

               boolean var53 = var32;
               boolean var33 = var53;
               boolean var54 = var33;
               if (!var54) {
                  ItemStack var24 = var2;
                  var61 = ((byte)((var24.getItem() instanceof TridentItem) ? 1 : 0));
                  int var56 = var11;
                  byte var55 = var61;
                  var64 = var55;
                  byte var34 = var55;
                  if (var56 != 0) {
                     return dev.prestige.recovery.SourceSupport.asBoolean(var64);
                  }

                  byte var57 = var34;
                  byte var35 = var57;
                  byte var58 = var35;
                  if (var58 == 0) {
                     return false;
                  }
               }
            }
         }

         var36 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var36);
   }

   private float cReturningFloat(Object[] var1) {
      ItemStack var5 = (ItemStack)var1[0];
      float var4 = (Float)var1[1];
      long var2 = (Long)var1[2];
      long var10000 = 98877397057116L ^ var2;
      int var6 = Event.cReturningInt();
      int var21 = var6;
      ItemStack var20 = var5;
      ItemStack var17 = var20;
      ItemStack var16 = var20;
      if (var21 != 0) {
         ItemStack var22 = var16;
         if (var22 == null) {
            return 0.0F;
         }

         var17 = var5;
      }

      ItemStack var9 = var17;
      boolean var23 = var9.isEmpty();
      if (!var23) {
            MinecraftClient var11 = b;
            ClientPlayerEntity var12 = var11.player;
            ItemCooldownManager var25 = var12.getItemCooldownManager();
            float var15 = var4;
            ItemStack var14 = var5;
            ItemCooldownManager var13 = var25;
            return var13.getCooldownProgress(var14, var15);
         } catch (Throwable var24) {
            return 0.0F;
         }
      } else {
         return 0.0F;
      }
   }

   private static float dReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 98877397057116L ^ var2;
      int var4 = Event.cReturningInt();
      float var21;
      int var19 = (var21 = var1 - 0.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
      int var12 = var4;
      int var11 = var19;
      int var8 = var11;
      int var5 = var11;
      if (var12 != 0) {
         int var13 = var5;
         if (var13 <= 0) {
            return 0.0F;
         }

         int var16 = var4;
         float var15 = 1.0F;
         float var14 = var1;
         float var9 = var14;
         float var10 = var15;
         float var6 = var14;
         float var7 = var15;
         if (var16 == 0) {
            return var9 * var10;
         }

         float var22;
         int var17 = (var22 = var6 - var7) == 0.0F ? 0 : (var22 < 0.0F ? -1 : 1);
         var8 = var17;
      }

      int var18 = var8;
      if (var18 >= 0) {
         return 1.0F;
      }

      float var20 = var1 * var1 * var1;
      float var24 = var1 * (var1 * 6.0F - 15.0F) + 10.0F;
      float var23 = var20;
      return var23 * var24;
   }

   private static float eReturningFloat(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 98877397057116L ^ var2;
      int var4 = Event.cReturningInt();
      float var20;
      int var19 = (var20 = var1 - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
      int var11 = var4;
      int var10 = var19;
      int var7 = var10;
      int var5 = var10;
      if (var11 != 0) {
         int var12 = var5;
         if (var12 < 0) {
            return 0.0F;
         }

         int var15 = var4;
         float var14 = var1;
         float var8 = var14;
         float var6 = var14;
         if (var15 == 0) {
            return var8;
         }

         float var21;
         int var16 = (var21 = var6 - 1.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
         var7 = var16;
      }

      int var17 = var7;
      return var17 <= 0 ? var1 : 1.0F;
   }

   private static Color cReturningColor(Object[] var0) {
      Color var4 = (Color)var0[0];
      float var1 = (Float)var0[1];
      long var2 = (Long)var0[2];
      var2 = 98877397057116L ^ var2;
      byte var10000 = 0;
      short var10001 = 16200;
      long var10002 = 2884389141766915000L ^ var2;
      var10001 = 255;
      Color var6 = var4;
      int var8 = (int)(var6.getAlpha() * var1);
      int var10 = Math.min(255, var8);
      int var5 = Math.max(0, var10);
      Color var11 = var4;
      int var16 = var11.getRed();
      Color var12 = var4;
      int var10003 = var12.getGreen();
      Color var13 = var4;
      return new Color(var16, var10003, var13.getBlue(), var5);
   }

   static {

      {

      b();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(94784394475176L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[2];
      String var28 = "äUi\u0091-:\u0000²S{Í\u0081³aÕµvæg5eûXwhK[\u0004\u000eIÊ4¦\u0010|¤èn\u009eu\u0088Èk\u0016\u0092Ø\u0015vÃ¨\\n\u0080ðÛ\u0080(:/È\u0090dµ¬Âüòèö\u0006¬UB\u0084}ªû¹Û |WVï\u0095À÷\u001e{§\u0087µ\u0096>i\bL×\u0004ÂGC\u0002¶-©è´\u0095%\u009bíó\u0013dJ[ \u0012ëæ\u00018\u0001öUBp\u0015ÉÈ+B$rV\u0096\u0018\u0003Ï¥ÙI\u0091Ñ\"\u00895\u0088¶èaúf\u009fY.Ð¾|\u001asm\u009ap+-\u0014\u0012i¼tÁ£!$Ú";
      int var30 = "äUi\u0091-:\u0000²S{Í\u0081³aÕµvæg5eûXwhK[\u0004\u000eIÊ4¦\u0010|¤èn\u009eu\u0088Èk\u0016\u0092Ø\u0015vÃ¨\\n\u0080ðÛ\u0080(:/È\u0090dµ¬Âüòèö\u0006¬UB\u0084}ªû¹Û |WVï\u0095À÷\u001e{§\u0087µ\u0096>i\bL×\u0004ÂGC\u0002¶-©è´\u0095%\u009bíó\u0013dJ[ \u0012ëæ\u00018\u0001öUBp\u0015ÉÈ+B$rV\u0096\u0018\u0003Ï¥ÙI\u0091Ñ\"\u00895\u0088¶èaúf\u009fY.Ð¾|\u001asm\u009ap+-\u0014\u0012i¼tÁ£!$Ú"
         .length();
      char var27 = '(';
      int var26 = -1;

      while (true) {
         byte[] var32 = var24.doFinal(var28.substring(++var26, var26 + var27).getBytes("ISO-8859-1"));
         String var41 = b(var32).intern();
         int var10001 = -1;
         var31[var29++] = var41;
         if ((var26 += var27) >= var30) {
            w = var31;
            x = new String[2];
            D = new HashMap(13);
            Cipher var11;
            var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(94784394475176L << var12 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var17 = new long[2];
            String var15 = "Ã\u008bÔÓöã]}ê_\u009aø+k0}";
            int var16 = "Ã\u008bÔÓöã]}ê_\u009aø+k0}".length();
            do {
               var10001 = var13;
               var13 += 8;
               byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
               var10001 = var14++;
               long var19 = (var18[0] & 255L) << 56
                  | (var18[1] & 255L) << 48
                  | (var18[2] & 255L) << 40
                  | (var18[3] & 255L) << 32
                  | (var18[4] & 255L) << 24
                  | (var18[5] & 255L) << 16
                  | (var18[6] & 255L) << 8
                  | var18[7] & 255L;
               byte[] var21 = var11.doFinal(
                  new byte[]{
                     (byte)(var19 >>> 56),
                     (byte)(var19 >>> 48),
                     (byte)(var19 >>> 40),
                     (byte)(var19 >>> 32),
                     (byte)(var19 >>> 24),
                     (byte)(var19 >>> 16),
                     (byte)(var19 >>> 8),
                     (byte)var19
                  }
               );
               long var10004 = (var21[0] & 255L) << 56
                  | (var21[1] & 255L) << 48
                  | (var21[2] & 255L) << 40
                  | (var21[3] & 255L) << 32
                  | (var21[4] & 255L) << 24
                  | (var21[5] & 255L) << 16
                  | (var21[6] & 255L) << 8
                  | var21[7] & 255L;
               // var17[var10001] = var10004;
            } while (var13 < var16);

            B = var17;
            C = new Integer[2];
            J = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(94784394475176L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[3];
            String var4 = "oé'ï£fn·×¯Ð¾`ê\\4¾°\u0085ÙqJ\u0094\u009e";
            int var5 = "oé'ï£fn·×¯Ð¾`ê\\4¾°\u0085ÙqJ\u0094\u009e".length();
            do {
               int var39 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var39, var2).getBytes("ISO-8859-1");
               var39 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var49 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var39] = var49;
            } while (var2 < var5);

            H = var6;
            I = new Long[3];
            break;
         }

         var27 = var28.charAt(var26);
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27392;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b3", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b3",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3526;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b3", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b3",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3848;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b3", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b3",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 44;
            yield var15;
         }
         case 1 -> {
            byte var16 = 39;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 9;
            yield var18;
         }
         case 4 -> {
            byte var19 = 49;
            yield var19;
         }
         case 5 -> {
            byte var20 = 58;
            yield var20;
         }
         case 6 -> {
            byte var21 = 38;
            yield var21;
         }
         case 7 -> {
            byte var22 = 24;
            yield var22;
         }
         case 8 -> {
            byte var23 = 4;
            yield var23;
         }
         case 9 -> {
            byte var24 = 47;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 12;
            yield var26;
         }
         case 12 -> {
            byte var27 = 45;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 63;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 18;
            yield var31;
         }
         case 17 -> {
            byte var32 = 14;
            yield var32;
         }
         case 18 -> {
            byte var33 = 48;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 17;
            yield var35;
         }
         case 21 -> {
            byte var36 = 19;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 59;
            yield var38;
         }
         case 24 -> {
            byte var39 = 2;
            yield var39;
         }
         case 25 -> {
            byte var40 = 42;
            yield var40;
         }
         case 26 -> {
            byte var41 = 36;
            yield var41;
         }
         case 27 -> {
            byte var42 = 41;
            yield var42;
         }
         case 28 -> {
            byte var43 = 28;
            yield var43;
         }
         case 29 -> {
            byte var44 = 55;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 27;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 51;
            yield var49;
         }
         case 35 -> {
            byte var50 = 35;
            yield var50;
         }
         case 36 -> {
            byte var51 = 13;
            yield var51;
         }
         case 37 -> {
            byte var52 = 29;
            yield var52;
         }
         case 38 -> {
            byte var53 = 50;
            yield var53;
         }
         case 39 -> {
            byte var54 = 3;
            yield var54;
         }
         case 40 -> {
            byte var55 = 21;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 33;
            yield var57;
         }
         case 43 -> {
            byte var58 = 26;
            yield var58;
         }
         case 44 -> {
            byte var59 = 40;
            yield var59;
         }
         case 45 -> {
            byte var60 = 56;
            yield var60;
         }
         case 46 -> {
            byte var61 = 8;
            yield var61;
         }
         case 47 -> {
            byte var62 = 6;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 5;
            yield var64;
         }
         case 50 -> {
            byte var65 = 15;
            yield var65;
         }
         case 51 -> {
            byte var66 = 43;
            yield var66;
         }
         case 52 -> {
            byte var67 = 1;
            yield var67;
         }
         case 53 -> {
            byte var68 = 23;
            yield var68;
         }
         case 54 -> {
            byte var69 = 22;
            yield var69;
         }
         case 55 -> {
            byte var70 = 52;
            yield var70;
         }
         case 56 -> {
            byte var71 = 54;
            yield var71;
         }
         case 57 -> {
            byte var72 = 30;
            yield var72;
         }
         case 58 -> {
            byte var73 = 34;
            yield var73;
         }
         case 59 -> {
            byte var74 = 0;
            yield var74;
         }
         case 60 -> {
            byte var75 = 7;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 53;
            yield var77;
         }
         default -> 46;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "nn[u\u001cNxn^/\u000fYo%])\u0003M~bJ>H_O";
      K[1] = int.class;
      L[1] = "java/lang/Integer";
      K[2] = "\u001aN&dl\u0012\fN#>\u007f\u0005\u001b\u0005 8s\u0011\nB7/8\u0001\u0011";
      K[3] = "2l3\u0001`QGL8\u000eq\u001e&B3\u0005uDR";
      K[4] = boolean.class;
      L[4] = "java/lang/Boolean";
      K[5] = "\u007f\u0013+{QF\u007f\u0013<']IeX<9]\\b)nb\u0005\u0016";
      K[6] = "{\fM\u0015J*{\fZIF%aGZWF0f6\b\f\u001eq";
      K[7] = ">X\\.j<KxW!{s*v\\*\u007f)^";
      K[8] = "j\u000fMj%C|\u000fH06TkDK6:@z\u0003\\!qQ=";
      K[9] = "QE.IT;ZJ?\u0006.?IK/I\u0018;^";
      K[10] = "(XD.\u001b)]xO!\nf<vD*\u000e<H";
      K[11] = "+E]-=-^eV\",b?k])(8K";
      K[12] = float.class;
      L[12] = "java/lang/Float";
      K[13] = "\u0018k_Yh\u0005\u0005~\u0007{)\b\u001dx";
      K[14] = ")&q\u0006;.)&fZ7!3mfD744\u001c2\u001c`";
      K[15] = "\u0004\u0001BA)\b\u0004\u0001U\u001d%\u0007\u001eJU\u0003%\u0012\u0019;\u0007X}W";
      K[16] = "\u000b-\u0014\u0019x_\u000b-\u0003EtP\u0011f\u0003[tE\u0016\u0017S\u0006%";
      K[17] = "E/: I\u0001E/-|E\u000e_d-bE\u001bX\u0015\u007f>\u0010Y";
      K[18] = "\u0019\u0016q{:s\u000f\u0016t!)d\u0018]w'%p\t\u001a`0nd%";
      K[19] = "Tw[1yk!WP>h$@Y[5l~4";
      K[20] = "#\u001f0\u000eif5\u001f5Tzq\"T6Rve3\u0013!E=tv";
      K[21] = "Nh\"uz/;H)zk`ZF\"qo:.";
      K[22] = void.class;
      L[22] = "java/lang/Void";
      K[23] = "\u0001\u0002Y\u0012HEt\"R\u001dY\n\u0015,Y\u0016]Pa";
      K[24] = "\u0010@KHG\u0013\u001bOZ\u0007$\u001e\u000eI";
      K[25] = "\u0000i\u007fm~duItbo+\u0014G\u007fikq`";
      K[26] = "\u0003nNMF\u0000vNEBWO\u0017@NIS\u0015c";
      K[27] = "H^hXW<^^m\u0002D+I\u0015n\u0004H?XRy\u0013\u0003(J";
      K[28] = "I?P[w\u0001<\u001f[TfN]\u0011P_b\u0014)";
      K[29] = "\fZk\u0002t'\u001aZnXg0\r\u0011m^k$\u001cVzI 4Q";
      K[30] = ";-\u0012.O\u000eN\r\u0019!^A/\u0003\u0012*Z\u001b[";
      K[31] = "\u0001o\u00166&_tO\u001d97\u0010\u0015A\u001623Ja";
      K[32] = "\u001eisj\u0004\tkIxe\u0015F\nGsn\u0011\u001c~";
      K[33] = "\\?H\u0015\u0006:)\u001fC\u001a\u0017uH\u0011H\u0011\u0013/<";
      K[34] = ";3Wc\u001c1-3R9\u000f&:xQ?\u00032+?F(H \u001d";
      K[35] = "j)c%\u001bn\u001f\th*\n!~\u0007c!\u000e{\n";
      K[36] = "Z\t\t{\u0016\u0010/)\u0002t\u0007_N'\t\u007f\u0003\u0005:";
      K[37] = "R!\u0001D\u0012+R!\u0016\u0018\u001e$Hj\u0016\u0006\u001e1O\u001bD]Iv";
      K[38] = "C]o\u0014amC]xHmbY\u0016xVmw^g*\t<=";
      K[39] = "PK\u0017_,EFK\u0012\u0005?RQ\u0000\u0011\u00033F@G\u0006\u0014xQC";
      K[40] = "6\u0005(5\rQC%#:\u001c\u001e\"+(1\u0018DV";
      K[41] = "S,R\u000e}$&\fY\u0001lkG\u0002R\nh13";
      K[42] = "\u0015Pkd/\b`p`k>G\u0001~k`:\u001du";
      K[43] = "/Y\u000fi\\\u000e/Y\u00185P\u00015\u0012\u0018+P\u00142cLv\u0006U";
      K[44] = "$\u0001\u001fw0\u0002/\u000e\u000e8Q\f$\u0005\nb";
      K[45] = "e\bR[\u0014<e\bE\u0007\u00183\u007fCE\u0019\u0018&x2\u0015DL";
      K[46] = "\u00112:]R7\u00112-\u0001^8\u000by-\u001f^-\f\bzC\to";
      K[47] = "0+d^P(E\u000boQAg$\u0005dZE=P";
      K[48] = "\r7zG4*\u00068k\bI?\u0014\"iK";
      K[49] = long.class;
      L[49] = "java/lang/Long";
      K[50] = ":Kk1Pn:K|m\\a \u0000|s\\t'q+,\n";
      K[51] = double.class;
      L[51] = "java/lang/Double";
      K[52] = "\u0005N4\u0012uQpn?\u001dd\u001e\u0011`4\u0016`De";
      K[53] = "gWH\u0013%8gW_O)7}\u001c_Q)\"zm\n\u000ep";
      K[54] = "dlG_}\u0003\u0011LLPlLpBG[h\u0016\u0004";
      K[55] = "\u007f;Cik\u0016i;F3x\u0001~pE5t\u0015o7R\"?\u0007m";
      K[56] = "@]\u0019P0\u000f\u0015\u0014\u0010\u001b\u000e\u001bF]b\u0013p\u001eNW\u0006\u0019iN/_\u001c\u0001o\u0004KU\u0005Q\u000e\fQM\u0003\u001bj\u0006H\u001db";
      K[57] = "1\u0012%t1{9\u0005`)@mm\u000bR*8biwi0 cz\u0013c)p\u0002";
      K[58] = "\u0002H2\u0005\u0007c\f\u0014 \u001fwr\u000fR(\u0011\u0011e.I7\u00112x\u0016L3\u0007wh\u001c\u00181\u001f\u0018dNB=|";
      K[59] = "P\u0007c_k\u0000\u0003\f&KQU[\u000f>Y\u0006\u0002\u0005_g5#R\u0006\u0019\"W*QK\u0004";
      K[60] = ";a'uK\u0013=c2w\"\u0006md#(N4?)}w\"Y|w;0[\u0019k& O";
      K[61] = "\u0012IG\u007f#&G\u0000N4\u001d2\u001c_<~w+\fT\u0005)v'\u00039\f$a&\u0010\u0000[%m)}\tV2l:D^W>cW";
      K[62] = "\u001eu~F\u0011(\u00182{\u0007a(\u00185!\u001a\r\u001aItyCa?\u000b) \u0007\u00055\u0012yA";
      K[63] = "W0hJ\u0012\u0000Ku#\u0002`\u0007:7!C\u000f\bXiz\u0004\t\b:`x[\t\nJ~jJ\u0018f";
      K[64] = "\u007f\u001e)qA\u001e-\u001dd-zNA\u001db5\u0015K#C9r\u0013KA\u0015>p@T8\u001d)5\u001d%";
      K[65] = "/[wOY4q\u0007\"]%:\u0016\u0002*FJ>t\\q\u0001L>\u0016\u0001oR]/oAx\u0003FP";
      K[66] = ")Ob\u0019q\u0003{L/EJQ\u0017Kv\\'TuM`]s8)\u0013jK&Z/\u0005k\u001fJ";
      K[67] = "?L>\u000ej2lG{\u001aPl8Ug\u0003<^o\u00139Tk\t>\u00158_ l8R=\u001eP";
      K[68] = ")5*\u0000w{57w\u000b\u0006}:(z\u000bjOkn'R;\u0018+)&\u0001yq4:f\u0013\u0006";
      K[69] = "4QWf\u000es<F\u0012;\u007fehH31\u0013\nwJ\t=\u0005n}SY\\";
      K[70] = "^,|{\u001b\u001a\f/1' H`/7?OO\u0002qlxIO`'kz\u001aP\u0019/|?G!";
      K[71] = "\thm_P)Zc(Kj|\u0002`0Y=+]<l5\u0014sSa%V\bq\u000ej";
      K[72] = "?&\u0018\u0007\u0007` {\u0017OwkE\u007fNF\u0018l'!\u0015\u0001\u001elEv\u001dA\u0006o|!\u001cM\t\u0002";
      K[73] = "Wa\u0018xy@K$S0\u000bO:fQqdHX8\n6bH:1\bibJJ/\u001axs&";
      K[74] = "giI_[:xz\tM$6vh\u0015UH\u0004'-J\u000e\u0014Se/IPV8\u007fmL[$={w\u001c^T#if\r2";
      K[75] = "|D\nhM\u0002/OO|wWwLWn \u0000(\u0011\f\u0002N\u0000)Z\nr\r[.DB";
      K[76] = "(>(f|&|>\u007f|\u0013't<vz\u007f\u0015'x),\u0013y`$,tc\u007fb1.\u001d";
      K[77] = "6fsV+j*#8\u001eYa[a:_6b9?a\u00180b[b\u007fK!s\"\"h\u001a:\f";
      K[78] = "\u001d>%IEj\u000f>b^,`~`$HCc\u001c>\u007f\u000fEc~7}PEa\u000e)oAT\r";
      K[79] = "\u0011x92\u000ekC{tn59/{rvZ>M%)1\\>/{qf_;A| 2N,/";
      K[80] = "F(^\u007fM_\u0018t\u000bm1R\u007fq\u0003v^U\u001d/X1XU\u007frFbID\u00062Q3R;";
      K[81] = "43\u001dh{j<$X5\n|h*l(g~cVQ,jr\u007f2[5:\u0013";
      K[82] = "^ Kp]\u0004\n \u001cj2\u0005\u0002\"\u0015l^7QgL62Z\u00131\rtK\u001a\u0004`\u0016\u000b";
      K[83] = "xV/M>1*Ub\u0011\u0005gFUd\tjd$\u000b?NldF\\7\u000etg\u007f\u000b6\u0002{\n";
      K[84] = "8\u0012}i\u00016.\u0017l\u0017\u000fI'\u0015tv\u001f--\f$\u0017";
      K[85] = "/<|\u001b,u){yZ\\u)|#G0Gx<s\u0011\\b:`\"Z8h#0C";
      K[86] = "a|Rid\u0012g~Gk\r\u00077yV4a5e4\u000eb\r^db](7Z\"iJS";
      K[87] = "W\u0000(h:}_\u0017m5K[&$J\u001fK5\u0003[,#2=\u0014\u001eq";
      K[88] = "TzC\u0006LK\u0006y\u000eZw\u000bjy\bB\u0018\u001e\b'S\u0005\u001e\u001ej.QZ\u001e\u001c\u001a0CK\u000fp";
      K[89] = "o*\u0002\fql:c\u000bGOpp\"yO,\"xf\b\\\u007f&zZ\u000b^pe<+\u0018\rtg\u0000";
      K[90] = ".#\u000fH\u000eq8&\u001e6\u0001\u000e1$\u0006W\u0010j;=V6";
      K[91] = "@\u0017b\u0006\u000e0\u0012\u0014/Z5e~\u0014)BZe\u001cJr\u0005\\e~\u0017lVMt\u0007W{\u0007V\u000b";
      K[92] = "'\tA9\u0016\u0000u\n\fe-A\u0019\n\n}BU{TQ:DU\u0019]SeDWiCAtU;";
      K[93] = "}[$\u0013O\b)[s\t \t!Yz\u000fL;s\u001f$Q \\&Yk\u0005\u0019\u000b'Udh\u0010\u00060TwQG\u0007<[\u001a";
      K[94] = "\u0000'P4Y=S,\u0015 ch\u000b/\r24?UxU^RxT9\u0006:\u0006x\u0003#";
      K[95] = "zj\u0001\u0004=#(iLX\u0006sDiJ@iv&7\u0011\u0007ovD`\u0019Gwu}7\u0018Kx\u0018";
      K[96] = "n\u007fq/;A;6xd\u0005U`i\nl{P`unfb\u0000\u0001}t~dJewm.\u0005B\u007fokdaHf?\n";
      K[97] = "x/X\u000f\bn,/\u000f\u0015go$-\u0006\u0013\u000b]vj[Kgc)k\u001e\t\u0018e)2Xt";
      K[98] = "\u001fMX\\\u001fI\u0000^\u0018N`E\u000eL\u0004V\fw_\t[\f[ \u001d\u000bXS\u0012K\u0007I]X`";
      K[99] = "?\u001dU\u0019\"\u0016k\u001d\u0002\u0003M\u0017c\u001f\u000b\u0005!%0[PZMIw\u0007Q\u000b=Ou\u0012Sb";
      K[100] = "X\u001b\u0014\fl\u0011\n\u0018YPWVf\u0018_H8D\u0004F\u0004\u000f>DfO\u0006P>F\u0016Q\u0014A/*";
      K[101] = "Hg\b\u001a\u0005G\u0012y\u000e\u0016oL.9J\u0006\u0000NLg\u0011A\u0006N.1\u0016CUQW9\u0001\u0006\b ";
      K[102] = "/cJ\u0016\u0002yq?\u001f\u0004~z\u0016:\u0017\u001f\u0011stdLX\u0017s\u00169R\u000b\u0006boyEZ\u001d\u001d";
      K[103] = "\u0003s;2$\u0013\u0019eo7T\t\u0016w7/8;D4huTW\u0002om!$Q\u0000zoH-\u001c\u00175m/.\u000f\u00067W:*\f\u001aq303\\{";
      K[104] = "L\u0010\u001fg\u00043\u0019Y\u0016,:'J\u0010dfP>R\r]1Q2]`T<F3NY\u0003=J<#P\u000e*K/\u001a\u0007\u000f&DB";
      K[105] = "\rJ\u0014S\b\u0001\u0005]Q\u000ey\u0017QS`\r\u0004\u0015<]T\t\u0018\u0002XWMYy";
      K[106] = "\u0006\f6#\u001dPP\u0010~\"y\nmUw9\u0016\u000e\u000f\u000b,~\u0010\u000em\\$>\b\rT\u000b%2\u0007`";
      K[107] = "#\u001f\u0000]<4q\u001cM\u0001\u0007c\u001d\u001cK\u0019ha\u007fB\u0010^na\u001d\u0015\u0018\u001evb$B\u0019\u0012y\u000f";
      K[108] = "e<xbh-c<!$\u00157a \"}y\u00053mz'\u0015iu8xseow-z\u001a%8p-/#r9|\"B*\u007f.}1{}~\"r\\";
      K[109] = " zZ\u0003xOtz\r\u0019\u0017N|x\u0004\u001f{|/<XG\u0017\u0010h`^\u0011g\u0016ju\\x";
      K[110] = "5\u0005\u001f\u0012\\W&QOW$Z+V\u0010\u0006s\rz\u0002IS$KtP\f\u0012GX \u0000I";
      K[111] = ".gReturningVoid(z\b\u001ezg\u007f`g\u001frevf\u000b-!!*1g\bayw{\u0003\u0002x)\u0016";
      K[112] = "(w{G\u0006Wzt6\u001b=\u0006\u0016t0\u0003R\u0002t*kDT\u0002\u0016|lF\u0007\u001dot{\u0003Zl";
      K[113] = "\u000ei*8\u001aT\\h,!d\u000fl;s>\u000b\n\u000ee(y\r\nll*&\r\b\u001cr87\u001cd";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3157178939449102L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3157178939449102L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3157178939449102L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 251;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 254;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 196;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 237;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 107;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 106;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 251;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 254;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 196;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b3",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b3" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
