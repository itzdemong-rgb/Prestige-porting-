package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.events.CrosshairRenderEvent;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.GameRenderUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.joml.Matrix4f;

public class CrosshairWidget extends HudElement {
   private long a;
   private float g;
   private static final long v = 26769671289373L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long H;
   private static final Object[] I = new Object[55];
   private static final String[] J = new String[55];

   public CrosshairWidget(long var1) {
      super("Crosshair", "Modifies the crosshair to a custom one", ((26769671289373L ^ (26769671289373L ^ var1)) ^ 136319314698403L));
      var1 = 26769671289373L ^ var1;
      long var3 = var1 ^ 136319314698403L;
      short var10001 = 18924;
      long var10002 = 7169216114765261543L ^ var1;
      short var6 = 27670;
      long var10003 = 8919112060807630620L ^ var1;

      this.a = H;
      this.g = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      MinecraftClient var6 = b;
      Window var7 = var6.getWindow();
      float var10001 = var7.getScaledWidth() / 2.0F;
      MinecraftClient var8 = b;
      Window var9 = var8.getWindow();
      float var10002 = var9.getScaledHeight() / 2.0F;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = var10002;
      var10005[0] = var10001;
      Object[] var11 = var10005;
      CrosshairWidget var10 = this;
      var10.aReturningVoid(var11);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      Matrix4f var3;
      long var5;
      long var7;
      long var9;
      long var13;
      long var15;
      float var19;
      int var82;
      label44: {
         int var81;
         label43: {
            label47: {
               var3 = (Matrix4f)var1[2];
               var5 = (Long)var1[3];
               var7 = var5 ^ 41197988814736L;
               var9 = var5 ^ 36477842301344L;
               long var11 = var5 ^ 82290774353645L;
               var13 = var5 ^ 3828154620058L;
               var15 = var5 ^ 1462326210748L;
               Object[] var10004 = new Object[]{null, 0.0F};
               var10004[0] = 0.0F;
               Object[] var29 = var10004;
               CrosshairWidget var28 = this;
               var28.iReturningVoid(var29);
               Matrix4f var30 = var3;
               float var10000 = var30.m00();
               Matrix4f var31 = var3;
               var10000 *= var31.m00();
               Matrix4f var32 = var3;
               float var10001 = var32.m01();
               Matrix4f var33 = var3;
               var10000 += var10001 * var33.m01();
               Matrix4f var34 = var3;
               var10001 = var34.m02();
               Matrix4f var35 = var3;
               double var36 = var10000 + var10001 * var35.m02();
               float var18 = (float)Math.sqrt(var36);
               int var132 = Event.bReturningInt();
               MinecraftClient var38 = b;
               Window var39 = var38.getWindow();
               float var10002 = var39.getScaledWidth() / 2.0F / var18;
               MinecraftClient var40 = b;
               Window var41 = var40.getWindow();
               float var10003 = var41.getScaledHeight() / 2.0F / var18;
               Object[] var10006 = new Object[]{null, null, var11};
               var10006[1] = var10003;
               var10006[0] = var10002;
               Object[] var43 = var10006;
               CrosshairWidget var42 = this;
               var42.aReturningVoid(var43);
               int var17 = var132;
               var19 = (float)(System.currentTimeMillis() - this.a) * 0.005F;
               this.a = System.currentTimeMillis();
               MinecraftClient var44 = b;
               HitResult var23 = var44.crosshairTarget;
               int var101 = var17;
               HitResult var100 = var23;
               HitResult var77 = var100;
               HitResult var76 = var100;
               if (var101 == 0) {
                  boolean var102 = var76 instanceof EntityHitResult;
                  if (!var102) {
                     break label47;
                  }

                  HitResult var103 = var23;
                  var77 = var103;
               }

               EntityHitResult var22 = (EntityHitResult)var77;
               EntityHitResult var47 = var22;
               Entity var128 = var47.getEntity();
               int var105 = var17;
               Entity var104 = var128;
               Entity var79 = var104;
               Entity var78 = var104;
               if (var105 == 0) {
                  boolean var106 = var78 instanceof LivingEntity;
                  if (!var106) {
                     break label47;
                  }

                  Entity var107 = var128;
                  var79 = var107;
               }

               LivingEntity var21 = (LivingEntity)var79;
               LivingEntity var50 = var21;
               int var109 = var17;
               int var108 = var50.hurtTime;
               var81 = var108;
               int var80 = var108;
               if (var109 != 0) {
                  break label43;
               }

               int var110 = var80;
               if (var110 > 0) {
                  var81 = 1;
                  break label43;
               }
            }

            var82 = 0;
            break label44;
         }

         int var111 = var81;
         var82 = var111;
      }

      int var20 = var82;
      int var114 = var20;
      float var113 = this.g;
      CrosshairWidget var112 = this;
      CrosshairWidget var85 = var112;
      float var86 = var113;
      CrosshairWidget var83 = var112;
      float var84 = var113;
      CrosshairWidget var87;
      float var88;
      float var89;
      if (var114 != 0) {
         float var117 = 1.0F;
         float var116 = var84;
         CrosshairWidget var115 = var83;
         var87 = var115;
         var88 = var116;
         var89 = var117;
      } else {
         var89 = 0.0F;
         var88 = var86;
         var87 = var85;
      }

      int var121 = var20;
      float var120 = var89;
      float var119 = var88;
      CrosshairWidget var118 = var87;
      CrosshairWidget var93 = var118;
      float var94 = var119;
      float var95 = var120;
      CrosshairWidget var90 = var118;
      float var91 = var119;
      float var92 = var120;
      CrosshairWidget var96;
      float var97;
      float var98;
      float var99;
      if (var121 != 0) {
         float var125 = var19 * 3.0F;
         float var124 = var92;
         float var123 = var91;
         CrosshairWidget var122 = var90;
         var96 = var122;
         var97 = var123;
         var98 = var124;
         var99 = var125;
      } else {
         var99 = var19;
         var98 = var95;
         var97 = var94;
         var96 = var93;
      }

      Object[] var151 = new Object[]{null, null, null, var7};
      var151[2] = var99;
      var151[1] = var98;
      var151[0] = var97;
      Object[] var54 = var151;
      var96.g = ClientUiUtil.bReturningFloat(var54);
      double var55 = System.currentTimeMillis() * 0.003;
      float var126 = ((float)Math.sin(var55) + 1.0F) * 0.5F;
      Object[] var57 = new Object[]{var9};
      Color var127 = ClientUiUtil.dReturningColor(var57);
      Color var58 = var127;
      int var138 = var58.getRed();
      int var141 = 785;
      long var147 = 2018165766146133466L ^ var5;
      Color var59 = var127;
      var138 += (int)((255 - var59.getRed()) * this.g);
      Color var60 = var127;
      var141 = var60.getGreen();
      short var148 = 25344;
      long var10005 = 4302786851717115336L ^ var5;
      Color var61 = var127;
      var141 += (int)((255 - var61.getGreen()) * this.g);
      Color var62 = var127;
      int var149 = var62.getBlue();
      short var150 = 25344;
      long var152 = 4302786851717115336L ^ var5;
      Color var63 = var127;
      Color var129 = new Color(var138, var141, var149 + (int)((255 - var63.getBlue()) * this.g));
      short var133 = 25344;
      float var24 = this.e - 0.5F;
      long var136 = 4302786851717115336L ^ var5;
      float var25 = this.f - 0.5F;
      float var26 = 1.5F + var126 * 0.3F + this.g * 1.25F;
      var133 = 255;
      short var137 = 24590;
      long var140 = 3701296212684762820L ^ var5;
      float var144 = var126 * 0.5F;
      float var65 = this.g;
      float var64 = var144;
      int var67 = 190 + (int)(65.0F * Math.max(var64, var65));
      int var27 = Math.min(255, var67);
      short var10009 = 24142;
      long var10010 = 3434900517856596097L ^ var5;
      Object[] var10007 = new Object[]{null, null, null, null, new Color(0, 0, 0, 90), var13};
      var10007[3] = 0.9F;
      var10007[2] = var25;
      var10007[1] = var24;
      var10007[0] = var3;
      Object[] var68 = var10007;
      GameRenderUtil.cReturningVoid(var68);
      var10007 = new Object[]{null, null, null, null, var129, var13};
      var10007[3] = 0.5F;
      var10007[2] = var25;
      var10007[1] = var24;
      var10007[0] = var3;
      Object[] var69 = var10007;
      GameRenderUtil.cReturningVoid(var69);
      float var145 = var26 - 0.5F;
      var10009 = 28528;
      var10010 = 2546814290756166073L ^ var5;
      var10007 = new Object[]{null, null, null, null, new Color(0, 0, 0, 60), var15};
      var10007[3] = var145;
      var10007[2] = var25;
      var10007[1] = var24;
      var10007[0] = var3;
      Object[] var70 = var10007;
      GameRenderUtil.eReturningVoid(var70);
      float var146 = var26 + 0.5F;
      var10009 = 16206;
      var10010 = 604917494939922816L ^ var5;
      var10007 = new Object[]{null, null, null, null, new Color(0, 0, 0, 60), var15};
      var10007[3] = var146;
      var10007[2] = var25;
      var10007[1] = var24;
      var10007[0] = var3;
      Object[] var71 = var10007;
      GameRenderUtil.eReturningVoid(var71);
      Color var72 = var129;
      int var153 = var72.getRed();
      Color var73 = var129;
      int var157 = var73.getGreen();
      Color var74 = var129;
      var10007 = new Object[]{null, null, null, null, new Color(var153, var157, var74.getBlue(), var27), var15};
      var10007[3] = var26;
      var10007[2] = var25;
      var10007[1] = var24;
      var10007[0] = var3;
      Object[] var75 = var10007;
      GameRenderUtil.eReturningVoid(var75);
   }

   @EventListener
   public void a(CrosshairRenderEvent var1) {
      Object[] var5 = new Object[0];
      CrosshairRenderEvent var4 = var1;
      var4.aReturningVoid(var5);
   }

   static {

      {

      b();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(73596338118161L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[2];
      String var22 = "Ðõ8¥\u0004\u0007\u0093\u008b9\u009b¹\u008a¹\u0084BÈên\u0013t¯¯\u001a\bã¬Aa®8¯\u0093Ô4L\\ã\u000b=A±nýÈØ\u00ad.\u0007\u007fõ\u0086©l\u0090Ç\u009eS\u0091\t¾RfB÷\u0018\u0085¬A\u0002Ù\u0091/·ýÜ\u0005C4\r\fb\u0082x8\u0089}3äE";
      int var24 = "Ðõ8¥\u0004\u0007\u0093\u008b9\u009b¹\u008a¹\u0084BÈên\u0013t¯¯\u001a\bã¬Aa®8¯\u0093Ô4L\\ã\u000b=A±nýÈØ\u00ad.\u0007\u007fõ\u0086©l\u0090Ç\u009eS\u0091\t¾RfB÷\u0018\u0085¬A\u0002Ù\u0091/·ýÜ\u0005C4\r\fb\u0082x8\u0089}3äE"
         .length();
      char var21 = '@';
      int var20 = -1;

      while (true) {
         byte[] var26 = var18.doFinal(var22.substring(++var20, var20 + var21).getBytes("ISO-8859-1"));
         String var38 = b(var26).intern();
         int var10001 = -1;
         var25[var23++] = var38;
         if ((var20 += var21) >= var24) {
            w = var25;
            x = new String[2];
            D = new HashMap(13);
            Cipher var5;
            var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var6 = 1; var6 < 8; var6++) {
               var10003[var6] = (byte)(73596338118161L << var6 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var11 = new long[6];
            String var9 = "©_8.\t\u0003g`spdY\u0081\u0011\u001dÔåÓº½\u0006Îê\u0096\u001a\f\u0017yiBqÝ";
            int var10 = "©_8.\t\u0003g`spdY\u0081\u0011\u001dÔåÓº½\u0006Îê\u0096\u001a\f\u0017yiBqÝ".length();
            label42:
            while (true) {
               var10001 = var7;
               var7 += 8;
               byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
               long[] var30 = var11;
               var10001 = var8++;
               long var41 = (var12[0] & 255L) << 56
                  | (var12[1] & 255L) << 48
                  | (var12[2] & 255L) << 40
                  | (var12[3] & 255L) << 32
                  | (var12[4] & 255L) << 24
                  | (var12[5] & 255L) << 16
                  | (var12[6] & 255L) << 8
                  | var12[7] & 255L;
               
                  long var13 = var41;
                  byte[] var15 = var5.doFinal(
                     new byte[]{
                        (byte)(var13 >>> 56),
                        (byte)(var13 >>> 48),
                        (byte)(var13 >>> 40),
                        (byte)(var13 >>> 32),
                        (byte)(var13 >>> 24),
                        (byte)(var13 >>> 16),
                        (byte)(var13 >>> 8),
                        (byte)var13
                     }
                  );
                  long var49 = (var15[0] & 255L) << 56
                     | (var15[1] & 255L) << 48
                     | (var15[2] & 255L) << 40
                     | (var15[3] & 255L) << 32
                     | (var15[4] & 255L) << 24
                     | (var15[5] & 255L) << 16
                     | (var15[6] & 255L) << 8
                     | var15[7] & 255L;
                  switch (var46) {
                     case 0:
                        var30[var10001] = var49;
                        if (var7 >= var10) {
                           B = var11;
                           C = new Integer[6];
                           Cipher var0;
                           var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                           var10002 = SecretKeyFactory.getInstance("DES");
                           var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                           for (int var1 = 1; var1 < 8; var1++) {
                              var10003[var1] = (byte)(73596338118161L << var1 * 8 >>> 56);
                           }

                           var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                           long var36 = 7463955161171382553L;
                           byte[] var4 = var0.doFinal(
                              new byte[]{
                                 (byte)103L,
                                 (byte)26517L,
                                 (byte)6788427L,
                                 (byte)1737837484L,
                                 (byte)444886396001L,
                                 (byte)113890917376272L,
                                 (byte)29156074848325713L,
                                 (byte)7463955161171382553L
                              }
                           );
                           long var44 = (var4[0] & 255L) << 56
                              | (var4[1] & 255L) << 48
                              | (var4[2] & 255L) << 40
                              | (var4[3] & 255L) << 32
                              | (var4[4] & 255L) << 24
                              | (var4[5] & 255L) << 16
                              | (var4[6] & 255L) << 8
                              | var4[7] & 255L;
                           
                           break;
                        }
                        break;
                     default:
                        var30[var10001] = var49;
                        if (var7 < var10) {
                           continue label42;
                        }

                        var9 = "6Èô¥\u009aãN]H>\u0086ß\u0084\u0090ÊÒ";
                        var10 = "6Èô¥\u009aãN]H>\u0086ß\u0084\u0090ÊÒ".length();
                        var7 = 0;
                  }

                  int var35 = var7;
                  var7 += 8;
                  var12 = var9.substring(var35, var7).getBytes("ISO-8859-1");
                  var30 = var11;
                  var10001 = var8++;
                  var41 = (var12[0] & 255L) << 56
                     | (var12[1] & 255L) << 48
                     | (var12[2] & 255L) << 40
                     | (var12[3] & 255L) << 32
                     | (var12[4] & 255L) << 24
                     | (var12[5] & 255L) << 16
                     | (var12[6] & 255L) << 8
                     | var12[7] & 255L;
                  var46 = 0;
               }
            }
         }

         var21 = var22.charAt(var20);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5203;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b4", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b4",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19801;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b4", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b4",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = J[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = I[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 35;
            yield var15;
         }
         case 1 -> {
            byte var16 = 5;
            yield var16;
         }
         case 2 -> {
            byte var17 = 17;
            yield var17;
         }
         case 3 -> {
            byte var18 = 57;
            yield var18;
         }
         case 4 -> {
            byte var19 = 45;
            yield var19;
         }
         case 5 -> {
            byte var20 = 54;
            yield var20;
         }
         case 6 -> {
            byte var21 = 49;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 34;
            yield var24;
         }
         case 10 -> {
            byte var25 = 26;
            yield var25;
         }
         case 11 -> {
            byte var26 = 3;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 20;
            yield var28;
         }
         case 14 -> {
            byte var29 = 27;
            yield var29;
         }
         case 15 -> {
            byte var30 = 48;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 36;
            yield var32;
         }
         case 18 -> {
            byte var33 = 19;
            yield var33;
         }
         case 19 -> {
            byte var34 = 30;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 18;
            yield var36;
         }
         case 22 -> {
            byte var37 = 50;
            yield var37;
         }
         case 23 -> {
            byte var38 = 41;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 31;
            yield var41;
         }
         case 27 -> {
            byte var42 = 7;
            yield var42;
         }
         case 28 -> {
            byte var43 = 61;
            yield var43;
         }
         case 29 -> {
            byte var44 = 22;
            yield var44;
         }
         case 30 -> {
            byte var45 = 40;
            yield var45;
         }
         case 31 -> {
            byte var46 = 25;
            yield var46;
         }
         case 32 -> {
            byte var47 = 33;
            yield var47;
         }
         case 33 -> {
            byte var48 = 10;
            yield var48;
         }
         case 34 -> {
            byte var49 = 32;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 37;
            yield var52;
         }
         case 38 -> {
            byte var53 = 0;
            yield var53;
         }
         case 39 -> {
            byte var54 = 53;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 23;
            yield var56;
         }
         case 42 -> {
            byte var57 = 24;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 28;
            yield var59;
         }
         case 45 -> {
            byte var60 = 16;
            yield var60;
         }
         case 46 -> {
            byte var61 = 11;
            yield var61;
         }
         case 47 -> {
            byte var62 = 2;
            yield var62;
         }
         case 48 -> {
            byte var63 = 46;
            yield var63;
         }
         case 49 -> {
            byte var64 = 63;
            yield var64;
         }
         case 50 -> {
            byte var65 = 59;
            yield var65;
         }
         case 51 -> {
            byte var66 = 62;
            yield var66;
         }
         case 52 -> {
            byte var67 = 43;
            yield var67;
         }
         case 53 -> {
            byte var68 = 9;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 52;
            yield var70;
         }
         case 56 -> {
            byte var71 = 51;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 15;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 21;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 29;
            yield var77;
         }
         default -> 58;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            J[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      I[0] = "\u000b\u0010\"P5\u007f\u001d\u0010'\n&h\n[$\f*|\u001b\u001c3\u001bak\u0018";
      I[1] = "e\u0007-+)m\u0010'&$8\"q)-/<x\u0005";
      I[2] = void.class;
      J[2] = "java/lang/Void";
      I[3] = "H\u0000,8\u0017v^\u0000)b\u0004aIK*d\buX\f=sCgi";
      I[4] = int.class;
      J[4] = "java/lang/Integer";
      I[5] = "r\u0018NC>ky\u0017_\f]fl\u0011";
      I[6] = double.class;
      J[6] = "java/lang/Double";
      I[7] = "\u0013\u0001KvGQf!@yV\u001e\u0007/KrRDs";
      I[8] = "NpK\u0000z;Np\\\\v4T;\\Bv!SJ\u000e\u001e#c";
      I[9] = "'\\>pK\u001c,S/?6\t>I-|";
      I[10] = long.class;
      J[10] = "java/lang/Long";
      I[11] = "gLyx1\u0005qL|\"\"\u0012f\u0007\u007f$.\u0006w@h3e\u00172";
      I[12] = "Y&R\n^-,\u0006Y\u0005ObM\bR\u000eK89";
      I[13] = ";X(av\u0019;X?=z\u0016!\u0013?#z\u0003&bm|+I";
      I[14] = "\u0002W&n\u0002X\u0014W#4\u0011O\u0003\u001c 2\u001d[\u0012[7%VJR";
      I[15] = "@rnz(\u0005K}\u007f5K\b^pp^~\nOclri\u0007";
      I[16] = "\u0016\u0000on;7\u0016\u0000x278\fKx,7-\u000b:(qf";
      I[17] = "F\u0001cI\u0010d[\u0014;kQiC\u0012";
      I[18] = "\u0001eP>l]\u0003{\u0019]gF\u001c~O$`";
      I[19] = float.class;
      J[19] = "java/lang/Float";
      I[20] = "%BZ:Md3B_`^s$\t\\fRg5NKq\u0019u\u0003";
      I[21] = "84O,VXM\u0014D#G\u0017,\u001aO(CMX";
      I[22] = "r5/-v\u0017r58qz\u0018h~8oz\ro\u000fi0\"";
      I[23] = "MZA+b[8zJ$s\u0014YtA/wN-";
      I[24] = "6x6ihd6x!5dk,3!+d~+Bq~3;";
      I[25] = "u\u0005L=+Nu\u0005[a'AoN[\u007f'Th?\t!\u007f\u0010";
      I[26] = "Wbpj{p\"B{ej?CLpnne7";
      I[27] = "SH\u0013Tt\u001a&h\u0018[eUGf\u0013Pa\u000f3";
      I[28] = "6\f\u000f_UB=\u0003\u001e\u00104L6\b\u001aJ";
      I[29] = "GeW\u000eF\u000e\u0018`WaTkD\"\u0003[R\u0011G7A\u00199R\\e\u000eP\u0005P_8Ta";
      I[30] = "{\u0015\u0003ZSf;\u0007\u0013\u0001:<ADR\u000b^.?\u0010\u0018\\^V";
      I[31] = "9VQ\u0019\u0015pc\t\u0004QelcS:W\n{eV^\u0011\u0017.z5\u0006\u0004\tpaQ@\u0019\\o\u0002";
      I[32] = "~t*Al-!q*.xH}3~\u0014x2~&<V\u0013qets\u001f/sf)).";
      I[33] = "\u0015e+D\u000bK\u0011f$DmLEb&H\u0001~\u0014#~\u0015m\u0012\u0010r\"W\u0013FZ%\"/";
      I[34] = "xgZ.^X#d\u0001}!\u0002;x\u001a-G\u0015\u001ac\u0005-d\b\"f\u0001;!V-3\u0002xN\u0015;o\u001c@";
      I[35] = "#mP\u0000{R):Z\u001bFB\u0013eHX|Hif]\u001a>#*}\u000fUw\u001f(~R\u000fF";
      I[36] = "\u001a\u0011i\u0005\u0006]A\u0007y_yPJ\u0017tS.\u0000\u0011A-?B\u0006G\u001ehA\u0016L\u0010\u001e";
      I[37] = "\u0001\u0006\\M\\J\u0001\u000fF\u000b!\u001dh\u0006\\\u0015Z\u0005S\u000eC\u0019Dt\u0001\u001fI\u000bPO\t\u0000E\u0015!";
      I[38] = "\u0005W8pY*EE(+0s?\\(p\nqE_=2H\u001a\u0006Do}\u0001&\u0004G2'0";
      I[39] = "I+\u00110@\u0000\u0013tDx0\u001c\u000b2\u0006B\f\b\u001e/\u0019&J\u0015K0z~_\u000b\u0015+\u001e8B^\nH";
      I[40] = "\u0016\u0002\u0007B[8C\u0015S\u001f*4\u0011\u0014\bHF\u0006FRV\u001f\u0011QA\u0013\u0005DL3E\u0010\nD*";
      I[41] = "+\u0019\u0016kp\bqFC#\u0000\nq\u001c}\"8\u0003t\u0002\u0003vrTtzF!l\u000bh\u0004\u0012k;\u000b\u0010AEud\u0017n\u0015\u000f\"do";
      I[42] = "pckd4* 9woJ;v%Sh&T aea2*t+2aJ";
      I[43] = "w\u0007u\f\n'`\u00054\u00176<$B\n\nJ(p\u0001s\u001fQ$xz";
      I[44] = "V\u001d\f*\u0005|A\u001fM19g\u0005Zs,EsQ\u001b\n9^\u007fY`";
      I[45] = "\u0016\u0005Z>!\u000f\u0010\u001fP2\u0010\u0019z\u0015Q\u007f*\u001e\u0000\u0016D=hu\u0011NJ#n\u000bA\u0014V(\u0010";
      I[46] = "Q/ifM6\u000bp<.=4\u0003<\u0002xA \u00067{mZ,\u000eLnhL=\u00115{s@5j ~eQ*\u00135eiYQ";
      I[47] = "\r\u0000\u000fsp\u001b]Z\u0013x\u000e\n\u000bF'vs\bf\u0001U~j\u001d\u0018U\u001f)je";
      I[48] = "yEmK|u,R9\u0016\rrrBfJZ%,\u0011?&cxtAeK0#.^";
      I[49] = "\fMLE+)\u0006\u001aF^\u00161<ET\u001d,3FFA_nX\u0005]\u0013\u0010'd\u0007^NJ\u0016";
      I[50] = " \u0007`2R0|L*8<0-K0;P\u0002y\bol\u0006U I<2@2-\u0006m#<";
      I[51] = "\u00012&\u001e\u001fp\u0007(,\u0012.`m\"-_\u0014a\u0017!8\u001dV\n\u0001?%\u000eUs\u0014$)\u0006.";
      I[52] = "\u0017T7\"=A\u0000Vv9\u0001ZD\u0010H$}N\u0010R11fB\u0018)";
      I[53] = "\u0001`h%\b\u0004\u0005cg%n\u0003Qge)\u00021\u0000'5pn]\u0004wa6\u0010\tN aN";
      I[54] = "\u000b#tB\bl[yhIv}\reYY\u001b\u007f\u0006\u0019-\u001b\u001av\u0018gyQMv`";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = I[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(J[var4]);
            I[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            I[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  I[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(2036715723920862L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  I[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(2036715723920862L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        I[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(2036715723920862L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 234;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 71;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 251;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 237;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 165;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 79;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 234;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 71;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 251;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b4",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
