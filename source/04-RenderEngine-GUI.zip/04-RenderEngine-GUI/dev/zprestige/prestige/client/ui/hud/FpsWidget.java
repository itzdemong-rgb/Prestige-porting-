package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;

public class FpsWidget extends HudElement {
   private static final int a;
   private static final long c;
   private ManagedGlTexture d;
   private final float[] g;
   private int h;
   private long i;
   private long j;
   private float k;
   private float l;
   private float o;
   private float p;
   private float t;
   private static final long v = 107701258810685L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[75];
   private static final String[] L = new String[75];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public FpsWidget(long var1) {
      super("FPS", "Show the client's fps", ((107701258810685L ^ (107701258810685L ^ var1)) ^ 80265868346726L));
      var1 = 107701258810685L ^ var1;
      long var3 = var1 ^ 80265868346726L;
      short var10001 = 88;
      long var10002 = 1259565344682829475L ^ var1;
      short var7 = 11856;
      long var10003 = 5759775344297658542L ^ var1;

      var10001 = 32206;
      var10002 = 8178899632622496594L ^ var1;
      this.g = new float[24];
      this.h = 0;
      this.i = invokeBinding1(20492, 8368276008173609150L ^ var1);
      this.j = invokeBinding2(4721, 8857124841255854786L ^ var1);
      this.k = -1.0F;
      this.l = -1.0F;
      this.t = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 23.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      FpsWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      long var2;
      Matrix4f var4;
      MeshBufferManager var5;
      RenderContext var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var27;
      int var31;
      label161: {
         var5 = (MeshBufferManager)var1[0];
         var6 = (RenderContext)var1[1];
         var4 = (Matrix4f)var1[2];
         var2 = (Long)var1[3];
         var7 = var2 ^ 49928519994039L;
         var9 = var2 ^ 41197988814736L;
         var11 = var2 ^ 48887442607471L;
         var13 = var2 ^ 124694493719688L;
         var15 = var2 ^ 81054074941871L;
         var17 = var2 ^ 36477842301344L;
         var19 = var2 ^ 13608202459885L;
         var21 = var2 ^ 29307267718371L;
         var23 = var2 ^ 113406911627307L;
         var25 = var2 ^ 54485265248081L;
         var27 = var2 ^ 17083579563515L;
         long var29 = var2 ^ 56760183293883L;
         var31 = Event.bReturningInt();
         int var186 = var31;
         FpsWidget var185 = this;
         FpsWidget var150 = var185;
         FpsWidget var149 = var185;
         if (var186 == 0) {
            ManagedGlTexture var187 = var149.d;
            if (var187 != null) {
               break label161;
            }

            FpsWidget var188 = this;
            var150 = var188;
         }

         short var10001 = 18149;
         long var10002 = 6611619382794318103L ^ var2;
         Object[] var73 = new Object[]{"assets/prestige/icons/hud/fps.png", var29};
         var150.d = TextureLoader.aReturningbT_C0095(var73);
      }

      MinecraftClient var74 = b;
      int var32 = var74.getCurrentFps();
      long var33 = System.currentTimeMillis();
      float var35 = (float)(var33 - this.j) * 0.005F;
      int var190 = var31;
      FpsWidget var189 = this;
      FpsWidget var152 = var189;
      FpsWidget var151 = var189;
      if (var190 == 0) {
         var151.j = var33;
         long var310;
         int var191 = (var310 = var33 - this.i - invokeBinding3(12382, 9016914058645606880L ^ var2)) == 0L ? 0 : (var310 < 0L ? -1 : 1);
         if (var191 >= 0) {
            this.g[this.h] = var32;
            int var269 = this.h + 1;
            short var280 = 13624;
            long var10003 = 3338805921261777582L ^ var2;
            this.h = var269 % 24;
            this.i = var33;
         }

         var152 = this;
      }

      FpsWidget var162;
      float var163;
      label154: {
         int var195 = var31;
         float var194 = 0.0F;
         float var193 = this.k;
         FpsWidget var192 = var152;
         FpsWidget var159 = var192;
         float var160 = var193;
         float var161 = var194;
         FpsWidget var153 = var192;
         float var154 = var193;
         float var155 = var194;
         if (var195 == 0) {
            float var311;
            int var197 = (var311 = var154 - var155) == 0.0F ? 0 : (var311 < 0.0F ? -1 : 1);
            FpsWidget var196 = var153;
            FpsWidget var158 = var196;
            FpsWidget var156 = var196;
            if (var197 < 0) {
               FpsWidget var198 = var156;
               FpsWidget var157 = var198;
               float var200 = var32;
               FpsWidget var199 = var157;
               var162 = var199;
               var163 = var200;
               break label154;
            }

            var161 = var32;
            var160 = this.k;
            var159 = var158;
         }

         float var291 = var35 * 0.5F;
         Object[] var10006 = new Object[]{null, null, null, var9};
         var10006[2] = var291;
         var10006[1] = var161;
         var10006[0] = var160;
         Object[] var79 = var10006;
         var163 = ClientUiUtil.bReturningFloat(var79);
         var162 = var159;
      }

      label148: {
         var162.k = var163;
         float var10000 = this.k;
         Object[] var292 = new Object[]{null, var25};
         var292[0] = var10000;
         Object[] var80 = var292;
         Color var36 = aReturningColor(var80);
         int var202 = var31;
         FpsWidget var201 = this;
         FpsWidget var165 = var201;
         FpsWidget var164 = var201;
         if (var202 == 0) {
            float var312;
            int var203 = (var312 = var164.l - 0.0F) == 0.0F ? 0 : (var312 < 0.0F ? -1 : 1);
            if (var203 < 0) {
               Color var82 = var36;
               this.l = var82.getRed();
               Color var83 = var36;
               this.o = var83.getGreen();
               Color var84 = var36;
               this.p = var84.getBlue();
               int var204 = var31;
               if (var204 == 0) {
                  break label148;
               }
            }

            float var270 = this.l;
            Color var86 = var36;
            float var281 = var86.getRed();
            Object[] var301 = new Object[]{null, null, null, var9};
            var301[2] = var35;
            var301[1] = var281;
            var301[0] = var270;
            Object[] var87 = var301;
            this.l = ClientUiUtil.bReturningFloat(var87);
            var270 = this.o;
            Color var88 = var36;
            var281 = var88.getGreen();
            var301 = new Object[]{null, null, null, var9};
            var301[2] = var35;
            var301[1] = var281;
            var301[0] = var270;
            Object[] var89 = var301;
            this.o = ClientUiUtil.bReturningFloat(var89);
            FpsWidget var205 = this;
            var165 = var205;
         }

         float var272 = this.p;
         Color var91 = var36;
         float var283 = var91.getBlue();
         Object[] var303 = new Object[]{null, null, null, var9};
         var303[2] = var35;
         var303[1] = var283;
         var303[0] = var272;
         Object[] var92 = var303;
         var165.p = ClientUiUtil.bReturningFloat(var92);
      }

      Color var37;
      String var38;
      float var40;
      float var41;
      float var42;
      float var43;
      float var44;
      float var45;
      float var46;
      float var48;
      float var49;
      boolean var50;
      float var168;
      label141: {
         var37 = new Color((int)this.l, (int)this.o, (int)this.p);
         int var93 = var32;
         var38 = String.valueOf(var93);
         MsdfFontManager var255 = Prestige.c;
         Object[] var95 = new Object[]{var19};
         MsdfFontManager var94 = var255;
         MsdfFont var256 = var94.aReturningcx_C0158(var95);
         Object[] var97 = new Object[]{var7};
         MsdfFont var96 = var256;
         float var39 = var96.cReturningFloat(var97);
         var255 = Prestige.c;
         Object[] var99 = new Object[]{var19};
         MsdfFontManager var98 = var255;
         MsdfFont var258 = var98.aReturningcx_C0158(var99);
         Object[] var101 = new Object[]{var38, var15};
         MsdfFont var100 = var258;
         var40 = var100.aReturningFloat(var101) * 1.0F;
         var255 = Prestige.c;
         Object[] var103 = new Object[]{var19};
         MsdfFontManager var102 = var255;
         MsdfFont var260 = var102.aReturningcx_C0158(var103);
         short var273 = 29858;
         long var284 = 1788224804108911441L ^ var2;
         Object[] var105 = new Object[]{"fps", var15};
         MsdfFont var104 = var260;
         var41 = var104.aReturningFloat(var105) * 0.65F;
         var42 = var39 * 1.0F;
         var43 = var39 * 0.65F;
         var44 = 7.5F;
         var45 = 5.5F + var44 + 5.5F;
         var46 = var45 + 0.5F + 5.5F;
         float var261 = var40 + 3.0F + var41;
         float var107 = 28.0F;
         float var106 = var261;
         float var47 = Math.max(var106, var107);
         var48 = var46 + var47 + 5.5F;
         Object[] var108 = new Object[]{var39};
         var49 = UiMetrics.bReturningFloat(var108);
         Object[] var110 = new Object[0];
         FpsWidget var109 = this;
         var50 = var109.cReturningBoolean(var110);
         MinecraftClient var111 = b;
         boolean var51 = var111.currentScreen instanceof HudEditorScreen;
         int var206 = var31;
         if (var206 == 0) {
            boolean var207 = var50;
            if (var207) {
               int var209 = var31;
               float var208 = this.t;
               var168 = var208;
               float var166 = var208;
               if (var209 != 0) {
                  break label141;
               }

               float var210 = var166;
               float var167 = var210;
               float var313;
               int var211 = (var313 = var167 - 0.0F) == 0.0F ? 0 : (var313 < 0.0F ? -1 : 1);
               if (var211 > 0) {
                  boolean var212 = var51;
                  if (!var212) {
                     this.e = this.e - (var48 - this.t);
                  }
               }
            }

            this.t = var48;
         }

         var168 = this.e;
      }

      float var52 = var168;
      float var53 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var11};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var49;
      var10011[5] = var48;
      var10011[4] = var53;
      var10011[3] = var52;
      var10011[2] = var4;
      var10011[1] = var6;
      var10011[0] = var5;
      Object[] var117 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var117);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var21};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var49;
      var10011[5] = var48;
      var10011[4] = var53;
      var10011[3] = var52;
      var10011[2] = var4;
      var10011[1] = var6;
      var10011[0] = var5;
      Object[] var118 = var10011;
      FilledRectangleRenderer.cReturningVoid(var118);
      Object[] var119 = new Object[]{var17};
      Color var54 = ClientUiUtil.dReturningColor(var119);
      boolean var213 = var50;
      float var169;
      if (var213) {
         float var214 = var52 + var48 - 5.5F - var44;
         var169 = var214;
      } else {
         var169 = var52 + 5.5F;
      }

      float var55 = var169;
      boolean var215 = var50;
      float var170;
      if (var215) {
         float var216 = var52 + var48 - var45 - 0.5F;
         var170 = var216;
      } else {
         var170 = var52 + var45;
      }

      float var57;
      float var58;
      float var59;
      label132: {
         float var56 = var170;
         ManagedGlTexture var293 = this.d;
         float var10005 = var53 + var49 / 2.0F - var44 / 2.0F;
         var10011 = new Object[]{null, null, null, null, null, null, null, null, var54, var27};
         var10011[7] = var44;
         var10011[6] = var44;
         var10011[5] = var10005;
         var10011[4] = var55;
         var10011[3] = var293;
         var10011[2] = var4;
         var10011[1] = var6;
         var10011[0] = var5;
         Object[] var122 = var10011;
         TexturedRectangleRenderer.cReturningVoid(var122);
         float var285 = var53 + 3.0F;
         float var294 = var56 + 0.5F;
         float var10004 = var53 + var49 - 3.0F;
         Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var13};
         var10008[4] = var10004;
         var10008[3] = var294;
         var10008[2] = var285;
         var10008[1] = var56;
         var10008[0] = var4;
         Object[] var123 = var10008;
         ShapeRenderer.lReturningVoid(var123);
         var57 = var53 + 3.0F;
         boolean var217 = var50;
         if (var217) {
            float var60 = var52 + var48 - var46;
            var59 = var60 - var41;
            var58 = var59 - 3.0F - var40;
            int var218 = var31;
            if (var218 == 0) {
               break label132;
            }
         }

         var58 = var52 + var46;
         var59 = var58 + var40 + 3.0F;
      }

      MsdfFontManager var262 = Prestige.c;
      Object[] var125 = new Object[]{var19};
      MsdfFontManager var124 = var262;
      MsdfFont var263 = var124.aReturningcx_C0158(var125);
      Object[] var10009 = new Object[]{null, null, null, null, null, var37, var23};
      var10009[4] = 1.0F;
      var10009[3] = var57;
      var10009[2] = var58;
      var10009[1] = var38;
      var10009[0] = var4;
      Object[] var127 = var10009;
      MsdfFont var126 = var263;
      var126.w(var127);
      var262 = Prestige.c;
      Object[] var129 = new Object[]{var19};
      MsdfFontManager var128 = var262;
      MsdfFont var265 = var128.aReturningcx_C0158(var129);
      short var286 = 19397;
      long var295 = 6048327238946946100L ^ var2;
      float var299 = var57 + (var42 - var43) - 0.5F;
      var10009 = new Object[]{null, null, null, null, null, UiMetrics.t, var23};
      var10009[4] = 0.65F;
      var10009[3] = var299;
      var10009[2] = var59;
      var10009[1] = "fps";
      var10009[0] = var4;
      Object[] var131 = var10009;
      MsdfFont var130 = var265;
      var130.w(var131);
      float var250 = var57 + var42 + 1.0F + 4.0F;
      boolean var219 = var50;
      float var171;
      if (var219) {
         float var220 = var52 + 5.5F;
         var171 = var220;
      } else {
         var171 = var52 + var46;
      }

      float var61 = var171;
      boolean var221 = var50;
      float var172;
      if (var221) {
         float var222 = var52 + var48 - var46;
         var172 = var222;
      } else {
         var172 = var52 + var48 - 5.5F;
      }

      float var62 = var172;
      float var63 = (var62 - var61) / 24.0F;
      float var64 = 60.0F;
      float[] var65 = this.g;
      int var66 = var65.length;
      int var175;
      while (true) {
         int var224 = var66;
         int var223 = var67;
         if (var223 < var224) {
            float var68 = var65[var67];
            int var225 = var31;
            if (var225 == 0) {
               float var314;
               int var266 = (var314 = var68 - var64) == 0.0F ? 0 : (var314 < 0.0F ? -1 : 1);
               int var227 = var31;
               int var226 = var266;
               var175 = var226;
               int var173 = var226;
               if (var227 != 0) {
                  break;
               }

               int var228 = var173;
               int var174 = var228;
               int var229 = var174;
               if (var229 > 0) {
                  var64 = var68;
               }

               var67++;
            }

            int var230 = var31;
            if (var230 == 0) {
               continue;
            }
         }

         var175 = 0;
         break;
      }

      int var251 = var175;

      while (true) {
         int var274 = 13624;
         long var287 = 3338805921261777582L ^ var2;
         byte var232 = 24;
         int var231 = var251;
         if (var231 < var232) {
            var274 = this.h + var251;
            var286 = 13624;
            var295 = 3338805921261777582L ^ var2;
            float var252 = this.g[var274 % 24];
            int var233 = var31;
            if (var233 != 0) {
               break;
            }

            label166: {
               int var236 = var31;
               float var235 = 0.0F;
               float var234 = var252;
               float var180 = var234;
               float var181 = var235;
               float var176 = var234;
               float var177 = var235;
               if (var236 == 0) {
                  float var238 = var177;
                  float var237 = var176;
                  float var178 = var237;
                  float var179 = var238;
                  float var315;
                  int var239 = (var315 = var178 - var179) == 0.0F ? 0 : (var315 < 0.0F ? -1 : 1);
                  if (var239 <= 0) {
                     int var240 = var31;
                     if (var240 == 0) {
                        break label166;
                     }
                  }

                  float var242 = var252 / var64 * 3.5F;
                  float var241 = 0.5F;
                  var180 = var241;
                  var181 = var242;
               }

               float var253 = var180 + var181;
               float var254 = var61 + var251 * var63;
               Object[] var297 = new Object[]{null, var25};
               var297[0] = var252;
               Object[] var140 = var297;
               Color var69 = aReturningColor(var140);
               int var244 = var31;
               int var243 = var251;
               int var183 = var243;
               int var182 = var243;
               int var184;
               if (var244 == 0) {
                  short var276 = 9434;
                  long var289 = 9056145817677980495L ^ var2;
                  byte var246 = 23;
                  int var245 = var182;
                  if (var245 == var246) {
                     short var267 = 5691;
                     long var277 = 1244054210576044455L ^ var2;
                     short var247 = 220;
                     var184 = var247;
                  } else {
                     short var268 = 6574;
                     long var278 = 4869423772293094973L ^ var2;
                     var184 = 110;
                  }
               } else {
                  int var248 = var183;
                  var184 = var248;
               }

               int var70 = var184;
               float var279 = var254 + 0.2F;
               float var290 = var250 - var253;
               float var298 = var254 + var63 - 0.2F;
               Color var143 = var69;
               int var304 = var143.getRed();
               Color var144 = var69;
               int var305 = var144.getGreen();
               Color var145 = var69;
               Object[] var306 = new Object[]{null, null, null, null, null, new Color(var304, var305, var145.getBlue(), var70), var13};
               var306[4] = var250;
               var306[3] = var298;
               var306[2] = var290;
               var306[1] = var279;
               var306[0] = var4;
               Object[] var146 = var306;
               ShapeRenderer.lReturningVoid(var146);
            }

            var251++;
            int var249 = var31;
            if (var249 == 0) {
               continue;
            }
         }

         Object[] var300 = new Object[]{null, var49};
         var300[0] = var48;
         Object[] var148 = var300;
         FpsWidget var147 = this;
         var147.iReturningVoid(var148);
         break;
      }
   }

   private static Color aReturningColor(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      var2 = 107701258810685L ^ var2;
      int var4 = Event.cReturningInt();
      float var37;
      int var10000 = (var37 = var1 - 120.0F) == 0.0F ? 0 : (var37 < 0.0F ? -1 : 1);
      int var10 = var4;
      int var9 = var10000;
      int var6 = var9;
      int var5 = var9;
      if (var10 != 0) {
         int var11 = var5;
         if (var11 >= 0) {
            short var19 = 26349;
            long var25 = 2697904359074970396L ^ var2;
            short var26 = 17096;
            long var32 = 7855087267514392382L ^ var2;
            short var33 = 31432;
            long var36 = 7080415713002202938L ^ var2;
            return new Color(96, 220, 130);
         }

         float var38;
         var6 = (var38 = var1 - 60.0F) == 0.0F ? 0 : (var38 < 0.0F ? -1 : 1);
      }

      int var13 = var4;
      int var12 = var6;
      int var8 = var12;
      int var7 = var12;
      if (var13 != 0) {
         int var14 = var7;
         if (var14 >= 0) {
            short var18 = 25539;
            long var23 = 1578011364990434878L ^ var2;
            short var24 = 815;
            long var30 = 809251715868843731L ^ var2;
            short var31 = 20515;
            long var35 = 2249992307412897225L ^ var2;
            return new Color(240, 200, 80);
         }

         float var39;
         var8 = (var39 = var1 - 30.0F) == 0.0F ? 0 : (var39 < 0.0F ? -1 : 1);
      }

      int var15 = var8;
      if (var15 >= 0) {
         short var17 = 8534;
         long var21 = 717850723713449122L ^ var2;
         short var22 = 25946;
         long var28 = 3292552400324180145L ^ var2;
         short var29 = 9957;
         long var34 = 6300684788558461725L ^ var2;
         return new Color(245, 145, 60);
      } else {
         short var10002 = 7536;
         long var10003 = 864167758928756875L ^ var2;
         short var20 = 21800;
         long var10004 = 3022092815496677597L ^ var2;
         short var27 = 27991;
         long var10005 = 6629207645354176672L ^ var2;
         return new Color(235, 75, 70);
      }
   }

   private static int aReturningInt(Object[] var0) {
      String var1 = (String)var0[0];
      long var2 = (Long)var0[1];
      var2 = 107701258810685L ^ var2;

      try {
         return invokeBinding5(invokeBinding4(var1, " ", 498614829188667413L, var2)[0], 498432766258673585L, var2);
      } catch (Exception var6) {
         return 0;
      }
   }

   static {

      {

      b();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(122309623264816L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[5];
      String var28 = "ª\u0089%4½Èº\u0015Ý£B\u0093©\u008c\u001at(\u007f1¼\u008f»9\u008cÇå9î¬<²\u0002û\u001a¥÷8g©¤\u0095~\u0002¯l~ï4×V&Æ\u0007{è\u008d¥\u0010{¾\u009f\u0002¶B\u0096-!¦åóóß\u0094h";
      int var30 = "ª\u0089%4½Èº\u0015Ý£B\u0093©\u008c\u001at(\u007f1¼\u008f»9\u008cÇå9î¬<²\u0002û\u001a¥÷8g©¤\u0095~\u0002¯l~ï4×V&Æ\u0007{è\u008d¥\u0010{¾\u009f\u0002¶B\u0096-!¦åóóß\u0094h"
         .length();
      char var27 = 16;
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     w = var31;
                     x = new String[5];
                     D = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(122309623264816L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[18];
                     String var15 = "·`EB*\u0094\u001eV\f\u000f×\u009c\u0089È\u0088üwPnúûî\u0081\"À\u0000Ì\tbF¬ ¥Èàò\u0085Ë*¥`z¿y¶´\u0083fÏx2î\u0013Ú\u0095'EÂ\u0012b!,_¹Ý\u0004ô\u0018l`ê\u0094\"ÑI¿\u0094{\u0080\u001a\u008f¯AøüE)!ØE¤\u0006°\\û \b\u008d«Ô\u0017\u009d bKñ\"\u000e¯\u001c®~\u008dÈ\u0019¢Ì\u0093ôpÞl«\u001aA:\u0005ç";
                     int var16 = "·`EB*\u0094\u001eV\f\u000f×\u009c\u0089È\u0088üwPnúûî\u0081\"À\u0000Ì\tbF¬ ¥Èàò\u0085Ë*¥`z¿y¶´\u0083fÏx2î\u0013Ú\u0095'EÂ\u0012b!,_¹Ý\u0004ô\u0018l`ê\u0094\"ÑI¿\u0094{\u0080\u001a\u008f¯AøüE)!ØE¤\u0006°\\û \b\u008d«Ô\u0017\u009d bKñ\"\u000e¯\u001c®~\u008dÈ\u0019¢Ì\u0093ôpÞl«\u001aA:\u0005ç"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    B = var17;
                                    C = new Integer[18];
                                    a = 24;
                                    J = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(122309623264816L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[4];
                                    String var4 = "ªY\\è\u0083HH¾)\u0082DS·\u0095hR";
                                    int var5 = "ªY\\è\u0083HH¾)\u0082DS·\u0095hR".length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   H = var6;
                                                   I = new Long[4];
                                                   c = /* /*DECRYPT:dev.zprestige.prestige.b5:6:29882:1956407406207538839*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.FpsWidget_29882";
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "Rr°¥\u001aì\\ÙÀ¦t\u001emYn0";
                                                var5 = "Rr°¥\u001aì\\ÙÀ¦t\u001emYn0".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "ö\u008a~HD\u0001Â6@N@ÑB¹ª\u009f";
                                 var16 = "ö\u008a~HD\u0001Â6@N@ÑB¹ª\u009f".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "\u000f\u009cÿ\u0015\u0016þE\u0017e,\u0090Isð~*p`zÄ°\u0094ê+Kç\u0084Ï\u001cþÞ±m\u0018¯oqk\u0090?ßy\në-\u0004\\È*Rü\u0014hÆÈªÎóâË\"{M¼D%ðÚ£V\u0090ô\u0010\u0091Î¸×\u0000?\u0084@§Q0`4ªÛ\u0002";
                  var30 = "\u000f\u009cÿ\u0015\u0016þE\u0017e,\u0090Isð~*p`zÄ°\u0094ê+Kç\u0084Ï\u001cþÞ±m\u0018¯oqk\u0090?ßy\në-\u0004\\È*Rü\u0014hÆÈªÎóâË\"{M¼D%ðÚ£V\u0090ô\u0010\u0091Î¸×\u0000?\u0084@§Q0`4ªÛ\u0002"
                     .length();
                  var27 = 'H';
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29795;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b5", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b5",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 1029;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b5", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b5",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25134;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b5", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b5",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 2;
            yield var15;
         }
         case 1 -> {
            byte var16 = 46;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 41;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 44;
            yield var20;
         }
         case 6 -> {
            byte var21 = 11;
            yield var21;
         }
         case 7 -> {
            byte var22 = 38;
            yield var22;
         }
         case 8 -> {
            byte var23 = 15;
            yield var23;
         }
         case 9 -> {
            byte var24 = 47;
            yield var24;
         }
         case 10 -> {
            byte var25 = 23;
            yield var25;
         }
         case 11 -> {
            byte var26 = 55;
            yield var26;
         }
         case 12 -> {
            byte var27 = 42;
            yield var27;
         }
         case 13 -> {
            byte var28 = 3;
            yield var28;
         }
         case 14 -> {
            byte var29 = 24;
            yield var29;
         }
         case 15 -> {
            byte var30 = 0;
            yield var30;
         }
         case 16 -> {
            byte var31 = 17;
            yield var31;
         }
         case 17 -> {
            byte var32 = 54;
            yield var32;
         }
         case 18 -> {
            byte var33 = 31;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 28;
            yield var35;
         }
         case 21 -> {
            byte var36 = 50;
            yield var36;
         }
         case 22 -> {
            byte var37 = 61;
            yield var37;
         }
         case 23 -> {
            byte var38 = 60;
            yield var38;
         }
         case 24 -> {
            byte var39 = 22;
            yield var39;
         }
         case 25 -> {
            byte var40 = 9;
            yield var40;
         }
         case 26 -> {
            byte var41 = 12;
            yield var41;
         }
         case 27 -> {
            byte var42 = 45;
            yield var42;
         }
         case 28 -> {
            byte var43 = 8;
            yield var43;
         }
         case 29 -> {
            byte var44 = 13;
            yield var44;
         }
         case 30 -> {
            byte var45 = 51;
            yield var45;
         }
         case 31 -> {
            byte var46 = 27;
            yield var46;
         }
         case 32 -> {
            byte var47 = 21;
            yield var47;
         }
         case 33 -> {
            byte var48 = 34;
            yield var48;
         }
         case 34 -> {
            byte var49 = 18;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 14;
            yield var53;
         }
         case 39 -> {
            byte var54 = 4;
            yield var54;
         }
         case 40 -> {
            byte var55 = 16;
            yield var55;
         }
         case 41 -> {
            byte var56 = 53;
            yield var56;
         }
         case 42 -> {
            byte var57 = 1;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 32;
            yield var59;
         }
         case 45 -> {
            byte var60 = 52;
            yield var60;
         }
         case 46 -> {
            byte var61 = 56;
            yield var61;
         }
         case 47 -> {
            byte var62 = 10;
            yield var62;
         }
         case 48 -> {
            byte var63 = 20;
            yield var63;
         }
         case 49 -> {
            byte var64 = 37;
            yield var64;
         }
         case 50 -> {
            byte var65 = 43;
            yield var65;
         }
         case 51 -> {
            byte var66 = 29;
            yield var66;
         }
         case 52 -> {
            byte var67 = 62;
            yield var67;
         }
         case 53 -> {
            byte var68 = 5;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 7;
            yield var70;
         }
         case 56 -> {
            byte var71 = 40;
            yield var71;
         }
         case 57 -> {
            byte var72 = 26;
            yield var72;
         }
         case 58 -> {
            byte var73 = 39;
            yield var73;
         }
         case 59 -> {
            byte var74 = 59;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 6;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "j~pY5,|~u\u0003&;k5v\u0005*/zra\u0012a=K";
      K[1] = int.class;
      L[1] = "java/lang/Integer";
      K[2] = "Z.G=P6L.BgC![eAaO5J\"Vv\u0004$\u000b";
      K[3] = "\u000fa,}^\u000bzA'rOD\u001bO,yK\u001eo";
      K[4] = " \u001e\u000eioD=\u000bVK.I%\r";
      K[5] = "\"ngF85)av\tE ;{tJ";
      K[6] = long.class;
      L[6] = "java/lang/Long";
      K[7] = "/\u0007p3d(9\u0007uiw?.Lvo{+?\u000bax0;'\u000bcsjv\u001b\u0010cnj1,\u0007";
      K[8] = "Ro^p]hDo[*N\u007fS$X,BkBcO;\t{L";
      K[9] = "\u0014S\u0007`\u001a=\u0014S\u0010<\u00162\u000e\u0018\u0010\"\u0016'\ti@\u007fG";
      K[10] = "6%\u0019\u000f\u0002f6%\u000eS\u000ei,n\u000eM\u000e|+\u001fY\u0012X";
      K[11] = ")y-d\u001c\u0002?y(>\u000f\u0015(2+8\u0003\u00019u</H\u00115";
      K[12] = "u\"nl\u0003l\u0000\u0002ec\u0012#a\fnh\u0016y\u0015";
      K[13] = void.class;
      L[13] = "java/lang/Void";
      K[14] = "\u001c;\\ \u0001{\n;Yz\u0012l\u001dpZ|\u001ex\f7MkUiI";
      K[15] = "@^\u0002Y>n5~\tV/!Tp\u0002]+{ ";
      K[16] = "K.n\u0006`\u001d].k\\s\nJehZ\u007f\u001e[\"\u007fM4\tY";
      K[17] = "#\"{jwJV\u0002pef\u00057\f{nb_C";
      K[18] = "0>*Pl4E\u001e!_}{$\u0010*Ty!P";
      K[19] = float.class;
      L[19] = "java/lang/Float";
      K[20] = "5Qo((9>^~gK4+Sq\f~6:@m i;";
      K[21] = "\u001f\u0010\u0018&w.\t\u0010\u001d|d9\u001e[\u001ezh-\u000f\u001c\tm#?9";
      K[22] = "w\u000fd=IN\u0002/o2X\u0001c!d9\\[\u0017";
      K[23] = "\u00028A\u00180L\t7PWSA\u001c1";
      K[24] = "\u0001GU\u0002P\u0004tg^\rAK\u0015iU\u0006E\u0011a";
      K[25] = "YIn8d\u000b,ie7uDMgn<q\u001e9";
      K[26] = boolean.class;
      L[26] = "java/lang/Boolean";
      K[27] = ")0YT&K?0\\\u000e5\\({_\b9H9<H\u001frX&";
      K[28] = "\u001c4So^#i\u0014X`Ol\b\u001aSkK6|";
      K[29] = "\u0003A\\>N7\u0015AYd] \u0002\nZbQ4\u0013MMu\u001a#\u000f";
      K[30] = "X&I.WM-\u0006B!F\u0002L\bI*BX8";
      K[31] = "\u007f\u000f\u000fBWVi\u000f\n\u0018DA~D\t\u001eHUo\u0003\u001e\t\u0003DO";
      K[32] = "LUrs\u001dBZUw)\u000eUM\u001et/\u0002A\\Yc8IVO";
      K[33] = "a?F\u0006>>\u0014\u001fM\t/qu\u0011F\u0002++\u0001";
      K[34] = "\n'\u0017\fAs\u0001(\u0006C<k\u0012/\u000f\n";
      K[35] = "F\btC~(3(\u007fLogR&tGk=&";
      K[36] = "\u001aJ\u000b\u000exQ\fJ\u000eTkF\u001b\u0001\rRgR\nF\u001aE,E\u0018";
      K[37] = "\u00027`\u0014j3w\u0017k\u001b{|\u0016\u0019`\u0010\u007f&b";
      K[38] = "l\f.H7.z\f+\u0012$9mG(\u0014(-|\u0000?\u0003c=1";
      K[39] = "\u000eT\u001641|{t\u001d; 3\u001az\u00160$in";
      K[40] = "(]\u0007;@+]}\f4Qd<s\u0007?U>H";
      K[41] = "\u001a=uwS(o\u001d~xBg\u000e\u0013usF=z";
      K[42] = ")\u0011\u001bD`\t\"\u001e\n\u000b\u0007\u000b7\u0015\n@<";
      K[43] = "\u001f(T\u001e@&j\b_\u0011Qi\u0017\u0010L\u0016X \u007f";
      K[44] = "\u007f`1|Iwto 3(y\u007fd$i";
      K[45] = "<B\u001c~\u001fDgOL\u0006\u0010/!\u0010Vb\u0016T4JV\u0006";
      K[46] = "\\{q\u0016n\u001b\u000b!<\u000b\u0001\u0015f:)J=\u001d\u0000x|\u0015m|\\11\fk\u0018\u001c12\u0001\u0001";
      K[47] = "v\u0019\u000bQ7\u001a(\u001eMST\b7_HE2\u001f\u0016DWE\u0011\u0002.ASST_2\u0018KS3\u001b&^\u0003(";
      K[48] = ")\\JtcM+\u001aB1\u0018X\u0015\u001fKkz\\.APps";
      K[49] = "0he\u0016\u001dY4u3RbMob<\u00065\u001a12ej]F6tg\u0001]I>>";
      K[50] = "\u007fs'*go&6s+Y O0+/e>)r~p5_~wpxd>.{!zY";
      K[51] = "x\u0006u?6\u0002#\u000b%G8ieT?#?\u0012p\u000e?G";
      K[52] = "xG}0Ycw\u0012'0$z\u0011U h\u0018zw\u0017u7H\u001b \u0012{?\u0019zp\u001e*=$";
      K[53] = "6\f\u0012\u00019\t8\u001c\u0015\u0012]\u0001\\\u001cOTa\u0004:^\u001a\u000b1em[\u0014\u0003`\u0004=WE\u0001]";
      K[54] = "J\u000bsPdy\u0013N'QZ zH\u007fUf(\u001c\n*\n6I\u0016\fe\u000498K\\g\u0010Z";
      K[55] = "44\u0015Pg\u0007t4\u0016]\r\fc82Aacq{\u0013Ha\u0018d!\u0013,";
      K[56] = "\b]\u0006\u007f>%\f@P;A:[F[d-\b\n\u0005\u00062p_I\u0005@g-$\\_@\u0003";
      K[57] = "PM\u0006H\u0002c\u0007\u0017KUmmj\u001a\u000bI\u0010c\u001a\u0013\u0007NU\u0004\u0007G\\S\nt\u000eK[\u0016m";
      K[58] = "A\u001d?\\\u0007tU]p_lt/Zd\u0007PyI\u00181X\u0000\u0018\u0015Q|A\u0006|UQ\u007fLl";
      K[59] = "\u001e\u0003E3ENJH\u00127u\u0013\u0019\u0001+;J\t\u001b\u0012Zf\u001a\u000b\u000fqGh\n\u001d\u0013\u0000\u001a8\b\tp\u001d\u0014(\u001e\u0015\u0001@D*\nv";
      K[60] = "\u007f \\l$b? _aNi(,kt3kE/\u001ek*j>:DkN";
      K[61] = "\tL[\u0000z\u001fWW@\t\u0015M4L\\X)ER\u000e\t\u0007y$\u0004\u000fP]+\u0014]J\u0004\\\u0015";
      K[62] = "`L#\u0000<\\o\u0019y\u0000AO\t^~X}Eo\u001c+\u0007-$h@v\u000f>\\{Y|\rA";
      K[63] = "\u0001w8[T4\u000e\"b[)%hee\u0003\u0015-\u000e'0\\ELY\">T\u0014-\t.oV)";
      K[64] = "(:_h.\"&?\u000fvU&I:T+i-/x\u0001t9L%~Nz6=x.LnU";
      K[65] = "M,r\u000e|IIxmN\u0018C.it\u0005$KH+!Zt*Jiu\u000e)\u0014H,|[\u0018";
      K[66] = "Ww_A|\u001c\\z\u000f\u0014\u0016\u000f2`\n\u0011*\u0005T\"_Nzd\u0003'QF+\u0005S+\u0000D\u0016";
      K[67] = "\"G{qVT4Jmt5V7VgytH\",znEW#Je~\t\u0015^S#oQB%Fyo5";
      K[68] = "\u001e\u001f\r\bjD\u0001\u000fAJ\u0017\\\u0011\u0001\u0000\u001cPLx\u001aB\nsN\u0003\u000f\u0018\n\u0017D\u0002\u0015\u0004\fq[\u0012YFq";
      K[69] = "pdq&R7ot=d/*nz`#/7lnx\"I(|\":_Rnl\u007fj=\u0016`|#\u0001";
      K[70] = "]\u001c&qe\\I\\ir\u000eZ3[}*2QU\u0019(ub0_\u001fg{mA\u0002Oeo\u000e";
      K[71] = "\rh|ME\u0017L:{T?\u001cu-p\u001e\u0003\u0016\u0013o%ASwDj+I\u0002\u0016\u0014fzK?";
      K[72] = "#\u001cJ\u001b\u000eE&\u000b\u001b\u001e1AZ\u0015O\u0018\rM<W\u001aG],kR\u0014O\fM;^EM1";
      K[73] = "._M\u0014Izw\u001a\u0019\u0015w!\u001e\u001cA\u0011K+x^\u0014N\u001bJrX[@\u0014;/\bYTw";
      K[74] = "`\u0005g6\u0017E \u0005d;}N7\tU0\u0010L<ueu\u0006E6\u000ep/\u0006!";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3159350494199731L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3159350494199731L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3159350494199731L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 229;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 224;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 106;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 80;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 232;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 186;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 229;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 224;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 106;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b5",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b5" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = d(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = d(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = d(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String[] invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = g(
                  MethodHandles.lookup(), "è", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)[Ljava/lang/String;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (String[])var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = g(MethodHandles.lookup(), "º", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = d(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
