package dev.zprestige.prestige.client.ui.hud;

public class HudAnchor {
   private final HudAxis a;
   private final int b;

   public HudAnchor(HudAxis var1, int var2) {
      this.a = var1;
      this.b = var2;
   }

   public HudAxis aReturningu_C0442(Object[] var1) {
      return this.a;
   }

   public int aReturningInt(Object[] var1) {
      return this.b;
   }
}
