package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;

import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventBus;
import dev.zprestige.prestige.api.setting.BooleanSetting;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.glfw.GLFW;

public class HudElement implements MinecraftAccess {
   private final String a;
   private final String c;
   private final BooleanSetting d;
   public float e;
   public float f;
   public float g;
   public float h;
   public HudAlignment i;
   public HudAlignment j;
   public float k;
   public float l;
   private static final float m = 8.0F;
   private boolean n;
   private float o;
   private float p;
   private boolean q;
   private boolean r;
   private boolean s;
   private float t;
   private float u;
   private static final long z = 7820857091329L;
   private static final String A;
   private static final long[] E;
   private static final Integer[] F;
   private static final Map G;
   private static final Object[] M = new Object[95];
   private static final String[] N = new String[95];
   private static volatile MethodHandle bindingCache1;

   public HudElement(String var1, String var2, long var3) {
      super();
      long var10000 = 7820857091329L ^ var3;

      this.d = new BooleanSetting(A, false);
      this.e = 0.0F;
      this.f = 0.0F;
      this.g = 0.0F;
      this.h = 0.0F;
      this.i = HudAlignment.Start;
      this.j = HudAlignment.Start;
      this.k = 0.0F;
      this.l = 0.0F;
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.o = 0.0F;
      this.p = 0.0F;
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.r = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.t = 0.0F;
      this.u = 0.0F;
      this.a = var1;
      this.c = var2;
   }

   public void aReturningVoid(Object[] var1) {
      float var3 = (Float)var1[0];
      float var2 = (Float)var1[1];
      long var4 = (Long)var1[2];
      var4 = 7820857091329L ^ var4;
      long var6 = var4 ^ 117872208439421L;
      this.e = var3;
      this.f = var2;
      Object[] var9 = new Object[]{var6};
      HudElement var8 = this;
      var8.bReturningVoid(var9);
   }

   public boolean aReturningBoolean(Object[] var1) {
      return this.s;
   }

   public void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7820857091329L ^ var2;
      long var4 = var2 ^ 74876217172502L;
      long var6 = var2 ^ 115435248269841L;
      long var8 = var2 ^ 41771320417496L;
      int var10 = Event.cReturningInt();
      MinecraftClient var11 = b;
      Window var32 = var11.getWindow();
      if (var32 != null) {
         int var34 = var10;
         HudElement var33 = this;
         HudElement var30 = var33;
         HudElement var27 = var33;
         if (var34 != 0) {
            float var46;
            int var35 = (var46 = var27.g - 0.0F) == 0.0F ? 0 : (var46 < 0.0F ? -1 : 1);
            label27:
            if (var35 > 0) {
               int var37 = var10;
               HudElement var36 = this;
               HudElement var31 = var36;
               HudElement var28 = var36;
               if (var37 != 0) {
                  HudElement var38 = var28;
                  HudElement var29 = var38;
                  float var47;
                  int var39 = (var47 = var29.h - 0.0F) == 0.0F ? 0 : (var47 < 0.0F ? -1 : 1);
                  if (var39 <= 0) {
                     break label27;
                  }

                  this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
                  MinecraftClient var17 = b;
                  Window var18 = var17.getWindow();
                  float var10001 = var18.getFramebufferWidth();
                  Object[] var19 = new Object[]{var8};
                  var10001 /= HudEditorScreen.bReturningFloat(var19);
                  Object[] var10004 = new Object[]{null, var4};
                  var10004[0] = var10001;
                  Object[] var21 = var10004;
                  HudElement var20 = this;
                  var20.cReturningVoid(var21);
                  var31 = this;
               }

               MinecraftClient var22 = b;
               Window var23 = var22.getWindow();
               float var43 = var23.getFramebufferHeight();
               Object[] var24 = new Object[]{var8};
               var43 /= HudEditorScreen.bReturningFloat(var24);
               Object[] var45 = new Object[]{null, var6};
               var45[0] = var43;
               Object[] var26 = var45;
               HudElement var25 = var31;
               var25.dReturningVoid(var26);
               return;
            }

            this.o = this.e;
            this.p = this.f;
            HudElement var40 = this;
            var30 = var40;
         }

         var30.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
      }
   }

   private void cReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 7820857091329L ^ var3;
      int var17 = Event.bReturningInt();
      float var6 = this.e + this.g / 2.0F - var2 / 2.0F;
      int var5 = var17;
      float var7 = var6;
      float var19;
      int var18 = (var19 = Math.abs(var7) - 8.0F) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
      int var11 = var5;
      int var10 = var18;
      int var9 = var10;
      int var8 = var10;
      if (var11 == 0) {
         int var12 = var8;
         if (var12 <= 0) {
            this.i = HudAlignment.Center;
            this.k = var6;
            int var13 = var5;
            if (var13 == 0) {
               return;
            }
         }

         float var20;
         int var14 = (var20 = var6 - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
         var9 = var14;
      }

      int var15 = var9;
      if (var15 < 0) {
         this.i = HudAlignment.Start;
         this.k = this.e;
         int var16 = var5;
         if (var16 == 0) {
            return;
         }
      }

      this.i = HudAlignment.End;
      this.k = var2 - (this.e + this.g);
   }

   private void dReturningVoid(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 7820857091329L ^ var2;
      int var17 = Event.cReturningInt();
      float var6 = this.f + this.h / 2.0F - var4 / 2.0F;
      int var5 = var17;
      float var7 = var6;
      float var19;
      int var18 = (var19 = Math.abs(var7) - 8.0F) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
      int var11 = var5;
      int var10 = var18;
      int var9 = var10;
      int var8 = var10;
      if (var11 != 0) {
         int var12 = var8;
         if (var12 <= 0) {
            this.j = HudAlignment.Center;
            this.l = var6;
            int var13 = var5;
            if (var13 != 0) {
               return;
            }
         }

         float var20;
         int var14 = (var20 = var6 - 0.0F) == 0.0F ? 0 : (var20 < 0.0F ? -1 : 1);
         var9 = var14;
      }

      int var15 = var9;
      if (var15 < 0) {
         this.j = HudAlignment.Start;
         this.l = this.f;
         int var16 = var5;
         if (var16 != 0) {
            return;
         }
      }

      this.j = HudAlignment.End;
      this.l = var4 - (this.f + this.h);
   }

   public boolean bReturningBoolean(Object[] var1) {
      return this.n;
   }

   public boolean cReturningBoolean(Object[] var1) {
      HudAlignment var4 = HudAlignment.End;
      HudAlignment var3 = this.i;
      byte var2;
      if (var3 == var4) {
         byte var5 = 1;
         var2 = var5;
      } else {
         var2 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var2);
   }

   public boolean dReturningBoolean(Object[] var1) {
      HudAlignment var4 = HudAlignment.End;
      HudAlignment var3 = this.j;
      byte var2;
      if (var3 == var4) {
         byte var5 = 1;
         var2 = var5;
      } else {
         var2 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var2);
   }

   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7820857091329L ^ var2;
      long var4 = var2 ^ 96172567911671L;
      long var6 = var2 ^ 129289796248878L;
      int var8 = Event.cReturningInt();
      MinecraftClient var13 = b;
      Window var10000 = var13.getWindow();
      int var84 = var8;
      Window var83 = var10000;
      Window var55 = var83;
      Window var54 = var83;
      if (var84 != 0) {
         Window var85 = var54;
         if (var85 == null) {
            return;
         }

         MinecraftClient var15 = b;
         var55 = var15.getWindow();
      }

      float var10;
      HudElement var61;
      label99: {
         float var9;
         int var62;
         Window var16 = var55;
         float var122 = var16.getFramebufferWidth();
         Object[] var17 = new Object[]{var6};
         var9 = var122 / HudEditorScreen.bReturningFloat(var17);
         MinecraftClient var18 = b;
         Window var19 = var18.getWindow();
         float var123 = var19.getFramebufferHeight();
         Object[] var20 = new Object[]{var6};
         var10 = var123 / HudEditorScreen.bReturningFloat(var20);
         int var87 = var8;
         byte var86 = ((byte)((this.n) ? 1 : 0));
         var62 = var86;
         byte var56 = var86;
         label72:
         if (var87 != 0) {
            label83: {
               byte var88 = var56;
               if (var88 != 0) {
                  int var90 = var8;
                  HudElement var89 = this;
                  var61 = var89;
                  HudElement var57 = var89;
                  if (var90 == 0) {
                     break label99;
                  }

                  HudElement var91 = var57;
                  HudElement var58 = var91;
                  float var127;
                  int var92 = (var127 = var58.g - 0.0F) == 0.0F ? 0 : (var127 < 0.0F ? -1 : 1);
                  if (var92 <= 0) {
                     break label83;
                  }

                  int var94 = var8;
                  HudElement var93 = this;
                  var61 = var93;
                  HudElement var59 = var93;
                  if (var94 == 0) {
                     break label99;
                  }

                  HudElement var95 = var59;
                  HudElement var60 = var95;
                  float var128;
                  int var96 = (var128 = var60.h - 0.0F) == 0.0F ? 0 : (var128 < 0.0F ? -1 : 1);
                  if (var96 <= 0) {
                     break label83;
                  }

                  this.e = this.o;
                  this.f = this.p;
                  Object[] var27 = new Object[]{var4};
                  HudElement var26 = this;
                  var26.bReturningVoid(var27);
                  int var97 = var8;
                  if (var97 == 0) {
                     break label83;
                  }
               }

               HudAlignment var40 = this.i;
               var62 = var40.ordinal();
               break label72;
            }

            float var125 = this.o;
            float var30 = var9 - this.g;
            float var29 = 0.0F;
            float var33 = Math.max(var29, var30);
            float var32 = 0.0F;
            float var31 = var125;
            this.e = Math.clamp(var31, var32, var33);
            HudElement var98 = this;
            var61 = var98;
            break label99;
         }

         int var99 = var62;

         float var11 = switch (var99) {
            case 0 -> {
               float var100 = this.k;
               yield var100;
            }
            case 1 -> var9 / 2.0F - this.g / 2.0F + this.k;
            case 2 -> {
               float var101 = var9 - this.k - this.g;
               yield var101;
            }
            default -> throw new MatchException(null, null);
         };
         HudAlignment var42 = this.j;
         int var102 = var42.ordinal();

         float var12;
         HudElement var72;
         int var73;
         label64: {
            var12 = switch (var102) {
               case 0 -> {
                  float var103 = this.l;
                  yield var103;
               }
               case 1 -> var10 / 2.0F - this.h / 2.0F + this.l;
               case 2 -> {
                  float var104 = var10 - this.l - this.h;
                  yield var104;
               }
               default -> throw new MatchException(null, null);
            };
            float var45 = var9 - this.g;
            float var44 = 0.0F;
            float var48 = Math.max(var44, var45);
            float var47 = 0.0F;
            float var46 = var11;
            this.e = Math.clamp(var46, var47, var48);
            float var50 = var10 - this.h;
            float var49 = 0.0F;
            float var53 = Math.max(var49, var50);
            float var52 = 0.0F;
            float var51 = var12;
            this.f = Math.clamp(var51, var52, var53);
            float var129;
            int var10001 = (var129 = this.e - var11) == 0.0F ? 0 : (var129 < 0.0F ? -1 : 1);
            int var107 = var8;
            int var106 = var10001;
            HudElement var105 = this;
            HudElement var69 = var105;
            int var70 = var106;
            HudElement var65 = var105;
            int var66 = var106;
            if (var107 != 0) {
               int var109 = var66;
               HudElement var108 = var65;
               HudElement var71 = var108;
               HudElement var67 = var108;
               if (var109 == 0) {
                  var73 = 0;
                  var72 = var71;
                  break label64;
               }

               HudElement var110 = var67;
               HudElement var68 = var110;
               var70 = 1;
               var69 = var68;
            }

            int var112 = var70;
            HudElement var111 = var69;
            var72 = var111;
            var73 = var112;
         }

         HudElement var81;
         int var82;
         label58: {
            var72.q = dev.prestige.recovery.SourceSupport.asBoolean(var73);
            float var130;
            int var124 = (var130 = this.f - var12) == 0.0F ? 0 : (var130 < 0.0F ? -1 : 1);
            int var115 = var8;
            int var114 = var124;
            HudElement var113 = this;
            HudElement var78 = var113;
            int var79 = var114;
            HudElement var74 = var113;
            int var75 = var114;
            if (var115 != 0) {
               int var117 = var75;
               HudElement var116 = var74;
               HudElement var80 = var116;
               HudElement var76 = var116;
               if (var117 == 0) {
                  var82 = 0;
                  var81 = var80;
                  break label58;
               }

               HudElement var118 = var76;
               HudElement var77 = var118;
               var79 = 1;
               var78 = var77;
            }

            int var120 = var79;
            HudElement var119 = var78;
            var81 = var119;
            var82 = var120;
         }

         var81.r = dev.prestige.recovery.SourceSupport.asBoolean(var82);
         return;
      }

      float var126 = this.p;
      float var36 = var10 - this.h;
      float var35 = 0.0F;
      float var39 = Math.max(var35, var36);
      float var38 = 0.0F;
      float var37 = var126;
      var61.f = Math.clamp(var37, var38, var39);
   }

   public void fReturningVoid(Object[] var1) {
      HudAlignment var5 = (HudAlignment)var1[0];
      HudAlignment var2 = (HudAlignment)var1[1];
      float var4 = (Float)var1[2];
      float var3 = (Float)var1[3];
      long var6 = (Long)var1[4];
      var6 = 7820857091329L ^ var6;
      long var8 = var6 ^ 133993673806461L;
      this.i = var5;
      this.j = var2;
      this.k = var4;
      this.l = var3;
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      Object[] var11 = new Object[]{var8};
      HudElement var10 = this;
      var10.eReturningVoid(var11);
   }

   public void gReturningVoid(Object[] var1) {
      HudCorner var2;
      float var3;
      float var4;
      long var7;
      int var9;
      byte var26;
      label45: {
         label44: {
            var2 = (HudCorner)var1[0];
            var3 = (Float)var1[1];
            var4 = (Float)var1[2];
            long var5 = (Long)var1[3];
            var5 = 7820857091329L ^ var5;
            var7 = var5 ^ 36790739503851L;
            var9 = Event.bReturningInt();
            int var45 = var9;
            HudCorner var44 = HudCorner.TopLeft;
            HudCorner var43 = var2;
            HudCorner var24 = var43;
            HudCorner var25 = var44;
            HudCorner var22 = var43;
            HudCorner var23 = var44;
            if (var45 == 0) {
               HudCorner var47 = var23;
               HudCorner var46 = var22;
               if (var46 == var47) {
                  break label44;
               }

               HudCorner var49 = HudCorner.BottomLeft;
               HudCorner var48 = var2;
               var24 = var48;
               var25 = var49;
            }

            HudCorner var51 = var25;
            HudCorner var50 = var24;
            if (var50 != var51) {
               var26 = 0;
               break label45;
            }
         }

         byte var52 = 1;
         var26 = var52;
      }

      byte var10;
      byte var31;
      label36: {
         label35: {
            var10 = var26;
            int var55 = var9;
            HudCorner var54 = HudCorner.TopLeft;
            HudCorner var53 = var2;
            HudCorner var29 = var53;
            HudCorner var30 = var54;
            HudCorner var27 = var53;
            HudCorner var28 = var54;
            if (var55 == 0) {
               HudCorner var57 = var28;
               HudCorner var56 = var27;
               if (var56 == var57) {
                  break label35;
               }

               HudCorner var59 = HudCorner.TopRight;
               HudCorner var58 = var2;
               var29 = var58;
               var30 = var59;
            }

            HudCorner var61 = var30;
            HudCorner var60 = var29;
            if (var60 != var61) {
               var31 = 0;
               break label36;
            }
         }

         byte var62 = 1;
         var31 = var62;
      }

      byte var11 = var31;
      byte var64 = var10;
      HudElement var63 = this;
      HudElement var33 = var63;
      HudElement var32 = var63;
      HudElement var34;
      HudAlignment var35;
      if (var64 != 0) {
         HudAlignment var66 = HudAlignment.Start;
         HudElement var65 = var32;
         var34 = var65;
         var35 = var66;
      } else {
         var35 = HudAlignment.End;
         var34 = var33;
      }

      byte var69 = var11;
      HudAlignment var68 = var35;
      HudElement var67 = var34;
      HudElement var38 = var67;
      HudAlignment var39 = var68;
      HudElement var36 = var67;
      HudAlignment var37 = var68;
      HudElement var40;
      HudAlignment var41;
      HudAlignment var42;
      if (var69 != 0) {
         HudAlignment var72 = HudAlignment.Start;
         HudAlignment var71 = var37;
         HudElement var70 = var36;
         var40 = var70;
         var41 = var71;
         var42 = var72;
      } else {
         var42 = HudAlignment.End;
         var41 = var39;
         var40 = var38;
      }

      Object[] var10007 = new Object[]{null, null, null, null, var7};
      var10007[3] = var4;
      var10007[2] = var3;
      var10007[1] = var42;
      var10007[0] = var41;
      Object[] var21 = var10007;
      HudElement var20 = var40;
      var20.fReturningVoid(var21);
   }

   public void hReturningVoid(Object[] var1) {
      float var5 = (Float)var1[0];
      float var2 = (Float)var1[1];
      long var3 = (Long)var1[2];
      var3 = 7820857091329L ^ var3;
      long var6 = var3 ^ 84467910840916L;
      long var8 = var3 ^ 105789632416339L;
      long var10 = var3 ^ 105261700148405L;
      long var12 = var3 ^ 49711716674714L;
      int var14 = Event.bReturningInt();
      int var67 = var14;
      HudElement var66 = this;
      HudElement var41 = var66;
      HudElement var40 = var66;
      if (var67 == 0) {
         boolean var68 = var40.n;
         if (var68) {
            this.o += var5;
            this.p += var2;
            this.e += var5;
            this.f += var2;
            return;
         }

         var41 = this;
      }

      HudAlignment var72 = HudAlignment.End;
      HudAlignment var71 = this.i;
      float var70 = var41.k;
      HudElement var69 = var41;
      HudElement var44 = var69;
      float var45 = var70;
      HudElement var42 = var69;
      float var43 = var70;
      HudElement var46;
      float var47;
      float var48;
      if (var71 == var72) {
         float var75 = -var5;
         float var74 = var43;
         HudElement var73 = var42;
         var46 = var73;
         var47 = var74;
         var48 = var75;
      } else {
         var48 = var5;
         var47 = var45;
         var46 = var44;
      }

      var46.k = var47 + var48;
      HudAlignment var79 = HudAlignment.End;
      HudAlignment var78 = this.j;
      float var77 = this.l;
      HudElement var76 = this;
      HudElement var51 = var76;
      float var52 = var77;
      HudElement var49 = var76;
      float var50 = var77;
      HudElement var53;
      float var54;
      float var55;
      if (var78 == var79) {
         float var82 = -var2;
         float var81 = var50;
         HudElement var80 = var49;
         var53 = var80;
         var54 = var81;
         var55 = var82;
      } else {
         var55 = var2;
         var54 = var52;
         var53 = var51;
      }

      var53.l = var54 + var55;
      int var84 = var14;
      HudElement var83 = this;
      HudElement var57 = var83;
      HudElement var56 = var83;
      if (var84 == 0) {
         Object[] var20 = new Object[]{var10};
         HudElement var19 = var56;
         var19.eReturningVoid(var20);
         MinecraftClient var21 = b;
         Window var85 = var21.getWindow();
         if (var85 == null) {
            return;
         }

         HudElement var86 = this;
         var57 = var86;
      }

      float var106;
      int var10000 = (var106 = var57.g - 0.0F) == 0.0F ? 0 : (var106 < 0.0F ? -1 : 1);
      int var88 = var14;
      int var87 = var10000;
      int var59 = var87;
      int var58 = var87;
      if (var88 == 0) {
         int var89 = var58;
         if (var89 <= 0) {
            return;
         }

         float var107;
         int var90 = (var107 = this.h - 0.0F) == 0.0F ? 0 : (var107 < 0.0F ? -1 : 1);
         var59 = var90;
      }

      int var92 = var14;
      int var91 = var59;
      int var61 = var91;
      int var60 = var91;
      if (var92 == 0) {
         int var93 = var60;
         if (var93 <= 0) {
            return;
         }

         var61 = (((this.q) ? 1 : 0));
      }

      HudElement var65;
      label75: {
         int var95 = var14;
         int var94 = var61;
         int var64 = var94;
         int var62 = var94;
         if (var95 == 0) {
            int var96 = var62;
            if (var96 == 0) {
               MinecraftClient var28 = b;
               Window var29 = var28.getWindow();
               float var10001 = var29.getFramebufferWidth();
               Object[] var30 = new Object[]{var12};
               var10001 /= HudEditorScreen.bReturningFloat(var30);
               Object[] var10004 = new Object[]{null, var6};
               var10004[0] = var10001;
               Object[] var32 = var10004;
               HudElement var31 = this;
               var31.cReturningVoid(var32);
            }

            int var98 = var14;
            HudElement var97 = this;
            var65 = var97;
            HudElement var63 = var97;
            if (var98 != 0) {
               break label75;
            }

            byte var99 = ((byte)((var63.r) ? 1 : 0));
            var64 = var99;
         }

         int var100 = var64;
         if (var100 != 0) {
            return;
         }

         var65 = this;
      }

      MinecraftClient var35 = b;
      Window var36 = var35.getWindow();
      float var103 = var36.getFramebufferHeight();
      Object[] var37 = new Object[]{var12};
      var103 /= HudEditorScreen.bReturningFloat(var37);
      Object[] var105 = new Object[]{null, var8};
      var105[0] = var103;
      Object[] var39 = var105;
      HudElement var38 = var65;
      var38.dReturningVoid(var39);
   }

   public void iReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      float var3 = (Float)var1[1];
      this.g = var2;
      this.h = var3;
   }

   public void jReturningVoid(Object[] var1) {
      long var4;
      long var6;
      long var8;
      int var10;
      BooleanSetting var32;
      byte var33;
      label30: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 127918346360774L;
         var6 = var2 ^ 55588640037348L;
         var8 = var2 ^ 79753987421705L;
         var10 = Event.bReturningInt();
         BooleanSetting var11;
         BooleanSetting var10000 = var11 = this.d;
         Boolean var12 = (Boolean)var11.aReturningObject();
         byte var10001 = ((byte)(((java.lang.Boolean)(var12)).booleanValue() ? 1 : 0));
         int var36 = var10;
         byte var35 = var10001;
         BooleanSetting var34 = var10000;
         BooleanSetting var29 = var34;
         byte var30 = var35;
         BooleanSetting var25 = var34;
         byte var26 = var35;
         if (var36 == 0) {
            byte var38 = var26;
            BooleanSetting var37 = var25;
            BooleanSetting var31 = var37;
            BooleanSetting var27 = var37;
            if (var38 != 0) {
               var33 = 0;
               var32 = var31;
               break label30;
            }

            BooleanSetting var39 = var27;
            BooleanSetting var28 = var39;
            var30 = 1;
            var29 = var28;
         }

         byte var41 = var30;
         BooleanSetting var40 = var29;
         var32 = var40;
         var33 = var41;
      }

      label23: {
         byte var14 = var33;
         Boolean var16 = Boolean.valueOf(dev.prestige.recovery.SourceSupport.asBoolean(var14));
         BooleanSetting var15 = var32;
         var15.aReturningVoid(var16);
         int var42 = var10;
         if (var42 == 0) {
            Object[] var18 = new Object[]{var6};
            HudElement var17 = this;
            boolean var43 = var17.eReturningBoolean(var18);
            if (!var43) {
               break label23;
            }

            EventBus var45 = Prestige.b;
            Object[] var21 = new Object[]{this, var4};
            EventBus var20 = var45;
            var20.aReturningVoid(var21);
         }

         int var44 = var10;
         if (var44 == 0) {
            return;
         }
      }

      EventBus var46 = Prestige.b;
      Object[] var24 = new Object[]{this, var8};
      EventBus var23 = var46;
      var23.bReturningVoid(var24);
   }

   public boolean eReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 7820857091329L ^ var2;
      BooleanSetting var4 = this.d;
      Boolean var5 = (Boolean)var4.aReturningObject();
      return var5;
   }

   public void kReturningVoid(Object[] var1) {
   }

   public void lReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[3]);
   }

   public void mReturningVoid(Object[] var1) {
      SourceSupport.discard(var1[0]);
   }

   public void nReturningVoid(Object[] var1) {
      float var199;
      float var202;

      Matrix4f var2;
      int var3;
      int var4;
      float var5;
      float var6;
      ArrayList var7;
      float var8;
      float var11;
      int var12;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      int var33;
      long var175;
      int var10000;
      label247: {
         label250: {
            var2 = (Matrix4f)var1[0];
            var11 = (Float)var1[1];
            var8 = (Float)var1[2];
            var5 = (Float)var1[3];
            var6 = (Float)var1[4];
            var3 = (Integer)var1[5];
            var12 = (Integer)var1[6];
            var4 = (Integer)var1[7];
            var7 = (ArrayList)var1[8];
            long var9 = (Long)var1[9];
            var175 = 7820857091329L ^ var9;
            var13 = var175 ^ 68641359461806L;
            var15 = var175 ^ 113815725352474L;
            var17 = var175 ^ 63336938104800L;
            var19 = var175 ^ 93696964835605L;
            var21 = var175 ^ 55147459712697L;
            var23 = var175 ^ 34519800933876L;
            var25 = var175 ^ 63155990561288L;
            var27 = var175 ^ 25405194921297L;
            var29 = var175 ^ 39997388426783L;
            var31 = var175 ^ 12182583967236L;
            var33 = Event.bReturningInt();
            float var245;
            var10000 = (var245 = var3 - var11) == 0.0F ? 0 : (var245 < 0.0F ? -1 : 1);
            if (var33 == 0) {
               if (var10000 <= 0) {
                  break label250;
               }

               float var246;
               var10000 = (var246 = var3 - (var11 + var5)) == 0.0F ? 0 : (var246 < 0.0F ? -1 : 1);
            }

            if (var33 == 0) {
               if (var10000 >= 0) {
                  break label250;
               }

               float var247;
               var10000 = (var247 = var12 - var8) == 0.0F ? 0 : (var247 < 0.0F ? -1 : 1);
            }

            if (var33 == 0) {
               if (var10000 <= 0) {
                  break label250;
               }

               float var248;
               var10000 = (var248 = var12 - (var8 + var6)) == 0.0F ? 0 : (var248 < 0.0F ? -1 : 1);
            }

            if (var33 != 0) {
               break label247;
            }

            if (var10000 < 0) {
               var10000 = 1;
               break label247;
            }
         }

         var10000 = 0;
      }

      int var34;
      var34 = var10000;
      var10000 = (((this.s) ? 1 : 0));
      label226:
      if (var33 == 0) {
         if (this.s) {
            float var35 = var3 + this.t;
            float var36 = var12 + this.u;
            this.e = var35;
            this.f = var36;
            MinecraftClient var59 = b;
            Window var60 = var59.getWindow();
            long var183 = var60.getHandle();
            int var10001 = 472;
            long var10002 = 3557289092388637049L ^ var175;
            long var61 = var183;
            var10000 = GLFW.glfwGetKey(var61, 340);
            if (var33 != 0) {
               break label226;
            }

            if (var10000 != 1) {
               float var37 = 5.0F;
               float var38 = 5.0F;
               HudAnchor var39 = null;
               HudAnchor var40 = null;
               Iterator var43 = var7.iterator();

               label219: {
                  while (var43.hasNext()) {
                     HudAnchor var44 = (HudAnchor)var43.next();
                     int[] var184 = HudAxisSwitchMap.a;
                     Object[] var69 = new Object[0];
                     HudAxis var70 = var44.aReturningu_C0442(var69);
                     var10000 = var184[var70.ordinal()];
                     if (var33 != 0) {
                        break label219;
                     }

                     label253: {
                        label254: {
                           if (var33 == 0) {
                              switch (var10000) {
                                 case 1:
                                    Object[] var74 = new Object[0];
                                    var10000 = var44.aReturningInt(var74);
                                    break;
                                 case 2:
                                    break label254;
                                 default:
                                    break label253;
                              }
                           }

                           float var76 = var10000 - this.e;
                           float var45 = Math.abs(var76);
                           Object[] var78 = new Object[0];
                           float var79 = var44.aReturningInt(var78) - (this.e + this.g);
                           float var46 = Math.abs(var79);
                           Object[] var81 = new Object[0];
                           float var82 = var44.aReturningInt(var81) - (this.e + this.g / 2.0F);
                           float var47 = Math.abs(var82);
                           float var249;
                           var10000 = (var249 = var45 - var37) == 0.0F ? 0 : (var249 < 0.0F ? -1 : 1);
                           if (var33 == 0) {
                              if (var10000 < 0) {
                                 var37 = var45;
                                 var39 = var44;
                                 var41 = 0;
                              }

                              float var250;
                              var10000 = (var250 = var46 - var37) == 0.0F ? 0 : (var250 < 0.0F ? -1 : 1);
                           }

                           if (var33 == 0) {
                              if (var10000 < 0) {
                                 var37 = var46;
                                 var39 = var44;
                                 var41 = 1;
                              }

                              float var251;
                              var10000 = (var251 = var47 - var37) == 0.0F ? 0 : (var251 < 0.0F ? -1 : 1);
                           }

                           if (var33 == 0) {
                              if (var10000 >= 0) {
                                 break label253;
                              }

                              var37 = var47;
                              var39 = var44;
                              var10000 = 2;
                           }

                           var41 = var10000;
                           if (var33 == 0) {
                              break label253;
                           }
                        }

                        Object[] var87 = new Object[0];
                        float var88 = var44.aReturningInt(var87) - this.f;
                        float var48 = Math.abs(var88);
                        Object[] var90 = new Object[0];
                        float var91 = var44.aReturningInt(var90) - (this.f + this.h);
                        float var49 = Math.abs(var91);
                        Object[] var93 = new Object[0];
                        float var94 = var44.aReturningInt(var93) - (this.f + this.h / 2.0F);
                        float var50 = Math.abs(var94);
                        float var252;
                        var10000 = (var252 = var48 - var38) == 0.0F ? 0 : (var252 < 0.0F ? -1 : 1);
                        if (var33 == 0) {
                           if (var10000 < 0) {
                              var38 = var48;
                              var40 = var44;
                              var42 = 0;
                           }

                           float var253;
                           var10000 = (var253 = var49 - var38) == 0.0F ? 0 : (var253 < 0.0F ? -1 : 1);
                        }

                        if (var33 == 0) {
                           if (var10000 < 0) {
                              var38 = var49;
                              var40 = var44;
                              var42 = 1;
                           }

                           float var254;
                           var10000 = (var254 = var50 - var38) == 0.0F ? 0 : (var254 < 0.0F ? -1 : 1);
                        }

                        if (var33 == 0) {
                           if (var10000 >= 0) {
                              break label253;
                           }

                           var38 = var50;
                           var40 = var44;
                           var10000 = 2;
                        }

                        var42 = var10000;
                     }

                     if (var33 != 0) {
                        break;
                     }
                  }

                  MinecraftClient var98 = b;
                  Window var99 = var98.getWindow();
                  var10000 = var99.getFramebufferWidth();
               }

               float var188 = var10000;
               Object[] var100 = new Object[]{var27};
               float var180 = var188 / HudEditorScreen.bReturningFloat(var100);
               MinecraftClient var101 = b;
               Window var102 = var101.getWindow();
               float var189 = var102.getFramebufferHeight();
               Object[] var103 = new Object[]{var27};
               float var181 = var189 / HudEditorScreen.bReturningFloat(var103);
               HudAnchor var190 = var39;
               if (var33 == 0) {
                  if (var39 != null) {
                     label256: {
                        var10001 = var41;
                        if (var33 == 0) {
                           if (var41 == 0) {
                              Object[] var108 = new Object[0];
                              var199 = var39.aReturningInt(var108);
                              break label256;
                           }

                           var10001 = var41;
                        }

                        if (var33 == 0) {
                           if (var10001 == 1) {
                              Object[] var112 = new Object[0];
                              var199 = var39.aReturningInt(var112) - this.g;
                              break label256;
                           }

                           Object[] var115 = new Object[0];
                           var10001 = var39.aReturningInt(var115);
                        }

                        var199 = var10001 - this.g / 2.0F;
                     }

                     this.e = var199;
                     Object[] var117 = new Object[0];
                     float var200 = var39.aReturningInt(var117) - 0.5F;
                     Object[] var119 = new Object[0];
                     float var10003 = var39.aReturningInt(var119) + 0.5F;
                     Object[] var120 = new Object[]{var21};
                     Object[] var10008 = new Object[]{null, null, null, null, null, ClientUiUtil.dReturningColor(var120), var15};
                     var10008[4] = var181;
                     var10008[3] = var10003;
                     var10008[2] = -1.0F;
                     var10008[1] = var200;
                     var10008[0] = var2;
                     Object[] var121 = var10008;
                     GameRenderUtil.r(var121);
                  }

                  var190 = var40;
               }

               if (var190 != null) {
                  label257: {
                     var10001 = var42;
                     if (var33 == 0) {
                        if (var42 == 0) {
                           Object[] var125 = new Object[0];
                           var202 = var40.aReturningInt(var125);
                           break label257;
                        }

                        var10001 = var42;
                     }

                     if (var33 == 0) {
                        if (var10001 == 1) {
                           Object[] var129 = new Object[0];
                           var202 = var40.aReturningInt(var129) - this.h;
                           break label257;
                        }

                        Object[] var132 = new Object[0];
                        var10001 = var40.aReturningInt(var132);
                     }

                     var202 = var10001 - this.h / 2.0F;
                  }

                  this.f = var202;
                  Object[] var134 = new Object[0];
                  float var206 = var40.aReturningInt(var134) - 0.5F;
                  Object[] var136 = new Object[0];
                  float var10004 = var40.aReturningInt(var136) + 0.5F;
                  Object[] var137 = new Object[]{var21};
                  Object[] var233 = new Object[]{null, null, null, null, null, ClientUiUtil.dReturningColor(var137), var15};
                  var233[4] = var10004;
                  var233[3] = var180;
                  var233[2] = var206;
                  var233[1] = 0.0F;
                  var233[0] = var2;
                  Object[] var138 = var233;
                  GameRenderUtil.r(var138);
               }
            }
         }

         Object[] var140 = new Object[]{var31};
         var10000 = (((this.eReturningBoolean(var140)) ? 1 : 0));
      }

      Color var191;
      if (var10000 != 0) {
         Object[] var141 = new Object[]{var21};
         Color var142 = ClientUiUtil.dReturningColor(var141);
         int var207 = var142.getRed();
         Object[] var143 = new Object[]{var21};
         Color var144 = ClientUiUtil.dReturningColor(var143);
         int var213 = var144.getGreen();
         Object[] var145 = new Object[]{var21};
         Color var146 = ClientUiUtil.dReturningColor(var145);
         int var220 = var146.getBlue();
         short var10005 = 12452;
         long var10006 = 1771414072446416904L ^ var175;
         var191 = new Color(var207, var213, var220, 40);
      } else {
         
         short var208 = 24914;
         long var214 = 4179000281244838391L ^ var175;
         short var215 = 2442;
         long var221 = 1449779780166762796L ^ var175;
         short var222 = 2442;
         long var227 = 1449779780166762796L ^ var175;
         byte var229;
         if (var34 != 0) {
            short var228 = 7312;
            long var232 = 9028093961108149299L ^ var175;
            var229 = 12;
         } else {
            var229 = 5;
         }

         var191 = new Color(255, 255, 255, var229);
      }

      Color var176 = var191;
      Matrix4f var192 = var2;
      float var203 = var11;
      float var209 = var8;
      float var216 = var11 + var5;
      float var223 = var8 + var6;
      if (var33 == 0) {
         Object[] var10009 = new Object[]{null, null, null, null, null, var176, new Vector4f(3.0F), var29};
         var10009[4] = var223;
         var10009[3] = var216;
         var10009[2] = var8;
         var10009[1] = var11;
         var10009[0] = var2;
         Object[] var149 = var10009;
         ShapeRenderer.u(var149);
         Object[] var151 = new Object[]{var31};
         if (this.eReturningBoolean(var151)) {
            var209 = var8 + 1.5F;
            var216 = var11 + 2.0F;
            var223 = var8 + var6 - 1.5F;
            Object[] var153 = new Object[]{var21};
            var10009 = new Object[]{null, null, null, null, null, ClientUiUtil.dReturningColor(var153), new Vector4f(1.0F), var29};
            var10009[4] = var223;
            var10009[3] = var216;
            var10009[2] = var209;
            var10009[1] = var11;
            var10009[0] = var2;
            Object[] var154 = var10009;
            ShapeRenderer.u(var154);
         }

         var192 = var2;
         var203 = var11;
         var209 = var8;
         var216 = var11 + var5;
         var223 = var8 + var6;
      }

      Color var230;
      short var10007 = 2442;
      long var234 = 1449779780166762796L ^ var175;
      short var235 = 2442;
      long var238 = 1449779780166762796L ^ var175;
      short var239 = 2442;
      long var10010 = 1449779780166762796L ^ var175;
      byte var242;
      if (var34 != 0) {
         short var241 = 24852;
         long var10011 = 6184106357216094644L ^ var175;
         var242 = 18;
      } else {
         short var243 = 18566;
         long var244 = 5629007827199459362L ^ var175;
         var242 = 8;
      }

      var230 = new Color(255, 255, 255, var242);
      Object[] var240 = new Object[]{null, null, null, null, null, null, null, var19};
      var240[6] = 3.0F;
      var240[5] = var230;
      var240[4] = var223;
      var240[3] = var216;
      var240[2] = var209;
      var240[1] = var203;
      var240[0] = var192;
      Object[] var157 = var240;
      GameRenderUtil.lReturningVoid(var157);
      Object[] var159 = new Object[]{var31};
      float var177 = var11 + (this.eReturningBoolean(var159) ? 6.0F : 3.0F);
      float var193 = var8 + var6 / 2.0F;
      MsdfFontManager var204 = Prestige.c;
      Object[] var161 = new Object[]{var23};
      MsdfFontManager var160 = var204;
      MsdfFont var205 = var160.aReturningcx_C0158(var161);
      Object[] var163 = new Object[]{var13};
      MsdfFont var162 = var205;
      float var178 = var193 - var162.cReturningFloat(var163) / 2.0F;
      Object[] var165 = new Object[]{var31};
      Color var194;
      if (this.eReturningBoolean(var165)) {
         var194 = Color.WHITE;
      } else {
         short var211 = 23364;
         long var218 = 284603461932684262L ^ var175;
         short var219 = 1465;
         long var225 = 5428161476634529054L ^ var175;
         short var226 = 1465;
         long var231 = 5428161476634529054L ^ var175;
         var194 = new Color(180, 180, 180);
      }

      Color var179 = var194;
      MsdfFontManager var195 = Prestige.c;
      Object[] var168 = new Object[]{var23};
      MsdfFontManager var167 = var195;
      MsdfFont var196 = var167.aReturningcx_C0158(var168);
      String var212 = this.a;
      Object[] var236 = new Object[]{null, null, null, null, var179, var25};
      var236[3] = var178;
      var236[2] = var177;
      var236[1] = var212;
      var236[0] = var2;
      Object[] var170 = var236;
      MsdfFont var169 = var196;
      var169.v(var170);
      var10000 = var4;
      if (var33 == 0) {
         if (var4 != 1) {
            return;
         }

         var10000 = var34;
      }

      if (var10000 != 0) {
         Object[] var174 = new Object[]{var17};
         this.jReturningVoid(var174);
      }
   }

   public void o(Object[] var1) {
      int var6 = (Integer)var1[0];
      int var4 = (Integer)var1[1];
      byte var5 = (byte)(((Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)((java.lang.Boolean)(Object)((Object)((Object)((Object)(var1[2]))))))))) ? 1 : 0);
      long var2 = (Long)var1[3];
      var2 = 7820857091329L ^ var2;
      long var7 = var2 ^ 104851062222182L;
      int var9 = Event.cReturningInt();
      int var32 = var9;
      byte var31 = var5;
      int var21 = var31;
      byte var17 = var31;
      if (var32 != 0) {
         byte var33 = var17;
         if (var33 != 0) {
            int var35 = var9;
            HudElement var34 = this;
            HudElement var20 = var34;
            HudElement var18 = var34;
            if (var35 != 0) {
               HudElement var36 = var18;
               HudElement var19 = var36;
               boolean var37 = var19.s;
               if (!var37) {
                  return;
               }

               this.s = dev.prestige.recovery.SourceSupport.asBoolean(0);
               HudElement var38 = this;
               var20 = var38;
            }

            Object[] var16 = new Object[]{var7};
            HudElement var15 = var20;
            var15.bReturningVoid(var16);
            return;
         }

         float var58;
         var21 = (var58 = var6 - this.e) == 0.0F ? 0 : (var58 < 0.0F ? -1 : 1);
      }

      int var30;
      label73: {
         int var29;
         label72: {
            label77: {
               int var40 = var9;
               int var39 = var21;
               int var23 = var39;
               int var22 = var39;
               if (var40 != 0) {
                  int var41 = var22;
                  if (var41 <= 0) {
                     break label77;
                  }

                  float var59;
                  int var42 = (var59 = var6 - (this.e + this.g)) == 0.0F ? 0 : (var59 < 0.0F ? -1 : 1);
                  var23 = var42;
               }

               int var44 = var9;
               int var43 = var23;
               int var25 = var43;
               int var24 = var43;
               if (var44 != 0) {
                  int var45 = var24;
                  if (var45 >= 0) {
                     break label77;
                  }

                  float var60;
                  int var46 = (var60 = var4 - this.f) == 0.0F ? 0 : (var60 < 0.0F ? -1 : 1);
                  var25 = var46;
               }

               int var48 = var9;
               int var47 = var25;
               int var27 = var47;
               int var26 = var47;
               if (var48 != 0) {
                  int var49 = var26;
                  if (var49 <= 0) {
                     break label77;
                  }

                  float var61;
                  int var50 = (var61 = var4 - (this.f + this.h)) == 0.0F ? 0 : (var61 < 0.0F ? -1 : 1);
                  var27 = var50;
               }

               int var52 = var9;
               int var51 = var27;
               var29 = var51;
               int var28 = var51;
               if (var52 == 0) {
                  break label72;
               }

               int var53 = var28;
               if (var53 < 0) {
                  var29 = 1;
                  break label72;
               }
            }

            var30 = 0;
            break label73;
         }

         int var54 = var29;
         var30 = var54;
      }

      int var10 = var30;
      int var55 = var9;
      if (var55 != 0) {
         int var56 = var10;
         if (var56 == 0) {
            return;
         }

         this.t = this.e - var6;
         this.u = this.f - var4;
      }

      this.s = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   public void p(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 7820857091329L ^ var2;
      long var4 = var2 ^ 100955262189055L;
      invokeBinding1(this, new Object[]{new Matrix4f(), var4}, -6321409059974347581L, var2);
   }

   public void q(Object[] var1) {
      Matrix4f var4 = (Matrix4f)var1[0];
      long var2 = (Long)var1[1];
      long var5 = var2 ^ 132376756164649L;
      float var10001 = this.e;
      float var10002 = this.f;
      float var10003 = this.e + this.g;
      float var10004 = this.f + this.h;
      Color var10005 = Color.WHITE;
      Object[] var10009 = new Object[]{null, null, null, null, null, null, null, var5};
      var10009[6] = 0.0F;
      var10009[5] = var10005;
      var10009[4] = var10004;
      var10009[3] = var10003;
      var10009[2] = var10002;
      var10009[1] = var10001;
      var10009[0] = var4;
      Object[] var7 = var10009;
      GameRenderUtil.lReturningVoid(var7);
   }

   public String aReturningString(Object[] var1) {
      return this.a;
   }

   public float aReturningFloat(Object[] var1) {
      return this.e;
   }

   public float bReturningFloat(Object[] var1) {
      return this.f;
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(13818380259259L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var15 = var13.doFinal("sv_êîÓÃ0".getBytes("ISO-8859-1"));
      String var22 = a(var15).intern();
      int var10001 = -1;
      A = var22;
      G = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(13818380259259L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[9];
      String var4 = "í\u0011§a¬¾|\u0015\\s\u0005Ìu\u0092Ð¬×^R\u0086\u0019ÝyëÎpáoä\u0007gg7¸pHqO¶Óï\u009dÍ¶û\b\u0015k·\u009aØ{|C6z";
      int var5 = "í\u0011§a¬¾|\u0015\\s\u0005Ìu\u0092Ð¬×^R\u0086\u0019ÝyëÎpáoä\u0007gg7¸pHqO¶Óï\u009dÍ¶û\b\u0015k·\u009aØ{|C6z".length();
      label29:
      while (true) {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var18 = var6;
         var10001 = var3++;
         long var24 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var24;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var29 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var27) {
               case 0:
                  var18[var10001] = var29;
                  if (var2 >= var5) {
                     E = var6;
                     F = new Integer[9];
                     break;
                  }
                  break;
               default:
                  var18[var10001] = var29;
                  if (var2 < var5) {
                     continue label29;
                  }

                  var4 = "+õ\u0006¢vô@JPxE0í¤\u0085¤";
                  var5 = "+õ\u0006¢vô@JPxE0í¤\u0085¤".length();
                  var2 = 0;
            }

            int var21 = var2;
            var2 += 8;
            var7 = var4.substring(var21, var2).getBytes("ISO-8859-1");
            var18 = var6;
            var10001 = var3++;
            var24 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var27 = 0;
         }
      }
   
      }

      
}

   private static MatchException b(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15407;
      if (F[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = E[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])G.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               G.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b1", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         F[var3] = var15;
      }

      return F[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b1",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = N[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = M[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 47;
            yield var15;
         }
         case 1 -> {
            byte var16 = 27;
            yield var16;
         }
         case 2 -> {
            byte var17 = 40;
            yield var17;
         }
         case 3 -> {
            byte var18 = 11;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 21;
            yield var22;
         }
         case 8 -> {
            byte var23 = 39;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 5;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 31;
            yield var27;
         }
         case 13 -> {
            byte var28 = 10;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 32;
            yield var30;
         }
         case 16 -> {
            byte var31 = 60;
            yield var31;
         }
         case 17 -> {
            byte var32 = 51;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 12;
            yield var34;
         }
         case 20 -> {
            byte var35 = 1;
            yield var35;
         }
         case 21 -> {
            byte var36 = 22;
            yield var36;
         }
         case 22 -> {
            byte var37 = 3;
            yield var37;
         }
         case 23 -> {
            byte var38 = 45;
            yield var38;
         }
         case 24 -> {
            byte var39 = 9;
            yield var39;
         }
         case 25 -> {
            byte var40 = 18;
            yield var40;
         }
         case 26 -> {
            byte var41 = 46;
            yield var41;
         }
         case 27 -> {
            byte var42 = 52;
            yield var42;
         }
         case 28 -> {
            byte var43 = 4;
            yield var43;
         }
         case 29 -> {
            byte var44 = 48;
            yield var44;
         }
         case 30 -> {
            byte var45 = 62;
            yield var45;
         }
         case 31 -> {
            byte var46 = 14;
            yield var46;
         }
         case 32 -> {
            byte var47 = 29;
            yield var47;
         }
         case 33 -> {
            byte var48 = 61;
            yield var48;
         }
         case 34 -> {
            byte var49 = 15;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 41;
            yield var51;
         }
         case 37 -> {
            byte var52 = 49;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 43;
            yield var54;
         }
         case 40 -> {
            byte var55 = 28;
            yield var55;
         }
         case 41 -> {
            byte var56 = 54;
            yield var56;
         }
         case 42 -> {
            byte var57 = 19;
            yield var57;
         }
         case 43 -> {
            byte var58 = 23;
            yield var58;
         }
         case 44 -> {
            byte var59 = 8;
            yield var59;
         }
         case 45 -> {
            byte var60 = 55;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 53;
            yield var63;
         }
         case 49 -> {
            byte var64 = 0;
            yield var64;
         }
         case 50 -> {
            byte var65 = 30;
            yield var65;
         }
         case 51 -> {
            byte var66 = 44;
            yield var66;
         }
         case 52 -> {
            byte var67 = 24;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 38;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 35;
            yield var72;
         }
         case 58 -> {
            byte var73 = 58;
            yield var73;
         }
         case 59 -> {
            byte var74 = 42;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 25;
            yield var76;
         }
         case 62 -> {
            byte var77 = 59;
            yield var77;
         }
         default -> 34;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            N[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      M[0] = "1\u0018~C5q'\u0018{\u0019&f0Sx\u001f*r!\u0014o\bacd";
      M[1] = "f='*2Tm26eQYx?9\u000ed[i,%\"sV";
      M[2] = "WM`gsAAMe=`VV\u0006f;lBGAq,'Pv";
      M[3] = int.class;
      N[3] = "java/lang/Integer";
      M[4] = "(\u0013\u001eL\u000em]3\u0015C\u001f\"<=\u001eH\u001bxH";
      M[5] = void.class;
      N[5] = "java/lang/Void";
      M[6] = "ZpX\u000f-\u0014ZpOS!\u001b@;OM!\u000eGJ\u001d\u0011tL";
      M[7] = "T\rub\u0017\u0019I\u0018-@V\u0014Q\u001e";
      M[8] = "6J#N\u000fV J&\u0014\u001cA7\u0001%\u0012\u0010U&F2\u0005[E>F0\u000e\u0001\b\u0002]0\u0013\u0001O5J";
      M[9] = "\u000e\u0019&X2?\u0018\u0019#\u0002!(\u000fR \u0004-<\u001e\u00157\u0013f,\u0010";
      M[10] = "|8>\u001czly-5\u001cqwu=wuZ]D";
      M[11] = long.class;
      N[11] = "java/lang/Long";
      M[12] = "0\u0018_l\u0011(.\u0010E#v)?\u000bHyP/";
      M[13] = "[,\b\u0014u@P#\u0019[\u0014N[(\u001d\u0001";
      M[14] = "[M\u0003PeVMM\u0006\nvAZ\u0006\u0005\fzUKA\u0012\u001b1EV";
      M[15] = "'y'.6CRY,!'\f3W'*#VG";
      M[16] = "Tg\u0000a:/Bg\u0005;)8U,\u0006=%,Dk\u0011*n*";
      M[17] = "\u0010X3mR$ex8bCk\u0004v3iG1p";
      M[18] = "\rYY\\\u00062\u0006VH\u0013e?\u0013P";
      M[19] = float.class;
      N[19] = "java/lang/Float";
      M[20] = "\u0011,L\u0018\u001f\u0005\u0011,[D\u0013\n\u000bg[Z\u0013\u001f\f\u0016\u000b\u0007B";
      M[21] = boolean.class;
      N[21] = "java/lang/Boolean";
      M[22] = "\u0011\u001aM'K^\u0007\u001aH}XI\u0010QK{T]\u0001\u0016\\l\u001fJ\u0002";
      M[23] = "b?/O-F\u0017\u001f$@<\tv\u0011/K8S\u0002";
      M[24] = "[\u0014}'n{M\u0014x}}lZ_{{qxK\u0018ll:j}";
      M[25] = "\u001c\u007fxA Qi_sN1\u001e\bQxE5D|";
      M[26] = "Y@7u\u0017!O@2/\u00046X\u000b1)\b\"IL&>C6e";
      M[27] = "mx~d\u0019\u0011\u0018Xuk\b^yV~`\f\u0004\r";
      M[28] = "E'lpP2[/v??5]'c]\u00174[";
      M[29] = " \b3\u000e\u0016GU(8\u0001\u0007\b4&3\n\u0003R@";
      M[30] = "\t1c\u0018pX\u001f1fBcO\bzeDo[\u0019=rS$K\u0015";
      M[31] = "+s)kH\u0018=s,1[\u000f*8/7W\u001b;\u007f8 \u001c\f9";
      M[32] = "e~^c\u000f?\u0010^Ul\u001epqP^g\u001a*\u0005";
      M[33] = "GY\rt%\u00052y\u0006{4JSw\rp0\u0010'";
      M[34] = "d\"=|\u001fl\u0011\u00026s\u000e#p\f=x\ny\u0004";
      M[35] = "oBm\u001c@>\u001abf\u0013Qq{lm\u0018U+\u000f";
      M[36] = "\u00064dY4\u0016s\u0014oV%Y\u0012\u001ad]!\u0003f";
      M[37] = "++8RQ\t^\u000b3]@F?\u00058VD\u001cK";
      M[38] = "\u0010\u000e\u001e\u001e:\u0013e.\u0015\u0011+\\\u0004 \u001e\u001a/\u0006p";
      M[39] = "Bu>O\nM7U5@\u001b\u0002V[>K\u001fX\"";
      M[40] = "PLQ@|TFLT\u001aoCQ\u0007W\u001ccW@@@\u000b(W";
      M[41] = "=\u001eS.\u0017\u0007H>X!\u0006H)0S*\u0002\u0012]";
      M[42] = "\u007f\u0000i\u001f\u0015P\n b\u0010\u0004\u001fk.i\u001b\u0000E\u001f";
      M[43] = "f1ioxk\u0013\u0011b`i$r\u001fikm~\u0006";
      M[44] = "\u0002\u0018z^4u\t\u0017k\u0011Xv\u0007\u0015i^t";
      M[45] = "]vm3*7Kvhi9 \\=ko54Mz|x~#\u007f";
      M[46] = ">W \">\u0014(W%x-\u0003?\u001c&~!\u0017.[1ij\u0006\u0016";
      M[47] = "\u0001vS\u0014gMtVX\u001bv\u0002\u0015XS\u0010rXa";
      M[48] = "o7Th8\u001d\u001a\u0017_g)R{\u0019Tl-\b\u000f";
      M[49] = ")@|\u0010n!i@hH\u0004r\u0010\u001coD4'yC=Jt\u0018";
      M[50] = "\u0015RN~?4\u000b]\u0017\u007f\u0003)\u0001F\u000bcD9hO\u0007?\u007f'W\u001c\u00187\u007fW\u0015RN~?4\u000b]\u0017\u007f\u0003";
      M[51] = "l;\\@\u001fo4}NOn3=:SK\u0002\u0001lz\u0003\u001dnl<(\u0003\u0013\u00073n&C,";
      M[52] = "w\u0001[$\u000eft\u0006Eh7S\n{dU71qY\u0004!]2vGH";
      M[53] = "+\u0013R){7o\u0001\u0015s\t?\u0016SVm6d|TPju";
      M[54] = "\u0016\u0017+~FWI\u0010{\u001dAj\u0006\u0018ex\u0000SJ\u0003bw8Q\u0013\u0001} \u0001TL\u0004y\u001d";
      M[55] = "@Gc\u0006Vx\u001f@3eBE\\]c]\u0017tLH(eT5\u0010\u0015lTD [-";
      M[56] = "-!\u0003C\u0002\u0000ug\u0011Ls\\| \fH\u001fn-aT\u0011s\u0003}2\\\u0010\u001a\\/<\u001c/";
      M[57] = "im >\u0000b/d*:z02h4\r\u0017#\u0015k:BJf8eqr\u0015\"mzKx\u00161f9\"'D?&\u0006q.\u0014oio.|\u001a/V";
      M[58] = "\u000bjPA,{KjD\u0019F)26C\u0015v}[i\u0011\u001b6B";
      M[59] = "\\\u0016rN\nUB\u0019+O6\\F\u0001.S_P\u007f\u000f.C[6L\u0017{BF\t\u001f\bsB6";
      M[60] = "\u0016\u0018WD \u0004\u0003EU\tJ\u001fhM]V'\u0012\n\u0001AF7v";
      M[61] = "\u001a=\u0011gKHA+Oe)EG'\u0003\u001e\u0018DD:\u001b|TXT*\u007f";
      M[62] = "\u0001)N\te0Y8@\u0016\u000b=0(G\u0012nl\td\\\u0015aTZgK\rf6W7O\u0002\u000b";
      M[63] = "#.J$\b&{?D;f+\u0012/C?\u0003z+cX8\fB(3HqY+waF1f";
      M[64] = "\bFB@1\u0017\b\u001f\u0016@_\f\u000e\u0004{Q3\u0001\u0004\u0014EX%\u0007\u0015\u007f\u0017Q;\u0005\u000fA\u001eG=\u0014d";
      M[65] = "\u0006+*qU*B9m+'#;+,7\u001btRinpK";
      M[66] = "\u000e9\u0005\u0006!\u001b\u00069HA\u001f@\u000e~Y^srY8\u0007\t$%_\u007fVUn\u001c\u00079DZ\u001f";
      M[67] = " ;\u0004()r{-Z*Kyy*,<;e\u0010<\u001b`7i/o\u0004h7\u0019";
      M[68] = "\u0013\u000f\u0005'\u0005x\u001e_\u0001(h}\u0003\\\r \u0001~y\n\u0000(X%\u0010UR&\u0018\u001a";
      M[69] = ")T\u0019g)(*S\u0007+\u0010-y\u0013 6|B.\u0003\u0014k/+qQ\u001a+\u0010";
      M[70] = "Q\u000e'Ejx\\D?@\r:?N0Phx\u0006\u0002+Wg@\u0004[)H0y\u0001\u0004,L\r";
      M[71] = "+:GV\u0007\u0003t=\u00175\u0017>;5\tPA\u0007w.\u000e_y\u0005.,\u0011\b@\u0000q)\u00155";
      M[72] = "L|\u0012nsuL%Fn\u001dlD,Nk\u001dkL!Kx#bZ'Z\u0013qkD%@-x}B4+\u007fqc@.\u0015vgeQEG\u007fygK{Ni\u007fv ";
      M[73] = "$hSQt'{o\u00032g\u001a4g\u001dW2#x|\u001aX\n!!~\u0005\u000f3$~{\u00012";
      M[74] = "b|>E\u0010.::,Jar3}1N\r@b=`\u0011a'go2\u0013Qx#:-)";
      M[75] = "r{]m\u0014ZtmSn$\u0006\u001dmJuAR$!QrNj &L7\u001d\u0000#!R{$";
      M[76] = "\u0002hgD3\u0013\u000213D]\u0004\u0007!^U1\u0005\u000e:`\\'\u0003\u001fQ2U9\u0001\u0005o;C?\u0010n=2]=\nP4$[,a";
      M[77] = "\u00047hUJM\u00070v\u0019sHTpA\r\u000eJ96g\u0007C\u0018Pi5\t\u0003'";
      M[78] = "gMxwmpdIdz\u0011t\u0006\u0001~{t&?Me|{\u001ej\u001d\u007fez c\u000byt\u0011";
      M[79] = "\u0007\u0013U?Vk\u0018\u001b^ 6t\u0019\u001fK'Jr\u001fr\u0001$Xl\u0007\u0019Z2\u0006ne";
      M[80] = "\r/F>?L\n)A}\u000fO3\"_\u007fj\u001e\nnDxe&Wi\u0002}}\u001aZmG;\u000f";
      M[81] = "ZuyK!u\u0005r)(4HJz7Mgq\u0006a0B_s_c/\u0015fv\u0000f+(";
      M[82] = "Y*_$OOAz@1 \u0019Xz[/I\u001a\",V'\u0010AKs\u0004)P~";
      M[83] = "\"O\u0018^>\f{\u0012\u0016\u001a\u0006AF_\u0017\u001cc\u0004\u007f\u0013\f\u001bl<}J\u000e\u0004;\u0005x\u0015\u000b\u0000\u0006";
      M[84] = "\u0018FQY\u001d\u001fGA\u0001:\u000f\"\bI\u001f_[\u001bDR\u0018Pc\u0019\u001dP\u0007\u0007Z\u001cBU\u0003:";
      M[85] = "\u000fylj'&\u0002}),Udk21h0\"R~*o?\u001aP'(ph#Ux-tU";
      M[86] = "\u0007P\u0004\u001eNx\u0012\r\u0006S$cy\u0005\u000e\fIn\u001bI\u0012\u001cY\nBQ\u0015\u0004\u00193G\u000e\u0010\u0000$";
      M[87] = "\u0013~B<~4Ly\u0012_m\t\u0003q\f:80Oj\u000b5\u0000d\u0002%\u000e/?7\u001d-\u000e_";
      M[88] = "4\u0002<\u001ds\u001c9H$\u0018\u0014@ZB+\bq\u001cc\u000e0\u000f~$aW2\u0010)\u001dd\b7\u0014\u0014";
      M[89] = "Ls\u001c\u0013\t\u0015\u0013tLp\u0015(\\|R\u0015O\u0011\u0010gU\u001aw\u0013IeJMN\u0016\u0016`Np";
      M[90] = "5\u0011AljSwS\u0006<WSK\u001eZ.2\u0002rRA)=:p\u000bC6j\u0003uTF2W";
      M[91] = "0\u0015026co\u0012`Q\"^ \u001a~4pgl\u0001y;He5\u0003flq`j\u0006bQ";
      M[92] = ">\u0014A\u0007\r\n3\u0010\u0004A\u007f]Z_\u001c\u0005\u001a\u000ec\u0013\u0007\u0002\u001566C\u001d\u001b\u0014\b?U\u001b\n\u007f";
      M[93] = "Tb7\u0017G\bWe)[~\r\u0004%\u001bQ\u0013\u000f\u000fYnG\u0010RV01\u0015\u001e\u0012i";
      M[94] = "2|\"3=Bp>ec\u0000ALs9qe\u0013u?\"vj+wf i=\u0012r9%m\u0000";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = M[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(N[var4]);
            M[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = M[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = N[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            M[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  M[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(982953488348346L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = M[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = N[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  M[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(982953488348346L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        M[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(982953488348346L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 88;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 70;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 231;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 234;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 36;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 217;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 88;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 70;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 231;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite f(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b1",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b1" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static void invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = f(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
