package dev.zprestige.prestige.client.ui.hud;

import net.minecraft.item.ItemStack;

public class ItemLabelData {
   public ItemStack a;
   public String b;

   public ItemLabelData(ItemStack var1, String var2) {
      this.a = var1;
      this.b = var2;
   }
}
