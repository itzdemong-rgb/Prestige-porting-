package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;

public class KeybindsWidget extends HudElement {
   private static final float m = 1.5F;
   private static final float a = 8.0F;
   private static final float c = 7.5F;
   private static final float d = 70.0F;
   private final Map g;
   private ManagedGlTexture h;
   private float k;
   private float l;
   private long i;
   private float o;
   private float p;
   private static final long v = 60640906816027L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long H;
   private static final Object[] I = new Object[115];
   private static final String[] J = new String[115];

   public KeybindsWidget(long var1) {
      super("Keybinds", "Show the client's keybinds", ((60640906816027L ^ (60640906816027L ^ var1)) ^ 5365963353428L));
      var1 = 60640906816027L ^ var1;
      long var3 = var1 ^ 5365963353428L;
      short var10001 = 20745;
      long var10002 = 3865055067655715934L ^ var1;
      short var6 = 4913;
      long var10003 = 7515373598132764261L ^ var1;

      this.g = new HashMap();
      this.k = 70.0F;
      this.l = 0.0F;
      this.i = H;
      this.o = 0.0F;
      this.p = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 63.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      KeybindsWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      boolean var363;

      long var2;
      RenderContext var4;
      Matrix4f var5;
      MeshBufferManager var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var25;
      long var27;
      long var29;
      long var31;
      long var33;
      long var35;
      long var37;
      int var39;
      label240: {
         var6 = (MeshBufferManager)var1[0];
         var4 = (RenderContext)var1[1];
         var5 = (Matrix4f)var1[2];
         var2 = (Long)var1[3];
         var7 = var2 ^ 48887442607471L;
         var9 = var2 ^ 91502317855300L;
         var11 = var2 ^ 36477842301344L;
         var13 = var2 ^ 13608202459885L;
         var15 = var2 ^ 29307267718371L;
         var17 = var2 ^ 113406911627307L;
         var19 = var2 ^ 17083579563515L;
         var21 = var2 ^ 51085646390574L;
         long var23 = var2 ^ 56760183293883L;
         var25 = var2 ^ 49928519994039L;
         var27 = var2 ^ 41197988814736L;
         var29 = var2 ^ 94840327315782L;
         var31 = var2 ^ 124694493719688L;
         var33 = var2 ^ 81054074941871L;
         var35 = var2 ^ 126879126745269L;
         var37 = var2 ^ 46684315333905L;
         var39 = Event.bReturningInt();
         int var282 = var39;
         KeybindsWidget var281 = this;
         KeybindsWidget var252 = var281;
         KeybindsWidget var251 = var281;
         if (var282 == 0) {
            ManagedGlTexture var283 = var251.h;
            if (var283 != null) {
               break label240;
            }

            KeybindsWidget var284 = this;
            var252 = var284;
         }

         short var10001 = 29241;
         long var10002 = 4512228842790528595L ^ var2;
         Object[] var76 = new Object[]{"assets/prestige/icons/other/keyboard.png", var23};
         var252.h = TextureLoader.aReturningbT_C0095(var76);
      }

      float var40 = (float)(System.currentTimeMillis() - this.i) * 0.005F;
      this.i = System.currentTimeMillis();
      MsdfFontManager var10000 = Prestige.c;
      Object[] var78 = new Object[]{var13};
      MsdfFontManager var77 = var10000;
      MsdfFont var378 = var77.aReturningcx_C0158(var78);
      Object[] var80 = new Object[]{var25};
      MsdfFont var79 = var378;
      float var41 = var79.cReturningFloat(var80);
      Object[] var10003 = new Object[]{null, 1.0F};
      var10003[0] = var41;
      Object[] var81 = var10003;
      float var42 = UiMetrics.aReturningFloat(var81);
      var10003 = new Object[]{null, 0.75F};
      var10003[0] = var41;
      Object[] var82 = var10003;
      float var43 = UiMetrics.aReturningFloat(var82);
      ArrayList var44 = new ArrayList();
      ModuleManager var83 = Prestige.d;
      List var84 = var83.aReturningVoid();
      Iterator var45 = var84.iterator();

      while (true) {
         Iterator var85 = var45;
         boolean var285 = var85.hasNext();
         if (!var285) {
            break;
         }

         Module var46;
         float var255;
         label230: {
            label229: {
               Iterator var86 = var45;
               var46 = (Module)var86.next();
               Module var87 = var46;
               byte var379 = ((byte)((var87.aReturningBoolean()) ? 1 : 0));
               int var287 = var39;
               byte var286 = var379;
               int var254 = var286;
               byte var253 = var286;
               if (var287 == 0) {
                  byte var288 = var253;
                  if (var288 == 0) {
                     break label229;
                  }

                  Object[] var90 = new Object[]{var9};
                  Module var89 = var46;
                  int var289 = var89.bReturningInt(var90);
                  var254 = var289;
               }

               
               if (var290 != var291) {
                  float var292 = 1.0F;
                  var255 = var292;
                  break label230;
               }
            }

            var255 = 0.0F;
         }

         float var47 = var255;
         Map var380 = this.g;
         float var93 = 0.0F;
         Float var96 = var93;
         Module var95 = var46;
         Map var94 = var380;
         Float var97 = ((java.lang.Float)(Object)(var94.getOrDefault(var95, var96)));
         float var381 = var97;
         Object[] var10005 = new Object[]{null, null, null, var27};
         var10005[2] = var40;
         var10005[1] = var47;
         var10005[0] = var381;
         Object[] var98 = var10005;
         float var48 = ClientUiUtil.bReturningFloat(var98);
         Map var382 = this.g;
         float var99 = var48;
         Float var102 = var99;
         Module var101 = var46;
         Map var100 = var382;
         var100.put(var101, var102);
         float var492;
         int var383 = (var492 = var48 - 0.05F) == 0.0F ? 0 : (var492 < 0.0F ? -1 : 1);
         int var294 = var39;
         int var293 = var383;
         int var257 = var293;
         int var256 = var293;
         if (var294 == 0) {
            int var295 = var256;
            if (var295 < 0) {
               continue;
            }

            Object[] var105 = new Object[]{var9};
            Module var104 = var46;
            int var106 = var104.bReturningInt(var105);
            String var384 = KeyEvent.getKeyText(var106);
            short var408 = 586;
            long var422 = 8393603705149249059L ^ var2;
            String var108 = "Unknown";
            String var107 = var384;
            var257 = (((var107.contains(var108)) ? 1 : 0));
         }

         String var260;
         label220: {
            int var297 = var39;
            int var296 = var257;
            int var259 = var296;
            int var258 = var296;
            if (var297 == 0) {
               int var298 = var258;
               if (var298 != 0) {
                  Object[] var111 = new Object[]{var9};
                  Module var110 = var46;
                  int var385 = var110.bReturningInt(var111);
                  var10003 = new Object[]{null, var29};
                  var10003[0] = var385;
                  Object[] var112 = var10003;
                  String var299 = ClientUiUtil.aReturningString(var112);
                  var260 = var299;
                  break label220;
               }

               Object[] var115 = new Object[]{var9};
               Module var114 = var46;
               var259 = var114.bReturningInt(var115);
            }

            int var116 = var259;
            var260 = KeyEvent.getKeyText(var116);
         }

         String var49 = var260;
         int var301 = var39;
         String var300 = var49;
         String var262 = var300;
         String var261 = var300;
         if (var301 == 0) {
            String var302 = var261;
            if (var302 == null) {
               continue;
            }

            var262 = var49;
         }

         String var118 = var262;
         boolean var386 = var118.isEmpty();
         int var304 = var39;
         boolean var303 = var386;
         boolean var263 = var303;
         if (var304 == 0) {
            boolean var305 = var263;
            if (var305) {
               continue;
            }

            ModuleListEntry var121 = new ModuleListEntry(var46, var49, var48);
            ArrayList var120 = var44;
            boolean var264 = var120.add(var121);
         }

         int var306 = var39;
         if (var306 != 0) {
            break;
         }
      }

      float var357 = 0.0F;
      float var358 = 70.0F;
      ArrayList var122 = var44;
      Iterator var359 = var122.iterator();

      while (true) {
         Iterator var123 = var359;
         boolean var307 = var123.hasNext();
         if (var307) {
            Iterator var124 = var359;
            ModuleListEntry var361 = (ModuleListEntry)var124.next();
            var10000 = Prestige.c;
            Object[] var126 = new Object[]{var13};
            MsdfFontManager var125 = var10000;
            MsdfFont var388 = var125.aReturningcx_C0158(var126);
            ModuleListEntry var127 = var361;
            Object[] var129 = new Object[]{var127.aX(), var33};
            MsdfFont var128 = var388;
            float var364 = var128.aReturningFloat(var129) * 0.75F + 5.5F;
            var10000 = Prestige.c;
            Object[] var131 = new Object[]{var13};
            MsdfFontManager var130 = var10000;
            MsdfFont var390 = var130.aReturningcx_C0158(var131);
            ModuleListEntry var132 = var361;
            Module var133 = var132.aW();
            Object[] var135 = new Object[]{var133.bReturningString(), var33};
            MsdfFont var134 = var390;
            float var50 = var134.aReturningFloat(var135) * 0.75F;
            ModuleListEntry var136 = var361;
            float var138 = var364 * var136.aY();
            float var137 = var357;
            var357 = Math.max(var137, var138);
            float var409 = 5.5F + var364 + 3.0F + var50 + 5.5F;
            ModuleListEntry var139 = var361;
            float var141 = var409 * var139.aY();
            float var140 = var358;
            var358 = Math.max(var140, var141);
            int var308 = var39;
            if (var308 != 0) {
               break;
            }

            int var309 = var39;
            if (var309 == 0) {
               continue;
            }
         }

         float var410 = this.k;
         float var432 = var40 * 2.0F;
         Object[] var10006 = new Object[]{null, null, null, var27};
         var10006[2] = var432;
         var10006[1] = var358;
         var10006[0] = var410;
         Object[] var143 = var10006;
         this.k = ClientUiUtil.bReturningFloat(var143);
         var410 = this.l;
         float var433 = var40 * 2.0F;
         var10006 = new Object[]{null, null, null, var27};
         var10006[2] = var433;
         var10006[1] = var357;
         var10006[0] = var410;
         Object[] var144 = var10006;
         this.l = ClientUiUtil.bReturningFloat(var144);
         break;
      }

      float var360 = var42;
      ArrayList var145 = var44;
      Iterator var362 = var145.iterator();

      int var311;
      do {
         Iterator var146 = var362;
         boolean var310 = var146.hasNext();
         if (!var310) {
            break;
         }

         Iterator var147 = var362;
         ModuleListEntry var365 = (ModuleListEntry)var147.next();
         float var412 = var43 + 1.5F;
         ModuleListEntry var148 = var365;
         var360 += var412 * var148.aY();
         var311 = var39;
      } while (var311 == 0);

      float var274;
      byte var366;
      label184: {
         Object[] var150 = new Object[0];
         KeybindsWidget var149 = this;
         var363 = var149.cReturningBoolean(var150);
         Object[] var152 = new Object[0];
         KeybindsWidget var151 = this;
         var366 = ((byte)((var151.dReturningBoolean(var152)) ? 1 : 0));
         MinecraftClient var153 = b;
         boolean var367 = var153.currentScreen instanceof HudEditorScreen;
         int var312 = var39;
         if (var312 == 0) {
            boolean var313 = var367;
            label173:
            if (!var313) {
               int var269;
               int var315 = var39;
               byte var314 = var366;
               var269 = var314;
               byte var265 = var314;
               label179:
               if (var315 == 0) {
                  byte var316 = var265;
                  byte var266 = var316;
                  byte var317 = var266;
                  if (var317 != 0) {
                     float var493;
                     int var391 = (var493 = this.o - 0.0F) == 0.0F ? 0 : (var493 < 0.0F ? -1 : 1);
                     int var319 = var39;
                     int var318 = var391;
                     var269 = var318;
                     int var267 = var318;
                     if (var319 != 0) {
                        break label179;
                     }

                     int var320 = var267;
                     int var268 = var320;
                     int var321 = var268;
                     if (var321 > 0) {
                        this.f = this.f - (var360 - this.o);
                     }
                  }

                  var269 = (((var363) ? 1 : 0));
               }

               int var323 = var39;
               int var322 = var269;
               int var273 = var322;
               int var270 = var322;
               if (var323 == 0) {
                  int var324 = var270;
                  if (var324 == 0) {
                     break label173;
                  }

                  int var326 = var39;
                  float var325 = this.p;
                  var274 = var325;
                  float var271 = var325;
                  if (var326 != 0) {
                     break label184;
                  }

                  float var327 = var271;
                  float var272 = var327;
                  float var494;
                  int var328 = (var494 = var272 - 0.0F) == 0.0F ? 0 : (var494 < 0.0F ? -1 : 1);
                  var273 = var328;
               }

               int var329 = var273;
               if (var329 > 0) {
                  this.e = this.e - (this.k - this.p);
               }
            }

            this.o = var360;
            this.p = this.k;
         }

         var274 = this.e;
      }

      float var51 = var274;
      float var52 = this.f;
      float var413 = this.k;
      Object[] var10004 = new Object[]{null, var360};
      var10004[0] = var413;
      Object[] var165 = var10004;
      KeybindsWidget var164 = this;
      var164.iReturningVoid(var165);
      Object[] var166 = new Object[]{var11};
      Color var53 = ClientUiUtil.dReturningColor(var166);
      byte var330 = var366;
      float var275;
      if (var330 != 0) {
         float var331 = var52 + var360 - var42;
         var275 = var331;
      } else {
         var275 = var52;
      }

      float var276;
      label162: {
         label161: {
            float var54;
            label246: {
               var54 = var275;
               short var392 = 17965;
               float var450 = this.k;
               Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, var7};
               var10012[8] = 4.0F;
               var10012[7] = 5;
               var10012[6] = var42;
               var10012[5] = var450;
               var10012[4] = var54;
               var10012[3] = var51;
               var10012[2] = var5;
               var10012[1] = var4;
               var10012[0] = var6;
               Object[] var168 = var10012;
               BlurredRectangleRenderer.eReturningVoid(var168);
               long var414 = 3363961205564445251L ^ var2;
               float var10007 = this.k;
               Color var10009 = UiMetrics.r;
               Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, var15};
               var10013[8] = 4.0F;
               var10013[7] = var10009;
               var10013[6] = var42;
               var10013[5] = var10007;
               var10013[4] = var54;
               var10013[3] = var51;
               var10013[2] = var5;
               var10013[1] = var4;
               var10013[0] = var6;
               Object[] var169 = var10013;
               FilledRectangleRenderer.cReturningVoid(var169);
               String var55 = "Keybinds";
               float var56 = (var42 - 7.5F) / 2.0F;
               float var57 = var54 + (var42 - var41) / 2.0F;
               byte var332 = ((byte)((var363) ? 1 : 0));
               if (var332 != 0) {
                  float var58 = var51 + this.k - 5.5F - 7.5F;
                  ManagedGlTexture var434 = this.h;
                  float var443 = var54 + var56;
                  Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, var53, var19};
                  var10011[7] = 7.5F;
                  var10011[6] = 7.5F;
                  var10011[5] = var443;
                  var10011[4] = var58;
                  var10011[3] = var434;
                  var10011[2] = var5;
                  var10011[1] = var4;
                  var10011[0] = var6;
                  Object[] var170 = var10011;
                  TexturedRectangleRenderer.cReturningVoid(var170);
                  float var59 = var58 - 3.0F - 0.5F;
                  float var423 = var54 + var56;
                  float var435 = var59 + 0.5F;
                  float var441 = var54 + var42 - var56;
                  Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var31};
                  var10008[4] = var441;
                  var10008[3] = var435;
                  var10008[2] = var423;
                  var10008[1] = var59;
                  var10008[0] = var5;
                  Object[] var171 = var10008;
                  ShapeRenderer.lReturningVoid(var171);
                  float var393 = var59 - 3.0F;
                  MsdfFontManager var415 = Prestige.c;
                  Object[] var173 = new Object[]{var13};
                  MsdfFontManager var172 = var415;
                  MsdfFont var416 = var172.aReturningcx_C0158(var173);
                  Object[] var175 = new Object[]{var55, var33};
                  MsdfFont var174 = var416;
                  float var60 = var393 - var174.aReturningFloat(var175);
                  int var336;
                  do {
                     String var176 = var55;
                     int var334 = var176.length();
                     int var333 = var61;
                     if (var333 >= var334) {
                        break;
                     }

                     int var178 = var61;
                     String var177 = var55;
                     char var179 = var177.charAt(var178);
                     String var62 = String.valueOf(var179);
                     var10000 = Prestige.c;
                     Object[] var181 = new Object[]{var13};
                     MsdfFontManager var180 = var10000;
                     MsdfFont var395 = var180.aReturningcx_C0158(var181);
                     short var451 = 10898;
                     long var453 = 679898252242061756L ^ var2;
                     short var454 = 17700;
                     long var461 = 8815556631949764107L ^ var2;
                     String var182 = var55;
                     int var455 = 10 + (var182.length() - 1 - var61);
                     Object[] var10010 = new Object[]{null, null, null, var35};
                     var10010[2] = var455;
                     var10010[1] = 10;
                     var10010[0] = var53;
                     Object[] var183 = var10010;
                     var10008 = new Object[]{null, null, null, null, GameRenderUtil.bReturningColor(var183), var37};
                     var10008[3] = var57;
                     var10008[2] = var60;
                     var10008[1] = var62;
                     var10008[0] = var5;
                     Object[] var185 = var10008;
                     MsdfFont var184 = var395;
                     var184.v(var185);
                     MsdfFontManager var417 = Prestige.c;
                     Object[] var187 = new Object[]{var13};
                     MsdfFontManager var186 = var417;
                     MsdfFont var418 = var186.aReturningcx_C0158(var187);
                     Object[] var189 = new Object[]{var62, var33};
                     MsdfFont var188 = var418;
                     var60 += var188.aReturningFloat(var189);
                     var61++;
                     int var335 = var39;
                     if (var335 != 0) {
                        break label246;
                     }

                     var336 = var39;
                  } while (var336 == 0);

                  int var337 = var39;
                  if (var337 == 0) {
                     break label246;
                  }
               }

               float var368 = var51 + 5.5F;
               ManagedGlTexture var436 = this.h;
               float var444 = var54 + var56;
               Object[] var479 = new Object[]{null, null, null, null, null, null, null, null, var53, var19};
               var479[7] = 7.5F;
               var479[6] = 7.5F;
               var479[5] = var444;
               var479[4] = var368;
               var479[3] = var436;
               var479[2] = var5;
               var479[1] = var4;
               var479[0] = var6;
               Object[] var191 = var479;
               TexturedRectangleRenderer.cReturningVoid(var191);
               float var370 = var368 + 7.5F + 3.0F;
               float var424 = var54 + var56;
               float var437 = var370 + 0.5F;
               float var442 = var54 + var42 - var56;
               Object[] var463 = new Object[]{null, null, null, null, null, UiMetrics.v, var31};
               var463[4] = var442;
               var463[3] = var437;
               var463[2] = var424;
               var463[1] = var370;
               var463[0] = var5;
               Object[] var192 = var463;
               ShapeRenderer.lReturningVoid(var192);
               float var372 = var370 + 0.5F + 3.0F;
               int var341;
               do {
                  String var193 = var55;
                  int var339 = var193.length();
                  int var338 = var374;
                  if (var338 >= var339) {
                     break;
                  }

                  int var195 = var374;
                  String var194 = var55;
                  char var196 = var194.charAt(var195);
                  String var376 = String.valueOf(var196);
                  var10000 = Prestige.c;
                  Object[] var198 = new Object[]{var13};
                  MsdfFontManager var197 = var10000;
                  MsdfFont var397 = var197.aReturningcx_C0158(var198);
                  short var452 = 17700;
                  long var456 = 8815556631949764107L ^ var2;
                  short var457 = 17700;
                  long var464 = 8815556631949764107L ^ var2;
                  int var458 = 10 + var374;
                  Object[] var473 = new Object[]{null, null, null, var35};
                  var473[2] = var458;
                  var473[1] = 10;
                  var473[0] = var53;
                  Object[] var199 = var473;
                  var463 = new Object[]{null, null, null, null, GameRenderUtil.bReturningColor(var199), var37};
                  var463[3] = var57;
                  var463[2] = var372;
                  var463[1] = var376;
                  var463[0] = var5;
                  Object[] var201 = var463;
                  MsdfFont var200 = var397;
                  var200.v(var201);
                  MsdfFontManager var419 = Prestige.c;
                  Object[] var203 = new Object[]{var13};
                  MsdfFontManager var202 = var419;
                  MsdfFont var420 = var202.aReturningcx_C0158(var203);
                  Object[] var205 = new Object[]{var376, var33};
                  MsdfFont var204 = var420;
                  var372 += var204.aReturningFloat(var205);
                  var374++;
                  int var340 = var39;
                  if (var340 != 0) {
                     break label161;
                  }

                  var341 = var39;
               } while (var341 == 0);
            }

            byte var342 = var366;
            if (var342 != 0) {
               float var343 = var54 - 1.5F - var43;
               var276 = var343;
               break label162;
            }
         }

         var276 = var52 + var42 + 1.5F;
      }

      float var369 = var276;
      int var356;
      do {
         ArrayList var208 = var44;
         int var345 = var208.size();
         int var344 = var371;
         if (var344 >= var345) {
            break;
         }

         int var210 = var371;
         ArrayList var209 = var44;
         ModuleListEntry var373 = (ModuleListEntry)var209.get(var210);
         ModuleListEntry var211 = var373;
         float var375 = var211.aY();
         int var398 = (int)(255.0F * var375);
         var10003 = new Object[]{null, var21};
         var10003[0] = var398;
         Object[] var212 = var10003;
         int var377 = aReturningInt(var212);
         float var495;
         int var399 = (var495 = var375 - 0.7F) == 0.0F ? 0 : (var495 < 0.0F ? -1 : 1);
         int var347 = var39;
         int var346 = var399;
         int var278 = var346;
         int var277 = var346;
         if (var347 == 0) {
            int var348 = var277;
            if (var348 > 0) {
               float var445 = this.k;
               Object[] var480 = new Object[]{null, null, null, null, null, null, null, null, null, var7};
               var480[8] = 4.0F;
               var480[7] = 5;
               var480[6] = var43;
               var480[5] = var445;
               var480[4] = var369;
               var480[3] = var51;
               var480[2] = var5;
               var480[1] = var4;
               var480[0] = var6;
               Object[] var214 = var480;
               BlurredRectangleRenderer.eReturningVoid(var214);
            }

            float var446 = this.k;
            Color var216 = UiMetrics.r;
            int var467 = var216.getRed();
            Color var217 = UiMetrics.r;
            int var474 = var217.getGreen();
            Color var218 = UiMetrics.r;
            int var481 = var218.getBlue();
            Color var219 = UiMetrics.r;
            int var488 = (int)(var219.getAlpha() * var375);
            Object[] var10015 = new Object[]{null, var21};
            var10015[0] = var488;
            Object[] var220 = var10015;
            Color var459 = new Color(var467, var474, var481, aReturningInt(var220));
            Object[] var482 = new Object[]{null, null, null, null, null, null, null, null, null, var15};
            var482[8] = 4.0F;
            var482[7] = var459;
            var482[6] = var43;
            var482[5] = var446;
            var482[4] = var369;
            var482[3] = var51;
            var482[2] = var5;
            var482[1] = var4;
            var482[0] = var6;
            Object[] var221 = var482;
            FilledRectangleRenderer.cReturningVoid(var221);
            var278 = (((var363) ? 1 : 0));
         }

         int var349 = var278;
         float var279;
         if (var349 != 0) {
            float var350 = var51 + this.k - 5.5F - this.l;
            var279 = var350;
         } else {
            var279 = var51 + 5.5F;
         }

         float var63 = var279;
         float var64 = var369 + (var43 - 8.0F) / 2.0F;
         float var447 = this.l;
         short var468 = 11542;
         long var475 = 3248967618470678075L ^ var2;
         short var476 = 12013;
         long var483 = 6937656784635334081L ^ var2;
         short var484 = 12013;
         long var489 = 6937656784635334081L ^ var2;
         int var490 = (int)(25.0F * var375);
         Object[] var491 = new Object[]{null, var21};
         var491[0] = var490;
         Object[] var223 = var491;
         Color var460 = new Color(255, 255, 255, aReturningInt(var223));
         Object[] var485 = new Object[]{null, null, null, null, null, null, null, null, null, var15};
         var485[8] = 3.0F;
         var485[7] = var460;
         var485[6] = 8.0F;
         var485[5] = var447;
         var485[4] = var64;
         var485[3] = var63;
         var485[2] = var5;
         var485[1] = var4;
         var485[0] = var6;
         Object[] var224 = var485;
         FilledRectangleRenderer.cReturningVoid(var224);
         short var421 = 17700;
         long var425 = 8815556631949764107L ^ var2;
         short var426 = 17700;
         long var439 = 8815556631949764107L ^ var2;
         int var427 = 10 + var371;
         Object[] var448 = new Object[]{null, null, null, var35};
         var448[2] = var427;
         var448[1] = 10;
         var448[0] = var53;
         Object[] var225 = var448;
         Color var65 = GameRenderUtil.bReturningColor(var225);
         Color var226 = var65;
         int var428 = var226.getRed();
         Color var227 = var65;
         int var440 = var227.getGreen();
         Color var228 = var65;
         Color var66 = new Color(var428, var440, var228.getBlue(), var377);
         var10000 = Prestige.c;
         Object[] var230 = new Object[]{var13};
         MsdfFontManager var229 = var10000;
         MsdfFont var401 = var229.aReturningcx_C0158(var230);
         ModuleListEntry var231 = var373;
         Object[] var233 = new Object[]{var231.aX(), var33};
         MsdfFont var232 = var401;
         float var67 = var232.aReturningFloat(var233) * 0.75F;
         float var68 = var63 + (this.l - var67) / 2.0F;
         float var69 = var64 + (8.0F - var41 * 0.75F) / 2.0F;
         var10000 = Prestige.c;
         Object[] var235 = new Object[]{var13};
         MsdfFontManager var234 = var10000;
         MsdfFont var403 = var234.aReturningcx_C0158(var235);
         ModuleListEntry var236 = var373;
         String var429 = var236.aX();
         Object[] var469 = new Object[]{null, null, null, null, null, var66, var17};
         var469[4] = 0.75F;
         var469[3] = var69;
         var469[2] = var68;
         var469[1] = var429;
         var469[0] = var5;
         Object[] var238 = var469;
         MsdfFont var237 = var403;
         var237.w(var238);
         ModuleListEntry var239 = var373;
         Module var240 = var239.aW();
         String var70 = var240.bReturningString();
         var10000 = Prestige.c;
         Object[] var242 = new Object[]{var13};
         MsdfFontManager var241 = var10000;
         MsdfFont var405 = var241.aReturningcx_C0158(var242);
         Object[] var244 = new Object[]{var70, var33};
         MsdfFont var243 = var405;
         float var71 = var243.aReturningFloat(var244) * 0.75F;
         byte var351 = ((byte)((var363) ? 1 : 0));
         float var280;
         if (var351 != 0) {
            float var352 = var63 - 3.0F - var71;
            var280 = var352;
         } else {
            var280 = var63 + this.l + 3.0F;
         }

         label128: {
            label127: {
               float var72 = var280;
               float var73 = var369 + (var43 - var41 * 0.75F) / 2.0F;
               var10000 = Prestige.c;
               Object[] var247 = new Object[]{var13};
               MsdfFontManager var246 = var10000;
               MsdfFont var407 = var246.aReturningcx_C0158(var247);
               short var466 = 12013;
               long var470 = 6937656784635334081L ^ var2;
               var468 = 12013;
               var475 = 6937656784635334081L ^ var2;
               short var478 = 12013;
               var483 = 6937656784635334081L ^ var2;
               int var487 = (int)(220.0F * var375);
               Object[] var10014 = new Object[]{null, var21};
               var10014[0] = var487;
               Object[] var248 = var10014;
               Object[] var472 = new Object[]{null, null, null, null, null, new Color(255, 255, 255, aReturningInt(var248)), var17};
               var472[4] = 0.75F;
               var472[3] = var73;
               var472[2] = var72;
               var472[1] = var70;
               var472[0] = var5;
               Object[] var250 = var472;
               MsdfFont var249 = var407;
               var249.w(var250);
               int var353 = var39;
               if (var353 == 0) {
                  byte var354 = var366;
                  if (var354 == 0) {
                     break label127;
                  }

                  var369 -= (var43 + 1.5F) * var375;
               }

               int var355 = var39;
               if (var355 == 0) {
                  break label128;
               }
            }

            var369 += (var43 + 1.5F) * var375;
         }

         var371++;
         var356 = var39;
      } while (var356 == 0);
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 60640906816027L ^ var1;
      int var4 = Event.cReturningInt();
      int var12 = var4;
      int var11 = var3;
      int var9 = var11;
      int var8 = var11;
      if (var12 != 0) {
         int var13 = var8;
         if (var13 < 0) {
            return 0;
         }

         var9 = var3;
      }

      short var10001 = 12013;
      long var10002 = 6937684483986375412L ^ var1;
      int var7 = var9;
      return Math.min(var7, 255);
   }

   static {

      {

      b();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(87303309736L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[5];
      String var22 = "=\u000b¯w\u001cÚ\u009c¾p\u001drOôm\u0090©\u001dGA°NºeçÃ%\u0002`\u00ad4}\u008aT\u0000\u000bm.Ý+®û\u0007G?¹d#ü\u0002$-\u009cB\u0085¬\u0006Ú\\\")\u0080¼®gváy\f,í\u0004H Ò\u0098Ðcàf|â u\u0091ÏÎ\u009cø \u0094ªYc?r\u001a\u008b\u0091ë!Ue^\"68Ã¥\u0095Ò\u0002/'!Ögä?\u000bCÏ.Üé\u0090\u00943Bc\u009d:ë>Æ¨\np\n\u0082\u0003\u009fs\u0095u\u008eîô[#\u0092þ\u0088 \u008bëý1·\u0086Þº\u0086";
      int var24 = "=\u000b¯w\u001cÚ\u009c¾p\u001drOôm\u0090©\u001dGA°NºeçÃ%\u0002`\u00ad4}\u008aT\u0000\u000bm.Ý+®û\u0007G?¹d#ü\u0002$-\u009cB\u0085¬\u0006Ú\\\")\u0080¼®gváy\f,í\u0004H Ò\u0098Ðcàf|â u\u0091ÏÎ\u009cø \u0094ªYc?r\u001a\u008b\u0091ë!Ue^\"68Ã¥\u0095Ò\u0002/'!Ögä?\u000bCÏ.Üé\u0090\u00943Bc\u009d:ë>Æ¨\np\n\u0082\u0003\u009fs\u0095u\u008eîô[#\u0092þ\u0088 \u008bëý1·\u0086Þº\u0086"
         .length();
      char var21 = 'H';
      int var29 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var29, var29 + var21);
         int var10001 = -1;

         while (true) {
            byte[] var26 = var18.doFinal(var30.getBytes("ISO-8859-1"));
            String var44 = b(var26).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var44;
                  if ((var29 += var21) >= var24) {
                     w = var25;
                     x = new String[5];
                     D = new HashMap(13);
                     Cipher var5;
                     var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(87303309736L << var6 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[4];
                     String var9 = "±æ&©Ó2¾Øn3\u0091\u0015|ÛÃ¯";
                     int var10 = "±æ&©Ó2¾Øn3\u0091\u0015|ÛÃ¯".length();
                     label46:
                     while (true) {
                        var10001 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
                        long[] var33 = var11;
                        var10001 = var8++;
                        long var48 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        
                           long var13 = var48;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var56 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var33[var10001] = var56;
                                 if (var7 >= var10) {
                                    B = var11;
                                    C = new Integer[4];
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(87303309736L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long var41 = -7374403748569243109L;
                                    byte[] var4 = var0.doFinal(
                                       new byte[]{
                                          (byte)153L,
                                          (byte)39336L,
                                          (byte)10070234L,
                                          (byte)2577980124L,
                                          (byte)659962911912L,
                                          (byte)168950505449528L,
                                          (byte)43251329395079330L,
                                          (byte)-7374403748569243109L
                                       }
                                    );
                                    long var51 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    
                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var56;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "\u0001FÁ%É(Ä(iOr5¢n\u0016å";
                                 var10 = "\u0001FÁ%É(Ä(iOr5¢n\u0016å".length();
                                 var7 = 0;
                           }

                           int var40 = var7;
                           var7 += 8;
                           var12 = var9.substring(var40, var7).getBytes("ISO-8859-1");
                           var33 = var11;
                           var10001 = var8++;
                           var48 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var29);
                  break;
               default:
                  var25[var23++] = var44;
                  if ((var29 += var21) < var24) {
                     var21 = var22.charAt(var29);
                     continue label64;
                  }

                  var22 = "i\u008d\u0012hòDæ4s\u0001k\u000b °\u009b7 \u007f\u000ev\u000f_?-\u008däW\u008bT~:\u001c\u0089{ë°·\u001f[a¾\u0002+è´\u009a\u0005¶÷";
                  var24 = "i\u008d\u0012hòDæ4s\u0001k\u000b °\u009b7 \u007f\u000ev\u000f_?-\u008däW\u008bT~:\u001c\u0089{ë°·\u001f[a¾\u0002+è´\u009a\u0005¶÷"
                     .length();
                  var21 = 16;
                  var29 = -1;
            }

            var30 = var22.substring(++var29, var29 + var21);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 6136;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b6", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b6",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 24767;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b6", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b6",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = J[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = I[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 1;
            yield var15;
         }
         case 1 -> {
            byte var16 = 3;
            yield var16;
         }
         case 2 -> {
            byte var17 = 42;
            yield var17;
         }
         case 3 -> {
            byte var18 = 62;
            yield var18;
         }
         case 4 -> {
            byte var19 = 16;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 7;
            yield var21;
         }
         case 7 -> {
            byte var22 = 55;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 26;
            yield var24;
         }
         case 10 -> {
            byte var25 = 5;
            yield var25;
         }
         case 11 -> {
            byte var26 = 15;
            yield var26;
         }
         case 12 -> {
            byte var27 = 53;
            yield var27;
         }
         case 13 -> {
            byte var28 = 27;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 35;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 60;
            yield var32;
         }
         case 18 -> {
            byte var33 = 18;
            yield var33;
         }
         case 19 -> {
            byte var34 = 61;
            yield var34;
         }
         case 20 -> {
            byte var35 = 28;
            yield var35;
         }
         case 21 -> {
            byte var36 = 13;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 21;
            yield var39;
         }
         case 25 -> {
            byte var40 = 50;
            yield var40;
         }
         case 26 -> {
            byte var41 = 23;
            yield var41;
         }
         case 27 -> {
            byte var42 = 12;
            yield var42;
         }
         case 28 -> {
            byte var43 = 48;
            yield var43;
         }
         case 29 -> {
            byte var44 = 25;
            yield var44;
         }
         case 30 -> {
            byte var45 = 40;
            yield var45;
         }
         case 31 -> {
            byte var46 = 11;
            yield var46;
         }
         case 32 -> {
            byte var47 = 44;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 41;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 43;
            yield var51;
         }
         case 37 -> {
            byte var52 = 33;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 9;
            yield var54;
         }
         case 40 -> {
            byte var55 = 57;
            yield var55;
         }
         case 41 -> {
            byte var56 = 49;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 45;
            yield var58;
         }
         case 44 -> {
            byte var59 = 34;
            yield var59;
         }
         case 45 -> {
            byte var60 = 19;
            yield var60;
         }
         case 46 -> {
            byte var61 = 4;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 17;
            yield var63;
         }
         case 49 -> {
            byte var64 = 59;
            yield var64;
         }
         case 50 -> {
            byte var65 = 39;
            yield var65;
         }
         case 51 -> {
            byte var66 = 29;
            yield var66;
         }
         case 52 -> {
            byte var67 = 38;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 63;
            yield var69;
         }
         case 55 -> {
            byte var70 = 56;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 46;
            yield var72;
         }
         case 58 -> {
            byte var73 = 36;
            yield var73;
         }
         case 59 -> {
            byte var74 = 37;
            yield var74;
         }
         case 60 -> {
            byte var75 = 6;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 32;
            yield var77;
         }
         default -> 22;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            J[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      I[0] = "G7@`i\u0010Z\"\u0018B(\u001dB$";
      I[1] = int.class;
      J[1] = "java/lang/Integer";
      I[2] = "E\b&\u0003\u0017\nN\u00077Lj\u001f\\\u001d5\u000f";
      I[3] = long.class;
      J[3] = "java/lang/Long";
      I[4] = "0S\b\u0012\u0005\u0002&S\rH\u0016\u00151\u0018\u000eN\u001a\u0001 _\u0019YQ\u00118_\u001bR\u000b\\\u0004D\u001bO\u000b\u001b3S";
      I[5] = "\u0019iyu}=\u000fi|/n*\u0018\"\u007f)b>\teh>).\u0007";
      I[6] = "\u0011\u000f+K9.\u0011\u000f<\u00175!\u000bD<\t54\f5lTd";
      I[7] = "\"VE\u001b-{\"VRG!t8\u001dRY!a?l\u0005\u0006w";
      I[8] = "\u0003jk7\u0011m\u0015jnm\u0002z\u0002!mk\u000en\u0013fz|E~\u001f";
      I[9] = "L\n\u0006hB/9*\rgS`X$\u0006lW:,";
      I[10] = void.class;
      J[10] = "java/lang/Void";
      I[11] = "\u001d \u00038t0\u0003(\u0019w\u0016,\u00045";
      I[12] = "m]oE6\u001csUu\nQ\u001dbNxPw\u001b";
      I[13] = "N%FjuSX%C0fDOn@6jP^)W!!A\u001b";
      I[14] = "a}\u0003X\u0001\u0016\u0014]\bW\u0010YuS\u0003\\\u0014\u0003\u0001";
      I[15] = "2\u00006,&F$\u00003v5Q3K0p9E\"\f'grQ&";
      I[16] = "~_$?8>h_!e+)\u007f\u0014\"c'=nS5tl*K";
      I[17] = "OV-c2\u0018DY<,O\u0000W^5e";
      I[18] = "\b,/)\u000b\u0015\u001e,*s\u0018\u0002\tg)u\u0014\u0016\u0018 >b_\u0006+";
      I[19] = "gCRGx2lLC\b\u0019<gGGR";
      I[20] = "\u0000\bf}\u0013\u0001\u0016\bc'\u0000\u0016\u0001C`!\f\u0002\u0010\u0004w6G\u0010&";
      I[21] = "ivSV]>\u001cVXYLq}XSRH+\t";
      I[22] = "(t7F\u001fR]T<I\u000e\u001d<Z7B\nGH";
      I[23] = float.class;
      J[23] = "java/lang/Float";
      I[24] = "\u0007\u001b'r\u0004Cr;,}\u0015\f\u00135'v\u0011Vg";
      I[25] = boolean.class;
      J[25] = "java/lang/Boolean";
      I[26] = "@A\u0002oMI5a\t`\\\u0006To\u0002kX\\ ";
      I[27] = "\u001bb7\u0003IynB<\fX6\u000fL7\u0007\\l{";
      I[28] = "\u0000;\u000e1\u001d`\u0016;\u000bk\u000ew\u0001p\bm\u0002c\u00107\u001fzIt\f";
      I[29] = " 5adX2U\u0015jkI}4\u001ba`M'@";
      I[30] = "\u0015\u001b/NQu\u0003\u001b*\u0014Bb\u0014P)\u0012Nv\u0005\u0017>\u0005\u0005g%";
      I[31] = "I3XnukB<I!\u001dkL3Z";
      I[32] = "C\u0014w\u001f6\u007f64|\u0010'0W:w\u001b#j#";
      I[33] = "\u001dXn UH\u000bXkzF_\u001c\u0013h|JK\rT\u007fk\u0001[@";
      I[34] = "I\u000fqxb\u001d</zwsR]!q|w\b)";
      I[35] = "\u000f\u0014zg\u001c?z4qh\rp\u001b:zc\t*o";
      I[36] = "cG\u0002\u0004E#uG\u0007^V4b\f\u0004XZ sK\u0013O\u00112B";
      I[37] = "\f\u0019gHK\u0014\u0007\u0016v\u0007&\u0010\u0007\nBL\u0014\r\u0003\u0016rL";
      I[38] = "I\nU;'?T\u001f\r?\u007f;M\u001f\r\u0011l'f\u001dF4}";
      I[39] = "%\u000e[JX\u00073\u000e^\u0010K\u0010$E]\u0016G\u00045\u0002J\u0001\f\u00137";
      I[40] = "&(ue\u0005kS\b~j\u0014$2\u0006ua\u0010~F";
      I[41] = "<e)*\u000eg\"m3ems&";
      I[42] = "Efl\u001c8F0Fg\u0013)\tQHl\u0018-S%";
      I[43] = "\nB#U4#\u0001M2\u001aW.\u0014K";
      I[44] = "lD:H);\u0019d1G8txj:L<.\f";
      I[45] = "\u0005(x\u0000\u001f\u0004\u0013(}Z\f\u0013\u0004c~\\\u0000\u0007\u0015$iKK\u0016W";
      I[46] = "rOq\u0010V0\u0007oz\u001fG\u007ffaq\u0014C%\u0012";
      I[47] = "@ZA+.\u001eVZDq=\tA\u0011Gw1\u001dPVP`z\rO";
      I[48] = "l`7\t|$\u0019@<\u0006mkxN7\ri1\f";
      I[49] = char.class;
      J[49] = "java/lang/Character";
      I[50] = "\bGJ\u0013ae\u001eGOIrr\t\fLO~f\u0018K[X5q\u000b";
      I[51] = "O[\u000b\u0007*X:{\u0000\b;\u0017[u\u000b\u0003?M/";
      I[52] = "KE]R\u0007'>eV]\u0016h_k]V\u00122+";
      I[53] = "S\u0000\u0013$[-E\u0000\u0016~H:RK\u0015xD.C\f\u0002o\u000f9@";
      I[54] = "j5ih\u000e]\u001f\u0015bg\u001f\u0012~\u001bil\u001bH\n";
      I[55] = "\u0006nHZ@A\u0010nM\u0000SV\u0007%N\u0006_B\u0016bY\u0011\u0014U\u0004";
      I[56] = "\u0013\u000f?[6|f/4T'3\u0007!?_#is";
      I[57] = "x\nP?#=s\u0005Ap@0f\bN\u001bu2w\u001bR7b?";
      I[58] = "R\u0012)\u0016}b'2\"\u0019l-F<)\u0012hw2";
      I[59] = "qJ~\u001e\f&&[nw\u00197joq\u000f\u00163\u0016\u001f-\u001c\u0016*.\u0017*\u0019\u000fZ";
      I[60] = "\u0002\u000f\u0005\u000e9i\u0001P\u0002\u0002ZiF\u0017\u0005\u000f<~g\f\u001a\u000f\u001fc_\t\u001e\u0019Z8Z\u0015A\u0000&y\u0004\u0003Bb";
      I[61] = "q%Es?s3*DaX\"KkL-h &/\u001br!";
      I[62] = ">.T\u000fx0>s\\Z\u001e2c YYIe=p\u00005#6a#EG\u007f,z<";
      I[63] = "!ue?U5`q;ze&\u001fscy\u0014?q(59\u0006=\u001fu>f\u001b+|;.s\u0005Y";
      I[64] = "c\u0013wmB\u00122\u00058;;H \u0005\u007f4GN&h53\u0002P2Qxm\u0003K\\";
      I[65] = "K\\&9\u0005$GU=)y=z\u0002s0\b:\u0014Y%p\u001a8z\u0004./\u0007.\u0019J>:\u0019\\";
      I[66] = "\u0001\u0019AT3l\u0007\u0013HJOt7hHM>}\fW\\M-vh";
      I[67] = "Z\u0016B/lb^\r\\v\u0000=]\u000ePo`Y\tPTspa\u0001WQj\u0000";
      I[68] = "Iz\b+ex[e\f>\n!\"%\u001a4:1\u0019t\f{lH";
      I[69] = "5\u0000-\nV\u001ex^,\u00118Ah\u001ehsTJ4S,\u001fFClR\u0014";
      I[70] = "l=rL\u0001M|jw\n`[\u000143O\u0011Tooe\u000f\u0003V\u0001gqJ\\^:cjT\u00052";
      I[71] = "Bl\u0007kF7\u0003hY.v2|j\u0001-\u0007=\u00121Wm\u0015?|=O7\u000b!\u0019*\u0003k\u0014[";
      I[72] = "A\u0004F4c\n\u0016\u0015V]v\u001bZ2@1\u0019O\u001e\u0003M-!G\u0019\u0006T]";
      I[73] = "~}wfj1j}dm\u000ed\u0014<:~\u007fhzgl>mj\u0014<>mn~,49hw\u000e";
      I[74] = "\u0002]`g31\u0006F~>_k\u0013nx##{hC}<4m\u0019\u0012,k&\n";
      I[75] = "(_8\u0016kc$V#\u0006\u0017w\u0019\u0001m\u001ff}wZ;_t\u007f\u0019X1\u0000||h\t`Wn\u001b";
      I[76] = "Ex}7AqIqf'=bt&(>Lo\u001a}~~^mt\u007ft!Vn\u0005.%vD\t";
      I[77] = "\u0012z|eB$\u001esgu>5#$)lO:M\u007f\u007f,]8#\"ts@.@ldf^\\";
      I[78] = "r(z\u001b?\u0011l>~MN\u0012\u0010a(\u0004?\u001d~:~D-\u001f\u0010<tL6\u0016.9s\u0003,{";
      I[79] = "j&L\u0006\\^;0\u0003P%\n8!>\u000f\u001d\u000e5-\u0006\u0007\u001a\u000b,]R[\u0014Xm1@RLYU";
      I[80] = "t.\fk<\u0003.aTbY\u001ay8\u0018h\u001e\n\u00102\u0017g$\u001eu%[;;dt.\fk<\u0003.aTbY";
      I[81] = "\u000b\u0002\u0007`K@\u001bU\u0002&*Uf\u000bFc[Y\bP\u0010#I[f\\\byWE\u0003KD%H?";
      I[82] = "J!;\u0010WUA-b\f'_,vb\u0014VTB-4TDV,p?\u000bY@O>/\u001eG2";
      I[83] = "\u000e1tbM\u0017O5*'}\u001007r$\f\u001d^l$d\u001e\u001f0`<>\u0000\u0001Uwpb\u001f{";
      I[84] = "!m/\u000f\u0007\u001fv|?f\u0012\u000e:N>\u000b\u0010\u0005F8|\r\u001d\u0013~0{\b\u0004c";
      I[85] = "d*\u0011\"\u001aM'rP*qK\u001c.T3\u0011Q$&S6\b!";
      I[86] = "WDO_s]S_Q\u0006\u001f\rZ\\N\n~\u0000F:K\tx\fB@\u0002\u0003mY=ZR\u0004t\u0001L\u000b\u0003Sff";
      I[87] = "_N&\u0011E\u0018DGl\u000b!JK_^\u001fPyKSar\u0018\u001dMCmJ\u0010\u001aHZ\u001d\u0018_X\u001aO&\u001cDFC#";
      I[88] = "^0X}\f\u0017\u001dh\u0019ug\u0010&4\u001dl\u0007\u000b\u001e<\u001ai\u001e{";
      I[89] = "~\u0000\u0018\u0005P}x\n\u0011\u001b,eFq\u0015\u0016Nqm\u0014\u0002Z\u0012n\u0017";
      I[90] = "'H+3\u001529Dw1(<]\u0012{5Y>3I-uK<]\u0014&*V*>Z6?HX";
      I[91] = "z\u0000YiL68\u000fX{+`@\u0019\toFcp\u000b\u0016kS";
      I[92] = "/7aD\fp)=hZph\u0016Fh[\r=*}l@\u0013dF";
      I[93] = "#X-1j\u0015n\u0006,*\u0004LzMR%tP\u0013Vt/oKb\u0007%x},";
      I[94] = "(q[m\u0006@<qHfb\u0015BcTp^\u0013ygOn\u0007\u007f";
      I[95] = "\u0000g,bA\u001a\u0007<+\u007f|\u000e\u001c:W4D\u0000\u001d,o<C\u0005\u0004\\n5\u0017\u000b\rdf2\u0012\u0012}eof\u001c\u001bEmhc\u0005k";
      I[96] = "\fKy)Z\u0012\u0018]}4 \f\u001aLQ(l\u000e\u0019Yk6\\c\u001b]'o\u0018\u000f\tT\u007fn \u000f\u001a\u0001+jL\u001d\u0013Y*RL\u000eF\r.>^\u0007\u001e\f\u0016";
      I[97] = "|~\u0002ju\u0004l)\u0007,\u0014\u0017\u0011wCie\u001d\u007f,\u0015)w\u001f\u0011)\u0013z}\u0001m~\u0002j\u0014";
      I[98] = "V':\u000f/tQ|=\u0012\u0012`BlA\u000e`gVf$\u0019,;I\u001c/\u0012pxQy8^,g+r3\u0002o\u007fNe\u007f^p\u0005";
      I[99] = "p%\u0006h\u0002C'4\u0016\u0001\u0017Rk\u0003\t|\u0015?.q\u0006a\b\u0007&v\u0003xx";
      I[100] = "{' \t8O?p\u007f@QKG'-A D)|{\u00012FG .\u0003o\u0012+a*]*\"";
      I[101] = ".&\fV]s. \r\u0010/gPg]\u0017^h><\u000bWLjPgY\u0004O~ho^\u0001V\u000e";
      I[102] = "~l9vO ;!0t3%\u0001(u1B*os#qP(\u0001\u007f;+N6dhwwQL";
      I[103] = "B\u001aH\u0011s\u0003F\u0001VH\u001fSH\rOdc8\u0011\\^Mo\u0000\u0019[[T\u001fIF\u0019\\D'T\u0015\u0001R-";
      I[104] = "#_*p&PrIe&_\u0002pHX,2Z!\u001c4>;\u0002 $8 8\u0000{Uiqo\u0012\u001c";
      I[105] = "\u0018Lt\u0006swIZ;P\n7FEk63tLWv\u000e;sIN\u0006";
      I[106] = "7B\u0010\u000fAo#B\u0003\u0004%9]Z\u0001\bN7,\u000bP_\\P";
      I[107] = "i\t\u001f#\\\t|P_`8[\u001b\b\u001faIVuSI![T\u001b\u000eB~FBx@RkX0";
      I[108] = "bE`\u001d$\u0002#A>X\u0014\u0010\\Cf[e\b2\u00180\u001bw\n\\E;Dj\u001c?\u000b+Qtn";
      I[109] = "H\"\u001c\u0011OY\u0012mD\u0018*PH7\u001c\u0003tWH-\u0018\u007fDLN-\u000f\u001aS\u0000\u00122u";
      I[110] = "x0u\u000b\u001bL!r#\u001c\u00191+\t'E\u001d@'g|\u0013]R%\ty\u0015\u000eX;u.\u0004\u001e1";
      I[111] = "\u001b#;\u0002otH%9G{\u001fI\u0019yGenDw\"\u0011%|F\u0019\u007f\u001azaPz1\no\u007f\"";
      I[112] = "-f\u00187! -`\u0019qS4S'I7: . \nh(-S'I7: . \nh(-S";
      I[113] = "A\u0019ao3EE\u0002\u007f6_\u0000B\u0003a>\u0018\u0010+\u0016r.6\u0017\u0013\u000b!68~A\u0019ao3EE\u0002\u007f6_";
      I[114] = "\u0003h1RZq\u0017~5O x\u0005o^EM1E+2WDiD\u00132D\u0011=@\u007f MI<x\u007f3\u0018\u001d8\u0014m:@\u001c\u0000";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = I[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(J[var4]);
            I[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            I[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  I[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(1360491160091260L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = I[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = J[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  I[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(1360491160091260L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        I[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(1360491160091260L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 228;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 112;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 86;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 240;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 80;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 218;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 228;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 112;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 86;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b6",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b6" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
