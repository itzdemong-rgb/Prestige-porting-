package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;



import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import org.joml.Matrix4f;

public class LatencyWidget extends HudElement {
   private static final int a;
   private static final long c;
   private static final float m = 100.0F;
   private ManagedGlTexture d;
   private final float[] g;
   private int h;
   private long i;
   private long j;
   private float k;
   private float l;
   private float o;
   private float p;
   private float t;
   private static final long v = 139934033560728L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[84];
   private static final String[] L = new String[84];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;

   public LatencyWidget(long var1) {
      super(invokeBinding1(11953, 1582522938921665849L ^ (139934033560728L ^ var1)), invokeBinding2(10569, 6667802717871817412L ^ (139934033560728L ^ var1)), ((139934033560728L ^ (139934033560728L ^ var1)) ^ 118045398136133L));
      var1 = 139934033560728L ^ var1;
      long var3 = var1 ^ 118045398136133L;

      this.g = new float[invokeBinding3(444, 4835058496239886169L ^ var1)];
      this.h = 0;
      this.i = invokeBinding4(24662, 3688762370705797811L ^ var1);
      this.j = invokeBinding5(7518, 443374385828024249L ^ var1);
      this.k = -1.0F;
      this.l = 96.0F;
      this.o = 220.0F;
      this.p = 130.0F;
      this.t = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 23.0F;
      var10005[0] = 65.0F;
      Object[] var7 = var10005;
      LatencyWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var2;
      Matrix4f var3;
      long var4;
      RenderContext var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var21;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      int var33;
      label183: {
         var2 = (MeshBufferManager)var1[0];
         var6 = (RenderContext)var1[1];
         var3 = (Matrix4f)var1[2];
         var4 = (Long)var1[3];
         var7 = var4 ^ 48887442607471L;
         var9 = var4 ^ 36477842301344L;
         var11 = var4 ^ 13608202459885L;
         var13 = var4 ^ 29307267718371L;
         var15 = var4 ^ 113406911627307L;
         var17 = var4 ^ 17083579563515L;
         long var19 = var4 ^ 56760183293883L;
         var21 = var4 ^ 49928519994039L;
         var23 = var4 ^ 41197988814736L;
         var25 = var4 ^ 124694493719688L;
         var27 = var4 ^ 81054074941871L;
         var29 = var4 ^ 93714620606017L;
         var31 = var4 ^ 133613601217409L;
         var33 = Event.cReturningInt();
         int var212 = var33;
         LatencyWidget var211 = this;
         LatencyWidget var165 = var211;
         LatencyWidget var164 = var211;
         if (var212 != 0) {
            ManagedGlTexture var213 = var164.d;
            if (var213 != null) {
               break label183;
            }

            LatencyWidget var214 = this;
            var165 = var214;
         }

         Object[] var75 = new Object[]{invokeBinding6(633, 3253189058754300120L ^ var4), var19};
         var165.d = TextureLoader.aReturningbT_C0095(var75);
      }

      long var34;
      float var174;
      label177: {
         var34 = System.currentTimeMillis();
         long var10000 = this.j;
         long var10001 = invokeBinding7(7518, 443324369612730004L ^ var4);
         int var219 = var33;
         long var217 = var10001;
         long var215 = var10000;
         long var170 = var215;
         long var172 = var217;
         long var166 = var215;
         long var168 = var217;
         if (var219 != 0) {
            long var340;
            int var220 = (var340 = var166 - var168) == 0L ? 0 : (var340 < 0L ? -1 : 1);
            if (!((var220) != 0)) {
               float var221 = 1.0F;
               var174 = var221;
               break label177;
            }

            var172 = this.j;
            var170 = var34;
         }

         var174 = (float)(var170 - var172) * 0.005F;
      }

      float var36;
      int var37;
      label186: {
         var36 = var174;
         this.j = var34;
         var37 = 0;
         int var223 = var33;
         MinecraftClient var222 = b;
         MinecraftClient var176 = var222;
         MinecraftClient var175 = var222;
         if (var223 != 0) {
            MinecraftClient var78 = var175;
            ClientPlayNetworkHandler var224 = var78.getNetworkHandler();
            if (var224 == null) {
               break label186;
            }

            MinecraftClient var225 = b;
            var176 = var225;
         }

         int var227 = var33;
         MinecraftClient var226 = var176;
         MinecraftClient var178 = var226;
         MinecraftClient var177 = var226;
         if (var227 != 0) {
            MinecraftClient var81 = var177;
            ClientPlayerEntity var228 = var81.player;
            if (var228 == null) {
               break label186;
            }

            MinecraftClient var229 = b;
            var178 = var229;
         }

         MinecraftClient var84 = var178;
         ClientPlayNetworkHandler var293 = var84.getNetworkHandler();
         MinecraftClient var85 = b;
         ClientPlayerEntity var86 = var85.player;
         UUID var88 = var86.getUuid();
         ClientPlayNetworkHandler var87 = var293;
         PlayerListEntry var38 = var87.getPlayerListEntry(var88);
         int var231 = var33;
         PlayerListEntry var230 = var38;
         PlayerListEntry var180 = var230;
         PlayerListEntry var179 = var230;
         if (var231 != 0) {
            PlayerListEntry var232 = var179;
            if (var232 == null) {
               break label186;
            }

            var180 = var38;
         }

         PlayerListEntry var90 = var180;
         var37 = var90.getLatency();
      }

      long var341;
      int var233 = (var341 = var34 - this.i - invokeBinding8(29627, 6752234536112685168L ^ var4)) == 0L ? 0 : (var341 < 0L ? -1 : 1);
      if (var233 >= 0) {
         this.g[this.h] = var37;
         this.h = (this.h + 1) % invokeBinding9(8542, 5965755871344909976L ^ var4);
         this.i = var34;
      }

      LatencyWidget var190;
      float var191;
      label154: {
         int var237 = var33;
         float var236 = 0.0F;
         float var235 = this.k;
         LatencyWidget var234 = this;
         LatencyWidget var187 = var234;
         float var188 = var235;
         float var189 = var236;
         LatencyWidget var181 = var234;
         float var182 = var235;
         float var183 = var236;
         if (var237 != 0) {
            float var342;
            int var239 = (var342 = var182 - var183) == 0.0F ? 0 : (var342 < 0.0F ? -1 : 1);
            LatencyWidget var238 = var181;
            LatencyWidget var186 = var238;
            LatencyWidget var184 = var238;
            if (var239 < 0) {
               LatencyWidget var240 = var184;
               LatencyWidget var185 = var240;
               float var242 = var37;
               LatencyWidget var241 = var185;
               var190 = var241;
               var191 = var242;
               break label154;
            }

            var189 = var37;
            var188 = this.k;
            var187 = var186;
         }

         Object[] var10006 = new Object[]{null, null, null, var23};
         var10006[2] = var36;
         var10006[1] = var189;
         var10006[0] = var188;
         Object[] var94 = var10006;
         var191 = ClientUiUtil.bReturningFloat(var94);
         var190 = var187;
      }

      Color var40;
      String var41;
      float var43;
      float var44;
      float var45;
      float var46;
      float var47;
      float var48;
      float var49;
      float var51;
      float var52;
      boolean var53;
      float var194;
      label148: {
         var190.k = var191;
         boolean var294 = false;
         float var95 = this.k;
         int var97 = Math.round(var95);
         int var287 = Math.max(0, var97);
         float var295 = var287;
         Object[] var10003 = new Object[]{null, var31};
         var10003[0] = var295;
         Object[] var98 = var10003;
         Color var39 = aReturningColor(var98);
         float var308 = this.l;
         Color var99 = var39;
         float var10002 = var99.getRed();
         Object[] var329 = new Object[]{null, null, null, var23};
         var329[2] = var36;
         var329[1] = var10002;
         var329[0] = var308;
         Object[] var100 = var329;
         this.l = ClientUiUtil.bReturningFloat(var100);
         var308 = this.o;
         Color var101 = var39;
         var10002 = var101.getGreen();
         var329 = new Object[]{null, null, null, var23};
         var329[2] = var36;
         var329[1] = var10002;
         var329[0] = var308;
         Object[] var102 = var329;
         this.o = ClientUiUtil.bReturningFloat(var102);
         var308 = this.p;
         Color var103 = var39;
         var10002 = var103.getBlue();
         var329 = new Object[]{null, null, null, var23};
         var329[2] = var36;
         var329[1] = var10002;
         var329[0] = var308;
         Object[] var104 = var329;
         this.p = ClientUiUtil.bReturningFloat(var104);
         var10002 = this.l;
         Object[] var10005 = new Object[]{null, var29};
         var10005[0] = var10002;
         Object[] var105 = var10005;
         int var315 = aReturningInt(var105);
         float var319 = this.o;
         var329 = new Object[]{null, var29};
         var329[0] = var319;
         Object[] var106 = var329;
         int var320 = aReturningInt(var106);
         float var10004 = this.p;
         Object[] var10007 = new Object[]{null, var29};
         var10007[0] = var10004;
         Object[] var107 = var10007;
         var40 = new Color(var315, var320, aReturningInt(var107));
         int var108 = var287;
         var41 = String.valueOf(var108);
         MsdfFontManager var296 = Prestige.c;
         Object[] var110 = new Object[]{var11};
         MsdfFontManager var109 = var296;
         MsdfFont var297 = var109.aReturningcx_C0158(var110);
         Object[] var112 = new Object[]{var21};
         MsdfFont var111 = var297;
         float var42 = var111.cReturningFloat(var112);
         MsdfFontManager var298 = Prestige.c;
         Object[] var114 = new Object[]{var11};
         MsdfFontManager var113 = var298;
         MsdfFont var299 = var113.aReturningcx_C0158(var114);
         Object[] var116 = new Object[]{var41, var27};
         MsdfFont var115 = var299;
         var43 = var115.aReturningFloat(var116) * 1.0F;
         MsdfFontManager var300 = Prestige.c;
         Object[] var118 = new Object[]{var11};
         MsdfFontManager var117 = var300;
         MsdfFont var301 = var117.aReturningcx_C0158(var118);
         Object[] var120 = new Object[]{invokeBinding10(21333, 3026245142854605303L ^ var4), var27};
         MsdfFont var119 = var301;
         var44 = var119.aReturningFloat(var120) * 0.65F;
         var45 = var42 * 1.0F;
         var46 = var42 * 0.65F;
         var47 = 7.5F;
         var48 = 5.5F + var47 + 5.5F;
         var49 = var48 + 0.5F + 5.5F;
         float var302 = var43 + 3.0F + var44;
         float var122 = 28.0F;
         float var121 = var302;
         float var50 = Math.max(var121, var122);
         var51 = var49 + var50 + 5.5F;
         Object[] var123 = new Object[]{var42};
         var52 = UiMetrics.bReturningFloat(var123);
         Object[] var125 = new Object[0];
         LatencyWidget var124 = this;
         var53 = var124.cReturningBoolean(var125);
         MinecraftClient var126 = b;
         boolean var54 = var126.currentScreen instanceof HudEditorScreen;
         int var243 = var33;
         if (var243 != 0) {
            boolean var244 = var53;
            if (var244) {
               int var246 = var33;
               float var245 = this.t;
               var194 = var245;
               float var192 = var245;
               if (var246 == 0) {
                  break label148;
               }

               float var247 = var192;
               float var193 = var247;
               float var343;
               int var248 = (var343 = var193 - 0.0F) == 0.0F ? 0 : (var343 < 0.0F ? -1 : 1);
               if (var248 > 0) {
                  boolean var249 = var54;
                  if (!var249) {
                     this.e = this.e - (var51 - this.t);
                  }
               }
            }

            this.t = var51;
         }

         var194 = this.e;
      }

      float var55 = var194;
      float var56 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var7};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var52;
      var10011[5] = var51;
      var10011[4] = var56;
      var10011[3] = var55;
      var10011[2] = var3;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var132 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var132);
      Color var333 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var13};
      var10011[8] = 4.0F;
      var10011[7] = var333;
      var10011[6] = var52;
      var10011[5] = var51;
      var10011[4] = var56;
      var10011[3] = var55;
      var10011[2] = var3;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var133 = var10011;
      FilledRectangleRenderer.cReturningVoid(var133);
      boolean var250 = var53;
      float var195;
      if (var250) {
         float var251 = var55 + var51 - 5.5F - var47;
         var195 = var251;
      } else {
         var195 = var55 + 5.5F;
      }

      float var57 = var195;
      boolean var252 = var53;
      float var196;
      if (var252) {
         float var253 = var55 + var51 - var48 - 0.5F;
         var196 = var253;
      } else {
         var196 = var55 + var48;
      }

      float var59;
      float var60;
      float var61;
      label139: {
         float var58 = var196;
         ManagedGlTexture var321 = this.d;
         float var328 = var56 + var52 / 2.0F - var47 / 2.0F;
         Object[] var136 = new Object[]{var9};
         var10011 = new Object[]{null, null, null, null, null, null, null, null, ClientUiUtil.dReturningColor(var136), var17};
         var10011[7] = var47;
         var10011[6] = var47;
         var10011[5] = var328;
         var10011[4] = var57;
         var10011[3] = var321;
         var10011[2] = var3;
         var10011[1] = var6;
         var10011[0] = var2;
         Object[] var137 = var10011;
         TexturedRectangleRenderer.cReturningVoid(var137);
         float var316 = var56 + 3.0F;
         float var322 = var58 + 0.5F;
         float var325 = var56 + var52 - 3.0F;
         Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var25};
         var10008[4] = var325;
         var10008[3] = var322;
         var10008[2] = var316;
         var10008[1] = var58;
         var10008[0] = var3;
         Object[] var138 = var10008;
         ShapeRenderer.lReturningVoid(var138);
         var59 = var56 + 3.0F;
         boolean var254 = var53;
         if (var254) {
            float var62 = var55 + var51 - var49;
            var61 = var62 - var44;
            var60 = var61 - 3.0F - var43;
            int var255 = var33;
            if (var255 != 0) {
               break label139;
            }
         }

         var60 = var55 + var49;
         var61 = var60 + var43 + 3.0F;
      }

      MsdfFontManager var303 = Prestige.c;
      Object[] var140 = new Object[]{var11};
      MsdfFontManager var139 = var303;
      MsdfFont var304 = var139.aReturningcx_C0158(var140);
      Object[] var10009 = new Object[]{null, null, null, null, null, var40, var15};
      var10009[4] = 1.0F;
      var10009[3] = var59;
      var10009[2] = var60;
      var10009[1] = var41;
      var10009[0] = var3;
      Object[] var142 = var10009;
      MsdfFont var141 = var304;
      var141.w(var142);
      var303 = Prestige.c;
      Object[] var144 = new Object[]{var11};
      MsdfFontManager var143 = var303;
      MsdfFont var306 = var143.aReturningcx_C0158(var144);
      String var317 = invokeBinding11(22749, 8752439514697536126L ^ var4);
      float var326 = var59 + (var45 - var46) - 0.5F;
      var10009 = new Object[]{null, null, null, null, null, UiMetrics.u, var15};
      var10009[4] = 0.65F;
      var10009[3] = var326;
      var10009[2] = var61;
      var10009[1] = var317;
      var10009[0] = var3;
      Object[] var146 = var10009;
      MsdfFont var145 = var306;
      var145.w(var146);
      float var288 = var59 + var45 + 1.0F + 4.0F;
      boolean var256 = var53;
      float var197;
      if (var256) {
         float var257 = var55 + 5.5F;
         var197 = var257;
      } else {
         var197 = var55 + var49;
      }

      float var63 = var197;
      boolean var258 = var53;
      float var198;
      if (var258) {
         float var259 = var55 + var51 - var49;
         var198 = var259;
      } else {
         var198 = var55 + var51 - 5.5F;
      }

      float var64 = var198;
      float var65 = (var64 - var63) / 24.0F;
      float var66 = 100.0F;
      float[] var67 = this.g;
      int var68 = var67.length;
      int var201;
      while (true) {
         int var261 = var68;
         int var260 = var69;
         if (var260 < var261) {
            float var70 = var67[var69];
            int var262 = var33;
            if (var262 != 0) {
               float var344;
               int var307 = (var344 = var70 - var66) == 0.0F ? 0 : (var344 < 0.0F ? -1 : 1);
               int var264 = var33;
               int var263 = var307;
               var201 = var263;
               int var199 = var263;
               if (var264 == 0) {
                  break;
               }

               int var265 = var199;
               int var200 = var265;
               int var266 = var200;
               if (var266 > 0) {
                  var66 = var70;
               }

               var69++;
            }

            int var267 = var33;
            if (var267 != 0) {
               continue;
            }
         }

         var201 = 0;
         break;
      }

      int var289 = var201;

      while (true) {
         int var269 = invokeBinding12(8542, 5965755871344909976L ^ var4);
         int var268 = var289;
         if (var268 < var269) {
            float var290 = this.g[(this.h + var289) % invokeBinding13(8542, 5965755871344909976L ^ var4)];
            int var270 = var33;
            if (var270 == 0) {
               break;
            }

            label189: {
               int var273 = var33;
               float var272 = 0.0F;
               float var271 = var290;
               float var206 = var271;
               float var207 = var272;
               float var202 = var271;
               float var203 = var272;
               if (var273 != 0) {
                  float var275 = var203;
                  float var274 = var202;
                  float var204 = var274;
                  float var205 = var275;
                  float var345;
                  int var276 = (var345 = var204 - var205) == 0.0F ? 0 : (var345 < 0.0F ? -1 : 1);
                  if (var276 <= 0) {
                     int var277 = var33;
                     if (var277 != 0) {
                        break label189;
                     }
                  }

                  float var279 = var290 / var66 * 3.5F;
                  float var278 = 0.5F;
                  var206 = var278;
                  var207 = var279;
               }

               float var291 = var206 + var207;
               float var292 = var63 + var289 * var65;
               Object[] var323 = new Object[]{null, var31};
               var323[0] = var290;
               Object[] var155 = var323;
               Color var71 = aReturningColor(var155);
               int var281 = var33;
               int var280 = var289;
               int var209 = var280;
               int var208 = var280;
               int var210;
               if (var281 != 0) {
                  int var283 = invokeBinding14(3711, 5185075599610245566L ^ var4);
                  int var282 = var208;
                  if (var282 == var283) {
                     int var284 = invokeBinding15(6958, 7750217941143086314L ^ var4);
                     var210 = var284;
                  } else {
                     var210 = invokeBinding16(19932, 2267717340882186762L ^ var4);
                  }
               } else {
                  int var285 = var209;
                  var210 = var285;
               }

               int var72 = var210;
               float var311 = var292 + 0.2F;
               float var318 = var288 - var291;
               float var324 = var292 + var65 - 0.2F;
               Color var158 = var71;
               int var334 = var158.getRed();
               Color var159 = var71;
               int var335 = var159.getGreen();
               Color var160 = var71;
               Object[] var336 = new Object[]{null, null, null, null, null, new Color(var334, var335, var160.getBlue(), var72), var25};
               var336[4] = var288;
               var336[3] = var324;
               var336[2] = var318;
               var336[1] = var311;
               var336[0] = var3;
               Object[] var161 = var336;
               ShapeRenderer.lReturningVoid(var161);
            }

            var289++;
            int var286 = var33;
            if (var286 != 0) {
               continue;
            }
         }

         Object[] var327 = new Object[]{null, var52};
         var327[0] = var51;
         Object[] var163 = var327;
         LatencyWidget var162 = this;
         var162.iReturningVoid(var163);
         break;
      }
   }

    private static Color aReturningColor(Object[] objectArray) {
        float f;
        long l;
        block13: {
            float f10;
            block14: {
                int n;
                block11: {
                    block12: {
                        f10 = ((Float)objectArray[0]).floatValue();
                        l = (Long)objectArray[1];
                        l = 0x1D6DB96A6F6BL ^ l;
                        n = LatencyWidget.invokeBinding17(-2555842180962388966L, l);
                        try {
                            try {
                                float f11 = f10 - 60.0f;
                                f = f11 == 0.0f ? 0 : (f11 < 0.0f ? -1 : 1);
                                if (n != 0) break block11;
                                if (f >= 0) break block12;
                            }
                            catch (MatchException matchException) {
                                throw LatencyWidget.invokeBinding18(matchException, -2550414083197104368L, l);
                            }
                            return new Color(LatencyWidget.invokeBinding19(12038, 0x16DAF17EB204FD3L ^ l), LatencyWidget.invokeBinding20(29810, 0x6F38565CA55A94A1L ^ l), LatencyWidget.invokeBinding21(21643, 0x18A1BA5164F13459L ^ l));
                        }
                        catch (MatchException matchException) {
                            throw LatencyWidget.invokeBinding22(matchException, -2550414083197104368L, l);
                        }
                    }
                    float f12 = f10 - 120.0f;
                    f = f12 == 0.0f ? 0 : (f12 < 0.0f ? -1 : 1);
                }
                try {
                    try {
                        if (n != 0) break block13;
                        if (f >= 0) break block14;
                    }
                    catch (MatchException matchException) {
                        throw LatencyWidget.invokeBinding23(matchException, -2550414083197104368L, l);
                    }
                    return new Color(LatencyWidget.invokeBinding24(5743, 0x3CDA869C73D5F6B5L ^ l), LatencyWidget.invokeBinding25(28138, 0x1CC51C1D51070D3AL ^ l), LatencyWidget.invokeBinding26(32702, 0x6F36EA30997F1F69L ^ l));
                }
                catch (MatchException matchException) {
                    throw LatencyWidget.invokeBinding27(matchException, -2550414083197104368L, l);
                }
            }
            float f13 = f10 - 200.0f;
            f = f13 == 0.0f ? 0 : (f13 < 0.0f ? -1 : 1);
        }
        try {
            if (f <= 0) {
                return new Color(LatencyWidget.invokeBinding28(16453, 0x4AFB539AAF97A099L ^ l), LatencyWidget.invokeBinding29(18072, 0x1C18FEAB72F12655L ^ l), LatencyWidget.invokeBinding30(13301, 0x5EE8AE92BECCD321L ^ l));
            }
        }
        catch (MatchException matchException) {
            throw LatencyWidget.invokeBinding31(matchException, -2550414083197104368L, l);
        }
        return new Color(LatencyWidget.invokeBinding32(22880, 0x6BB1B3E93DB139BBL ^ l), LatencyWidget.invokeBinding33(10605, 0x5E8DE643EBCEC9B3L ^ l), LatencyWidget.invokeBinding34(12372, 0x738162C5FCEF5098L ^ l));
    }

    private static int aReturningInt(Object[] objectArray) {
        int n;
        block6: {
            int n2;
            long l;
            block4: {
                float f;
                block5: {
                    f = ((Float)objectArray[0]).floatValue();
                    l = (Long)objectArray[1];
                    l = 0x1D6DB96A6F6BL ^ l;
                    int n3 = LatencyWidget.invokeBinding35(-2214311280916580065L, l);
                    try {
                        try {
                            float f10 = f - 0.0f;
                            n2 = f10 == 0.0f ? 0 : (f10 < 0.0f ? -1 : 1);
                            if (n3 == 0) break block4;
                            if (n2 >= 0) break block5;
                        }
                        catch (MatchException matchException) {
                            throw LatencyWidget.invokeBinding36(matchException, -2208110334328884528L, l);
                        }
                        n = 0;
                        break block6;
                    }
                    catch (MatchException matchException) {
                        throw LatencyWidget.invokeBinding37(matchException, -2208110334328884528L, l);
                    }
                }
                n2 = (int)f;
            }
            n = LatencyWidget.invokeBinding39(n2, LatencyWidget.invokeBinding38(30886, 0x4F1828AE883525B0L ^ l), -2214498131941478194L, l);
        }
        return n;
    }

   static {

      {

      b();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(70626653644382L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[5];
      String var28 = "Þï\u008a%üÄ\u0013l\u001a/1¼\u0006½»ÖÂ&Y`»¥ §{oÝÒ01¢÷g¡uòù0µ\u0088\u0001wÃ3TÔª\u0003\u0013ÆY\u000fGº EÆm´É\u0006\u009bÌc0\u001c¹A\u00801L\u0085\u009aÜ\u0013Ì;1<éûJ6ç\u0094\t1\u008dû\u008f\u000fW\u0006¥-Á¡\u0089H\u0010GJAªS\u001b\u0097bmÕJ\u008bO\u00108Õ\u009f\u0001GÑæ¶?<\u001aÏ4Ï6%";
      int var30 = "Þï\u008a%üÄ\u0013l\u001a/1¼\u0006½»ÖÂ&Y`»¥ §{oÝÒ01¢÷g¡uòù0µ\u0088\u0001wÃ3TÔª\u0003\u0013ÆY\u000fGº EÆm´É\u0006\u009bÌc0\u001c¹A\u00801L\u0085\u009aÜ\u0013Ì;1<éûJ6ç\u0094\t1\u008dû\u008f\u000fW\u0006¥-Á¡\u0089H\u0010GJAªS\u001b\u0097bmÕJ\u008bO\u00108Õ\u009f\u0001GÑæ¶?<\u001aÏ4Ï6%"
         .length();
      char var27 = '@';
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     w = var31;
                     x = new String[5];
                     D = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(70626653644382L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[19];
                     String var15 = "§¡R\u0002A§ ?x¯\u00019û¡õ¾ÿ\u009aØ*ú\u008aÌ\u00039$ü\u0090n\u0090ð\u000eP´=jköb\u008eþ\u0097ò\nC©\u0012Ó\u0095¾Ä\u0088\u0098\u0000P\u009e2lUý\u0019oî®_êGÛ9m\fe\u0011û{\u0017¾>Sô\u008a\u001bú\u0088¿Ú§*\u0095Ýr\u008aZßÖ\u001aÜN\u0016¾<»´)þÓqpv¦ýX\u007fyæ:Ç²þ\u0091\u0013¢\u000eäj?üåßð9°Ý\u001eDC";
                     int var16 = "§¡R\u0002A§ ?x¯\u00019û¡õ¾ÿ\u009aØ*ú\u008aÌ\u00039$ü\u0090n\u0090ð\u000eP´=jköb\u008eþ\u0097ò\nC©\u0012Ó\u0095¾Ä\u0088\u0098\u0000P\u009e2lUý\u0019oî®_êGÛ9m\fe\u0011û{\u0017¾>Sô\u008a\u001bú\u0088¿Ú§*\u0095Ýr\u008aZßÖ\u001aÜN\u0016¾<»´)þÓqpv¦ýX\u007fyæ:Ç²þ\u0091\u0013¢\u000eäj?üåßð9°Ý\u001eDC"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    B = var17;
                                    C = new Integer[19];
                                    a =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.LatencyWidget_31172";
                                    J = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(70626653644382L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[4];
                                    String var4 = "j\u009c4é\u0011z\u0017\u001eô÷]/ùýÃé";
                                    int var5 = "j\u009c4é\u0011z\u0017\u001eô÷]/ùýÃé".length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   H = var6;
                                                   I = new Long[4];
                                                   c =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.LatencyWidget_6898";
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "7XÓ\båeÕ\u0092>/\u0015v\u0017:@\u008b";
                                                var5 = "7XÓ\båeÕ\u0092>/\u0015v\u0017:@\u008b".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "tÆÔK\u0088ÃÉ\u008acN]¦\u0080é;Q";
                                 var16 = "tÆÔK\u0088ÃÉ\u008acN]¦\u0080é;Q".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "£yÐCâ¬?~-D\u001a\u009bY\u001bÚ«\u0010:)\u0096ôËxý\b\fâÙú,q}d";
                  var30 = "£yÐCâ¬?~-D\u001a\u009bY\u001bÚ«\u0010:)\u0096ôËxý\b\fâÙú,q}d".length();
                  var27 = 16;
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2355;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b7", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b7",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15446;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b7", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b7",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12377;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b7", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b7",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 0;
            yield var15;
         }
         case 1 -> {
            byte var16 = 10;
            yield var16;
         }
         case 2 -> {
            byte var17 = 46;
            yield var17;
         }
         case 3 -> {
            byte var18 = 61;
            yield var18;
         }
         case 4 -> {
            byte var19 = 6;
            yield var19;
         }
         case 5 -> {
            byte var20 = 28;
            yield var20;
         }
         case 6 -> {
            byte var21 = 29;
            yield var21;
         }
         case 7 -> {
            byte var22 = 43;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 14;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 37;
            yield var26;
         }
         case 12 -> {
            byte var27 = 13;
            yield var27;
         }
         case 13 -> {
            byte var28 = 20;
            yield var28;
         }
         case 14 -> {
            byte var29 = 12;
            yield var29;
         }
         case 15 -> {
            byte var30 = 8;
            yield var30;
         }
         case 16 -> {
            byte var31 = 39;
            yield var31;
         }
         case 17 -> {
            byte var32 = 11;
            yield var32;
         }
         case 18 -> {
            byte var33 = 4;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 19;
            yield var35;
         }
         case 21 -> {
            byte var36 = 22;
            yield var36;
         }
         case 22 -> {
            byte var37 = 18;
            yield var37;
         }
         case 23 -> {
            byte var38 = 53;
            yield var38;
         }
         case 24 -> {
            byte var39 = 1;
            yield var39;
         }
         case 25 -> {
            byte var40 = 3;
            yield var40;
         }
         case 26 -> {
            byte var41 = 31;
            yield var41;
         }
         case 27 -> {
            byte var42 = 44;
            yield var42;
         }
         case 28 -> {
            byte var43 = 62;
            yield var43;
         }
         case 29 -> {
            byte var44 = 23;
            yield var44;
         }
         case 30 -> {
            byte var45 = 7;
            yield var45;
         }
         case 31 -> {
            byte var46 = 21;
            yield var46;
         }
         case 32 -> {
            byte var47 = 45;
            yield var47;
         }
         case 33 -> {
            byte var48 = 47;
            yield var48;
         }
         case 34 -> {
            byte var49 = 51;
            yield var49;
         }
         case 35 -> {
            byte var50 = 9;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 54;
            yield var52;
         }
         case 38 -> {
            byte var53 = 41;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 34;
            yield var55;
         }
         case 41 -> {
            byte var56 = 58;
            yield var56;
         }
         case 42 -> {
            byte var57 = 36;
            yield var57;
         }
         case 43 -> {
            byte var58 = 27;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 24;
            yield var60;
         }
         case 46 -> {
            byte var61 = 25;
            yield var61;
         }
         case 47 -> {
            byte var62 = 16;
            yield var62;
         }
         case 48 -> {
            byte var63 = 38;
            yield var63;
         }
         case 49 -> {
            byte var64 = 49;
            yield var64;
         }
         case 50 -> {
            byte var65 = 5;
            yield var65;
         }
         case 51 -> {
            byte var66 = 55;
            yield var66;
         }
         case 52 -> {
            byte var67 = 60;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 50;
            yield var69;
         }
         case 55 -> {
            byte var70 = 40;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 42;
            yield var72;
         }
         case 58 -> {
            byte var73 = 26;
            yield var73;
         }
         case 59 -> {
            byte var74 = 52;
            yield var74;
         }
         case 60 -> {
            byte var75 = 63;
            yield var75;
         }
         case 61 -> {
            byte var76 = 15;
            yield var76;
         }
         case 62 -> {
            byte var77 = 32;
            yield var77;
         }
         default -> 56;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "s({\u001dW$e(~GD3rc}AH'c$jV\u00036 ";
      K[1] = ",\u000b4\u000bb\u001cY+?\u0004sS8%4\u000fw\tL";
      K[2] = int.class;
      L[2] = "java/lang/Integer";
      K[3] = "P\u0000\u001f]F\u0000[\u000f\u000e\u0012%\rN\t";
      K[4] = "R.t\u0001BS'\u000e\u007f\u000eS\u001cF\u0000t\u0005WF2";
      K[5] = "Ih&\u000b$\fT}~)e\u0001L{";
      K[6] = "%5}Y='.:l\u0016@2< nU";
      K[7] = long.class;
      L[7] = "java/lang/Long";
      K[8] = "V\rqOb~@\rt\u0015qiWFw\u0013}}F\u0001`\u00046m^\u0001b\u000fl b\u001ab\u0012lgU\r";
      K[9] = "i\u001e\u000e\u001c]~\u007f\u001e\u000bFNihU\b@B}y\u0012\u001fW\tmw";
      K[10] = "\u0011P7\u000e=j\u0011P R1e\u000b\u001b L1p\fjp\u0011`";
      K[11] = "w\u001ai$.Hw\u001a~x\"GmQ~f\"Rj )9t";
      K[12] = "\tA\u0006a|f\u001fA\u0003;oq\b\n\u0000=ce\u0019M\u0017*(u\u0015";
      K[13] = "<\"\u00034`HI\u0002\b;q\u0007(\f\u00030u]\\";
      K[14] = void.class;
      L[14] = "java/lang/Void";
      K[15] = "\rfRB|#\u001bfW\u0018o4\f-T\u001ec \u001djC\t(2,";
      K[16] = ",\u0018d:\u0005T,\u0018sf\t[6Ssx\tN1\"&'\\";
      K[17] = "\u0006\u001fP;\u0006\u0002\u0010\u001fUa\u0015\u0015\u0007TVg\u0019\u0001\u0016\u0013ApR\u0010S";
      K[18] = "pyH\u0007_b\u0005YC\bN-dWH\u0003Jw\u0010";
      K[19] = "~oh\\\n(hom\u0006\u0019?\u007f$n\u0000\u0015+ncy\u0017^<l";
      K[20] = "+BL_\u0011,^bGP\u0000c?lL[\u00049K";
      K[21] = "\u0018\u001b:K?c\u0018\u001b-\u00173l\u0002P-\t3y\u0005!yQd";
      K[22] = ",|5RP6Y\\>]Ay8R5VE#L";
      K[23] = float.class;
      L[23] = "java/lang/Float";
      K[24] = "_(:;,6T'+tO;A*$\u001fz9P983m4";
      K[25] = "\u0019B XCu\u0019B7\u0004Oz\u0003\t7\u001aOo\u0004xbB\u001e";
      K[26] = "v%h:_y`%m`Lnwnnf@zf)yq\u000bhP";
      K[27] = "brRVon\u0017RYY~!v\\RRz{\u0002";
      K[28] = "\u001eeNK\u0004\u0019kEED\u0015V\nKNO\u0011\f~";
      K[29] = "X\u000b9\u00178\u0017-+2\u0018)XL%9\u0013-\u00028";
      K[30] = boolean.class;
      L[30] = "java/lang/Boolean";
      K[31] = "\t[,RhR\u0017S6\u001d\u0013r*~";
      K[32] = "g|`O?tq|e\u0015,cf7f\u0013 wwpq\u0004kgh";
      K[33] = "mDE&\f|\u0018dN)\u001d3yjE\"\u0019i\r";
      K[34] = "rZ\fDE%dZ\t\u001eV2s\u0011\n\u0018Z&bV\u001d\u000f\u00111~";
      K[35] = "_81|U\u0016*\u0018:sDYK\u00161x@\u0003?";
      K[36] = "-S\u000b:V\u0001;S\u000e`E\u0016,\u0018\rfI\u0002=_\u001aq\u0002\u0013\u001d";
      K[37] = "l\"K ](z\"NzN?miM|B+|.Zk\t<o";
      K[38] = "O{sU}#:[xZll[UsQh6/";
      K[39] = "\u0014B*L\r\u000e\u001fM;\u0003p\u0016\fJ2J";
      K[40] = "8rde\u001e+MRoj\u000fd,\\da\u000b>X";
      K[41] = "t\u0003\u0018oP5b\u0003\u001d5C\"uH\u001e3O6d\u000f\t$\u0004!v";
      K[42] = "0r\u000f\u0013A#ER\u0004\u001cPl$\\\u000f\u0017T6P";
      K[43] = "1\u0017nke\u0015'\u0017k1v\u00020\\h7z\u0016!\u001b\u007f 1\u0006l";
      K[44] = "\u000fn\u0017\\i;zN\u001cSxt\u001b@\u0017X|.o";
      K[45] = "D@\u001b\u00020g1`\u0010\r!(Pn\u001b\u0006%r$";
      K[46] = "g\u0007\u001fO\u0000U\u0012'\u0014@\u0011\u001as)\u001fK\u0015@\u0007";
      K[47] = "\u000bK\"\u0003\u000e\u0007\u0000D3Lo\t\u000bO7\u0016";
      K[48] = "I)\u0013\f~\u0007W{\u0010nn>Sq\u0001\f<\u0006F{\u001f\u0007\u0007\u0007I)\u001aTnPVwFn";
      K[49] = "c\\\u0000\u001aqq!]B\u0007I}0J8@,)<\u0000Q\u00173w`:\u0001\u001cx}cSV\u0003&!Y\u0003]H,\"0TB\u0016p\u0018";
      K[50] = "3\u0004N\u00153y-VMw#@)\\\\\u0015qx<VB\u001eJ|jNNNw\"'M_w";
      K[51] = "%\u00140*,r/\f7$J`LQ.$/0%\u00061zs\n";
      K[52] = ",\u001aBL\u001a\u0018~\u0006\\Y'\u0011m\u0005^^A\u0006L\u001eA^b\u001bt\u001bEH'G\u007fGU^C\bhC^3";
      K[53] = "%\u0012GLP7&_\u000f\u0014=e\u0018\\\u0002M\u0003w$\u0019AO\u0004";
      K[54] = "*}.\u0017Rmil.\u00035{t}5\u0002b,*-ln\u0005|o ?\u001cT/h)";
      K[55] = "\u001c\u001c\u000f)=S\u0012\u0000\u0005*R\u0016,\u0005\u0014o0R\u0014\u0010\u001eq;iEEEj*\t\u0017\u001d\u0011xR";
      K[56] = "&Kk L6,Sl.*%O\u000eu.Ot&Yjp\u0013N";
      K[57] = "|\u000e\u001f\u0006Q\n?\u001f\u001f\u00126\u0017.\u001f\u0000\u0018Z%z^^E6\u0018(Z\u000f\u0015G\u0003}\n\u0000\u007f";
      K[58] = "F'd*Z\u000b\u001c`xu'\u0017,%}:EM\u00140w$NvEe,?_\u0016\u0017=x-'";
      K[59] = "\u0012\u0011\u0006\u001d\u000fm\u000fUFG47~\u0017\u0017_VhF\u0002\u001dA]S\u0017WFZL3E\u000f\u0012H4";
      K[60] = "eR(zF)&C(n!?;R3ovhe\u0005k\u0003L#<O4;P3!\u000e";
      K[61] = "%iZ=p\u0000+uP>\u001fS\u0015pA{}\u0001-eKev:z2\u00124a[hmN8\u001f";
      K[62] = "8 %{*\u001dz!gf\u0012\u0011c \u001d!wEg|tvh\u001b;F$}#\u00118/sb}M\u0002\u007fx)wNk(gw+t";
      K[63] = "B<\u000bV9\b\u001cq\bG\u0000Z\u0013|*Wl5GeA_:\\\u0010z\u001f\u0003\u0000";
      K[64] = "(&7]n\"6t4?~\u001b-&jCtz1f Z\u0017{|&'\\vg<l>?";
      K[65] = "\u000f~\u0003v0L\u0005d]2QP\u0002z\u0001)=bU7\\\u007fQ\f\n7\u0004t8[\u0015iXN";
      K[66] = "\u0012v0\u001d[\u0013\u0019/`Ce\u000fshi\u0005\u0007XK}c\u001b\fcO+{\u0017\\^\u0011fx\u0006e";
      K[67] = "O\u0015\u0005`(<\r\u0014G}\u00100\u001c\u0003=l-oD\r\\~r3HsR>*d\u000b\u0012@avhu\u001c\u00009!+\u0014\u000e_e-U";
      K[68] = "O\u00152wD\u0007\r\u0014pj|\u0014\u0012\u000elx|\u0001HI;j\u001d\u0013\u0017\u00157\u0014E\u000bD\u00160}\u0012\u0014\u001aJ\n";
      K[69] = "\u0019\u0017!\\%\u0001GZ\"M\u001cSHW\u0010TaQ%\u0012?\u0001y\u0006LE _%<";
      K[70] = "t&5?*\u00061e78SSJ%c\u007f1\u0001r0ia::z<x9<\u0000t r:S";
      K[71] = "=\u0017V8\u0015$gPJgh2W\u0015O(\nbo\u0000E6\u0001Y3\u0004]5We)\u001aJ2h";
      K[72] = "\u0005\u0002_\u000f\u001at\u001eW\u000f\u0000p`\u0002\u0015\u0006\u0007\u001cRUYYYpa\nXWQO5T\u000b\\`\u0010}\rQ\u0007\u0019\u001agS\u0015f";
      K[73] = "\b&\"p\u0018\u0000Ra>/e\u0014b$;`\u0007FZ11~\f}\u000bdje\u001d\u001dY<>we";
      K[74] = "d:6%\u0007\u000fd%0ciU\u0001#\"e\u000b\u000496({\u0000?naq*\u0017^|>-&i";
      K[75] = "u=Zg%\u0001.o\u0006lL\u0010\u0012|S\u007f.B*iYa%yj3Yy}\u0006m3\u0002lL";
      K[76] = "6L\u001ezfq0\u0010\u000fqXkO\u000f\u000fd:;w\u001a\u0005z1\u0000&O^a `t\u0017\nsX";
      K[77] = "\u0018qQ-\u0017dS{Hh.d\u000bzK=itb'SaK \u000bpL?\u0017\u001a\u0018qQ-\u0017dS{Hh.";
      K[78] = "\u0006M\b\u0000#\u0015\u001a]\u0015A@H\u0006C\u000e\u0017,zV\u0001PO@I\u000e\u000e_A\u007f\u001dP]Tp";
      K[79] = "\u0007>Pe!X\fg\u0000;\u001fBf \t}}\u0013^5\u0003cv(\tbZ2aI\u001b=\u0006>\u001f";
      K[80] = "45LJ9\u0000si^\u000bT\u0012O)L\n6Bw<F\u0014=y&i\u001d\u000f,\u0019t1I\u001dT";
      K[81] = "\f/|C\u0012SAz'P+\u000eq?)RIXI*#LBc\u0018\u007fxWS\u0003J',E+";
      K[82] = "W}#\u0011MwYa)\u0012\"&gd8W@v_q2IKM\b&k\u0018\\,\u001ay7\u0014\"";
      K[83] = "tQ'\u0010Y:*\u001c$\u0001`h%\u0011\u0013\u0006\rj.me\u0019Qbr\u00042\u0006\u000f>H";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3355556175617285L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3355556175617285L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3355556175617285L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 66;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 249;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 36;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 197;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 198;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 66;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 249;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b7",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static String invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = a(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = a(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = d(MethodHandles.lookup(), "k", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding5(int var0, long var1) {
         MethodHandle var7 = bindingCache5;
         MethodHandle var6 = bindingCache5;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache5 = d(MethodHandles.lookup(), "k", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = a(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding7(int var0, long var1) {
         MethodHandle var7 = bindingCache7;
         MethodHandle var6 = bindingCache7;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache7 = d(MethodHandles.lookup(), "k", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding8(int var0, long var1) {
         MethodHandle var7 = bindingCache8;
         MethodHandle var6 = bindingCache8;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache8 = d(MethodHandles.lookup(), "k", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding9(int var0, long var1) {
         MethodHandle var7 = bindingCache9;
         MethodHandle var6 = bindingCache9;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache9 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = a(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static String invokeBinding11(int var0, long var1) {
         MethodHandle var7 = bindingCache11;
         MethodHandle var6 = bindingCache11;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache11 = a(MethodHandles.lookup(), "j", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding12(int var0, long var1) {
         MethodHandle var7 = bindingCache12;
         MethodHandle var6 = bindingCache12;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache12 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding13(int var0, long var1) {
         MethodHandle var7 = bindingCache13;
         MethodHandle var6 = bindingCache13;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache13 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding14(int var0, long var1) {
         MethodHandle var7 = bindingCache14;
         MethodHandle var6 = bindingCache14;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache14 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding15(int var0, long var1) {
         MethodHandle var7 = bindingCache15;
         MethodHandle var6 = bindingCache15;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache15 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding16(int var0, long var1) {
         MethodHandle var7 = bindingCache16;
         MethodHandle var6 = bindingCache16;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache16 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding17(long var0, long var2) {
         MethodHandle var8 = bindingCache17;
         MethodHandle var7 = bindingCache17;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache17 = g(MethodHandles.lookup(), "Æ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding19(int var0, long var1) {
         MethodHandle var7 = bindingCache19;
         MethodHandle var6 = bindingCache19;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache19 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding20(int var0, long var1) {
         MethodHandle var7 = bindingCache20;
         MethodHandle var6 = bindingCache20;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache20 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static MatchException invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding24(int var0, long var1) {
         MethodHandle var7 = bindingCache24;
         MethodHandle var6 = bindingCache24;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache24 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding25(int var0, long var1) {
         MethodHandle var7 = bindingCache25;
         MethodHandle var6 = bindingCache25;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache25 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding26(int var0, long var1) {
         MethodHandle var7 = bindingCache26;
         MethodHandle var6 = bindingCache26;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache26 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static MatchException invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding28(int var0, long var1) {
         MethodHandle var7 = bindingCache28;
         MethodHandle var6 = bindingCache28;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache28 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding29(int var0, long var1) {
         MethodHandle var7 = bindingCache29;
         MethodHandle var6 = bindingCache29;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache29 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding30(int var0, long var1) {
         MethodHandle var7 = bindingCache30;
         MethodHandle var6 = bindingCache30;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache30 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static MatchException invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding32(int var0, long var1) {
         MethodHandle var7 = bindingCache32;
         MethodHandle var6 = bindingCache32;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache32 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding33(int var0, long var1) {
         MethodHandle var7 = bindingCache33;
         MethodHandle var6 = bindingCache33;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache33 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding34(int var0, long var1) {
         MethodHandle var7 = bindingCache34;
         MethodHandle var6 = bindingCache34;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache34 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding35(long var0, long var2) {
         MethodHandle var8 = bindingCache35;
         MethodHandle var7 = bindingCache35;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache35 = g(MethodHandles.lookup(), "Æ", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = g(
                  MethodHandles.lookup(), "Æ", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding38(int var0, long var1) {
         MethodHandle var7 = bindingCache38;
         MethodHandle var6 = bindingCache38;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache38 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding39(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = g(MethodHandles.lookup(), "Æ", SourceSupport.methodType("(IIJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding40(int var0, long var1) {
         MethodHandle var7 = bindingCache40;
         MethodHandle var6 = bindingCache40;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache40 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding41(int var0, long var1) {
         MethodHandle var7 = bindingCache41;
         MethodHandle var6 = bindingCache41;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache41 = d(MethodHandles.lookup(), "k", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
