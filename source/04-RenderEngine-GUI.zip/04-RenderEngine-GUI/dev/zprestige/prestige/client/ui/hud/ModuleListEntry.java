package dev.zprestige.prestige.client.ui.hud;

import dev.zprestige.prestige.api.module.Module;

public record ModuleListEntry(Module aW, String aX, float aY) {
}
