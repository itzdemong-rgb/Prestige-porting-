package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import dev.zprestige.prestige.client.management.ModuleManager;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;

public class ModuleListWidget extends HudElement {
   private final Map a;
   private final Map c;
   private final Map d;
   private static long i;
   private static float m;
   private static final float j = 500.0F;
   private static final float k = 1.0F;
   private float l;
   private float o;
   private static final long v = 140608460609745L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[109];
   private static final String[] L = new String[109];
   private static volatile MethodHandle bindingCache1;

   public ModuleListWidget(long var1) {
      super("Module List", "List of currently enabled modules", ((140608460609745L ^ (140608460609745L ^ var1)) ^ 39152934017637L));
      var1 = 140608460609745L ^ var1;
      long var3 = var1 ^ 39152934017637L;
      short var10001 = 15332;
      long var10002 = 9186972328583088823L ^ var1;
      short var6 = 4389;
      long var10003 = 5143923539882762359L ^ var1;

      this.a = new HashMap();
      this.c = new HashMap();
      this.d = new HashMap();
      this.l = 0.0F;
      this.o = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 135.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      ModuleListWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void q(Object[] var1) {
      Matrix4f var4;
      long var5;
      ModuleListWidget var12;
      label26: {
         var4 = (Matrix4f)var1[0];
         long var2 = (Long)var1[1];
         var5 = var2 ^ 0L;
         int var7 = Event.bReturningInt();
         float var21;
         int var10000 = (var21 = this.g - 0.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
         int var14 = var7;
         int var13 = var10000;
         int var11 = var13;
         int var8 = var13;
         if (var14 == 0) {
            int var15 = var8;
            if (var15 <= 0) {
               return;
            }

            int var17 = var7;
            ModuleListWidget var16 = this;
            var12 = var16;
            ModuleListWidget var9 = var16;
            if (var17 != 0) {
               break label26;
            }

            ModuleListWidget var18 = var9;
            ModuleListWidget var10 = var18;
            float var22;
            int var19 = (var22 = var10.h - 0.0F) == 0.0F ? 0 : (var22 < 0.0F ? -1 : 1);
            var11 = var19;
         }

         int var20 = var11;
         if (var20 <= 0) {
            return;
         }

         var12 = this;
      }

      var12.q(new Object[]{var4, var5});
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var6 = (MeshBufferManager)var1[0];
      RenderContext var2 = (RenderContext)var1[1];
      Matrix4f var3 = (Matrix4f)var1[2];
      long var4 = (Long)var1[3];
      long var7 = var4 ^ 49928519994039L;
      long var9 = var4 ^ 41197988814736L;
      long var11 = var4 ^ 98258037622386L;
      long var13 = var4 ^ 48887442607471L;
      long var15 = var4 ^ 81054074941871L;
      long var17 = var4 ^ 36477842301344L;
      long var19 = var4 ^ 126879126745269L;
      long var21 = var4 ^ 13608202459885L;
      long var23 = var4 ^ 29307267718371L;
      long var25 = var4 ^ 46684315333905L;
      long var27 = var4 ^ 107676523192134L;
      int var10000 = Event.cReturningInt();
      long var30 = System.currentTimeMillis();
      int var29 = var10000;
      m = (float)(var30 - i) * 0.005F;
      i = var30;
      ModuleManager var62 = Prestige.d;
      List var63 = var62.aReturningVoid();
      Iterator var32 = var63.iterator();

      int var245;
      do {
         Iterator var64 = var32;
         boolean var235 = var64.hasNext();
         if (!var235) {
            break;
         }

         Module var33;
         boolean var202;
         Iterator var65 = var32;
         var33 = (Module)var65.next();
         Module var66 = var33;
         boolean var34 = var66.aReturningBoolean();
         Map var318 = this.c;
         boolean var67 = var34;
         Boolean var70 = var67;
         Module var69 = var33;
         Map var68 = var318;
         Boolean var35 = ((java.lang.Boolean)(Object)(var68.put(var69, var70)));
         int var237 = var29;
         boolean var236 = var34;
         var202 = var236;
         boolean var199 = var236;
         label199:
         if (var237 != 0) {
            boolean var238 = var199;
            if (var238) {
               Boolean var73 = var35;
               Boolean var72 = Boolean.FALSE;
               boolean var319 = var72.equals(var73);
               int var240 = var29;
               boolean var239 = var319;
               var202 = var239;
               boolean var200 = var239;
               if (var240 == 0) {
                  break label199;
               }

               boolean var241 = var200;
               boolean var201 = var241;
               boolean var242 = var201;
               if (var242) {
                  Map var320 = this.d;
                  long var76 = var30;
                  Long var80 = var76;
                  Module var79 = var33;
                  Map var78 = var320;
                  var78.put(var79, var80);
               }
            }

            var202 = var34;
         }

         boolean var243 = var202;
         float var203;
         if (var243) {
            float var244 = 1.0F;
            var203 = var244;
         } else {
            var203 = 0.0F;
         }

         float var36 = var203;
         Map var321 = this.a;
         float var83 = 0.0F;
         Float var86 = var83;
         Module var85 = var33;
         Map var84 = var321;
         Float var87 = ((java.lang.Float)(Object)(var84.getOrDefault(var85, var86)));
         float var37 = var87;
         float var10002 = m;
         Object[] var10005 = new Object[]{null, null, null, var9};
         var10005[2] = var10002;
         var10005[1] = var36;
         var10005[0] = var37;
         Object[] var88 = var10005;
         var37 = ClientUiUtil.bReturningFloat(var88);
         Map var322 = this.a;
         float var89 = var37;
         Float var92 = var89;
         Module var91 = var33;
         Map var90 = var322;
         var90.put(var91, var92);
         var245 = var29;
      } while (var245 != 0);

      ArrayList var307 = new ArrayList();
      Map var93 = this.a;
      Set var94 = var93.entrySet();
      Iterator var308 = var94.iterator();

      ArrayList var210;
      label207: {
         int var209;
         while (true) {
            Iterator var95 = var308;
            boolean var246 = var95.hasNext();
            if (var246) {
               Iterator var96 = var308;
               Entry var310 = (Entry)var96.next();
               Entry var97 = var310;
               Float var98 = (Float)var97.getValue();
               float var368;
               var10000 = (var368 = var98 - 0.005F) == 0.0F ? 0 : (var368 < 0.0F ? -1 : 1);
               int var248 = var29;
               int var247 = var10000;
               var209 = var247;
               int var204 = var247;
               if (var248 == 0) {
                  break;
               }

               int var250 = var29;
               int var249 = var204;
               int var205 = var249;
               if (var250 != 0) {
                  int var251 = var205;
                  int var206 = var251;
                  int var252 = var206;
                  if (var252 > 0) {
                     Entry var102 = var310;
                     ArrayList var101 = var307;
                     boolean var253 = var101.add(var102);
                  }
               }

               int var254 = var29;
               if (var254 != 0) {
                  continue;
               }
            }

            int var256 = var29;
            ArrayList var255 = var307;
            var210 = var255;
            ArrayList var208 = var255;
            if (var256 == 0) {
               break label207;
            }

            ArrayList var104 = var208;
            byte var257 = ((byte)((var104.isEmpty()) ? 1 : 0));
            var209 = var257;
            break;
         }

         int var258 = var209;
         if (var258 != 0) {
            Object[] var361 = new Object[]{null, 0.0F};
            var361[0] = 0.0F;
            Object[] var107 = var361;
            ModuleListWidget var106 = this;
            var106.iReturningVoid(var107);
            this.l = 0.0F;
            this.o = 0.0F;
            return;
         }

         var210 = var307;
      }

      Comparator var110 = invokeBinding1();
      ArrayList var109 = var210;
      var109.sort(var110);
      MsdfFontManager var324 = Prestige.c;
      Object[] var112 = new Object[]{var21};
      MsdfFontManager var111 = var324;
      MsdfFont var325 = var111.aReturningcx_C0158(var112);
      Object[] var114 = new Object[]{var7};
      MsdfFont var113 = var325;
      float var309 = var113.cReturningFloat(var114);
      Object[] var10003 = new Object[]{null, 1.0F};
      var10003[0] = var309;
      Object[] var115 = var10003;
      float var311 = UiMetrics.aReturningFloat(var115);
      float var312 = 0.0F;
      float var313 = 0.0F;
      ArrayList var116 = var307;
      Iterator var315 = var116.iterator();

      int var217;
      while (true) {
         Iterator var117 = var315;
         boolean var259 = var117.hasNext();
         if (var259) {
            Iterator var118 = var315;
            Entry var38 = (Entry)var118.next();
            MsdfFontManager var326 = Prestige.c;
            Object[] var120 = new Object[]{var21};
            MsdfFontManager var119 = var326;
            MsdfFont var327 = var119.aReturningcx_C0158(var120);
            Entry var121 = var38;
            Module var122 = (Module)var121.getKey();
            Object[] var124 = new Object[]{var122.bReturningString(), var15};
            MsdfFont var123 = var327;
            float var39 = var123.aReturningFloat(var124) + 11.0F;
            int var262 = var29;
            float var261 = var312;
            float var260 = var39;
            float var215 = var260;
            float var216 = var261;
            float var211 = var260;
            float var212 = var261;
            if (var262 != 0) {
               float var369;
               var10000 = (var369 = var211 - var212) == 0.0F ? 0 : (var369 < 0.0F ? -1 : 1);
               int var264 = var29;
               int var263 = var10000;
               var217 = var263;
               int var213 = var263;
               if (var264 == 0) {
                  break;
               }

               int var265 = var213;
               int var214 = var265;
               int var266 = var214;
               if (var266 > 0) {
                  var312 = var39;
               }

               float var10001 = var311 + 1.0F;
               Entry var127 = var38;
               Float var128 = (Float)var127.getValue();
               var216 = var10001 * var128;
               var215 = var313;
            }

            var313 = var215 + var216;
            int var267 = var29;
            if (var267 != 0) {
               continue;
            }
         }

         MinecraftClient var129 = b;
         Window var130 = var129.getWindow();
         var217 = var130.getScaledWidth();
         break;
      }

      float var329 = var217;
      MinecraftClient var131 = b;
      Window var132 = var131.getWindow();
      float var330 = var132.getScaledHeight();
      Object[] var134 = new Object[0];
      ModuleListWidget var133 = this;
      byte var316 = ((byte)((var133.dReturningBoolean(var134)) ? 1 : 0));
      Object[] var136 = new Object[0];
      ModuleListWidget var135 = this;
      byte var40 = ((byte)((var135.cReturningBoolean(var136)) ? 1 : 0));
      MinecraftClient var137 = b;
      boolean var41 = var137.currentScreen instanceof HudEditorScreen;
      int var268 = var29;
      if (var268 != 0) {
         ModuleListWidget var227;
         label156: {
            boolean var269 = var41;
            label155:
            if (!var269) {
               int var222;
               int var271 = var29;
               byte var270 = var316;
               var222 = var270;
               byte var218 = var270;
               label152:
               if (var271 != 0) {
                  byte var272 = var218;
                  byte var219 = var272;
                  byte var273 = var219;
                  if (var273 != 0) {
                     float var370;
                     var10000 = (var370 = this.l - 0.0F) == 0.0F ? 0 : (var370 < 0.0F ? -1 : 1);
                     int var275 = var29;
                     int var274 = var10000;
                     var222 = var274;
                     int var220 = var274;
                     if (var275 == 0) {
                        break label152;
                     }

                     int var276 = var220;
                     int var221 = var276;
                     int var277 = var221;
                     if (var277 > 0) {
                        this.f = this.f - (var313 - this.l);
                     }
                  }

                  var222 = var40;
               }

               int var279 = var29;
               int var278 = var222;
               int var226 = var278;
               int var223 = var278;
               if (var279 != 0) {
                  int var280 = var223;
                  if (var280 == 0) {
                     break label155;
                  }

                  int var282 = var29;
                  ModuleListWidget var281 = this;
                  var227 = var281;
                  ModuleListWidget var224 = var281;
                  if (var282 == 0) {
                     break label156;
                  }

                  ModuleListWidget var283 = var224;
                  ModuleListWidget var225 = var283;
                  float var371;
                  int var284 = (var371 = var225.o - 0.0F) == 0.0F ? 0 : (var371 < 0.0F ? -1 : 1);
                  var226 = var284;
               }

               int var285 = var226;
               if (var285 > 0) {
                  this.e = this.e - (var312 - this.o);
               }
            }

            this.l = var313;
            this.o = var312;
            var227 = this;
         }

         Object[] var10004 = new Object[]{null, var313};
         var10004[0] = var312;
         Object[] var149 = var10004;
         ModuleListWidget var148 = var227;
         var148.iReturningVoid(var149);
      }

      Object[] var150 = new Object[]{var17};
      Color var42 = ClientUiUtil.dReturningColor(var150);
      ArrayList var151 = var307;
      int var43 = var151.size();
      byte var286 = var316;
      float var228;
      if (var286 != 0) {
         float var287 = this.f + var313 - var311;
         var228 = var287;
      } else {
         var228 = this.f;
      }

      float var44 = var228;
      int var306;
      do {
         ArrayList var153 = var307;
         int var289 = var153.size();
         int var288 = var45;
         if (var288 >= var289) {
            break;
         }

         int var155 = var45;
         ArrayList var154 = var307;
         Entry var46 = (Entry)var154.get(var155);
         Entry var156 = var46;
         Module var47 = (Module)var156.getKey();
         Entry var157 = var46;
         Float var158 = (Float)var157.getValue();
         float var48 = var158;
         Module var159 = var47;
         String var49 = var159.bReturningString();
         MsdfFontManager var332 = Prestige.c;
         Object[] var161 = new Object[]{var21};
         MsdfFontManager var160 = var332;
         MsdfFont var333 = var160.aReturningcx_C0158(var161);
         Object[] var163 = new Object[]{var49, var15};
         MsdfFont var162 = var333;
         float var50 = var162.aReturningFloat(var163) + 11.0F;
         float var51 = (1.0F - var48) * 6.0F;
         int var291 = var29;
         byte var290 = var40;
         byte var230 = var290;
         byte var229 = var290;
         int var231;
         if (var291 != 0) {
            byte var292 = var229;
            if (var292 != 0) {
               int var293 = var43 - 1 - var45;
               var231 = var293;
            } else {
               var231 = var45;
            }
         } else {
            byte var294 = var230;
            var231 = var294;
         }

         Color var53;
         float var54;
         label133: {
            int var52 = var231;
            short var339 = 16151;
            long var341 = 1701250234352153589L ^ var4;
            short var342 = 11151;
            long var349 = 7768947625267210095L ^ var4;
            int var343 = 10 + var52;
            Object[] var362 = new Object[]{null, null, null, var19};
            var362[2] = var343;
            var362[1] = 10;
            var362[0] = var42;
            Object[] var166 = var362;
            var53 = GameRenderUtil.bReturningColor(var166);
            byte var295 = var40;
            if (var295 != 0) {
               var54 = this.e + var312 - var50 - var51;
               int var296 = var29;
               if (var296 != 0) {
                  break label133;
               }
            }

            var54 = this.e + var51;
         }

         Map var334 = this.d;
         int var344 = 19870;
         long var350 = 10672721967564557L ^ var4;
         Long var171 = 0L;
         Module var170 = var47;
         Map var169 = var334;
         Long var172 = ((java.lang.Long)(Object)(var169.getOrDefault(var170, var171)));
         long var55 = var172;
         short var340 = 28125;
         long var345 = 5233847758151706447L ^ var4;
         long var372;
         int var297 = (var372 = var55 - 0L) == 0L ? 0 : (var372 < 0L ? -1 : 1);
         float var232;
         if (!((var297) != 0)) {
            float var298 = 0.0F;
            var232 = var298;
         } else {
            float var175 = 1.0F - (float)(var30 - var55) / 500.0F;
            float var174 = 0.0F;
            var232 = Math.max(var174, var175);
         }

         label127: {
            label126: {
               label215: {
                  float var57 = var232;
                  var57 *= var57;
                  Color var176 = UiMetrics.r;
                  var10000 = (int)(var176.getAlpha() * var48);
                  var10003 = new Object[]{null, var11};
                  var10003[0] = var10000;
                  Object[] var177 = var10003;
                  int var58 = aReturningInt(var177);
                  float var59 = var57 * 0.35F;
                  Color var178 = UiMetrics.r;
                  var344 = var178.getRed();
                  Color var179 = var53;
                  int var352 = var179.getRed();
                  Object[] var10007 = new Object[]{null, null, null, var27};
                  var10007[2] = var59;
                  var10007[1] = var352;
                  var10007[0] = var344;
                  Object[] var180 = var10007;
                  var344 = bReturningInt(var180);
                  Color var181 = UiMetrics.r;
                  int var353 = var181.getGreen();
                  Color var182 = var53;
                  int var357 = var182.getGreen();
                  Object[] var10008 = new Object[]{null, null, null, var27};
                  var10008[2] = var59;
                  var10008[1] = var357;
                  var10008[0] = var353;
                  Object[] var183 = var10008;
                  int var354 = bReturningInt(var183);
                  Color var184 = UiMetrics.r;
                  var357 = var184.getBlue();
                  Color var185 = var53;
                  int var363 = var185.getBlue();
                  Object[] var10009 = new Object[]{null, null, null, var27};
                  var10009[2] = var59;
                  var10009[1] = var363;
                  var10009[0] = var357;
                  Object[] var186 = var10009;
                  Color var60 = new Color(var344, var354, bReturningInt(var186), var58);
                  Color var187 = var53;
                  var344 = var187.getRed();
                  Color var188 = var53;
                  int var355 = var188.getGreen();
                  Color var189 = var53;
                  var357 = var189.getBlue();
                  var363 = (int)(255.0F * var48);
                  var10008 = new Object[]{null, var11};
                  var10008[0] = var363;
                  Object[] var190 = var10008;
                  Color var61 = new Color(var344, var355, var357, aReturningInt(var190));
                  float var373;
                  var10000 = (var373 = var48 - 0.7F) == 0.0F ? 0 : (var373 < 0.0F ? -1 : 1);
                  int var300 = var29;
                  int var299 = var10000;
                  int var234 = var299;
                  int var233 = var299;
                  if (var300 != 0) {
                     int var301 = var233;
                     if (var301 > 0) {
                        Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var13};
                        var10011[8] = 4.0F;
                        var10011[7] = 5;
                        var10011[6] = var311;
                        var10011[5] = var50;
                        var10011[4] = var44;
                        var10011[3] = var54;
                        var10011[2] = var3;
                        var10011[1] = var2;
                        var10011[0] = var6;
                        Object[] var192 = var10011;
                        BlurredRectangleRenderer.eReturningVoid(var192);
                     }

                     Object[] var367 = new Object[]{null, null, null, null, null, null, null, null, null, var23};
                     var367[8] = 4.0F;
                     var367[7] = var60;
                     var367[6] = var311;
                     var367[5] = var50;
                     var367[4] = var44;
                     var367[3] = var54;
                     var367[2] = var3;
                     var367[1] = var2;
                     var367[0] = var6;
                     Object[] var194 = var367;
                     FilledRectangleRenderer.cReturningVoid(var194);
                     MsdfFontManager var337 = Prestige.c;
                     Object[] var196 = new Object[]{var21};
                     MsdfFontManager var195 = var337;
                     MsdfFont var338 = var195.aReturningcx_C0158(var196);
                     float var356 = var54 + 5.5F;
                     float var360 = var44 + 3.0F;
                     var10008 = new Object[]{null, null, null, null, var61, var25};
                     var10008[3] = var360;
                     var10008[2] = var356;
                     var10008[1] = var49;
                     var10008[0] = var3;
                     Object[] var198 = var10008;
                     MsdfFont var197 = var338;
                     var197.v(var198);
                     int var302 = var29;
                     if (var302 == 0) {
                        break label215;
                     }

                     byte var303 = var316;
                     var234 = var303;
                  }

                  int var304 = var234;
                  if (var304 == 0) {
                     break label126;
                  }

                  var44 -= (var311 + 1.0F) * var48;
               }

               int var305 = var29;
               if (var305 != 0) {
                  break label127;
               }
            }

            var44 += (var311 + 1.0F) * var48;
         }

         var45++;
         var306 = var29;
      } while (var306 != 0);
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 140608460609745L ^ var1;
      int var4 = Event.cReturningInt();
      int var12 = var4;
      int var11 = var3;
      int var9 = var11;
      int var8 = var11;
      if (var12 != 0) {
         int var13 = var8;
         if (var13 < 0) {
            return 0;
         }

         var9 = var3;
      }

      short var10001 = 31830;
      long var10002 = 1112689064005037590L ^ var1;
      int var7 = var9;
      return Math.min(var7, 255);
   }

   private static int bReturningInt(Object[] var0) {
      int var5 = (Integer)var0[0];
      int var4 = (Integer)var0[1];
      float var1 = (Float)var0[2];
      long var2 = (Long)var0[3];
      var2 = 140608460609745L ^ var2;
      long var6 = var2 ^ 78421453390309L;
      int var10000 = (int)(var5 + (var4 - var5) * var1);
      Object[] var10003 = new Object[]{null, var6};
      var10003[0] = var10000;
      Object[] var8 = var10003;
      return aReturningInt(var8);
   }

   private static int lambda$renderNew$0(Entry var0, Entry var1) {
      long var10001 = 54013157229755L ^ 101037406500486L;
      var10001 = 54013157229755L ^ 33205163122116L;
      MsdfFontManager var10000 = Prestige.c;
      Object[] var9 = new Object[]{51869363673471L};
      MsdfFontManager var8 = var10000;
      MsdfFont var22 = var8.aReturningcx_C0158(var9);
      Entry var10 = var1;
      Module var11 = (Module)var10.getKey();
      Object[] var13 = new Object[]{var11.bReturningString(), 117628177084989L};
      MsdfFont var12 = var22;
      float var23 = var12.aReturningFloat(var13);
      MsdfFontManager var25 = Prestige.c;
      Object[] var15 = new Object[]{51869363673471L};
      MsdfFontManager var14 = var25;
      MsdfFont var26 = var14.aReturningcx_C0158(var15);
      Entry var16 = var0;
      Module var17 = (Module)var16.getKey();
      Object[] var19 = new Object[]{var17.bReturningString(), 117628177084989L};
      MsdfFont var18 = var26;
      float var21 = var18.aReturningFloat(var19);
      float var20 = var23;
      return Float.compare(var20, var21);
   }

   static {

      {

      b();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(18625034544976L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[2];
      String var26 = "1ÂùÚ3 a^\u0016\u0017U|²ïøWª\u0083oüü Åmð{\b\u0087¯ã\u001d1ñÈQ\u000b¾[Öæ¡>\u0013\u0092\u00ad£\u009c\u001b»Êç\u0004´¹\u0090tãj\n\u0090X¥\u001b  +\u0092 \nôkê6PÖ\u0090\u008a1àÞ\u009a\"îàË§¼\"\u0004\u0082\u0002»/Ü\u0099\u0001\u009a";
      int var28 = "1ÂùÚ3 a^\u0016\u0017U|²ïøWª\u0083oüü Åmð{\b\u0087¯ã\u001d1ñÈQ\u000b¾[Öæ¡>\u0013\u0092\u00ad£\u009c\u001b»Êç\u0004´¹\u0090tãj\n\u0090X¥\u001b  +\u0092 \nôkê6PÖ\u0090\u008a1àÞ\u009a\"îàË§¼\"\u0004\u0082\u0002»/Ü\u0099\u0001\u009a"
         .length();
      char var25 = '@';
      int var24 = -1;

      while (true) {
         byte[] var30 = var22.doFinal(var26.substring(++var24, var24 + var25).getBytes("ISO-8859-1"));
         String var39 = b(var30).intern();
         int var10001 = -1;
         var29[var27++] = var39;
         if ((var24 += var25) >= var28) {
            w = var29;
            x = new String[2];
            D = new HashMap(13);
            Cipher var11;
            var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(18625034544976L << var12 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var17 = new long[3];
            String var15 = "u\u0013×t·*(\u0014YÔÁ~ZöÄ\u008bÁ\u0012\f¡\u009dáÁ\u0012";
            int var16 = "u\u0013×t·*(\u0014YÔÁ~ZöÄ\u008bÁ\u0012\f¡\u009dáÁ\u0012".length();
            do {
               var10001 = var13;
               var13 += 8;
               byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
               var10001 = var14++;
               long var19 = (var18[0] & 255L) << 56
                  | (var18[1] & 255L) << 48
                  | (var18[2] & 255L) << 40
                  | (var18[3] & 255L) << 32
                  | (var18[4] & 255L) << 24
                  | (var18[5] & 255L) << 16
                  | (var18[6] & 255L) << 8
                  | var18[7] & 255L;
               byte[] var21 = var11.doFinal(
                  new byte[]{
                     (byte)(var19 >>> 56),
                     (byte)(var19 >>> 48),
                     (byte)(var19 >>> 40),
                     (byte)(var19 >>> 32),
                     (byte)(var19 >>> 24),
                     (byte)(var19 >>> 16),
                     (byte)(var19 >>> 8),
                     (byte)var19
                  }
               );
               long var10004 = (var21[0] & 255L) << 56
                  | (var21[1] & 255L) << 48
                  | (var21[2] & 255L) << 40
                  | (var21[3] & 255L) << 32
                  | (var21[4] & 255L) << 24
                  | (var21[5] & 255L) << 16
                  | (var21[6] & 255L) << 8
                  | var21[7] & 255L;
               // var17[var10001] = var10004;
            } while (var13 < var16);

            B = var17;
            C = new Integer[3];
            J = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(18625034544976L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[2];
            String var4 = "«&Yv\u0019ÃÂ-ü\u00182\u001d\tQ@ù";
            int var5 = "«&Yv\u0019ÃÂ-ü\u00182\u001d\tQ@ù".length();
            do {
               int var37 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var37, var2).getBytes("ISO-8859-1");
               var37 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var47 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var37] = var47;
            } while (var2 < var5);

            H = var6;
            I = new Long[2];
            i = 0L;
            m = 0.0F;
            break;
         }

         var25 = var26.charAt(var24);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 15565;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b8", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b8",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 20336;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b8", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b8",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 18689;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b8", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b8",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 15;
            yield var15;
         }
         case 1 -> {
            byte var16 = 24;
            yield var16;
         }
         case 2 -> {
            byte var17 = 8;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 16;
            yield var19;
         }
         case 5 -> {
            byte var20 = 28;
            yield var20;
         }
         case 6 -> {
            byte var21 = 34;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 11;
            yield var25;
         }
         case 11 -> {
            byte var26 = 41;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 44;
            yield var28;
         }
         case 14 -> {
            byte var29 = 53;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 12;
            yield var32;
         }
         case 18 -> {
            byte var33 = 58;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 37;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 33;
            yield var38;
         }
         case 24 -> {
            byte var39 = 27;
            yield var39;
         }
         case 25 -> {
            byte var40 = 61;
            yield var40;
         }
         case 26 -> {
            byte var41 = 5;
            yield var41;
         }
         case 27 -> {
            byte var42 = 47;
            yield var42;
         }
         case 28 -> {
            byte var43 = 6;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 30;
            yield var45;
         }
         case 31 -> {
            byte var46 = 14;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 43;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 0;
            yield var50;
         }
         case 36 -> {
            byte var51 = 62;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 20;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 18;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 46;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 57;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 32;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 25;
            yield var65;
         }
         case 51 -> {
            byte var66 = 42;
            yield var66;
         }
         case 52 -> {
            byte var67 = 17;
            yield var67;
         }
         case 53 -> {
            byte var68 = 2;
            yield var68;
         }
         case 54 -> {
            byte var69 = 10;
            yield var69;
         }
         case 55 -> {
            byte var70 = 9;
            yield var70;
         }
         case 56 -> {
            byte var71 = 4;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 19;
            yield var73;
         }
         case 59 -> {
            byte var74 = 40;
            yield var74;
         }
         case 60 -> {
            byte var75 = 39;
            yield var75;
         }
         case 61 -> {
            byte var76 = 7;
            yield var76;
         }
         case 62 -> {
            byte var77 = 26;
            yield var77;
         }
         default -> 1;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "pLYn\"TmY\u0001LcYu_";
      K[1] = int.class;
      L[1] = "java/lang/Integer";
      K[2] = "\\d{:\u0019M\\dlf\u0015BF/lx\u0015WA^>$@\u0015";
      K[3] = "\u0014CFLY\u001f\u001fLW\u0003$\n\rVU@";
      K[4] = long.class;
      L[4] = "java/lang/Long";
      K[5] = "/8{[\b\u001510a\u0014k\u00015}HTR\u0012<";
      K[6] = "}\b]/)sv\u0007L`H}}\fH:";
      K[7] = "\u0016zo\nJ\u0010\u0000zjPY\u0007\u00171iVU\u0013\u0006v~A\u001e\u0003\u001ev|JDN\"m|WD\t\u0015z";
      K[8] = "\u001eU9SJf\bU<\tYq\u001f\u001e?\u000fUe\u000eY(\u0018\u001eu\u0000";
      K[9] = "-EnUyO-Ey\tu@7\u000ey\u0017uU0\u007f)J$";
      K[10] = ":\u001c\"6|d:\u001c5jpk W5tp~'&b+&";
      K[11] = "/\rA\naF1\u0005[E\u0003Z6\u0018";
      K[12] = "TC?d\u001aBJK%+wXSR(wUCQP";
      K[13] = void.class;
      L[13] = "java/lang/Void";
      K[14] = ")\f[=_27\u0004Ar83&\u001fL(\u001e5";
      K[15] = "CNE[\t[HAT\u0014eXFCV[I";
      K[16] = "`6C\u0007dhk9RH\u0006kd0";
      K[17] = "U\ni;{\nC\nlah\u001dTAogd\tE\u0006xp/\u0018\u0000";
      K[18] = "\u0019,\u000bC+rl\f\u0000L:=\r\u0002\u000bG>gy";
      K[19] = "8\u0001\\\r\u0015\b.\u0001YW\u0006\u001f9JZQ\n\u000b(\rMFA\u001b\u001b";
      K[20] = "ZYzwHzLY\u007f-[m[\u0012|+WyJUk<\u001ciF";
      K[21] = "\u0013\r\u001fx\u000f.f-\u0014w\u001ea\u0007#\u001f|\u001a;s";
      K[22] = float.class;
      L[22] = "java/lang/Float";
      K[23] = "S\u0010[Q`-E\u0010^\u000bs:R[]\r\u007f.C\u001cJ\u001a4?\u000f";
      K[24] = "P-\u0005\u001aai[\"\u0014U\u0002dN/\u001b>7f_<\u0007\u0012 k";
      K[25] = "$TV\u0004 XQt]\u000b1\u00170zV\u00005MD";
      K[26] = boolean.class;
      L[26] = "java/lang/Boolean";
      K[27] = "X1ff5G-\u0011mi$\bL\u001ffb R8";
      K[28] = "\u0016\f\fxd\u0019\b\u0004\u00167\u0019\t\b";
      K[29] = "T\b\u0002\u001eB$_\u0007\u0013Q*$Q\b\u0000";
      K[30] = "9E*+)H/E/q:_8\u000e,w6K)I;`}Y\u001f";
      K[31] = "HY\u0018\u000b25=y\u0013\u0004#z\\w\u0018\u000f' (";
      K[32] = "\u0012s0\u0015\u00074\u0004s5O\u0014#\u001386I\u00187\u0002\u007f!^S'O";
      K[33] = "V`o[\u0011h#@dT\u0000'BNo_\u0004}6";
      K[34] = "l\n+|t\u0018\u0019* seWx$+xa\r\f";
      K[35] = "\u0013MflnH\u0005Mc6}_\u0012\u0006`0qK\u0003Aw':Y2";
      K[36] = "I\u001cZ\u000e[\u0019<<Q\u0001JV]2Z\nN\f)";
      K[37] = "\u001es\trV\u0011\bs\f(E\u0006\u001f8\u000f.I\u0012\u000e\u007f\u00189\u0002\u0005+";
      K[38] = "q\r#T{kz\u00022\u001b\u0006si\u0005;R";
      K[39] = "/[\u001bF*\u000f1S\u0001\tI\u001b5";
      K[40] = "\u001d{\u00186U*h[\u00139De\tU\u00182@?}";
      K[41] = "U6&\u000b/\u000e^97DL\u0003K?";
      K[42] = "3\u0002}kQ&F\"vd@i',}oD3S";
      K[43] = "/B\u0000\u0000\u0005G9B\u0005Z\u0016P.\t\u0006\\\u001aD?N\u0011KQT ";
      K[44] = ";hJ+kKNHA$z\u0004/FJ/~^[";
      K[45] = "\u0003^z\u001e\"Iv~q\u00113\u0006\u0017pz\u001a7\\c";
      K[46] = "\u0018E?\u0011fCme4\u001ew\f\fk?\u0015sVx";
      K[47] = "\r\u0004\u0014,2*\u001b\u0004\u0011v!=\fO\u0012p-)\u001d\b\u0005gf>\u001e";
      K[48] = "0\u0012\u0019\fd\u001fE2\u0012\u0003uP$<\u0019\bq\nP";
      K[49] = "\u001fnny\u0011\u001b\tnk#\u0002\f\u001e%h%\u000e\u0018\u000fb\u007f2E\u000f\u001d";
      K[50] = "\u001a,\u0003o\u000fxo\f\b`\u001e7\u000e\u0002\u0003k\u001amz";
      K[51] = "BK!h(|7k*g93Ve!l=i\"";
      K[52] = "yD\u001a[\u007fWz\u0002\u001b'+\u0002k4\u0013_$\u0006\u0017\u0001\u0013H>Qg\u0011KVD";
      K[53] = "Z-'My\u001d\u0005,)A\u001d@\u000e3y\u001aqr_r!G\u001dY\u0007 cCmI_>\u0019";
      K[54] = "\u0016,'<6IOn'g\f\u001bQj82j\fpq'2I\u0011Ht#$\fJR|<niJ\u0017n)_";
      K[55] = "[lsO,#\u001853\u0010P#\rw\u000eF!L\\5/\u00124=\u001ce2UP";
      K[56] = "cQ\u001b&R3>T[:c=_\u0011\u0017~\u000eg%\u0015\\'\u0007";
      K[57] = "P49w\r\u0002\f/\"-a\u0014\u000f&#*6CQvzF^B\u0015+v|\u0011\u0015\n,";
      K[58] = "[\u0016r\u0006\u000e\u001a[Lg_7X\fSj>\u0007@TYdG\u000e\u001e\tO\u0016\u000fV]VK\u007f^LCP)";
      K[59] = "co0rR@c5%+k\u0018/=.#\u0017\u001e)P=u\u0012\u001dc:dr\u000f@S";
      K[60] = "!q@\u0018);sl\n\u0011Y\u0014\u0001T!'Y3)*\b\u001a8a4`\u0001";
      K[61] = "wRM?xteR\u0015(G{z\u0004\u001c\u000b.{`\u000fso9scS\u0016o|avb";
      K[62] = "h9\\Q\u007f:i4\u001dM\u000e \u0003&^K1>x;[\\iA25^\u0013l(c/@\u0015\u000e";
      K[63] = "\u001a*\u0004\\7S\u001fu^\tNHvy\u0006\u0007v\u0018Oy\\\u0012/!";
      K[64] = "~Z\u0019\b1B']\u0004U\u0001Nz\u0015\u001cl=\u0016u\\\u0004\u001d}Fh\u001b`";
      K[65] = "4D\u0013\u0006Cl8]YV$j0F\u0019\u000e^lWM\u0003\u001aCl7N\u0003\u001bD\u00019A\u001c\u0000Ia:A\u001d\u0007$}3L\u001bYTmkRa";
      K[66] = "a{V0<\u0017`~@3]F\fcC*bPw~F=:/bs@(0OasA/]";
      K[67] = "\nrLwVMViW-:PYqR!Vb\u000e7\fv\u00015\ro\fv^\rRn\u0002z:";
      K[68] = "IiW:-DJ/VFy\u0011[\nW*\u0016\u0000C?@xf\u0010\u001b!:";
      K[69] = "\u001d\u001c+z\u007fS\u001bEhv\r@rO)w\u007fD\u0015L>|m)\u001d^7e`N\u001eI<w\r";
      K[70] = "1\u0006[\u0002\u0000j0\u000b\u001a\u001eq}Z\u0019Y\u0018Nn!\u0004\\\u000f\u0016\u0011;Z]\u0019\u0011r!\u001bD\u0004q";
      K[71] = "\u0011>\u00162c7\u00103W.\u0012'z!\u0014(-3\u0001<\u0011?uL\u001bb\u0010)r/\u0001#\t4\u0012";
      K[72] = "$cnVX_/td\u0010:\u0000:\u007fsFF\u0006<\u0012`\u0010C\u0005vx9\u0017^XF";
      K[73] = "Jg\u001doEtKj\\s4f!x\u001fu\u000bpZe\u001abS\u000f\u0010k\u001f-VfAq\u0001+4";
      K[74] = "Cv\u0011\u0014\u0013tC,\u0004M*\"\u001e5uPN\"\tw\u0005@\u0016<suKN\u0013)\u00025\u001bSTM";
      K[75] = "\u0003\nr/xb\u000f\u00138\u007f\u001fq\t\t}#Xa`\u0003b3xb\u0000\u0000b2\u007f\u000f\u0003\nr/xb\u000f\u00138\u007f\u001f";
      K[76] = "<\u0017\nCI\u007f:[LA5|XTJT\ni#IOCR\u00166DIVXv5DHQ5";
      K[77] = "Fe\u001b\u0004\u0014sXx\u000f\u001b(g#n\u001b\u001d\u0017uXs\u001e\nO\n\u0012}\u001bEJcCg\u0005C(";
      K[78] = "\u0001c#\u001d#!\u0000f5\u001eBrl{6\u0007}f\u0017f3\u0010%\u0019\u0002k5\u0005/y\u0001k4\u0002B";
      K[79] = "#SQrQS \u0015P\u000e\u0005\u00061%Fc\u0007\rM\u0016Xa\u0010U=\u0006\u0000\u007fj";
      K[80] = "K\u0002\u0012\u0014\u0017\r\u0019\u001fX\u001dg\u0012K\u0007U\u000b \u0002\"\u0002\u0019\u001c\u0003\fA\u0018X\u0005\u001elK\u0002\u0012\u0014\u0017\r\u0019\u001fX\u001dg";
      K[81] = "u!!q\u001bL+'>-y\u001e\u0012?4&\u0003Jb/l8y";
      K[82] = "\u001aA_|2\u000f\bA\u0007k\r\u001a\u0019\u0015\u001c{J\npK\u001fzsU\u0015KZhfd\u001aA_|2\u000f\bA\u0007k\r";
      K[83] = "\u0017\u0011\u001foleI\u0017\u00003\u000e6p\u000f\n8tc\u0000\u001fR&\u000e";
      K[84] = "\u0017R^Q\u0014y\u0011\u000b\u001d]fix\u001c\\YY|\u0003\u0001YN\u0001\u0003\u0004\nMFXs\u0014RS<";
      K[85] = "o$~nZk2!>rkbS5c4Tw!0<n\u0001";
      K[86] = "Ca\u001b}b\u000f\u001af\u0006 R\u0005C%$t\"\u0019*?Sc6\u0005I%\u0012z+e";
      K[87] = "&-#\t@:2)<\u0001p ^(.T\u0013s!41\u0014AJ";
      K[88] = "{FdDR\u0014{\u001cq\u001dkL04e\u0004\u0017\\K\u00181\u0006\u000fM(\u0002p\u001f\u0012-";
      K[89] = "\u0000A-Na2\u0010\u0004\u007f\nP%\u001aY\u0011\f4/\u0001\u0001a\u001cl1{Cu\u001f*~\u000bS-\u0001P<\u001fPkN ,GN\u0011";
      K[90] = "\u0001]yk\u00044\u0001Z3`?#\u001d\u001c9\u007fd#\u0007`!\u007fX7\u0019^*hRq{";
      K[91] = "\\\u0007b\\,\u0001\\\u0000(W\u0017\u0014KF\u001fC[\u0016HS%]k{\u001a\u0004:\u0000s\nZT'G\u0017G\u0018Xa]f\u0007HE&9+ED\u0003<Hk\u0015YDX";
      K[92] = "oYH\u0013\u0004\u0013=D\u0002\u001at\u001f\u007fE\u001b\u0005\u000fr:\u0006\u0010X\u0010\u0003zV\r\u001ft\u00137B\u0016\u0001\u0017\tv[\u000ba";
      K[93] = "6\u0000DK'\u00180L\u0002I[\u001dRC\u0004\\d\u000e)^\u0001K<q<\b\u0017E`I?N\u00169";
      K[94] = "I9\u0004\u0006L=Y|VB}*[78V\u001f2U*XU\u001f3RGVZ\u0000(_'UZ\u0001/2)ZE\u001a\"R*ZD\u001dO";
      K[95] = ".&\u0011C\u000e9-`\u0010?Zl<U\u0018BX\u0001<{\u0013E\u000bq,#\r?";
      K[96] = "SOs})zW\u0004*t\u0018inO2u'\u007f\u0015R7b\u007f\u0000\u0003W'oy8\u0002R1l\u0018";
      K[97] = "J_P0Fc\u0007X\u001a}+j7\u0017_%\u0014|L\nZ2L\u0003Y\u0007\\'FcZ\u0007] +";
      K[98] = "\u0013\u0014>\\\b{\u0015M}Pzh|Z<TE~\u0007G9C\u001d\u0001\u0000L-KDq\u0010\u001431";
      K[99] = "npHwcPn*].Z\u00002#,sd\u000bg+]34\u0016 OM~ \r>,W?9\u0010^";
      K[100] = "wu)9\u00149w/<`-{&8 \u0001Qd(0sqA<6J";
      K[101] = "M[0se\u001dY_/{U\u00045Fnj1\rV\\/s,m";
      K[102] = "\u0012WhXS2\u0013R~[2t\u007fO}B\ru\u0004RxUU\nN\\}\u001aPc\u001fFc\u001c2";
      K[103] = "j}6y\u0010\u0004fd|)w\u0007m}-d)\u0000mg)\u0018\u0019\u000bt})x\u001a\u000buzD";
      K[104] = "\u0000{\u0012z6UC\"R%JUV`rw.GV\u001c\u0010 (\u0003_mPp5D;";
      K[105] = "*z#3:\u000ej=k?\\_Z3lkcJ!.i|;54x\u007frg\r7>~\u000e";
      K[106] = "/\u001eRI\u0017K;_V\u0018.F^RBA\u0011R%OGVI-oAB\u0019LD>[\\\u001f.";
      K[107] = "(^\u0013x{9w_\u001dt\u001fd|@M/sV-\u0000\u001dv\u001f}uSWvom-M-";
      K[108] = "(Q\u001eAmw(VTJVu/\u0010$\u0018hok\bUX8r,l\u0018\u001a446\u001dXJ)sRP\u001aFoi#\u0010J[(\r";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(424658910288847L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(424658910288847L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(424658910288847L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 114;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 79;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 251;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 232;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 83;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 192;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 114;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 79;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 251;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b8",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b8" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Comparator invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "compare",
                  SourceSupport.methodType("()Ljava/util/Comparator;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)I", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/b8", "lambda$renderNew$0", "(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I"
                  ),
                  SourceSupport.methodType("(Ljava/util/Map$Entry;Ljava/util/Map$Entry;)I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Comparator)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
