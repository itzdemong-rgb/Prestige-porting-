package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.Notification;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.client.ui.NotificationTypeSwitchMap;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.module.Module;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;

public class ModuleNotificationsWidget extends HudElement {
   public static ModuleNotificationsWidget a;
   private static final long c;
   private static final int d;
   private static final float m = 10.0F;
   private static final float i = 90.0F;
   private static final float j = 12.0F;
   private final ArrayList k;
   private final Map l;
   private long n;
   private float o;
   private float p;
   private static final long v = 105555079518017L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[113];
   private static final String[] L = new String[113];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public ModuleNotificationsWidget(long var1) {
      super("Module Notifications", "Draws module notifications when toggled.", ((105555079518017L ^ (105555079518017L ^ var1)) ^ 11043758663013L));
      var1 = 105555079518017L ^ var1;
      long var3 = var1 ^ 11043758663013L;
      short var10001 = 16703;
      long var10002 = 7946170942033804117L ^ var1;
      short var6 = 14959;
      long var10003 = 9103324530205769735L ^ var1;

      this.k = new ArrayList();
      this.l = new HashMap();
      this.n = invokeBinding1(20565, 3626748100130197379L ^ var1);
      this.o = 0.0F;
      this.p = 0.0F;
      a = this;
   }

   public static void r(Object[] var0) {
      Module var1 = (Module)var0[0];
      long var2 = (Long)var0[1];
      var2 = 105555079518017L ^ var2;
      long var4 = var2 ^ 15858902392713L;
      long var6 = var2 ^ 66701984120559L;
      int var8 = Event.bReturningInt();
      ModuleNotificationsWidget var10000 = a;
      Object[] var10 = new Object[]{var6};
      ModuleNotificationsWidget var9 = var10000;
      boolean var28 = var9.eReturningBoolean(var10);
      int var23 = var8;
      boolean var22 = var28;
      boolean var21 = var22;
      boolean var20 = var22;
      if (var23 == 0) {
         boolean var24 = var20;
         if (!var24) {
            return;
         }

         Module var12 = var1;
         var21 = var12.aReturningBoolean();
      }

      boolean var25 = var21;
      if (var25) {
         var10000 = a;
         Module var13 = var1;
         String var10001 = var13.bReturningString();
         short var10002 = 24187;
         long var10003 = 8720824814853743338L ^ var2;
         Object[] var15 = new Object[]{var10001, "Has been enabled.", NotificationType.SUCCESS, var4};
         ModuleNotificationsWidget var14 = var10000;
         var14.t(var15);
         int var26 = var8;
         if (var26 == 0) {
            return;
         }
      }

      var10000 = a;
      Module var17 = var1;
      String var31 = var17.bReturningString();
      short var32 = 16623;
      long var33 = 6846522694511033469L ^ var2;
      Object[] var19 = new Object[]{var31, "Has been disabled.", NotificationType.ERROR, var4};
      ModuleNotificationsWidget var18 = var10000;
      var18.t(var19);
   }

   public static void s(Object[] var0) {
      Module var2 = (Module)var0[0];
      String var1 = (String)var0[1];
      NotificationType var3 = (NotificationType)var0[2];
      long var4 = (Long)var0[3];
      var4 = 105555079518017L ^ var4;
      long var6 = var4 ^ 6630557303307L;
      long var8 = var4 ^ 58007697007469L;
      int var10 = Event.cReturningInt();
      int var21 = var10;
      ModuleNotificationsWidget var20 = a;
      ModuleNotificationsWidget var19 = var20;
      ModuleNotificationsWidget var18 = var20;
      if (var21 != 0) {
         Object[] var12 = new Object[]{var8};
         ModuleNotificationsWidget var11 = var18;
         boolean var22 = var11.eReturningBoolean(var12);
         if (!var22) {
            return;
         }

         var19 = a;
      }

      Module var15 = var2;
      Object[] var17 = new Object[]{var15.bReturningString(), var1, var3, var6};
      ModuleNotificationsWidget var16 = var19;
      var16.t(var17);
   }

   private void t(Object[] var1) {
      String var6 = (String)var1[0];
      String var5 = (String)var1[1];
      NotificationType var4 = (NotificationType)var1[2];
      long var2 = (Long)var1[3];
      var2 = 105555079518017L ^ var2;
      long var7 = var2 ^ 98219072025078L;
      int var10000 = Event.cReturningInt();
      ArrayList var12 = this.k;
      Iterator var10 = var12.iterator();
      int var9 = var10000;

      while (true) {
         Iterator var13 = var10;
         boolean var31 = var13.hasNext();
         if (var31) {
            Iterator var14 = var10;
            Notification var11 = (Notification)var14.next();
            String var16 = var6;
            String var15 = var11.recoveryAccess_read_a();
            boolean var45 = var15.equals(var16);
            int var33 = var9;
            boolean var32 = var45;
            boolean var23 = var32;
            if (var33 == 0) {
               break;
            }

            label33: {
               Notification var29;
               label43: {
                  int var35 = var9;
                  boolean var34 = var23;
                  boolean var28 = var34;
                  boolean var24 = var34;
                  if (var35 != 0) {
                     boolean var36 = var24;
                     boolean var25 = var36;
                     boolean var37 = var25;
                     if (!var37) {
                        break label33;
                     }

                     int var39 = var9;
                     Notification var38 = var11;
                     var29 = var38;
                     Notification var26 = var38;
                     if (var39 == 0) {
                        break label43;
                     }

                     Notification var40 = var26;
                     Notification var27 = var40;
                     boolean var41 = var27.recoveryAccess_read_f();
                     var28 = var41;
                  }

                  boolean var42 = var28;
                  if (var42) {
                     break label33;
                  }

                  var29 = var11;
               }

               var29.recoveryAccess_write_f(dev.prestige.recovery.SourceSupport.asBoolean(1));
            }

            int var43 = var9;
            if (var43 != 0) {
               continue;
            }
         }

         ArrayList var46 = this.k;
         Notification var22 = new Notification(var6, var5, var4, var7);
         ArrayList var21 = var46;
         boolean var30 = var21.add(var22);
         break;
      }
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var4;
      label17: {
         long var2 = (Long)var1[0];
         var4 = var2 ^ 101393985901669L;
         long var6 = var2 ^ 20883324854464L;
         int var8 = Event.bReturningInt();
         MinecraftClient var11 = b;
         Window var10000 = var11.getWindow();
         int var27 = var8;
         Window var26 = var10000;
         Window var25 = var26;
         Window var24 = var26;
         if (var27 == 0) {
            Window var28 = var24;
            if (var28 == null) {
               break label17;
            }

            MinecraftClient var13 = b;
            Window var29 = var13.getWindow();
            var25 = var29;
         }

         Window var15 = var25;
         float var31 = var15.getFramebufferWidth();
         Object[] var16 = new Object[]{var6};
         float var9 = var31 / HudEditorScreen.bReturningFloat(var16);
         MinecraftClient var17 = b;
         Window var18 = var17.getWindow();
         float var32 = var18.getFramebufferHeight();
         Object[] var19 = new Object[]{var6};
         float var10 = var32 / HudEditorScreen.bReturningFloat(var19);
         float var10001 = var9 - 90.0F - 4.0F;
         float var10002 = var10 - 70.0F;
         Object[] var10005 = new Object[]{null, null, var4};
         var10005[1] = var10002;
         var10005[0] = var10001;
         Object[] var21 = var10005;
         ModuleNotificationsWidget var20 = this;
         var20.aReturningVoid(var21);
         int var30 = var8;
         if (var30 == 0) {
            return;
         }
      }

      Object[] var33 = new Object[]{null, null, var4};
      var33[1] = 150.0F;
      var33[0] = 200.0F;
      Object[] var23 = var33;
      ModuleNotificationsWidget var22 = this;
      var22.aReturningVoid(var23);
   }

   @Override
   public void q(Object[] var1) {
      Matrix4f var4;
      long var5;
      ModuleNotificationsWidget var12;
      label26: {
         var4 = (Matrix4f)var1[0];
         long var2 = (Long)var1[1];
         var5 = var2 ^ 0L;
         int var7 = Event.cReturningInt();
         float var21;
         int var10000 = (var21 = this.g - 0.0F) == 0.0F ? 0 : (var21 < 0.0F ? -1 : 1);
         int var14 = var7;
         int var13 = var10000;
         int var11 = var13;
         int var8 = var13;
         if (var14 != 0) {
            int var15 = var8;
            if (var15 <= 0) {
               return;
            }

            int var17 = var7;
            ModuleNotificationsWidget var16 = this;
            var12 = var16;
            ModuleNotificationsWidget var9 = var16;
            if (var17 == 0) {
               break label26;
            }

            ModuleNotificationsWidget var18 = var9;
            ModuleNotificationsWidget var10 = var18;
            float var22;
            int var19 = (var22 = var10.h - 0.0F) == 0.0F ? 0 : (var22 < 0.0F ? -1 : 1);
            var11 = var19;
         }

         int var20 = var11;
         if (var20 <= 0) {
            return;
         }

         var12 = this;
      }

      var12.q(new Object[]{var4, var5});
   }

   
   @Override
   public void lReturningVoid(Object[] var1) {
      java.util.ArrayList var382;

      long var2;
      RenderContext var4;
      MeshBufferManager var5;
      Matrix4f var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      long var33;
      long var35;
      long var37;
      long var39;
      int var41;
      long var42;
      float var213;
      label314: {
         var5 = (MeshBufferManager)var1[0];
         var4 = (RenderContext)var1[1];
         var6 = (Matrix4f)var1[2];
         var2 = (Long)var1[3];
         var7 = var2 ^ 50051124971157L;
         var9 = var2 ^ 48887442607471L;
         var11 = var2 ^ 68792269758944L;
         var13 = var2 ^ 13608202459885L;
         var15 = var2 ^ 21455495630540L;
         var17 = var2 ^ 29307267718371L;
         var19 = var2 ^ 113406911627307L;
         var21 = var2 ^ 17083579563515L;
         var23 = var2 ^ 4527834288712L;
         var25 = var2 ^ 55292252235716L;
         var27 = var2 ^ 73179937689918L;
         var29 = var2 ^ 49928519994039L;
         var31 = var2 ^ 41197988814736L;
         var33 = var2 ^ 124694493719688L;
         var35 = var2 ^ 81054074941871L;
         var37 = var2 ^ 16139628387067L;
         var39 = var2 ^ 64495915607067L;
         int var10000 = Event.cReturningInt();
         var42 = System.currentTimeMillis();
         var41 = var10000;
         long var403 = this.n;
         long var10001 = invokeBinding2(6828, 1422961376592114806L ^ var2);
         int var276 = var41;
         long var274 = var10001;
         long var272 = var403;
         long var209 = var272;
         long var211 = var274;
         long var205 = var272;
         long var207 = var274;
         if (var276 != 0) {
            long var465;
            int var277 = (var465 = var205 - var207) == 0L ? 0 : (var465 < 0L ? -1 : 1);
            if (!((var277) != 0)) {
               float var278 = 0.0F;
               var213 = var278;
               break label314;
            }

            var211 = this.n;
            var209 = var42;
         }

         var213 = (float)(var209 - var211) * 0.005F;
      }

      float var44 = var213;
      this.n = var42;
      MinecraftClient var81 = b;
      byte var45 = ((byte)((var81.currentScreen instanceof HudEditorScreen) ? 1 : 0));
      ArrayList var82 = this.k;
      Iterator var46 = var82.iterator();

      byte var237;
      while (true) {
         Iterator var83 = var46;
         boolean var279 = var83.hasNext();
         if (var279) {
            Iterator var84 = var46;
            Notification var47 = (Notification)var84.next();
            int var281 = var41;
            Notification var280 = var47;
            Notification var217 = var280;
            Notification var214 = var280;
            if (var281 != 0) {
               int var283 = var41;
               byte var282 = ((byte)((var214.recoveryAccess_read_f()) ? 1 : 0));
               var237 = var282;
               byte var215 = var282;
               if (var283 == 0) {
                  break;
               }

               byte var284 = var215;
               byte var216 = var284;
               byte var285 = var216;
               if (var285 == 0) {
                  long var466;
                  int var286 = (var466 = var42 - var47.recoveryAccess_read_d() - invokeBinding3(28920, 6371097278011563553L ^ var2)) == 0L ? 0 : (var466 < 0L ? -1 : 1);
                  if (var286 >= 0) {
                     var47.recoveryAccess_write_f(true);
                  }
               }

               var217 = var47;
            }

            boolean var289 = var47.recoveryAccess_read_f();
            float var288 = var47.recoveryAccess_read_e();
            Notification var287 = var217;
            Notification var220 = var287;
            float var221 = var288;
            Notification var218 = var287;
            float var219 = var288;
            Notification var222;
            float var223;
            float var224;
            if (var289) {
               float var292 = 0.0F;
               float var291 = var219;
               Notification var290 = var218;
               var222 = var290;
               var223 = var291;
               var224 = var292;
            } else {
               var224 = 1.0F;
               var223 = var221;
               var222 = var220;
            }

            boolean var296 = var47.recoveryAccess_read_f();
            float var295 = var224;
            float var294 = var223;
            Notification var293 = var222;
            Notification var228 = var293;
            float var229 = var294;
            float var230 = var295;
            Notification var225 = var293;
            float var226 = var294;
            float var227 = var295;
            Notification var231;
            float var232;
            float var233;
            float var234;
            if (var296) {
               float var300 = var44 * 2.0F;
               float var299 = var227;
               float var298 = var226;
               Notification var297 = var225;
               var231 = var297;
               var232 = var298;
               var233 = var299;
               var234 = var300;
            } else {
               var234 = var44;
               var233 = var230;
               var232 = var229;
               var231 = var228;
            }

            label300: {
               Object[] var10006 = new Object[]{null, null, null, var31};
               var10006[2] = var234;
               var10006[1] = var233;
               var10006[0] = var232;
               Object[] var91 = var10006;
               var231.recoveryAccess_write_e(ClientUiUtil.bReturningFloat(var91));
               int var302 = var41;
               byte var301 = ((byte)((var47.recoveryAccess_read_f()) ? 1 : 0));
               int var236 = var301;
               byte var235 = var301;
               if (var302 != 0) {
                  byte var303 = var235;
                  if (var303 == 0) {
                     break label300;
                  }

                  float var467;
                  int var304 = (var467 = var47.recoveryAccess_read_e() - 0.01F) == 0.0F ? 0 : (var467 < 0.0F ? -1 : 1);
                  var236 = var304;
               }

               int var305 = var236;
               if (var305 <= 0) {
                  Iterator var94 = var46;
                  var94.remove();
               }
            }

            int var306 = var41;
            if (var306 != 0) {
               continue;
            }
         }

         var237 = 0;
         break;
      }

      int var381 = var237;
      ArrayList var96 = this.k;
      Iterator var48 = var96.iterator();

      label289:
      while (true) {
         Iterator var97 = var48;
         boolean var307 = var97.hasNext();
         if (var307) {
            Iterator var98 = var48;
            Notification var49 = (Notification)var98.next();
            int var309 = var41;
            boolean var308 = var49.recoveryAccess_read_f();
            boolean var239 = var308;
            boolean var238 = var308;
            if (var309 != 0) {
               boolean var310 = var238;
               if (!var310) {
                  var381++;
               }

               int var311 = var41;
               if (var311 != 0) {
                  continue;
               }

               ArrayList var100 = this.k;
               var48 = var100.iterator();
               Iterator var101 = var48;
               var239 = var101.hasNext();
               boolean var312 = var239;
               if (!var312) {
                  break;
               }
            } else {
               boolean var397 = var239;
               if (!var397) {
                  break;
               }
            }
         } else {
            ArrayList var388 = this.k;
            var48 = var388.iterator();
            Iterator var389 = var48;
            boolean var392 = var389.hasNext();
            boolean var398 = var392;
            if (!var398) {
               break;
            }
         }

         while (true) {
            Iterator var102 = var48;
            Notification var383 = (Notification)var102.next();
            int var314 = var41;
            int var313 = var381;
            int var242 = var313;
            int var240 = var313;
            if (var314 != 0) {
               byte var316 = 5;
               int var315 = var240;
               if (var315 <= var316) {
                  break label289;
               }

               int var318 = var41;
               Notification var317 = var383;
               Notification var243 = var317;
               Notification var241 = var317;
               if (var318 != 0) {
                  boolean var319 = var241.recoveryAccess_read_f();
                  boolean var394 = var319;
                  boolean var320 = var394;
                  if (!var320) {
                     var243 = var383;
                     var243.recoveryAccess_write_f(true);
                     var381--;
                  }

                  int var321 = var41;
                  if (var321 == 0) {
                     break label289;
                  }
               } else {
                  var243.recoveryAccess_write_f(true);
                  var381--;
                  int var401 = var41;
                  if (var401 == 0) {
                     break label289;
                  }
               }
            } else {
               int var400 = var242;
               if (var400 == 0) {
                  Notification var396 = var383;
                  var396.recoveryAccess_write_f(true);
                  var381--;
               }

               int var402 = var41;
               if (var402 == 0) {
                  break label289;
               }
            }

            Iterator var390 = var48;
            boolean var393 = var390.hasNext();
            boolean var399 = var393;
            if (!var399) {
               break label289;
            }
         }
      }

      byte var247;
      var382 = new ArrayList(this.k);
      int var323 = var41;
      byte var322 = var45;
      var247 = var322;
      byte var244 = var322;
      label242:
      if (var323 != 0) {
         byte var324 = var244;
         if (var324 != 0) {
            ArrayList var107 = var382;
            byte var404 = ((byte)((var107.isEmpty()) ? 1 : 0));
            int var326 = var41;
            byte var325 = var404;
            var247 = var325;
            byte var245 = var325;
            if (var326 == 0) {
               break label242;
            }

            byte var327 = var245;
            byte var246 = var327;
            byte var328 = var246;
            if (var328 != 0) {
               short var10002 = 13690;
               long var10003 = 1090725803663097374L ^ var2;
               short var434 = 28104;
               long var10004 = 5829053840984417966L ^ var2;
               Notification var384 = new Notification("Module Notifications", "Toasts appear here.", NotificationType.SUCCESS, var15);
               var384.recoveryAccess_write_e(1.0F);
               Notification var111 = var384;
               ArrayList var110 = var382;
               var110.add(var111);
            }
         }

         ArrayList var112 = var382;
         var247 = ((byte)((var112.isEmpty()) ? 1 : 0));
      }

      int var330 = var41;
      byte var329 = var247;
      int var249 = var329;
      byte var248 = var329;
      if (var330 != 0) {
         byte var331 = var248;
         if (var331 != 0) {
            Object[] var452 = new Object[]{null, 0.0F};
            var452[0] = 0.0F;
            Object[] var115 = var452;
            ModuleNotificationsWidget var114 = this;
            var114.iReturningVoid(var115);
            this.o = 0.0F;
            this.p = 0.0F;
            return;
         }

         MinecraftClient var117 = b;
         Window var118 = var117.getWindow();
         var249 = var118.getFramebufferWidth();
      }

      float var405 = var249;
      Object[] var119 = new Object[]{var23};
      var405 /= HudEditorScreen.bReturningFloat(var119);
      MinecraftClient var120 = b;
      Window var121 = var120.getWindow();
      var405 = var121.getFramebufferHeight();
      Object[] var122 = new Object[]{var23};
      var405 /= HudEditorScreen.bReturningFloat(var122);
      Object[] var124 = new Object[0];
      ModuleNotificationsWidget var123 = this;
      byte var51 = ((byte)((var123.cReturningBoolean(var124)) ? 1 : 0));
      Object[] var126 = new Object[0];
      ModuleNotificationsWidget var125 = this;
      byte var52 = ((byte)((var125.dReturningBoolean(var126)) ? 1 : 0));
      MsdfFontManager var409 = Prestige.c;
      Object[] var128 = new Object[]{var13};
      MsdfFontManager var127 = var409;
      MsdfFont var410 = var127.aReturningcx_C0158(var128);
      Object[] var130 = new Object[]{var29};
      MsdfFont var129 = var410;
      float var53 = var129.cReturningFloat(var130);
      float var54 = var53 * 1.65F + 6.0F;
      float var55 = 0.0F;
      float var56 = 0.0F;
      ArrayList var131 = var382;
      Iterator var57 = var131.iterator();

      float var262;
      label234: {
         ModuleNotificationsWidget var261;
         label323: {
            int var260;
            label232: {
               while (true) {
                  Iterator var132 = var57;
                  boolean var332 = var132.hasNext();
                  if (var332) {
                     Iterator var133 = var57;
                     Notification var58 = (Notification)var133.next();
                     Object[] var135 = new Object[]{var58, var25};
                     ModuleNotificationsWidget var134 = this;
                     float var137 = var134.cReturningFloat(var135);
                     float var136 = var55;
                     var55 = Math.max(var136, var137);
                     var56 += (var54 + 3.0F) * var58.recoveryAccess_read_e();
                     int var333 = var41;
                     if (var333 == 0) {
                        break;
                     }

                     int var334 = var41;
                     if (var334 != 0) {
                        continue;
                     }
                  }

                  int var336 = var41;
                  byte var335 = var45;
                  var260 = var335;
                  byte var250 = var335;
                  if (var336 == 0) {
                     break label232;
                  }

                  byte var337 = var250;
                  if (var337 == 0) {
                     int var255;
                     int var339 = var41;
                     byte var338 = var52;
                     var255 = var338;
                     byte var251 = var338;
                     label221:
                     if (var339 != 0) {
                        byte var340 = var251;
                        byte var252 = var340;
                        byte var341 = var252;
                        if (var341 != 0) {
                           float var468;
                           int var411 = (var468 = this.o - 0.0F) == 0.0F ? 0 : (var468 < 0.0F ? -1 : 1);
                           int var343 = var41;
                           int var342 = var411;
                           var255 = var342;
                           int var253 = var342;
                           if (var343 == 0) {
                              break label221;
                           }

                           int var344 = var253;
                           int var254 = var344;
                           int var345 = var254;
                           if (var345 > 0) {
                              this.f = this.f - (var56 - this.o);
                           }
                        }

                        var255 = var51;
                     }

                     int var347 = var41;
                     int var346 = var255;
                     var260 = var346;
                     int var256 = var346;
                     if (var347 == 0) {
                        break label232;
                     }

                     int var348 = var256;
                     if (var348 != 0) {
                        float var469;
                        int var412 = (var469 = this.p - 0.0F) == 0.0F ? 0 : (var469 < 0.0F ? -1 : 1);
                        int var350 = var41;
                        int var349 = var412;
                        var260 = var349;
                        int var257 = var349;
                        if (var350 == 0) {
                           break label232;
                        }

                        int var351 = var257;
                        int var258 = var351;
                        int var352 = var258;
                        if (var352 > 0) {
                           this.e = this.e - (var55 - this.p);
                        }
                     }
                  }

                  this.o = var56;
                  this.p = var55;
                  int var354 = var41;
                  ModuleNotificationsWidget var353 = this;
                  var261 = var353;
                  ModuleNotificationsWidget var259 = var353;
                  if (var354 == 0) {
                     break label323;
                  }

                  Object[] var441 = new Object[]{null, var56};
                  var441[0] = var55;
                  Object[] var150 = var441;
                  ModuleNotificationsWidget var149 = var259;
                  var149.iReturningVoid(var150);
                  break;
               }

               var260 = var52;
            }

            int var355 = var260;
            if (var355 != 0) {
               float var356 = this.f + var56 - var54;
               var262 = var356;
               break label234;
            }

            var261 = this;
         }

         var262 = var261.f;
      }

      float var385 = var262;
      ArrayList var153 = var382;
      int var386 = var153.size() - 1;

      int var380;
      do {
         int var357 = var386;
         if (var357 < 0) {
            break;
         }

         int var155 = var386;
         ArrayList var154 = var382;
         Notification var59 = (Notification)var154.get(var155);
         float var60 = var59.recoveryAccess_read_e();
         Object[] var157 = new Object[]{var59, var25};
         ModuleNotificationsWidget var156 = this;
         float var61 = var156.cReturningFloat(var157);
         Object[] var158 = new Object[]{var59.recoveryAccess_read_c(), var11};
         Color var62 = aReturningColor(var158);
         float var63 = (1.0F - var60) * 12.0F;
         byte var358 = var51;
         float var263;
         if (var358 != 0) {
            float var359 = this.e + var55 - var61 + var63;
            var263 = var359;
         } else {
            var263 = this.e - var63;
         }

         float var64 = var263;
         float var65 = var64 + var61;
         Color var160 = UiMetrics.r;
         int var427 = var160.getRed();
         Color var161 = UiMetrics.r;
         int var435 = var161.getGreen();
         Color var162 = UiMetrics.r;
         int var442 = var162.getBlue();
         Color var163 = UiMetrics.r;
         int var10005 = (int)(var163.getAlpha() * var60);
         Object[] var10008 = new Object[]{null, var7};
         var10008[0] = var10005;
         Object[] var164 = var10008;
         Color var66 = new Color(var427, var435, var442, aReturningInt(var164));
         int var423 = (int)(230.0F * var60);
         Object[] var443 = new Object[]{null, null, var39};
         var443[1] = var423;
         var443[0] = var62;
         Object[] var165 = var443;
         Color var67 = bReturningColor(var165);
         int var428 = 17607;
         long var436 = 1697566798607033401L ^ var2;
         int var437 = 25295;
         long var444 = 5987713996122358327L ^ var2;
         int var445 = 25295;
         long var453 = 5987713996122358327L ^ var2;
         var10005 = (int)(255.0F * var60);
         var10008 = new Object[]{null, var7};
         var10008[0] = var10005;
         Object[] var166 = var10008;
         Color var68 = new Color(255, 255, 255, aReturningInt(var166));
         Color var167 = UiMetrics.u;
         var428 = var167.getRed();
         Color var168 = UiMetrics.u;
         var437 = var168.getGreen();
         Color var169 = UiMetrics.u;
         var445 = var169.getBlue();
         var10005 = (int)(255.0F * var60);
         var10008 = new Object[]{null, var7};
         var10008[0] = var10005;
         Object[] var170 = var10008;
         Color var69 = new Color(var428, var437, var445, aReturningInt(var170));
         int var360 = var41;
         if (var360 != 0) {
            float var470;
            int var361 = (var470 = var60 - 0.7F) == 0.0F ? 0 : (var470 < 0.0F ? -1 : 1);
            if (var361 > 0) {
               Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
               var10011[8] = 4.0F;
               var10011[7] = 5;
               var10011[6] = var54;
               var10011[5] = var61;
               var10011[4] = var385;
               var10011[3] = var64;
               var10011[2] = var6;
               var10011[1] = var4;
               var10011[0] = var5;
               Object[] var172 = var10011;
               BlurredRectangleRenderer.eReturningVoid(var172);
            }

            Object[] var463 = new Object[]{null, null, null, null, null, null, null, null, null, var17};
            var463[8] = 4.0F;
            var463[7] = var66;
            var463[6] = var54;
            var463[5] = var61;
            var463[4] = var385;
            var463[3] = var64;
            var463[2] = var6;
            var463[1] = var4;
            var463[0] = var5;
            Object[] var174 = var463;
            FilledRectangleRenderer.cReturningVoid(var174);
         }

         Object[] var176 = new Object[]{var59.recoveryAccess_read_c(), var37};
         ModuleNotificationsWidget var175 = this;
         ManagedGlTexture var70 = var175.aReturningbT_C0095(var176);
         byte var362 = var51;
         float var264;
         if (var362 != 0) {
            float var363 = var65 - 5.5F - 10.0F;
            var264 = var363;
         } else {
            var264 = var64 + 5.5F;
         }

         float var71 = var264;
         float var456 = var385 + (var54 - 10.0F) / 2.0F;
         Object[] var464 = new Object[]{null, null, null, null, null, null, null, null, var67, var21};
         var464[7] = 10.0F;
         var464[6] = 10.0F;
         var464[5] = var456;
         var464[4] = var71;
         var464[3] = var70;
         var464[2] = var6;
         var464[1] = var4;
         var464[0] = var5;
         Object[] var178 = var464;
         TexturedRectangleRenderer.cReturningVoid(var178);
         MsdfFontManager var413 = Prestige.c;
         Object[] var180 = new Object[]{var13};
         MsdfFontManager var179 = var413;
         MsdfFont var414 = var179.aReturningcx_C0158(var180);
         Object[] var182 = new Object[]{var59.recoveryAccess_read_a(), var35};
         MsdfFont var181 = var414;
         float var72 = var181.aReturningFloat(var182) * 0.9F;
         MsdfFontManager var415 = Prestige.c;
         Object[] var184 = new Object[]{var13};
         MsdfFontManager var183 = var415;
         MsdfFont var416 = var183.aReturningcx_C0158(var184);
         Object[] var186 = new Object[]{var59.recoveryAccess_read_b(), var35};
         MsdfFont var185 = var416;
         float var73 = var185.aReturningFloat(var186) * 0.75F;
         byte var364 = var51;
         float var265;
         if (var364 != 0) {
            float var365 = var71 - 3.0F - var72;
            var265 = var365;
         } else {
            var265 = var71 + 10.0F + 3.0F;
         }

         float var74 = var265;
         byte var366 = var51;
         float var266;
         if (var366 != 0) {
            float var367 = var71 - 3.0F - var73;
            var266 = var367;
         } else {
            var266 = var71 + 10.0F + 3.0F;
         }

         float var75 = var266;
         MsdfFontManager var417 = Prestige.c;
         Object[] var190 = new Object[]{var13};
         MsdfFontManager var189 = var417;
         MsdfFont var418 = var189.aReturningcx_C0158(var190);
         String var430 = var59.recoveryAccess_read_a();
         float var447 = var385 + 3.0F;
         Object[] var10009 = new Object[]{null, null, null, null, null, var68, var19};
         var10009[4] = 0.9F;
         var10009[3] = var447;
         var10009[2] = var74;
         var10009[1] = var430;
         var10009[0] = var6;
         Object[] var192 = var10009;
         MsdfFont var191 = var418;
         var191.w(var192);
         MsdfFontManager var419 = Prestige.c;
         Object[] var194 = new Object[]{var13};
         MsdfFontManager var193 = var419;
         MsdfFont var420 = var193.aReturningcx_C0158(var194);
         String var431 = var59.recoveryAccess_read_b();
         float var448 = var385 + 3.0F + var53 * 0.9F;
         var10009 = new Object[]{null, null, null, null, null, var69, var19};
         var10009[4] = 0.75F;
         var10009[3] = var448;
         var10009[2] = var75;
         var10009[1] = var431;
         var10009[0] = var6;
         Object[] var196 = var10009;
         MsdfFont var195 = var420;
         var195.w(var196);
         boolean var368 = var59.recoveryAccess_read_f();
         float var267;
         if (var368) {
            float var369 = 0.0F;
            var267 = var369;
         } else {
            var405 = 1.0F - (float)(var42 - var59.recoveryAccess_read_d()) / 2000.0F;
            Object[] var457 = new Object[]{null, null, null, var27};
            var457[2] = 1.0F;
            var457[1] = 0.0F;
            var457[0] = var405;
            Object[] var198 = var457;
            var267 = ClientUiUtil.aReturningFloat(var198);
         }

         float var76 = var267;
         float var77 = (var61 - 11.0F) * var76;
         int var372 = var41;
         float var371 = 0.5F;
         float var370 = var77;
         float var270 = var370;
         float var271 = var371;
         float var268 = var370;
         float var269 = var371;
         if (var372 != 0) {
            float var471;
            int var373 = (var471 = var268 - var269) == 0.0F ? 0 : (var471 < 0.0F ? -1 : 1);
            label182:
            if (var373 > 0) {
               Color var78;
               label187: {
                  var423 = (int)(150.0F * var60);
                  Object[] var449 = new Object[]{null, null, var39};
                  var449[1] = var423;
                  var449[0] = var62;
                  Object[] var200 = var449;
                  var78 = bReturningColor(var200);
                  int var374 = var41;
                  if (var374 != 0) {
                     byte var375 = var51;
                     if (var375 == 0) {
                        break label187;
                     }

                     float var425 = var65 - 5.5F - var77;
                     float var432 = var385 + var54 - 3.0F;
                     float var439 = var65 - 5.5F;
                     float var450 = var385 + var54 - 2.0F;
                     var10008 = new Object[]{null, null, null, null, null, var78, var33};
                     var10008[4] = var450;
                     var10008[3] = var439;
                     var10008[2] = var432;
                     var10008[1] = var425;
                     var10008[0] = var6;
                     Object[] var202 = var10008;
                     ShapeRenderer.lReturningVoid(var202);
                  }

                  int var376 = var41;
                  if (var376 != 0) {
                     break label182;
                  }
               }

               float var426 = var64 + 5.5F;
               float var433 = var385 + var54 - 3.0F;
               float var440 = var64 + 5.5F + var77;
               float var451 = var385 + var54 - 2.0F;
               var10008 = new Object[]{null, null, null, null, null, var78, var33};
               var10008[4] = var451;
               var10008[3] = var440;
               var10008[2] = var433;
               var10008[1] = var426;
               var10008[0] = var6;
               Object[] var204 = var10008;
               ShapeRenderer.lReturningVoid(var204);
            }

            var405 = var54 + 3.0F;
            var271 = var60;
            var270 = var405;
         }

         label178: {
            float var387;
            label177: {
               var387 = var270 * var271;
               int var377 = var41;
               if (var377 != 0) {
                  byte var378 = var52;
                  if (var378 == 0) {
                     break label177;
                  }

                  var385 -= var387;
               }

               int var379 = var41;
               if (var379 != 0) {
                  break label178;
               }
            }

            var385 += var387;
         }

         var386--;
         var380 = var41;
      } while (var380 != 0);
   }

   private float cReturningFloat(Object[] var1) {
      Notification var4 = (Notification)var1[0];
      long var2 = (Long)var1[1];
      var2 = 105555079518017L ^ var2;
      long var5 = var2 ^ 30778026180906L;
      long var7 = var2 ^ 103532973501032L;
      MsdfFontManager var10000 = Prestige.c;
      Object[] var13 = new Object[]{var7};
      MsdfFontManager var12 = var10000;
      MsdfFont var25 = var12.aReturningcx_C0158(var13);
      Object[] var15 = new Object[]{var4.recoveryAccess_read_a(), var5};
      MsdfFont var14 = var25;
      float var9 = var14.aReturningFloat(var15) * 0.9F;
      var10000 = Prestige.c;
      Object[] var17 = new Object[]{var7};
      MsdfFontManager var16 = var10000;
      MsdfFont var27 = var16.aReturningcx_C0158(var17);
      Object[] var19 = new Object[]{var4.recoveryAccess_read_b(), var5};
      MsdfFont var18 = var27;
      float var10 = var18.aReturningFloat(var19) * 0.75F;
      float var21 = var10;
      float var20 = var9;
      float var11 = Math.max(var20, var21);
      float var23 = 18.5F + var11 + 5.5F;
      float var22 = 90.0F;
      return Math.max(var22, var23);
   }

   private ManagedGlTexture aReturningbT_C0095(Object[] var1) {
      NotificationType var4 = (NotificationType)var1[0];
      long var2 = (Long)var1[1];
      var2 = 105555079518017L ^ var2;
      long var5 = var2 ^ 102470324177409L;
      int var10000 = Event.cReturningInt();
      NotificationType var10 = var4;
      Map var9 = this.l;
      ManagedGlTexture var8 = (ManagedGlTexture)var9.get(var10);
      int var7 = var10000;
      int var21 = var7;
      ManagedGlTexture var20 = var8;
      ManagedGlTexture var19 = var20;
      ManagedGlTexture var18 = var20;
      if (var21 != 0) {
         ManagedGlTexture var22 = var18;
         if (var22 == null) {
            NotificationType var12 = var4;
            String var13 = var12.name();
            String var24 = var13.toLowerCase();
            short var10001 = 13921;
            long var10002 = 7471392531945173178L ^ var2;
            short var25 = 15067;
            long var10003 = 6553103899256863747L ^ var2;
            Object[] var14 = new Object[]{"assets/prestige/icons/notifications/" + var24 + ".png", var5};
            var8 = TextureLoader.aReturningbT_C0095(var14);
            ManagedGlTexture var17 = var8;
            NotificationType var16 = var4;
            Map var15 = this.l;
            var15.put(var16, var17);
         }

         var19 = var8;
      }

      return var19;
   }

   private static Color aReturningColor(Object[] var0) {
      NotificationType var3 = (NotificationType)var0[0];
      long var1 = (Long)var0[1];
      var1 = 105555079518017L ^ var1;
      NotificationType var4 = var3;
      int var5 = NotificationTypeSwitchMap.a[var4.ordinal()];
      switch (var5) {
         case 1:
            short var10 = 9922;
            long var18 = 2407730158744268946L ^ var1;
            short var19 = 29660;
            long var26 = 3375060057929721217L ^ var1;
            short var27 = 25342;
            long var30 = 1252505344881472674L ^ var1;
            return new Color(76, 175, 80);
         case 2:
            short var9 = 1305;
            long var16 = 1678600503408284490L ^ var1;
            short var17 = 21556;
            long var24 = 7848386592833733217L ^ var1;
            short var25 = 1421;
            long var29 = 1420007657684521941L ^ var1;
            return new Color(244, 67, 54);
         case 3:
            short var8 = 25295;
            long var14 = 5987813568509883542L ^ var1;
            short var15 = 18323;
            long var23 = 2378626070894809540L ^ var1;
            return new Color(255, 152, 0);
         case 4:
            short var7 = 26743;
            long var12 = 5670035711039159853L ^ var1;
            short var13 = 28440;
            long var21 = 3982689771663210830L ^ var1;
            short var22 = 29878;
            long var28 = 3309189177135440615L ^ var1;
            return new Color(33, 150, 243);
         default:
            short var10002 = 8254;
            long var10003 = 1982563667408480L ^ var1;
            short var11 = 8211;
            long var10004 = 8767302035534804551L ^ var1;
            short var20 = 8211;
            long var10005 = 8767302035534804551L ^ var1;
            return new Color(128, 128, 128);
      }
   }

   private static Color bReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      int var2 = (Integer)var0[1];
      long var3 = (Long)var0[2];
      var3 = 105555079518017L ^ var3;
      long var5 = var3 ^ 131038288360911L;
      Color var7 = var1;
      int var10002 = var7.getRed();
      Color var8 = var1;
      int var10003 = var8.getGreen();
      Color var9 = var1;
      int var10004 = var9.getBlue();
      Object[] var10008 = new Object[]{null, var5};
      var10008[0] = var2;
      Object[] var10 = var10008;
      return new Color(var10002, var10003, var10004, aReturningInt(var10));
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 105555079518017L ^ var1;
      int var4 = Event.bReturningInt();
      int var12 = var4;
      int var11 = var3;
      int var9 = var11;
      int var8 = var11;
      if (var12 == 0) {
         int var13 = var8;
         if (var13 < 0) {
            return 0;
         }

         var9 = var3;
      }

      short var10001 = 25295;
      long var10002 = 5987799186353984483L ^ var1;
      int var7 = var9;
      return Math.min(var7, 255);
   }

   static {

      {

      long var10001 = 76064025484369L ^ 79958958946703L;
      b();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(76064025484369L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[8];
      String var26 = "V%Õ±ì9R\u0005OLwp\u0082<ööÇIS\u008eb\u000e\u0083\u00192ð÷\u009fd«7z§\u0011ægÕ\u0084\u0011\u0088P¢ç\u0098-Ñ\u0088\u008aS¨í£)Q+!»\u0088`½$²Å¶}Æ\u0004î\u009aF@rO\u0095I¤\u000fÌÊ1\u0002iØ)\f\u0012í$\u009bC@y\u009dÉ\u009b\u009d°>r+\u0093yY\f\u00013Ò\u0012sq»=ý bK£\fî\u008ae(øg\"a\u009aäÓØ£\u0098Ù\u0088¦*\u0012ïñÂ'\u009e2\u0015F\u0097øP¡Íé+µfbÌ§\u0013\u0019øÑf(VR\u001c\bý}¼\u000e¬ #\u008aW\u0094\u0098TÌ\u0091+üJWIÖs\u0096\u009fà\u000f2H¢ÿ\u0088gpÅ\u0099Lä(°\u009e\u000eb6â\u0087\u0019S¢Á%7<ns8!\b°\u000e±\u009dîM«xéGE\u0089siÉy/\u0087q\u0019-@\u000b¾\u0095\fuvã*\n\u00ad¡\u0001\u0091Õ\u008c-\u009e\u0000$Å\u0085¤«µ/\u0007ÿ9¿&í\bß÷½4:x\u001b\u008aZ'É`ÄÁ>áxn>´mI\u0014ôwB\u0086ôÁµ|ê";
      int var28 = "V%Õ±ì9R\u0005OLwp\u0082<ööÇIS\u008eb\u000e\u0083\u00192ð÷\u009fd«7z§\u0011ægÕ\u0084\u0011\u0088P¢ç\u0098-Ñ\u0088\u008aS¨í£)Q+!»\u0088`½$²Å¶}Æ\u0004î\u009aF@rO\u0095I¤\u000fÌÊ1\u0002iØ)\f\u0012í$\u009bC@y\u009dÉ\u009b\u009d°>r+\u0093yY\f\u00013Ò\u0012sq»=ý bK£\fî\u008ae(øg\"a\u009aäÓØ£\u0098Ù\u0088¦*\u0012ïñÂ'\u009e2\u0015F\u0097øP¡Íé+µfbÌ§\u0013\u0019øÑf(VR\u001c\bý}¼\u000e¬ #\u008aW\u0094\u0098TÌ\u0091+üJWIÖs\u0096\u009fà\u000f2H¢ÿ\u0088gpÅ\u0099Lä(°\u009e\u000eb6â\u0087\u0019S¢Á%7<ns8!\b°\u000e±\u009dîM«xéGE\u0089siÉy/\u0087q\u0019-@\u000b¾\u0095\fuvã*\n\u00ad¡\u0001\u0091Õ\u008c-\u009e\u0000$Å\u0085¤«µ/\u0007ÿ9¿&í\bß÷½4:x\u001b\u008aZ'É`ÄÁ>áxn>´mI\u0014ôwB\u0086ôÁµ|ê"
         .length();
      char var25 = '(';
      int var34 = -1;

      label81:
      while (true) {
         String var35 = var26.substring(++var34, var34 + var25);
         // while (true) {
            byte[] var30 = var22.doFinal(var35.getBytes("ISO-8859-1"));
            String var52 = b(var30).intern();
            switch (var41) {
               case 0:
                  var29[var27++] = var52;
                  if ((var34 += var25) >= var28) {
                     w = var29;
                     x = new String[8];
                     D = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(76064025484369L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[15];
                     String var15 = "\u0016\u0013ÃZ\u0010¤\u001dÔPþÊ\u0080q\f^\b\u008a\u0089\u0014\u0019Û'ÃÝó\u001aF¥Q\u0010ù]?4ZÇ/ì)\u0012~Yº\u0017è!\u009e\u001fß®ý¯.\u0096û\u009d\u00902\u0002B$\u0018\u0013ò×\u0089\u0088ªÖ\u0015«\u009d$\u0084Ò÷o\u0003Ú<\u008e`ç$\u0013%Ô¸\u0086Êôv¨û§\u007f\\ôÙ;-æ\u009fl";
                     int var16 = "\u0016\u0013ÃZ\u0010¤\u001dÔPþÊ\u0080q\f^\b\u008a\u0089\u0014\u0019Û'ÃÝó\u001aF¥Q\u0010ù]?4ZÇ/ì)\u0012~Yº\u0017è!\u009e\u001fß®ý¯.\u0096û\u009d\u00902\u0002B$\u0018\u0013ò×\u0089\u0088ªÖ\u0015«\u009d$\u0084Ò÷o\u0003Ú<\u008e`ç$\u0013%Ô¸\u0086Êôv¨û§\u007f\\ôÙ;-æ\u009fl"
                        .length();
                     label63:
                     while (true) {
                        int var45 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var45, var13).getBytes("ISO-8859-1");
                        long[] var38 = var17;
                        int var46 = var14++;
                        long var56 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var56;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var67 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var62) {
                              case 0:
                                 var38[var46] = var67;
                                 if (var13 >= var16) {
                                    B = var17;
                                    C = new Integer[15];
                                    d = 5;
                                    J = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(76064025484369L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[4];
                                    String var4 = "\u0088aï\u009dòÎP©\f<âMy¥}¤";
                                    int var5 = "\u0088aï\u009dòÎP©\f<âMy¥}¤".length();
                                    label47:
                                    while (true) {
                                       int var48 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var48, var2).getBytes("ISO-8859-1");
                                       long[] var40 = var6;
                                       int var49 = var3++;
                                       long var59 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var59;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var67 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var65) {
                                             case 0:
                                                var40[var49] = var67;
                                                if (var2 >= var5) {
                                                   H = var6;
                                                   I = new Long[4];
                                                   c = /* /*DECRYPT:dev.zprestige.prestige.b9:4:17728:8246022953102354442*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.ModuleNotificationsWidget_17728";
                                                   a = new ModuleNotificationsWidget(14941861979614L);
                                                   break;
                                                }
                                                break;
                                             default:
                                                var40[var49] = var67;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "a¹\u0086F\u0006\u009d:\u0082/v\u008d\u00ad\u0015\u0014G\u009d";
                                                var5 = "a¹\u0086F\u0006\u009d:\u0082/v\u008d\u00ad\u0015\u0014G\u009d".length();
                                                var2 = 0;
                                          }

                                          int var50 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var50, var2).getBytes("ISO-8859-1");
                                          var40 = var6;
                                          var49 = var3++;
                                          var59 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var65 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var38[var46] = var67;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "[ê\u0006\u0084kÒD»\u0087\bn\u0095ÿ=\u009fà";
                                 var16 = "[ê\u0006\u0084kÒD»\u0087\bn\u0095ÿ=\u009fà".length();
                                 var13 = 0;
                           }

                           int var47 = var13;
                           var13 += 8;
                           var18 = var15.substring(var47, var13).getBytes("ISO-8859-1");
                           var38 = var17;
                           var46 = var14++;
                           var56 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var62 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var34);
                  break;
               default:
                  var29[var27++] = var52;
                  if ((var34 += var25) < var28) {
                     var25 = var26.charAt(var34);
                     continue label81;
                  }

                  var26 = "+\u0006\n\u0095pY²À\u0005\u0018Ú.\t\u0093S^(!¤ãÉº!\u0093·Æïi^{\u001a`1\u009f8ÐÂ\u0099mM\u0001\\8rVs\u007f\u0007lY3\u0081+È\u009c\u009cQ";
                  var28 = "+\u0006\n\u0095pY²À\u0005\u0018Ú.\t\u0093S^(!¤ãÉº!\u0093·Æïi^{\u001a`1\u009f8ÐÂ\u0099mM\u0001\\8rVs\u007f\u0007lY3\u0081+È\u009c\u009cQ"
                     .length();
                  var25 = 16;
                  var34 = -1;
            }

            var35 = var26.substring(++var34, var34 + var25);
            var41 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2294;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b9", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b9",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9070;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b9", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b9",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27978;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b9", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b9",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 14;
            yield var15;
         }
         case 1 -> {
            byte var16 = 9;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 23;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 15;
            yield var20;
         }
         case 6 -> {
            byte var21 = 36;
            yield var21;
         }
         case 7 -> {
            byte var22 = 41;
            yield var22;
         }
         case 8 -> {
            byte var23 = 56;
            yield var23;
         }
         case 9 -> {
            byte var24 = 18;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 33;
            yield var26;
         }
         case 12 -> {
            byte var27 = 59;
            yield var27;
         }
         case 13 -> {
            byte var28 = 43;
            yield var28;
         }
         case 14 -> {
            byte var29 = 11;
            yield var29;
         }
         case 15 -> {
            byte var30 = 53;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 42;
            yield var32;
         }
         case 18 -> {
            byte var33 = 38;
            yield var33;
         }
         case 19 -> {
            byte var34 = 58;
            yield var34;
         }
         case 20 -> {
            byte var35 = 32;
            yield var35;
         }
         case 21 -> {
            byte var36 = 21;
            yield var36;
         }
         case 22 -> {
            byte var37 = 17;
            yield var37;
         }
         case 23 -> {
            byte var38 = 52;
            yield var38;
         }
         case 24 -> {
            byte var39 = 0;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 48;
            yield var41;
         }
         case 27 -> {
            byte var42 = 47;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 63;
            yield var44;
         }
         case 30 -> {
            byte var45 = 24;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 2;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 49;
            yield var49;
         }
         case 35 -> {
            byte var50 = 30;
            yield var50;
         }
         case 36 -> {
            byte var51 = 1;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 25;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 5;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 44;
            yield var58;
         }
         case 44 -> {
            byte var59 = 6;
            yield var59;
         }
         case 45 -> {
            byte var60 = 37;
            yield var60;
         }
         case 46 -> {
            byte var61 = 34;
            yield var61;
         }
         case 47 -> {
            byte var62 = 7;
            yield var62;
         }
         case 48 -> {
            byte var63 = 8;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 60;
            yield var66;
         }
         case 52 -> {
            byte var67 = 35;
            yield var67;
         }
         case 53 -> {
            byte var68 = 51;
            yield var68;
         }
         case 54 -> {
            byte var69 = 28;
            yield var69;
         }
         case 55 -> {
            byte var70 = 16;
            yield var70;
         }
         case 56 -> {
            byte var71 = 3;
            yield var71;
         }
         case 57 -> {
            byte var72 = 26;
            yield var72;
         }
         case 58 -> {
            byte var73 = 12;
            yield var73;
         }
         case 59 -> {
            byte var74 = 39;
            yield var74;
         }
         case 60 -> {
            byte var75 = 13;
            yield var75;
         }
         case 61 -> {
            byte var76 = 54;
            yield var76;
         }
         case 62 -> {
            byte var77 = 61;
            yield var77;
         }
         default -> 20;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "\u00012h\u0017\\\n\u00172mMO\u001d\u0000ynKC\t\u0011>y\\\b\u001b ";
      K[1] = int.class;
      L[1] = "java/lang/Integer";
      K[2] = "j@_XX\u0019j@H\u0004T\u0016p\u000bH\u001aT\u0003wz\u001aF\u0001A";
      K[3] = "\u0010nN\u001aB0\u0006nK@Q'\u0011%HF]3\u0000b_Q\u0016',";
      K[4] = "ow=2)6\u001aW6=8y{Y=6<#\u000f";
      K[5] = float.class;
      L[5] = "java/lang/Float";
      K[6] = "/s\u001eW\u0011\u001f9s\u001b\r\u0002\b.8\u0018\u000b\u000e\u001c?\u007f\u000f\u001cE\rz";
      K[7] = "W+Wl,\u001b\"\u000b\\c=TC\u0005Wh9\u000e7";
      K[8] = void.class;
      L[8] = "java/lang/Void";
      K[9] = "xKx\u001a\u0010%nK}@\u00032y\u0000~F\u000f&hGiQD7%";
      K[10] = "\u0005g`/M3\u000ehq`.>\u001be~\u000b\u001b<\nvb'\f1";
      K[11] = "\u000eO\u0004\u0002N6\u000eO\u0013^B9\u0014\u0004\u0013@B,\u0013uC\u001d\u0013";
      K[12] = "Q$5Ud~Z+$\u001a\u0019fI,-S";
      K[13] = "Twa\u0001U\b_xpN4\u0006Tst\u0014";
      K[14] = boolean.class;
      L[14] = "java/lang/Boolean";
      K[15] = "qm\r`\u001fDoe\u0017/pCim\u0002MXBo";
      K[16] = "\u0006\u0015\u0010%pk\u0018\u001d\nj\u0017j\t\u0006\u000701l";
      K[17] = ".&\u0003K >%)\u0012\u0004C30/";
      K[18] = "t\u0002\u0002\u0014Mqb\u0002\u0007N^fuI\u0004HRrd\u000e\u0013_\u0019bj";
      K[19] = "KdghMs>Dlg\\<_JglXf+";
      K[20] = "/+a%%%9+d\u007f62.`gy:&?'pnq63";
      K[21] = "2\u0019Iqr=$\u0019L+a*3RO-m>\"\u0015X:&.:\u0015Z1|c\u0006\u000eZ,|$1\u0019";
      K[22] = "IO$=\u007fr<o/2n=]a$9jg)";
      K[23] = "nAX:+$\u001baS5:kzoX>>1\u000e";
      K[24] = "+$a*W'^\u0004j%Fh?\na.B2K";
      K[25] = "K'jw-1]'o->&Jll+22[+{<y%~";
      K[26] = "\u001d`<\u001b><\u000b`9A-+\u001c+:G!?\rl-Pj:";
      K[27] = "^tf\u001e>[Ca><\u007fV[g";
      K[28] = "\u000fH>yVqzh5vG>\u001bf>}Cdo";
      K[29] = "\u000fkgH\u0000.\u0019kb\u0012\u00139\u000e a\u0014\u001f-\u001fgv\u0003T:\u0003";
      K[30] = "TH\u000ePp6!h\u0005_ay@f\u000eTe#4";
      K[31] = "s\u007f0\n !e\u007f5P36r46V?\"cs!At3C";
      K[32] = "`\u007f!\\@%~w;\u0013#1z";
      K[33] = "p4$~%\u0003\u0005\u0014/q4Ld\u001a$z0\u0016\u0010";
      K[34] = "S\fMj!u&,Fe0:G\"Mn4`3";
      K[35] = "UsCS}J^|R\u001c\u0000_LfP_";
      K[36] = long.class;
      L[36] = "java/lang/Long";
      K[37] = "\u007f\u001e/sc\b\u007f\u001e8/o\u0007eU81o\u0012b$on9";
      K[38] = "\u0006+}Xtxs\u000bvWe7\u0012\u0005}\\amf";
      K[39] = "fTWv\u0003mx\\M9aq\u007fA";
      K[40] = "N{F:sK;[M5b\u0004ZUF>f^.";
      K[41] = "xlf\u001e}0nlcDn'y'`Bb3h`wU)$j";
      K[42] = "NCk\u001cZc;c`\u0013K,Zmk\u0018Ov.";
      K[43] = ",BPL_KYb[CN\u00048lPHJ^L";
      K[44] = "\u0001vNE\u0010[tVEJ\u0001\u0014\u0015XNA\u0005Na";
      K[45] = "\u0005R\u000bs]}\u0013R\u000e)Nj\u0004\u0019\r/B~\u0015^\u001a8\tl#";
      K[46] = "l\u0011#)\u0014\f\u00191(&\u0005Cx?#-\u0001\u0019\f";
      K[47] = ".Whz\u001c\u001c[wcu\rS:yh~\t\tN";
      K[48] = "#%J'\n\n5%O}\u0019\u001d\"nL{\u0015\t3)[l^\u001e ";
      K[49] = "W\u0004|\u0016w@\"$w\u0019f\u000fC*|\u0012bU7";
      K[50] = "\b0LNFZ}\u0010GAW\u0015\u001c\u001eLJSOh";
      K[51] = "EFg]500flR$\u007fQhgY %%";
      K[52] = "\u007fj4hP9ij12C.~!24O:of%#\u0004-}";
      K[53] = "/M<|;}Zm7s*2;c<x.hO";
      K[54] = "1UC5lw'UFo\u007f`0\u001eEist!YR~8dl";
      K[55] = "Kl0ciN>L;lx\u0001_B0g|[+";
      K[56] = "\r^\u001c\u007f2]x~\u0017p#\u0012\u0019p\u001c{'Hm";
      K[57] = "\t\u0012\u0003\u0004uFX\u001bJ\\DW7F\b\u000b&\u0000\u0006\u001eSX>\u00017\u001d\u000eG!SJ\u0012T\\-=";
      K[58] = "\r`\u0001E\u0007}\u0002:\u001aIio\u0002!5D\u0011`\u0006]E\u001c\u0013f\r<\u001c^R9o";
      K[59] = ",\u000fs>\b\u00124Lq|d\u00186\rkl\u0002\u000f\u0017\u0016tl!\u0012/\u0013pzd\u000b{\u0005cx[\u001a/Gc\u0001";
      K[60] = "E\b63{b\u0015\u001a1c\u0010{(\u0013-0){IC1.j";
      K[61] = "\u0003b\u0000c<7P|UnQ2]u\th\u0006e\u0003%P\u0004(`Ax\ff-8Gw";
      K[62] = "bM\u0016\u000bg\t)V\u001a\t\u0017\b6@\u0010\u0016{:g\u0001HO\u0017TgF\u0016\u0013v\r%\u0007Iq";
      K[63] = "\u000eU??i\f\u0012X <\n\u001dc\u0006jmh_R^1>p^c\u0001h-;\u001d\u001eAo=5b";
      K[64] = "7\u001f\u001b\u0003m= \u0000M\u0019\u0017>1\u001c\b\u0015k87q\u0018\u0017zd\"I\u0010\u0004&'M";
      K[65] = "=\u007fR\u0010\u001a\u0000{!\u0017\u0005w\u001f\u0001$RS\u0015C0|\t\u0000\rB\u0001#P\u0013F\u0001|cW\u0003H~";
      K[66] = "Q\bj\u0013\u007f\u0006Y\u001b6P\u0010XV\u0013{(!UX\u001a<ObD\u0002_\u0007";
      K[67] = "_5W>q7C8H=\u001202f\u0002lpd\u0003>Y?he2c\u0000\"#!\n$T:rY";
      K[68] = "t=fW\u000ba|.:\u0014d#s3l\u0012\tY oz]\u001b$`hjSd";
      K[69] = "\fD\u007f(uD_Z*%\u0018J^Br(tx\t\u0004,\u007f#/\nOt5hKATx7\u0018";
      K[70] = "\u0014*^1b\f\u001bpE=\f\u001e\u001bky9`qO+Y2n\u0010\u0016i\u0018m\f";
      K[71] = "\"M:;ZW \u0012gtbZ*M0JS\u0004x\u0011e-\u001fV<N]";
      K[72] = "\u0014Tx\u0011m\u0012R\n=\u0004\u0000\u0000(\u000fxRbQ\u0019W#\u0001zP(_/\u0005xT\u0015[2_el";
      K[73] = "_K\u0001\u001b\u0016V\u0013\u0019ED.\\\u0017\u000eSFU1_\u0018Y[\u0015V\u001c\t\u0003\u001e.X\u0002\u0015B\u001a\u0013\\\u001fO_\"";
      K[74] = "]z\u0018Q(\u0007\u0004e\u0006]\u0017\u0002Hw\u0013Yk\u0004N\u001a\u0003[zX[\"\u000bH&\u001b4";
      K[75] = "\u0002M\u0000X-5\u0019G\u0017S\u0011l|\u001aC\u0003s8MB\u0018Pk9|\u001fAM }DX\u0015Uq\u0005";
      K[76] = "h$N\u0001\b\u0005.z\u000b\u0014e\u0010T\u007fNB\u0007Fe'\u0015\u0011\u001fGT/\u0019\u0015\u001dCi+\u0004O\u0000{";
      K[77] = "R()Y\u0018^\u001ezm\u0006 E\u0004Tu\u001fMC(yi\r \b[++XGD\tot`";
      K[78] = "\u007fUE\r\f\u000f9\u000b\u0000\u0018a\u0018C\u000eEN\u0003LrV\u001e\u001d\u001bMC\tG\u000eP\u000e>I@\u001e^q";
      K[79] = "K\u0010F\u0014}}\u0019S[\b\u0006-(\u0018\u0004@dy\u0019@_\u0013|x(EZ\u0000;!WD_\u0016zD";
      K[80] = "?\u0000X;~0(\u001f\u000e!\u0004=(\u00121}8(#\fP$zi|n\u0000/g+~\tC>=nE";
      K[81] = "V\u0004J55W\u0010Z\u000f XDj_Jv:\u0014[\u0007\u0011%\"\u0015j\u000f\u001d! \u0011W\u000b\u0000{=)";
      K[82] = "\u007f6N`(cd<Yk\u00149\u0001a\r;vn09Vhno\u0001d\u000fu%+9#[mtS";
      K[83] = "6\bn[%T1I8Tj.b10\t)L2\u0000hRzT317\u000bi\u001fpLw\fy\u0011\u000f";
      K[84] = "\u0012M/\u0002!n\u000e@0\u0001Bk\u007f\u001ezP =NF!\u00038<\u007f\u001bx\u001esxG\\,\u0006\"\u0000";
      K[85] = "8`x:[F7:c65T7!J%XV<]<cO]8<e!\u000e\u0002Z";
      K[86] = "\u001a7AzK*AkL\u0015ZI\u0018kTsR(A)\u0015,0";
      K[87] = "OLf)j\u0015\u0004Wj+\u001a\u0014\u001bA`4v&J\u00010b\u001aHJGf1{\u0011\b\u00069S";
      K[88] = "t)6\\\r\u0005% \u007f\u0004<\u0017J}=S^C{%f\u0000FBJ c\u0013\u0001\u001b5!f\u0005@~";
      K[89] = "O)v\u0004\u0001\u0014\u0014u{k\u0011wMuc\r\u0018\u0016\u00147\"Rz";
      K[90] = "5z{\u001c&\u0000<jlX@\nN\"%\u0010\"S\u007fz~C:RN%'Pq\u00113e @\u007fn";
      K[91] = "T5l=b\n\u0005<%eS\u001ajag21L[9<a)Mjde|b\tR#1d3q";
      K[92] = "3v;iz5k0;,\u00058;rAcn4/5& \u007fnj\u000ep9f.mi3(<kV";
      K[93] = "`e\b-E)b:Ub}%{l\u000e:\u0014&\u00019S&\u001b ``\u0011gDB";
      K[94] = "\u0014$\u0005@dIE-L\u0018U[*vPO>[FxS\u000782\u0015,\u0004\u0015<^\u001b/L\u0013U";
      K[95] = "X\u0011=p\u0006:P\u0002a3ib[\u0001\u0016&\u0019~2\u0013<-\u0011:\u000f\u0017!w\f\u0002";
      K[96] = "W\r\"vsB\n\f2)\u001eY7@e}'\u000bP\f79x3";
      K[97] = "\u0016N0/bw\u0001Qf5\u0018t\u0017m<(ddlI56`-QM(l}\u0015";
      K[98] = "xu-b\nyw//``'r\"\u0017c\\8u&v:\u001ey*D.f\u001a$q%w$[{\u0013}+ \u0006 r$iaYB";
      K[99] = "\u0018\u00161~SM\u0017L3|9\u0013\u001aW\u000bz\u0000\tB_3=T\u0011\u0013'7\u007fFG\u000b\u001fp+^\u0016s\u001b29\b\u000eK\\f!Yv";
      K[100] = "\u0019\u001c\u001b\u0000\u0015-RKD\u001a.z#\u001b\u001dKL-\u0012CF\u0018T,#\u001e\u001f\u0005\u001fh\u001bYK\u001dN\u0010";
      K[101] = "fW\u001e\u0007H\u001fi\r\u0005\u000b&\ri\u0016)\u0006[\u000f\u0004S_\u0018@\u0000e\n\u001dY\u001fb";
      K[102] = "\u0011tZy~CAhD:\u0015Kz=\u0003qw\u001fKeX\"o\u001eziR.vA\u0014u_1u\"";
      K[103] = "Tnc\u0019%X\u0005g*A\u0014_j:h\u0016v\u001e[b3En\u001fj=jV%\\\u0017}mF+#";
      K[104] = "59KLMyl&U@rt05:\u001c\u0019~%b]_\b$`YSA\u0014eddW\\Nx\\";
      K[105] = "C]\u0011Dkz\u001e\\\u0001\u001b\u0006b#H\u0002\u0012~3\u001eL\u001fHc\u000b";
      K[106] = "\u000e\u0003YI3J\u0019\u001c\u000fSIA\u0018\u00010\u0007\"K\rVWD3\u0011HmYZ/PLP]GuMt";
      K[107] = "\u001e\fD7\t \t\u0013\u0012-s9\u0005\u0010@HJ~\u001e\u0004O)\u0013<_[-";
      K[108] = "?iRG#\u0013!m[J\u0012\u001cO*\u0011\tpJ~rJZhKO-\u0013I#\b2m\u0014Y-w";
      K[109] = "T~\\W\u001c?\u0005w\u0015\u000f--j*WXOy[r\f\u000bWxjqQ\u0014H*\u0017~\u000b\u000fDD";
      K[110] = "!\u001a_C&8dGE\u0010.\u0002s\"\fG.`%\u0013T\u001c}x$\"\u000bEn3g_KB~=\u0018";
      K[111] = "+v}U\\Rz\u007f4\rm@\u0015\"vZ\u000f\u0014$z-\t\u0017\u0015\u0015\"q\u0011\u000bKt{3PT)";
      K[112] = "\u0018y4HBD@?4\r=^\u0000}NBVE\u0004:)\u0001G\u001fA\u0001\u007f\u0018^_Ff<\t\u0004\u001a}0%\u0010D\u001d\u001as4J\u0001&";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(949517031905176L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(949517031905176L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(949517031905176L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 208;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 99;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 249;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 225;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 109;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 208;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 99;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 249;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b9",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = d(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = d(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = d(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = d(MethodHandles.lookup(), "r", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
