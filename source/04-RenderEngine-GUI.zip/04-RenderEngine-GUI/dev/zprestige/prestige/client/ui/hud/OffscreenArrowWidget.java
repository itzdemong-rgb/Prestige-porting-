package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.util.EntityUtil;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.renderlib.ShapeRenderer;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

public class OffscreenArrowWidget extends HudElement {
   private static final float m = 16.0F;
   private static final float a = 9.0F;
   private static final float c = 5.0F;
   private static final float d = 4.5F;
   private static final float e = 45.0F;
   private static final float f = 45.0F;
   private static final float g = 5.0F;
   private static final float h = 10.0F;
   private static final float i = 28.0F;
   private static final float j = 0.18F;
   private float k;
   private float l;
   private boolean n;
   private long o;
   private static final long v = 55078432665304L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Long[] C;
   private static final Map D;
   private static final Object[] H = new Object[73];
   private static final String[] I = new String[73];

   public OffscreenArrowWidget(long var1) {
      super("Offscreen Arrow", "Points to the closest player when they're off-screen", ((55078432665304L ^ (55078432665304L ^ var1)) ^ 26855052346888L));
      var1 = 55078432665304L ^ var1;
      long var3 = var1 ^ 26855052346888L;
      short var10001 = 11711;
      long var10002 = 2282528470259997986L ^ var1;
      short var7 = 297;
      long var10003 = 6775101234925384117L ^ var1;

      this.k = 0.0F;
      this.l = 0.0F;
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      var10001 = 21987;
      var10002 = 8531691773565083309L ^ var1;
      this.o = 0L;
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      Matrix4f var2 = (Matrix4f)var1[2];
      long var3 = (Long)var1[3];
      long var7 = var3 ^ 36477842301344L;
      long var9 = var3 ^ 100723319147960L;
      long var11 = var3 ^ 95746790943520L;
      long var13 = var3 ^ 111086046474883L;
      int var10000 = Event.bReturningInt();
      Object[] var10005 = new Object[]{null, 0.0F};
      var10005[0] = 0.0F;
      Object[] var42 = var10005;
      OffscreenArrowWidget var41 = this;
      var41.iReturningVoid(var42);
      int var15 = var10000;
      int var160 = var15;
      MinecraftClient var159 = b;
      MinecraftClient var131 = var159;
      MinecraftClient var130 = var159;
      if (var160 == 0) {
         MinecraftClient var43 = var130;
         ClientPlayerEntity var161 = var43.player;
         if (var161 == null) {
            return;
         }

         MinecraftClient var162 = b;
         var131 = var162;
      }

      MinecraftClient var46 = var131;
      ClientWorld var163 = var46.world;
      if (var163 != null) {
         long var16;
         float var140;
         label99: {
            var16 = System.currentTimeMillis();
            short var10001 = 24332;
            long var10002 = 7535653509811914275L ^ var3;
            int var168 = var15;
            long var164 = this.o;
            long var136 = var164;
            long var138 = var166;
            long var132 = var164;
            long var134 = var166;
            if (var168 == 0) {
               long var224;
               int var169 = (var224 = var132 - var134) == 0L ? 0 : (var224 < 0L ? -1 : 1);
               if (!((var169) != 0)) {
                  float var170 = 0.016F;
                  var140 = var170;
                  break label99;
               }

               var138 = this.o;
               var136 = var16;
            }

            var140 = (float)(var136 - var138) / 1000.0F;
         }

         int var20;
         float var21;
         float var198;
         label109: {
            var198 = var140;
            this.o = var16;
            float var51 = 0.05F;
            float var50 = var198;
            var198 = Math.min(var50, var51);
            Object[] var52 = new Object[]{var13};
            PlayerEntity var19 = EntityUtil.aReturningPlayerEntity(var52);
            var20 = 0;
            var21 = 0.0F;
            int var172 = var15;
            PlayerEntity var171 = var19;
            PlayerEntity var142 = var171;
            PlayerEntity var141 = var171;
            if (var172 == 0) {
               PlayerEntity var173 = var141;
               if (var173 == null) {
                  break label109;
               }

               var142 = var19;
            }

            double var36;
            int var147;
            label87: {
               int var146;
               label86: {
                  label110: {
                     PlayerEntity var54 = var142;
                     Vec3d var22 = var54.getEyePos();
                     MinecraftClient var55 = b;
                     ClientPlayerEntity var56 = var55.player;
                     Vec3d var23 = var56.getEyePos();
                     Vec3d var57 = var22;
                     Vec3d var58 = var23;
                     double var24 = var57.x - var58.x;
                     Vec3d var59 = var22;
                     Vec3d var60 = var23;
                     double var26 = var59.y - var60.y;
                     Vec3d var61 = var22;
                     Vec3d var62 = var23;
                     double var28 = var61.z - var62.z;
                     double var63 = var24 * var24 + var28 * var28;
                     double var30 = Math.sqrt(var63);
                     double var210 = -var24;
                     double var67 = var28;
                     double var65 = var210;
                     double var69 = Math.atan2(var65, var67);
                     double var32 = Math.toDegrees(var69);
                     double var73 = var30;
                     double var71 = var26;
                     double var75 = -Math.atan2(var71, var73);
                     double var34 = Math.toDegrees(var75);
                     MinecraftClient var77 = b;
                     ClientPlayerEntity var78 = var77.player;
                     double var79 = var32 - var78.getYaw();
                     var36 = MathHelper.wrapDegrees(var79);
                     MinecraftClient var81 = b;
                     ClientPlayerEntity var82 = var81.player;
                     double var38 = var34 - var82.getPitch();
                     double var83 = var36;
                     double var225;
                     var10000 = (var225 = Math.abs(var83) - 45.0) == 0.0 ? 0 : (var225 < 0.0 ? -1 : 1);
                     int var175 = var15;
                     int var174 = var10000;
                     int var144 = var174;
                     int var143 = var174;
                     if (var175 == 0) {
                        int var176 = var143;
                        if (var176 >= 0) {
                           break label110;
                        }

                        double var86 = var38;
                        double var226;
                        int var177 = (var226 = Math.abs(var86) - 45.0) == 0.0 ? 0 : (var226 < 0.0 ? -1 : 1);
                        var144 = var177;
                     }

                     int var179 = var15;
                     int var178 = var144;
                     var146 = var178;
                     int var145 = var178;
                     if (var179 != 0) {
                        break label86;
                     }

                     int var180 = var145;
                     if (var180 < 0) {
                        var146 = 1;
                        break label86;
                     }
                  }

                  var147 = 0;
                  break label87;
               }

               int var181 = var146;
               var147 = var181;
            }

            int var150;
            label74: {
               int var40 = var147;
               int var183 = var15;
               int var182 = var40;
               int var149 = var182;
               int var148 = var182;
               if (var183 == 0) {
                  int var184 = var148;
                  if (var184 != 0) {
                     var150 = 0;
                     break label74;
                  }

                  var149 = 1;
               }

               int var185 = var149;
               var150 = var185;
            }

            var20 = var150;
            var21 = (float)var36;
         }

         label68: {
            int var187 = var15;
            byte var186 = ((byte)((this.n) ? 1 : 0));
            int var152 = var186;
            byte var151 = var186;
            if (var187 == 0) {
               byte var188 = var151;
               if (var188 != 0) {
                  break label68;
               }

               var152 = var20;
            }

            int var189 = var152;
            if (var189 != 0) {
               this.k = var21;
               this.n = true;
            }
         }

         double var93 = -5.0F * var198;
         float var199 = 1.0F - (float)Math.exp(var93);
         int var190 = var20;
         float var153;
         if (var190 != 0) {
            float var191 = 10.0F;
            var153 = var191;
         } else {
            var153 = 28.0F;
         }

         float var200 = var153;
         double var96 = -var200 * var198;
         float var201 = 1.0F - (float)Math.exp(var96);
         float var98 = var21 - this.k;
         float var25 = MathHelper.wrapDegrees(var98);
         float var99 = this.k + var25 * var199;
         this.k = MathHelper.wrapDegrees(var99);
         int var192 = var20;
         float var154;
         if (var192 != 0) {
            float var193 = 1.0F;
            var154 = var193;
         } else {
            var154 = 0.0F;
         }

         float var202 = var154;
         this.l = this.l + (var202 - this.l) * var201;
         int var196 = var15;
         float var195 = 0.01F;
         float var194 = this.l;
         float var157 = var194;
         float var158 = var195;
         float var155 = var194;
         float var156 = var195;
         if (var196 == 0) {
            float var227;
            int var197 = (var227 = var155 - var156) == 0.0F ? 0 : (var227 < 0.0F ? -1 : 1);
            if (var197 < 0) {
               this.n = false;
               return;
            }

            Matrix4f var103 = var2;
            float var212 = var103.m00();
            Matrix4f var104 = var2;
            float var213 = var212 * var104.m00();
            Matrix4f var105 = var2;
            float var215 = var105.m01();
            Matrix4f var106 = var2;
            float var214 = var213 + var215 * var106.m01();
            Matrix4f var107 = var2;
            var215 = var107.m02();
            Matrix4f var108 = var2;
            var158 = var215 * var108.m02();
            var157 = var214;
         }

         double var109 = var157 + var158;
         float var27 = (float)Math.sqrt(var109);
         MinecraftClient var111 = b;
         Window var112 = var111.getWindow();
         float var203 = var112.getScaledWidth() / 2.0F / var27;
         MinecraftClient var113 = b;
         Window var114 = var113.getWindow();
         float var29 = var114.getScaledHeight() / 2.0F / var27;
         double var115 = this.k;
         double var204 = Math.toRadians(var115);
         double var117 = var204;
         float var205 = (float)Math.sin(var117);
         double var119 = var204;
         float var33 = -((float)Math.cos(var119));
         float var206 = -var33;
         float var35 = var205;
         Object[] var121 = new Object[]{var7};
         Color var207 = ClientUiUtil.dReturningColor(var121);
         double var122 = var16 * 0.012;
         float var37 = 1.0F + 0.18F * (float)Math.sin(var122);
         float var217 = 0.1F * this.l * var37;
         Object[] var10004 = new Object[]{null, null, var11};
         var10004[1] = var217;
         var10004[0] = var207;
         Object[] var124 = var10004;
         int var208 = aReturningInt(var124);
         var217 = 0.22F * this.l * var37;
         var10004 = new Object[]{null, null, var11};
         var10004[1] = var217;
         var10004[0] = var207;
         Object[] var125 = var10004;
         int var39 = aReturningInt(var125);
         Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var9};
         var10014[11] = var208;
         var10014[10] = 6.9F;
         var10014[9] = 7.4F;
         var10014[8] = 13.8F;
         var10014[7] = 18.4F;
         var10014[6] = var35;
         var10014[5] = var206;
         var10014[4] = var33;
         var10014[3] = var205;
         var10014[2] = var29;
         var10014[1] = var203;
         var10014[0] = var2;
         Object[] var126 = var10014;
         r(var126);
         var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var9};
         var10014[11] = var39;
         var10014[10] = 5.7F;
         var10014[9] = 6.2F;
         var10014[8] = 11.4F;
         var10014[7] = 17.2F;
         var10014[6] = var35;
         var10014[5] = var206;
         var10014[4] = var33;
         var10014[3] = var205;
         var10014[2] = var29;
         var10014[1] = var203;
         var10014[0] = var2;
         Object[] var127 = var10014;
         r(var127);
         var217 = this.l;
         var10004 = new Object[]{null, null, var11};
         var10004[1] = var217;
         var10004[0] = var207;
         Object[] var128 = var10004;
         int var209 = aReturningInt(var128);
         var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var9};
         var10014[11] = var209;
         var10014[10] = 4.5F;
         var10014[9] = 5.0F;
         var10014[8] = 9.0F;
         var10014[7] = 16.0F;
         var10014[6] = var35;
         var10014[5] = var206;
         var10014[4] = var33;
         var10014[3] = var205;
         var10014[2] = var29;
         var10014[1] = var203;
         var10014[0] = var2;
         Object[] var129 = var10014;
         r(var129);
      }
   }

   private static void r(Object[] var0) {
      Matrix4f var12 = (Matrix4f)var0[0];
      float var10 = (Float)var0[1];
      float var14 = (Float)var0[2];
      float var4 = (Float)var0[3];
      float var13 = (Float)var0[4];
      float var5 = (Float)var0[5];
      float var7 = (Float)var0[6];
      float var6 = (Float)var0[7];
      float var3 = (Float)var0[8];
      float var9 = (Float)var0[9];
      float var11 = (Float)var0[10];
      int var8 = (Integer)var0[11];
      long var1 = (Long)var0[12];
      var1 = 55078432665304L ^ var1;
      long var15 = var1 ^ 124268784105735L;
      float var17 = var10 + var4 * var6;
      float var18 = var14 + var13 * var6;
      float var19 = -var4 * var3;
      float var20 = -var13 * var3;
      float var21 = var5 * var9;
      float var22 = var7 * var9;
      float var23 = var17 + var19 + var21;
      float var24 = var18 + var20 + var22;
      float var25 = var17 + var19 - var21;
      float var26 = var18 + var20 - var22;
      float var27 = var17 - var4 * var11;
      float var28 = var18 - var13 * var11;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, null, var15};
      var10010[7] = var8;
      var10010[6] = var24;
      var10010[5] = var23;
      var10010[4] = var28;
      var10010[3] = var27;
      var10010[2] = var18;
      var10010[1] = var17;
      var10010[0] = var12;
      Object[] var29 = var10010;
      ShapeRenderer.kReturningVoid(var29);
      var10010 = new Object[]{null, null, null, null, null, null, null, null, var15};
      var10010[7] = var8;
      var10010[6] = var28;
      var10010[5] = var27;
      var10010[4] = var26;
      var10010[3] = var25;
      var10010[2] = var18;
      var10010[1] = var17;
      var10010[0] = var12;
      Object[] var30 = var10010;
      ShapeRenderer.kReturningVoid(var30);
   }

   private static int aReturningInt(Object[] var0) {
      Color var2 = (Color)var0[0];
      float var1 = (Float)var0[1];
      long var3 = (Long)var0[2];
      var3 = 55078432665304L ^ var3;
      long var5 = var3 ^ 136142941853123L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var1;
      Object[] var8 = var10004;
      float var9 = 255.0F * cReturningFloat(var8);
      int var7 = Math.round(var9);
      Color var10 = var2;
      int var10002 = var10.getRed();
      Color var11 = var2;
      int var10003 = var11.getGreen();
      Color var12 = var2;
      Color var13 = new Color(var10002, var10003, var12.getBlue(), var7);
      return var13.getRGB();
   }

   private static float cReturningFloat(Object[] var0) {
      float var3 = (Float)var0[0];
      long var1 = (Long)var0[1];
      long var10000 = 55078432665304L ^ var1;
      int var4 = Event.cReturningInt();
      int var16 = var4;
      float var15 = 0.0F;
      float var14 = var3;
      float var11 = var14;
      float var12 = var15;
      float var9 = var14;
      float var10 = var15;
      if (var16 != 0) {
         float var19;
         int var17 = (var19 = var9 - var10) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
         if (var17 < 0) {
            return 0.0F;
         }

         var12 = 1.0F;
         var11 = var3;
      }

      float var8 = var12;
      float var7 = var11;
      return Math.min(var7, var8);
   }

   static {

      {

      b();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(92096315928056L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[2];
      String var17 = "|\u009e\u008dþ\u0002L\u000ek\\!\u008eû\u0000\u00058\u008dÁn\u0016±yHÌ\u0082¦Ó®1\u001fR\u000b½`1á\u0090=\u008fÍ{°\u0014å\u0098TÃÃWÔ`ÜæëÈÀÒu:c«\u0090Må¥Ì\u0000\u001b\u0091=d»Ý%\u007fF_Ò§*3\u001eÑú\\Tey\u00982Ô\u000fØÛ\u0007\u0013&p\u008f>\u009eêHB=\u0095ßi|Åß\u0013ÝË°.w)\na\u008d¬9ÊXq\u0019\u0083\u0004\u007f";
      int var19 = "|\u009e\u008dþ\u0002L\u000ek\\!\u008eû\u0000\u00058\u008dÁn\u0016±yHÌ\u0082¦Ó®1\u001fR\u000b½`1á\u0090=\u008fÍ{°\u0014å\u0098TÃÃWÔ`ÜæëÈÀÒu:c«\u0090Må¥Ì\u0000\u001b\u0091=d»Ý%\u007fF_Ò§*3\u001eÑú\\Tey\u00982Ô\u000fØÛ\u0007\u0013&p\u008f>\u009eêHB=\u0095ßi|Åß\u0013ÝË°.w)\na\u008d¬9ÊXq\u0019\u0083\u0004\u007f"
         .length();
      char var16 = ' ';
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var27 = b(var21).intern();
         int var10001 = -1;
         var20[var18++] = var27;
         if ((var15 += var16) >= var19) {
            w = var20;
            x = new String[2];
            D = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(92096315928056L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[2];
            String var4 = "\u009595è\\«åh£.\u00ad2¢¨i½";
            int var5 = "\u009595è\\«åh£.\u00ad2¢¨i½".length();
            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               // var6[var10001] = var10004;
            } while (var2 < var5);

            B = var6;
            C = new Long[2];
            break;
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8559;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/b_", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b_",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 23228;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/b_", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b_",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = I[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = H[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 4;
            yield var15;
         }
         case 1 -> {
            byte var16 = 31;
            yield var16;
         }
         case 2 -> {
            byte var17 = 18;
            yield var17;
         }
         case 3 -> {
            byte var18 = 21;
            yield var18;
         }
         case 4 -> {
            byte var19 = 11;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 33;
            yield var22;
         }
         case 8 -> {
            byte var23 = 38;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 49;
            yield var26;
         }
         case 12 -> {
            byte var27 = 19;
            yield var27;
         }
         case 13 -> {
            byte var28 = 7;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 9;
            yield var30;
         }
         case 16 -> {
            byte var31 = 27;
            yield var31;
         }
         case 17 -> {
            byte var32 = 58;
            yield var32;
         }
         case 18 -> {
            byte var33 = 29;
            yield var33;
         }
         case 19 -> {
            byte var34 = 34;
            yield var34;
         }
         case 20 -> {
            byte var35 = 53;
            yield var35;
         }
         case 21 -> {
            byte var36 = 54;
            yield var36;
         }
         case 22 -> {
            byte var37 = 22;
            yield var37;
         }
         case 23 -> {
            byte var38 = 46;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 51;
            yield var40;
         }
         case 26 -> {
            byte var41 = 48;
            yield var41;
         }
         case 27 -> {
            byte var42 = 15;
            yield var42;
         }
         case 28 -> {
            byte var43 = 37;
            yield var43;
         }
         case 29 -> {
            byte var44 = 62;
            yield var44;
         }
         case 30 -> {
            byte var45 = 61;
            yield var45;
         }
         case 31 -> {
            byte var46 = 55;
            yield var46;
         }
         case 32 -> {
            byte var47 = 2;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 56;
            yield var49;
         }
         case 35 -> {
            byte var50 = 5;
            yield var50;
         }
         case 36 -> {
            byte var51 = 23;
            yield var51;
         }
         case 37 -> {
            byte var52 = 50;
            yield var52;
         }
         case 38 -> {
            byte var53 = 57;
            yield var53;
         }
         case 39 -> {
            byte var54 = 28;
            yield var54;
         }
         case 40 -> {
            byte var55 = 39;
            yield var55;
         }
         case 41 -> {
            byte var56 = 14;
            yield var56;
         }
         case 42 -> {
            byte var57 = 10;
            yield var57;
         }
         case 43 -> {
            byte var58 = 16;
            yield var58;
         }
         case 44 -> {
            byte var59 = 47;
            yield var59;
         }
         case 45 -> {
            byte var60 = 40;
            yield var60;
         }
         case 46 -> {
            byte var61 = 52;
            yield var61;
         }
         case 47 -> {
            byte var62 = 32;
            yield var62;
         }
         case 48 -> {
            byte var63 = 1;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 0;
            yield var65;
         }
         case 51 -> {
            byte var66 = 26;
            yield var66;
         }
         case 52 -> {
            byte var67 = 42;
            yield var67;
         }
         case 53 -> {
            byte var68 = 44;
            yield var68;
         }
         case 54 -> {
            byte var69 = 17;
            yield var69;
         }
         case 55 -> {
            byte var70 = 6;
            yield var70;
         }
         case 56 -> {
            byte var71 = 13;
            yield var71;
         }
         case 57 -> {
            byte var72 = 35;
            yield var72;
         }
         case 58 -> {
            byte var73 = 60;
            yield var73;
         }
         case 59 -> {
            byte var74 = 12;
            yield var74;
         }
         case 60 -> {
            byte var75 = 41;
            yield var75;
         }
         case 61 -> {
            byte var76 = 59;
            yield var76;
         }
         case 62 -> {
            byte var77 = 45;
            yield var77;
         }
         default -> 24;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            I[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      H[0] = ":wS!\u000331xBn`>$~";
      H[1] = float.class;
      I[1] = "java/lang/Float";
      H[2] = int.class;
      I[2] = "java/lang/Integer";
      H[3] = "\t_-0\u0004%\u0014Ju\u0012E(\fL";
      H[4] = ";\u0017\u0000Ve\u000e-\u0017\u0005\fv\u0019:\\\u0006\nz\r+\u001b\u0011\u001d1\u001c\u0000";
      H[5] = "^\u0018\b@yr+8\u0003Oh=J6\bDlg>";
      H[6] = "]6;2P\u0003V9*}3\u000eC4%\u0016\u0006\fR'9:\u0011\u0001";
      H[7] = "Y| b+\u007fO|%88hX7&>4|Ip1)\u007fnx";
      H[8] = "kE \"\u0018\u0016\u001ee+-\tY\u007fk &\r\u0003\u000b";
      H[9] = void.class;
      I[9] = "java/lang/Void";
      H[10] = double.class;
      I[10] = "java/lang/Double";
      H[11] = "\u0016bWbkv\u0016b@>gy\f)@ gl\u000bX\u0012|2.";
      H[12] = "w^*{!Y|Q;4\\LnK9w";
      H[13] = long.class;
      I[13] = "java/lang/Long";
      H[14] = "Q^\u0012'C4Q^\u0005{O;K\u0015\u0005eO.LdQ=\u0018";
      H[15] = "Ry\\'%NDyY}6YS2Z{:MBuMlq\\\u0007";
      H[16] = "\u0010BGp)\u001debL\u007f8R\u0004lGt<\bp";
      H[17] = "??\u001a'I1??\r{E>%t\reE+\"\u0005\\=\u0017";
      H[18] = "2-< L\u001c2-+|@\u0013(f+b@\u0006/\u0017y8\u0014B";
      H[19] = "Cc1e\\}Cc&9PrY(&'Pg^Yvz\u0001";
      H[20] = "\"j%n#v\"j22/y8!2,/l?Pbu}-";
      H[21] = "\u0005Ch02\"\u0007]!S99\u0018Xw*>";
      H[22] = "2\u0018+9hn$\u0018.c{y3S-ewm\"\u0014:r<\u007f\u0014";
      H[23] = "(\u0019|Et\r]9wJeB<7|Aa\u0018H";
      H[24] = "W(\u0015(>\\A(\u0010r-KVc\u0013t!_G$\u0004cjJf";
      H[25] = ",a#6\u0011]YA(9\u0000\u00128O#2\u0004HL";
      H[26] = "/=?\u001f.\u0005/=(C\"\n5v(]\"\u001f2\u0007}\u0002{";
      H[27] = "-R6\u001fQ?Xr=\u0010@p9|6\u001bD*M";
      H[28] = "t 5P0Tb 0\n#Cuk3\f/Wd,$\u001bd@f";
      H[29] = "Y\u00025Jk;,\">EztM,5N~.9";
      H[30] = "tDFnax\u007fKW!\u0000vt@S{";
      H[31] = "4C~'WJ?\u0000z2j\u0001\u000eRw7\u0003\u0017s\u0001o>W{0Ln!Q\t3Tnqj";
      H[32] = "]3\u0005\u001b\\a\u0019n\u001fJci`4\u000bO\u001a~\rb\u001eZ\u0013\u0003";
      H[33] = "-\u0007U1sWi\u0002NK1\u0006wm\u0001/0\u0016\u007f\u0013\\3t\\\u0011RZ1;\to\u000fFuqg";
      H[34] = "\u0002\nQ!\u0004\t\\^_.<R_LU7P`\u000e\r\rj<\u000eWYL-QXBLEP";
      H[35] = "^r}2\u000e@V,>~r\u0011\u0013i>/\u0014\u00062r!/7\u001b\nw%9rKVm<r\u0014B\u0016(#B";
      H[36] = "\u0016\u001eGYx)\u0016\u0007I_\u0004#J\u001dF\u0004h\u0011\u001c_\u001a^8F[\u0013K\u001c?}X[[c";
      H[37] = "F4Qo'|\u00021J\u0015s<\u0002^\u0005qd=\u0014 Xm wza^oo\"\u0004<B+%L";
      H[38] = "?=7sTR{8,\t\b\u0003eW {\u0000\u001d8l#3\u0010b\u007f%1vVY|m!\t\u0011\u0010n(g2\u0012X~W";
      H[39] = "\u0001T#7\t\u001eE\t9f6\u0017<S-cO\u0001Q\u00058vF|";
      H[40] = "\u0004\u000f~SS\n\u0001Ys\u0017h\u0005m\u0001aQ\u0001\b\u0010RyXUdS\u001fxGS\u0016P\u0007x\u0017h";
      H[41] = "0TE)&H4Z_sE\u0016;HJ\"\u0012Aa\u0018\u0016Nz\u001c T@0'\u0000d\u001e";
      H[42] = "]C>p\u0003\u000b]Z0v\u007f\u0001\u0001@?-\u00133W\u0002cwBd\u0010N25D_\u0013\u0006\"J";
      H[43] = "<7\u0000\u0001:\u0006x2\u001b{\u007fQZ4\u0007\u001ajP{]T\u001fyGn#\t\u0003=\r\u0000b\u000f\u0001rX~?\u0013E86";
      H[44] = "y?Sfn/wvF!\u0014#\u007f3Oyx\u0011)t\u0012!-Fx>Dywv|0^#\u0014";
      H[45] = "D\u0005QQH9\u0000\u0000J+\u001an\u0003o\u0005O\u000bx\u0016\u0011XSO2xP^Q\u0000g\u0006\rB\u0015J\t";
      H[46] = "B\u000fw{9nW\bx,\u0007qO\bs-P&\u0011_+A6`O_k.6yAY";
      H[47] = "tX5f(\u00060].\u001cmQ\u0004_1f|[32axkG&L<d/\rH\r:f`X6P&\"*6";
      H[48] = "i0A\u001f\tr-5ZeK;/&*ZT8$4T\u0007H|nZ\u0015\u0001J3;$H\u001d\u000eyU";
      H[49] = "Q., \u0011'D)#w/3P8,}C\u0001\u0007~r*\u0014V\r~(k\u0017hS*&d/";
      H[50] = "\u001a2/,\u001aX\u0015d=*'\u0000\u001a#6,K2Nbmp\u0017eH;,:I\u001b\u0015'hp'Z\u0013%'%Y\u0007\u000famK";
      H[51] = "$<=7O?+j/1rg$-$7\u001eUpl\u007faI\u00025#)/I96k9P\u000ep$.\u007fk\r84Q";
      H[52] = "\u0003GE+\t\u0002_\u0007L=7\u0014T\u0007&4[{\u0000\u001e\u0015 J\u0016V\u000b\u0000)7";
      H[53] = "\u001b5~@m\u0007J1,\u0000\u0010\u0007M1\u001dCb\u000f\n2&@*\u001fu";
      H[54] = "O3rH\u0001|O*|N}v\u00130s\u0015\u0011DEw.MD\u0013\u0014=x\u0015\u001e#\u00103bO}";
      H[55] = "pHNM0h{\u000bJX\r0J\u0006\u001aH18u\u000bG_4Yv\u0004H\u0018lf{Y_\u001d\r";
      H[56] = "=\u0014A\u000fEPl\u0010\u0013O8Pk\u0012\"\fJX,\u0013\u0019\u000f\u0002HS";
      H[57] = "\u0005Y.1\u001a4\u0001W4kyj\u000eE!:.=T\u0015\u007fVF`\u0015Y+(\u001b|Q\u0013";
      H[58] = "\u0013$\u0010\f\u0011\u0016\u0017*\nVrH\u00188\u001f\u0007%\u001fBhBkMB\u0003$\u0015\u0015\u0010^Gn";
      H[59] = "YutbpqK/zc\u001c#7|zzu#J/bs!O\r# q\"6Qc)g\u001c";
      H[60] = "^?N\u001fJ\u001a\u001a:Ue\tM\u001f3Ie\u000fX\u000f*\u001e^\f\u0010\u001fU\u001c\u0000\u001aS\u001f8J\u0015\u000fZb";
      H[61] = "\u0019C<\u001a:]E\u00035\f\u0004KN\u0003O\fyI#F`\u0001}YN\u0010u\u0014t$";
      H[62] = "O!{\u001f.PFu9ZP^/s'X9[R ?Qm7D`8Y*^J)-\u001eP";
      H[63] = "pnon\u0002\u00074kt\u0014RK%b>\u0014\u0004S6ujjYOr?\u0004+_M=jzvC\tw\u0004;pAF\"zfl\u0005\fL";
      H[64] = "\u0016i\u0010\ni?\u0003n\u001f]W \u001bn\u0014\\\u0000wD3O06\u007f\u0003i\u0014\f;5\u0002z";
      H[65] = "\u000ew~PA?Jre*\u0011eI\u001d*N\u0002~\\cwRF42\"qP\taL\u007fm\u0014C\u000f";
      H[66] = "a\"k/<\u0005r<{0\u0002\u0007\u0003>d9k\b~m|0?d= }/9\u0016>8}\u007f\u0002";
      H[67] = "\u000f\rd \u0007B\u0004N`5:\u00185\u001cm0S\u001fHOu9\u0007sI\rc6\u0001HJEsI";
      H[68] = "\u0000QD\u001e(-\\\u0011M\b\u0016;W\u0011'#\\T\u0003\b\u0014\u0015k9U\u001d\u0001\u001c\u0016";
      H[69] = "\u0005X^4O%\u000e\u001bZ!r}?IW$\u001bxB\u001aO-O\u0014\u0006O]$\u000fyPZH-r";
      H[70] = "Di\u000eAe\u0004\u0015m\\\u0001\u0018\u0004\u0012lmBj\fUnVA\"\u001c*";
      H[71] = "YuYD$R\u0007!WK\u001c\t\u00043]Rp;Us\r\u000b\u001cU\f&DHq\u0003\u00193M5";
      H[72] = "5Yg\u001b$Gi\u0019n\r\u001aQb\u0019\u0011\u0013wSieg\fsGr\b1\u0019fN\u000f";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = H[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(I[var4]);
            H[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = H[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = I[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            H[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  H[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(2166507332157251L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = H[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = I[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  H[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(2166507332157251L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        H[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(2166507332157251L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 116;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 103;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 86;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 216;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 181;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 78;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 116;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 103;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 86;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/b_",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/b_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
