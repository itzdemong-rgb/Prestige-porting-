package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;

import org.joml.Matrix4f;
import java.util.HashSet;
import net.minecraft.client.network.ClientPlayerEntity;
import java.util.Iterator;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.entity.effect.StatusEffectInstance;
import org.joml.Vector4f;



import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.entity.effect.StatusEffect;

public class PotionDisplayWidget extends HudElement {
   private static final float m = 0.65F;
   private final Map a;
   private ManagedGlTexture c;
   private float g;
   private float h;
   private float k;
   private static long d;
   private static final long v = 20368215036302L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final Object[] H = new Object[136];
   private static final String[] I = new String[136];
   private static volatile MethodHandle bindingCache1;

   public PotionDisplayWidget(long var1) {
      super("Potion Display", "Show active potion effects with duration and level", ((20368215036302L ^ (20368215036302L ^ var1)) ^ 75207908575369L));
      var1 = 20368215036302L ^ var1;
      long var3 = var1 ^ 75207908575369L;
      short var10001 = 14391;
      long var10002 = 6079075589830401708L ^ var1;
      short var6 = 3011;
      long var10003 = 5655492246017568090L ^ var1;

      this.a = new LinkedHashMap();
      this.g = 70.0F;
      this.h = 0.0F;
      this.k = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 100.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      PotionDisplayWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   protected String bReturningString(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 20368215036302L ^ var2;
      int var5 = Event.bReturningInt();
      int var16 = var5;
      int var15 = var4;
      int var11 = var15;
      int var10 = var15;
      if (var16 == 0) {
         int var17 = var10;
         switch (var17) {
            case 1:
               return "I";
            case 2:
               short var38 = 16421;
               long var44 = 4322753214967095151L ^ var2;
               return "II";
            case 3:
               short var37 = 2405;
               long var43 = 3054545642713929249L ^ var2;
               return "III";
            case 4:
               short var36 = 10381;
               long var42 = 2539635986398902213L ^ var2;
               return "IV";
            case 5:
               return "V";
            case 6:
               short var35 = 11394;
               long var41 = 8354621610846188494L ^ var2;
               return "VI";
            case 7:
               short var34 = 25748;
               long var40 = 8886262452296760275L ^ var2;
               return "VII";
            case 8:
               short var33 = 30321;
               long var39 = 8981411281583614257L ^ var2;
               return "VIII";
            case 9:
               short var10000 = 12121;
               long var10001 = 4615323620995297311L ^ var2;
               return "IX";
            case 10:
               return "X";
            default:
               var11 = var4;
         }
      }

      int var29 = var5;
      int var28 = var11;
      int var13 = var28;
      int var12 = var28;
      if (var29 == 0) {
         int var30 = var12;
         if (var30 <= 0) {
            return "I";
         }

         var13 = var4;
      }

      int var9 = var13;
      return String.valueOf(var9);
   }

   protected String cReturningString(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 20368215036302L ^ var3;
      short var10001 = 22656;
      long var10002 = 5011754563355448901L ^ var3;
      int var5 = var2 / 20;
      var10001 = 13399;
      var10002 = 1600514502273530520L ^ var3;
      int var6 = var5 / 60;
      var10001 = 28723;
      var10002 = 4004378435612655354L ^ var3;
      int var7 = var5 % 60;
      int var16 = var6;
      if (var16 > 0) {
         short var18 = 32652;
         long var23 = 4293151547550607345L ^ var3;
         Object[] var24 = new Object[2];
         int var8 = var6;
         var24[0] = var8;
         int var9 = var7;
         var24[1] = var9;
         Object[] var11 = var24;
         String var10 = "%d:%02d";
         return String.format(var10, var11);
      } else {
         short var10000 = 5394;
         long var21 = 3563527452875541859L ^ var3;
         Object[] var22 = new Object[1];
         int var13 = var7;
         var22[0] = var13;
         Object[] var15 = var22;
         String var14 = "0:%02d";
         return String.format(var14, var15);
      }
   }

   @Override
    public void lReturningVoid(final Object[] array) {
        final MeshBufferManager an_C0030 = (MeshBufferManager)array[0];
        final RenderContext gz_C0376 = (RenderContext)array[1];
        final Matrix4f matrix4f = (Matrix4f)array[2];
        final long longValue = (long)array[3];
        final long n = longValue ^ 0x6B560F5AFA42L;
        final long n2 = longValue ^ 0x2C767EA68D6FL;
        final long n3 = longValue ^ 0x212D28D521A0L;
        final long n4 = longValue ^ 0xC606812DAEDL;
        final long n5 = longValue ^ 0x1AA7A1481CE3L;
        final long l = longValue ^ 0x67249AAEC02BL;
        final long n6 = longValue ^ 0xF8994B0FDFBL;
        final long i = longValue ^ 0x3765B24B3906L;
        final long j = longValue ^ 0x339F829007BBL;
        final long n7 = longValue ^ 0x4AF0133AEE31L;
        final long k = longValue ^ 0x428E8830D13EL;
        final long m = longValue ^ 0x2D68E3B2CAB7L;
        final long n8 = longValue ^ 0x2578277D1F90L;
        final long n9 = longValue ^ 0x1B1D13ECDE78L;
        final long l2 = longValue ^ 0x7168B300EC88L;
        final long n10 = longValue ^ 0x49B7DF5831AFL;
        final long n11 = longValue ^ 0x7365594770B5L;
        final long l3 = longValue ^ 0x682C874FF4BDL;
        final long l4 = longValue ^ 0x2E7AEFEB5E22L;
        final long n12 = longValue ^ 0x2A758A083511L;
        final int cReturningInt;
        final int n13 = cReturningInt = Event.cReturningInt();
        PotionDisplayWidget ca_C0112 = this;
        Label_0304: {
            if (cReturningInt != 0) {
                if (this.c != null) {
                    break Label_0304;
                }
                ca_C0112 = this;
            }
            ca_C0112.c = TextureLoader.aReturningbT_C0095(new Object[] { "assets/prestige/icons/hud/potion.png", j });
        }
        final float f = (System.currentTimeMillis() - dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget.d) * 0.005f;
        dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget.d = System.currentTimeMillis();
        final HashSet set = new HashSet();
        final ClientPlayerEntity player = dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget.b.player;
        final int n14 = n13;
        final ClientPlayerEntity clientPlayerEntity;
        ClientPlayerEntity player2 = clientPlayerEntity = player;
    Label_1798:
        while (true) {
            Iterator<Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance>> iterator = null;
            Map.Entry<RegistryEntry, StatusEffectInstance> entry = null;
            Object value = null;
            Label_1528: {
                Label_1436: {
                    if (n14 != 0) {
                        if (clientPlayerEntity == null) {
                            break Label_1436;
                        }
                        player2 = dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget.b.player;
                    }
                    iterator = player2.getActiveStatusEffects().entrySet().iterator();
                Label_0465:
                    while (true) {
                        Iterator<Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance>> iterator2 = iterator;
                        while (iterator2.hasNext()) {
                            final Iterator<Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance>> iterator3 = iterator;
                            final int n15 = n13;
                            final Iterator<Map.Entry<RegistryEntry<StatusEffect>, StatusEffectInstance>> iterator4;
                            iterator2 = (iterator4 = iterator3);
                            if (n15 != 0) {
                                entry = ((Iterator<Map.Entry<RegistryEntry, StatusEffectInstance>>)((java.util.Iterator)(Object)(iterator4))).next();
                                final StatusEffect key = ((net.minecraft.entity.effect.StatusEffect)(Object)(((Map.Entry<RegistryEntry, Object>)((java.util.Map.Entry)(Object)(entry))).getKey().value()));
                                final StatusEffectInstance statusEffectInstance = ((Map.Entry<Object, StatusEffectInstance>)((java.util.Map.Entry)(Object)(entry))).getValue();
                                final StatusEffect statusEffect = key;
                                final int n16 = n13;
                                final StatusEffect statusEffect2;
                                value = (statusEffect2 = statusEffect);
                                if (n16 == 0) {
                                    break Label_1528;
                                }
                                if (statusEffect2 == null) {
                                    continue Label_0465;
                                }
                                final StatusEffectInstance statusEffectInstance2 = statusEffectInstance;
                                final int n17 = n13;
                                final StatusEffectInstance statusEffectInstance4;
                                StatusEffectInstance statusEffectInstance3 = statusEffectInstance4 = statusEffectInstance2;
                                if (n17 != 0) {
                                    if (statusEffectInstance4 == null) {
                                        continue Label_0465;
                                    }
                                    statusEffectInstance3 = statusEffectInstance;
                                }
                                final boolean infinite = statusEffectInstance3.isInfinite();
                                final int n18 = n13;
                                final boolean b = infinite;
                                Label_0896: {
                                    if (n18 != 0) {
                                        if (!b) {
                                            final int duration = statusEffectInstance.getDuration();
                                            final int n19 = n13;
                                            final int n20 = duration;
                                            if (n19 == 0) {
                                                break Label_0896;
                                            }
                                            if (n20 <= 0) {
                                                continue Label_0465;
                                            }
                                        }
                                        set.add(key);
                                    }
                                }
                                final PotionDisplayEntry c6;
                                final PotionDisplayEntry c5 = c6 = ((dev.zprestige.prestige.client.ui.hud.PotionDisplayEntry)(Object)(this.a.computeIfAbsent(key, invokeBinding1())));
                                final String string = key.getName().getString();
                                final int n21 = n13;
                                final String s = string;
                                final PotionDisplayEntry c7 = c6;
                                final String s2 = s;
                                final PotionDisplayEntry c8 = c7;
                                final String a = s;
                                PotionDisplayEntry c12;
                                String b2;
                                if (n21 != 0) {
                                    c8.a = a;
                                    final PotionDisplayEntry c9 = c5;
                                    final int amplifier = statusEffectInstance.getAmplifier();
                                    final PotionDisplayEntry c10 = c9;
                                    if (amplifier > 0) {
                                        final PotionDisplayEntry c11 = c10;
                                        final String bReturningString = this.bReturningString(new Object[] { statusEffectInstance.getAmplifier() + 1, l3 });
                                        c12 = c11;
                                        b2 = bReturningString;
                                    }
                                    else {
                                        final PotionDisplayEntry c13 = c10;
                                        b2 = null;
                                        c12 = c13;
                                    }
                                }
                                else {
                                    final PotionDisplayEntry c14 = c7;
                                    final String s3 = s2;
                                    c12 = c14;
                                    b2 = s3;
                                }
                                c12.b = b2;
                                c5.c = bReturningColor(new Object[] { new Color(key.getColor()), l4 });
                                c5.f = statusEffectInstance.isInfinite();
                                c5.d = statusEffectInstance.getDuration();
                                final PotionDisplayEntry c15 = c5;
                                final int n22 = n13;
                                final PotionDisplayEntry c17;
                                PotionDisplayEntry c16 = c17 = c15;
                                Label_1423: {
                                    if (n22 != 0) {
                                        if (c17.d <= c5.e) {
                                            break Label_1423;
                                        }
                                        c16 = c5;
                                    }
                                    c16.e = c5.d;
                                }
                                if (n13 == 0) {
                                    break;
                                }
                                continue Label_0465;
                            }
                        }
                        break;
                    }
                }
                iterator = this.a.entrySet().iterator();
                if (!iterator.hasNext()) {
                    break Label_1798;
                }
                entry = ((Iterator<Map.Entry<RegistryEntry, StatusEffectInstance>>)((java.util.Iterator)(Object)(iterator))).next();
                value = ((Map.Entry<Object, Object>)((java.util.Map.Entry)(Object)(entry))).getValue();
            }
            final PotionDisplayEntry c18 = (PotionDisplayEntry)value;
            float n23;
            if (set.contains(((Map.Entry<Object, Object>)((java.util.Map.Entry)(Object)(entry))).getKey())) {
                n23 = 1.0f;
            }
            else {
                n23 = 0.0f;
            }
            final float f2 = n23;
            c18.g = ClientUiUtil.bReturningFloat(new Object[] { c18.g, f2, f, n8 });
            final float n24 = dev.prestige.recovery.SourceSupport.fcmpl(f2, 0.0f);
            final int n25 = n13;
            final float n27;
            float n26 = n27 = n24;
            Label_1785: {
                if (n25 != 0) {
                    if (n27 != 0) {
                        break Label_1785;
                    }
                    n26 = dev.prestige.recovery.SourceSupport.fcmpg(c18.g, 0.02f);
                }
                if (n26 < 0) {
                    iterator.remove();
                }
            }
            if (n13 != 0) {
                continue;
            }
            break;
        }
        final float cReturningFloat = Prestige.c.aReturningcx_C0158(new Object[] { n4 }).cReturningFloat(new Object[] { m });
        final float aReturningFloat = UiMetrics.aReturningFloat(new Object[] { cReturningFloat, 1.0f });
        final float aReturningFloat2 = UiMetrics.aReturningFloat(new Object[] { cReturningFloat, 0.9f });
        final float n28 = 23.0f;
        float max = Math.max(70.0f, n28 + Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { "Potions", n10 }) + 5.5f);
        float n29 = aReturningFloat;
        while (true) {
            for (PotionDisplayEntry c19 : ((java.lang.Iterable<PotionDisplayEntry>)(Object)(this.a.values()))) {
                final float g = c19.g;
                final float n30 = 0.02f;
                final int n31 = n13;
                final float n32 = n30;
                float n33 = g;
                float n34 = n32;
                final float n35 = n33;
                final float n36 = n32;
                if (n31 != 0) {
                    final float n37 = dev.prestige.recovery.SourceSupport.fcmpg(n35, n36);
                    final int n38 = n13;
                    final float n39;
                    final float dReturningBoolean = n39 = n37;
                    if (n38 == 0) {
                        final float n40 = dReturningBoolean;
                        final boolean cReturningBoolean = this.cReturningBoolean(new Object[0]);
                        final boolean b3 = dev.zprestige.prestige.client.ui.hud.PotionDisplayWidget.b.currentScreen instanceof HudEditorScreen;
                        float e = 0.0f;
                        Label_3465: {
                            if (n13 != 0) {
                                Label_3399: {
                                    if (!b3) {
                                        final float n41 = n40;
                                        final int n42 = n13;
                                        final float n44;
                                        float n43 = n44 = n41;
                                        Label_3230: {
                                            if (n42 != 0) {
                                                if (n44 != 0) {
                                                    final float n45 = dev.prestige.recovery.SourceSupport.fcmpl(this.h, 0.0f);
                                                    final int n46 = n13;
                                                    final float n47;
                                                    n43 = (n47 = n45);
                                                    if (n46 == 0) {
                                                        break Label_3230;
                                                    }
                                                    if (n47 > 0) {
                                                        this.f -= n29 - this.h;
                                                    }
                                                }
                                                n43 = (cReturningBoolean ? 1 : 0);
                                            }
                                        }
                                        final float n48 = n43;
                                        final int n49 = n13;
                                        final float n51;
                                        float n50 = n51 = n48;
                                        if (n49 != 0) {
                                            if (n51 == 0) {
                                                break Label_3399;
                                            }
                                            final float k2 = this.k;
                                            final int n52 = n13;
                                            final float n53;
                                            e = (n53 = k2);
                                            if (n52 == 0) {
                                                break Label_3465;
                                            }
                                            n50 = dev.prestige.recovery.SourceSupport.fcmpl(n53, 0.0f);
                                        }
                                        if (n50 > 0) {
                                            this.e -= this.g - this.k;
                                        }
                                    }
                                }
                                this.h = n29;
                                this.k = this.g;
                                this.iReturningVoid(new Object[] { this.g, n29 });
                            }
                            e = this.e;
                        }
                        final float n54 = e;
                        float f3;
                        if (n40 != 0) {
                            f3 = this.f + n29 - aReturningFloat;
                        }
                        else {
                            f3 = this.f;
                        }
                        final float n55 = f3;
                        BlurredRectangleRenderer.eReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, n54, n55, this.g, aReturningFloat, 5, 4.0f, n2 });
                        FilledRectangleRenderer.cReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, n54, n55, this.g, aReturningFloat, UiMetrics.r, 4.0f, n5 });
                        final String s4 = "Potions";
                        final float n56 = n55 + (aReturningFloat - 7.5f) / 2.0f;
                        final float n57 = n55 + 3.0f;
                        float n58 = 0.0f;
                        Label_5248: {
                            Label_5235: {
                                Label_5198: {
                                    if (n13 != 0) {
                                        if (cReturningBoolean) {
                                            TexturedRectangleRenderer.cReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, this.c, n54 + this.g - 5.5f - 7.5f, n56, 7.5f, 7.5f, ClientUiUtil.dReturningColor(new Object[] { n3 }), n6 });
                                            final float f4 = n54 + this.g - 18.0f;
                                            ShapeRenderer.lReturningVoid(new Object[] { matrix4f, f4 - 0.5f, n55 + 3.0f, f4, n55 + aReturningFloat - 3.0f, UiMetrics.v, l2 });
                                            float f5 = n54 + this.g - n28 - Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { s4, n10 });
                                            int index = 0;
                                            while (index < s4.length()) {
                                                final String value2 = String.valueOf(s4.charAt(index));
                                                Prestige.c.aReturningcx_C0158(new Object[] { n4 }).v(new Object[] { matrix4f, value2, f5, n57, GameRenderUtil.bReturningColor(new Object[] { ClientUiUtil.dReturningColor(new Object[] { n3 }), 10, 10 + (s4.length() - 1 - index), n11 }), n12 });
                                                f5 += Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { value2, n10 });
                                                ++index;
                                                if (n13 == 0) {
                                                    break Label_5198;
                                                }
                                                if (n13 == 0) {
                                                    break;
                                                }
                                            }
                                            if (n13 != 0) {
                                                break Label_5198;
                                            }
                                        }
                                        TexturedRectangleRenderer.cReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, this.c, n54 + 5.5f, n56, 7.5f, 7.5f, ClientUiUtil.dReturningColor(new Object[] { n3 }), n6 });
                                    }
                                    final float f6 = n54 + 5.5f + 7.5f + 5.0f;
                                    ShapeRenderer.lReturningVoid(new Object[] { matrix4f, f6, n55 + 3.0f, f6 + 0.5f, n55 + aReturningFloat - 3.0f, UiMetrics.v, l2 });
                                    float f7 = n54 + n28;
                                    int index2 = 0;
                                    while (index2 < s4.length()) {
                                        final String value3 = String.valueOf(s4.charAt(index2));
                                        Prestige.c.aReturningcx_C0158(new Object[] { n4 }).v(new Object[] { matrix4f, value3, f7, n57, GameRenderUtil.bReturningColor(new Object[] { ClientUiUtil.dReturningColor(new Object[] { n3 }), 10, 10 + index2, n11 }), n12 });
                                        f7 += Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { value3, n10 });
                                        ++index2;
                                        if (n13 == 0) {
                                            break Label_5235;
                                        }
                                        if (n13 == 0) {
                                            break;
                                        }
                                    }
                                }
                                if (n40 != 0) {
                                    n58 = n55 - 3.0f - aReturningFloat2;
                                    break Label_5248;
                                }
                            }
                            n58 = n55 + aReturningFloat + 3.0f;
                        }
                        float n59 = n58;
                        for (final PotionDisplayEntry c20 : ((java.lang.Iterable<PotionDisplayEntry>)(Object)(this.a.values()))) {
                            final float g2 = c20.g;
                            final int n60 = n13;
                            final float n61;
                            float g3 = n61 = g2;
                            if (n60 != 0) {
                                if (n61 < 0.02f) {
                                    continue;
                                }
                                g3 = c20.g;
                            }
                            final float n62 = g3;
                            final int n63 = (int)(255.0f * n62);
                            final float n64 = n59;
                            final float n65 = (1.0f - n62) * 6.0f;
                            if (n13 != 0) {
                                if (n62 > 0.7f) {
                                    BlurredRectangleRenderer.eReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, n54, n64, this.g, aReturningFloat2, 5, 4.0f, n2 });
                                }
                                FilledRectangleRenderer.cReturningVoid(new Object[] { an_C0030, gz_C0376, matrix4f, n54, n64, this.g, aReturningFloat2, aReturningColor(new Object[] { UiMetrics.r, (int)(UiMetrics.r.getAlpha() * n62), n7 }), 4.0f, n5 });
                            }
                            final String dReturningString = this.dReturningString(new Object[] { c20, n });
                            final float n66 = Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { c20.a, n10 }) * 0.9f;
                            final float n67 = Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { dReturningString, n10 }) * 0.9f;
                            final float n68 = n64 + (aReturningFloat2 - 2.0f - cReturningFloat * 0.9f) / 2.0f;
                            float f8 = 0.0f;
                            float f9 = 0.0f;
                            Label_6069: {
                                if ((cReturningBoolean ? 1 : 0) != 0) {
                                    f8 = n54 + this.g - 5.5f - n66 - n65;
                                    f9 = n54 + 5.5f;
                                    if (n13 != 0) {
                                        break Label_6069;
                                    }
                                }
                                f8 = n54 + 5.5f + n65;
                                f9 = n54 + this.g - 5.5f - n67;
                            }
                            Prestige.c.aReturningcx_C0158(new Object[] { n4 }).w(new Object[] { matrix4f, c20.a, f8, n68, 0.9f, aReturningColor(new Object[] { UiMetrics.s, n63, n7 }), l });
                            final PotionDisplayEntry c21 = c20;
                            final int n69 = n13;
                            final PotionDisplayEntry c23;
                            PotionDisplayEntry c22 = c23 = c21;
                            if (n69 != 0) {
                                if (c23.b != null) {
                                    final float cReturningFloat2 = this.cReturningFloat(new Object[] { c20.b, n9 });
                                    final float n70 = cReturningFloat * 0.65f + 1.5f;
                                    float n71;
                                    if ((cReturningBoolean ? 1 : 0) != 0) {
                                        n71 = f8 - 3.0f - cReturningFloat2;
                                    }
                                    else {
                                        n71 = f8 + n66 + 3.0f;
                                    }
                                    final float f10 = n71;
                                    final float f11 = n64 + (aReturningFloat2 - 2.0f - n70) / 2.0f;
                                    ShapeRenderer.u(new Object[] { matrix4f, f10, f11, f10 + cReturningFloat2, f11 + n70, aReturningColor(new Object[] { c20.c, (int)(70.0f * n62), n7 }), new Vector4f(3.0f), i });
                                    Prestige.c.aReturningcx_C0158(new Object[] { n4 }).w(new Object[] { matrix4f, c20.b, f10 + 2.0f, f11 + 0.75f, 0.65f, aReturningColor(new Object[] { c20.c, n63, n7 }), l });
                                }
                                c22 = c20;
                            }
                            final boolean f12 = c22.f;
                            final int n72 = n13;
                            final boolean b4;
                            int d = (b4 = f12) ? 1 : 0;
                            int n73 = 0;
                            Label_6918: {
                                if (n72 != 0) {
                                    if (b4) {
                                        n73 = Integer.MAX_VALUE;
                                        break Label_6918;
                                    }
                                    d = c20.d;
                                }
                                n73 = d / 20;
                            }
                            final int n75;
                            final int n74 = n75 = n73;
                            final int n76 = 5;
                            final int n77 = n13;
                            final int n78 = n76;
                            int n79 = n75;
                            int n80 = n78;
                            final int n81 = n79;
                            final int n82 = n78;
                            Color color = null;
                            Label_7325: {
                                if (n77 != 0) {
                                    if (n81 <= n82) {
                                        color = new Color(235, 64, 64, (int)(Math.min((int)(170.0 + 85.0 * Math.sin(System.currentTimeMillis() * 0.012)), 255) * n62));
                                        if (n13 != 0) {
                                            break Label_7325;
                                        }
                                    }
                                    final int n83 = n74;
                                    final int n84 = 10;
                                    n79 = n83;
                                    n80 = n84;
                                }
                                if (n79 <= n80) {
                                    color = new Color(255, 190, 80, n63);
                                    if (n13 != 0) {
                                        break Label_7325;
                                    }
                                }
                                color = new Color(235, 235, 235, n63);
                            }
                            Prestige.c.aReturningcx_C0158(new Object[] { n4 }).w(new Object[] { matrix4f, dReturningString, f9, n68, 0.9f, color, l });
                            final boolean f13 = c20.f;
                            final int n85 = n13;
                            final boolean b5;
                            int e2 = (b5 = f13) ? 1 : 0;
                            float aReturningFloat3 = 0.0f;
                            Label_7710: {
                                if (n85 != 0) {
                                    if (b5) {
                                        aReturningFloat3 = 1.0f;
                                        break Label_7710;
                                    }
                                    e2 = c20.e;
                                }
                                final int n86 = e2;
                                final int n87 = n13;
                                final int n88;
                                int d2 = n88 = n86;
                                if (n87 != 0) {
                                    if (n88 <= 0) {
                                        aReturningFloat3 = 0.0f;
                                        break Label_7710;
                                    }
                                    d2 = c20.d;
                                }
                                aReturningFloat3 = ClientUiUtil.aReturningFloat(new Object[] { d2 / (float)c20.e, 0.0f, 1.0f, k });
                            }
                            final float n89 = aReturningFloat3;
                            final float f14 = n64 + aReturningFloat2 - 1.9f;
                            final float f15 = n64 + aReturningFloat2 - 1.15f;
                            final float n90 = (this.g - 4.0f) * n89;
                            Color color2;
                            if (n74 <= 5) {
                                color2 = aReturningColor(new Object[] { new Color(235, 64, 64), (int)(200.0f * n62), n7 });
                            }
                            else {
                                color2 = aReturningColor(new Object[] { c20.c, (int)(160.0f * n62), n7 });
                            }
                            final Color color3 = color2;
                            final Matrix4f matrix4f2 = matrix4f;
                            final float n91 = n54 + 2.0f;
                            final float n92 = f14;
                            final float n93 = n54 + this.g - 2.0f;
                            final float n94 = f15;
                            final Color color4 = new Color(255, 255, 255, (int)(18.0f * n62));
                            final int n95 = n13;
                            final Color color5 = color4;
                            final float n96 = n94;
                            final float n97 = n93;
                            final float n98 = n92;
                            final float n99 = n91;
                            Matrix4f matrix4f3 = matrix4f2;
                            float f16 = n99;
                            float f17 = n98;
                            float f18 = n97;
                            float f19 = n96;
                            Color color6 = color5;
                            final Matrix4f matrix4f4 = matrix4f3;
                            final float f20 = n99;
                            final float f21 = n98;
                            final float f22 = n97;
                            final float f23 = n96;
                            final Color color7 = color5;
                            Label_8583: {
                                if (n95 != 0) {
                                    ShapeRenderer.lReturningVoid(new Object[] { matrix4f4, f20, f21, f22, f23, color7, l2 });
                                    if ((cReturningBoolean ? 1 : 0) != 0) {
                                        ShapeRenderer.lReturningVoid(new Object[] { matrix4f, n54 + this.g - 2.0f - n90, f14, n54 + this.g - 2.0f, f15, color3, l2 });
                                        if (n13 != 0) {
                                            break Label_8583;
                                        }
                                    }
                                    final Matrix4f matrix4f5 = matrix4f;
                                    final float n100 = n54 + 2.0f;
                                    final float n101 = f14;
                                    final float n102 = n54 + 2.0f + n90;
                                    final float n103 = f15;
                                    final Color color8 = color3;
                                    final float n104 = n103;
                                    final float n105 = n102;
                                    final float n106 = n101;
                                    final float n107 = n100;
                                    matrix4f3 = matrix4f5;
                                    f16 = n107;
                                    f17 = n106;
                                    f18 = n105;
                                    f19 = n104;
                                    color6 = color8;
                                }
                                ShapeRenderer.lReturningVoid(new Object[] { matrix4f3, f16, f17, f18, f19, color6, l2 });
                            }
                            final float n108 = n59;
                            final int n109 = (int)n40;
                            final float n110 = n108;
                            float n113;
                            float n114;
                            if (n109 != 0) {
                                final float n111 = n110;
                                final float n112 = -1.0f;
                                n113 = n111;
                                n114 = n112;
                            }
                            else {
                                final float n115 = n110;
                                n114 = 1.0f;
                                n113 = n115;
                            }
                            n59 = n113 + n114 * (aReturningFloat2 + 3.0f) * n62;
                            if (n13 == 0) {
                                break;
                            }
                        }
                        return;
                    }
                    if (n39 < 0) {
                        continue;
                    }
                    final float n116 = 5.5f;
                    n34 = Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { c19.a, n10 }) * 0.9f;
                    n33 = n116;
                }
                final float n117 = n33;
                final float n118 = n34;
                final int n119 = n13;
                final float n120 = n118;
                final float n121 = n117;
                final float n122 = n120;
                final float n123 = n121;
                final float n124 = n120;
                float n129;
                float n130;
                if (n119 != 0) {
                    final float n125 = n123 + n124;
                    final String b6 = c19.b;
                    final float n126 = n125;
                    if (b6 != null) {
                        final float n127 = n126;
                        final float n128 = 3.0f + this.cReturningFloat(new Object[] { c19.b, n9 });
                        n129 = n127;
                        n130 = n128;
                    }
                    else {
                        final float n131 = n126;
                        n130 = 0.0f;
                        n129 = n131;
                    }
                }
                else {
                    final float n132 = n121;
                    final float n133 = n122;
                    n129 = n132;
                    n130 = n133;
                }
                final float n134 = n129 + n130 + 8.0f + Prestige.c.aReturningcx_C0158(new Object[] { n4 }).aReturningFloat(new Object[] { this.dReturningString(new Object[] { c19, n }), n10 }) * 0.9f + 5.5f;
                final float n135 = max;
                final int n136 = n13;
                final float n137 = n135;
                float n138 = n134;
                float n139 = n137;
                final float n140 = n138;
                final float n141 = n137;
                if (n136 != 0) {
                    if (n140 > n141) {
                        max = n134;
                    }
                    final float n142 = n29;
                    n139 = (aReturningFloat2 + 3.0f) * c19.g;
                    n138 = n142;
                }
                n29 = n138 + n139;
                if (n13 == 0) {
                    break;
                }
            }
            this.g = ClientUiUtil.bReturningFloat(new Object[] { this.g, max, f * 2.0f, n8 });
            final float dReturningBoolean = this.dReturningBoolean(new Object[0]) ? 1 : 0;
            continue;
        }
    }

   private float cReturningFloat(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 20368215036302L ^ var2;
      long var5 = var2 ^ 70560214957657L;
      long var7 = var2 ^ 6576195163419L;
      MsdfFontManager var10000 = Prestige.c;
      Object[] var10 = new Object[]{var7};
      MsdfFontManager var9 = var10000;
      MsdfFont var14 = var9.aReturningcx_C0158(var10);
      Object[] var12 = new Object[]{var4, var5};
      MsdfFont var11 = var14;
      return var11.aReturningFloat(var12) * 0.65F + 4.0F;
   }

   private String dReturningString(Object[] var1) {
      PotionDisplayEntry var2 = (PotionDisplayEntry)var1[0];
      long var3 = (Long)var1[1];
      var3 = 20368215036302L ^ var3;
      long var5 = var3 ^ 4153109960781L;
      boolean var11 = var2.f;
      String var10;
      if (var11) {
         short var10000 = 6408;
         long var10001 = 3479119498631366840L ^ var3;
         String var12 = "INF";
         var10 = var12;
      } else {
         int var14 = var2.d;
         Object[] var10004 = new Object[]{null, var5};
         var10004[0] = var14;
         Object[] var9 = var10004;
         PotionDisplayWidget var8 = this;
         var10 = var8.cReturningString(var9);
      }

      return var10;
   }

   private static Color aReturningColor(Object[] var0) {
      Color var4 = (Color)var0[0];
      int var1 = (Integer)var0[1];
      long var2 = (Long)var0[2];
      var2 = 20368215036302L ^ var2;
      Color var5 = var4;
      int var10002 = var5.getRed();
      Color var6 = var4;
      int var10003 = var6.getGreen();
      Color var7 = var4;
      int var10004 = var7.getBlue();
      byte var10005 = 0;
      short var10007 = 7388;
      long var10008 = 5632361871082672040L ^ var2;
      int var8 = var1;
      int var11 = Math.min(var8, 255);
      return new Color(var10002, var10003, var10004, Math.max(0, var11));
   }

   private static Color bReturningColor(Object[] var0) {
      Color var3 = (Color)var0[0];
      long var1 = (Long)var0[1];
      var1 = 20368215036302L ^ var1;
      int var10000 = Event.bReturningInt();
      Color var10 = var3;
      int var5 = var10.getRed();
      int var4 = var10000;
      Color var11 = var3;
      int var6 = var11.getGreen();
      Color var12 = var3;
      int var7 = var12.getBlue();
      int var8 = var5 * 3 + var6 * 4 + var7 >> 3;
      short var10001 = 442;
      long var10002 = 880263587600589525L ^ var1;
      int var19 = var4;
      byte var18 = 90;
      int var17 = var8;
      int var15 = var17;
      int var16 = var18;
      int var13 = var17;
      byte var14 = var18;
      if (var19 == 0) {
         byte var21 = var14;
         int var20 = var13;
         if (var20 >= var21) {
            return new Color(var5, var6, var7);
         }

         short var25 = 27471;
         long var26 = 3083463911576832036L ^ var1;
         int var23 = var8;
         byte var22 = 90;
         var15 = var22;
         var16 = var23;
      }

      float var9 = (var15 - var16) / 90.0F * 0.6F;
      var10001 = 29867;
      var10002 = 2717064067898054603L ^ var1;
      var5 += (int)((255 - var5) * var9);
      var10001 = 29867;
      var10002 = 2717064067898054603L ^ var1;
      var6 += (int)((255 - var6) * var9);
      var10001 = 29867;
      var10002 = 2717064067898054603L ^ var1;
      var7 += (int)((255 - var7) * var9);
      return new Color(var5, var6, var7);
   }

   private static PotionDisplayEntry lambda$renderNew$0(StatusEffect var0) {
      long var10001 = 72024868178229L ^ 115352405949465L;
      return new PotionDisplayEntry(45526846338348L);
   }

   static {

      {

      b();
      Cipher var18;
      Cipher var10000 = var18 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var19 = 1; var19 < 8; var19++) {
         var10003[var19] = (byte)(18922521224000L << var19 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var25 = new String[15];
      String var22 = "#\u00164ã~næ þå\u001ap;\u0012\u007f\u0018\u0010¶¸×\u0000>íj\u0097Á|ç\u008d\r\u000fì5\u0010\u009e\u0011q\u001e¹wï\u008d6\u001d\u00805\u0011\u0083<a\u0010\rÈÄ\u001bVè/h@ó\u0089&«w+¨ ä\u0094\u0007\u0011Ícêþ\u0080z\u00adö&\u0010\u0094nê·ýù\u0003`KÓ\u0019\u0096W2C¶r\u0080\u0010øú¦Å\u008c_\u0089ËÝ©á\u0094Y\u0091Å7XÓòl]Ô\u009a\u001dCT2à3C\u00949¡\u0004g¬÷ï\u0014Sn$\u009eËý\u009d\u0085÷ð¥\"\u0003\u0082\u009eöÒËFpüàLm<\u0091gK\u0011æb¢gKILSY\u0006kVz#súß÷TxÎÐ\u0088îÝCä\u009d'hy\u0086\u0096|\u0092pl\u0010xpSR\u0092\"2¼øT%\u0085÷ÞÀ9\u0018X«X}X\u009eÆ$*\u0094Ä³\u0095Ã¸ÉóùA\u0013éñú2\u0010§ç'8âöãøíÍØ6\u0080[Ô¿\u0010ÞmvÔ=\u000e=:\u000f^Õ\u00199slc\u0010\u000e´3¡×À¦>¼ýéý´q2ñ\u0010ç\u0093\u0083\bÂpB³\u001fzDÁ@$AN";
      int var24 = "#\u00164ã~næ þå\u001ap;\u0012\u007f\u0018\u0010¶¸×\u0000>íj\u0097Á|ç\u008d\r\u000fì5\u0010\u009e\u0011q\u001e¹wï\u008d6\u001d\u00805\u0011\u0083<a\u0010\rÈÄ\u001bVè/h@ó\u0089&«w+¨ ä\u0094\u0007\u0011Ícêþ\u0080z\u00adö&\u0010\u0094nê·ýù\u0003`KÓ\u0019\u0096W2C¶r\u0080\u0010øú¦Å\u008c_\u0089ËÝ©á\u0094Y\u0091Å7XÓòl]Ô\u009a\u001dCT2à3C\u00949¡\u0004g¬÷ï\u0014Sn$\u009eËý\u009d\u0085÷ð¥\"\u0003\u0082\u009eöÒËFpüàLm<\u0091gK\u0011æb¢gKILSY\u0006kVz#súß÷TxÎÐ\u0088îÝCä\u009d'hy\u0086\u0096|\u0092pl\u0010xpSR\u0092\"2¼øT%\u0085÷ÞÀ9\u0018X«X}X\u009eÆ$*\u0094Ä³\u0095Ã¸ÉóùA\u0013éñú2\u0010§ç'8âöãøíÍØ6\u0080[Ô¿\u0010ÞmvÔ=\u000e=:\u000f^Õ\u00199slc\u0010\u000e´3¡×À¦>¼ýéý´q2ñ\u0010ç\u0093\u0083\bÂpB³\u001fzDÁ@$AN"
         .length();
      char var21 = 16;
      int var29 = -1;

      label64:
      while (true) {
         String var30 = var22.substring(++var29, var29 + var21);
         int var10001 = -1;

         while (true) {
            byte[] var26 = var18.doFinal(var30.getBytes("ISO-8859-1"));
            String var44 = b(var26).intern();
            switch (var10001) {
               case 0:
                  var25[var23++] = var44;
                  if ((var29 += var21) >= var24) {
                     w = var25;
                     x = new String[15];
                     D = new HashMap(13);
                     Cipher var7;
                     var10000 = var7 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var8 = 1; var8 < 8; var8++) {
                        var10003[var8] = (byte)(18922521224000L << var8 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var13 = new long[17];
                     String var11 = "Ïe§hÚ¸Eß¿\u0004ÆgYð\u0012Q\u007f[ÁU\u001c(²zÂÞ\u007f\tâÿ6zw×\u0018¾C+qý²{\u0010Z((\u0097$ý\u0014&\u0096Ã°¬¡\u009bü¨\u001dñ¹}y\u0006º;\u009a¸¼)ª\u0011¤\rdßý3`÷¡\u0080\u001e¡Å\u009bÃú ··c,/ýAòË\u00039\u008c@µÇ>ìÛ\u0084f´kQg\bÏDyEI";
                     int var12 = "Ïe§hÚ¸Eß¿\u0004ÆgYð\u0012Q\u007f[ÁU\u001c(²zÂÞ\u007f\tâÿ6zw×\u0018¾C+qý²{\u0010Z((\u0097$ý\u0014&\u0096Ã°¬¡\u009bü¨\u001dñ¹}y\u0006º;\u009a¸¼)ª\u0011¤\rdßý3`÷¡\u0080\u001e¡Å\u009bÃú ··c,/ýAòË\u00039\u008c@µÇ>ìÛ\u0084f´kQg\bÏDyEI"
                        .length();
                     label46:
                     while (true) {
                        var10001 = var9;
                        var9 += 8;
                        byte[] var14 = var11.substring(var10001, var9).getBytes("ISO-8859-1");
                        long[] var33 = var13;
                        var10001 = var10++;
                        long var48 = (var14[0] & 255L) << 56
                           | (var14[1] & 255L) << 48
                           | (var14[2] & 255L) << 40
                           | (var14[3] & 255L) << 32
                           | (var14[4] & 255L) << 24
                           | (var14[5] & 255L) << 16
                           | (var14[6] & 255L) << 8
                           | var14[7] & 255L;
                        // while (true) {
                           long var15 = var48;
                           byte[] var17 = var7.doFinal(
                              new byte[]{
                                 (byte)(var15 >>> 56),
                                 (byte)(var15 >>> 48),
                                 (byte)(var15 >>> 40),
                                 (byte)(var15 >>> 32),
                                 (byte)(var15 >>> 24),
                                 (byte)(var15 >>> 16),
                                 (byte)(var15 >>> 8),
                                 (byte)var15
                              }
                           );
                           long var56 = (var17[0] & 255L) << 56
                              | (var17[1] & 255L) << 48
                              | (var17[2] & 255L) << 40
                              | (var17[3] & 255L) << 32
                              | (var17[4] & 255L) << 24
                              | (var17[5] & 255L) << 16
                              | (var17[6] & 255L) << 8
                              | var17[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var33[var10001] = var56;
                                 if (var9 >= var12) {
                                    B = var13;
                                    C = new Integer[17];
                                    Cipher var2;
                                    var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var3 = 1; var3 < 8; var3++) {
                                       var10003[var3] = (byte)(18922521224000L << var3 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long var41 = -8874694399213504366L;
                                    byte[] var6 = var2.doFinal(
                                       new byte[]{
                                          (byte)132L,
                                          (byte)34006L,
                                          (byte)8705728L,
                                          (byte)2228666486L,
                                          (byte)570538620620L,
                                          (byte)146057886878906L,
                                          (byte)37390819041000184L,
                                          (byte)-8874694399213504366L
                                       }
                                    );
                                    long var51 = (var6[0] & 255L) << 56
                                       | (var6[1] & 255L) << 48
                                       | (var6[2] & 255L) << 40
                                       | (var6[3] & 255L) << 32
                                       | (var6[4] & 255L) << 24
                                       | (var6[5] & 255L) << 16
                                       | (var6[6] & 255L) << 8
                                       | var6[7] & 255L;
                                    // long var0 = var51;
                                    d = var0;
                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var56;
                                 if (var9 < var12) {
                                    continue label46;
                                 }

                                 var11 = "ö\u0099yê\u009e(`#J@·:h â#";
                                 var12 = "ö\u0099yê\u009e(`#J@·:h â#".length();
                                 var9 = 0;
                           }

                           int var40 = var9;
                           var9 += 8;
                           var14 = var11.substring(var40, var9).getBytes("ISO-8859-1");
                           var33 = var13;
                           var10001 = var10++;
                           var48 = (var14[0] & 255L) << 56
                              | (var14[1] & 255L) << 48
                              | (var14[2] & 255L) << 40
                              | (var14[3] & 255L) << 32
                              | (var14[4] & 255L) << 24
                              | (var14[5] & 255L) << 16
                              | (var14[6] & 255L) << 8
                              | var14[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var21 = var22.charAt(var29);
                  break;
               default:
                  var25[var23++] = var44;
                  if ((var29 += var21) < var24) {
                     var21 = var22.charAt(var29);
                     continue label64;
                  }

                  var22 = "\u0082V\u001c& \u0002·ÿ\rÓÂÖ\u0001å\u0095I@|¶\u0003ëÁb\u001bº\u0003\u0085Æ>£¨HV$+ú\u0091ä\u0080\u008fâ´Qrêû\u0017íOöæg\u0093°Õ(É;3EX¢¡«\u008azpHÊì½[{ÿ\t-Ø\t\u0019\u0099¨";
                  var24 = "\u0082V\u001c& \u0002·ÿ\rÓÂÖ\u0001å\u0095I@|¶\u0003ëÁb\u001bº\u0003\u0085Æ>£¨HV$+ú\u0091ä\u0080\u008fâ´Qrêû\u0017íOöæg\u0093°Õ(É;3EX¢¡«\u008azpHÊì½[{ÿ\t-Ø\t\u0019\u0099¨"
                     .length();
                  var21 = 16;
                  var29 = -1;
            }

            var30 = var22.substring(++var29, var29 + var21);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            int var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14828;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/ca", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ca_C0112",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ca" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12127;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ca", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ca_C0112",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ca" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = I[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = H[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 54;
            yield var15;
         }
         case 1 -> {
            byte var16 = 42;
            yield var16;
         }
         case 2 -> {
            byte var17 = 11;
            yield var17;
         }
         case 3 -> {
            byte var18 = 27;
            yield var18;
         }
         case 4 -> {
            byte var19 = 41;
            yield var19;
         }
         case 5 -> {
            byte var20 = 24;
            yield var20;
         }
         case 6 -> {
            byte var21 = 10;
            yield var21;
         }
         case 7 -> {
            byte var22 = 8;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 39;
            yield var24;
         }
         case 10 -> {
            byte var25 = 18;
            yield var25;
         }
         case 11 -> {
            byte var26 = 45;
            yield var26;
         }
         case 12 -> {
            byte var27 = 14;
            yield var27;
         }
         case 13 -> {
            byte var28 = 51;
            yield var28;
         }
         case 14 -> {
            byte var29 = 37;
            yield var29;
         }
         case 15 -> {
            byte var30 = 28;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 63;
            yield var32;
         }
         case 18 -> {
            byte var33 = 6;
            yield var33;
         }
         case 19 -> {
            byte var34 = 36;
            yield var34;
         }
         case 20 -> {
            byte var35 = 52;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 29;
            yield var37;
         }
         case 23 -> {
            byte var38 = 38;
            yield var38;
         }
         case 24 -> {
            byte var39 = 57;
            yield var39;
         }
         case 25 -> {
            byte var40 = 21;
            yield var40;
         }
         case 26 -> {
            byte var41 = 62;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 53;
            yield var43;
         }
         case 29 -> {
            byte var44 = 60;
            yield var44;
         }
         case 30 -> {
            byte var45 = 23;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 40;
            yield var47;
         }
         case 33 -> {
            byte var48 = 50;
            yield var48;
         }
         case 34 -> {
            byte var49 = 7;
            yield var49;
         }
         case 35 -> {
            byte var50 = 49;
            yield var50;
         }
         case 36 -> {
            byte var51 = 20;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 0;
            yield var53;
         }
         case 39 -> {
            byte var54 = 35;
            yield var54;
         }
         case 40 -> {
            byte var55 = 30;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 43;
            yield var58;
         }
         case 44 -> {
            byte var59 = 61;
            yield var59;
         }
         case 45 -> {
            byte var60 = 22;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 31;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 1;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 16;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 58;
            yield var71;
         }
         case 57 -> {
            byte var72 = 32;
            yield var72;
         }
         case 58 -> {
            byte var73 = 15;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 17;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 59;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            I[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      H[0] = "\u0015\u0013\t,W\u001b\u0003\u0013\fvD\f\u0014X\u000fpH\u0018\u0005\u001f\u0018g\u0003\n4";
      H[1] = int.class;
      I[1] = "java/lang/Integer";
      H[2] = "\u0010#;x\u001f2\u0006#>\"\f%\u0011h=$\u00001\u0000/*3K!\u0015";
      H[3] = "Q\u001274\u0016\u0014Z\u001d&{u\u0019O\u0010)\u0010@\u001b^\u00035<W\u0016";
      H[4] = "O\u00146\u001e\u0016\\D\u001b'QkDW\u001c.\u0018";
      H[5] = "G\\q\u0012O\u0007LS`](\u0005YX`\u0016\u0013";
      H[6] = "9\u007fCm~~L_Hbo1-QCikkY";
      H[7] = "|~GX[&j~B\u0002H1}5A\u0004D%lrV\u0013\u000f5b";
      H[8] = ";c/1C)NC$>Rf/M/5V<[";
      H[9] = "Apte[9Wpq?H.@;r9D:Q|e.\u000f*]";
      H[10] = "=\f3\"OE+\f6x\\R<G5~PF-\u0000\"i\u001bV5\u0000 bA\u001b\t\u001b \u007fA\\>\f";
      H[11] = "ea\u0016Ok+\u0010A\u001d@zdqO\u0016K~>\u0005";
      H[12] = float.class;
      I[12] = "java/lang/Float";
      H[13] = "#\u0000|hGjV wgV%7.|lR\u007fC";
      H[14] = "z\u0019\u0019W\u001f\u000bq\u0016\b\u0018|\u0006d\u0010";
      H[15] = "e^[\u0011&*xK\u00033g'`M";
      H[16] = "4jk'w04j|{{?.!|e{*)P.;#h";
      H[17] = ",jE`h6,jR<d96!R\"d,1P\u0003{3n";
      H[18] = "\f\u0013*\u0001i{y3!\u000ex4\u0018=*\u0005|nl";
      H[19] = "$M\u0004'E\"/B\u0015h87=X\u0017+";
      H[20] = long.class;
      I[20] = "java/lang/Long";
      H[21] = "=>%#r7#6?l\u0011#'{\u0016,(0.";
      H[22] = "\r'?2\u001fV\u0006(.}~X\r#*'";
      H[23] = "V\u0016~uwpV\u0016i){\u007fL]i7{jK,9j*";
      H[24] = "fa\u000e[9}fa\u0019\u00075r|*\u0019\u00195g{[NFc";
      H[25] = "\b\u001b:r\u0015K};1}\u0004\u0004\u001c5:v\u0000^h";
      H[26] = "\u0005+;\u0007gNp\u000b0\bv\u0001\u0011\u0005;\u0003r[e";
      H[27] = void.class;
      I[27] = "java/lang/Void";
      H[28] = "\u0000c\u0002\u0003D'\u001ek\u0018L)=\u0006n\u0011\u0001\u001e;\u0005l";
      H[29] = "\r}M\u001cbS\u0013uWS\u0005R\u0002nZ\t#T";
      H[30] = "\\5+jbyJ5.0qn]~-6}zL9:!6k\t";
      H[31] = "Al\u0013\flP4L\u0018\u0003}\u001fUB\u0013\byE!";
      H[32] = "\u0012\u0017\u001fudD\u0012\u0017\b)hK\b\\\b7h^\u000f-Zi0\u001e";
      H[33] = "L\u000f\u001f\u001f\u0015k9/\u0014\u0010\u0004$X!\u001f\u001b\u0000~,";
      H[34] = boolean.class;
      I[34] = "java/lang/Boolean";
      H[35] = "\t\u000b`G\\>\t\u000bw\u001bP1\u0013@w\u0005P$\u00141#]\u0007";
      H[36] = "Y\u001e0\u0000r\u001bG\u0016*O\u0011\u000fC";
      H[37] = "G\u0003(}x)Q\u0003-'k>FH.!g*W\u000f96,8a";
      H[38] = "ke6*,\u000e\u001eE=%=A\u007fK6.9\u001b\u000b";
      H[39] = "i#:a\u0013-i#-=\u001f\"sh-#\u001f7t\u0019xwFt";
      H[40] = "p\u0003\u007f\u0014f\u0018\u0005#t\u001bwWd-\u007f\u0010s\r\u0010";
      H[41] = "{D5Y(neL/\u0016U~e";
      H[42] = "q\u0016UD}\u0005g\u0016P\u001en\u0012p]S\u0018b\u0006a\u001aD\u000f)\u0011}";
      H[43] = ") ]~\u0019\u001d\\\u0000Vq\bR=\u000e]z\f\bI";
      H[44] = "\u0016\nA#\u0007\u0010\u0000\nDy\u0014\u0007\u0017AG\u007f\u0018\u0013\u0006\u0006PhS\u0002&";
      H[45] = "ko}D*.}ox\u001e99j${\u00185-{cl\u000f~:y";
      H[46] = "\u001fC,\u0019#-jc'\u00162b\u000bm,\u001d68\u007f";
      H[47] = "L\u0011k:H\u001791`5YXX?k>]\u0002,";
      H[48] = "\u0017\u0017ct\u0007~\u0001\u0017f.\u0014i\u0016\\e(\u0018}\u0007\u001br?SmJ";
      H[49] = "BSF*\nH7sM%\u001b\u0007V}F.\u001f]\"";
      H[50] = "7^3!2jB~8.#%#p3%'\u007fW";
      H[51] = ";~{ya4N^pvp{/P{}t![";
      H[52] = double.class;
      I[52] = "java/lang/Double";
      H[53] = "i^h\ft\u001f\u001c~c\u0003eP}ph\ba\n\t";
      H[54] = "\u001545n\u0012~`\u0014>a\u00031\u0001\u001a5j\u0007ku";
      H[55] = "{\tn\u0006BD\u000e)e\tS\u000bo'n\u0002WQ\u001b";
      H[56] = "\u001b8YO{I\u00050C\u00003I\u001f:[G:R_\u001fZ@6H\u00186A";
      H[57] = "^#iDl\u0000H#l\u001e\u007f\u0017_ho\u0018s\u0003N/x\u000f8\u0013Q";
      H[58] = "DR\u000b\u0002\u0012u1r\u0000\r\u0003:P|\u000b\u0006\u0007`$";
      H[59] = char.class;
      I[59] = "java/lang/Character";
      H[60] = "\u0011b\u0001oP\\\u0007b\u00045CK\u0010)\u00073O_\u0001n\u0010$\u0004H\u0012";
      H[61] = "9A\u0005EovLa\u000eJ~9-o\u0005AzcY";
      H[62] = "Lo\u0002n{:9O\tajuXA\u0002jn/,";
      H[63] = "\u0000ccP\u0002h\u0016cf\n\u0011\u007f\u0001(e\f\u001dk\u0010or\u001bV|\u0013";
      H[64] = "vH_;Uz\u0003hT4D5bf_?@o\u0016";
      H[65] = "(|>W~+>|;\rm<)78\u000ba(8p/\u001c*?*";
      H[66] = ":f\u0016\u0000\u00042OF\u001d\u000f\u0015}.H\u0016\u0004\u0011'Z";
      H[67] = "=Zh\r\u001bKHzc\u0002\n\u0004)th\t\u000e^]";
      H[68] = "J\u001f]S7n??V\\&!^1]W\"{*";
      H[69] = "Ym\u007f2U\u0002@?h16\u000bY,\u000ft\u0006_K=nwS\tV\\6}\u0007\u0015Q=5(Q\b0e?|M\u000fQfj*Pn";
      H[70] = "G2Y[\u001foQu\b\u001e\u007fl@7Y\u0000\u0013^\u0010v\u0007_\u007fb\u0014tW\u0018\u0012h@7Ag";
      H[71] = "K\b\u001aP>3\u0010RE\\\u0007!LN<]\u007f.H2L\t65@SO\\`(!";
      H[72] = "@U\u007f&Sf\u0014\\cdi|y\u0002e~Su\u0016Rhg\u0017yy\u0000c'VuH\u000b2qV\u0016";
      H[73] = "A\bJo\u0011rT\u0018Jqn)P\u001b\u0000l\b>q\u0000\u001fl+#I\u0005\u001bzn/C\u001eE\u007f\u0014+\u0012\f\u0006\u0001";
      H[74] = "nX\\\u001cG^k\u0000X\u00106]m\u0018u\u001cG2n\u0019UJ\b[0\u0005F\u001a6";
      H[75] = "\b4w1`\u0001Oq4,XW77yu2\u0005P0t}(";
      H[76] = "Y#\u0012!\u0017\u0005G~\u0003l|\u0001W\u007f\u000bp+V\t/R\u001c\u0013\u001dSoU\"\u0002\bZc";
      H[77] = "i\u0011*\u0007YX=\u00186EcBPF0_YK?\u0016=F\u001dGP\u0015`U\n\u0011-N:\n\u0006(";
      H[78] = "$\u0017qeT\u0007*\u0013{q1\u001c\u001aW|d\u000b\u0000u\u0007q}O\f\u001a\u000fh0R_'Q'm\u000bc";
      H[79] = "lB;\u0010WC\u007f\u0018)\u00130Os\u0016?\u0003LIu{&\u0013ID7\u0012<\u0003QJ\u000f";
      H[80] = "4\u0004\u001a@}k4\u001c\u0013[\u001d3WLAG'18\u001cL^c=W\u0014U\u0013~njJ\u001aN'R";
      H[81] = "BW_|\u0019 \u0016^C>#9{\u0003J+]m\u0004]_}_PA\\E?\u001e/\u001fI\u0013=#";
      H[82] = "\u0005\u00145\u0012P2\u000eEc\u00123gS\u001efQS\u0003\u0007H8VRb\u0004\u001dnK3";
      H[83] = "|m(r\u0011Pf}0|)_rd-\u0018GD|/oq\u0019Xo\u007fQ";
      H[84] = "azNI^0j+\u0018I=o=l\u0017\u001fA\u0001azNI^0j+\u0018I=80sH\u0015Rh=j\f\u0019=:6*M\u0015\f1g|Mv";
      H[85] = "ZyW4AcP-\u0014\">a\\<3&DoW/haR2\u000e#Yj\u0003d\u000e@";
      H[86] = "i\r9p\n3g\u00164#k7a\u001bdt\u0007\u00051Z;#kk<V\u007fr\nhi\u0000b\u0013";
      H[87] = "\u0010)3!t9\u001e-95\u00114.i> +>A939o2.`%>ldCa;,w]";
      H[88] = ":w@SC\u0004 gX]{\u00174k^G\u0016m8p\bZGPf?U\u0003{";
      H[89] = "{JkYki \u00104UR{|\f^]>\u0014(@5K3u+\u0015cVR";
      H[90] = "y Oz14y8FaQa\u001ah\u0014}knu8\u0019d/b\u001a6Frjk|4Et!\r";
      H[91] = "g-\u001c<m\u0000d0\\9\u0016\u001bm(F7z)>l\u0016`\u0016\u0006e>D9g\u000fz%GP";
      H[92] = "v\u0004-\nf*\u007f\u001b6\t\u000f%g\u0005:\u0005t[mX9\u0012h6~\u0002+\u0011\u000f";
      H[93] = "\t\nK.B\u0010\u0001@]\u007f-Fp\u0002N*\u0017L\u001fRC3S@p\u000bU4P\u0016\u001d\nK&K/";
      H[94] = ",4%x_Kn'3;`\u001d13;Q[JgV-{\u0003Mh?sg\u0010\u001dV";
      H[95] = "p%fg;\u0003p=o|[Q\u0013m=`aY|=0y%U\u00133oo`\\u1li+:";
      H[96] = "?^ev[6+[=&5/8R$vI)>?=fL$|V'vT*D";
      H[97] = "02f\u001aF!0*o\u0001&qSz=\u001d\u001c{<*0\u0004XwS\")IE$n|f\u0014\u001c\u0018";
      H[98] = "fSU\u0013# w\u0003_\u0016Ov\u001aVS\u0013u|u\u0006^\n1p\u001a\u0011\u0002\u0013+g'\r\u0002\u001b3\u001f";
      H[99] = "F\u000e%\u0004.]\bI/Z_P8L5_eNW\u001c8F!B8\u0014!\u000b<\u0011\u0005JnVe-";
      H[100] = "~\u000bO!\u001ep*\u0002Sc$kG\\Uy\u001ec(\fX`ZoG^S \u001bcvU\u0002v\u001b\u0000";
      H[101] = "\u0007N4Ej\u001b\u0013Kl\u0015\u0004\b\u001bIsEe\u0005\u0007/aQgXBF?Mt\b|H7F?\u0005\u001aJ4@tc";
      H[102] = "4Ks@;9<\u0001e\u0011TlMCvDne\"\u0013{]*iMJmZ)? KsH2\u0006";
      H[103] = "\rKuC\u000e^\u0003Fc\u001cg\f}\u0014y\u0019]\u0002\u0012Dt\u0000\u0019\u000e}LmM\u0004]@\u0012\"\u0010]a";
      H[104] = "~+\u0015cC\u0012p/\u001fw&\u001d@k\u0018b\u001c\u0015/;\u0015{X\u0019@b\u0003|[O-c\u001dn@v";
      H[105] = "gAmAMf<\u001b2Mtt`\u0007MR\u0019vk{;\u0018E`l\u001a8M\u0013}\r";
      H[106] = "yoJ\u0017h_wtGD\t[qy\u0017\u0013ei!8GH\t\u0007,4\f\u0015h\u0004yb\u0011t";
      H[107] = "tP|_rQ Y`\u001dHJM\u0007f\u0007rB\"Wk\u001e6NM\u000e}\u00195\u0018 \u000fc\u000b.!";
      H[108] = "39r\u0000xIe1sb((ad(\u0019#Ib1~\u0004B";
      H[109] = "7A\u0007\u0013V[.\u0013\u0010\u00105L?\u0016wU\r^g\u001e\f\u001eNS<\rwU\r^g\u001e\f\u001eNS<\rw";
      H[110] = "qct\u0015-/'kuw|N#>.\fv/ kx\u0011\u0017";
      H[111] = "\u001e1(=?\u0000Pv\"cN\u0014`s8ft\u0013\u000f#5\u007f0\u001f`+,2-L]ucotp";
      H[112] = "onif\u0003Z{k16mKxcRa\u0010A/1;?\fR\u007f\u000f57\u0007\u0019ri74\u0001R\u0014";
      H[113] = "^8\u000b\u00108i\n1\u0017R\u0002ugo\u0011H8z\b?\u001cQ|vgm\u0017\u0011=zVfFG=\u0019";
      H[114] = "zJUY\u000b'd\u0017D\u0014`#t\u0016L\b7t*A\u0014d\u00074/\u0017S\u001a\u0004)o\u0012";
      H[115] = "FO\u00182NJ\\_\u0000<vCLM'5\u0006_%QY2MECSZ4\u0006#";
      H[116] = "MZ@3v.T\bW0\u0015'E\r0u%s_\nQvp%Bk\t|$9E\n\n)r$$R\u0000}n#EQU+sB";
      H[117] = "ot/\u001e\u0007!)i#\u0018bg=n1M%wT3|\u0011\u0019x50)G\u0004\u0019ot/\u001e\u0007!)i#\u0018b";
      H[118] = "1\u0014^ z68\u000bE#\u0013*/\rN3H*5qO#(.'\t[&p~I";
      H[119] = "A4K\u0017\u000f\u0016I~]F`E8<N\u0013ZJWlC\n\u001eF8o\u001e\u0019\t\u0010E4DF\u0005)";
      H[120] = "H\u0016~5@KA\te6)QW\u0016l*UWq\u001d]=RWV\u000f\u00149TY\u000bM}gHJ[s-l\u0016\u0004\b\u001arh\u0016\u0003^sz*J\u0001\u000e\u001a$6YQ0";
      H[121] = ">\u0014(F\"o0\u000f%\u0015Ck6\u0002uB/YgN(\u0018r\u000e<F\u007f\u001e%h>EyUC";
      H[122] = "\u001e\u0003J\bu6\u0007Q]\u000b\u0016?\u001eB:Gg!\n\u000bWFy3\u00112\n\u0006m'N_\u000b\u0018\u007f<w\u0002K\fkc\u001a\u0003U\u001epZ";
      H[123] = "/z\u0013\u0012t?t L\u001eM-(<6\u001f0/EyLJ6#$z\u0019\u001c+B";
      H[124] = "\u000b\u0002\u0006y\u0017Z\f\u000f\u000ec.T7KUv\u0014^X\u001bXoPR7LFtJXSBB~^=";
      H[125] = "^#*\u0001%i\f$t\\/\f\u000e\u0018u\u000e)6\u0004w%\u00030r\b\u0018|\u00157q^u}\u000b%jg";
      H[126] = "ZL(^9hQ\u001d~^Z2\u0001In(&YX\u0010%\u001a;8[Es\u0007Z`\\\u0011x[%?Z\u001co\u000fZ";
      H[127] = "Jn\u007fJJ\f\u0001><KJl\u0018S=CHV\u0010<mNQ\u0012\u001cSeW\u001c\u000fOn;\u0018AVs";
      H[128] = "\u001fS}lQd\u0014\u0002+l2+M[<>u;$\u0006qbI4E\u0005$4TU\u001fS}lQd\u0014\u0002+l2";
      H[129] = "Sn[$Z?]jQ0?%m.V%\u00058\u0002~[<A4mvBq\\gP(\r,\u0005[";
      H[130] = "&dM~d\"#<Ir\u0015!%$yzq3%XInvuv1\u0017re%H";
      H[131] = "\u00102$7M\u0013\u00192\u007f%\u0016zC\rz!C@Jb*,Z\u0004F\r)qI\u0013\u0010pr+\u0016\u001f)";
      H[132] = "\u007fYz\u000b\u0010E{\u000e!\u0018\u0002{-h~\u000e\u001bA%\u0007.\u0003\u0002\u0005)h&\u001aO\u0018zUxU\u0012AF";
      H[133] = " h]X\u001c86/\f\u001d|;'m]\u0003\u0010\tw,\u0000Z|gz F\u0005\u001dd/v[d";
      H[134] = "\u0015a5Ar5Ah)\u0003H,,6/\u0019r&Cf\"\u00006*,e\u007f\u0013!|Q>%L-E";
      H[135] = "nJfM_\u007fe\u001b0M<0<B'\u001f{ U\u001fgCPt*@aNG U\u001d6N\u0003-d\u0016g\u0018\u0003N";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = H[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(I[var4]);
            H[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = H[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = I[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            H[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  H[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(1609606840869840L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = H[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = I[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  H[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(1609606840869840L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        H[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(1609606840869840L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 118;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 36;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 74;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 251;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 248;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 72;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 118;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 36;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 74;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ca_C0112",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ca" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/ca_C0112",
                     "lambda$renderNew$0",
                     "(Lnet/minecraft/entity/effect/StatusEffect;)Ldev/zprestige/prestige/c5;"
                  ),
                  SourceSupport.methodType("(Lnet/minecraft/entity/effect/StatusEffect;)Ldev/zprestige/prestige/c5;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
