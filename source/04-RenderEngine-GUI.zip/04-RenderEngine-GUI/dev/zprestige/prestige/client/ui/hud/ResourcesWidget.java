package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.events.TickEvent;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.management.NotificationManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.NotificationType;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.joml.Matrix4f;

public class ResourcesWidget extends HudElement {
   private static final Item[] a;
   private static final String[] c;
   private static final int[] d;
   private static final long g;
   private static final long h;
   private static final int i;
   private final int[] j;
   private final int[] k;
   private final long[] l;
   private final ItemStack[] m;
   private boolean n;
   private boolean q;
   private static final float o = 0.6F;
   private static final float p = 9.6F;
   private static final long v = 16234236170648L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[97];
   private static final String[] L = new String[97];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public ResourcesWidget(long var1) {
      super("Resources", "Tracks gapples, totems, crystals, and exp — warns when any drops below threshold.", ((16234236170648L ^ (16234236170648L ^ var1)) ^ 78272142695886L));
      var1 = 16234236170648L ^ var1;
      long var3 = var1 ^ 78272142695886L;
      short var10001 = 31727;
      long var10002 = 4001612055987314500L ^ var1;
      short var6 = 8171;
      long var10003 = 1331322859890162501L ^ var1;

      this.j = new int[a.length];
      this.k = new int[a.length];
      this.l = new long[a.length];
      this.m = new ItemStack[a.length];
      this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.q = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   private void r(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 16234236170648L ^ var2;
      int var4 = Event.cReturningInt();
      int var9 = var4;
      byte var8 = ((byte)((this.q) ? 1 : 0));
      byte var7 = var8;
      byte var6 = var8;
      if (var9 != 0) {
         byte var10 = var6;
         if (var10 != 0) {
            return;
         }

         var7 = 0;
      }

      int var5 = var7;

      while (true) {
         int var12 = a.length;
         int var11 = var5;
         if (var11 < var12) {
            this.m[var5] = new ItemStack(a[var5]);
            var5++;
            int var13 = var4;
            if (var13 == 0) {
               break;
            }

            int var14 = var4;
            if (var14 != 0) {
               continue;
            }
         }

         this.q = dev.prestige.recovery.SourceSupport.asBoolean(1);
         break;
      }
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 220.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      ResourcesWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   private static int aReturningInt(Object[] var0) {
      Item var3 = (Item)var0[0];
      long var1 = (Long)var0[1];
      var1 = 16234236170648L ^ var1;
      int var10000 = Event.cReturningInt();
      int var4 = var10000;

      ItemStack var22;
      while (true) {
         short var10001 = 11246;
         long var10002 = 3503916636659218516L ^ var1;
         byte var24 = 35;
         int var23 = var6;
         if (var23 <= var24) {
            MinecraftClient var8 = b;
            ClientPlayerEntity var9 = var8.player;
            PlayerInventory var36 = var9.getInventory();
            int var11 = var6;
            PlayerInventory var10 = var36;
            ItemStack var7 = var10.getStack(var11);
            int var25 = var4;
            if (var25 != 0) {
               int var27 = var4;
               ItemStack var26 = var7;
               var22 = var26;
               ItemStack var20 = var26;
               if (var27 == 0) {
                  break;
               }

               ItemStack var28 = var20;
               ItemStack var21 = var28;
               ItemStack var13 = var21;
               Item var37 = var13.getItem();
               Item var30 = var3;
               Item var29 = var37;
               if (var29 == var30) {
                  ItemStack var15 = var7;
                  var5 += var15.getCount();
               }

               var6++;
            }

            int var31 = var4;
            if (var31 != 0) {
               continue;
            }
         }

         MinecraftClient var16 = b;
         ClientPlayerEntity var17 = var16.player;
         var22 = var17.getOffHandStack();
         break;
      }

      ItemStack var35 = var22;
      ItemStack var18 = var35;
      Item var38 = var18.getItem();
      Item var33 = var3;
      Item var32 = var38;
      if (var32 == var33) {
         ItemStack var19 = var35;
         var5 += var19.getCount();
      }

      return var5;
   }

   @EventListener
   public void a(TickEvent var1) {
      long var10001 = 91150955603891L ^ 57029481098859L;
      var10001 = 91150955603891L ^ 56963353572583L;
      int var8 = Event.cReturningInt();
      int var74 = var8;
      MinecraftClient var73 = b;
      MinecraftClient var48 = var73;
      MinecraftClient var47 = var73;
      if (var74 != 0) {
         MinecraftClient var16 = var47;
         ClientPlayerEntity var75 = var16.player;
         if (var75 == null) {
            return;
         }

         MinecraftClient var76 = b;
         var48 = var76;
      }

      MinecraftClient var19 = var48;
      ClientWorld var77 = var19.world;
      if (var77 != null) {
         ResourcesWidget var52;
         label106: {
            int var51;
            label107: {
               while (true) {
                  int var79 = a.length;
                  int var78 = var9;
                  if (var78 < var79) {
                     int[] var10000 = this.j;
                     Object[] var21 = new Object[]{a[var9], 106895455160792L};
                     var10000[var9] = aReturningInt(var21);
                     var9++;
                     int var80 = var8;
                     if (var80 == 0) {
                        break;
                     }

                     int var81 = var8;
                     if (var81 != 0) {
                        continue;
                     }
                  }

                  MinecraftClient var23 = b;
                  ClientPlayerEntity var24 = var23.player;
                  int var83 = var8;
                  int var82 = var24.age;
                  var51 = var82;
                  int var49 = var82;
                  if (var83 == 0) {
                     break label107;
                  }

                  byte var85 = 40;
                  int var84 = var49;
                  if (var84 < var85) {
                     byte var129 = 0;
                     byte var10003 = 0;
                     int var30 = this.j.length;
                     int[] var28 = this.k;
                     int[] var26 = this.j;
                     System.arraycopy(var26, 0, var28, 0, var30);
                     this.n = dev.prestige.recovery.SourceSupport.asBoolean(0);
                     return;
                  }
                  break;
               }

               int var87 = var8;
               ResourcesWidget var86 = this;
               var52 = var86;
               ResourcesWidget var50 = var86;
               if (var87 == 0) {
                  break label106;
               }

               byte var88 = ((byte)((var50.n) ? 1 : 0));
               var51 = var88;
            }

            int var89 = var51;
            if (var89 != 0) {
               long var123 = System.currentTimeMillis();
               int var122;
               do {
                  int var92 = a.length;
                  int var91 = var11;
                  if (var91 >= var92) {
                     break;
                  }

                  int var12;
                  int var60;
                  label73: {
                     int var59;
                     label72: {
                        label71: {
                           var12 = d[var11];
                           int var124 = this.k[var11];
                           int var95 = var8;
                           int var94 = var12;
                           int var93 = var124;
                           int var57 = var93;
                           int var58 = var94;
                           int var53 = var93;
                           int var54 = var94;
                           if (var95 != 0) {
                              int var97 = var54;
                              int var96 = var53;
                              if (var96 < var97) {
                                 break label71;
                              }

                              var124 = this.j[var11];
                              int var99 = var8;
                              int var98 = var124;
                              var59 = var98;
                              int var55 = var98;
                              if (var99 == 0) {
                                 break label72;
                              }

                              int var100 = var55;
                              int var56 = var100;
                              int var102 = var12;
                              int var101 = var56;
                              var57 = var101;
                              var58 = var102;
                           }

                           int var104 = var58;
                           int var103 = var57;
                           if (var103 < var104) {
                              var59 = 1;
                              break label72;
                           }
                        }

                        var60 = 0;
                        break label73;
                     }

                     int var105 = var59;
                     var60 = var105;
                  }

                  int var13 = var60;
                  int var106 = var8;
                  if (var106 != 0) {
                     int var107 = var13;
                     label57:
                     if (var107 != 0) {
                        var10001 = this.l[var11];
                        int var112 = var8;
                        long var110 = var10001;
                        long var108 = var123;
                        long var69 = var108;
                        long var71 = var110;
                        long var61 = var108;
                        long var63 = var110;
                        if (var112 != 0) {
                           long var115 = var63;
                           long var113 = var61;
                           long var65 = var113;
                           long var67 = var115;
                           long var134;
                           int var117 = (var134 = var65 - var67) == 0L ? 0 : (var134 < 0L ? -1 : 1);
                           if (var117 < 0) {
                              break label57;
                           }

                           NotificationManager var126 = Prestige.v;
                           String var10002 = c[var11] + " low: " + this.j[var11] + "/" + var12;
                           long var133 =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.ResourcesWidget_476";
                           Object[] var10007 = new Object[]{null, null, null, NotificationType.WARNING, 106826240627540L};
                           var10007[2] = var133;
                           var10007[1] = var10002;
                           var10007[0] = "Resources";
                           Object[] var46 = var10007;
                           NotificationManager var45 = var126;
                           var45.aReturningVoid(var46);
                           long var127 =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.ResourcesWidget_32089";
                           long var120 = (long)(Math.random() * 5000.0);
                           long var118 = var127;
                           var69 = var118;
                           var71 = var120;
                        }

                        long var14 = var69 + var71;
                        this.l[var11] = var123 + var14;
                     }

                     this.k[var11] = this.j[var11];
                     var11++;
                  }

                  var122 = var8;
               } while (var122 != 0);

               return;
            }

            byte var130 = 0;
            byte var132 = 0;
            int var37 = this.j.length;
            int[] var35 = this.k;
            int[] var33 = this.j;
            System.arraycopy(var33, 0, var35, 0, var37);
            ResourcesWidget var90 = this;
            var52 = var90;
         }

         var52.n = dev.prestige.recovery.SourceSupport.asBoolean(1);
      }
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var2 = (MeshBufferManager)var1[0];
      RenderContext var6 = (RenderContext)var1[1];
      Matrix4f var3 = (Matrix4f)var1[2];
      long var4 = (Long)var1[3];
      long var7 = var4 ^ 49928519994039L;
      long var9 = var4 ^ 48887442607471L;
      long var11 = var4 ^ 124694493719688L;
      long var13 = var4 ^ 81054074941871L;
      long var15 = var4 ^ 36477842301344L;
      long var17 = var4 ^ 126879126745269L;
      long var19 = var4 ^ 13608202459885L;
      long var21 = var4 ^ 110128736735278L;
      long var23 = var4 ^ 29307267718371L;
      long var25 = var4 ^ 113406911627307L;
      long var27 = var4 ^ 46684315333905L;
      long var29 = var4 ^ 61991993207385L;
      Object[] var61 = new Object[]{var21};
      ResourcesWidget var60 = this;
      var60.r(var61);
      int var10000 = Event.bReturningInt();
      short var10001 = 13611;
      long var10002 = 5796923443362666535L ^ var4;
      String var32 = "Resources";
      MsdfFontManager var203 = Prestige.c;
      Object[] var63 = new Object[]{var19};
      MsdfFontManager var62 = var203;
      MsdfFont var204 = var62.aReturningcx_C0158(var63);
      Object[] var65 = new Object[]{var7};
      MsdfFont var64 = var204;
      float var33 = var64.cReturningFloat(var65);
      Object[] var10004 = new Object[]{null, 1.0F};
      var10004[0] = var33;
      Object[] var66 = var10004;
      float var34 = UiMetrics.aReturningFloat(var66);
      var10004 = new Object[]{null, 0.9F};
      var10004[0] = var33;
      Object[] var67 = var10004;
      float var35 = UiMetrics.aReturningFloat(var67);
      MsdfFontManager var205 = Prestige.c;
      Object[] var69 = new Object[]{var19};
      MsdfFontManager var68 = var205;
      MsdfFont var206 = var68.aReturningcx_C0158(var69);
      Object[] var71 = new Object[]{var32, var13};
      MsdfFont var70 = var206;
      float var36 = var70.aReturningFloat(var71);
      float var37 = 5.5F + var36 + 5.5F;
      int var31 = var10000;
      float var132;
      float var133;
      while (true) {
         int var148 = a.length;
         int var147 = var38;
         if (var147 < var148) {
            MsdfFontManager var193 = Prestige.c;
            Object[] var73 = new Object[]{var19};
            MsdfFontManager var72 = var193;
            MsdfFont var194 = var72.aReturningcx_C0158(var73);
            int var74 = this.j[var38];
            Object[] var76 = new Object[]{String.valueOf(var74), var13};
            MsdfFont var75 = var194;
            float var39 = var75.aReturningFloat(var76) * 0.9F;
            float var40 = 18.1F + var39 + 5.5F;
            int var149 = var31;
            if (var149 == 0) {
               int var152 = var31;
               float var151 = var37;
               float var150 = var40;
               var132 = var150;
               var133 = var151;
               float var128 = var150;
               float var129 = var151;
               if (var152 != 0) {
                  break;
               }

               float var154 = var129;
               float var153 = var128;
               float var130 = var153;
               float var131 = var154;
               float var226;
               int var155 = (var226 = var130 - var131) == 0.0F ? 0 : (var226 < 0.0F ? -1 : 1);
               if (var155 > 0) {
                  var37 = var40;
               }

               var38++;
            }

            int var156 = var31;
            if (var156 == 0) {
               continue;
            }
         }

         float var195 = var34 + 3.0F + var35 * a.length;
         var133 = 3.0F;
         var132 = var195;
         break;
      }

      float var188 = var132 + var133;
      Object[] var80 = new Object[0];
      ResourcesWidget var79 = this;
      byte var189 = ((byte)((var79.dReturningBoolean(var80)) ? 1 : 0));
      Object[] var82 = new Object[0];
      ResourcesWidget var81 = this;
      byte var190 = ((byte)((var81.cReturningBoolean(var82)) ? 1 : 0));
      var10004 = new Object[]{null, var188};
      var10004[0] = var37;
      Object[] var84 = var10004;
      ResourcesWidget var83 = this;
      var83.iReturningVoid(var84);
      float var41 = this.e;
      float var42 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var188;
      var10011[5] = var37;
      var10011[4] = var42;
      var10011[3] = var41;
      var10011[2] = var3;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var85 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var85);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var23};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var188;
      var10011[5] = var37;
      var10011[4] = var42;
      var10011[3] = var41;
      var10011[2] = var3;
      var10011[1] = var6;
      var10011[0] = var2;
      Object[] var86 = var10011;
      FilledRectangleRenderer.cReturningVoid(var86);
      float var43 = var42 + 3.0F;
      byte var157 = var190;
      float var134;
      if (var157 != 0) {
         float var158 = var41 + var37 - 5.5F - var36;
         var134 = var158;
      } else {
         var134 = var41 + 5.5F;
      }

      float var44 = var134;
      float var45 = var44;
      int var166;
      do {
         String var88 = var32;
         int var160 = var88.length();
         int var159 = var46;
         if (var159 >= var160) {
            break;
         }

         int var90 = var46;
         String var89 = var32;
         char var91 = var89.charAt(var90);
         String var47 = String.valueOf(var91);
         int var162 = var31;
         byte var161 = var190;
         byte var136 = var161;
         byte var135 = var161;
         int var137;
         if (var162 == 0) {
            byte var163 = var135;
            if (var163 != 0) {
               String var93 = var32;
               int var164 = var93.length() - 1 - var46;
               var137 = var164;
            } else {
               var137 = var46;
            }
         } else {
            byte var165 = var136;
            var137 = var165;
         }

         int var48 = var137;
         MsdfFontManager var196 = Prestige.c;
         Object[] var96 = new Object[]{var19};
         MsdfFontManager var95 = var196;
         MsdfFont var197 = var95.aReturningcx_C0158(var96);
         Object[] var97 = new Object[]{var15};
         Color var10005 = ClientUiUtil.dReturningColor(var97);
         short var10006 = 909;
         long var219 = 7618424086636907492L ^ var4;
         short var220 = 512;
         long var10008 = 4398350248560937581L ^ var4;
         int var221 = 10 + var48;
         Object[] var10010 = new Object[]{null, null, null, var17};
         var10010[2] = var221;
         var10010[1] = 10;
         var10010[0] = var10005;
         Object[] var98 = var10010;
         Object[] var223 = new Object[]{null, null, null, null, GameRenderUtil.bReturningColor(var98), var27};
         var223[3] = var43;
         var223[2] = var45;
         var223[1] = var47;
         var223[0] = var3;
         Object[] var100 = var223;
         MsdfFont var99 = var197;
         var99.v(var100);
         MsdfFontManager var207 = Prestige.c;
         Object[] var102 = new Object[]{var19};
         MsdfFontManager var101 = var207;
         MsdfFont var208 = var101.aReturningcx_C0158(var102);
         Object[] var104 = new Object[]{var47, var13};
         MsdfFont var103 = var208;
         var45 += var103.aReturningFloat(var104);
         var46++;
         var166 = var31;
      } while (var166 == 0);

      float var191 = var42 + var34 - 0.5F;
      float var209 = var41 + 5.5F;
      float var10003 = var41 + var37 - 5.5F;
      float var215 = var191 + 0.5F;
      Object[] var224 = new Object[]{null, null, null, null, null, UiMetrics.v, var11};
      var224[4] = var215;
      var224[3] = var10003;
      var224[2] = var191;
      var224[1] = var209;
      var224[0] = var3;
      Object[] var105 = var224;
      ShapeRenderer.lReturningVoid(var105);
      long var192 = System.currentTimeMillis();
      double var106 = var192 * 0.012;
      double var110 = 170.0 + 85.0 * Math.sin(var106);
      double var108 = 255.0;
      int var49 = (int)Math.min(var108, var110);
      float var50 = var42 + var34 + 3.0F;
      byte var146;
      while (true) {
         int var168 = a.length;
         int var167 = var51;
         if (var167 < var168) {
            int var170 = var31;
            byte var169 = ((byte)((this.n) ? 1 : 0));
            var146 = var169;
            byte var138 = var169;
            if (var170 != 0) {
               break;
            }

            int var144;
            label78: {
               label109: {
                  int var172 = var31;
                  byte var171 = var138;
                  int var141 = var171;
                  byte var139 = var171;
                  if (var172 == 0) {
                     byte var173 = var139;
                     byte var140 = var173;
                     byte var174 = var140;
                     if (var174 == 0) {
                        break label109;
                     }

                     int var175 = this.j[var51];
                     var141 = var175;
                  }

                  int var177 = var31;
                  int var176 = var141;
                  int var143 = var176;
                  int var142 = var176;
                  if (var177 != 0) {
                     int var181 = var143;
                     var144 = var181;
                     break label78;
                  }

                  int var179 = d[var51];
                  int var178 = var142;
                  if (var178 < var179) {
                     byte var180 = 1;
                     var144 = var180;
                     break label78;
                  }
               }

               var144 = 0;
            }

            int var52 = var144;
            int var182 = var52;
            Color var145;
            if (var182 != 0) {
               short var210 = 18783;
               long var211 = 6575658398156882228L ^ var4;
               short var212 = 26220;
               long var216 = 3319791167569079814L ^ var4;
               short var217 = 10376;
               long var218 = 3800672803865911533L ^ var4;
               Color var183 = new Color(235, 64, 64, var49);
               var145 = var183;
            } else {
               var145 = UiMetrics.s;
            }

            Color var53;
            String var54;
            float var56;
            float var57;
            float var58;
            float var59;
            label66: {
               var53 = var145;
               int var118 = this.j[var51];
               var54 = String.valueOf(var118);
               MsdfFontManager var198 = Prestige.c;
               Object[] var120 = new Object[]{var19};
               MsdfFontManager var119 = var198;
               MsdfFont var199 = var119.aReturningcx_C0158(var120);
               Object[] var122 = new Object[]{var54, var13};
               MsdfFont var121 = var199;
               float var55 = var121.aReturningFloat(var122) * 0.9F;
               var56 = var50 + (var35 - var33 * 0.9F) / 2.0F;
               var57 = var50 + (var35 - 9.6F) / 2.0F;
               byte var184 = var190;
               if (var184 != 0) {
                  var58 = var41 + var37 - 5.5F - 9.6F;
                  var59 = var58 - 3.0F - var55;
                  int var185 = var31;
                  if (var185 == 0) {
                     break label66;
                  }
               }

               var58 = var41 + 5.5F;
               var59 = var58 + 9.6F + 3.0F;
            }

            ItemStack var200 = this.m[var51];
            Object[] var222 = new Object[]{null, null, null, null, var3, var29};
            var222[3] = 0.6F;
            var222[2] = var57;
            var222[1] = var58;
            var222[0] = var200;
            Object[] var123 = var222;
            GameRenderUtil.aReturningBoolean(var123);
            MsdfFontManager var201 = Prestige.c;
            Object[] var125 = new Object[]{var19};
            MsdfFontManager var124 = var201;
            MsdfFont var202 = var124.aReturningcx_C0158(var125);
            Object[] var10009 = new Object[]{null, null, null, null, null, var53, var25};
            var10009[4] = 0.9F;
            var10009[3] = var56;
            var10009[2] = var59;
            var10009[1] = var54;
            var10009[0] = var3;
            Object[] var127 = var10009;
            MsdfFont var126 = var202;
            var126.w(var127);
            var50 += var35;
            var51++;
            int var186 = var31;
            if (var186 == 0) {
               continue;
            }
         }

         var146 = var189;
         break;
      }

      byte var187 = var146;
      if (var187 != 0) {
      }
   }

   static {

      {

      b();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(90237129353599L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[8];
      String var26 = "a%\u0004ÆDÊ`4E\u008e«¦æ©\u0090(\u0080\u008b¢'\u0082a\u0011\u001f\u000f/i\u000b\u0099Çq¬\u0084ê\u0002GÑN_~\u00810Ö¬\u0007\u008e)4i\u0081\u0007/õÆbå\u008bjrª^ÂÞPÂ©ãZÏpß\u001e\u008f\u0096òzÔç´Yö³\u009fóõ\u0080³\u0085\u009d\u009d¥å1 \u0000z\u0011~Ï\u0002®%\u000e\u00ad\u0010âF¤?P\u001c\u0086ß\u0001\u0014\u0099ssß\u00ad½F,{@\u009e\u0001~ÿ\u0003j-'m\u008dÈ×ãcôrËrá·\u0010\u0085\u009cw£Îº|\u0090÷Q\u0080\u00819\u001c;!\u0010É_@\u0091¬\u0019\u001c{\u0006Zg\u0014EÆ¯ª é2\u0002{\u000b*^Å\feX-8\u0010\u0011sÃx\u008f\u001bù¸\u0095{qÈñüV\u001fàÀ\u0018\r±\u008a6½`\u0088Ä,í\u0082V¹\u0080'\u0097Z\u0096\u00965§ ¨1";
      int var28 = "a%\u0004ÆDÊ`4E\u008e«¦æ©\u0090(\u0080\u008b¢'\u0082a\u0011\u001f\u000f/i\u000b\u0099Çq¬\u0084ê\u0002GÑN_~\u00810Ö¬\u0007\u008e)4i\u0081\u0007/õÆbå\u008bjrª^ÂÞPÂ©ãZÏpß\u001e\u008f\u0096òzÔç´Yö³\u009fóõ\u0080³\u0085\u009d\u009d¥å1 \u0000z\u0011~Ï\u0002®%\u000e\u00ad\u0010âF¤?P\u001c\u0086ß\u0001\u0014\u0099ssß\u00ad½F,{@\u009e\u0001~ÿ\u0003j-'m\u008dÈ×ãcôrËrá·\u0010\u0085\u009cw£Îº|\u0090÷Q\u0080\u00819\u001c;!\u0010É_@\u0091¬\u0019\u001c{\u0006Zg\u0014EÆ¯ª é2\u0002{\u000b*^Å\feX-8\u0010\u0011sÃx\u008f\u001bù¸\u0095{qÈñüV\u001fàÀ\u0018\r±\u008a6½`\u0088Ä,í\u0082V¹\u0080'\u0097Z\u0096\u00965§ ¨1"
         .length();
      char var25 = 16;
      int var34 = -1;

      label81:
      while (true) {
         String var35 = var26.substring(++var34, var34 + var25);
         int var10001 = -1;

         while (true) {
            byte[] var30 = var22.doFinal(var35.getBytes("ISO-8859-1"));
            String var51 = b(var30).intern();
            switch (var10001) {
               case 0:
                  var29[var27++] = var51;
                  if ((var34 += var25) >= var28) {
                     w = var29;
                     x = new String[8];
                     D = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(90237129353599L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[10];
                     String var15 = "aÔ)\u0086Ãò$\u007f¥^^]@k«0jÒäÀ®²\u0080òYö]p6\u0087|3¿ô°q6\u0083sa43\u007fó\u0098\u001b}n\u0007ÄmëÎ³býÀ\tÈdK xé";
                     int var16 = "aÔ)\u0086Ãò$\u007f¥^^]@k«0jÒäÀ®²\u0080òYö]p6\u0087|3¿ô°q6\u0083sa43\u007fó\u0098\u001b}n\u0007ÄmëÎ³býÀ\tÈdK xé".length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var38 = var17;
                        var10001 = var14++;
                        long var55 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var55;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var66 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var61) {
                              case 0:
                                 var38[var10001] = var66;
                                 if (var13 >= var16) {
                                    B = var17;
                                    C = new Integer[10];
                                    i = 40;
                                    J = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(90237129353599L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[4];
                                    String var4 = ">Ð0OlÙ\u0081PµþáÈ¶Láø";
                                    int var5 = ">Ð0OlÙ\u0081PµþáÈ¶Láø".length();
                                    label47:
                                    while (true) {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       long[] var40 = var6;
                                       var47 = var3++;
                                       long var58 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       
                                          long var8 = var58;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var66 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var64) {
                                             case 0:
                                                var40[var47] = var66;
                                                if (var2 >= var5) {
                                                   H = var6;
                                                   I = new Long[4];
                                                   h =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.ResourcesWidget_14962";
                                                   g =  */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.ResourcesWidget_8267";
                                                   a = new Item[]{Items.GOLDEN_APPLE, Items.TOTEM_OF_UNDYING, Items.END_CRYSTAL, Items.EXPERIENCE_BOTTLE};
                                                   c = new String[]{"Gapples", "Totems", "Crystals", "Exp"};
                                                   d = new int[]{5, 2, 16, 8};
                                                   break;
                                                }
                                                break;
                                             default:
                                                var40[var47] = var66;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "¬+6\u0081u+u\r±÷N¿\n\u0015\u007f¸";
                                                var5 = "¬+6\u0081u+u\r±÷N¿\n\u0015\u007f¸".length();
                                                var2 = 0;
                                          }

                                          int var49 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                          var40 = var6;
                                          var47 = var3++;
                                          var58 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var64 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var38[var10001] = var66;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "\u001béR\u0085Ú8}æt¹f\f\u0003òÿ\u0082";
                                 var16 = "\u001béR\u0085Ú8}æt¹f\f\u0003òÿ\u0082".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var38 = var17;
                           var10001 = var14++;
                           var55 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var61 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var34);
                  break;
               default:
                  var29[var27++] = var51;
                  if ((var34 += var25) < var28) {
                     var25 = var26.charAt(var34);
                     continue label81;
                  }

                  var26 = "\u000böKÝ1\u0090\u0017Oýq\u008c\u0003ÿéà\u0082\u001d2ÌÓNÜJÞ\u0010~p·v!\u007f\u008b[é\\\u000fddÞiñ";
                  var28 = "\u000böKÝ1\u0090\u0017Oýq\u008c\u0003ÿéà\u0082\u001d2ÌÓNÜJÞ\u0010~p·v!\u007f\u008b[é\\\u000fddÞiñ".length();
                  var25 = 24;
                  var34 = -1;
            }

            var35 = var26.substring(++var34, var34 + var25);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 28315;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cb", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cb_C0114",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 3071;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cb", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cb_C0114",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 25784;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cb", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cb_C0114",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 37;
            yield var15;
         }
         case 1 -> {
            byte var16 = 11;
            yield var16;
         }
         case 2 -> {
            byte var17 = 20;
            yield var17;
         }
         case 3 -> {
            byte var18 = 26;
            yield var18;
         }
         case 4 -> {
            byte var19 = 27;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 16;
            yield var21;
         }
         case 7 -> {
            byte var22 = 42;
            yield var22;
         }
         case 8 -> {
            byte var23 = 30;
            yield var23;
         }
         case 9 -> {
            byte var24 = 62;
            yield var24;
         }
         case 10 -> {
            byte var25 = 32;
            yield var25;
         }
         case 11 -> {
            byte var26 = 18;
            yield var26;
         }
         case 12 -> {
            byte var27 = 17;
            yield var27;
         }
         case 13 -> {
            byte var28 = 63;
            yield var28;
         }
         case 14 -> {
            byte var29 = 60;
            yield var29;
         }
         case 15 -> {
            byte var30 = 2;
            yield var30;
         }
         case 16 -> {
            byte var31 = 5;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 10;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 56;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 1;
            yield var37;
         }
         case 23 -> {
            byte var38 = 31;
            yield var38;
         }
         case 24 -> {
            byte var39 = 34;
            yield var39;
         }
         case 25 -> {
            byte var40 = 4;
            yield var40;
         }
         case 26 -> {
            byte var41 = 3;
            yield var41;
         }
         case 27 -> {
            byte var42 = 25;
            yield var42;
         }
         case 28 -> {
            byte var43 = 54;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 48;
            yield var45;
         }
         case 31 -> {
            byte var46 = 24;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 45;
            yield var48;
         }
         case 34 -> {
            byte var49 = 8;
            yield var49;
         }
         case 35 -> {
            byte var50 = 35;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 41;
            yield var52;
         }
         case 38 -> {
            byte var53 = 39;
            yield var53;
         }
         case 39 -> {
            byte var54 = 46;
            yield var54;
         }
         case 40 -> {
            byte var55 = 21;
            yield var55;
         }
         case 41 -> {
            byte var56 = 53;
            yield var56;
         }
         case 42 -> {
            byte var57 = 23;
            yield var57;
         }
         case 43 -> {
            byte var58 = 50;
            yield var58;
         }
         case 44 -> {
            byte var59 = 36;
            yield var59;
         }
         case 45 -> {
            byte var60 = 49;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 33;
            yield var63;
         }
         case 49 -> {
            byte var64 = 22;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 15;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 58;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 44;
            yield var70;
         }
         case 56 -> {
            byte var71 = 40;
            yield var71;
         }
         case 57 -> {
            byte var72 = 43;
            yield var72;
         }
         case 58 -> {
            byte var73 = 28;
            yield var73;
         }
         case 59 -> {
            byte var74 = 9;
            yield var74;
         }
         case 60 -> {
            byte var75 = 61;
            yield var75;
         }
         case 61 -> {
            byte var76 = 13;
            yield var76;
         }
         case 62 -> {
            byte var77 = 47;
            yield var77;
         }
         default -> 12;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "\u001fa\rm=+\ta\b7.<\u001e*\u000b1\"(\u000fm\u001c&i8\u0019";
      K[1] = "\n9\u0011}B`\u00016\u00002!m\u0014;\u000fY\u0014o\u0005(\u0013u\u0003b";
      K[2] = "pB)t+PfB,.8Gq\t/(4S`N8?\u007fAQ";
      K[3] = int.class;
      L[3] = "java/lang/Integer";
      K[4] = "$8apgd/7p?\u0004i:1";
      K[5] = double.class;
      L[5] = "java/lang/Double";
      K[6] = " \u0005\u00029v\u0007+\n\u0013v\u000b\u00129\u0010\u00115";
      K[7] = long.class;
      L[7] = "java/lang/Long";
      K[8] = "^x\u0015;P\u001bHx\u0010aC\f_3\u0013gO\u0018Nt\u0004p\u0004\bVt\u0006{^Ejo\u0006f^\u0002]x";
      K[9] = "\u001dO|h\u0015o\u000bOy2\u0006x\u001c\u0004z4\nl\rCm#A|\u0003";
      K[10] = "5q\u001aI\u0002'#q\u001f\u0013\u001104:\u001c\u0015\u001d$%}\u000b\u0002V4)";
      K[11] = "3u|2\u0000 FUw=\u0011o'[|6\u00155S";
      K[12] = void.class;
      L[12] = "java/lang/Void";
      K[13] = "g\u0015p\u001d# q\u0015uG07f^vA<#w\u0019aVw22";
      K[14] = "Ee\u0007R{:0E\f]juQK\u0007Vn/%";
      K[15] = "h&F+:J~&Cq)]im@w%Ix*W`n^z";
      K[16] = "ZAKA\by/a@N\u00196NoKE\u001dl:";
      K[17] = ">cU&4.5lDiI6&kM ";
      K[18] = "'\u00193-\u0018GR98\"\t\b373)\rRG";
      K[19] = float.class;
      L[19] = "java/lang/Float";
      K[20] = "\u0017\":P0Pb\u00021_!\u001f\u0003\f:T%Ew";
      K[21] = boolean.class;
      L[21] = "java/lang/Boolean";
      K[22] = "yR\u0016f?\u0005oR\u0013<,\u0012x\u0019\u0010: \u0006i^\u0007-k\u0011j";
      K[23] = "s\f{t*/\u0006,p{;`g\"{p?:\u0013";
      K[24] = "2\\\u0002$\u0015-$\\\u0007~\u0006:3\u0017\u0004x\n.\"P\u0013oA<\u0014";
      K[25] = "Uta1\bc Tj>\u0019,AZa5\u001dv5";
      K[26] = "8\u0010']dF%\u0005\u007f\u007f%K=\u0003";
      K[27] = "'CZv\rxRcQy\u001c73mZr\u0018mG";
      K[28] = "j\u0019H10v\u001f9C>!9~7H5%c\n";
      K[29] = "^Kj|}:HKo&n-_\u0000l b9NG{7))Q";
      K[30] = "~Q\u0007\rX#\u000bq\f\u0002Ilj\u007f\u0007\tM6\u001e";
      K[31] = char.class;
      L[31] = "java/lang/Character";
      K[32] = "\u000bV\u0005bcN~v\u000emr\u0001\u001fx\u0005fv[k";
      K[33] = "\u000f>\f#\u001a\u007fz\u001e\u0007,\u000b0\u001b\u0010\f'\u000fjo";
      K[34] = "\u0006\nK\"r4s*@-c{\u0012$K&g!f";
      K[35] = "C\u0017U$\u0010\u000bU\u0017P~\u0003\u001cB\\Sx\u000f\bS\u001bDoD\u001fA";
      K[36] = "m{_&'\t\u0018[T)6FyU_\"2\u001c\r";
      K[37] = "3k\u0015f\u001bv%k\u0010<\ba2 \u0013:\u0004u#g\u0004-Oen";
      K[38] = "#o\u001a0;\u0018VO\u0011?*W7A\u001a4.\rC";
      K[39] = "5\u0006Xf4r@&Si%=!(Xb!gU";
      K[40] = "J\u001d2;w\u0003J\u001d%g{\fPV%y{\u0019W'w-*X";
      K[41] = "u\u000eaO*\u0014u\u000ev\u0013&\u001boEv\r&\u000eh4$V~O";
      K[42] = "aK4|\u0003baK# \u000fm{\u0000#>\u000fx|qwfX";
      K[43] = "up]nn$upJ2b+o;J,b>hJ\u0018v5|";
      K[44] = "\u0016${llg\u0016$l0`h\fol.`}\u000b\u001e>u87";
      K[45] = "=*z+US=*mwY\\'amiYI \u0010=4\b";
      K[46] = ")gO\u000f\"\u0015?gJU1\u0002(,IS=\u00169k^Dv\u0006\u0002";
      K[47] = "w:xvG;\u0002\u001asyVtc\u0014xrR.\u0017";
      K[48] = "v+?)\u00195v+(u\u0015:l`(k\u0015/k\u0011}4L";
      K[49] = "\t\u0001(\u0007s4\u0002\u000e9H\u0012:\t\u0005=\u0012";
      K[50] = "_P\u007f%aU*pt*p\u001aK~\u007f!t@?";
      K[51] = ",Sh|\u007f\rYscsnB8}hxj\u0018L";
      K[52] = "yH%\u001aUj?I+\u001a1~@\f:JI,0\u000e;\u0016V\u0014";
      K[53] = "[G\u007f\u0002]c\u001d\u0007sY'y\u0001\u001c\u001c\\]2\u0010\u001c,\u0000Ce\\z'\u001d\u0017r\u0006J{\u0003@>`";
      K[54] = "b%\r?\"Fy{P'\u001c\u001es6\u000f#p,%sRx,{cz\u0012u{A':Su\u001c";
      K[55] = "\u0019\u000fu\u0016q~\u0002Q(\u000eO-\u0004\rs\u0001\u0018}]Y-mu#\\\u0018/\u001dw\"\u0000\u0007";
      K[56] = "\u0006&AWs)GuJT\u00159\u001cwW\u0000BgG*\fln1\u001dzC\u0000s<\u0016&";
      K[57] = "\u0003A\u0001m~Z\u0011\u0000\u00128\u0001N\u0013D\u0013:m|A\tKl\u0001P\u0018X\u0013-mM\u0015SO]";
      K[58] = "2?\r*\"_2b\u0002sHDs)\u0019!.SR2\u0006!\rNj7\u00027H\u0012n3\u001d)&\u001fm7\u001eL";
      K[59] = "=WUc.G~DB2_\\\u0000\u0015K3c\u0007xGWf8";
      K[60] = "!x\u0012v\u0016\u000fa!E&j\u001c\u001e3\b%R\r%<E}\u001ac.0M0Z_l#\b1j";
      K[61] = "h!l<\u001bP. b<\u007fEQesl\u0007\u0016!gr0\u0018.";
      K[62] = "N4M\u000fX0@+]\u001f>6\u007f(A\u0018\u00069D'\f@NWO+\u0004\r\u000ek\r8A\f>";
      K[63] = "\n$W6f\n]'P5V\nc5N`n\u0000X:\u00038&nS6\u000bufR\u0011%NtV";
      K[64] = ",\"<2mT~k7\u007fPQ+6!s05|0wwhE~1+hP";
      K[65] = "\t\u0000iR^/I\u000bx\u0001b\"\u0016\u0016f\u00005uHA>l\u001e#\u0015\u0000<Q\u0005}H\u0018";
      K[66] = "\u0013X\u000bv\n<U\u0018\u0007-p8I\u0003h(\nmX\u0003Xt\u0014:\u0014eSi@-NU\u000fw\u0017a(^\u0012#\u0000;\u0018\u0002\ftL]";
      K[67] = "\u001b%g\u000e\bcZvl\rns\u0001tqY9-[!,5\u0015{\u0000yeY\bv\u000b%";
      K[68] = "LDCQp\b\f\u001d\u0014\u0001\f\rs\u000fY\u00024\nH\u0000\u0014Z|d\u001fM@\fq\u0003\u0002\u001d\u0014[\f";
      K[69] = "\"\u000f;\n]\u00019\u000e,\u0011b\t]D!\u0018Z\u000efKl@\u0012`mGd\rR\\/T!\fb";
      K[70] = "6`B93l8\u007fR)Ug\u0007|N.me<s\u0003v%\u000bjrPw6g9d\u000e~U";
      K[71] = "X \u001f7H`\t/Y(w966\u001e<O>\r9Sd\u0007P[8\u0000e\u0014<\b.^lw";
      K[72] = "qL\u0018L! 2_\u000f\u001dP.LO]\u0011+o-T\\\u00060";
      K[73] = "HrPa\u001bc\u00107L~fa(;Kk^c\u00134\u00063\u0016\rI)Z`\u0000d\u00110\t<f";
      K[74] = "@V!\n\fo^Ze4\u001c\t\u001c\u000b$\u0004\u000e3[E~\u0004u0\u0019\b+OOwWR+4";
      K[75] = ".EE\u000eJ)0I\u00010ZO9X\u0016\b]t6\u0015N@3u+\u001d\u0007\bCw*A\u00180";
      K[76] = "d_\u0019onh6CL4^yZO\u000e:f~a@Cb.\u0010e\u0004\u0014i\"|%]C9^";
      K[77] = "$\u001a9dBHeI2g$X>K/3s\u0006e\u0016{__P?F;3B]4\u001a";
      K[78] = "~R3dqjpM#t\u0017fON?s/ctAr+g\r\"@!*taqV\u007f#\u0017";
      K[79] = "u\u001fZ\blL*CN\u0019\u001e\u001d\u0016\u000f^\b&\u001a-\u0000\u0013PntzMG\u0006c\u0013g\u001d\u0013Q\u001e";
      K[80] = "y\u000bvM\"1+B}\u0000\u001f;s\u0010~9cP)\u0019=\b' +\u0018a\u0017\u001f4w\thNx/)Evp";
      K[81] = "OpTOuVAoD_\u0013X~lXX+_Ec\u0015\u0000c1No\u001dM#\r\f|XL\u0013";
      K[82] = "\u0015\u0018t&\u00118QX5&vg\u0005Tip\u001aUU\u00142'v8\b\u0011q/\u0006:\tMn\u0017\u000b{\u001a\u0018vf\u0019:\tM\t";
      K[83] = "hb$,@7(i5\u007f|:wt+~+m()p\u0012\f$.%(l\u0015?)h";
      K[84] = "5\u0003\u0004J8^gJ\u000f\u0007\u0005A6\u0015\u000b\u001aBQ_K\u0016N}\u0007/I\u0017\u0012b?5\u0003\u0004J8^gJ\u000f\u0007\u0005";
      K[85] = "B2\u001fuaC\\>[Kb%U/Lsv\u001eZb\u0014;\u0018\u0015VjY{$WE/XK";
      K[86] = "O\u000b\u007f\u0015\u0002\u0011\u000fR(E~\u0003p@eFF\u0013KO(\u001e\u000e}@C SNA\u0002PeR~";
      K[87] = "[6D]1O\u001aeO^W_AgR\n\u0000\u0001\u001c4\rf,W@jF\n1ZK6";
      K[88] = "\u0016xONCI\r&\u0012V}\u0011\u0007kMR\u0011#T/\u0012\u0004}\t\u0013e\u001dJ\f\u001bRvH5";
      K[89] = "R\u001cpv8`RA\u007f/Ry\u0014\nwa9w\u0016\u0001\u001ea;j\u0014\u001e}{n-Pp$pkhV\u0000&q7wn\u0001wj(~\r\u001b\"-l\u0010T\u0010'hj`V\u0011{wR*\u000eIf(\"(\u000f\u0015y\u0010baW\f., r\u0012\r\u001e";
      K[90] = "\u000eT\u000f';\u0004_[I8\u0004^`B\u000e,<Z[MCtt4\u0001P\u001f'b]YIL{\u0004";
      K[91] = "+T)\u001dh\u001b'\u000f5\u0003\u0002\u0013L\u0017*\u0011:\u0016w\u0018gIrx|\u0014o\u00042D>\u0007*\u0005\u0002";
      K[92] = " UQ,aA<FZ7\u0011MXWF,)NcX\u000bta hT\u00039!\u001c*GF8\u0011";
      K[93] = "\u001dK\u001f\u001fM\"]\u0012HO1%\"\u0000\u0005L\t \u0019\u000fH\u0014ANNB\u001cBL)S\u0012H\u00151";
      K[94] = "\u0014\u0012\u00151>\u0010\u0006S\u0006dA\u0004\u0004\u0017\u0007f-6VZ[>A[\tR\u001f91Y\b\u000e\u0000\u0001";
      K[95] = "\u000b2qYR\bMr}\u0002(\u0013Yi~[Mi\u000bu\"LNYWku\u0000(";
      K[96] = "~\u0015(\u0002,c,\\#O\u0011|}\u0003'RVl\u0014\u0003>O}<s\u0018`\u0003c\u0002~\u0015(\u0002,c,\\#O\u0011";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3483425172504570L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3483425172504570L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3483425172504570L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 181;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 78;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 251;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 122;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 80;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 89;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 181;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 78;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 251;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cb_C0114",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cb" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
