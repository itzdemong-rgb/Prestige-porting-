package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.events.PacketReceiveEvent;
import dev.zprestige.prestige.api.events.WorldResetEvent;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.api.eventbus.EventListener;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.joml.Matrix4f;

public class SpeedWidget extends HudElement {
   private static final int a;
   private static final long c;
   private static final float m = 20.0F;
   private ManagedGlTexture d;
   private final float[] g;
   private int h;
   private long i;
   private float k;
   private long j;
   private float l;
   private float o;
   private float p;
   private float t;
   private float u;
   private static final long v = 35155711277500L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long[] B;
   private static final Integer[] C;
   private static final Map D;
   private static final long[] H;
   private static final Long[] I;
   private static final Map J;
   private static final Object[] K = new Object[80];
   private static final String[] L = new String[80];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;

   public SpeedWidget(long var1) {
      super("TPS", "Show the server's tick rate. Measured off the interval between WorldTimeUpdate packets.", ((35155711277500L ^ (35155711277500L ^ var1)) ^ 78412489646373L));
      var1 = 35155711277500L ^ var1;
      long var3 = var1 ^ 78412489646373L;
      short var10001 = 31394;
      long var10002 = 3487917344790357069L ^ var1;
      short var7 = 20613;
      long var10003 = 4083799495610502763L ^ var1;

      var10001 = 2542;
      var10002 = 5134952020033180881L ^ var1;
      this.g = new float[24];
      this.h = 0;
      this.i = invokeBinding1(340, 3392378428180381154L ^ var1);
      this.k = -1.0F;
      this.j = invokeBinding2(340, 3392378428180381154L ^ var1);
      this.l = -1.0F;
      this.o = -1.0F;
      this.u = 0.0F;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 45.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      SpeedWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @EventListener
   public void a(PacketReceiveEvent var1) {
      int var4 = Event.cReturningInt();
      Object[] var11 = new Object[0];
      PacketReceiveEvent var10 = var1;
      boolean var19 = var10.aReturningVoid(var11) instanceof WorldTimeUpdateS2CPacket;
      if (var19) {
         long var5 = System.currentTimeMillis();
         int var21 = var4;
         SpeedWidget var20 = this;
         SpeedWidget var18 = var20;
         SpeedWidget var17 = var20;
         if (var21 != 0) {
            long var25;
            int var22 = (var25 = var17.i - /* /*DECRYPT:dev.zprestige.prestige.cc_C0116:3:31184:8471940553022649274*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.SpeedWidget_31184") == 0L ? 0 : (var25 < 0L ? -1 : 1);
            if (var22 > 0) {
               long var7 = var5 - this.i;
               int var23 = var4;
               if (var23 == 0) {
                  return;
               }

               long var26;
               int var24 = (var26 = var7 - /* /*DECRYPT:dev.zprestige.prestige.cc_C0116:4:29626:7884200385486502354*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.SpeedWidget_29626") == 0L ? 0 : (var26 < 0L ? -1 : 1);
               if (var24 >= 0) {
                  float var10000 = 20000.0F / (float)var7;
                  float var16 = 20.0F;
                  float var15 = var10000;
                  float var9 = Math.min(var15, var16);
                  this.k = var9;
                  this.g[this.h] = var9;
                  this.h = (this.h + 1) % 24;
               }
            }

            var18 = this;
         }

         var18.i = var5;
      }
   }

   @EventListener
   public void a(WorldResetEvent var1) {
      int var10000 = Event.bReturningInt();
      int var4 = var10000;

      while (true) {
         byte var7 = 24;
         int var6 = var5;
         if (var6 < var7) {
            this.g[var5] = 0.0F;
            var5++;
            int var8 = var4;
            if (var8 != 0) {
               break;
            }

            int var9 = var4;
            if (var9 == 0) {
               continue;
            }
         }

         this.h = 0;
         this.i = /* /*DECRYPT:dev.zprestige.prestige.cc_C0116:5:340:3392344089824316221*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.SpeedWidget_340";
         this.k = -1.0F;
         this.l = -1.0F;
         break;
      }
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      long var2;
      RenderContext var4;
      Matrix4f var5;
      MeshBufferManager var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var29;
      int var31;
      label167: {
         var6 = (MeshBufferManager)var1[0];
         var4 = (RenderContext)var1[1];
         var5 = (Matrix4f)var1[2];
         var2 = (Long)var1[3];
         var7 = var2 ^ 49928519994039L;
         var9 = var2 ^ 41197988814736L;
         var11 = var2 ^ 48887442607471L;
         var13 = var2 ^ 124694493719688L;
         var15 = var2 ^ 81054074941871L;
         var17 = var2 ^ 36477842301344L;
         var19 = var2 ^ 13608202459885L;
         var21 = var2 ^ 29307267718371L;
         var23 = var2 ^ 113406911627307L;
         var25 = var2 ^ 17083579563515L;
         long var27 = var2 ^ 56760183293883L;
         var29 = var2 ^ 61849539686927L;
         var31 = Event.bReturningInt();
         int var191 = var31;
         SpeedWidget var190 = this;
         SpeedWidget var152 = var190;
         SpeedWidget var151 = var190;
         if (var191 == 0) {
            ManagedGlTexture var192 = var151.d;
            if (var192 != null) {
               break label167;
            }

            SpeedWidget var193 = this;
            var152 = var193;
         }

         short var10001 = 29396;
         long var10002 = 4522973534577105266L ^ var2;
         Object[] var72 = new Object[]{"assets/prestige/icons/hud/clock.png", var27};
         var152.d = TextureLoader.aReturningbT_C0095(var72);
      }

      float var34;
      float var35;
      String var36;
      label170: {
         long var32 = System.currentTimeMillis();
         var34 = (float)(var32 - this.j) * 0.005F;
         this.j = var32;
         float var316;
         int var10000 = (var316 = this.k - 0.0F) == 0.0F ? 0 : (var316 < 0.0F ? -1 : 1);
         int var195 = var31;
         int var194 = var10000;
         int var154 = var194;
         int var153 = var194;
         if (var195 == 0) {
            int var196 = var153;
            if (var196 < 0) {
               var35 = 0.0F;
               short var258 = 16483;
               long var274 = 2101592848718244804L ^ var2;
               var36 = "-.-";
               int var197 = var31;
               if (var197 == 0) {
                  break label170;
               }
            }

            long var317;
            int var198 = (var317 = this.i - invokeBinding6(340, 3392377879763486895L ^ var2)) == 0L ? 0 : (var317 < 0L ? -1 : 1);
            var154 = var198;
         }

         int var159;
         label154: {
            int var158;
            label153: {
               label171: {
                  int var200 = var31;
                  int var199 = var154;
                  int var156 = var199;
                  int var155 = var199;
                  if (var200 == 0) {
                     int var201 = var155;
                     if (var201 <= 0) {
                        break label171;
                     }

                     long var318;
                     int var202 = (var318 = var32 - this.i - invokeBinding7(17939, 7485453315086667757L ^ var2)) == 0L ? 0 : (var318 < 0L ? -1 : 1);
                     var156 = var202;
                  }

                  int var204 = var31;
                  int var203 = var156;
                  var158 = var203;
                  int var157 = var203;
                  if (var204 != 0) {
                     break label153;
                  }

                  int var205 = var157;
                  if (var205 > 0) {
                     var158 = 1;
                     break label153;
                  }
               }

               var159 = 0;
               break label154;
            }

            int var206 = var158;
            var159 = var206;
         }

         int var37 = var159;
         int var207 = var37;
         float var160;
         if (var207 != 0) {
            float var208 = 0.0F;
            var160 = var208;
         } else {
            var160 = this.k;
         }

         var35 = var160;
         Locale var259 = Locale.ROOT;
         short var275 = 8176;
         long var286 = 1193742077657216081L ^ var2;
         Object[] var287 = new Object[1];
         float var79 = var35;
         var287[0] = var79;
         Object[] var82 = var287;
         String var81 = "%.1f";
         Locale var80 = var259;
         var36 = String.format(var80, var81, var82);
      }

      SpeedWidget var170;
      float var171;
      label141: {
         int var212 = var31;
         float var211 = 0.0F;
         float var210 = this.l;
         SpeedWidget var209 = this;
         SpeedWidget var167 = var209;
         float var168 = var210;
         float var169 = var211;
         SpeedWidget var161 = var209;
         float var162 = var210;
         float var163 = var211;
         if (var212 == 0) {
            float var319;
            int var214 = (var319 = var162 - var163) == 0.0F ? 0 : (var319 < 0.0F ? -1 : 1);
            SpeedWidget var213 = var161;
            SpeedWidget var166 = var213;
            SpeedWidget var164 = var213;
            if (var214 < 0) {
               SpeedWidget var215 = var164;
               SpeedWidget var165 = var215;
               float var217 = var35;
               SpeedWidget var216 = var165;
               var170 = var216;
               var171 = var217;
               break label141;
            }

            var169 = var35;
            var168 = this.l;
            var167 = var166;
         }

         float var10003 = var34 * 0.5F;
         Object[] var10006 = new Object[]{null, null, null, var9};
         var10006[2] = var10003;
         var10006[1] = var169;
         var10006[0] = var168;
         Object[] var85 = var10006;
         var171 = ClientUiUtil.bReturningFloat(var85);
         var170 = var167;
      }

      label135: {
         var170.l = var171;
         float var260 = this.l;
         Object[] var298 = new Object[]{null, var29};
         var298[0] = var260;
         Object[] var86 = var298;
         Color var256 = aReturningColor(var86);
         int var219 = var31;
         SpeedWidget var218 = this;
         SpeedWidget var173 = var218;
         SpeedWidget var172 = var218;
         if (var219 == 0) {
            float var320;
            int var220 = (var320 = var172.o - 0.0F) == 0.0F ? 0 : (var320 < 0.0F ? -1 : 1);
            if (var220 < 0) {
               Color var88 = var256;
               this.o = var88.getRed();
               Color var89 = var256;
               this.p = var89.getGreen();
               Color var90 = var256;
               this.t = var90.getBlue();
               int var221 = var31;
               if (var221 == 0) {
                  break label135;
               }
            }

            float var276 = this.o;
            Color var92 = var256;
            float var288 = var92.getRed();
            Object[] var307 = new Object[]{null, null, null, var9};
            var307[2] = var34;
            var307[1] = var288;
            var307[0] = var276;
            Object[] var93 = var307;
            this.o = ClientUiUtil.bReturningFloat(var93);
            var276 = this.p;
            Color var94 = var256;
            var288 = var94.getGreen();
            var307 = new Object[]{null, null, null, var9};
            var307[2] = var34;
            var307[1] = var288;
            var307[0] = var276;
            Object[] var95 = var307;
            this.p = ClientUiUtil.bReturningFloat(var95);
            SpeedWidget var222 = this;
            var173 = var222;
         }

         float var278 = this.t;
         Color var97 = var256;
         float var290 = var97.getBlue();
         Object[] var309 = new Object[]{null, null, null, var9};
         var309[2] = var34;
         var309[1] = var290;
         var309[0] = var278;
         Object[] var98 = var309;
         var173.t = ClientUiUtil.bReturningFloat(var98);
      }

      Color var38;
      float var40;
      float var41;
      float var42;
      float var43;
      float var44;
      float var45;
      float var46;
      float var48;
      float var49;
      boolean var50;
      float var176;
      label128: {
         var38 = new Color((int)this.o, (int)this.p, (int)this.t);
         MsdfFontManager var261 = Prestige.c;
         Object[] var100 = new Object[]{var19};
         MsdfFontManager var99 = var261;
         MsdfFont var262 = var99.aReturningcx_C0158(var100);
         Object[] var102 = new Object[]{var7};
         MsdfFont var101 = var262;
         float var39 = var101.cReturningFloat(var102);
         var261 = Prestige.c;
         Object[] var104 = new Object[]{var19};
         MsdfFontManager var103 = var261;
         MsdfFont var264 = var103.aReturningcx_C0158(var104);
         Object[] var106 = new Object[]{var36, var15};
         MsdfFont var105 = var264;
         var40 = var105.aReturningFloat(var106) * 1.0F;
         var261 = Prestige.c;
         Object[] var108 = new Object[]{var19};
         MsdfFontManager var107 = var261;
         MsdfFont var266 = var107.aReturningcx_C0158(var108);
         short var279 = 17732;
         long var291 = 8711890729407819488L ^ var2;
         Object[] var110 = new Object[]{"tps", var15};
         MsdfFont var109 = var266;
         var41 = var109.aReturningFloat(var110) * 0.65F;
         var42 = var39 * 1.0F;
         var43 = var39 * 0.65F;
         var44 = 7.5F;
         var45 = 5.5F + var44 + 5.5F;
         var46 = var45 + 0.5F + 5.5F;
         float var267 = var40 + 3.0F + var41;
         float var112 = 28.0F;
         float var111 = var267;
         float var47 = Math.max(var111, var112);
         var48 = var46 + var47 + 5.5F;
         Object[] var113 = new Object[]{var39};
         var49 = UiMetrics.bReturningFloat(var113);
         Object[] var115 = new Object[0];
         SpeedWidget var114 = this;
         var50 = var114.cReturningBoolean(var115);
         MinecraftClient var116 = b;
         boolean var51 = var116.currentScreen instanceof HudEditorScreen;
         int var223 = var31;
         if (var223 == 0) {
            boolean var224 = var50;
            if (var224) {
               int var226 = var31;
               float var225 = this.u;
               var176 = var225;
               float var174 = var225;
               if (var226 != 0) {
                  break label128;
               }

               float var227 = var174;
               float var175 = var227;
               float var321;
               int var228 = (var321 = var175 - 0.0F) == 0.0F ? 0 : (var321 < 0.0F ? -1 : 1);
               if (var228 > 0) {
                  boolean var229 = var51;
                  if (!var229) {
                     this.e = this.e - (var48 - this.u);
                  }
               }
            }

            this.u = var48;
         }

         var176 = this.e;
      }

      float var52 = var176;
      float var53 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var11};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var49;
      var10011[5] = var48;
      var10011[4] = var53;
      var10011[3] = var52;
      var10011[2] = var5;
      var10011[1] = var4;
      var10011[0] = var6;
      Object[] var122 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var122);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var21};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var49;
      var10011[5] = var48;
      var10011[4] = var53;
      var10011[3] = var52;
      var10011[2] = var5;
      var10011[1] = var4;
      var10011[0] = var6;
      Object[] var123 = var10011;
      FilledRectangleRenderer.cReturningVoid(var123);
      Object[] var124 = new Object[]{var17};
      Color var54 = ClientUiUtil.dReturningColor(var124);
      boolean var230 = var50;
      float var177;
      if (var230) {
         float var231 = var52 + var48 - 5.5F - var44;
         var177 = var231;
      } else {
         var177 = var52 + 5.5F;
      }

      float var55 = var177;
      boolean var232 = var50;
      float var178;
      if (var232) {
         float var233 = var52 + var48 - var45 - 0.5F;
         var178 = var233;
      } else {
         var178 = var52 + var45;
      }

      float var57;
      float var58;
      float var59;
      label119: {
         float var56 = var178;
         ManagedGlTexture var299 = this.d;
         float var10005 = var53 + var49 / 2.0F - var44 / 2.0F;
         var10011 = new Object[]{null, null, null, null, null, null, null, null, var54, var25};
         var10011[7] = var44;
         var10011[6] = var44;
         var10011[5] = var10005;
         var10011[4] = var55;
         var10011[3] = var299;
         var10011[2] = var5;
         var10011[1] = var4;
         var10011[0] = var6;
         Object[] var127 = var10011;
         TexturedRectangleRenderer.cReturningVoid(var127);
         float var292 = var53 + 3.0F;
         float var300 = var56 + 0.5F;
         float var10004 = var53 + var49 - 3.0F;
         Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var13};
         var10008[4] = var10004;
         var10008[3] = var300;
         var10008[2] = var292;
         var10008[1] = var56;
         var10008[0] = var5;
         Object[] var128 = var10008;
         ShapeRenderer.lReturningVoid(var128);
         var57 = var53 + 3.0F;
         boolean var234 = var50;
         if (var234) {
            float var60 = var52 + var48 - var46;
            var59 = var60 - var41;
            var58 = var59 - 3.0F - var40;
            int var235 = var31;
            if (var235 == 0) {
               break label119;
            }
         }

         var58 = var52 + var46;
         var59 = var58 + var40 + 3.0F;
      }

      MsdfFontManager var268 = Prestige.c;
      Object[] var130 = new Object[]{var19};
      MsdfFontManager var129 = var268;
      MsdfFont var269 = var129.aReturningcx_C0158(var130);
      Object[] var10009 = new Object[]{null, null, null, null, null, var38, var23};
      var10009[4] = 1.0F;
      var10009[3] = var57;
      var10009[2] = var58;
      var10009[1] = var36;
      var10009[0] = var5;
      Object[] var132 = var10009;
      MsdfFont var131 = var269;
      var131.w(var132);
      var268 = Prestige.c;
      Object[] var134 = new Object[]{var19};
      MsdfFontManager var133 = var268;
      MsdfFont var271 = var133.aReturningcx_C0158(var134);
      short var293 = 21916;
      long var301 = 4005628299562303033L ^ var2;
      float var305 = var57 + (var42 - var43) - 0.5F;
      var10009 = new Object[]{null, null, null, null, null, UiMetrics.t, var23};
      var10009[4] = 0.65F;
      var10009[3] = var305;
      var10009[2] = var59;
      var10009[1] = "tps";
      var10009[0] = var5;
      Object[] var136 = var10009;
      MsdfFont var135 = var271;
      var135.w(var136);
      float var257 = var57 + var42 + 1.0F + 4.0F;
      boolean var236 = var50;
      float var179;
      if (var236) {
         float var237 = var52 + 5.5F;
         var179 = var237;
      } else {
         var179 = var52 + var46;
      }

      float var61 = var179;
      boolean var238 = var50;
      float var180;
      if (var238) {
         float var239 = var52 + var48 - var46;
         var180 = var239;
      } else {
         var180 = var52 + var48 - 5.5F;
      }

      float var62 = var180;
      float var63 = (var62 - var61) / 24.0F;
      while (true) {
         int var280 = 2542;
         long var294 = 5134948164491616668L ^ var2;
         byte var241 = 24;
         int var240 = var64;
         if (var240 < var241) {
            var280 = this.h + var64;
            var293 = 2542;
            var301 = 5134948164491616668L ^ var2;
            float var65 = this.g[var280 % 24];
            int var242 = var31;
            if (var242 != 0) {
               break;
            }

            label173: {
               int var245 = var31;
               float var244 = 0.0F;
               float var243 = var65;
               float var185 = var243;
               float var186 = var244;
               float var181 = var243;
               float var182 = var244;
               if (var245 == 0) {
                  float var247 = var182;
                  float var246 = var181;
                  float var183 = var246;
                  float var184 = var247;
                  float var322;
                  int var248 = (var322 = var183 - var184) == 0.0F ? 0 : (var322 < 0.0F ? -1 : 1);
                  if (var248 <= 0) {
                     break label173;
                  }

                  var186 = var65 / 20.0F * 3.5F;
                  var185 = 0.5F;
               }

               float var66 = var185 + var186;
               float var67 = var61 + var64 * var63;
               Object[] var303 = new Object[]{null, var29};
               var303[0] = var65;
               Object[] var142 = var303;
               Color var68 = aReturningColor(var142);
               int var250 = var31;
               int var249 = var64;
               int var188 = var249;
               int var187 = var249;
               int var189;
               if (var250 == 0) {
                  short var282 = 29295;
                  long var296 = 828414787974781465L ^ var2;
                  byte var252 = 23;
                  int var251 = var187;
                  if (var251 == var252) {
                     short var272 = 27396;
                     long var283 = 6428031354839712635L ^ var2;
                     short var253 = 220;
                     var189 = var253;
                  } else {
                     short var273 = 7494;
                     long var284 = 8680715020837696818L ^ var2;
                     var189 = 110;
                  }
               } else {
                  int var254 = var188;
                  var189 = var254;
               }

               int var69 = var189;
               float var285 = var67 + 0.2F;
               float var297 = var257 - var66;
               float var304 = var67 + var63 - 0.2F;
               Color var145 = var68;
               int var310 = var145.getRed();
               Color var146 = var68;
               int var311 = var146.getGreen();
               Color var147 = var68;
               Object[] var312 = new Object[]{null, null, null, null, null, new Color(var310, var311, var147.getBlue(), var69), var13};
               var312[4] = var257;
               var312[3] = var304;
               var312[2] = var297;
               var312[1] = var285;
               var312[0] = var5;
               Object[] var148 = var312;
               ShapeRenderer.lReturningVoid(var148);
            }

            var64++;
            int var255 = var31;
            if (var255 == 0) {
               continue;
            }
         }

         Object[] var306 = new Object[]{null, var49};
         var306[0] = var48;
         Object[] var150 = var306;
         SpeedWidget var149 = this;
         var149.iReturningVoid(var150);
         break;
      }
   }

   private static Color aReturningColor(Object[] var0) {
      float var1 = (Float)var0[0];
      long var2 = (Long)var0[1];
      var2 = 35155711277500L ^ var2;
      int var4 = Event.cReturningInt();
      float var37;
      int var10000 = (var37 = var1 - 19.0F) == 0.0F ? 0 : (var37 < 0.0F ? -1 : 1);
      int var10 = var4;
      int var9 = var10000;
      int var6 = var9;
      int var5 = var9;
      if (var10 != 0) {
         int var11 = var5;
         if (var11 >= 0) {
            short var19 = 6181;
            long var25 = 507995377573936110L ^ var2;
            short var26 = 11733;
            long var32 = 6665588511449583123L ^ var2;
            short var33 = 20669;
            long var36 = 8862499492657296235L ^ var2;
            return new Color(96, 220, 130);
         }

         float var38;
         var6 = (var38 = var1 - 15.0F) == 0.0F ? 0 : (var38 < 0.0F ? -1 : 1);
      }

      int var13 = var4;
      int var12 = var6;
      int var8 = var12;
      int var7 = var12;
      if (var13 != 0) {
         int var14 = var7;
         if (var14 >= 0) {
            short var18 = 21289;
            long var23 = 8339209613449982189L ^ var2;
            short var24 = 15328;
            long var30 = 5532258724077246504L ^ var2;
            short var31 = 8754;
            long var35 = 5095256406439526908L ^ var2;
            return new Color(240, 200, 80);
         }

         float var39;
         var8 = (var39 = var1 - 10.0F) == 0.0F ? 0 : (var39 < 0.0F ? -1 : 1);
      }

      int var15 = var8;
      if (var15 >= 0) {
         short var17 = 21498;
         long var21 = 6569569680521621552L ^ var2;
         short var22 = 10112;
         long var28 = 7358051317469774914L ^ var2;
         short var29 = 16828;
         long var34 = 3560957176267203179L ^ var2;
         return new Color(245, 145, 60);
      } else {
         short var10002 = 11276;
         long var10003 = 1235657711479754693L ^ var2;
         short var20 = 17199;
         long var10004 = 2667388240366919919L ^ var2;
         short var27 = 12840;
         long var10005 = 7549179427257356775L ^ var2;
         return new Color(235, 75, 70);
      }
   }

   static {

      {

      b();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(25391203020820L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[7];
      String var28 = "kò=½²4òºØ¿\u0001&ïvÅ¬@fß\u0096\u0090HãØ\u008ddu!,\u0087°\u0089AP·Èú\u0003ü¬üJÿNÍ¨µP<»Nªp.Î\u0089¢iäÈÅ\u0098ä»5Õ\u008d÷#ÇVEt Eø½L6ëá\u0010·§L\u00adÂGm!Ü3LZTnäâ\u0010\u008a÷$\u0085Èax¾\u0092ç^Íe¡AÈ\u0088\u008e5³ÍÔ=\nahàE±kzy\u0092'ºÎäÚ@±U«Z\u001d\u009diªÜ\u008f1¹\u0017Wqkeâÿï>p$g¹\\¡Ä&\u0014úÈLÇ\f\u009b\\\u0089\u0098ÕÊ\u008f\\\u0006X\u0084\u001a£\u008aÞÙ\u0086tûó!\u008dL\u0005Åê\u008c\u001cÞ9\u0013u\\}ê<ý§È\u000e\f¡\u0084æ\u0099x\u008b\u0003Ã\rÀ¢\u009cá\u0089f75\tt$qÑ\fg*R\u009e\u0094¿ú~\u00186\u009f\u001dOy\u0098";
      int var30 = "kò=½²4òºØ¿\u0001&ïvÅ¬@fß\u0096\u0090HãØ\u008ddu!,\u0087°\u0089AP·Èú\u0003ü¬üJÿNÍ¨µP<»Nªp.Î\u0089¢iäÈÅ\u0098ä»5Õ\u008d÷#ÇVEt Eø½L6ëá\u0010·§L\u00adÂGm!Ü3LZTnäâ\u0010\u008a÷$\u0085Èax¾\u0092ç^Íe¡AÈ\u0088\u008e5³ÍÔ=\nahàE±kzy\u0092'ºÎäÚ@±U«Z\u001d\u009diªÜ\u008f1¹\u0017Wqkeâÿï>p$g¹\\¡Ä&\u0014úÈLÇ\f\u009b\\\u0089\u0098ÕÊ\u008f\\\u0006X\u0084\u001a£\u008aÞÙ\u0086tûó!\u008dL\u0005Åê\u008c\u001cÞ9\u0013u\\}ê<ý§È\u000e\f¡\u0084æ\u0099x\u008b\u0003Ã\rÀ¢\u009cá\u0089f75\tt$qÑ\fg*R\u009e\u0094¿ú~\u00186\u009f\u001dOy\u0098"
         .length();
      char var27 = 16;
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     w = var31;
                     x = new String[7];
                     D = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(25391203020820L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[18];
                     String var15 = "\u0006ð¤\u0093É\u001cY>ÆC\u001bTz´*f8»í\u0003qV\u00954\u0084l\u000fÇ!n\u0080\u0004\u0081\u000e\u001eë\u0083\u0091\u0000-ÙPòÉ\u0081\u0002VÕµ«\u0015\u0017ë½A&î\u0002\t\u001bÌ\u00ady!µ5ú¯\u0093K¨\n¶Ý¾ÀÖ\u0000Èi×Û\"O.#îËº¿à\u0092¦¿u\u0098´³3\u008a+â©EvÏ\u007fkyqp>,Å\u000b`SÓó'\u000fî\u007f\u0012bw\u0083ó";
                     int var16 = "\u0006ð¤\u0093É\u001cY>ÆC\u001bTz´*f8»í\u0003qV\u00954\u0084l\u000fÇ!n\u0080\u0004\u0081\u000e\u001eë\u0083\u0091\u0000-ÙPòÉ\u0081\u0002VÕµ«\u0015\u0017ë½A&î\u0002\t\u001bÌ\u00ady!µ5ú¯\u0093K¨\n¶Ý¾ÀÖ\u0000Èi×Û\"O.#îËº¿à\u0092¦¿u\u0098´³3\u008a+â©EvÏ\u007fkyqp>,Å\u000b`SÓó'\u000fî\u007f\u0012bw\u0083ó"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    B = var17;
                                    C = new Integer[18];
                                    a = 24;
                                    J = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(25391203020820L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[5];
                                    String var4 = "\u001d\u0000ÃptNH\u001c2êþ^Ë|W\u0014}/è%-\u001d\u0093Á";
                                    int var5 = "\u001d\u0000ÃptNH\u001c2êþ^Ë|W\u0014}/è%-\u001d\u0093Á".length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   H = var6;
                                                   I = new Long[5];
                                                   c = /* /*DECRYPT:dev.zprestige.prestige.cc_C0116:8:26555:4146815449467661776*/ */ "DECRYPT_ME_dev.zprestige.prestige.client.ui.hud.SpeedWidget_26555";
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "\u0083Å5óQ?\u0010\u0010ù\u0013\u001fQ6ñ\u0019?";
                                                var5 = "\u0083Å5óQ?\u0010\u0010ù\u0013\u001fQ6ñ\u0019?".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "³°¸<@:Pþ)N\u0081;\u007fDaÝ";
                                 var16 = "³°¸<@:Pþ)N\u0081;\u007fDaÝ".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "¦\u007fê¹\u0093\u0085Ó¢èÁ_\u00136ÿ\\|\u0010ð'#\u000fã'g\u0001\u0003þUÚÒÍ®;";
                  var30 = "¦\u007fê¹\u0093\u0085Ó¢èÁ_\u00136ÿ\\|\u0010ð'#\u000fã'g\u0001\u0003þUÚÒÍ®;".length();
                  var27 = 16;
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 10293;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cc", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cc_C0116",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27622;
      if (C[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = B[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])D.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               D.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cc", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         C[var3] = var15;
      }

      return C[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cc_C0116",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19048;
      if (I[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = H[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])J.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               J.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cc", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         I[var3] = var15;
      }

      return I[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cc_C0116",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = L[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = K[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 60;
            yield var15;
         }
         case 1 -> {
            byte var16 = 7;
            yield var16;
         }
         case 2 -> {
            byte var17 = 52;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 38;
            yield var22;
         }
         case 8 -> {
            byte var23 = 30;
            yield var23;
         }
         case 9 -> {
            byte var24 = 35;
            yield var24;
         }
         case 10 -> {
            byte var25 = 20;
            yield var25;
         }
         case 11 -> {
            byte var26 = 12;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 10;
            yield var28;
         }
         case 14 -> {
            byte var29 = 49;
            yield var29;
         }
         case 15 -> {
            byte var30 = 17;
            yield var30;
         }
         case 16 -> {
            byte var31 = 42;
            yield var31;
         }
         case 17 -> {
            byte var32 = 25;
            yield var32;
         }
         case 18 -> {
            byte var33 = 57;
            yield var33;
         }
         case 19 -> {
            byte var34 = 9;
            yield var34;
         }
         case 20 -> {
            byte var35 = 46;
            yield var35;
         }
         case 21 -> {
            byte var36 = 11;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 36;
            yield var38;
         }
         case 24 -> {
            byte var39 = 21;
            yield var39;
         }
         case 25 -> {
            byte var40 = 55;
            yield var40;
         }
         case 26 -> {
            byte var41 = 39;
            yield var41;
         }
         case 27 -> {
            byte var42 = 8;
            yield var42;
         }
         case 28 -> {
            byte var43 = 43;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 48;
            yield var45;
         }
         case 31 -> {
            byte var46 = 2;
            yield var46;
         }
         case 32 -> {
            byte var47 = 16;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 4;
            yield var49;
         }
         case 35 -> {
            byte var50 = 3;
            yield var50;
         }
         case 36 -> {
            byte var51 = 34;
            yield var51;
         }
         case 37 -> {
            byte var52 = 29;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 5;
            yield var55;
         }
         case 41 -> {
            byte var56 = 15;
            yield var56;
         }
         case 42 -> {
            byte var57 = 54;
            yield var57;
         }
         case 43 -> {
            byte var58 = 1;
            yield var58;
         }
         case 44 -> {
            byte var59 = 44;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 45;
            yield var61;
         }
         case 47 -> {
            byte var62 = 47;
            yield var62;
         }
         case 48 -> {
            byte var63 = 6;
            yield var63;
         }
         case 49 -> {
            byte var64 = 63;
            yield var64;
         }
         case 50 -> {
            byte var65 = 27;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 40;
            yield var67;
         }
         case 53 -> {
            byte var68 = 61;
            yield var68;
         }
         case 54 -> {
            byte var69 = 32;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 62;
            yield var71;
         }
         case 57 -> {
            byte var72 = 23;
            yield var72;
         }
         case 58 -> {
            byte var73 = 0;
            yield var73;
         }
         case 59 -> {
            byte var74 = 26;
            yield var74;
         }
         case 60 -> {
            byte var75 = 56;
            yield var75;
         }
         case 61 -> {
            byte var76 = 14;
            yield var76;
         }
         case 62 -> {
            byte var77 = 51;
            yield var77;
         }
         default -> 31;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            L[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      K[0] = "ms[\u0007\u001a\u0000f|JHg\u0015tfH\u000b";
      K[1] = long.class;
      L[1] = "java/lang/Long";
      K[2] = "{$J\u00027fp+[MTke-";
      K[3] = float.class;
      L[3] = "java/lang/Float";
      K[4] = "rW\u000bS\u000f\bdW\u000e\t\u001c\u001fs\u001c\r\u000f\u0010\u000bb[\u001a\u0018[\u0019S";
      K[5] = int.class;
      L[5] = "java/lang/Integer";
      K[6] = "\u0010?*`;P\u0006?/:(G\u0011t,<$S\u00003;+oC\u0017";
      K[7] = "qfM'=\\zi\\h^QodS\u0003kS~wO/|^";
      K[8] = "Gq\u00122]gQq\u0017hNpF:\u0014nBdW}\u0003y\tuG";
      K[9] = "=\r*\u007fw\u001aH-!pfU)#*{b\u000f]";
      K[10] = "*\u001a4\u0002C%*\u001a#^O*0Q#@O?7 r\u0019\u0017z";
      K[11] = "\u0005W\r+w\u0007\u0013W\bqd\u0010\u0004\u001c\u000bwh\u0004\u0015[\u001c`#\u0014\r[\u001ekyY1@\u001evy\u001e\u0006W";
      K[12] = "W\u0001 2_\u0012A\u0001%hL\u0005VJ&n@\u0011G\r1y\u000b\u0001I";
      K[13] = "\bK\u0017\"&)\bK\u0000~*&\u0012\u0000\u0000`*3\u0015qP={";
      K[14] = "51h\u001bf[51\u007fGjT/z\u007fYjA(\u000b(\u0006<";
      K[15] = "S4C8\n@E4Fb\u0019WR\u007fEd\u0015CC8Rs^SO";
      K[16] = "k\bmtqu\u001e(f{`:\u007f&mpd`\u000b";
      K[17] = void.class;
      L[17] = "java/lang/Void";
      K[18] = "9zI\u001d)F/zLG:Q81OA6E)vXV}Tl";
      K[19] = "\u000esx)4x{Ss&%7\u001a]x-!mn";
      K[20] = "i\u00120GUA\u007f\u00125\u001dFVhY6\u001bJBy\u001e!\f\u0001U{";
      K[21] = "KZ2\u0014:\n>z9\u001b+E_t2\u0010/\u001f+";
      K[22] = "{\\z.\u0003p\u000e|q!\u0012?orz*\u0016e\u001b";
      K[23] = "q;-\u001b-Ll.u9lAt(";
      K[24] = "O?\u001ctJXD0\r;7@W7\u0004r";
      K[25] = "\u0014u8\u0000\u001b7\n}\"Oy-\u001du\"\u0004";
      K[26] = "t-C1 v\u0001\rH>19`\u0003C55c\u0014";
      K[27] = "I~[^V\\<^PQG\u0013]P[ZCI)";
      K[28] = "nXT;7qxXQa$fo\u0013Rg(r~TEpc`H";
      K[29] = "Bn/F\u0012\b7N$I\u0003GV@/B\u0007\u001d\"";
      K[30] = "\u0007%\tC\u0015,r\u0005\u0002L\u0004c\u0013\u000b\tG\u00009g";
      K[31] = "ca#WhX\u0016A(Xy\u0017wO#S}M\u0003";
      K[32] = boolean.class;
      L[32] = "java/lang/Boolean";
      K[33] = "QG)-W[GG,wDLP\f/qHXAK8f\u0003H^";
      K[34] = ":Z\u001c6\f\u0005Oz\u00179\u001dJ.t\u001c2\u0019\u0010Z";
      K[35] = "<\tu{v<*\tp!e+=Bs'i?,\u0005d0\"(0";
      K[36] = "\u001f8\\\f\u0016>j\u0018W\u0003\u0007q\u000b\u0016\\\b\u0003+\u007f";
      K[37] = "gJ814GqJ=k'Pf\u0001>m+DwF)z`UW";
      K[38] = "UX\u0005GtZCX\u0000\u001dgMT\u0013\u0003\u001bkYET\u0014\f NV";
      K[39] = "\u0017n\u0000HOTbN\u000bG^\u001b\u0003@\u0000LZAw";
      K[40] = "mT\u007f\u0016\u001e:f[nYv:hT}";
      K[41] = "\u0015\fS1\u0017``,X>\u0006/\u0001\"S5\u0002uu";
      K[42] = "b(\\\n'Pt(YP4GccZV8Sr$MAsD`";
      K[43] = "\u001e*hR\u001c/k\nc]\r`\n\u0004hV\t:~";
      K[44] = "+{,!N\u001e={){]\t*0*}Q\u001d;w=j\u001a\rv";
      K[45] = "Cb5\u000bE\b6B>\u0004TGWL5\u000fP\u001d#";
      K[46] = "]%-%-\"(\u0005&*<mI\u000b-!87=";
      K[47] = "C\u0012'4Mg62,;\\(W<'0Xr#";
      K[48] = "\u0010]<eV2\u001bR-*7<\u0010Y)p";
      K[49] = "\u0007Q\u0004\u0013\u001d/\u0001\u0010E\u001eo4=\u001a\\@\t`R]@\rP^";
      K[50] = "6\u007f%tF\u0011*zf\u001b\u0015\u0014,i3}\u000257v3^\u001f\r2r%\u001bGV.q0r\u001c\u0005/z^";
      K[51] = "\u000e\u001b:9\bC\u0005H)=s\u0014>\u001b46C\u0000TJ7e\u0013";
      K[52] = "f!#{|y/crz\u0000g6t(gW0h$q\u000b1v%p7r{bh~";
      K[53] = "d\u000f\u0007\"rVm\u001c\u001ed\u0019C<\u0004n`uO'XQ1x_\"bT6p\\g]\u0005;`Y]X\u00023c\u001cb\t\u000f#f&";
      K[54] = ":Dlcn\u0012#EpaQ\tSS?phL1Fib!v9Xjq-\u0004?DagQ";
      K[55] = "\u001a2F\rW\u000b\u001cs\u0007\u0000%\u0011 y\u001e^CDO>\u0002\u0013\u001az";
      K[56] = "'/\u0012\u0006j\u0010/0JY\u0013\u001dL-KU*F.8\u001dGc|&&\u001eTo\u000e :\u0015B\u0013";
      K[57] = "0k(M\u0002f3m(J\u007f9]%uZFg?0#H\u000f]7. [\u0003/12+M\u007f";
      K[58] = "h,m\u001d&\\;`|\u001bZGT =Jc\u001465kX*.;ha\u001cfB5,2[Z";
      K[59] = "&n\rf\u001e7ue\u0014&p\".s\u00125\fL)bLeH)vg\u0019#p#.sM2\u000bp%j\r\\\u0000|'0M>\u0015*5yw3\u00176sg\f`\u001c/3\t";
      K[60] = "\r\u0010\u0012RaM\u0014\u0011\u000eP^@d\u0007AAg\u0013\u0006\u0012\u0017S.)^\u001b\u0018Ud\u0016\u000f\u0016\bP^";
      K[61] = "^\u001b\u0007\rA+P_TJ}(\\_1X\u0011G\nAVSC(M]\u001b\n}";
      K[62] = "LXL4}\u001aCO\u0011r\u0003\u000f.R\u0011b:YLGGpscA\u001aM4?\u000fO^\u001es\u0003";
      K[63] = "\u0007/\u001dJ`o\u000e<\u0004\f\u000bzW2t\bgvDxKYjfABN^be\u0004}\u001fSr`>x\u0018[q%\u0001)\u0015Kt\u001f";
      K[64] = "\u00008/}#\u001f\u000e||:\u001f\u001c\u0002|\t!b\u001eo;!xyM\u0000|=5 s";
      K[65] = "pR\u000e\"\u0001,!Q]r~/@CP|G|\"V\u0006n\u000eF)T\u0003oA\"0U\u001fm~";
      K[66] = "16Z)\u000139)\u0002vx4Z4\u0003zAe8!Uh\b_? J*\u001d2g=^)x";
      K[67] = "\bVy'\u0013F[\u001ah!o]4\u0017(.\u001fPIU)|\u00154\t\u001b)n\u000bIK\u001a{do";
      K[68] = "I\r\u000b\ta\tA\u0012SV\u0018\f\"\u000fRZ!_@\u001a\u0004HheH\u0004\u0007[d\u0017N\u0018\fM\u0018";
      K[69] = "z7\b`\u0018jfc\u001b{!|\u001c-Ep\u0018,~8\u0013bQ\u0016&1\u001cd\u001b)w<\fa!";
      K[70] = "s\u001c)'< \u007f\u0003e [/\u0014\u0016i-b|v\u0003??+Fl\u0014>$gvpY<\u007f[";
      K[71] = "\u0003\u007fh|Jt\u001evn{0dzl=*\t5\u0018yk8@\u000f\u0010gh+L}\u0016{c=0";
      K[72] = "<_[t%MvU\fy\u001a\u0003.WHv]\u0013G\tYr`GxXTbe}<_[t%MvU\fy\u001a";
      K[73] = "|k{\u000f@[#n.Ixd[G\u001c6\u0018U'9xSGPr\u007f";
      K[74] = "\u0018B\u001e/?\u0010C__!V\u0010%MR/oCGX\u0004=&y\u001aP\u0003$g\u0002\u001a[\t0V";
      K[75] = "@VvwK\u001dOA+15\u000e\"\\+!\f^@I}3Ed\u0018@r5\u000f[IMb05";
      K[76] = "]9w:yL@&;)\u0006\u001c!)79?MC<a+vwK\"b8z\u0005M>i.\u0006";
      K[77] = "[5\u001e\u0006k Vz\u0004O\n'&:_Q3pD/\tCzJL1\nPv8J-\u0001F\n";
      K[78] = "TG\tk.6MF\u0015i\u00119=PZx(h_E\fjaR\u0007L\u0003l+mVA\u0013i\u0011";
      K[79] = "aO\u0001GB'o\u000bR\u0000~$c\u000b\"\u0005\u0013&hwV\u001dC-0\u0018\u0011\u0001\u000et\u000e";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = K[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(L[var4]);
            K[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            K[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  K[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(3382150282018789L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = K[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = L[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  K[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(3382150282018789L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        K[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(3382150282018789L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 220;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 239;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 103;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 202;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 122;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 223;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 220;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 239;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 103;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cc_C0116",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long invokeBinding1(int var0, long var1) {
         MethodHandle var7 = bindingCache1;
         MethodHandle var6 = bindingCache1;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache1 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding5(int var0, long var1) {
         MethodHandle var7 = bindingCache5;
         MethodHandle var6 = bindingCache5;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache5 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding7(int var0, long var1) {
         MethodHandle var7 = bindingCache7;
         MethodHandle var6 = bindingCache7;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache7 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding8(int var0, long var1) {
         MethodHandle var7 = bindingCache8;
         MethodHandle var6 = bindingCache8;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache8 = d(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
