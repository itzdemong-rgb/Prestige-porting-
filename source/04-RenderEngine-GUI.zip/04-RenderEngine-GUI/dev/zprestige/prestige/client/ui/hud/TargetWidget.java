package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.api.util.Easing;
import dev.zprestige.prestige.api.util.ExpiringValue;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.management.TargetManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.HudEditorScreen;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.GameRenderUtil;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.Window;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.AssetInfo.TextureAsset;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector4f;

public class TargetWidget extends HudElement {
   private static final long a;
   private static final long c;
   private final ExpiringValue d;
   private ManagedGlTexture g;
   private Identifier h;
   private String i;
   private float k;
   private float l;
   private float o;
   private float p;
   private float t;
   private float u;
   private float j;
   private UUID m;
   private long n;
   private Iterable q;
   private ItemStack r;
   private ItemStack s;
   private long v;
   private long w;
   private static final long x = 139550922882879L;
   private static final String[] y;
   private static final String[] B;
   private static final Map C = new HashMap(13);
   private static final long[] D;
   private static final Integer[] H;
   private static final Map I;
   private static final long[] J;
   private static final Long[] K;
   private static final Map L;
   private static final Object[] O = new Object[147];
   private static final String[] P = new String[147];

   public TargetWidget(long var1) {
      super("Target", "Displays information about your current target", ((139550922882879L ^ (139550922882879L ^ var1)) ^ 104538434682162L));
      var1 = 139550922882879L ^ var1;
      long var3 = var1 ^ 104538434682162L;
      long var5 = var1 ^ 76611634316755L;
      short var10001 = 17754;
      long var10002 = 2848889820922492153L ^ var1;
      short var11 = 20480;
      long var10003 = 7609588692376134055L ^ var1;

      this.d = new ExpiringValue(500.0F, false, Easing.BACK_IN_OUT, var5);
      this.i = "";
      this.k = 0.0F;
      this.l = 0.0F;
      this.o = 0.0F;
      this.p = 0.0F;
      this.t = 0.0F;
      this.u = 0.0F;
      this.j = 0.0F;
      var10001 = 11741;
      var10002 = 6326832055515464964L ^ var1;
      this.n = 0L;
      this.r = ItemStack.EMPTY;
      this.s = ItemStack.EMPTY;
      var10001 = 4112;
      var10002 = 8684443743125272782L ^ var1;
      this.v = 0L;
      var10001 = 4112;
      var10002 = 8684443743125272782L ^ var1;
      this.w = 0L;
   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      long var6 = var2 ^ 20883324854464L;
      MinecraftClient var10 = b;
      Window var11 = var10.getWindow();
      float var10000 = var11.getFramebufferWidth();
      Object[] var12 = new Object[]{var6};
      float var8 = var10000 / HudEditorScreen.bReturningFloat(var12);
      MinecraftClient var13 = b;
      Window var14 = var13.getWindow();
      var10000 = var14.getFramebufferHeight();
      Object[] var15 = new Object[]{var6};
      float var9 = var10000 / HudEditorScreen.bReturningFloat(var15);
      float var10001 = var8 / 2.0F - 65.0F;
      float var10002 = var9 / 2.0F + 80.0F;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = var10002;
      var10005[0] = var10001;
      Object[] var17 = var10005;
      TargetWidget var16 = this;
      var16.aReturningVoid(var17);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var2;
      Matrix4f var3;
      long var4;
      RenderContext var6;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      long var25;
      long var27;
      long var29;
      long var31;
      long var33;
      long var35;
      long var37;
      long var39;
      long var41;
      long var43;
      long var45;
      int var47;
      Object var244;
      label244: {
         var2 = (MeshBufferManager)var1[0];
         var6 = (RenderContext)var1[1];
         var3 = (Matrix4f)var1[2];
         var4 = (Long)var1[3];
         var7 = var4 ^ 10118816919681L;
         var9 = var4 ^ 130197577917328L;
         var11 = var4 ^ 13608202459885L;
         var13 = var4 ^ 24175257716744L;
         var15 = var4 ^ 113406911627307L;
         var17 = var4 ^ 120523633818450L;
         var19 = var4 ^ 57210688632464L;
         var21 = var4 ^ 61991993207385L;
         var23 = var4 ^ 60909922498822L;
         var25 = var4 ^ 73179937689918L;
         var27 = var4 ^ 342803718297L;
         var29 = var4 ^ 49928519994039L;
         var31 = var4 ^ 41197988814736L;
         var33 = var4 ^ 81054074941871L;
         var35 = var4 ^ 77183416798732L;
         var37 = var4 ^ 80242236617694L;
         var39 = var4 ^ 112793546742719L;
         var41 = var4 ^ 122446396730938L;
         var43 = var4 ^ 46684315333905L;
         var45 = var4 ^ 72801293730098L;
         int var10000 = Event.cReturningInt();
         this.w = System.currentTimeMillis() - this.v;
         var47 = var10000;
         this.v = System.currentTimeMillis();
         int var291 = var47;
         MinecraftClient var290 = b;
         MinecraftClient var243 = var290;
         MinecraftClient var242 = var290;
         if (var291 != 0) {
            MinecraftClient var67 = var242;
            boolean var292 = var67.currentScreen instanceof HudEditorScreen;
            if (!var292) {
               TargetManager var386 = Prestige.n;
               Object[] var72 = new Object[0];
               TargetManager var71 = var386;
               var244 = var71.aReturningPlayerEntity(var72);
               break label244;
            }

            MinecraftClient var293 = b;
            var243 = var293;
         }

         MinecraftClient var70 = var243;
         ClientPlayerEntity var294 = var70.player;
         var244 = var294;
      }

      Object var48;
      label247: {
         var48 = var244;
         int var296 = var47;
         Object var295 = var48;
         Object var246 = var295;
         Object var245 = var295;
         if (var296 != 0) {
            Object var297 = var245;
            if (var297 == null) {
               break label247;
            }

            var246 = var48;
         }

         Object var74 = var246;
         UUID var298 = ((PlayerEntity)var74).getUuid();
         if (var298 != null) {
            MinecraftClient var75 = b;
            ClientPlayNetworkHandler var387 = var75.getNetworkHandler();
            Object var76 = var48;
            UUID var78 = ((PlayerEntity)var76).getUuid();
            ClientPlayNetworkHandler var77 = var387;
            PlayerListEntry var299 = var77.getPlayerListEntry(var78);
            if (var299 != null) {
               break label247;
            }
         }

         var48 = null;
      }

      ExpiringValue var251;
      boolean var252;
      label228: {
         MinecraftClient var80 = b;
         boolean var301 = var80.currentScreen instanceof HudEditorScreen;
         ExpiringValue var300 = this.d;
         ExpiringValue var250 = var300;
         ExpiringValue var247 = var300;
         if (!var301) {
            Object var303 = var48;
            ExpiringValue var302 = var247;
            var250 = var302;
            ExpiringValue var248 = var302;
            if (var303 != null) {
               ExpiringValue var304 = var248;
               ExpiringValue var249 = var304;
               boolean var306 = true;
               ExpiringValue var305 = var249;
               var251 = var305;
               var252 = var306;
               break label228;
            }
         }

         var252 = false;
         var251 = var250;
      }

      Object[] var10004 = new Object[]{null, var37};
      var10004[0] = var252;
      Object[] var84 = var10004;
      ExpiringValue var83 = var251;
      var83.aReturningVoid(var84);
      float var49 = 130.0F;
      float var50 = 40.0F;
      MinecraftClient var85 = b;
      boolean var307 = var85.currentScreen instanceof HudEditorScreen;
      float var253;
      if (var307) {
         float var308 = 1.0F;
         var253 = var308;
      } else {
         ExpiringValue var388 = this.d;
         Object[] var88 = new Object[]{var39};
         ExpiringValue var87 = var388;
         var253 = var87.aReturningFloat(var88);
      }

      float var51 = var253;
      int var309 = var47;
      if (var309 != 0) {
         TargetWidget var289;
         label220: {
            float var533;
            int var310 = (var533 = var51 - 0.01F) == 0.0F ? 0 : (var533 < 0.0F ? -1 : 1);
            if (var310 > 0) {
               Matrix4f var52 = new Matrix4f();
               float var10001 = this.e + var49 / 2.0F;
               float var10002 = this.f + var50 / 2.0F;
               float var93 = 0.0F;
               float var92 = var10002;
               float var91 = var10001;
               Matrix4f var90 = var52;
               var90.translate(var91, var92, var93);
               float var97 = var51;
               float var96 = var51;
               float var95 = var51;
               Matrix4f var94 = var52;
               var94.scale(var95, var96, var97);
               var10001 = -this.e - var49 / 2.0F;
               var10002 = -this.f - var50 / 2.0F;
               float var101 = 0.0F;
               float var100 = var10002;
               float var99 = var10001;
               Matrix4f var98 = var52;
               var98.translate(var99, var100, var101);
               Matrix4f var104 = new Matrix4f();
               Matrix4f var103 = var52;
               Matrix4f var102 = var3;
               var52 = var102.mul((Matrix4fc)var103, var104);
               float var10003 = this.e;
               float var471 = this.f;
               Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(4.0F), var27};
               var10011[7] = 5;
               var10011[6] = var50;
               var10011[5] = var49;
               var10011[4] = var471;
               var10011[3] = var10003;
               var10011[2] = var52;
               var10011[1] = var6;
               var10011[0] = var2;
               Object[] var105 = var10011;
               BlurredRectangleRenderer.dReturningVoid(var105);
               var10001 = this.e;
               var10002 = this.f;
               var10003 = this.e + var49;
               float var472 = this.f + var50;
               Object[] var10009 = new Object[]{null, null, null, null, null, UiMetrics.r, new Vector4f(4.0F), var23};
               var10009[4] = var472;
               var10009[3] = var10003;
               var10009[2] = var10002;
               var10009[1] = var10001;
               var10009[0] = var52;
               Object[] var106 = var10009;
               ShapeRenderer.u(var106);
               Object var311 = var48;
               if (var311 != null) {
                  MinecraftClient var107 = b;
                  ClientPlayNetworkHandler var389 = var107.getNetworkHandler();
                  Object var108 = var48;
                  UUID var110 = ((PlayerEntity)var108).getUuid();
                  ClientPlayNetworkHandler var109 = var389;
                  PlayerListEntry var111 = var109.getPlayerListEntry(var110);
                  SkinTextures var112 = var111.getSkinTextures();
                  TextureAsset var113 = var112.body();
                  Identifier var53 = var113.texturePath();
                  int var312 = var47;
                  if (var312 != 0) {
                     Identifier var115 = this.h;
                     Identifier var114 = var53;
                     boolean var313 = var114.equals(var115);
                     if (!var313) {
                        this.h = var53;
                        Object[] var117 = new Object[]{var53, var17};
                        this.g = ManagedGlTexture.dReturningbT_C0095(var117);
                     }

                     Object var119 = var48;
                     Text var120 = ((PlayerEntity)var119).getName();
                     this.i = var120.getString();
                  }

                  float var54;
                  TargetWidget var261;
                  float var262;
                  label215: {
                     Object var121 = var48;
                     float var390 = ((PlayerEntity)var121).getHealth();
                     Object var122 = var48;
                     var54 = var390 + ((PlayerEntity)var122).getAbsorptionAmount();
                     double var123 = var54;
                     this.k = (float)Math.ceil(var123);
                     Object[] var126 = new Object[]{var48, var7};
                     TargetWidget var125 = this;
                     this.o = var125.cReturningFloat(var126);
                     MinecraftClient var127 = b;
                     int var316 = var47;
                     ClientPlayerEntity var315 = var127.player;
                     TargetWidget var314 = this;
                     TargetWidget var258 = var314;
                     Object var259 = var315;
                     TargetWidget var254 = var314;
                     ClientPlayerEntity var255 = var315;
                     if (var316 != 0) {
                        ClientPlayerEntity var318 = var255;
                        TargetWidget var317 = var254;
                        TargetWidget var260 = var317;
                        TargetWidget var256 = var317;
                        if (var318 == null) {
                           var262 = 0.0F;
                           var261 = var260;
                           break label215;
                        }

                        TargetWidget var319 = var256;
                        TargetWidget var257 = var319;
                        var259 = var48;
                        var258 = var257;
                     }

                     MinecraftClient var129 = b;
                     ClientPlayerEntity var131 = var129.player;
                     Object var130 = var259;
                     float var321 = ((PlayerEntity)var130).distanceTo((Entity)var131);
                     TargetWidget var320 = var258;
                     var261 = var320;
                     var262 = var321;
                  }

                  label209: {
                     int var267;
                     label208: {
                        label207: {
                           var261.j = var262;
                           int var323 = var47;
                           TargetWidget var322 = this;
                           TargetWidget var266 = var322;
                           TargetWidget var263 = var322;
                           if (var323 != 0) {
                              UUID var324 = var263.m;
                              if (var324 != null) {
                                 UUID var391 = this.m;
                                 Object var133 = var48;
                                 UUID var135 = ((PlayerEntity)var133).getUuid();
                                 UUID var134 = var391;
                                 byte var392 = ((byte)((var134.equals(var135)) ? 1 : 0));
                                 int var326 = var47;
                                 byte var325 = var392;
                                 var267 = var325;
                                 byte var264 = var325;
                                 if (var326 == 0) {
                                    break label208;
                                 }

                                 byte var327 = var264;
                                 byte var265 = var327;
                                 byte var328 = var265;
                                 if (var328 != 0) {
                                    break label207;
                                 }
                              }

                              Object var138 = var48;
                              this.m = ((PlayerEntity)var138).getUuid();
                              this.l = this.k;
                              this.p = this.o;
                              this.t = this.o;
                              TargetWidget var329 = this;
                              var266 = var329;
                           }

                           short var420 = 4112;
                           long var439 = 8684431366564942228L ^ var4;
                           var266.n = 0L;
                           int var330 = var47;
                           if (var330 != 0) {
                              break label209;
                           }
                        }

                        float var534;
                        int var331 = (var534 = var54 - (this.u - 0.05F)) == 0.0F ? 0 : (var534 < 0.0F ? -1 : 1);
                        var267 = var331;
                     }

                     int var332 = var267;
                     if (var332 < 0) {
                        this.n = System.currentTimeMillis();
                     }
                  }

                  this.u = var54;
                  ArrayList var55 = new ArrayList();
                  AttributeModifierSlot var142 = AttributeModifierSlot.ARMOR;
                  Iterator var56 = var142.iterator();

                  while (true) {
                     Iterator var143 = var56;
                     boolean var333 = var143.hasNext();
                     if (var333) {
                        Iterator var144 = var56;
                        EquipmentSlot var57 = (EquipmentSlot)var144.next();
                        int var334 = var47;
                        if (var334 == 0) {
                           break;
                        }

                        EquipmentSlot var145 = var57;
                        String var393 = var145.getName();
                        short var421 = 14891;
                        long var440 = 1940390070741377745L ^ var4;
                        String var147 = "body";
                        String var146 = var393;
                        boolean var394 = var146.equals(var147);
                        int var336 = var47;
                        boolean var335 = var394;
                        boolean var268 = var335;
                        if (var336 != 0) {
                           boolean var337 = var268;
                           boolean var269 = var337;
                           boolean var338 = var269;
                           if (var338) {
                              continue;
                           }

                           EquipmentSlot var151 = var57;
                           Object var150 = var48;
                           ItemStack var153 = ((PlayerEntity)var150).getEquippedStack(var151);
                           ArrayList var152 = var55;
                           boolean var270 = var152.add(var153);
                        }

                        int var339 = var47;
                        if (var339 != 0) {
                           continue;
                        }
                     }

                     ArrayList var154 = var55;
                     Collections.reverse(var154);
                     this.q = var55;
                     Object var155 = var48;
                     this.r = ((PlayerEntity)var155).getMainHandStack();
                     break;
                  }

                  Object var156 = var48;
                  this.s = ((PlayerEntity)var156).getOffHandStack();
               }

               long var380 = System.currentTimeMillis() - this.n;
               int var341 = var47;
               TargetWidget var340 = this;
               TargetWidget var272 = var340;
               TargetWidget var271 = var340;
               if (var341 != 0) {
                  short var422 = 4112;
                  long var441 = 8684431366564942228L ^ var4;
                  long var535;
                  int var342 = (var535 = var271.n - 0L) == 0L ? 0 : (var535 < 0L ? -1 : 1);
                  if (((var342) != 0)) {
                     short var423 = 26024;
                     long var442 = 7570640568155825198L ^ var4;
                     long var536;
                     int var343 = (var536 = var380 - 350L) == 0L ? 0 : (var536 < 0L ? -1 : 1);
                     if (var343 < 0) {
                        float var381 = 1.0F - (float)var380 / 350.0F;
                        float var395 = 55.0F * var381;
                        Object[] var10006 = new Object[]{null, null, null, var25};
                        var10006[2] = 1.0F;
                        var10006[1] = 0.0F;
                        var10006[0] = var51;
                        Object[] var159 = var10006;
                        int var383 = (int)(var395 * ClientUiUtil.aReturningFloat(var159));
                        var10001 = this.e;
                        var10002 = this.f;
                        var10003 = this.e + var49;
                        float var473 = this.f + var50;
                        short var10007 = 18830;
                        long var10008 = 4838691439992119650L ^ var4;
                        short var498 = 19137;
                        long var508 = 3873725967741428278L ^ var4;
                        short var509 = 30902;
                        long var10010 = 3231863270268276822L ^ var4;
                        var10009 = new Object[]{null, null, null, null, null, new Color(235, 70, 70, var383), new Vector4f(4.0F), var23};
                        var10009[4] = var473;
                        var10009[3] = var10003;
                        var10009[2] = var10002;
                        var10009[1] = var10001;
                        var10009[0] = var52;
                        Object[] var160 = var10009;
                        ShapeRenderer.u(var160);
                     }
                  }

                  var272 = this;
               }

               int var345 = var47;
               TargetWidget var344 = var272;
               TargetWidget var274 = var344;
               TargetWidget var273 = var344;
               if (var345 != 0) {
                  ManagedGlTexture var346 = var273.g;
                  if (var346 != null) {
                     float var396 = this.e + 5.0F;
                     var10001 = this.f + 5.0F;
                     ManagedGlTexture var521 = this.g;
                     Color var528 = Color.WHITE;
                     Object[] var10017 = new Object[]{null, null, null, var25};
                     var10017[2] = 1.0F;
                     var10017[1] = 0.0F;
                     var10017[0] = var51;
                     Object[] var162 = var10017;
                     float var10012 = ClientUiUtil.aReturningFloat(var162);
                     Object[] var10015 = new Object[]{null, null, var41};
                     var10015[1] = var10012;
                     var10015[0] = var528;
                     Object[] var163 = var10015;
                     Object[] var10014 = new Object[]{
                        null, null, null, null, null, null, null, null, null, var52, var521, ShapeRenderer.aReturningColor(var163), var9
                     };
                     var10014[8] = 0.0F;
                     var10014[7] = 3.75F;
                     var10014[6] = 3.75F;
                     var10014[5] = 22.5F;
                     var10014[4] = 3.75F;
                     var10014[3] = 30.0F;
                     var10014[2] = 30.0F;
                     var10014[1] = var10001;
                     var10014[0] = var396;
                     Object[] var164 = var10014;
                     GameRenderUtil.x(var164);
                     var10001 = this.e + 5.0F;
                     var10002 = this.f + 5.0F;
                     var10003 = this.e + 35.0F;
                     float var474 = this.f + 35.0F;
                     short var491 = 6146;
                     long var499 = 536741021708382433L ^ var4;
                     short var500 = 32603;
                     long var511 = 3679682413904140208L ^ var4;
                     short var512 = 32603;
                     long var522 = 3679682413904140208L ^ var4;
                     short var523 = 28584;
                     long var529 = 2298653172728956736L ^ var4;
                     Color var10005 = new Color(14, 14, 14, 140);
                     var10009 = new Object[]{null, null, null, null, null, null, null, var35};
                     var10009[6] = 0.0F;
                     var10009[5] = var10005;
                     var10009[4] = var474;
                     var10009[3] = var10003;
                     var10009[2] = var10002;
                     var10009[1] = var10001;
                     var10009[0] = var52;
                     Object[] var165 = var10009;
                     GameRenderUtil.lReturningVoid(var165);
                  }

                  MsdfFontManager var397 = Prestige.c;
                  Object[] var168 = new Object[]{var11};
                  MsdfFontManager var167 = var397;
                  MsdfFont var398 = var167.aReturningcx_C0158(var168);
                  String var445 = this.i;
                  var10003 = this.e + 40.0F;
                  float var475 = this.f + 3.0F;
                  Object[] var501 = new Object[]{null, null, null, null, UiMetrics.s, var43};
                  var501[3] = var475;
                  var501[2] = var10003;
                  var501[1] = var445;
                  var501[0] = var52;
                  Object[] var170 = var501;
                  MsdfFont var169 = var398;
                  var169.v(var170);
                  var274 = this;
               }

               label176: {
                  float var399 = var274.j;
                  var10004 = new Object[]{null, null, var19};
                  var10004[1] = 1;
                  var10004[0] = var399;
                  Object[] var171 = var10004;
                  float var172 = ClientUiUtil.cReturningFloat(var171);
                  String var400 = String.valueOf(var172);
                  short var427 = 8176;
                  long var446 = 9058728111241332491L ^ var4;
                  String var175 = "";
                  String var174 = ".0";
                  String var173 = var400;
                  String var382 = var173.replace(var174, var175) + "m";
                  MsdfFontManager var401 = Prestige.c;
                  Object[] var177 = new Object[]{var11};
                  MsdfFontManager var176 = var401;
                  MsdfFont var402 = var176.aReturningcx_C0158(var177);
                  Object[] var179 = new Object[]{var382, var33};
                  MsdfFont var178 = var402;
                  float var384 = var178.aReturningFloat(var179) * 0.75F;
                  MsdfFontManager var403 = Prestige.c;
                  Object[] var181 = new Object[]{var11};
                  MsdfFontManager var180 = var403;
                  MsdfFont var404 = var180.aReturningcx_C0158(var181);
                  Object[] var183 = new Object[]{var29};
                  MsdfFont var182 = var404;
                  float var385 = var182.cReturningFloat(var183);
                  MsdfFontManager var405 = Prestige.c;
                  Object[] var185 = new Object[]{var11};
                  MsdfFontManager var184 = var405;
                  MsdfFont var406 = var184.aReturningcx_C0158(var185);
                  var10003 = this.e + var49 - 5.5F - var384;
                  float var477 = this.f + 3.0F + (var385 - var385 * 0.75F) * 0.5F;
                  var10009 = new Object[]{null, null, null, null, null, UiMetrics.u, var15};
                  var10009[4] = 0.75F;
                  var10009[3] = var477;
                  var10009[2] = var10003;
                  var10009[1] = var382;
                  var10009[0] = var52;
                  Object[] var187 = var10009;
                  MsdfFont var186 = var406;
                  var186.w(var187);
                  var10001 = this.p;
                  var10002 = this.o;
                  var10003 = (float)this.w * 0.008F;
                  Object[] var487 = new Object[]{null, null, null, var31};
                  var487[2] = var10003;
                  var487[1] = var10002;
                  var487[0] = var10001;
                  Object[] var188 = var487;
                  this.p = ClientUiUtil.bReturningFloat(var188);
                  var10001 = this.l;
                  var10002 = this.k;
                  var10003 = (float)this.w * 0.01F;
                  var487 = new Object[]{null, null, null, var31};
                  var487[2] = var10003;
                  var487[1] = var10002;
                  var487[0] = var10001;
                  Object[] var189 = var487;
                  this.l = ClientUiUtil.bReturningFloat(var189);
                  float var537;
                  int var407 = (var537 = this.o - this.t) == 0.0F ? 0 : (var537 < 0.0F ? -1 : 1);
                  int var348 = var47;
                  int var347 = var407;
                  int var276 = var347;
                  int var275 = var347;
                  if (var348 != 0) {
                     int var349 = var275;
                     if (var349 >= 0) {
                        this.t = this.o;
                        int var350 = var47;
                        if (var350 != 0) {
                           break label176;
                        }
                     }

                     long var408 = System.currentTimeMillis() - this.n;
                     short var430 = 32683;
                     long var449 = 3225860693944729134L ^ var4;
                     long var538;
                     int var351 = (var538 = var408 - 400L) == 0L ? 0 : (var538 < 0L ? -1 : 1);
                     var276 = var351;
                  }

                  int var352 = var276;
                  if (var352 > 0) {
                     var10001 = this.t;
                     var10002 = this.o;
                     var10003 = (float)this.w * 0.003F;
                     var487 = new Object[]{null, null, null, var31};
                     var487[2] = var10003;
                     var487[1] = var10002;
                     var487[0] = var10001;
                     Object[] var193 = var487;
                     this.t = ClientUiUtil.bReturningFloat(var193);
                  }
               }

               float var58 = this.e + 40.0F;
               float var59 = 65.0F;
               var10002 = this.f + 28.0F;
               var10003 = var58 + var59;
               float var478 = this.f + 35.0F;
               short var492 = 27070;
               long var502 = 5360118419587629407L ^ var4;
               short var503 = 781;
               long var515 = 7612890682032155631L ^ var4;
               short var516 = 781;
               long var524 = 7612890682032155631L ^ var4;
               short var525 = 19648;
               long var530 = 6214234341736490022L ^ var4;
               var10009 = new Object[]{null, null, null, null, null, new Color(255, 255, 255, 22), new Vector4f(1.5F), var23};
               var10009[4] = var478;
               var10009[3] = var10003;
               var10009[2] = var10002;
               var10009[1] = var58;
               var10009[0] = var52;
               Object[] var195 = var10009;
               ShapeRenderer.u(var195);
               int var354 = var47;
               TargetWidget var353 = this;
               TargetWidget var278 = var353;
               TargetWidget var277 = var353;
               if (var354 != 0) {
                  float var539;
                  int var355 = (var539 = var277.t - (this.p + 0.005F)) == 0.0F ? 0 : (var539 < 0.0F ? -1 : 1);
                  if (var355 > 0) {
                     var10002 = this.f + 28.0F;
                     var10003 = var58 + var59 * this.t;
                     float var479 = this.f + 35.0F;
                     var492 = 18830;
                     var502 = 4838691439992119650L ^ var4;
                     short var505 = 24714;
                     long var518 = 8187490124621514876L ^ var4;
                     short var519 = 13566;
                     var524 = 891242433030708240L ^ var4;
                     short var527 = 23497;
                     long var531 = 2080437083046851360L ^ var4;
                     var10009 = new Object[]{null, null, null, null, null, new Color(235, 85, 85, 130), new Vector4f(1.5F), var23};
                     var10009[4] = var479;
                     var10009[3] = var10003;
                     var10009[2] = var10002;
                     var10009[1] = var58;
                     var10009[0] = var52;
                     Object[] var197 = var10009;
                     ShapeRenderer.u(var197);
                  }

                  var278 = this;
               }

               var10001 = this.p;
               var10004 = new Object[]{null, var13};
               var10004[0] = var10001;
               Object[] var200 = var10004;
               TargetWidget var199 = var278;
               Color var60 = var199.aReturningColor(var200);
               float var409 = var59 * this.p;
               float var202 = 2.5F;
               float var201 = var409;
               float var61 = Math.max(var201, var202);
               var10002 = this.f + 28.0F;
               var10003 = var58 + var61;
               float var481 = this.f + 35.0F;
               Color var203 = var60;
               Color var490 = var203.darker();
               Color var204 = var60;
               Color var494 = var204.brighter();
               Color var205 = var60;
               Color var506 = var205.darker();
               Color var206 = var60;
               Object[] var532 = new Object[]{null, null, null, null, null, null, var490, var494, var506, var206.brighter(), var45};
               var532[5] = 1.5F;
               var532[4] = var481;
               var532[3] = var10003;
               var532[2] = var10002;
               var532[1] = var58;
               var532[0] = var52;
               Object[] var207 = var532;
               GameRenderUtil.p(var207);
               var409 = this.l;
               var10004 = new Object[]{null, null, var19};
               var10004[1] = 1;
               var10004[0] = var409;
               Object[] var208 = var10004;
               float var209 = ClientUiUtil.cReturningFloat(var208);
               String var411 = String.valueOf(var209);
               short var433 = 12462;
               long var454 = 5458104670461929558L ^ var4;
               String var212 = "";
               String var211 = ".0";
               String var210 = var411;
               String var62 = var210.replace(var211, var212);
               float var540;
               int var356 = (var540 = this.p - 0.6F) == 0.0F ? 0 : (var540 < 0.0F ? -1 : 1);
               Color var279;
               if (var356 > 0) {
                  Color var357 = UiMetrics.s;
                  var279 = var357;
               } else {
                  var279 = var60;
               }

               Color var63 = var279;
               MsdfFontManager var412 = Prestige.c;
               Object[] var215 = new Object[]{var11};
               MsdfFontManager var214 = var412;
               MsdfFont var413 = var214.aReturningcx_C0158(var215);
               var10003 = this.e + var49;
               MsdfFontManager var483 = Prestige.c;
               Object[] var217 = new Object[]{var11};
               MsdfFontManager var216 = var483;
               MsdfFont var484 = var216.aReturningcx_C0158(var217);
               Object[] var219 = new Object[]{var62, var33};
               MsdfFont var218 = var484;
               var10003 = var10003 - var218.aReturningFloat(var219) - 5.5F;
               float var485 = this.f + 26.0F;
               Object[] var507 = new Object[]{null, null, null, null, var63, var43};
               var507[3] = var485;
               var507[2] = var10003;
               var507[1] = var62;
               var507[0] = var52;
               Object[] var221 = var507;
               MsdfFont var220 = var413;
               var220.v(var221);
               int var359 = var47;
               TargetWidget var358 = this;
               var289 = var358;
               TargetWidget var280 = var358;
               if (var359 == 0) {
                  break label220;
               }

               Iterable var360 = var280.q;
               if (var360 != null) {
                  float var64 = -2.5F;
                  Iterable var223 = this.q;
                  Iterator var65 = var223.iterator();

                  boolean var283;
                  label164: {
                     int var367;
                     do {
                        Iterator var224 = var65;
                        boolean var361 = var224.hasNext();
                        if (!var361) {
                           break;
                        }

                        Iterator var225 = var65;
                        ItemStack var66 = (ItemStack)var225.next();
                        int var362 = var47;
                        if (var362 != 0) {
                           ItemStack var226 = var66;
                           boolean var414 = var226.isEmpty();
                           int var364 = var47;
                           boolean var363 = var414;
                           var283 = var363;
                           boolean var281 = var363;
                           if (var364 == 0) {
                              break label164;
                           }

                           boolean var365 = var281;
                           boolean var282 = var365;
                           boolean var366 = var282;
                           if (!var366) {
                              var10001 = this.e + 40.5F + var64;
                              var10002 = this.f + 13.0F;
                              Object[] var495 = new Object[]{null, null, null, null, var52, var21};
                              var495[3] = 0.8F;
                              var495[2] = var10002;
                              var495[1] = var10001;
                              var495[0] = var66;
                              Object[] var229 = var495;
                              GameRenderUtil.aReturningBoolean(var229);
                           }

                           var64 += 15.0F;
                        }

                        var367 = var47;
                     } while (var367 != 0);

                     ItemStack var231 = this.r;
                     var283 = var231.isEmpty();
                  }

                  boolean var288;
                  int var369 = var47;
                  boolean var368 = var283;
                  var288 = var368;
                  boolean var284 = var368;
                  label151:
                  if (var369 != 0) {
                     boolean var370 = var284;
                     if (!var370) {
                        ItemStack var415 = this.r;
                        var10001 = this.e + 40.5F + var64;
                        var10002 = this.f + 13.0F;
                        Object[] var496 = new Object[]{null, null, null, null, var52, var21};
                        var496[3] = 0.8F;
                        var496[2] = var10002;
                        var496[1] = var10001;
                        var496[0] = var415;
                        Object[] var233 = var496;
                        boolean var416 = GameRenderUtil.aReturningBoolean(var233);
                        int var372 = var47;
                        boolean var371 = var416;
                        var288 = var371;
                        boolean var285 = var371;
                        if (var372 == 0) {
                           break label151;
                        }

                        boolean var373 = var285;
                        boolean var286 = var373;
                        boolean var374 = var286;
                        if (var374) {
                           var64 += 15.0F;
                        }
                     }

                     int var376 = var47;
                     TargetWidget var375 = this;
                     var289 = var375;
                     TargetWidget var287 = var375;
                     if (var376 == 0) {
                        break label220;
                     }

                     ItemStack var236 = var287.s;
                     boolean var377 = var236.isEmpty();
                     var288 = var377;
                  }

                  boolean var378 = var288;
                  if (!var378) {
                     ItemStack var417 = this.s;
                     var10001 = this.e + 40.5F + var64;
                     var10002 = this.f + 13.0F;
                     Object[] var497 = new Object[]{null, null, null, null, var52, var21};
                     var497[3] = 0.8F;
                     var497[2] = var10002;
                     var497[1] = var10001;
                     var497[0] = var417;
                     Object[] var238 = var497;
                     GameRenderUtil.aReturningBoolean(var238);
                  }
               }
            }

            var289 = this;
         }

         var10004 = new Object[]{null, var50};
         var10004[0] = var49;
         Object[] var241 = var10004;
         TargetWidget var240 = var289;
         var240.iReturningVoid(var241);
      }
   }

   private float cReturningFloat(Object[] var1) {
      PlayerEntity var4 = (PlayerEntity)var1[0];
      long var2 = (Long)var1[1];
      var2 = 139550922882879L ^ var2;
      long var5 = var2 ^ 58646895763072L;
      PlayerEntity var7 = var4;
      float var10000 = var7.getHealth();
      PlayerEntity var8 = var4;
      var10000 = (var10000 + var8.getAbsorptionAmount()) / 20.0F;
      Object[] var10005 = new Object[]{null, null, null, var5};
      var10005[2] = 1.0F;
      var10005[1] = 0.0F;
      var10005[0] = var10000;
      Object[] var9 = var10005;
      return ClientUiUtil.aReturningFloat(var9);
   }

   private Color aReturningColor(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      var3 = 139550922882879L ^ var3;
      long var5 = var3 ^ 81613746378391L;
      int var7 = Event.bReturningInt();
      float var25;
      int var10000 = (var25 = var2 - 0.6F) == 0.0F ? 0 : (var25 < 0.0F ? -1 : 1);
      int var13 = var7;
      int var12 = var10000;
      int var11 = var12;
      int var10 = var12;
      if (var13 == 0) {
         int var14 = var10;
         if (var14 > 0) {
            Object[] var9 = new Object[]{var5};
            return ClientUiUtil.dReturningColor(var9);
         }

         float var26;
         var11 = (var26 = var2 - 0.3F) == 0.0F ? 0 : (var26 < 0.0F ? -1 : 1);
      }

      int var15 = var11;
      if (var15 > 0) {
         short var17 = 11772;
         long var19 = 7417628214153867814L ^ var3;
         short var20 = 10973;
         long var22 = 1489971093575333120L ^ var3;
         short var23 = 22222;
         long var24 = 5818225687726065950L ^ var3;
         return new Color(240, 170, 60);
      } else {
         short var10002 = 27874;
         long var10003 = 327245973437035312L ^ var3;
         short var18 = 5324;
         long var10004 = 4180704464634268436L ^ var3;
         short var21 = 5896;
         long var10005 = 2955397679072430299L ^ var3;
         return new Color(235, 75, 75);
      }
   }

   static {

      {

      b();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(138879375252926L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[5];
      String var28 = "\u0007ø³v>ï,ÔB.°\u0004E·t\t\u0010÷\u0097\u008e\u0013\u0084_3{\fcÂ6\u0015 ]x\u0010¾\u0006V¦'s`\u0016 ôî\u0097ZíÔÎ";
      int var30 = "\u0007ø³v>ï,ÔB.°\u0004E·t\t\u0010÷\u0097\u008e\u0013\u0084_3{\fcÂ6\u0015 ]x\u0010¾\u0006V¦'s`\u0016 ôî\u0097ZíÔÎ".length();
      char var27 = 16;
      int var36 = -1;

      label81:
      while (true) {
         String var37 = var28.substring(++var36, var36 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var37.getBytes("ISO-8859-1"));
            String var53 = b(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var53;
                  if ((var36 += var27) >= var30) {
                     y = var31;
                     B = new String[5];
                     I = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(138879375252926L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[18];
                     String var15 = "\u0011ÓÚÍýÑÙ'\u00adJ#ÚJ¾,\u0088õ\u0001\u0080{\u0081\u00adÈs\u000fì½iRf[\u0089¸÷\u009b4¾\u0003ï \u007f·¢~G\u0082]~¬\u0019\n\u0088lª´\u009fQ/\u000b\u008f\u001e¿\u001a!Ùû÷3GI5{\u0087·\u0092´Û³Ï®¡ i0´K\u001a{>xÏÇEÄ{\u0099\u0001I\u0089\u0097\u0094\u0081\u00819 lë\u0019Ù\u001b&15z% ]©Ðdc:Åp§\u008eÆG";
                     int var16 = "\u0011ÓÚÍýÑÙ'\u00adJ#ÚJ¾,\u0088õ\u0001\u0080{\u0081\u00adÈs\u000fì½iRf[\u0089¸÷\u009b4¾\u0003ï \u007f·¢~G\u0082]~¬\u0019\n\u0088lª´\u009fQ/\u000b\u008f\u001e¿\u001a!Ùû÷3GI5{\u0087·\u0092´Û³Ï®¡ i0´K\u001a{>xÏÇEÄ{\u0099\u0001I\u0089\u0097\u0094\u0081\u00819 lë\u0019Ù\u001b&15z% ]©Ðdc:Åp§\u008eÆG"
                        .length();
                     label63:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var40 = var17;
                        var10001 = var14++;
                        long var57 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        // while (true) {
                           long var19 = var57;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var63) {
                              case 0:
                                 var40[var10001] = var68;
                                 if (var13 >= var16) {
                                    D = var17;
                                    H = new Integer[18];
                                    L = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(138879375252926L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[6];
                                    String var4 = "£\\m¤;\u0010¦C\u0018¶M\u009bE\u0002\u0080\u0081üÎ«\u000bB]«\u0007³Ø¥lû\u0010t¨";
                                    int var5 = "£\\m¤;\u0010¦C\u0018¶M\u009bE\u0002\u0080\u0081üÎ«\u000bB]«\u0007³Ø¥lû\u0010t¨".length();
                                    label47:
                                    while (true) {
                                       int var49 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var49, var2).getBytes("ISO-8859-1");
                                       long[] var42 = var6;
                                       var49 = var3++;
                                       long var60 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       // while (true) {
                                          long var8 = var60;
                                          byte[] var10 = var0.doFinal(
                                             new byte[]{
                                                (byte)(var8 >>> 56),
                                                (byte)(var8 >>> 48),
                                                (byte)(var8 >>> 40),
                                                (byte)(var8 >>> 32),
                                                (byte)(var8 >>> 24),
                                                (byte)(var8 >>> 16),
                                                (byte)(var8 >>> 8),
                                                (byte)var8
                                             }
                                          );
                                          var68 = (var10[0] & 255L) << 56
                                             | (var10[1] & 255L) << 48
                                             | (var10[2] & 255L) << 40
                                             | (var10[3] & 255L) << 32
                                             | (var10[4] & 255L) << 24
                                             | (var10[5] & 255L) << 16
                                             | (var10[6] & 255L) << 8
                                             | var10[7] & 255L;
                                          switch (var66) {
                                             case 0:
                                                var42[var49] = var68;
                                                if (var2 >= var5) {
                                                   J = var6;
                                                   K = new Long[6];
                                                   c = 400L;
                                                   a = 350L;
                                                   break;
                                                }
                                                break;
                                             default:
                                                var42[var49] = var68;
                                                if (var2 < var5) {
                                                   continue label47;
                                                }

                                                var4 = "]\u008bæl¨w\u009f~\u008a&I\u0090\u009a\u009bù:";
                                                var5 = "]\u008bæl¨w\u009f~\u008a&I\u0090\u009a\u009bù:".length();
                                                var2 = 0;
                                          }

                                          int var51 = var2;
                                          var2 += 8;
                                          var7 = var4.substring(var51, var2).getBytes("ISO-8859-1");
                                          var42 = var6;
                                          var49 = var3++;
                                          var60 = (var7[0] & 255L) << 56
                                             | (var7[1] & 255L) << 48
                                             | (var7[2] & 255L) << 40
                                             | (var7[3] & 255L) << 32
                                             | (var7[4] & 255L) << 24
                                             | (var7[5] & 255L) << 16
                                             | (var7[6] & 255L) << 8
                                             | var7[7] & 255L;
                                          var66 = 0;
                                       }
                                    }
                                 }
                                 break;
                              default:
                                 var40[var10001] = var68;
                                 if (var13 < var16) {
                                    continue label63;
                                 }

                                 var15 = "p7\u0095µ\n\u0013\u001dÁ2\u009caA:ØÓº";
                                 var16 = "p7\u0095µ\n\u0013\u001dÁ2\u009caA:ØÓº".length();
                                 var13 = 0;
                           }

                           int var48 = var13;
                           var13 += 8;
                           var18 = var15.substring(var48, var13).getBytes("ISO-8859-1");
                           var40 = var17;
                           var10001 = var14++;
                           var57 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var63 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var36);
                  break;
               default:
                  var31[var29++] = var53;
                  if ((var36 += var27) < var30) {
                     var27 = var28.charAt(var36);
                     continue label81;
                  }

                  var28 = "\u0097\u0086Þï¿\u00adð\u0010ºñW\u0000ä\u008f=\u008eP\u000e7D\u0092pf\u0006|\u0085¤ª¤©\u009aø\f\u001b\u008eÓ-\u0000´·dð:[=ç\u0011i\u00903\u009b\fÓ\u0018>h8 §?F\u0015\u001dH!mtÔ4\u0099\u0013ÿb íÞ\u0096õVÑ`±;î2¥èà\u009fmüÜ0È\u0085¡\u0095";
                  var30 = "\u0097\u0086Þï¿\u00adð\u0010ºñW\u0000ä\u008f=\u008eP\u000e7D\u0092pf\u0006|\u0085¤ª¤©\u009aø\f\u001b\u008eÓ-\u0000´·dð:[=ç\u0011i\u00903\u009b\fÓ\u0018>h8 §?F\u0015\u001dH!mtÔ4\u0099\u0013ÿb íÞ\u0096õVÑ`±;î2¥èà\u009fmüÜ0È\u0085¡\u0095"
                     .length();
                  var27 = 16;
                  var36 = -1;
            }

            var37 = var28.substring(++var36, var36 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23403;
      if (B[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])C.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               C.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cd", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = y[var5].getBytes("ISO-8859-1");
         B[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return B[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cd_C0118",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 11124;
      if (H[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = D[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])I.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               I.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cd", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         H[var3] = var15;
      }

      return H[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cd_C0118",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16917;
      if (K[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = J[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])L.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               L.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cd", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         K[var3] = var15;
      }

      return K[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cd_C0118",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = P[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = O[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 37;
            yield var15;
         }
         case 1 -> {
            byte var16 = 7;
            yield var16;
         }
         case 2 -> {
            byte var17 = 26;
            yield var17;
         }
         case 3 -> {
            byte var18 = 29;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 15;
            yield var20;
         }
         case 6 -> {
            byte var21 = 6;
            yield var21;
         }
         case 7 -> {
            byte var22 = 62;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 9;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 5;
            yield var26;
         }
         case 12 -> {
            byte var27 = 50;
            yield var27;
         }
         case 13 -> {
            byte var28 = 41;
            yield var28;
         }
         case 14 -> {
            byte var29 = 45;
            yield var29;
         }
         case 15 -> {
            byte var30 = 30;
            yield var30;
         }
         case 16 -> {
            byte var31 = 59;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 49;
            yield var33;
         }
         case 19 -> {
            byte var34 = 60;
            yield var34;
         }
         case 20 -> {
            byte var35 = 23;
            yield var35;
         }
         case 21 -> {
            byte var36 = 44;
            yield var36;
         }
         case 22 -> {
            byte var37 = 21;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 31;
            yield var39;
         }
         case 25 -> {
            byte var40 = 56;
            yield var40;
         }
         case 26 -> {
            byte var41 = 22;
            yield var41;
         }
         case 27 -> {
            byte var42 = 27;
            yield var42;
         }
         case 28 -> {
            byte var43 = 16;
            yield var43;
         }
         case 29 -> {
            byte var44 = 12;
            yield var44;
         }
         case 30 -> {
            byte var45 = 24;
            yield var45;
         }
         case 31 -> {
            byte var46 = 10;
            yield var46;
         }
         case 32 -> {
            byte var47 = 46;
            yield var47;
         }
         case 33 -> {
            byte var48 = 25;
            yield var48;
         }
         case 34 -> {
            byte var49 = 18;
            yield var49;
         }
         case 35 -> {
            byte var50 = 55;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 36;
            yield var52;
         }
         case 38 -> {
            byte var53 = 42;
            yield var53;
         }
         case 39 -> {
            byte var54 = 43;
            yield var54;
         }
         case 40 -> {
            byte var55 = 1;
            yield var55;
         }
         case 41 -> {
            byte var56 = 28;
            yield var56;
         }
         case 42 -> {
            byte var57 = 61;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 53;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 48;
            yield var61;
         }
         case 47 -> {
            byte var62 = 13;
            yield var62;
         }
         case 48 -> {
            byte var63 = 3;
            yield var63;
         }
         case 49 -> {
            byte var64 = 17;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 11;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 32;
            yield var72;
         }
         case 58 -> {
            byte var73 = 2;
            yield var73;
         }
         case 59 -> {
            byte var74 = 4;
            yield var74;
         }
         case 60 -> {
            byte var75 = 20;
            yield var75;
         }
         case 61 -> {
            byte var76 = 38;
            yield var76;
         }
         case 62 -> {
            byte var77 = 58;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            P[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      O[0] = ",-,NuT:-)\u0014fC-f*\u0012jW<!=\u0005!F\u001c";
      O[1] = "55\fR\u0014R@\u0015\u0007]\u0005\u001d!\u001b\fV\u0001GU";
      O[2] = "p\\}\u007f\u0000\u0012p\\j#\f\u001dj\u0017j=\f\bmf1gUN";
      O[3] = "t#cW!;t#t\u000b-4nht\u0015-!i\u0019&K|e#bt\u0015-!i\u0019&K|j+";
      O[4] = "tVC5@'bVFoS0u\u001dEi_$dZR~\u00144|ZPuNy@APhN>wV";
      O[5] = "HVw^\u0003V^Vr\u0004\u0010AI\u001dq\u0002\u001cUXZf\u0015W@x";
      O[6] = "B+{q,nB+l- aX`l3 t_\u0011>it0";
      O[7] = "NX\u001d~5WNX\n\"9XT\u0013\n<9MSbXga\u0007";
      O[8] = "\u0019\u00105,\u000e@\u0004\u0005m\u000eOM\u001c\u0003";
      O[9] = "qz+Y2Azu:\u0016OTho8U";
      O[10] = long.class;
      P[10] = "java/lang/Long";
      O[11] = "g5/]\u007f\u001bg58\u0001s\u0014}~8\u001fs\u0001z\u000fmG\"";
      O[12] = "\u0004\u0014W\u0005\u001d\u0004\u0012\u0014R_\u000e\u0013\u0005_QY\u0002\u0007\u0014\u0018FNI\u0017\u001a";
      O[13] = "Z\"\u0018\u0017V7L\"\u001dME [i\u001eKI4J.\t\\\u0002&[";
      O[14] = "r\u0012\u0010}QM\u00072\u001br@\u0002f<\u0010yDX\u0012";
      O[15] = float.class;
      P[15] = "java/lang/Float";
      O[16] = "G1I>\u0016\u0006G1^b\u001a\t]z^|\u001a\u001cZ\u000b\u000e!K";
      O[17] = "O\u000e-7S\"O\u000e:k_-UE:u_8R4m*\t";
      O[18] = boolean.class;
      P[18] = "java/lang/Boolean";
      O[19] = "jm\u0018iAh|m\u001d3R\u007fk&\u001e5^kza\t\"\u0015{v";
      O[20] = ":1n\u0001\u0010NO\u0011e\u000e\u0001\u0001.\u001fn\u0005\u0005[Z";
      O[21] = void.class;
      P[21] = "java/lang/Void";
      O[22] = "F6S`\bYP6V:\u001bNG}U<\u0017ZV:B+\\JF";
      O[23] = "c/\bK\u0007'\u0016\u000f\u0003D\u0016hw\u0001\bO\u00122\u0003";
      O[24] = "2T7\u0000>y2T \\2v(\u001f B2c/nu\u001dg";
      O[25] = "H\u0019\u001d(\u0011R^\u0019\u0018r\u0002EIR\u001bt\u000eQX\u0015\fcE@\u001d";
      O[26] = "),~0B=\\\fu?Sr=\u0002~4W(I";
      O[27] = "@X\u00129J\f^P\bv'\u0016FU\u0001;\u0010\u0010EW\u0017";
      O[28] = "lB4P<zrJ.\u001f^fuW";
      O[29] = "[\u0019y\u0001l\u0011M\u0019|[\u007f\u0006ZR\u007f]s\u0012K\u0015hJ8\u0000}";
      O[30] = "X\r\u001a$(\u0014--\u0011+9[L#\u001a =\u00018";
      O[31] = "C\u0018\u0017IrR]\u0010\r\u0006\u0015SL\u000b\u0000\\3U";
      O[32] = "\r\"Z&B\"\u0006-Ki#,\r&O3";
      O[33] = "\u0000T=%\u0019?\u0000T*y\u00150\u001a\u001f*g\u0015%\u001dn{>Bg";
      O[34] = "~\u00132(a^u\u001c#g\u001cFf\u001b*.";
      O[35] = "Zke\t5RLk`S&E[ cU*QJgtBaA\u0007";
      O[36] = "{kF^T\u001e\u000eKMQEQoEFZA\u000b\u001b";
      O[37] = "\u0001'^\f7\u001dt\u0007U\u0003&R\u0015\t^\b\"\ba";
      O[38] = "kz/j\u001e;idf\t\u0015 va0p\u0012";
      O[39] = "r\u0018%CoLl\u0010?\f\u0014lQ=";
      O[40] = "W5Om\u001bqW5X1\u0017~M~X/\u0017kJ\u000f\tz@(";
      O[41] = "~\u0011~>>\u001e\u000b1u1/Qj?~:+\u000b\u001e";
      O[42] = "h~WEN\u0006\u001d^\\J_I|PWA[\u0013\b";
      O[43] = "h&V\u001e/)h&AB#&rmA\\#3u\u001c\u0013\u0003rt";
      O[44] = "#(\u000bA{D5(\u000e\u001bhS\"c\r\u001ddG3$\u001a\n/P0";
      O[45] = "M0\u0017\u0013\u0018M8\u0010\u001c\u001c\t\u0002Y\u001e\u0017\u0017\rX-";
      O[46] = "d4\u0011\u0017nO\u0011\u0014\u001a\u0018\u007f\u0000p\u001a\u0011\u0013{Z\u0004";
      O[47] = "\"V3\u0007u74V6]f #\u001d5[j42Z\"L!#0";
      O[48] = "-'PzBCX\u0007[uS\f9\tP~WVM";
      O[49] = "}8,\u000b\u0015`v7=Dvmc:2/Cor).\u0003Tb";
      O[50] = "z\u001bt\u0014AH\u000f;\u007f\u001bP\u0007n5t\u0010T]\u001a";
      O[51] = ";I\u001eF@HNi\u0015IQ\u0007/g\u001eBU][";
      O[52] = "\"'3X\u000fd\"'$\u0004\u0003k8l$\u001a\u0003~?\u001d~DU9";
      O[53] = "lch\u001c\u001c;zcmF\u000f,m(n@\u00038|oyWH*M";
      O[54] = int.class;
      P[54] = "java/lang/Integer";
      O[55] = "qE.A\u001fEqE9\u001d\u0013Jk\u000e9\u0003\u0013_l\u007fm[D";
      O[56] = "\f\u0003\u000et%\u0001y#\u0005{4N\u0018-\u000ep0\u0014l";
      O[57] = "_\u0004Q\u0014E\u000b_\u0004FHI\u0004EOFVI\u0011B>\u0014\b\u0011U";
      O[58] = "#\u007fS4O4(pB{,9=v";
      O[59] = " BD)\u0016\u001f+MUf{\u001b+Qa-I\u0006/MQ-";
      O[60] = "]\u0018\bF\u0002}V\u0017\u0019\teeR\u000b\u001fE@t";
      O[61] = "+[S^F:^{XQWu?uSZS/K";
      O[62] = "f\u0015q\u001a\u001fb\u00135z\u0015\u000e-r;q\u001e\nw\u0006";
      O[63] = double.class;
      P[63] = "java/lang/Double";
      O[64] = "\u0019\u0013\u0006r\u000e=l3\r}\u001fr\r=\u0006v\u001b(y";
      O[65] = ",\u001baOC'Y;j@Rh85aKV2L";
      O[66] = "aRJ\u0012\f\u000ecL\u0003q\u0007\u0015|IU\b\u0000\u0002";
      O[67] = "W\u0018(^Wi\"8#QF&C6(ZB|7";
      O[68] = "FbsW\u001c.3BxX\raRLsS\t;&";
      O[69] = " \u0018um\u007f& \u0018b1s):Sb/s<=\"0s&~";
      O[70] = "kB<j\u0007.}B90\u00149j\t:6\u0018-{N-!S9W";
      O[71] = "'~1\u0012\u001c(R^:\u001d\rg3P1\u0016\t=G";
      O[72] = "%\u0011\u0001Y\u000fCP1\nV\u001e\f1?\u0001]\u001aVE";
      O[73] = "Z<wfBQ/\u001c|iS\u001eN\u0012wbWD:";
      O[74] = "\u0019T>,.o^Xf]$\u0005\u001cS m\"}K\u000ea0+\u0005\u0019T>,.o^Xf]";
      O[75] = "6^\u0011;UVa\nCd3\rhTU\u0003\nX5\u000f-n^Y>@N)\fXk1";
      O[76] = "i(|\u0012OCb/uL5UR*h\u0003^Zb.pGW";
      O[77] = "#O\t1O\u0014qTQ1\"\u0018rY\u000b3N*!\u001dTe\"@sT\u0000(\u001dLc\u001c\u0016T";
      O[78] = "@oa\u001c(7\u0004i!\u0010N9\u0007w?\u001c2>\u0007\u0016m\u0005\u007f3\u001br)\u0003??}";
      O[79] = "GyC3\u0010\f\u0016|S1oY\u0004bW9\tN%yH9*S\u001d|L/o\rIu\u00153\u0016S\u0003s\u0017T";
      O[80] = "\u0019Rw#;=\u0015\u0005ccZ;D\u0016gy6\t\u0014P7'b^\u0010\u0005;q<nGQi.Z";
      O[81] = ";\u0012\u00116\u0006=0\u0015\u0018h|&\u0000\u001b\u001c%E/0QG2L";
      O[82] = "t)[0sK~+K&\u0014@ErF($C=%\u001biyJE\"RluN%4Vih)";
      O[83] = "3+!\u0012=\u0002e'(P\u0006T8/*\u0003Q\u0003f\u007fsom\u0005d8$Q?\u0002;$";
      O[84] = "V0[\u0005Q>Z \u0013\u0013-d\u0006 J\tAVTm\u0014V-mR6L\fD9\b En";
      O[85] = "\u0000z#F\u0004lQpjOnvlr6X^c\u0014%k\u0019\u0003jl&>Y\u00167\n'=AW\t";
      O[86] = "vL\u0002fOo$C\u0017nRV*J\u0014dH:\u0018\u001bU<\u0011Vv\u001e\n9\u0010:1Y\u0012m\u001eV";
      O[87] = "#V;\t\u000bJ2\u001f \u001dyIM^/\u001bIJ5\trZ\u0014CMZ;V\u0019F)\u001e=\u0016\u0015 ";
      O[88] = "\u0002!&\u0012\u000e7T-/P5j\u00054)\bYXQuwU5`\u0014st\u0014\f5\u000e$qo";
      O[89] = "4%s@\u000b4+=$AblTzxMRg,-%\f\u000fnT.pL\u001a32/sT[\r";
      O[90] = "m{jkS/qxhdk*b8c`\u0010=\u000f$~f\n0` ?$\u0013Pb#sbU6c k#k";
      O[91] = "11I^Sn?cHDjyR7YEZx*`\u0004\u0004\u0007qRgM\u0001\u000bu2qI\u0004\u0016\u0012";
      O[92] = "m4\u001cf~_c.\u0016xDPd#\u000f\u001d!Vjn\u000edu\f5(s";
      O[93] = "EDC\u000f\u0000MNZW\u0005`DNWg\u0018\u001aJED<\u0002\u0006MSR\u0000\u0001\rU\u0013+";
      O[94] = "&V4\u0003Mx<D?Ct\u007fA\u00034BDy9Ti\u0003\u0019pAW<C\f-'V?[M\u0013";
      O[95] = "6\u0014\"NC\nd\u000fzN.\u0006g\u0002 LB44F{\u0011.\nsF!LN\u001cwC<+";
      O[96] = "Ic$w^\u000e\u0018im~4\u0002%k1i\u0004\u0001]<l(Y\b%;%-U\fE-!(Hk";
      O[97] = "\u0001\u0006.\r0LW\n'O\u000b\u0011\u0006\u0013!\u0017g#QU\u007f@0tR\u0004+\u0012kM\u0000\u000b>\u001avt";
      O[98] = "lF$?\u0019\rxIn.c\roOs/\u0007\u0018iK\u0015=\u001aItAu+\u001eLi&|-[\u0010rFj)^\r\u0015Oll\u0002\u0016uYhi\u001fqlF$?\u0019\rxIn.c";
      O[99] = "x_//v1{T7o\u000f`gD ;t\r{Y*brt/\u0003u$\u000fa'S/=f5}E&_";
      O[100] = "H>Ir^UBcN\"?VK\u007fX\u007fD;WbR&BB\u00038\r`?W\u000bhWyV\u0003Q~^\u001b";
      O[101] = "n`M7%t%!Yu\u001f\"mmNndOqpD7b6%*\u001bq\u001f#-zAhvwwlH\n";
      O[102] = "0H-|rG:J=j\u0015L\u0001\u00130d%OyDm%xF\u0001G8em\u001bgF;},%";
      O[103] = "jCRI\u001b\u001dd\u0011SS\"\b\tEBR\u0012\u000bq\u0012\u001f\u0013O\u0002\t\u0015V\u0016C\u0006i\u0003R\u0013^a";
      O[104] = "\u0014vmi'\u001f\u001a9e7N\u0013\u0005u<l\"!U8f0N\u0010\u000eo,rr\u0013\u0005wl\u000b";
      O[105] = "$*ax\u0003#cx`-r+y\"&\u001eI~$x^3\u0002*#}exC>aG";
      O[106] = "\u001bA \u000f\"L\u0004Yw\u000eK\u001c{\u001e+\u0002{\u001f\u0003IvC&\u0016{J#\u00033K\u001dK \u001bru";
      O[107] = "\u0001\u00194ek=\f\u001075S |C`rc:\u0004\u0014=3>3|\u0017hs+n\u001a\u0016kkjP";
      O[108] = "@\u0018vkVB\u0004\u001e6g0J\u0014\u001b$fJ&@\u0018vkVB\u0004\u001e6g0";
      O[109] = "9\u0014'u\u0000Q4\u001d$%8DDNsb\bV<\u0019.#U_D\u001a{c@\u0002\"\u001bx{\u0001<";
      O[110] = "&8Zt.h<rE DvV9Kmta.n\u0016,)hVmCl<50l@t}\u000b";
      O[111] = "qDYLni`\rBX\u001cj\u001f\u0004\u0018H|g|\u0018\\S#\u0003nMJBx`r\tQ\u001d\u001c";
      O[112] = "\u0015}B5\u0012V\u001b/C/+@v{R.\u001b@\u000e,\u000foFIv+FjJM\u0016=BoW*";
      O[113] = "Z\tT\f[K\u000b\u0003\u001d\u00051E6\u0001A\u0012\u0001DNV\u001cS\\M6QUVPIVGQSM.";
      O[114] = "dh\u0018E\u0012P6s@E\u007f\\5~\u001aG\u0013ne<D\u001f\u007fCdz\u0013A\u0011I9}C ";
      O[115] = "&\t\u0001-Acz\t\u0010:\u0019\nu1GqE7 ]\u00006]c.1";
      O[116] = "G_T%hsDTLe\u00111H]O8V!!PKmp(AFOhmOG_T%hsDTLe\u0011";
      O[117] = "D&z \u001eI\u0016)o(\u0003p\u0018 l\"\u0019\u001c*q,rOpDtr\u007fA\u001c\u00033j+Op";
      O[118] = "\u0010m[*xUTk\u001b&\u001enmU6\u0007\u001e\fT%\n,zHRe\u0006";
      O[119] = "m'I%9&?<\u0011%T*<1K'8\u0018ou\u0015\u007fT&(uJ'40,pW@";
      O[120] = "j\u000f\u001c\u001aR&+\nN\r\u0007O2K@\u0012R34M-\f\\ (\rD\u0002F*67";
      O[121] = "F\u00009\u0007ZO\u001a\u0000(\u0010\u0002&\u00148\u007f[^\u001b@T8\u001cFON8";
      O[122] = "g\u0002\u0000u\u00129&\u0007RbGP0[\\c\u0017\u0007b\u000b\u000b=GPg\u0002\u0000u\u00129&\u0007RbG";
      O[123] = "\u0017s`P\u001c\u001a\u0003|*Af\u001d\u0005z5Vf\u000f\u0017+0\\\u0006\u0019\u0013.-;\u000f\u001fVr6[\u0019\u001bSoQR\u001f^\u000ft1D\u001b[\u0012\u0013([W\r\u0014o<T\u001d\u001cn";
      O[124] = "\"m;\n\u00036ta2H8`)i0\u001bo7w>hw\u00014tn:\u0013Za#g*";
      O[125] = "D\tL['DJ\u0013FE\u001dMI\u0015eMmQ \u0002\u001aJ{OIV@\\r-";
      O[126] = "h5qcbo:.)c\u000fc9#sacQjg/9\u000f;8.xz07(fn\u0006";
      O[127] = "GJ1Q^7\u0015QiQ3;\u0016\\3S_\tF\u001cl\u000b38\u0014_8TU3\nK24";
      O[128] = "3*I\"]W>#JreSNp\u001d5UP6'@t\bYN%I#\u0003X'q\u00135\n:";
      O[129] = "Ko0?\"2\u0019th?O>\u001ay2=#\fJ:ikObLgi!7>O94*O2\u000e=3=/$\n8.Z";
      O[130] = "IFJ~iiG\u0014KdPy*@Ze`\u007fR\u0017\u0007$=v*DN(0sN\u0000Hh<\u0015";
      O[131] = "+7fYZ\u0019uq>\u0006YxwbtcZ\u0001*jc\u0003L\u0005/w\u0004\nJ@sld\u001cNEn\u000bm\u001a\u000b\u0019uk{\u001e\u000e\u0004\u0012";
      O[132] = "S'\u0010YtIP,\b\u0019\r\u000fX9\u0012@f\u00185xKIgEDp\u0010WdL5xKIgEDp\u0010WdL5'\u0010O}\f\t$\u001bW=u";
      O[133] = "&L4\u0001\u0002,$\u000bv\rY^~\r&\n\u000f\"x\u000bK\u0014\u00011dK\"\u001a\u001b;zq";
      O[134] = "RM\u000728EH\u0007\u0018fRO\"L\u0016+bLZ\u001bKj?E\"H\u0002f2@F\f\u0004&>&";
      O[135] = "t5]u~0.b_(:M'^\u001b}?}'&L ~ .^Ki{,*>]m~1M";
      O[136] = "Gg\u0000\u0010B,\r<\u0017\u0019 uw>\u0011U\u0010v\u000fiL\u0014M\u007fwkMQBv\u0012:G\u0018K\u001c";
      O[137] = "X~\u000b\u001d5Y\u00068SB68\n/\bC\\\u0001^%\u0013V'C\u0003x\u0006\u001b\\\u0001^%\u0013V'C\u0003x\u0006\u001b\\";
      O[138] = "b\u0017|%W\bf\u000f8,>QYWo2\u000eR!\u00002sS[YRh,[U0\u0000st[8";
      O[139] = "\u001e-o3\u0005U\u000fdt'wTp%{!GU\br&`\u001a\\puoe\u0016X\u0010ck`\u000b?";
      O[140] = "D_F\u001a\u0010\tHO\u000e\flX\u0018^S\u001d;\u0006A\b\bqQZ\bXKN]J@N";
      O[141] = "n\u001a8\"K\u001a;\u0000o'0Fl\u001acx\\t;V<&0Y=\u001ej~^S`\u0019:\u001f\u0000\u001bq[b|\fLe\u001b\u0003";
      O[142] = "[u,YC\u0006_4n@#\u0000UiP]C\n\u0004x)\t\u0019UB\u0005<\u0001I\u000f[lh[_\u00069";
      O[143] = "_r\u000bs'DK}Ab]][v:!4SX#Bu!TK#:a=\tMhFu2C\\\u0012CxlS\\nWw&B&";
      O[144] = "52G\u0000\u0013fd8\u000e\ty}Y:R\u001eIi!m\u000f_\u0014`YnZ\u001f\u0001=?oY\u0007@\u0003";
      O[145] = "sDf\u0018#\u0013~MeH\u001b\u001a\u000e\u001e2\u000f+\u0014vIoNv\u001d\u000eJ:\u000ec@hK9\u0016\"~";
      O[146] = "M\u001f71\u0018U\u001f\u0004o1uY\u001c\t53\u0019kOLldu@\u000eD7=\u001cNALiTHP\u0000\u001e)kD@H\bU";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = O[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(P[var4]);
            O[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = O[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = P[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            O[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  O[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(2283857940403468L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = O[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = P[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  O[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(2283857940403468L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        O[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(2283857940403468L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 114;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 79;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 105;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 76;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 194;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 232;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 114;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 79;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 105;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cd_C0118",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
