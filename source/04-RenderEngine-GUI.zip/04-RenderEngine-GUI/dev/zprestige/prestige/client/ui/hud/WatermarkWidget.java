package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.TextureLoader;
import dev.zprestige.prestige.renderlib.TexturedRectangleRenderer;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;

public class WatermarkWidget extends HudElement {
   private static final String a;
   private static final String b;
   private static final float m = 12.0F;
   private ManagedGlTexture c;
   private static final long v = 40964298622805L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long B;
   private static final Object[] C = new Object[62];
   private static final String[] D = new String[62];

   public WatermarkWidget(long var1) {
      super("Watermark", "Show the client's watermark", ((40964298622805L ^ (40964298622805L ^ var1)) ^ 17073506634598L));
      var1 = 40964298622805L ^ var1;
      long var3 = var1 ^ 17073506634598L;
      short var10001 = 14875;
      long var10002 = 1626661975769280224L ^ var1;
      short var6 = 30806;
      long var10003 = 609120484267273385L ^ var1;

   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 3.0F;
      var10005[0] = 2.0F;
      Object[] var7 = var10005;
      WatermarkWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      Matrix4f var2;
      RenderContext var3;
      MeshBufferManager var4;
      long var5;
      long var7;
      long var9;
      long var11;
      long var13;
      long var15;
      long var17;
      long var19;
      long var21;
      long var23;
      label29: {
         var4 = (MeshBufferManager)var1[0];
         var3 = (RenderContext)var1[1];
         var2 = (Matrix4f)var1[2];
         var5 = (Long)var1[3];
         var7 = var5 ^ 49928519994039L;
         var9 = var5 ^ 48887442607471L;
         var11 = var5 ^ 124694493719688L;
         var13 = var5 ^ 81054074941871L;
         var15 = var5 ^ 36477842301344L;
         var17 = var5 ^ 13608202459885L;
         var19 = var5 ^ 29307267718371L;
         var21 = var5 ^ 113406911627307L;
         var23 = var5 ^ 17083579563515L;
         long var25 = var5 ^ 56760183293883L;
         int var27 = Event.bReturningInt();
         int var96 = var27;
         WatermarkWidget var95 = this;
         WatermarkWidget var91 = var95;
         WatermarkWidget var90 = var95;
         if (var96 == 0) {
            ManagedGlTexture var97 = var90.c;
            if (var97 != null) {
               break label29;
            }

            WatermarkWidget var98 = this;
            var91 = var98;
         }

         short var10001 = 22913;
         long var10002 = 1691331741608481399L ^ var5;
         Object[] var49 = new Object[]{"assets/prestige/icons/logo.png", var25};
         var91.c = TextureLoader.aReturningbT_C0095(var49);
      }

      MsdfFontManager var10000 = Prestige.c;
      Object[] var51 = new Object[]{var17};
      MsdfFontManager var50 = var10000;
      MsdfFont var105 = var50.aReturningcx_C0158(var51);
      Object[] var53 = new Object[]{var7};
      MsdfFont var52 = var105;
      float var28 = var52.cReturningFloat(var53);
      var10000 = Prestige.c;
      Object[] var55 = new Object[]{var17};
      MsdfFontManager var54 = var10000;
      MsdfFont var107 = var54.aReturningcx_C0158(var55);
      short var115 = 22790;
      long var117 = 6967946456544776958L ^ var5;
      Object[] var57 = new Object[]{"Prestige Client", var13};
      MsdfFont var56 = var107;
      float var29 = var56.aReturningFloat(var57) * 1.0F;
      Object[] var10003 = new Object[]{null, 1.0F};
      var10003[0] = var28;
      Object[] var58 = var10003;
      float var108 = UiMetrics.aReturningFloat(var58);
      float var60 = 18.0F;
      float var59 = var108;
      float var30 = Math.max(var59, var60);
      float var33 = 29.0F + var29 + 5.5F;
      float var34 = this.e;
      float var35 = this.f;
      Object[] var62 = new Object[0];
      WatermarkWidget var61 = this;
      boolean var36 = var61.cReturningBoolean(var62);
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var30;
      var10011[5] = var33;
      var10011[4] = var35;
      var10011[3] = var34;
      var10011[2] = var2;
      var10011[1] = var3;
      var10011[0] = var4;
      Object[] var63 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var63);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var19};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var30;
      var10011[5] = var33;
      var10011[4] = var35;
      var10011[3] = var34;
      var10011[2] = var2;
      var10011[1] = var3;
      var10011[0] = var4;
      Object[] var64 = var10011;
      FilledRectangleRenderer.cReturningVoid(var64);
      Object[] var65 = new Object[]{var15};
      Color var37 = ClientUiUtil.dReturningColor(var65);
      double var66 = System.currentTimeMillis() * 0.0031415926535897933;
      float var38 = (float)(Math.sin(var66) * 0.5 + 0.5);
      int var39 = (int)B + (int)(50.0F * var38);
      Color var68 = var37;
      int var118 = var68.getRed();
      Color var69 = var37;
      int var123 = var69.getGreen();
      Color var70 = var37;
      Color var40 = new Color(var118, var123, var70.getBlue(), var39);
      boolean var99 = var36;
      float var92;
      if (var99) {
         float var100 = var34 + var33 - 5.5F - 12.0F;
         var92 = var100;
      } else {
         var92 = var34 + 5.5F;
      }

      float var41 = var92;
      boolean var101 = var36;
      float var93;
      if (var101) {
         float var102 = var34 + var33 - 23.0F - 0.5F;
         var93 = var102;
      } else {
         var93 = var34 + 23.0F;
      }

      float var42 = var93;
      float var43 = var35 + (var30 - 12.0F) / 2.0F;
      ManagedGlTexture var124 = this.c;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, var37, var23};
      var10011[7] = 12.0F;
      var10011[6] = 12.0F;
      var10011[5] = var43;
      var10011[4] = var41;
      var10011[3] = var124;
      var10011[2] = var2;
      var10011[1] = var3;
      var10011[0] = var4;
      Object[] var73 = var10011;
      TexturedRectangleRenderer.cReturningVoid(var73);
      float var119 = var35 + 3.0F;
      float var125 = var42 + 0.5F;
      float var10004 = var35 + var30 - 3.0F;
      Object[] var10008 = new Object[]{null, null, null, null, null, UiMetrics.v, var11};
      var10008[4] = var10004;
      var10008[3] = var125;
      var10008[2] = var119;
      var10008[1] = var42;
      var10008[0] = var2;
      Object[] var74 = var10008;
      ShapeRenderer.lReturningVoid(var74);
      boolean var103 = var36;
      float var94;
      if (var103) {
         float var104 = var34 + var33 - 29.0F - var29;
         var94 = var104;
      } else {
         var94 = var34 + 29.0F;
      }

      float var44 = var94;
      float var45 = var35 + (var30 - var28 * 1.0F) / 2.0F;
      var10000 = Prestige.c;
      Object[] var77 = new Object[]{var17};
      MsdfFontManager var76 = var10000;
      MsdfFont var110 = var76.aReturningcx_C0158(var77);
      var115 = 17317;
      var117 = 6152113070329170005L ^ var5;
      Object[] var79 = new Object[]{"Prestige ", var13};
      MsdfFont var78 = var110;
      float var46 = var78.aReturningFloat(var79) * 1.0F;
      var10000 = Prestige.c;
      Object[] var81 = new Object[]{var17};
      MsdfFontManager var80 = var10000;
      MsdfFont var112 = var80.aReturningcx_C0158(var81);
      short var121 = 24968;
      long var126 = 5541851448496859772L ^ var5;
      Object[] var10009 = new Object[]{null, null, null, null, null, var40, var21};
      var10009[4] = 1.0F;
      var10009[3] = var45;
      var10009[2] = var44;
      var10009[1] = "Prestige";
      var10009[0] = var2;
      Object[] var83 = var10009;
      MsdfFont var82 = var112;
      var82.w(var83);
      var10000 = Prestige.c;
      Object[] var85 = new Object[]{var17};
      MsdfFontManager var84 = var10000;
      MsdfFont var114 = var84.aReturningcx_C0158(var85);
      short var122 = 11123;
      long var127 = 4724903005223870592L ^ var5;
      float var128 = var44 + var46;
      var10009 = new Object[]{null, null, null, null, null, var40, var21};
      var10009[4] = 1.0F;
      var10009[3] = var45;
      var10009[2] = var128;
      var10009[1] = "Client";
      var10009[0] = var2;
      Object[] var87 = var10009;
      MsdfFont var86 = var114;
      var86.w(var87);
      Object[] var129 = new Object[]{null, var30};
      var129[0] = var33;
      Object[] var89 = var129;
      WatermarkWidget var88 = this;
      var88.iReturningVoid(var89);
   }

   static {

      {

      b();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(20570428403914L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[9];
      String var11 = "YM2ÒÒ\u001eì\u000e,\u0007f¦\u007f_\u008c½\u0082½¢\u008e\u0014\u0087[Ä\u008aÎ\u0095wÏ\u001b\u0080°8Pm\u0094xÑ^72Ã äwÆïñßn³àQ÷]×FlAv\u009f\u0093´÷]\u009al\"j¸Q¶S\u0001bD\u008b<P+ÃK9ñöÏ¶Pm \u0097H\u0006\u0002Í\u0002\u008a¬4¦úCÜ¥\u0087\u001cg¾\u008apäS\u001cÀXR\u0081\u0010«\u0089ßJ\u0010Ë\u008b¬yî\u001frÔtÃ\u0001Ü\t \u0089\u0002\u0018ÌwÐçë¿ÃùÐIð\b5áS3#è\u0096\u0088n\u0090Äì «ØõÈE¦u\u000fÏtýkÌ\u008aÒÚñ\u0097rP~@ \u009cÆùS;ð¼ã]0\u008cÿþêøNç49dì®ë,\u001d\u0003\u0085?\b1´Q\\p`öÀ\u001f|÷'}y1Tms¹\u0007³\u0089ò#ÔIn½õ";
      int var13 = "YM2ÒÒ\u001eì\u000e,\u0007f¦\u007f_\u008c½\u0082½¢\u008e\u0014\u0087[Ä\u008aÎ\u0095wÏ\u001b\u0080°8Pm\u0094xÑ^72Ã äwÆïñßn³àQ÷]×FlAv\u009f\u0093´÷]\u009al\"j¸Q¶S\u0001bD\u008b<P+ÃK9ñöÏ¶Pm \u0097H\u0006\u0002Í\u0002\u008a¬4¦úCÜ¥\u0087\u001cg¾\u008apäS\u001cÀXR\u0081\u0010«\u0089ßJ\u0010Ë\u008b¬yî\u001frÔtÃ\u0001Ü\t \u0089\u0002\u0018ÌwÐçë¿ÃùÐIð\b5áS3#è\u0096\u0088n\u0090Äì «ØõÈE¦u\u000fÏtýkÌ\u008aÒÚñ\u0097rP~@ \u009cÆùS;ð¼ã]0\u008cÿþêøNç49dì®ë,\u001d\u0003\u0085?\b1´Q\\p`öÀ\u001f|÷'}y1Tms¹\u0007³\u0089ò#ÔIn½õ"
         .length();
      char var10 = ' ';
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     w = var14;
                     x = new String[9];
                     b = "Client";
                     a = "Prestige";
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(20570428403914L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = 3837979915917004041L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)53L,
                           (byte)13635L,
                           (byte)3490622L,
                           (byte)893599334L,
                           (byte)228761429543L,
                           (byte)58562925963089L,
                           (byte)14992109046550797L,
                           (byte)3837979915917004041L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     B = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "+\u009c¸þ\u0019nÚ\u0006\u0090¦~ýW2\u0081\u0093\u0018×©\u0004ÔEÜ_\u0081\"$\u0012æ\u0097s%wÑ¢\u0012ý¥)\u0084\u00ad";
                  var13 = "+\u009c¸þ\u0019nÚ\u0006\u0090¦~ýW2\u0081\u0093\u0018×©\u0004ÔEÜ_\u0081\"$\u0012æ\u0097s%wÑ¢\u0012ý¥)\u0084\u00ad".length();
                  var10 = 16;
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 2146;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cf", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cf_C0122",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cf" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = D[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = C[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 19;
            yield var17;
         }
         case 3 -> {
            byte var18 = 24;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 29;
            yield var20;
         }
         case 6 -> {
            byte var21 = 55;
            yield var21;
         }
         case 7 -> {
            byte var22 = 51;
            yield var22;
         }
         case 8 -> {
            byte var23 = 38;
            yield var23;
         }
         case 9 -> {
            byte var24 = 12;
            yield var24;
         }
         case 10 -> {
            byte var25 = 7;
            yield var25;
         }
         case 11 -> {
            byte var26 = 41;
            yield var26;
         }
         case 12 -> {
            byte var27 = 20;
            yield var27;
         }
         case 13 -> {
            byte var28 = 46;
            yield var28;
         }
         case 14 -> {
            byte var29 = 54;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 0;
            yield var31;
         }
         case 17 -> {
            byte var32 = 56;
            yield var32;
         }
         case 18 -> {
            byte var33 = 43;
            yield var33;
         }
         case 19 -> {
            byte var34 = 16;
            yield var34;
         }
         case 20 -> {
            byte var35 = 21;
            yield var35;
         }
         case 21 -> {
            byte var36 = 63;
            yield var36;
         }
         case 22 -> {
            byte var37 = 4;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 17;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 52;
            yield var41;
         }
         case 27 -> {
            byte var42 = 5;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 58;
            yield var44;
         }
         case 30 -> {
            byte var45 = 2;
            yield var45;
         }
         case 31 -> {
            byte var46 = 23;
            yield var46;
         }
         case 32 -> {
            byte var47 = 57;
            yield var47;
         }
         case 33 -> {
            byte var48 = 59;
            yield var48;
         }
         case 34 -> {
            byte var49 = 50;
            yield var49;
         }
         case 35 -> {
            byte var50 = 33;
            yield var50;
         }
         case 36 -> {
            byte var51 = 35;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 30;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 31;
            yield var55;
         }
         case 41 -> {
            byte var56 = 36;
            yield var56;
         }
         case 42 -> {
            byte var57 = 60;
            yield var57;
         }
         case 43 -> {
            byte var58 = 10;
            yield var58;
         }
         case 44 -> {
            byte var59 = 3;
            yield var59;
         }
         case 45 -> {
            byte var60 = 8;
            yield var60;
         }
         case 46 -> {
            byte var61 = 28;
            yield var61;
         }
         case 47 -> {
            byte var62 = 18;
            yield var62;
         }
         case 48 -> {
            byte var63 = 15;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 45;
            yield var65;
         }
         case 51 -> {
            byte var66 = 9;
            yield var66;
         }
         case 52 -> {
            byte var67 = 11;
            yield var67;
         }
         case 53 -> {
            byte var68 = 26;
            yield var68;
         }
         case 54 -> {
            byte var69 = 47;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 61;
            yield var72;
         }
         case 58 -> {
            byte var73 = 34;
            yield var73;
         }
         case 59 -> {
            byte var74 = 42;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 25;
            yield var76;
         }
         case 62 -> {
            byte var77 = 37;
            yield var77;
         }
         default -> 6;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            D[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      C[0] = "\u0001^\u001a\u0001NY\u0017^\u001f[]N\u0000\u0015\u001c]QZ\u0011R\u000bJ\u001aKT";
      C[1] = "c_ A\u0016V\u0016\u007f+N\u0007\u0019wq E\u0003C\u0003";
      C[2] = void.class;
      D[2] = "java/lang/Void";
      C[3] = "VU\u0004-\u0007)@U\u0001w\u0014>W\u001e\u0002q\u0018*FY\u0015fS:T";
      C[4] = "[R_)8LP]Nf[AEPA\rnCTC]!yN";
      C[5] = "\u0004\u00157%Bj\u0012\u00152\u007fQ}\u0005^1y]i\u0014\u0019&n\u0016{%";
      C[6] = int.class;
      D[6] = "java/lang/Integer";
      C[7] = "jn)N\u0006\u0016|n,\u0014\u0015\u0001k%/\u0012\u0019\u0015zb8\u0005R\u0007L";
      C[8] = "{\u0013\f%x^\u000e3\u0007*i\u0011o=\f!mK\u001b";
      C[9] = "\r:R0-~\u0010/\n\u0012ls\b)";
      C[10] = "\u0003jSo~;\beB \u001d6\u001dc";
      C[11] = float.class;
      D[11] = "java/lang/Float";
      C[12] = double.class;
      D[12] = "java/lang/Double";
      C[13] = "p9V#\u0003\u0005f9Sy\u0010\u0012qrP\u007f\u001c\u0006`5GhW\u0016n";
      C[14] = "={0NZ'H[;AKh)U0JO2]";
      C[15] = "\u0015\u0004h3\u0003_\u0003\u0004mi\u0010H\u0014Ono\u001c\\\u0005\byxWL\t";
      C[16] = "XRn~jXS]\u007f1\u0017MAG}r";
      C[17] = long.class;
      D[17] = "java/lang/Long";
      C[18] = "\u0015\u000b4\u000fyn\u0003\u000b1Ujy\u0014@2Sfm\u0005\u0007%D-}\u001d\u0007'Ow0!\u001c'Rww\u0016\u000b";
      C[19] = "sI?\r[+\u0006i4\u0002Jdgg?\tN>\u0013";
      C[20] = boolean.class;
      D[20] = "java/lang/Boolean";
      C[21] = "SGV\u000b#|&g]\u000423GiV\u000f6i3";
      C[22] = "}E\u0004\u001d^5kE\u0001GM\"|\u000e\u0002AA6mI\u0015V\n&r";
      C[23] = "vgqPb\u0002\u0003Gz_sMbIqTw\u0017\u0016";
      C[24] = ".{W\u0012|v[[\\\u001dm9:UW\u0016icN";
      C[25] = "\u0010\u00062\u0000<H\u0006\u00067Z/_\u0011M4\\#K\u0000\n#Kh\\\u0002";
      C[26] = "&d\n\u000eM\u001fSD\u0001\u0001\\P2J\n\nX\nF";
      C[27] = "\u0005\u0017\u0018bN\u0006\u0013\u0017\u001d8]\u0011\u0004\\\u001e>Q\u0005\u0015\u001b\t)\u001a\u0012\t";
      C[28] = "'=KQl\u0007R\u001d@^}H3\u0013KUy\u0012G";
      C[29] = "^\u0006\u000bu\n\u001eH\u0006\u000e/\u0019\t_M\r)\u0015\u001dN\n\u001a>^\fn";
      C[30] = "\u001f@\u0014Z\u001cA\t@\u0011\u0000\u000fV\u001e\u000b\u0012\u0006\u0003B\u000fL\u0005\u0011HU\u001c";
      C[31] = "w\u001cc!GD\u0002<h.V\u000bc2c%RQ\u0017";
      C[32] = "}[?l7\u001a\b{4c&Uiu?h\"\u000f\u001d";
      C[33] = "V\u000eBBe>@\u000eG\u0018v)WED\u001ez=F\u0002S\t1*T";
      C[34] = "lP<{n-\u0019p7t\u007fbx~<\u007f{8\f";
      C[35] = "\u0016LX\u0019qT\u0000L]CbC\u0017\u0007^EnW\u0006@IR%GK";
      C[36] = "7F7\u0011#5Bf<\u001e2z#h7\u00156 W";
      C[37] = "\r\u000f\bym\u0016x/\u0003v|Y\u0019!\b}x\u0003m";
      C[38] = "+!\u0017\u0013LO .\u0006\\-A+%\u0002\u0006";
      C[39] = "Z3\u0017\u0003S?\u000bdHZ/m`c\u000fJ\u00108\u001c9\u001a\u0004O\u0004Z\"\u0006\u0007\u0013x\u00007HX/";
      C[40] = "\f\u0011\u0010BO0OP\u0018A#d7R\u001dHMoY\u0002\u000eQ\u001b\u000e";
      C[41] = ">L\u00175\t,{\u001a\u0011z9:\u0003]\u000bc]&}H\u00149WV=\u0014\u0016:^l}D\u000eg9";
      C[42] = "^\u0013V(yY]\u000b_!HF\b\u00039s8E\u0002\u001a\b6!^\u001as\u0006<.@\bBC%5XaLI*+JP\tP13#";
      C[43] = "w\\d<^%tDm5o$)Z\u000bh\u001fo&^6*Q/w<;(_1*\u0001yf\u001f`H";
      C[44] = "*>\u0011eG]jn\t8 \bys!>]\n\u00143\u0004\"N\u0006zc\u0017;\u0018g";
      C[45] = "*}\u001b`\u0005\u0004z+A(z\u000b\u001bbB~\u001e\u0012ew]$\u0014brw\u0018iD\u000e}qGyz";
      C[46] = "\"C=[^\u0007%\u0001r\u0001,\t5@x\tJ\u001e\u0014[g\ti\u0003,^c\u001f,\tx\u0002b\u0004O\u0013!U?d";
      C[47] = "A5\u0015\t/R\u0012'\u0015\bPH*x\u0014V(\\L(B\f`";
      C[48] = ")aL\u001c/k'0(\u0007Oq'?L\u001c1d8eFl\"8;<\u0017\rvi#e(";
      C[49] = "r~#G#%}x|W\u001d6\u001bkyPy9e~f\nsI\"tl\\{8&,oI\u001d";
      C[50] = "J\u0007TzG}F\u0015\u001ct|h$\u0011Jq\u0018qZ\u0004U+\u0012\u0001\u001b\u0019Kt\u00150^\u0000Pl|";
      C[51] = "Y*,\u0003\u0002>W{H\u001ab$Wt,\u0003\u001c1H.&s[;Bx.\u0002_cAmH";
      C[52] = "Wq>vt\u0001Y Zg\u0014\u001bY/>vj\u000eFu4\u0006-\u0004L#<w)\\O6Z";
      C[53] = "`\\aZH\u0019lUiK%\u001b\u0000AkNA\u000f~Tt\u0014K\u007f9^~BC\u000e=\u0006}W%";
      C[54] = "ZgV\u0014\u000f\u007f\u0002a\\\u001cax8u]\u0014\u0005aF`BN\u000f\u0011[2B\u000b\u0002t\bbE\na";
      C[55] = "/\tB\u007f\u007fo.MJ/EmL\nT(!v2\u001fKr+\u0006u\u0015A$#wqMB1E";
      C[56] = "L\u001b6\u00002\u0018C\u001di\u0010\f\u001d%\u000el\u0017h\u0004[\u001bsMbt\u001a\u0006m\u0012eE_\u001fv\n\f";
      C[57] = "O7 p\u0005\u0017Ns#\u007f`\f)s-}\u0004\u0017Wf2'\u000eg\u0010l8q\u0006\u0016\u00144;d`";
      C[58] = "5Q\u000e\u0001R%?O\u0001Y-/RU\u0007\u0002I2,@\u0018XCBkJ\u0012\u000eK3o\u0012\u0011\u001b-";
      C[59] = "|\u0017\u007fBF$s\u0011 Rx#\u0015\u0002%U\u001c8k\u0017:\u000f\u0016H*\n$P\u0011yo\u0013?Hx";
      C[60] = "\u001f~V1\u0003;_.NldnL3vc\b\u0001\u001d T`\u0005oM3M6d";
      C[61] = "{\u000eBUm\u001e;^Z\b\nK(Cw\u0010gI#?\u0004\u0005rJ$QT\u0016k\u001cE";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = C[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(D[var4]);
            C[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = C[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            C[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  C[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(2690599715389892L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = C[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  C[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(2690599715389892L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        C[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(2690599715389892L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 170;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 114;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 82;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 118;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 194;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 170;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 114;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 82;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cf_C0122",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cf" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
