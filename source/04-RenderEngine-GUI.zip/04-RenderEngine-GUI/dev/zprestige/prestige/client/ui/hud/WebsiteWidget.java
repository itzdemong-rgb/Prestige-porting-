package dev.zprestige.prestige.client.ui.hud;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.client.ui.ClientUiUtil;
import dev.zprestige.prestige.client.ui.UiMetrics;
import dev.zprestige.prestige.renderlib.BlurredRectangleRenderer;
import dev.zprestige.prestige.renderlib.FilledRectangleRenderer;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.renderlib.font.MsdfFont;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;

public class WebsiteWidget extends HudElement {
   private static final String a;
   private static final long v = 65672540258074L;
   private static final String[] w;
   private static final String[] x;
   private static final Map y = new HashMap(13);
   private static final long B;
   private static final Object[] C = new Object[43];
   private static final String[] D = new String[43];

   public WebsiteWidget(long var1) {
      super("Website", "Display client website", ((65672540258074L ^ (65672540258074L ^ var1)) ^ 55102878915501L));
      var1 = 65672540258074L ^ var1;
      long var3 = var1 ^ 55102878915501L;
      short var10001 = 276;
      long var10002 = 1836241937371617627L ^ var1;
      short var6 = 17637;
      long var10003 = 4181301812326603947L ^ var1;

   }

   @Override
   public void mReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 101393985901669L;
      Object[] var10005 = new Object[]{null, null, var4};
      var10005[1] = 3.0F;
      var10005[0] = 150.0F;
      Object[] var7 = var10005;
      WebsiteWidget var6 = this;
      var6.aReturningVoid(var7);
   }

   @Override
   public void lReturningVoid(Object[] var1) {
      MeshBufferManager var3 = (MeshBufferManager)var1[0];
      RenderContext var2 = (RenderContext)var1[1];
      Matrix4f var6 = (Matrix4f)var1[2];
      long var4 = (Long)var1[3];
      long var7 = var4 ^ 49928519994039L;
      long var9 = var4 ^ 48887442607471L;
      long var11 = var4 ^ 81054074941871L;
      long var13 = var4 ^ 36477842301344L;
      long var15 = var4 ^ 13608202459885L;
      long var17 = var4 ^ 29307267718371L;
      long var19 = var4 ^ 113406911627307L;
      MsdfFontManager var10000 = Prestige.c;
      Object[] var33 = new Object[]{var15};
      MsdfFontManager var32 = var10000;
      MsdfFont var55 = var32.aReturningcx_C0158(var33);
      Object[] var35 = new Object[]{var7};
      MsdfFont var34 = var55;
      float var21 = var34.cReturningFloat(var35);
      var10000 = Prestige.c;
      Object[] var37 = new Object[]{var15};
      MsdfFontManager var36 = var10000;
      MsdfFont var57 = var36.aReturningcx_C0158(var37);
      short var10001 = 24095;
      long var10002 = 8647878169606244759L ^ var4;
      Object[] var39 = new Object[]{"648k.exe", var11};
      MsdfFont var38 = var57;
      float var22 = var38.aReturningFloat(var39) * 1.0F;
      float var23 = 5.5F + var22 + 5.5F;
      Object[] var10003 = new Object[]{null, 1.0F};
      var10003[0] = var21;
      Object[] var40 = var10003;
      float var24 = UiMetrics.aReturningFloat(var40);
      float var25 = this.e;
      float var26 = this.f;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10011[8] = 4.0F;
      var10011[7] = 5;
      var10011[6] = var24;
      var10011[5] = var23;
      var10011[4] = var26;
      var10011[3] = var25;
      var10011[2] = var6;
      var10011[1] = var2;
      var10011[0] = var3;
      Object[] var41 = var10011;
      BlurredRectangleRenderer.eReturningVoid(var41);
      Color var10007 = UiMetrics.r;
      var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var17};
      var10011[8] = 4.0F;
      var10011[7] = var10007;
      var10011[6] = var24;
      var10011[5] = var23;
      var10011[4] = var26;
      var10011[3] = var25;
      var10011[2] = var6;
      var10011[1] = var2;
      var10011[0] = var3;
      Object[] var42 = var10011;
      FilledRectangleRenderer.cReturningVoid(var42);
      Object[] var43 = new Object[]{var13};
      Color var27 = ClientUiUtil.dReturningColor(var43);
      double var44 = System.currentTimeMillis() * 0.0031415926535897933;
      float var28 = (float)(Math.sin(var44) * 0.5 + 0.5);
      Color var46 = var27;
      int var60 = var46.getRed();
      Color var47 = var27;
      int var62 = var47.getGreen();
      Color var48 = var27;
      Color var29 = new Color(var60, var62, var48.getBlue(), (int)B + (int)(105.0F * var28));
      float var30 = var25 + 5.5F;
      float var31 = var26 + (var24 - var21 * 1.0F) / 2.0F;
      var10000 = Prestige.c;
      Object[] var50 = new Object[]{var15};
      MsdfFontManager var49 = var10000;
      MsdfFont var59 = var49.aReturningcx_C0158(var50);
      short var61 = 22608;
      long var63 = 7418909002874933215L ^ var4;
      Object[] var10009 = new Object[]{null, null, null, null, null, var29, var19};
      var10009[4] = 1.0F;
      var10009[3] = var31;
      var10009[2] = var30;
      var10009[1] = "648k.exe";
      var10009[0] = var6;
      Object[] var52 = var10009;
      MsdfFont var51 = var59;
      var51.w(var52);
      Object[] var10004 = new Object[]{null, var24};
      var10004[0] = var23;
      Object[] var54 = var10004;
      WebsiteWidget var53 = this;
      var53.iReturningVoid(var54);
   }

   static {

      {

      b();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(23501935329662L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[5];
      String var11 = "\u0015y\u0091\u00077d\u0087f9,\u0082KQ7\u0091\u001e\u007fÍ¸Õòð\u0005\u0082«z\u008faå0>h¿uy\u0086Ö{æk\u0010Ë®\u001f\u0010\tF\u0017ÎèNø$\räb\f \u009cÆ\u00112·FY8rÓ\u0002¦DBÅ]ÞÊî\u0084)©û§nI'Ã\u0091ÂÛ\u0007";
      int var13 = "\u0015y\u0091\u00077d\u0087f9,\u0082KQ7\u0091\u001e\u007fÍ¸Õòð\u0005\u0082«z\u008faå0>h¿uy\u0086Ö{æk\u0010Ë®\u001f\u0010\tF\u0017ÎèNø$\räb\f \u009cÆ\u00112·FY8rÓ\u0002¦DBÅ]ÞÊî\u0084)©û§nI'Ã\u0091ÂÛ\u0007"
         .length();
      char var10 = '(';
      int var17 = -1;

      label37:
      while (true) {
         String var18 = var11.substring(++var17, var17 + var10);
         // while (true) {
            byte[] var15 = var7.doFinal(var18.getBytes("ISO-8859-1"));
            String var27 = b(var15).intern();
            switch (var10001) {
               case 0:
                  var14[var12++] = var27;
                  if ((var17 += var10) >= var13) {
                     w = var14;
                     x = new String[5];
                     a = "648k.exe";
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(23501935329662L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var24 = -468227278958265095L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)249L,
                           (byte)63872L,
                           (byte)16351365L,
                           (byte)4185949637L,
                           (byte)1071603107139L,
                           (byte)274330395427723L,
                           (byte)70228581229497212L,
                           (byte)-468227278958265095L
                        }
                     );
                     long var31 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     var10001 = -1;
                     B = var31;
                     break;
                  }

                  var10 = var11.charAt(var17);
                  break;
               default:
                  var14[var12++] = var27;
                  if ((var17 += var10) < var13) {
                     var10 = var11.charAt(var17);
                     continue label37;
                  }

                  var11 = "1\u0012\u0015Ü¡\u001a\u008a|[Êø+·\u0012/\u0084k0\u0002lS\u001e\u0002\u0013\u0096:8\u0011\u0011\u001d\u000b\u009eæÞ\u0098\u001f\u009f#`º(\u008d\u0014ÖÉ§ýpk\u001e°\u009c':\"?ý\u0080Â\u009d3íT\u001bÍâUAÚ\u0098¢\u0000ö\u0096Ädª»Ô\u0098n";
                  var13 = "1\u0012\u0015Ü¡\u001a\u008a|[Êø+·\u0012/\u0084k0\u0002lS\u001e\u0002\u0013\u0096:8\u0011\u0011\u001d\u000b\u009eæÞ\u0098\u001f\u009f#`º(\u008d\u0014ÖÉ§ýpk\u001e°\u009c':\"?ý\u0080Â\u009d3íT\u001bÍâUAÚ\u0098¢\u0000ö\u0096Ädª»Ô\u0098n"
                     .length();
                  var10 = '(';
                  var17 = -1;
            }

            var18 = var11.substring(++var17, var17 + var10);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static String b(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21529;
      if (x[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])y.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               y.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cg", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = w[var5].getBytes("ISO-8859-1");
         x[var5] = b(((Cipher)var4[0]).doFinal(var9));
      }

      return x[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cg_C0124",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = D[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = C[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 50;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 22;
            yield var17;
         }
         case 3 -> {
            byte var18 = 56;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 49;
            yield var20;
         }
         case 6 -> {
            byte var21 = 35;
            yield var21;
         }
         case 7 -> {
            byte var22 = 29;
            yield var22;
         }
         case 8 -> {
            byte var23 = 16;
            yield var23;
         }
         case 9 -> {
            byte var24 = 1;
            yield var24;
         }
         case 10 -> {
            byte var25 = 33;
            yield var25;
         }
         case 11 -> {
            byte var26 = 27;
            yield var26;
         }
         case 12 -> {
            byte var27 = 58;
            yield var27;
         }
         case 13 -> {
            byte var28 = 26;
            yield var28;
         }
         case 14 -> {
            byte var29 = 19;
            yield var29;
         }
         case 15 -> {
            byte var30 = 51;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 44;
            yield var32;
         }
         case 18 -> {
            byte var33 = 48;
            yield var33;
         }
         case 19 -> {
            byte var34 = 21;
            yield var34;
         }
         case 20 -> {
            byte var35 = 30;
            yield var35;
         }
         case 21 -> {
            byte var36 = 46;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 23;
            yield var38;
         }
         case 24 -> {
            byte var39 = 40;
            yield var39;
         }
         case 25 -> {
            byte var40 = 12;
            yield var40;
         }
         case 26 -> {
            byte var41 = 15;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 57;
            yield var44;
         }
         case 30 -> {
            byte var45 = 52;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 7;
            yield var47;
         }
         case 33 -> {
            byte var48 = 34;
            yield var48;
         }
         case 34 -> {
            byte var49 = 11;
            yield var49;
         }
         case 35 -> {
            byte var50 = 32;
            yield var50;
         }
         case 36 -> {
            byte var51 = 53;
            yield var51;
         }
         case 37 -> {
            byte var52 = 59;
            yield var52;
         }
         case 38 -> {
            byte var53 = 8;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 18;
            yield var55;
         }
         case 41 -> {
            byte var56 = 2;
            yield var56;
         }
         case 42 -> {
            byte var57 = 28;
            yield var57;
         }
         case 43 -> {
            byte var58 = 62;
            yield var58;
         }
         case 44 -> {
            byte var59 = 5;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 55;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 38;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 37;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 9;
            yield var68;
         }
         case 54 -> {
            byte var69 = 17;
            yield var69;
         }
         case 55 -> {
            byte var70 = 41;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 3;
            yield var72;
         }
         case 58 -> {
            byte var73 = 13;
            yield var73;
         }
         case 59 -> {
            byte var74 = 25;
            yield var74;
         }
         case 60 -> {
            byte var75 = 24;
            yield var75;
         }
         case 61 -> {
            byte var76 = 14;
            yield var76;
         }
         case 62 -> {
            byte var77 = 42;
            yield var77;
         }
         default -> 39;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            D[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      C[0] = "\\ X\u0015yqJ ]Ojf]k^IfrL,I^-`z";
      C[1] = "GM^j\u001aP2mUe\u000b\u001fSc^n\u000fE'";
      C[2] = "Y&O\u000f\u001f=D3\u0017-^0\\5";
      C[3] = "o[T5{vdTEz\u0018{qR";
      C[4] = double.class;
      D[4] = "java/lang/Double";
      C[5] = int.class;
      D[5] = "java/lang/Integer";
      C[6] = ":C\u00003(e,C\u0005i;r;\b\u0006o7f*O\u0011x|v$";
      C[7] = "\u0007[`j\u0000Vr{ke\u0011\u0019\u0013u`n\u0015Cg";
      C[8] = "e\u001d+\u0012U$s\u001d.HF3dV-NJ'u\u0011:Y\u00017y";
      C[9] = "\u0016l\n\u00002v\u001dc\u001bOOc\u000fy\u0019\f";
      C[10] = long.class;
      D[10] = "java/lang/Long";
      C[11] = "Sg~+)2Eg{q:%R,xw61Cko`}![kmk'lgpmv'+Pg";
      C[12] = "+\u001c)g_K^<\"hN\u0004?2)cJ^K";
      C[13] = void.class;
      D[13] = "java/lang/Void";
      C[14] = ",({o\f5:(~5\u001f\"-c}3\u00136<$j$X&#";
      C[15] = "MW;\u0007\u0004Q8w0\b\u0015\u001eYy;\u0003\u0011D-";
      C[16] = float.class;
      D[16] = "java/lang/Float";
      C[17] = "m\u0017\u001a/TM{\u0017\u001fuGZl\\\u001csKN}\u001b\u000bd\u0000_8";
      C[18] = "Q\f\u001a%cH$,\u0011*r\u0007E\"\u001a!v]1";
      C[19] = ",6^\u0018t~Y\u0016U\u0017e18\u0018^\u001cakL";
      C[20] = "LSjkiTZSo1zCM\u0018l7vW\\_{ =@N";
      C[21] = "\u0012c\u0010\u00159*gC\u001b\u001a(e\u0006M\u0010\u0011,?r";
      C[22] = "\u0013\u0001Gck\f\u0005\u0001B9x\u001b\u0012JA?t\u000f\u0003\rV(?\u001fN";
      C[23] = "?i6@'bJI=O6-+G6D2w_";
      C[24] = "\u000193-\u0007Vt\u00198\"\u0016\u0019\u0015\u00173)\u0012Ca";
      C[25] = ">\u0015\u000e\u0003\u0002\u0010K5\u0005\f\u0013_*;\u000e\u0007\u0017\u0005^";
      C[26] = "\u0001BE6\u001a\u001b\nMTy{\u0015\u0001FP#";
      C[27] = "sM\u0015!o`\u007fN\u001f]n^r\u0011Jm~/vLQ?\u0002d+KL!k=.\u0002E]";
      C[28] = "WXDeT<TX\u001c{$$\f\u0000x/K3\u0011\r\u001ch\u0014<\tfC{H#\u0006\u0002\u0004$G;m";
      C[29] = "40H\u0015Y(m5\u0001\u001c%.cu:\u0012X,\u000e2\f\u0016L~q3\u001d\u000fIA";
      C[30] = "U\u000b:\n.y\u0019\u001f I_qi\u000e!\u0015od\u0018\n|\u000e=\u0018T\u000b2M2$\r\f$\t_";
      C[31] = "{<\u0019nN\u0000/(\u0013{!Q8*\u000fdGF\u00191\u0010dd[!4\u0014r!\u0005\u007f=\u0013d@\n}i\t\t";
      C[32] = "m,{tA[:}u$\u007f\u0000]!s6\u0005\u001a<mg,F";
      C[33] = "<\u0005\\\u001f\u0012^e\u0002J[\u007f\u001d\u0001\u0000OGO\u001ep\u0004\u0012\\\u001db0Q\\X\u0005\u000b9\\B\u001f\u007f";
      C[34] = "5\u0018\f13am\u001e\u000emKi\u0004\u0003T7{|u\u0007\t,)\u0000n^\u000f +j}\u0011H8K";
      C[35] = "!N/;%6&\u000fz:\u001e>KUr;.#:Q/ |_z\u0004a$d6s\t\u007fc\u001e";
      C[36] = "X\u0011[EYb_P\u000eDbb2\n\u0006ERwC\u000e[^\u0000\u000b\u0003[\u0015Z\u0018b\nV\u000b\u001db";
      C[37] = ";/9_\u000eJb(/\u001bc\u001f\u0006**\u0007S\nw.w\u001c\u0001vlwq\u0010\u0003\u001c\u007f86\bc";
      C[38] = "B3=t,o\u0014nyu@j/k& p}^o{;\"\u0001\u001e:5?:h\u00177+x@";
      C[39] = "\r@?\u0010o:\u0005\u0019`\u0012\u0014+cDa\f$:\u0012@<\u0017vFR\u0015r\u0013n/[\u0018lT\u0014";
      C[40] = "b$\u001f\u0014\u001cJ;#\tPq\u001d_!\fLA\n.%QW\u0013v5|W[\u0011\u001c&3\u0010Cq";
      C[41] = "\u00015\u0000J0FX0ICL@VpbD /\u0000pX@sP\u0001aAEL";
      C[42] = "\u0013h\u0001Z:(JmHSF.D-vC+,OQ\u0002E&(\u0016.\u0003T?-)";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = C[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(D[var4]);
            C[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = C[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            C[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  C[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(1842450370436994L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = C[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = D[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  C[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(1842450370436994L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        C[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(1842450370436994L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 105;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 194;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 237;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 36;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 252;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 113;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 105;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 194;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 237;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cg_C0124",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
