package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.NumberUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;

public class BlurredRectangleRenderer extends PrimitiveRenderer {
   private static final BlurredRectangleRenderer a;
   private static final Map b;
   private static final Map c;
   private final int d;
   private final int e;
   private static final long f = 19116552745676L;
   private static final String[] g;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[93];
   private static final String[] n = new String[93];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;

   private BlurredRectangleRenderer(long var1) {
      super("shaders/rounded_texture.vert", "shaders/rounded_texture_blurred.frag", ((19116552745676L ^ (19116552745676L ^ var1)) ^ 3351907032197L));
      var1 = 19116552745676L ^ var1;
      long var3 = var1 ^ 85660297310746L;
      long var5 = var1 ^ 3351907032197L;
      long var7 = var1 ^ 88162769664551L;
      short var10001 = 2056;
      long var10002 = 5505299652657615524L ^ var1;
      short var25 = 5538;
      long var10003 = 5177646155989847823L ^ var1;

      Object[] var10 = new Object[0];
      BlurredRectangleRenderer var9 = this;
      GlProgram var22 = var9.aReturningfM_C0295(var10);
      short var26 = 26367;
      var10003 = 3362967706651032656L ^ var1;
      Object[] var12 = new Object[]{"roundness", var3};
      GlProgram var11 = var22;
      this.d = var11.dReturningInt(var12);
      Object[] var14 = new Object[0];
      BlurredRectangleRenderer var13 = this;
      GlProgram var23 = var13.aReturningfM_C0295(var14);
      short var27 = 8544;
      var10003 = 8249050842724744142L ^ var1;
      Object[] var16 = new Object[]{"invBlurTexSize", var3};
      GlProgram var15 = var23;
      this.e = var15.dReturningInt(var16);
      Object[] var18 = new Object[0];
      BlurredRectangleRenderer var17 = this;
      GlProgram var10000 = var17.aReturningfM_C0295(var18);
      var10001 = 24583;
      var10002 = 5518713531942369965L ^ var1;
      Object[] var10005 = new Object[]{null, null, var7};
      var10005[1] = 0;
      var10005[0] = "texSampler";
      Object[] var20 = var10005;
      GlProgram var19 = var10000;
      var19.aReturningVoid(var20);
   }

   public static void aReturningVoid(Object[] var0) {
      MeshBufferManager var1 = (MeshBufferManager)var0[0];
      RenderContext var6 = (RenderContext)var0[1];
      float var4 = (Float)var0[2];
      float var7 = (Float)var0[3];
      float var9 = (Float)var0[4];
      float var5 = (Float)var0[5];
      int var8 = (Integer)var0[6];
      long var2 = (Long)var0[7];
      var2 = 19116552745676L ^ var2;
      long var10 = var2 ^ 89790066737660L;
      DualPassBlurRenderer var12 = (DualPassBlurRenderer)invokeBinding3(b, invokeBinding1(var8, 3648600016660234456L, var2), invokeBinding2(var8), 3648884739753878303L, var2);
      BlurredRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(0.0F), var10};
      var10012[7] = var5;
      var10012[6] = var9;
      var10012[5] = var7;
      var10012[4] = var4;
      var10012[3] = var12;
      var10012[2] = var10003;
      var10012[1] = var6;
      var10012[0] = var1;
      invokeBinding4(var10000, var10012, 3648163487152461265L, var2);
   }

   public static void bReturningVoid(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      float var4 = (Float)var0[2];
      float var6 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var8 = (Float)var0[5];
      int var5 = (Integer)var0[6];
      float var3 = (Float)var0[7];
      long var1 = (Long)var0[8];
      var1 = 19116552745676L ^ var1;
      long var11 = var1 ^ 17381889923887L;
      DualPassBlurRenderer var13 = (DualPassBlurRenderer)invokeBinding7(b, invokeBinding5(var5, -6309208806130509301L, var1), invokeBinding6(var5), -6309491192676992564L, var1);
      BlurredRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var3), var11};
      var10012[7] = var8;
      var10012[6] = var10;
      var10012[5] = var6;
      var10012[4] = var4;
      var10012[3] = var13;
      var10012[2] = var10003;
      var10012[1] = var9;
      var10012[0] = var7;
      invokeBinding8(var10000, var10012, -6308488396279755006L, var1);
   }

   public static void cReturningVoid(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      float var2 = (Float)var0[2];
      float var8 = (Float)var0[3];
      float var9 = (Float)var0[4];
      float var5 = (Float)var0[5];
      int var3 = (Integer)var0[6];
      Vector4f var4 = (Vector4f)var0[7];
      long var6 = (Long)var0[8];
      var6 = 19116552745676L ^ var6;
      long var11 = var6 ^ 120449201594596L;
      DualPassBlurRenderer var13 = (DualPassBlurRenderer)invokeBinding11(b, invokeBinding9(var3, -7801832935504272960L, var6), invokeBinding10(var3), -7801556772341677561L, var6);
      BlurredRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, var4, var11};
      var10012[7] = var5;
      var10012[6] = var9;
      var10012[5] = var8;
      var10012[4] = var2;
      var10012[3] = var13;
      var10012[2] = var10003;
      var10012[1] = var1;
      var10012[0] = var10;
      invokeBinding12(var10000, var10012, -7802242840568630071L, var6);
   }

   public static void dReturningVoid(Object[] var0) {
      MeshBufferManager var5 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      Matrix4f var1 = (Matrix4f)var0[2];
      float var7 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var6 = (Float)var0[5];
      float var2 = (Float)var0[6];
      int var4 = (Integer)var0[7];
      Vector4f var11 = (Vector4f)var0[8];
      long var8 = (Long)var0[9];
      var8 = 19116552745676L ^ var8;
      long var12 = var8 ^ 91184289604235L;
      Map var10000 = b;
      int var15 = var4;
      Integer var10001 = var15;
      Function var18 = invokeBinding13(var4);
      Integer var17 = var10001;
      Map var16 = var10000;
      DualPassBlurRenderer var14 = (DualPassBlurRenderer)var16.computeIfAbsent(var17, var18);
      BlurredRectangleRenderer var22 = a;
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, var11, var12};
      var10012[7] = var2;
      var10012[6] = var6;
      var10012[5] = var10;
      var10012[4] = var7;
      var10012[3] = var14;
      var10012[2] = var1;
      var10012[1] = var3;
      var10012[0] = var5;
      Object[] var20 = var10012;
      BlurredRectangleRenderer var19 = var22;
      var19.gReturningVoid(var20);
   }

   public static void eReturningVoid(Object[] var0) {
      MeshBufferManager var11 = (MeshBufferManager)var0[0];
      RenderContext var7 = (RenderContext)var0[1];
      Matrix4f var3 = (Matrix4f)var0[2];
      float var1 = (Float)var0[3];
      float var2 = (Float)var0[4];
      float var4 = (Float)var0[5];
      float var8 = (Float)var0[6];
      int var10 = (Integer)var0[7];
      float var9 = (Float)var0[8];
      long var5 = (Long)var0[9];
      var5 = 19116552745676L ^ var5;
      long var12 = var5 ^ 139465392115581L;
      Map var10000 = b;
      int var15 = var10;
      Integer var10001 = var15;
      Function var18 = invokeBinding14(var10);
      Integer var17 = var10001;
      Map var16 = var10000;
      DualPassBlurRenderer var14 = (DualPassBlurRenderer)var16.computeIfAbsent(var17, var18);
      BlurredRectangleRenderer var22 = a;
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var9), var12};
      var10012[7] = var8;
      var10012[6] = var4;
      var10012[5] = var2;
      var10012[4] = var1;
      var10012[3] = var14;
      var10012[2] = var3;
      var10012[1] = var7;
      var10012[0] = var11;
      Object[] var20 = var10012;
      BlurredRectangleRenderer var19 = var22;
      var19.gReturningVoid(var20);
   }

   public static void fReturningVoid(Object[] var0) {
      MeshBufferManager var3 = (MeshBufferManager)var0[0];
      RenderContext var5 = (RenderContext)var0[1];
      DualPassBlurRenderer var4 = (DualPassBlurRenderer)var0[2];
      float var6 = (Float)var0[3];
      float var8 = (Float)var0[4];
      float var2 = (Float)var0[5];
      float var1 = (Float)var0[6];
      float var7 = (Float)var0[7];
      long var9 = (Long)var0[8];
      var9 = 19116552745676L ^ var9;
      long var11 = var9 ^ 124342533265362L;
      BlurredRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var7), var11};
      var10012[7] = var1;
      var10012[6] = var2;
      var10012[5] = var8;
      var10012[4] = var6;
      var10012[3] = var4;
      var10012[2] = var10003;
      var10012[1] = var5;
      var10012[0] = var3;
      invokeBinding15(var10000, var10012, -1977430001375837185L, var9);
   }

   private void gReturningVoid(Object[] var1) {
      Matrix4f var9 = (Matrix4f)var1[2];
      DualPassBlurRenderer var6 = (DualPassBlurRenderer)var1[3];
      float var12 = (Float)var1[4];
      float var4 = (Float)var1[5];
      float var8 = (Float)var1[6];
      float var5 = (Float)var1[7];
      Vector4f var10 = (Vector4f)var1[8];
      long var2 = (Long)var1[9];
      var2 = 19116552745676L ^ var2;
      long var13 = var2 ^ 126887890947678L;
      long var15 = var2 ^ 82501598482498L;
      long var17 = var2 ^ 69108525307906L;
      Object[] var21 = new Object[]{var6, var10, var15};
      BlurredRectangleRenderer var20 = this;
      DrawPipeline var19 = var20.aReturningdn_C0192(var21);
      Object[] var22 = new Object[]{var17};
      RenderCommandBatcher var10000 = ShapeRenderer.aReturningf4(var22);
      Object[] var24 = new Object[]{new PipelineRenderCommand(var19, invokeBinding16(var9, var12, var4, var5, var8)), var13};
      RenderCommandBatcher var23 = var10000;
      var23.bReturningVoid(var24);
   }

   private DrawPipeline aReturningdn_C0192(Object[] var1) {
      DualPassBlurRenderer var3 = (DualPassBlurRenderer)var1[0];
      Vector4f var2 = (Vector4f)var1[1];
      long var4 = (Long)var1[2];
      var4 = 19116552745676L ^ var4;
      long var6 = var4 ^ 75205686063470L;
      long var8 = var4 ^ 26131109103645L;
      int var10000 = Event.cReturningInt();
      Object[] var14 = new Object[]{var2, var8};
      Vector4f var11 = NumberUtil.aReturningVector4f(var14);
      int var10 = var10000;
      Map var38 = c;
      Function var17 = invokeBinding17();
      DualPassBlurRenderer var16 = var3;
      Map var15 = var38;
      Map var12 = (Map)var15.computeIfAbsent(var16, var17);
      Vector4f var19 = var11;
      Map var18 = var12;
      DrawPipeline var13 = (DrawPipeline)var18.get(var19);
      int var35 = var10;
      DrawPipeline var34 = var13;
      DrawPipeline var33 = var34;
      DrawPipeline var32 = var34;
      if (var35 != 0) {
         DrawPipeline var36 = var32;
         if (var36 == null) {
            VertexFormat var10002 = VertexFormats.g;
            short var10005 = 25254;
            long var10006 = 2910486741384163783L ^ var4;
            RenderState[] var39 = new RenderState[7];
            Object[] var21 = new Object[]{invokeBinding18(var3)};
            var39[0] = RenderState.bReturningfP_C0301(var21);
            var39[1] = RenderState.a;
            Object[] var23 = new Object[0];
            BlurredRectangleRenderer var22 = this;
            Object[] var24 = new Object[]{var22.aReturningfM_C0295(var23)};
            var39[2] = RenderState.aReturninggH_C0339(var24);
            short var10008 = 30549;
            long var10009 = 9132817675589116976L ^ var4;
            Object[] var10011 = new Object[]{null, true};
            var10011[0] = 2884;
            Object[] var25 = var10011;
            var39[3] = RenderState.aReturninggF_C0335(var25);
            var10011 = new Object[]{null, true};
            var10011[0] = true;
            Object[] var26 = var10011;
            var39[4] = RenderState.aReturninggI_C0341(var26);
            var10008 = 31282;
            var10009 = 9212918859731298646L ^ var4;
            short var43 = 28115;
            long var10010 = 4124783867886993073L ^ var4;
            var10011 = new Object[]{null, 515};
            var10011[0] = 515;
            Object[] var27 = var10011;
            var39[5] = RenderState.aReturninggD_C0331(var27);
            short var10007 = 25735;
            long var41 = 3192204405480191968L ^ var4;
            Object[] var28 = new Object[]{invokeBinding19(this, var3, var11)};
            var39[6] = RenderState.aReturningfP_C0301(var28);
            var13 = new DrawPipeline(var10002, 4, false, var39, var6);
            DrawPipeline var31 = var13;
            Vector4f var30 = var11;
            Map var29 = var12;
            var29.put(var30, var31);
         }

         var33 = var13;
      }

      return var33;
   }

   private void lambda$getRenderLayer$8(DualPassBlurRenderer var1, Vector4f var2, RenderPass var3) {
      GL13.glActiveTexture(33984);
      int var10000 = 3553;
      int var8 = var1.c.a;
      GL11.glBindTexture(3553, var8);
      var10000 = this.e;
      Object[] var10 = new Object[0];
      DualPassBlurRenderer var9 = var1;
      float var10001 = 1.0F / var9.aReturningInt(var10);
      Object[] var12 = new Object[0];
      DualPassBlurRenderer var11 = var1;
      float var15 = 1.0F / var11.bReturningInt(var12);
      float var14 = var10001;
      int var13 = var10000;
      GL20.glUniform2f(var13, var14, var15);
      Vector4f var16 = var2;
      Vector4f var17 = var2;
      Vector4f var18 = var2;
      Vector4f var19 = var2;
      float var24 = var19.w;
      float var23 = var18.z;
      float var22 = var17.y;
      float var21 = var16.x;
      int var20 = this.d;
      GL20.glUniform4f(var20, var21, var22, var23, var24);
   }

   private static void lambda$getRenderLayer$7(DualPassBlurRenderer var0, RenderPassBuilder var1) {
      long var10001 = 95844401759159L ^ 80675140871447L;
      Object[] var6 = new Object[0];
      var10001 = RenderThreadUtil.aReturningLong(var6);
      Object[] var10004 = new Object[]{null, 33484212561568L};
      var10004[0] = var10001;
      Object[] var8 = var10004;
      DualPassBlurRenderer var7 = var0;
      var7.bReturningVoid(var8);
   }

   private static Map lambda$getRenderLayer$6(DualPassBlurRenderer var0) {
      long var10001 = 122637276441773L ^ 132660300821435L;
      Object[] var10003 = new Object[]{null, 25489915207446L};
      var10003[0] = 128;
      Object[] var5 = var10003;
      return NumberUtil.aReturningMap(var5);
   }

   private static void lambda$drawInternal$5(Matrix4f var0, float var1, float var2, float var3, float var4, Float var5, MeshDataConsumer var6) {
      long var10001 = 133194601622466L ^ 126089124932472L;
      var10001 = 133194601622466L ^ 61827996727262L;
      var10001 = 133194601622466L ^ 54928124053545L;
      var10001 = 133194601622466L ^ 133972156258347L;
      var10001 = 133194601622466L ^ 70389226108894L;
      Object[] var20 = new Object[]{12707221340346L};
      MeshDataConsumer var19 = var6;
      MeshDataConsumer var10000 = var19.kReturningVoid(var20);
      float var10003 = var2 + var3;
      Float var21 = var5;
      float var10004 = var21;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var1;
      var10007[0] = var0;
      Object[] var23 = var10007;
      MeshDataConsumer var22 = var10000;
      var10000 = var22.dReturningMeshDataConsumer(var23);
      Object[] var25 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var24 = var10000;
      var10000 = var24.bReturningMeshDataConsumer(var25);
      Object[] var27 = new Object[]{new float[]{var4, var3}, 62839871708188L};
      MeshDataConsumer var26 = var10000;
      var10000 = var26.bReturningMeshDataConsumer(var27);
      float var10002 = var1 + var4;
      var10003 = var2 + var3;
      Float var28 = var5;
      var10004 = var28;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var10002;
      var10007[0] = var0;
      Object[] var30 = var10007;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.dReturningMeshDataConsumer(var30);
      Object[] var32 = new Object[]{new float[]{var4, 0.0F}, 62839871708188L};
      MeshDataConsumer var31 = var10000;
      var10000 = var31.bReturningMeshDataConsumer(var32);
      Object[] var34 = new Object[]{new float[]{var4, var3}, 62839871708188L};
      MeshDataConsumer var33 = var10000;
      var10000 = var33.bReturningMeshDataConsumer(var34);
      var10002 = var1 + var4;
      Float var35 = var5;
      var10004 = var35;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var2;
      var10007[1] = var10002;
      var10007[0] = var0;
      Object[] var37 = var10007;
      MeshDataConsumer var36 = var10000;
      var10000 = var36.dReturningMeshDataConsumer(var37);
      Object[] var39 = new Object[]{new float[]{var4, var3}, 62839871708188L};
      MeshDataConsumer var38 = var10000;
      var10000 = var38.bReturningMeshDataConsumer(var39);
      Object[] var41 = new Object[]{new float[]{var4, var3}, 62839871708188L};
      MeshDataConsumer var40 = var10000;
      var10000 = var40.bReturningMeshDataConsumer(var41);
      Float var42 = var5;
      var10004 = var42;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var2;
      var10007[1] = var1;
      var10007[0] = var0;
      Object[] var44 = var10007;
      MeshDataConsumer var43 = var10000;
      var10000 = var43.dReturningMeshDataConsumer(var44);
      Object[] var46 = new Object[]{new float[]{0.0F, var3}, 62839871708188L};
      MeshDataConsumer var45 = var10000;
      var10000 = var45.bReturningMeshDataConsumer(var46);
      Object[] var48 = new Object[]{new float[]{var4, var3}, 62839871708188L};
      MeshDataConsumer var47 = var10000;
      var10000 = var47.bReturningMeshDataConsumer(var48);
      Object[] var50 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var49 = var10000;
      var10000 = var49.iReturningVoid(var50);
      Object[] var52 = new Object[]{80089257141227L};
      MeshDataConsumer var51 = var10000;
      var51.hReturningMeshDataConsumer(var52);
   }

   private static DualPassBlurRenderer lambda$draw$4(int var0, Integer var1) {
      long var10001 = 72513665494606L ^ 19325326309919L;
      return new DualPassBlurRenderer(var0, var0 * 2, 88377012540497L);
   }

   private static DualPassBlurRenderer lambda$draw$3(int var0, Integer var1) {
      long var10001 = 60395433534043L ^ 112755913586186L;
      return new DualPassBlurRenderer(var0, var0 * 2, 88377012540497L);
   }

   private static DualPassBlurRenderer lambda$draw$2(int var0, Integer var1) {
      long var10001 = 46810738458114L ^ 135180222179923L;
      return new DualPassBlurRenderer(var0, var0 * 2, 88377012540497L);
   }

   private static DualPassBlurRenderer lambda$draw$1(int var0, Integer var1) {
      long var10001 = 50270625964408L ^ 138368457241897L;
      return new DualPassBlurRenderer(var0, var0 * 2, 88377012540497L);
   }

   private static DualPassBlurRenderer lambda$draw$0(int var0, Integer var1) {
      long var10001 = 35772394109052L ^ 124141879929901L;
      return new DualPassBlurRenderer(var0, var0 * 2, 88377012540497L);
   }

   static {

      {

      long var10001 = 136308517271160L ^ 111666888388875L;
      var10001 = 136308517271160L ^ 119666808138094L;
      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(136308517271160L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[5];
      String var15 = "Ëày«Òk\u0098Û(è^\u007fÜ¾Â\u0096]\u0085\u009bêÓZ\u0004\r\u0018\u0097\u009b¥|~=ô¸¿^÷¥ü\u000e½Ú4S\u008bÇ©\u00aduä8\u0016\n³æ\u008cçôÉ1r\u008dªî\u0089I\u009b53H0Ð/ìä¯\u0094ïîæí¬\\\u009aå\"òsÓö¸\u009e?G!·ë'\u0013rÂ\u008dnËÀLW";
      int var17 = "Ëày«Òk\u0098Û(è^\u007fÜ¾Â\u0096]\u0085\u009bêÓZ\u0004\r\u0018\u0097\u009b¥|~=ô¸¿^÷¥ü\u000e½Ú4S\u008bÇ©\u00aduä8\u0016\n³æ\u008cçôÉ1r\u008dªî\u0089I\u009b53H0Ð/ìä¯\u0094ïîæí¬\\\u009aå\"òsÓö¸\u009e?G!·ë'\u0013rÂ\u008dnËÀLW"
         .length();
      char var14 = 24;
      int var30 = -1;

      label54:
      while (true) {
         String var31 = var15.substring(++var30, var30 + var14);
         
            byte[] var19 = var11.doFinal(var31.getBytes("ISO-8859-1"));
            String var44 = a(var19).intern();
            switch (var36) {
               case 0:
                  var18[var16++] = var44;
                  if ((var30 += var14) >= var17) {
                     g = var18;
                     h = new String[5];
                     l = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(136308517271160L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "\u0084êìk):ÂK\u001e°\u008cfß(E:××(±lÃT\u000e7è\u0090\u0089ºz±\u0081\u0011\u001d\u0014\u008eë\u0007ut\fD¦5N\u001bÒÇ";
                     int var5 = "\u0084êìk):ÂK\u001e°\u008cfß(E:××(±lÃT\u000e7è\u0090\u0089ºz±\u0081\u0011\u001d\u0014\u008eë\u0007ut\fD¦5N\u001bÒÇ".length();
                     label36:
                     while (true) {
                        int var40 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var40, var2).getBytes("ISO-8859-1");
                        long[] var34 = var6;
                        int var41 = var3++;
                        long var48 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var48;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var55 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var51) {
                              case 0:
                                 var34[var41] = var55;
                                 if (var2 >= var5) {
                                    j = var6;
                                    k = new Integer[8];
                                    a = new BlurredRectangleRenderer(33499502823283L);
                                    Object[] var53 = new Object[]{null, 25489915207446L};
                                    var53[0] = 4;
                                    Object[] var26 = var53;
                                    b = NumberUtil.aReturningMap(var26);
                                    var53 = new Object[]{null, 25489915207446L};
                                    var53[0] = 4;
                                    Object[] var27 = var53;
                                    c = NumberUtil.aReturningMap(var27);
                                    break;
                                 }
                                 break;
                              default:
                                 var34[var41] = var55;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0012§\u00ad\u008f\u0081µ\u0080ñÆ\u0098ÚÓC\u001fPU";
                                 var5 = "\u0012§\u00ad\u008f\u0081µ\u0080ñÆ\u0098ÚÓC\u001fPU".length();
                                 var2 = 0;
                           }

                           int var42 = var2;
                           var2 += 8;
                           var7 = var4.substring(var42, var2).getBytes("ISO-8859-1");
                           var34 = var6;
                           var41 = var3++;
                           var48 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var51 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var30);
                  break;
               default:
                  var18[var16++] = var44;
                  if ((var30 += var14) < var17) {
                     var14 = var15.charAt(var30);
                     continue label54;
                  }

                  var15 = "\u001b\u0090\u0004òÝ¥\u009ac¹hk¤ñöZZO?õ\u0001QÃAóâú5\u0017\u0019\\ùü\u001få;·\fl\u007fLÉÃLGË·\u0003\u009d\u00ad$§¾\u001b¶í\u001d Á\u0093J¦\u0010\rÕ.Ì[a\u008e1 ¬:\u0081j\u00ad#\u0007\u000f\u0091mø\u0007\u0088³7ðµ\u0085";
                  var17 = "\u001b\u0090\u0004òÝ¥\u009ac¹hk¤ñöZZO?õ\u0001QÃAóâú5\u0017\u0019\\ùü\u001få;·\fl\u007fLÉÃLGË·\u0003\u009d\u00ad$§¾\u001b¶í\u001d Á\u0093J¦\u0010\rÕ.Ì[a\u008e1 ¬:\u0081j\u00ad#\u0007\u000f\u0091mø\u0007\u0088³7ðµ\u0085"
                     .length();
                  var14 = '8';
                  var30 = -1;
            }

            var31 = var15.substring(++var30, var30 + var14);
            var36 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 12049;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/c9", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = g[var5].getBytes("ISO-8859-1");
         h[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c9",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 28777;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/c9", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c9",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 2;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 39;
            yield var18;
         }
         case 4 -> {
            byte var19 = 28;
            yield var19;
         }
         case 5 -> {
            byte var20 = 12;
            yield var20;
         }
         case 6 -> {
            byte var21 = 51;
            yield var21;
         }
         case 7 -> {
            byte var22 = 15;
            yield var22;
         }
         case 8 -> {
            byte var23 = 22;
            yield var23;
         }
         case 9 -> {
            byte var24 = 25;
            yield var24;
         }
         case 10 -> {
            byte var25 = 23;
            yield var25;
         }
         case 11 -> {
            byte var26 = 52;
            yield var26;
         }
         case 12 -> {
            byte var27 = 16;
            yield var27;
         }
         case 13 -> {
            byte var28 = 26;
            yield var28;
         }
         case 14 -> {
            byte var29 = 20;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 43;
            yield var31;
         }
         case 17 -> {
            byte var32 = 44;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 27;
            yield var34;
         }
         case 20 -> {
            byte var35 = 18;
            yield var35;
         }
         case 21 -> {
            byte var36 = 63;
            yield var36;
         }
         case 22 -> {
            byte var37 = 10;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 59;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 32;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 62;
            yield var43;
         }
         case 29 -> {
            byte var44 = 55;
            yield var44;
         }
         case 30 -> {
            byte var45 = 56;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 9;
            yield var47;
         }
         case 33 -> {
            byte var48 = 7;
            yield var48;
         }
         case 34 -> {
            byte var49 = 1;
            yield var49;
         }
         case 35 -> {
            byte var50 = 4;
            yield var50;
         }
         case 36 -> {
            byte var51 = 42;
            yield var51;
         }
         case 37 -> {
            byte var52 = 11;
            yield var52;
         }
         case 38 -> {
            byte var53 = 34;
            yield var53;
         }
         case 39 -> {
            byte var54 = 36;
            yield var54;
         }
         case 40 -> {
            byte var55 = 38;
            yield var55;
         }
         case 41 -> {
            byte var56 = 50;
            yield var56;
         }
         case 42 -> {
            byte var57 = 13;
            yield var57;
         }
         case 43 -> {
            byte var58 = 57;
            yield var58;
         }
         case 44 -> {
            byte var59 = 53;
            yield var59;
         }
         case 45 -> {
            byte var60 = 33;
            yield var60;
         }
         case 46 -> {
            byte var61 = 31;
            yield var61;
         }
         case 47 -> {
            byte var62 = 40;
            yield var62;
         }
         case 48 -> {
            byte var63 = 58;
            yield var63;
         }
         case 49 -> {
            byte var64 = 35;
            yield var64;
         }
         case 50 -> {
            byte var65 = 5;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 8;
            yield var67;
         }
         case 53 -> {
            byte var68 = 19;
            yield var68;
         }
         case 54 -> {
            byte var69 = 21;
            yield var69;
         }
         case 55 -> {
            byte var70 = 61;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 6;
            yield var72;
         }
         case 58 -> {
            byte var73 = 3;
            yield var73;
         }
         case 59 -> {
            byte var74 = 47;
            yield var74;
         }
         case 60 -> {
            byte var75 = 17;
            yield var75;
         }
         case 61 -> {
            byte var76 = 29;
            yield var76;
         }
         case 62 -> {
            byte var77 = 14;
            yield var77;
         }
         default -> 49;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      m[0] = "{J\u0003w_)pE\u001288+eN\u0012s\u0003";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = "\u0005;z\u0011*q\u001b3`^Ie\u001f";
      m[3] = "L~'z6]Gq65WSLz2o";
      m[4] = ">\f\u0013P1{ \u0004\t\u001fy{:\u000e\u0011Xp`z+\u0010_|z=\u0002\u000b";
      m[5] = "\u0007\u0004SN n\u0011\u0004V\u00143y\u0006OU\u0012?m\u0017\bB\u0005t}Z";
      m[6] = "LG^)\u0001s9gU&\u0010<Xi^-\u0014f,";
      m[7] = void.class;
      n[7] = "java/lang/Void";
      m[8] = "*BEet\u0013<B@?g\u0004+\tC9k\u0010:NT. \u0000\r";
      m[9] = "YO7O\nk,o<@\u001b$Ma7K\u001f~9";
      m[10] = "f*Uv^3\u0013\n^yO|r\u0004UrK&\u0006";
      m[11] = "SRi>L\u0003&rb1]LG|i:Y\u00163";
      m[12] = "\u0000@\u0006\u0003\u0015\u0003\u000bO\u0017L}\u0003\u0005@\u0004";
      m[13] = float.class;
      n[13] = "java/lang/Float";
      m[14] = "e\u001d\te\u0017\u0003\u0010=\u0002j\u0006Lq3\ta\u0002\u0016\u0005";
      m[15] = "\u0002H\u001d:!\u000bwh\u001650D\u0016f\u001d>4\u001eb";
      m[16] = "\u0010)\u0007\u000e\b\u001c\u0006)\u0002T\u001b\u000b\u0011b\u0001R\u0017\u001f\u0000%\u0016E\\\nA";
      m[17] = "0\u0015m s+E5f/bd$;m$f>P";
      m[18] = "7*5bg.!*08t96a3>x-'&$)38g";
      m[19] = "\u000eF\fD=\u0002{f\u0007K,M\u001ah\f@(\u0017n";
      m[20] = "\u0019R\u00185\u001d%\u000fR\u001do\u000e2\u0018\u0019\u001ei\u0002&\t^\t~I1\u000b";
      m[21] = "_t\t__3*T\u0002PN|KZ\t[J&?";
      m[22] = "VKL-\u0014<#kG\"\u0005sBeL)\u0001)6";
      m[23] = "\u001b\u0002l%We\r\u0002i\u007fDr\u001aIjyHf\u000b\u000e}n\u0003q\u0011";
      m[24] = "xjl3qVnjiibAy!jonUhf}x%@L";
      m[25] = "l$VJLu\u0019\u0004]E]:x\nVNY`\f";
      m[26] = "p(/33tf(*i cqc)o,w`$>xgcP";
      m[27] = "v\u001a,qf\n`\u001a)+u\u001dwQ*-y\tf\u0016=:2\u0019*";
      m[28] = "0&h\t3`E\u0006c\u0006\"/$\bh\r&uP";
      m[29] = "N$Lz|\"X$I o5OoJ&c!^(]1(4g";
      m[30] = "N8\u0014$(nX8\u0011~;yOs\u0012x7m^4\u0005o|\u007fo";
      m[31] = " \u0002'2DDU\",=U\u000b4,'6QQ@";
      m[32] = "Eh\u0012umC0H\u0019z|\fQF\u0012qxV%";
      m[33] = "|.\u001dp<<\t\u000e\u0016\u007f-sh\u0000\u001dt))\u001c";
      m[34] = "P\u001ca\u0018\u0003kF\u001cdB\u0010|QWgD\u001ch@\u0010pSW|r";
      m[35] = "</Kv\u0012@I\u000f@y\u0003\u000f(\u0001Kr\u0007U\\";
      m[36] = "-A#,;[/_jT4W6\\667";
      m[37] = "Nc\u0013\u000f^o;C\u0018\u0000O ZM\u0013\u000bKz.";
      m[38] = "7)S g?!)Vzt(6bU|x<'%Bk3(\u001a";
      m[39] = "3\u001cz:l]F<q5}\u0012'2z>yHS";
      m[40] = "m\\>C\u0017!{\\;\u0019\u00046l\u00178\u001f\b\"}P/\bC6A";
      m[41] = "L^R~g\u0019GQC1\u0004\u0014R\\LZ1\u0016COPv&\u001b";
      m[42] = "`8\byj$\u0015\u0018\u0003v{kt\u0016\b}\u007f1\u0000";
      m[43] = ".\u001c\u0016x\u000f\u001d[<\u001dw\u001eR:2\u0016|\u001a\bN";
      m[44] = "\u000fQ=?k0\nD6?h7\u0005M=})\u0000,\u0011j";
      m[45] = "<50u6E*55/%R=~6))F,9!>bT5";
      m[46] = "\u0017J**\f\u0004bj!%\u001dK\u0003d*.\u0019\u0011w";
      m[47] = "r\u001d\u000bJ\u0011Q\u0007=\u0000E\u0000\u001ef3\u000bN\u0004D\u0012";
      m[48] = "t=9\u000b\u007fOq(2\u000b|H~!9I=\u007fW~o";
      m[49] = "<7K\t?;9\"@\t<<6+KK}\u000b\u001ft\u001f";
      m[50] = "\u001aXo\u001c\u000e.\fXjF\u001d9\u001b\u0013i@\u0011-\nT~WZ:\u0014";
      m[51] = "\u0010\u001d7\u00125xe=<\u001d$7\u000437\u0016 mp";
      m[52] = long.class;
      n[52] = "java/lang/Long";
      m[53] = "?X\u001aH;=Jx\u0011G*r+v\u001aL.(_";
      m[54] = "(\u00130~&\r%N~yJ\u001eD\u00166q)K:Cq,(ED\u00127xu\u0004-Qtg/t";
      m[55] = ",E\u0013@0\u001f\"\u0006\u0013\u0017\u0000\u0018C\u000eSGcN=[\u0014\u001ab@CV\rM{\f;LVUoq";
      m[56] = "b\b,qHT.Rps)P_RtoJ\u000e!\u000732K\u0000_V.b[P:\u001at>Y1";
      m[57] = "\u007fNsA|\u0010?S\u007fY\u001b@D\u0010:Mx\u0016:E}\u0010y\u0018DFaY&Q#\u0012x\u0011 )";
      m[58] = "Aoh\u0018\u000b)Uim\u00045*?.?\nV\u007fA{xWWq?h:\u0000Y&Cwe\u00145";
      m[59] = "}c&\u000fRr19z\r3t@9~\u0011P(>l9LQ&@=$\u001cAv%q~@C\u0017";
      m[60] = "k\u0003)!SX-\u001e;\"=\u000fr\"4.S\u0007l\u001an!=\u001f*\u0019>)A\u0000u\rR~Q\u001bnG/vS^*\u007fc#F\u0018.\u0002k!\u0003\\\u0016N>4EXkF<q\u0001`'\u0013)7\u0005\u001d/\u0011ls=].\u001am?T\u001em\u00057O";
      m[61] = "\u001ejR\u000e }\u0006iW\u0019]{z|\b\u00191v\u0006cW\r]";
      m[62] = "TVja/\nSOqk\u001e\u0006,\u0007a\u007ffNQ\u000fc:\"";
      m[63] = "\u0004jI0i;\n)IgY<k!\t7:j\u0015tNj;dkwB\"2e\u0005y\u0001\"eU";
      m[64] = "S7=|u|\u00126yp\u001a+\u00073\u0004%*/\u0000rfx~?\u0004O>/q.W-c{a*j";
      m[65] = "\u000f6L)y`\u0001uL~Ig`}\f.*1\u001e(Ks+?`>\r8si\u0011+Kzv\u000e";
      m[66] = "P\u0010cI\u0017\\Y\u0017{Uv\u000f:O8@\u0015YD\u001a\u007f\u001d\u0014W:Oy\u0015\u0015\t\u0002\u000exQ\u0019f";
      m[67] = "4J[#)htWW;N>\u000f\u0014\u0012/-nqAUr,`\u000f\u0010\u0013&q!fSP9+Q";
      m[68] = "\u000fRzM,LC\b&OMC2\b\"S.\u0016L]e\u000e/\u00182\fx^?HW@\"\u0002=)";
      m[69] = "\u001d\f;o|\u001c\r\u0015;`\u0003\u001flS3~`I\u0012\u0006t#aGlS2uh\f\u0013\u0003v{aJl";
      m[70] = "\\}\u000eAH$H{\u000b]v'\"<YS\u0015r\\i\u001e\u000e\u0014|\"8XZI=K{\u001bE\u0013M";
      m[71] = "\u0011\f-Q,x\u001fO-\u0006\u001c\u007f~GmV\u007f)\u0000\u0012*\u000b~'~\u0005d@~*G@hFp\u0016";
      m[72] = "VD\u0018(?\u001a\u0016Y\u00140XJmX\u0006/?^\u000bJ\f'7#\u0016M\u000f/%E\u0004G\u0007'X";
      m[73] = "\ngLLZB\u0004y/VO^GjhF&E\u0006aCNZZYu/\u0018FY^{W\u0016X:";
      m[74] = "icKv7:/~YuYmpBVy7enz\nvY}(y\\~%bwm0)5yl'M!7<(\u001f\u0001t\"z,b\tvg>\u0014\"\b}fr}aKb<\u0002";
      m[75] = "zE;-4X}\\ '\u0005[\u0002\u001403}\u001c\u007f\u001c2v9";
      m[76] = "@1?uJ}Thbu8~-7ek[(Sb\"6Z&-b`8[{To=v\\\u0017";
      m[77] = "R.)d\u001f4\u0013/mhpg\f3hz\fa*8Ym\u000ba\r*\u0010=@g\u0001kr`\u0014w\u0005V+>Ow\u0014o.kNtkl l\u001a1\t1t|\u001e\f";
      m[78] = "\\\u0004\u0011;~\u0015\u0001\u0018Jb\u0000\u0018=B\u0011kcNC\u0017V6b@=\u0018Qj1\t\r\u0002Pj:q";
      m[79] = "\f\bnq\u001f\u001a\u0018\u000ekm!\u001arI9cBL\f\u001c~>CBr\u000f<iM\u0015\u000e\u0010c}!";
      m[80] = "\"|:\u000e2t0hc\r\u000bp6Yd\fgC?cy\u0017qrRl9\fgy.sf\u0018\u000b`nui\fw\u007f1a\u0005W3zmcl\u0014pe7\u0013";
      m[81] = "\u0003F&5uK\r\u0005&bEOl\rf2&\u001a\u0012X!o'\u0014l[-'.\u0015\u0002Un'y%";
      m[82] = "Fwt?v7\n-(=\u00172{-,!tm\u0005xk|uc{)v,e3\u001ee,pgR";
      m[83] = "N/_\u000fWT@l_XgS!d\u001f\b\u0004\u0005_1XU\u0005\u000b!;]\u0002V^O/\u0019Z\u001a:";
      m[84] = "\u001eD\u0018jDRV\u0010\r2'\r\u000b0\u000bpF\u001c\u0002%\r|[\u001f\u0015\u0014`s\u001b\u0004\u0003\u001f\u001clD\u0010oDXi\u0018\u0012\u0006\u0007\u001bvBb";
      m[85] = "H 6\r%VA'.\u0011D\u0005\"\u007fm\u0004'S\\**Y&]\">4\u000f!]^9-\u0014+l";
      m[86] = "N,\u0003\u00143^\u00056\u000fSMB\u001a(\tU\u0013E\u001a2\r)|@\u00057XTtB@s`";
      m[87] = "g\u0004]\u0013`*`\u001dF\u0019Q$\u001fUV\r)nb]THm";
      m[88] = "P>\u0001Q\u0016KJ?\u0001Zn\u00173~U\f\rDM+\u0012Q\fJ38P\u0006\u0002\u001dO'\u000f\u0012n";
      m[89] = "\u0007,\u0010\u0006\u001a\u000f\u00005\u000b\f+\u0002\u007f}\u001b\u0018SK\u0002u\u0019]\u0017";
      m[90] = ">]\u0000.Z_\u007f\\D\"5\u001fzY9w\u0005\fm\u0018[*Q\u001ci%\u0003}^\r:G^)N\t\u0007\u001f\t&_ZeB]6[g";
      m[91] = "_lTE@R\u00136\bG![b6\f[B\b\u001ccK\u0006C\u0006b2VVSV\u0007~\f\nQ7";
      m[92] = "Oh\u000b\u0006\u007f{Ui\u000b\r\u0007\",(_[dtR}\u0018\u0006ez,,^R8;Eo\u001dMbK";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(226653442562895L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(226653442562895L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(226653442562895L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 80;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 72;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 71;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 111;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 84;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 235;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 80;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 72;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 71;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c9",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c9" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Integer invokeBinding1(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(MethodHandles.lookup(), "ë", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding2(int var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$draw$0", "(ILjava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Object invokeBinding3(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache3;
         MethodHandle var10 = bindingCache3;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache3 = c(
                  MethodHandles.lookup(),
                  "T",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static void invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = c(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Integer invokeBinding5(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "ë", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding6(int var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$draw$1", "(ILjava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Object invokeBinding7(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache7;
         MethodHandle var10 = bindingCache7;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache7 = c(
                  MethodHandles.lookup(),
                  "T",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static void invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = c(MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Integer invokeBinding9(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = c(MethodHandles.lookup(), "ë", SourceSupport.methodType("(IJJ)Ljava/lang/Integer;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Integer)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding10(int var0) {
         MethodHandle var5 = bindingCache10;
         MethodHandle var4 = bindingCache10;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$draw$2", "(ILjava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Object invokeBinding11(Object var0, Object var1, Object var2, long var3, long var5) {
         MethodHandle var11 = bindingCache11;
         MethodHandle var10 = bindingCache11;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache11 = c(
                  MethodHandles.lookup(),
                  "T",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var8.invokeExact((Object)var0, (Object)var1, (Object)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static void invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = c(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Function invokeBinding13(int var0) {
         MethodHandle var5 = bindingCache13;
         MethodHandle var4 = bindingCache13;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache13 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$draw$3", "(ILjava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Function invokeBinding14(int var0) {
         MethodHandle var5 = bindingCache14;
         MethodHandle var4 = bindingCache14;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache14 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$draw$4", "(ILjava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/am_C0028;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static void invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = c(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiConsumer invokeBinding16(Matrix4f var0, float var1, float var2, float var3, float var4) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Lorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/c9",
                     "lambda$drawInternal$5",
                     "(Lorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var6.invokeExact((Matrix4f)var0, (float)var1, (float)var2, (float)var3, (float)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding17() {
         MethodHandle var4 = bindingCache17;
         MethodHandle var3 = bindingCache17;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache17 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/c9", "lambda$getRenderLayer$6", "(Ldev/zprestige/prestige/am_C0028;)Ljava/util/Map;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/am_C0028;)Ljava/util/Map;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding18(DualPassBlurRenderer var0) {
         MethodHandle var5 = bindingCache18;
         MethodHandle var4 = bindingCache18;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache18 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/am_C0028;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/c9",
                     "lambda$getRenderLayer$7",
                     "(Ldev/zprestige/prestige/am_C0028;Ldev/zprestige/prestige/du_C0204;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/du_C0204;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((DualPassBlurRenderer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Consumer invokeBinding19(BlurredRectangleRenderer var0, DualPassBlurRenderer var1, Vector4f var2) {
         MethodHandle var7 = bindingCache19;
         MethodHandle var6 = bindingCache19;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache19 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/c9;Ldev/zprestige/prestige/am_C0028;Lorg/joml/Vector4f;)Ljava/util/function/Consumer;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/c9",
                     "lambda$getRenderLayer$8",
                     "(Ldev/zprestige/prestige/am_C0028;Lorg/joml/Vector4f;Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var4.invokeExact((BlurredRectangleRenderer)var0, (DualPassBlurRenderer)var1, (Vector4f)var2);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }
}
