package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.NumberUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Vector4f;

public class ColorComponents {
   public final float a;
   public final float b;
   public final float c;
   public final float d;
   private static final long e = 22528305718922L;
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h = new HashMap(13);
   private static final Object[] i = new Object[19];
   private static final String[] j = new String[19];

   public ColorComponents(Vector4f var1, long var2) {
      super();
      var2 = 22528305718922L ^ var2;
      long var4 = var2 ^ 132055005372530L;

      Vector4f var6 = var1;
      float var10001 = var6.x;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var7 = var10004;
      this.a = NumberUtil.aReturningFloat(var7);
      Vector4f var8 = var1;
      var10001 = var8.y;
      var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var9 = var10004;
      this.b = NumberUtil.aReturningFloat(var9);
      Vector4f var10 = var1;
      var10001 = var10.z;
      var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var11 = var10004;
      this.c = NumberUtil.aReturningFloat(var11);
      Vector4f var12 = var1;
      var10001 = var12.w;
      var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var13 = var10004;
      this.d = NumberUtil.aReturningFloat(var13);
   }

   @Override
   public boolean equals(Object var1) {
      int var4 = Event.bReturningInt();
      int var37 = var4;
      ColorComponents var36 = this;
      Object var24 = var36;
      ColorComponents var23 = var36;
      if (var37 == 0) {
         Object var39 = var1;
         ColorComponents var38 = var23;
         if (var38 == var39) {
            return true;
         }

         var24 = var1;
      }

      int var10000 = (((var24 instanceof ColorComponents) ? 1 : 0));
      int var41 = var4;
      byte var40 = (byte)var10000;
      byte var26 = var40;
      byte var25 = var40;
      if (var41 == 0) {
         byte var42 = var25;
         if (var42 != 0) {
            ColorComponents var5 = (ColorComponents)var1;
            int var43 = var4;
            if (var43 == 0) {
               float var11 = this.a;
               float var10 = var5.a;
               var10000 = Float.compare(var10, var11);
               int var46 = var4;
               int var45 = var10000;
               int var28 = var45;
               int var27 = var45;
               if (var46 == 0) {
                  int var47 = var27;
                  if (var47 != 0) {
                     return false;
                  }

                  float var14 = this.b;
                  float var13 = var5.b;
                  int var48 = Float.compare(var13, var14);
                  var28 = var48;
               }

               int var50 = var4;
               int var49 = var28;
               int var30 = var49;
               int var29 = var49;
               if (var50 == 0) {
                  int var51 = var29;
                  if (var51 != 0) {
                     return false;
                  }

                  float var18 = this.c;
                  float var17 = var5.c;
                  int var52 = Float.compare(var17, var18);
                  var30 = var52;
               }

               int var54 = var4;
               int var53 = var30;
               int var32 = var53;
               int var31 = var53;
               if (var54 == 0) {
                  int var55 = var31;
                  if (var55 != 0) {
                     return false;
                  }

                  float var22 = this.d;
                  float var21 = var5.d;
                  int var56 = Float.compare(var21, var22);
                  var32 = var56;
               }

               int var58 = var4;
               int var57 = var32;
               int var34 = var57;
               int var33 = var57;
               if (var58 != 0) {
                  return dev.prestige.recovery.SourceSupport.asBoolean(var34);
               }

               int var59 = var33;
               if (var59 == 0) {
                  byte var62 = 1;
                  return dev.prestige.recovery.SourceSupport.asBoolean(var62);
               }

               return false;
            }
         }

         byte var44 = 0;
         var26 = var44;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var26);
   }

   @Override
   public int hashCode() {
      float var4 = this.a;
      int var3 = Float.floatToIntBits(var4);
      int var10000 = 31 * var3;
      float var5 = this.b;
      var3 = var10000 + Float.floatToIntBits(var5);
      var10000 = 31 * var3;
      float var6 = this.c;
      var3 = var10000 + Float.floatToIntBits(var6);
      var10000 = 31 * var3;
      float var7 = this.d;
      return var10000 + Float.floatToIntBits(var7);
   }

   static {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(60176559505538L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[2];
      String var6 = "¾9ÌØcy°\u0007Cê\u001eÁäà\u0012\r";
      int var7 = "¾9ÌØcy°\u0007Cê\u001eÁäà\u0012\r".length();
      do {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         var10001 = var5++;
         long var10 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         byte[] var12 = var2.doFinal(
            new byte[]{
               (byte)(var10 >>> 56),
               (byte)(var10 >>> 48),
               (byte)(var10 >>> 40),
               (byte)(var10 >>> 32),
               (byte)(var10 >>> 24),
               (byte)(var10 >>> 16),
               (byte)(var10 >>> 8),
               (byte)var10
            }
         );
         long var10004 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // var8[var10001] = var10004;
      } while (var4 < var7);

      f = var8;
      g = new Integer[2];
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6673;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dr", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dr_C0198",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 19;
            yield var15;
         }
         case 1 -> {
            byte var16 = 27;
            yield var16;
         }
         case 2 -> {
            byte var17 = 56;
            yield var17;
         }
         case 3 -> {
            byte var18 = 57;
            yield var18;
         }
         case 4 -> {
            byte var19 = 23;
            yield var19;
         }
         case 5 -> {
            byte var20 = 36;
            yield var20;
         }
         case 6 -> {
            byte var21 = 53;
            yield var21;
         }
         case 7 -> {
            byte var22 = 30;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 15;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 47;
            yield var26;
         }
         case 12 -> {
            byte var27 = 10;
            yield var27;
         }
         case 13 -> {
            byte var28 = 35;
            yield var28;
         }
         case 14 -> {
            byte var29 = 3;
            yield var29;
         }
         case 15 -> {
            byte var30 = 6;
            yield var30;
         }
         case 16 -> {
            byte var31 = 63;
            yield var31;
         }
         case 17 -> {
            byte var32 = 44;
            yield var32;
         }
         case 18 -> {
            byte var33 = 1;
            yield var33;
         }
         case 19 -> {
            byte var34 = 0;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 22;
            yield var36;
         }
         case 22 -> {
            byte var37 = 16;
            yield var37;
         }
         case 23 -> {
            byte var38 = 42;
            yield var38;
         }
         case 24 -> {
            byte var39 = 61;
            yield var39;
         }
         case 25 -> {
            byte var40 = 18;
            yield var40;
         }
         case 26 -> {
            byte var41 = 24;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 49;
            yield var43;
         }
         case 29 -> {
            byte var44 = 2;
            yield var44;
         }
         case 30 -> {
            byte var45 = 11;
            yield var45;
         }
         case 31 -> {
            byte var46 = 52;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 48;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 40;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 51;
            yield var52;
         }
         case 38 -> {
            byte var53 = 5;
            yield var53;
         }
         case 39 -> {
            byte var54 = 26;
            yield var54;
         }
         case 40 -> {
            byte var55 = 17;
            yield var55;
         }
         case 41 -> {
            byte var56 = 7;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 45;
            yield var58;
         }
         case 44 -> {
            byte var59 = 54;
            yield var59;
         }
         case 45 -> {
            byte var60 = 60;
            yield var60;
         }
         case 46 -> {
            byte var61 = 39;
            yield var61;
         }
         case 47 -> {
            byte var62 = 34;
            yield var62;
         }
         case 48 -> {
            byte var63 = 29;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 37;
            yield var65;
         }
         case 51 -> {
            byte var66 = 46;
            yield var66;
         }
         case 52 -> {
            byte var67 = 59;
            yield var67;
         }
         case 53 -> {
            byte var68 = 41;
            yield var68;
         }
         case 54 -> {
            byte var69 = 32;
            yield var69;
         }
         case 55 -> {
            byte var70 = 8;
            yield var70;
         }
         case 56 -> {
            byte var71 = 25;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 31;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 9;
            yield var75;
         }
         case 61 -> {
            byte var76 = 13;
            yield var76;
         }
         case 62 -> {
            byte var77 = 58;
            yield var77;
         }
         default -> 28;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "1\n\u001bta`:\u0005\n;\t`4\n\u0019";
      i[1] = float.class;
      j[1] = "java/lang/Float";
      i[2] = int.class;
      j[2] = "java/lang/Integer";
      i[3] = "a6,]Idc(e%Fhz+9GE";
      i[4] = "\u0013w`KrZ\u0005we\u0011aM\u0012<f\u0017mY\u0003{q\u0000&LB";
      i[5] = "e\u0014\u0016\u000fw\u0010\u00104\u001d\u0000f_q:\u0016\u000bb\u0005\u0005";
      i[6] = "\u00037*@@W\u00157/\u001aS@\u0002|,\u001c_T\u0013;;\u000b\u0014F\"";
      i[7] = "0\u000b\u007f\u00172\u0002&\u000bzM!\u00151@yK-\u0001 \u0007n\\f\u0016&";
      i[8] = "}/wgJ\u0002v f()\u000fc-iC\u001c\rr>uo\u000b\u0000";
      i[9] = "mIK\u000fu\u001cfFZ@\u0014\u0012mM^\u001a";
      i[10] = " \fB\u0000mAvS^\u0006\u0000Z\u001b\u0007Y\u0001xK'NWU13\"\u0001ZR<HrPU_\u0000";
      i[11] = "\"\u0015fFQ<q\u001caC0*\u0018B J^ic\u0012qES";
      i[12] = "N\u007f,\u0000Nj\u001en.\\1or)&\u0006\bh\u0003|~_A\u0005";
      i[13] = "\u0015u\b5MSF|\u000f0,H/\"N9B\u0006Tr\u001f6O";
      i[14] = "3\u0010?\u0003[C<\u001a38L\u001c=\u0004'BJ{aA(V\u001b\u00001\u0010'['Be\u001a \u0004\\\u00124\u0015-8\u001e\u001aaE#IKB8\fN";
      i[15] = "\u0006hlMcE\tb`vq\u0019\nma*x<\u000bxW\u0017c\u0006m= \u0010qA\u0016mq\u001f|}Te$Or\f\u0001=}\u0006\u001f";
      i[16] = "J-\u0004fbA\u0010$\ne_Qw|^~aQK{W>b8J%C96\u0004M,\u0003:_";
      i[17] = "\u0011Pd\u001d,\u0010BYc\u0018M\b+\u0007\"\u0011#EPWs\u001e.";
      i[18] = "H\fYrnO\u001b\u0005^w\u000fVr[\u001f~a\u001a\t\u000bNql";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(678381672839560L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(678381672839560L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(678381672839560L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 249;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 255;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 218;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 210;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 109;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 238;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 249;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 255;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 218;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dr_C0198",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dr" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
