package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class DrawPipeline {
   public VertexFormat a;
   public int b;
   public boolean c;
   public RenderState[] d;
   public static final boolean e;
   private static final long f = 10063025717903L;
   private static final String[] g;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final Object[] j = new Object[39];
   private static final String[] k = new String[39];
   private static volatile MethodHandle bindingCache1;

   public DrawPipeline(VertexFormat var1, int var2, boolean var3, RenderState[] var4, long var5) {
      super();
      var5 = 10063025717903L ^ var5;
      long var7 = var5 ^ 15652733121663L;

      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      boolean var10 = e;
      if (!var10) {
         Object[] var9 = new Object[]{var4, var7};
         boolean var11 = aReturningBoolean(var9);
         if (!var11) {
            short var10002 = 27704;
            long var10003 = 6383599061864399254L ^ var5;
            throw new AssertionError("duplicate states that shouldnt be duplicated!");
         }
      }
   }

   public int aReturningInt(Object[] var1) {
      return this.b;
   }

   public RenderState[] aReturningArrayOffP_C0301(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 10063025717903L ^ var2;
      RenderState[] var4 = new RenderState[this.d.length];
      invokeBinding1(this.d, 0, var4, 0, var4.length, 2563972129697942641L, var2);
      return var4;
   }

   private static boolean aReturningBoolean(Object[] var0) {
      RenderState[] var1 = (RenderState[])var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 10063025717903L ^ var2;
      HashSet var4 = new HashSet(var1.length);
      RenderState[] var5 = var1;
      int var6 = var5.length;
      while (true) {
         int var13 = var6;
         int var12 = var7;
         if (var12 >= var13) {
            return true;
         }

         RenderState var8 = var5[var7];
         RenderState var9 = var8;
         boolean var14 = var9.aReturningBoolean();
         if (!var14) {
            Class var11 = var8.getClass();
            HashSet var10 = var4;
            boolean var15 = var10.add(var11);
            if (!var15) {
               return false;
            }
         }

         var7++;
      }
   }

   public void aReturningVoid(Object[] var1) {
      ManagedGlBuffer var2;
      RenderContext var5;
      MeshDrawRange var6;
      GlVertexArray var7;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      int var18;
      label51: {
         var5 = (RenderContext)var1[0];
         var7 = (GlVertexArray)var1[1];
         var2 = (ManagedGlBuffer)var1[2];
         var6 = (MeshDrawRange)var1[3];
         long var3 = (Long)var1[4];
         var3 = 10063025717903L ^ var3;
         var8 = var3 ^ 137406729001470L;
         var10 = var3 ^ 118250725304614L;
         var12 = var3 ^ 79959165462850L;
         var14 = var3 ^ 69824738013648L;
         var16 = var3 ^ 55343299017456L;
         var18 = Event.cReturningInt();
         int var50 = var18;
         boolean var49 = e;
         boolean var48 = var49;
         boolean var47 = var49;
         if (var50 != 0) {
            boolean var51 = var47;
            if (var51) {
               break label51;
            }

            MeshDrawRange var26 = var6;
            VertexFormat var10000 = var26.a2();
            VertexFormat var28 = this.a;
            VertexFormat var27 = var10000;
            boolean var52 = var27.equals(var28);
            var48 = var52;
         }

         boolean var53 = var48;
         if (!var53) {
            short var10002 = 25831;
            long var10003 = 3477157551310395635L ^ var3;
            throw new AssertionError("format mismatch!");
         }
      }

      Object[] var31 = new Object[]{var10};
      RenderPassBuilder var19 = RenderPass.aReturningdu_C0204(var31);
      RenderState[] var20 = this.d;
      int var21 = var20.length;
      int var56;
      do {
         int var55 = var21;
         int var54 = var22;
         if (var54 >= var55) {
            break;
         }

         RenderState var23 = var20[var22];
         RenderPassBuilder var33 = var19;
         RenderState var32 = var23;
         var32.aReturningVoid(var33);
         var22++;
         var56 = var18;
      } while (var56 != 0);

      Object[] var35 = new Object[]{var12};
      RenderPassBuilder var34 = var19;
      RenderPass var65 = var34.aReturningRenderPass(var35);
      Object[] var37 = new Object[]{var8};
      RenderPass var36 = var65;
      var36.aReturningVoid(var37);
      Object[] var39 = new Object[]{var5, var14};
      RenderPass var38 = var65;
      var38.bReturningVoid(var39);
      RenderState[] var66 = this.d;
      var22 = var66.length;
      while (true) {
         int var58 = var22;
         int var57 = var68;
         if (var57 < var58) {
            RenderState var24 = var66[var68];
            RenderPass var41 = var65;
            RenderState var40 = var24;
            var40.aReturningVoid(var41);
            var68++;
            int var59 = var18;
            if (var59 == 0) {
               break;
            }

            int var60 = var18;
            if (var60 != 0) {
               continue;
            }
         }

         int var71 = this.b;
         MeshDrawRange var43 = var6;
         int var10004 = var43.a4();
         Object[] var10007 = new Object[]{null, null, null, null, var16};
         var10007[3] = var10004;
         var10007[2] = var71;
         var10007[1] = var2;
         var10007[0] = var7;
         Object[] var45 = var10007;
         RenderPass var44 = var65;
         var44.dReturningVoid(var45);
         var66 = this.d;
         var22 = var66.length;
         break;
      }

      var68 = 0;

      int var63;
      do {
         int var62 = var22;
         int var61 = var68;
         if (var61 >= var62) {
            break;
         }

         RenderState var70 = var66[var68];
         RenderState var46 = var70;
         var46.aReturningVoid();
         var68++;
         var63 = var18;
      } while (var63 != 0);
   }

   public boolean bReturningBoolean(Object[] var1) {
      return this.c;
   }

   public VertexFormat aReturningf8(Object[] var1) {
      return this.a;
   }

   static {

      {

      aReturningVoid();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(112248897475031L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var7 = new String[2];
      String var4 = "<\u00ad|\u0088GHw¢¥ñ\u0017M\u0082\u000e\u009du\u0084\u0082ÿ>ûD<>Y\u007fYÖÔy/=\u0099ú-\u001cGïNÕHÂw\u009d²\u009cø\u0088w}&IPÿq¿\u001d¬Õ¢ø¿¹q;\u0097È¿Û\bPd\u001e[f\u00adÁòÎQ\u0088¨\u0080'üú4¨Æf\u001a\u008dÞ¬^¿øh¶\u009f{\u0010Ý\u0017ÑÀ+°£¥\u0081\t\u008b";
      int var6 = "<\u00ad|\u0088GHw¢¥ñ\u0017M\u0082\u000e\u009du\u0084\u0082ÿ>ûD<>Y\u007fYÖÔy/=\u0099ú-\u001cGïNÕHÂw\u009d²\u009cø\u0088w}&IPÿq¿\u001d¬Õ¢ø¿¹q;\u0097È¿Û\bPd\u001e[f\u00adÁòÎQ\u0088¨\u0080'üú4¨Æf\u001a\u008dÞ¬^¿øh¶\u009f{\u0010Ý\u0017ÑÀ+°£¥\u0081\t\u008b"
         .length();
      char var3 = '(';
      int var2 = -1;

      while (true) {
         byte[] var8 = var0.doFinal(var4.substring(++var2, var2 + var3).getBytes("ISO-8859-1"));
         String var14 = a(var8).intern();
         // var7[var5++] = var14;
         if ((var2 += var3) >= var6) {
            g = var7;
            h = new String[2];
            Class<DrawPipeline> var11 = DrawPipeline.class;
            e = dev.prestige.recovery.SourceSupport.asBoolean((!var11.desiredAssertionStatus() ? 1 : 0));
            break;
         }

         var3 = var4.charAt(var2);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32064;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dn", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = g[var5].getBytes("ISO-8859-1");
         h[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dn_C0192",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dn" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = k[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = j[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 55;
            yield var15;
         }
         case 1 -> {
            byte var16 = 54;
            yield var16;
         }
         case 2 -> {
            byte var17 = 7;
            yield var17;
         }
         case 3 -> {
            byte var18 = 25;
            yield var18;
         }
         case 4 -> {
            byte var19 = 23;
            yield var19;
         }
         case 5 -> {
            byte var20 = 51;
            yield var20;
         }
         case 6 -> {
            byte var21 = 57;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 18;
            yield var23;
         }
         case 9 -> {
            byte var24 = 22;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 63;
            yield var26;
         }
         case 12 -> {
            byte var27 = 9;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 27;
            yield var29;
         }
         case 15 -> {
            byte var30 = 60;
            yield var30;
         }
         case 16 -> {
            byte var31 = 35;
            yield var31;
         }
         case 17 -> {
            byte var32 = 16;
            yield var32;
         }
         case 18 -> {
            byte var33 = 31;
            yield var33;
         }
         case 19 -> {
            byte var34 = 46;
            yield var34;
         }
         case 20 -> {
            byte var35 = 20;
            yield var35;
         }
         case 21 -> {
            byte var36 = 50;
            yield var36;
         }
         case 22 -> {
            byte var37 = 52;
            yield var37;
         }
         case 23 -> {
            byte var38 = 11;
            yield var38;
         }
         case 24 -> {
            byte var39 = 19;
            yield var39;
         }
         case 25 -> {
            byte var40 = 5;
            yield var40;
         }
         case 26 -> {
            byte var41 = 10;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 38;
            yield var45;
         }
         case 31 -> {
            byte var46 = 30;
            yield var46;
         }
         case 32 -> {
            byte var47 = 59;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 15;
            yield var49;
         }
         case 35 -> {
            byte var50 = 61;
            yield var50;
         }
         case 36 -> {
            byte var51 = 40;
            yield var51;
         }
         case 37 -> {
            byte var52 = 33;
            yield var52;
         }
         case 38 -> {
            byte var53 = 58;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 47;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 2;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 53;
            yield var59;
         }
         case 45 -> {
            byte var60 = 42;
            yield var60;
         }
         case 46 -> {
            byte var61 = 13;
            yield var61;
         }
         case 47 -> {
            byte var62 = 14;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 1;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 44;
            yield var66;
         }
         case 52 -> {
            byte var67 = 12;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 3;
            yield var69;
         }
         case 55 -> {
            byte var70 = 8;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 17;
            yield var72;
         }
         case 58 -> {
            byte var73 = 4;
            yield var73;
         }
         case 59 -> {
            byte var74 = 43;
            yield var74;
         }
         case 60 -> {
            byte var75 = 39;
            yield var75;
         }
         case 61 -> {
            byte var76 = 36;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 28;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            k[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      j[0] = "U6+\u00006EC6.Z%RT}-\\)FE::KbQ_";
      j[1] = "Q($yu\u0011$\b/vd^E\u0006$}`\u00041";
      j[2] = boolean.class;
      k[2] = "java/lang/Boolean";
      j[3] = "[83=+\u0000P7\"rH\rE:-\u0019}\u000fT)15j\u0002";
      j[4] = "\u001alhF0Y\u0011cy\t]Y\u0011~m";
      j[5] = "M\u0005g=-5F\nvrP T\u0010t1";
      j[6] = "\u001dOJ\u001a[\u0003\u0016@[U:\r\u001dK_\u000f";
      j[7] = int.class;
      k[7] = "java/lang/Integer";
      j[8] = void.class;
      k[8] = "java/lang/Void";
      j[9] = "\u0004}|\rH|\u0012}yW[k\u00056zQW\u007f\u0014qmF\u001cj0";
      j[10] = "\u000bF\u0004\u0019ZX\u001dF\u0001CIO\n\r\u0002EE[\u001bJ\u0015R\u000eL\u001a";
      j[11] = "Nnq$\u0010cXnt~\u0003tO%wx\u000f`^b`oDw^";
      j[12] = "f4XX-\t\u0013\u0014SW<Fr\u001aX\\8\u001c\u0006";
      j[13] = "y1M\u0001*mo1H[9zxzK]5ni=\\J~|X";
      j[14] = "T];\u0018GvB]>BTaU\u0016=DXuDQ*S\u0013aB";
      j[15] = "` W\u0013\\=v RIO*akQOC>p,FX\b+<";
      j[16] = "J%tYP\u0018?\u0005\u007fVAW^\u000bt]E\r*";
      j[17] = "6PU\u0017\u0015{Cp^\u0018\u00044\"~U\u0013\u0000nV";
      j[18] = "\u001bc\u001e 9tnC\u0015/(;\u000fM\u001e$,a{";
      j[19] = "\n(W2in\u007f\b\\=x!\u001e\u0006W6|{j";
      j[20] = "\u001a\u0016\u0004d\n\f\u0004\u001e\u001e+w\u001c\u0004";
      j[21] = "\u001el,K\u001dHK/9%L-M02]HL\u0018h$_%\u0014]5'J^\u0016\u0019<s%";
      j[22] = "tmWRE~uz\u0011\u0011*oJ)C\u0000O6%-\u0010UC\u0006wjC\u0003Tz2dI\u000b*";
      j[23] = "#Z((s\u0012aA.!\u001cG\u001cK25dC}\u001ej#f.#J? ,A'\u0019j,\u001c";
      j[24] = "hA=\u00176z=\u0002(yg\u001fmAm\u001fudk\u0013nG\u000e%kC5\u0002u#9@my";
      j[25] = "us2.7\u0018t02/YID\u007f07a_/\u007fg8=\"";
      j[26] = "}\u001dKbYC>\u001e\u0012sfXvf\u001bbY@&\n\u001fv\u0014IL";
      j[27] = "F>6j_\u0019Bmcfo\u001fy?;\u007f\u0017\u001b\u0018jci\u0015vF.!b\u0000J\u00045'ko";
      j[28] = ")\u0007!{a_(\u0010g8\u000eN\u0017E$!kHlG`(?'";
      j[29] = "*vp&\u0013z\"y6.*/+s\ncC4+\";8V 8\u001f3#O#(d1gFwG";
      j[30] = "\u001c)\u00018Z\u0000^2\u000715U#8\u001b%MQBmC3O<\u001e(\u0016;K@[&\u001c35";
      j[31] = "*SbDZ@+D$\u00075Q\u0014\u0015g\u0016[FhPi\u001cS8";
      j[32] = "w\u0007\u00030.Zq\u0006\u0007p^I!M\u0003q3I\u0005M\u0019f$Y-Q\u0004P\"L0K\u0019\u000bgY)S\rpe\u001d \u0007b";
      j[33] = "g_JiR'`\t\u001b\u007f1'!\u001eCtZ)#\u0015*9X<7Y\u001bbM($d\u0017?Wv&\u000f\u0017hX*[XCw]sj\u0003VcNNf^L=L%f\tCa1sa\u0002\u0012xZs6\rN\u0005\f26\nTyI<<\u0002*";
      j[34] = "/\u000fn\u0001wD+\u001b#\b\u001dE?\n8\u0014f(z\u001e#\u001c \u0019!\u000b7\u000f\u001d\u0011:\u00124\u001ff\u0013~\u001b`p";
      j[35] = "Ng<V?P\f|:_P\u0006qv&K(\u0001\u0010#~]*lLf+U.\u0010\th!]P";
      j[36] = "tT2gK\u00106O4n$@KE(z\\A*\u0010pl^,vU%dZP3[/l$";
      j[37] = "`DunBq#G,\u007f}jm?q,\u001b;,Tq{\u0014gQ";
      j[38] = "*O9_\u0012'+X\u007f\u001c}6\u0014\u000b=\u001a\u00100(I&\u001c\u0019_)H-\u000e\u0003#lF'\u0006}";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = j[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            j[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  j[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(437222288267564L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  j[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(437222288267564L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        j[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(437222288267564L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 101;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 226;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 84;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 106;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 164;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 244;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 101;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 226;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 84;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dn_C0192",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dn" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static void invokeBinding1(Object var0, int var1, Object var2, int var3, int var4, long var5, long var7) {
         MethodHandle var13 = bindingCache1;
         MethodHandle var12 = bindingCache1;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache1 = b(
                  MethodHandles.lookup(), "ô", SourceSupport.methodType("(Ljava/lang/Object;ILjava/lang/Object;IIJJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            var10.invokeExact((Object)var0, (int)var1, (Object)var2, (int)var3, (int)var4, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }
}
