package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.NumberUtil;
import dev.zprestige.prestige.renderlib.state.AlphaBlendState;
import dev.zprestige.prestige.renderlib.state.CapabilityState;
import dev.zprestige.prestige.renderlib.state.ColorUniformState;
import dev.zprestige.prestige.renderlib.state.DepthFunctionState;
import dev.zprestige.prestige.renderlib.state.ProgramState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Vector4f;

public class DrawPipelines {
   public static final DrawPipeline a;
   public static final DrawPipeline b;
   public static final DrawPipeline c;
   public static final DrawPipeline d;
   public static final DrawPipeline e;
   private static final Map f;
   private static final int g;
   private static final long h = 32545606813734L;
   private static final long[] i;
   private static final Integer[] j;
   private static final Map k;
   private static final Object[] l = new Object[16];
   private static final String[] m = new String[16];

   public static DrawPipeline aReturningdn_C0192(Object[] var0) {
      Vector4f var1 = (Vector4f)var0[0];
      long var2 = (Long)var0[1];
      var2 = 32545606813734L ^ var2;
      long var4 = var2 ^ 45807686708323L;
      long var6 = var2 ^ 133623233746628L;
      int var10000 = Event.bReturningInt();
      ColorComponents var9 = new ColorComponents(var1, var6);
      int var8 = var10000;
      ColorComponents var12 = var9;
      Map var11 = f;
      DrawPipeline var10 = (DrawPipeline)var11.get(var12);
      int var20 = var8;
      DrawPipeline var19 = var10;
      DrawPipeline var18 = var19;
      DrawPipeline var17 = var19;
      if (var20 == 0) {
         DrawPipeline var21 = var17;
         if (var21 == null) {
            VertexFormat var10002 = VertexFormats.e;
            short var10005 = 23247;
            long var10006 = 1391387573362728513L ^ var2;
            RenderState[] var23 = new RenderState[]{RenderState.a, new ProgramState(ShaderPrograms.c), null, null, null, null, null};
            short var10010 = 10119;
            long var10011 = 7206545208282735360L ^ var2;
            var23[2] = new CapabilityState(2884, true);
            var23[3] = new AlphaBlendState(true, true);
            var10010 = 27457;
            var10011 = 774759071705509832L ^ var2;
            short var27 = 7946;
            long var10012 = 2244996158742289285L ^ var2;
            var23[4] = new DepthFunctionState(515, 515);
            var10010 = 18075;
            var10011 = 2417885283545645590L ^ var2;
            var23[5] = new CapabilityState(2929, false);
            short var10007 = 22407;
            long var10008 = 4221383216631190284L ^ var2;
            var23[6] = new ColorUniformState(var9);
            var10 = new DrawPipeline(var10002, 4, false, var23, var4);
            DrawPipeline var16 = var10;
            ColorComponents var15 = var9;
            Map var14 = f;
            var14.put(var15, var16);
         }

         var18 = var10;
      }

      return var18;
   }

   static {

      {

      long var10001 = 30388192255211L ^ 98261408062286L;
      var10001 = 30388192255211L ^ 127828713901707L;
      var10001 = 30388192255211L ^ 13802283254781L;
      aReturningVoid();
      Cipher var12;
      Cipher var10000 = var12 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var13 = 1; var13 < 8; var13++) {
         var10003[var13] = (byte)(30388192255211L << var13 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var14 = var12.doFinal("\u0090\rcÐÆÊ«\u009bX\u00adíV\u008fNÌÝ".getBytes("ISO-8859-1"));
      String var38 = a(var14).intern();
      // String var11 = var38;
      k = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(30388192255211L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[10];
      String var4 = "\u000bW\u001b¯Ñ\u001b.`SyÓÅ\u001dW\u0091\u0084ä¶UèC\u009e\u0014ÃCVP°7C\u0015ÍÃâaBKO\u009d±\u0003Xa³¾\u009eìC)\u0087ðw\u0081êþã\u0093þ_¸Éªõ»";
      int var5 = "\u000bW\u001b¯Ñ\u001b.`SyÓÅ\u001dW\u0091\u0084ä¶UèC\u009e\u0014ÃCVP°7C\u0015ÍÃâaBKO\u009d±\u0003Xa³¾\u009eìC)\u0087ðw\u0081êþã\u0093þ_¸Éªõ»"
         .length();
      label29:
      while (true) {
         int var34 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var34, var2).getBytes("ISO-8859-1");
         long[] var28 = var6;
         int var35 = var3++;
         long var40 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var40;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var46 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var43) {
               case 0:
                  var28[var35] = var46;
                  if (var2 >= var5) {
                     i = var6;
                     j = new Integer[10];
                     a = new DrawPipeline(
                        VertexFormats.b,
                        4,
                        false,
                        new RenderState[]{RenderState.a, new ProgramState(ShaderPrograms.a), new CapabilityState(2884, false), new AlphaBlendState(true, true), new DepthFunctionState(515, 515)},
                        123013172433504L
                     );
                     b = new DrawPipeline(
                        VertexFormats.b,
                        4,
                        false,
                        new RenderState[]{
                           RenderState.a,
                           new ProgramState(ShaderPrograms.a),
                           new CapabilityState(2884, false),
                           new AlphaBlendState(true, true),
                           new DepthFunctionState(515, 515),
                           new CapabilityState(2929, false)
                        },
                        123013172433504L
                     );
                     c = new DrawPipeline(
                        VertexFormats.b,
                        4,
                        false,
                        new RenderState[]{
                           RenderState.a,
                           new ProgramState(ShaderPrograms.a),
                           new CapabilityState(2884, true),
                           new AlphaBlendState(true, true),
                           new DepthFunctionState(515, 515),
                           new CapabilityState(2929, true)
                        },
                        123013172433504L
                     );
                     d = new DrawPipeline(
                        VertexFormats.b,
                        1,
                        false,
                        new RenderState[]{RenderState.a, new ProgramState(ShaderPrograms.a), new CapabilityState(2884, true), new AlphaBlendState(true, true), new DepthFunctionState(515, 515)},
                        123013172433504L
                     );
                     e = new DrawPipeline(
                        VertexFormats.b,
                        1,
                        false,
                        new RenderState[]{
                           RenderState.a,
                           new ProgramState(ShaderPrograms.a),
                           new CapabilityState(2884, true),
                           new AlphaBlendState(true, true),
                           new DepthFunctionState(515, 515),
                           new CapabilityState(2929, false)
                        },
                        123013172433504L
                     );
                     short var29 = 27786;
                     var10001 = 4606304779776579075L;
                     Object[] var45 = new Object[]{null, 25489915207446L};
                     var45[0] = 128;
                     Object[] var23 = var45;
                     f = NumberUtil.aReturningMap(var23);
                     GlProgram var30 = ShaderPrograms.c;
                     Object[] var25 = new Object[]{var11, 73654548629413L};
                     GlProgram var24 = var30;
                     g = var24.dReturningInt(var25);
                     break;
                  }
                  break;
               default:
                  var28[var35] = var46;
                  if (var2 < var5) {
                     continue label29;
                  }

                  var4 = "sOpZ¯ö\u0017\u0089¢ÍÌ!1\u0018\u0000S";
                  var5 = "sOpZ¯ö\u0017\u0089¢ÍÌ!1\u0018\u0000S".length();
                  var2 = 0;
            }

            int var36 = var2;
            var2 += 8;
            var7 = var4.substring(var36, var2).getBytes("ISO-8859-1");
            var28 = var6;
            var35 = var3++;
            var40 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var43 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14989;
      if (j[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = i[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])k.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               k.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dp", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         j[var3] = var15;
      }

      return j[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dp_C0194",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dp" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 59;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 50;
            yield var17;
         }
         case 3 -> {
            byte var18 = 16;
            yield var18;
         }
         case 4 -> {
            byte var19 = 0;
            yield var19;
         }
         case 5 -> {
            byte var20 = 7;
            yield var20;
         }
         case 6 -> {
            byte var21 = 20;
            yield var21;
         }
         case 7 -> {
            byte var22 = 31;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 30;
            yield var24;
         }
         case 10 -> {
            byte var25 = 54;
            yield var25;
         }
         case 11 -> {
            byte var26 = 43;
            yield var26;
         }
         case 12 -> {
            byte var27 = 42;
            yield var27;
         }
         case 13 -> {
            byte var28 = 55;
            yield var28;
         }
         case 14 -> {
            byte var29 = 29;
            yield var29;
         }
         case 15 -> {
            byte var30 = 15;
            yield var30;
         }
         case 16 -> {
            byte var31 = 33;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 27;
            yield var33;
         }
         case 19 -> {
            byte var34 = 1;
            yield var34;
         }
         case 20 -> {
            byte var35 = 63;
            yield var35;
         }
         case 21 -> {
            byte var36 = 9;
            yield var36;
         }
         case 22 -> {
            byte var37 = 25;
            yield var37;
         }
         case 23 -> {
            byte var38 = 8;
            yield var38;
         }
         case 24 -> {
            byte var39 = 6;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 56;
            yield var42;
         }
         case 28 -> {
            byte var43 = 10;
            yield var43;
         }
         case 29 -> {
            byte var44 = 49;
            yield var44;
         }
         case 30 -> {
            byte var45 = 48;
            yield var45;
         }
         case 31 -> {
            byte var46 = 13;
            yield var46;
         }
         case 32 -> {
            byte var47 = 5;
            yield var47;
         }
         case 33 -> {
            byte var48 = 61;
            yield var48;
         }
         case 34 -> {
            byte var49 = 53;
            yield var49;
         }
         case 35 -> {
            byte var50 = 38;
            yield var50;
         }
         case 36 -> {
            byte var51 = 3;
            yield var51;
         }
         case 37 -> {
            byte var52 = 4;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 34;
            yield var54;
         }
         case 40 -> {
            byte var55 = 60;
            yield var55;
         }
         case 41 -> {
            byte var56 = 21;
            yield var56;
         }
         case 42 -> {
            byte var57 = 23;
            yield var57;
         }
         case 43 -> {
            byte var58 = 57;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 36;
            yield var60;
         }
         case 46 -> {
            byte var61 = 41;
            yield var61;
         }
         case 47 -> {
            byte var62 = 26;
            yield var62;
         }
         case 48 -> {
            byte var63 = 28;
            yield var63;
         }
         case 49 -> {
            byte var64 = 18;
            yield var64;
         }
         case 50 -> {
            byte var65 = 52;
            yield var65;
         }
         case 51 -> {
            byte var66 = 14;
            yield var66;
         }
         case 52 -> {
            byte var67 = 47;
            yield var67;
         }
         case 53 -> {
            byte var68 = 37;
            yield var68;
         }
         case 54 -> {
            byte var69 = 62;
            yield var69;
         }
         case 55 -> {
            byte var70 = 17;
            yield var70;
         }
         case 56 -> {
            byte var71 = 2;
            yield var71;
         }
         case 57 -> {
            byte var72 = 32;
            yield var72;
         }
         case 58 -> {
            byte var73 = 35;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 39;
            yield var75;
         }
         case 61 -> {
            byte var76 = 22;
            yield var76;
         }
         case 62 -> {
            byte var77 = 12;
            yield var77;
         }
         default -> 44;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      l[0] = "9+\u0000\u001ddy/+\u0005Gwn8`\u0006A{z)'\u0011V0oh";
      l[1] = "}W\u0011\u001a\\\u000b\bw\u001a\u0015MDiy\u0011\u001eI\u001e\u001d";
      l[2] = "Cie10L]a\u007f~SXY";
      l[3] = "9YG4i}/YBnzj8\u0012Ahv~)UV\u007f=k\u0010";
      l[4] = "\t-`2wV|\rk=f\u0019\u001d\u0003`6bCi";
      l[5] = int.class;
      m[5] = "java/lang/Integer";
      l[6] = "{fH`\u0004,mfM:\u0017;z-N<\u001b/kjY+P=Z";
      l[7] = "Kx%\u0014\u001a\f]x N\t\u001bJ3#H\u0005\u000f[t4_N\u0018_";
      l[8] = "\\u\u001a*\u0013\u007fWz\u000beprBw\u0004\u000eEpSd\u0018\"R}";
      l[9] = "\u000fKuf\bN\u0004Dd)i@\u000fO`s";
      l[10] = "\u00020bJa2N:7B\u001ca>po\u000bx{G\"0@{\u000b";
      l[11] = "\u001b\u0015!\u0000|^B\u0007\"\u0003\u0013QO\u001b\u001aQo\u0007K\u001c#V+A@g$\u0013*WY^#Wl\\\"";
      l[12] = "\u0002x)P)F\u001c;<..6Tz<_w\t\u000eg-NG\u000f\u001c<#A'V\u000e? .";
      l[13] = "W4B{~[P|Q:OGmvO{>\u001bR,Rj/+V-Bo?R\u0004r\tlO";
      l[14] = "1u\u0017\u001dWO6/\u0007\u0016gJ\f#\u001dKW\u001f2\u007f\f\n\u001a#1e]@[\u001dmt\u001c\rg";
      l[15] = "\u001cv\u0006S?[Ed\u0005PPCXx=\u0002,\u0002L\u007f\u0004\u0005hDG\u0004\u0003@iR^=\u0004\u0004/Y%:A\u00059@\u001c=\u0005C2;";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(691273754094547L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(691273754094547L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(691273754094547L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 231;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 170;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 246;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 84;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 201;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 202;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 231;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 170;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 246;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dp_C0194",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dp" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

    public static int recoveryAccess_read_g() { return dev.zprestige.prestige.renderlib.DrawPipelines.g; }
}
