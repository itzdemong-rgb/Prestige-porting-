package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public class DualPassBlurRenderer {
   public ManagedGlFramebuffer a;
   public ManagedGlFramebuffer b;
   public ManagedGlTexture c;
   public ManagedGlTexture d;
   private int e;
   private int f;
   private static final MinecraftClient g;
   private static final int h;
   private static final int i;
   private static final int j;
   private final float k;
   private final float l;
   private boolean m;
   private final RenderPassSequence n;
   private long o;
   private static final long p = 82581497762932L;
   private static final long[] q;
   private static final Integer[] r;
   private static final Map s;
   private static final long t;
   private static final Object[] u = new Object[58];
   private static final String[] v = new String[58];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public int aReturningInt(Object[] var1) {
      return this.e;
   }

   public int bReturningInt(Object[] var1) {
      return this.f;
   }

   public DualPassBlurRenderer(float var1, float var2, long var3) {
      super();
      var3 = 82581497762932L ^ var3;
      long var5 = var3 ^ 59162014062474L;
      long var7 = var3 ^ 27665570288624L;
      long var9 = var3 ^ 21632131620358L;
      long var11 = var3 ^ 127383255346250L;

      Object[] var13 = new Object[]{var5};
      this.a = ManagedGlFramebuffer.aReturningbR_C0091(var13);
      Object[] var14 = new Object[]{var5};
      this.b = ManagedGlFramebuffer.aReturningbR_C0091(var14);
      short var10001 = 24554;
      long var10002 = 3367658467033187993L ^ var3;
      Object[] var10004 = new Object[]{null, var11};
      var10004[0] = 3553;
      Object[] var15 = var10004;
      this.c = ManagedGlTexture.aReturningbT_C0095(var15);
      var10001 = 24554;
      var10002 = 3367658467033187993L ^ var3;
      var10004 = new Object[]{null, var11};
      var10004[0] = 3553;
      Object[] var16 = var10004;
      this.d = ManagedGlTexture.aReturningbT_C0095(var16);
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.o = t;
      MinecraftClient var17 = g;
      Window var18 = var17.getWindow();
      this.e = var18.getFramebufferWidth();
      MinecraftClient var19 = g;
      Window var20 = var19.getWindow();
      this.f = var20.getFramebufferHeight();
      this.k = var1;
      this.l = var2;
      Object[] var22 = new Object[]{var7};
      DualPassBlurRenderer var21 = this;
      var21.aReturningVoid(var22);
      RenderPassSequence var29 = new RenderPassSequence();
      GlProgram var32 = ShaderPrograms.d;
      Consumer var10003 = invokeBinding1(this);
      int var36 = this.b.a;
      Object[] var10007 = new Object[]{null, null, null, var9};
      var10007[2] = var36;
      var10007[1] = var10003;
      var10007[0] = var32;
      Object[] var24 = var10007;
      RenderPassSequence var23 = var29;
      RenderPassSequence var30 = var23.aReturningc4(var24);
      GlProgram var33 = ShaderPrograms.d;
      var10003 = invokeBinding2(this);
      int var37 = this.a.a;
      var10007 = new Object[]{null, null, null, var9};
      var10007[2] = var37;
      var10007[1] = var10003;
      var10007[0] = var33;
      Object[] var26 = var10007;
      RenderPassSequence var25 = var30;
      this.n = var25.aReturningc4(var26);
   }

   private void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 82581497762932L ^ var2;
      long var4 = var2 ^ 65881221766071L;
      long var6 = var2 ^ 11265240210121L;
      long var8 = var2 ^ 50341878305289L;
      long var10 = var2 ^ 37281876732878L;
      int var12 = Event.cReturningInt();
      int var49 = var12;
      byte var48 = ((byte)((this.m) ? 1 : 0));
      char var47 = (char)var48;
      byte var46 = var48;
      if (var49 != 0) {
         byte var50 = var46;
         if (var50 != 0) {
            ManagedGlTexture var14 = this.c;
            var14.close();
            ManagedGlTexture var15 = this.d;
            var15.close();
         }

         short var10001 = 24554;
         long var10002 = 3367568522307830045L ^ var2;
         Object[] var10004 = new Object[]{null, var10};
         var10004[0] = 3553;
         Object[] var17 = var10004;
         this.c = ManagedGlTexture.aReturningbT_C0095(var17);
         ManagedGlTexture var10000 = this.c;
         var10001 = 11957;
         var10002 = 1294856145613877315L ^ var2;
         int var83 = this.e;
         int var10003 = this.f;
         Object[] var10006 = new Object[]{null, null, null, var4};
         var10006[2] = var10003;
         var10006[1] = var83;
         var10006[0] = 32849;
         Object[] var19 = var10006;
         ManagedGlTexture var18 = var10000;
         var18.cReturningVoid(var19);
         var10000 = this.c;
         var10001 = 24514;
         var10002 = 5453226022986875194L ^ var2;
         var10004 = new Object[]{null, var6};
         var10004[0] = 9729;
         Object[] var21 = var10004;
         ManagedGlTexture var20 = var10000;
         var20.bReturningVoid(var21);
         var10000 = this.c;
         var10001 = 6631;
         var10002 = 3086743272491796253L ^ var2;
         var10004 = new Object[]{null, var8};
         var10004[0] = 33071;
         Object[] var23 = var10004;
         ManagedGlTexture var22 = var10000;
         var22.eReturningVoid(var23);
         var10001 = 24554;
         var10002 = 3367568522307830045L ^ var2;
         var10004 = new Object[]{null, var10};
         var10004[0] = 3553;
         Object[] var24 = var10004;
         this.d = ManagedGlTexture.aReturningbT_C0095(var24);
         var10000 = this.d;
         var10001 = 21394;
         var10002 = 6954688340060179819L ^ var2;
         int var88 = this.e;
         var10003 = this.f;
         var10006 = new Object[]{null, null, null, var4};
         var10006[2] = var10003;
         var10006[1] = var88;
         var10006[0] = 32849;
         Object[] var26 = var10006;
         ManagedGlTexture var25 = var10000;
         var25.cReturningVoid(var26);
         var10000 = this.d;
         var10001 = 31689;
         var10002 = 968862623063614778L ^ var2;
         var10004 = new Object[]{null, var6};
         var10004[0] = 9729;
         Object[] var28 = var10004;
         ManagedGlTexture var27 = var10000;
         var27.bReturningVoid(var28);
         var10000 = this.d;
         var10001 = 23921;
         var10002 = 8035494048187384705L ^ var2;
         var10004 = new Object[]{null, var8};
         var10004[0] = 33071;
         Object[] var30 = var10004;
         ManagedGlTexture var29 = var10000;
         var29.eReturningVoid(var30);
         short var57 = 30306;
         long var73 = 6975909318750120089L ^ var2;
         char var58 = '赀';
         int var32 = this.a.a;
         GL30.glBindFramebuffer(36160, var32);
         short var59 = 21261;
         long var74 = 3048972185079295L ^ var2;
         char var60 = '赀';
         var10001 = 15284;
         var10002 = 7386060106083657034L ^ var2;
         char var76 = '賠';
         short var92 = 24554;
         long var98 = 3367568522307830045L ^ var2;
         short var93 = 3553;
         int var36 = this.c.a;
         GL30.glFramebufferTexture2D(36160, 36064, 3553, var36, 0);
         short var61 = 21261;
         long var77 = 3048972185079295L ^ var2;
         char var62 = '赀';
         int var39 = this.b.a;
         GL30.glBindFramebuffer(36160, var39);
         short var63 = 21261;
         long var78 = 3048972185079295L ^ var2;
         char var64 = '赀';
         var10001 = 211;
         var10002 = 4294148739003178543L ^ var2;
         char var80 = '賠';
         short var95 = 24554;
         long var99 = 3367568522307830045L ^ var2;
         short var96 = 3553;
         int var43 = this.d.a;
         GL30.glFramebufferTexture2D(36160, 36064, 3553, var43, 0);
         short var65 = 21261;
         long var81 = 3048972185079295L ^ var2;
         var47 = '赀';
      }

      char var45 = var47;
      GL30.glBindFramebuffer(var45, 0);
      this.m = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   private boolean aReturningBoolean(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 82581497762932L ^ var2;
      long var4 = var2 ^ 76110119913354L;
      int var6 = Event.bReturningInt();
      MinecraftClient var9 = g;
      Window var10000 = var9.getWindow();
      int var37 = var6;
      Window var36 = var10000;
      Window var25 = var36;
      Window var24 = var36;
      if (var37 == 0) {
         Window var38 = var24;
         if (var38 == null) {
            return false;
         }

         MinecraftClient var12 = g;
         var25 = var12.getWindow();
      }

      Window var13 = var25;
      int var7 = var13.getFramebufferWidth();
      MinecraftClient var14 = g;
      Window var15 = var14.getWindow();
      int var8 = var15.getFramebufferHeight();
      int var40 = var6;
      int var39 = var7;
      int var29 = var39;
      int var26 = var39;
      if (var40 == 0) {
         int var41 = var26;
         label56:
         if (var41 > 0) {
            int var43 = var6;
            int var42 = var8;
            int var30 = var42;
            int var27 = var42;
            if (var43 == 0) {
               int var44 = var27;
               int var28 = var44;
               int var45 = var28;
               if (var45 <= 0) {
                  break label56;
               }

               var30 = this.e;
            }

            int var47 = var6;
            int var46 = var30;
            int var34 = var46;
            int var31 = var46;
            if (var47 == 0) {
               int var49 = var7;
               int var48 = var31;
               label42:
               if (var48 == var49) {
                  int var51 = var6;
                  int var50 = this.f;
                  int var35 = var50;
                  int var32 = var50;
                  if (var51 == 0) {
                     int var52 = var32;
                     int var33 = var52;
                     int var54 = var8;
                     int var53 = var33;
                     if (var53 != var54) {
                        break label42;
                     }

                     var35 = 0;
                  }

                  return dev.prestige.recovery.SourceSupport.asBoolean(var35);
               }

               this.e = var7;
               this.f = var8;
               Object[] var23 = new Object[]{var4};
               DualPassBlurRenderer var22 = this;
               var22.aReturningVoid(var23);
               byte var55 = 1;
               var34 = var55;
            }

            return dev.prestige.recovery.SourceSupport.asBoolean(var34);
         }

         var29 = 0;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var29);
   }

   public void bReturningVoid(Object[] var1) {
      long var2;
      long var8;
      DualPassBlurRenderer var23;
      label24: {
         label23: {
            var2 = (Long)var1[0];
            long var4 = (Long)var1[1];
            var4 = 82581497762932L ^ var4;
            long var6 = var4 ^ 97989258048255L;
            var8 = var4 ^ 132864830002964L;
            int var10000 = Event.bReturningInt();
            Object[] var13 = new Object[]{var6};
            DualPassBlurRenderer var12 = this;
            byte var11 = ((byte)((var12.aReturningBoolean(var13)) ? 1 : 0));
            int var10 = var10000;
            int var25 = var10;
            byte var24 = var11;
            int var22 = var24;
            byte var19 = var24;
            if (var25 == 0) {
               byte var26 = var19;
               if (((var26) != 0)) {
                  break label23;
               }

               int var28 = var10;
               DualPassBlurRenderer var27 = this;
               var23 = var27;
               DualPassBlurRenderer var20 = var27;
               if (var28 != 0) {
                  break label24;
               }

               DualPassBlurRenderer var29 = var20;
               DualPassBlurRenderer var21 = var29;
               long var33;
               int var30 = (var33 = var21.o - var2) == 0L ? 0 : (var33 < 0L ? -1 : 1);
               var22 = var30;
            }

            int var31 = var22;
            if (!((var31) != 0)) {
               return;
            }
         }

         var23 = this;
      }

      Object[] var10004 = new Object[]{null, var8};
      var10004[0] = var2;
      Object[] var18 = var10004;
      DualPassBlurRenderer var17 = var23;
      var17.cReturningVoid(var18);
   }

   private void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = (Long)var1[1];
      var4 = 82581497762932L ^ var4;
      long var6 = var4 ^ 113706919621506L;
      this.o = var2;
      RenderPassSequence var10000 = this.n;
      Object[] var9 = new Object[]{var6};
      RenderPassSequence var8 = var10000;
      var8.aReturningVoid(var9);
   }

   private void lambda$new$1(RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = this.d.a;
      GL30.glBindTexture(3553, var6);
      float var9 = 1.0F;
      float var8 = 0.0F;
      int var7 = h;
      GL20.glUniform2f(var7, var8, var9);
      float var11 = this.k;
      int var10 = i;
      GL20.glUniform1f(var10, var11);
      float var13 = this.l;
      int var12 = j;
      GL20.glUniform1f(var12, var13);
   }

   private void lambda$new$0(RenderPass var1) {
      long var10001 = 128859760669309L ^ 27546768187372L;
      GL13.glActiveTexture(33984);
      Object[] var8 = new Object[]{119018830146961L};
      int var6 = RenderThreadUtil.bReturningInt(var8);
      short var10000 = 3553;
      int var10 = var6;
      GL30.glBindTexture(3553, var10);
      float var13 = 0.0F;
      float var12 = 1.0F;
      int var11 = h;
      GL20.glUniform2f(var11, var12, var13);
      float var15 = this.k;
      int var14 = i;
      GL20.glUniform1f(var14, var15);
      float var17 = this.l;
      int var16 = j;
      GL20.glUniform1f(var16, var17);
   }

   static {

      {

      long var10001 = 30530647742998L ^ 98103249919411L;
      var10001 = 30530647742998L ^ 75865637131662L;
      aReturningVoid();
      Cipher var17;
      Cipher var10000 = var17 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var18 = 1; var18 < 8; var18++) {
         var10003[var18] = (byte)(30530647742998L << var18 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var16 = new String[4];
      String var21 = "\u000eï\u001fX¾Ð\u000bÄ®$Ð£©z^*\b9xÂ\u008d©\u0016\u008bö";
      int var23 = "\u000eï\u001fX¾Ð\u000bÄ®$Ð£©z^*\b9xÂ\u008d©\u0016\u008bö".length();
      char var20 = 16;
      int var41 = -1;

      label64:
      while (true) {
         String var42 = var21.substring(++var41, var41 + var20);
         // while (true) {
            byte[] var24 = var17.doFinal(var42.getBytes("ISO-8859-1"));
            String var63 = a(var24).intern();
            switch (var52) {
               case 0:
                  var16[var22++] = var63;
                  if ((var41 += var20) >= var23) {
                     s = new HashMap(13);
                     Cipher var5;
                     var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var6 = 1; var6 < 8; var6++) {
                        var10003[var6] = (byte)(30530647742998L << var6 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var11 = new long[14];
                     String var9 = "ã\u00116X\u0089\u008fÄP?+\u000bI£\b\u0007pà[E\u001enáÌXÚú#åHmôQ¬\u008dHC[\u0092:\u009bÅ.Èþ\u0005þ¾%N\u008dRtoâÇÙD\u009aNr\bØ\u000fÅj$çÜ\u0098TDÞ¢ëQ\u0000}Àc\t\u0098_ç¥\u0005t\u0098óbè!É¶\u0088´³";
                     int var10 = "ã\u00116X\u0089\u008fÄP?+\u000bI£\b\u0007pà[E\u001enáÌXÚú#åHmôQ¬\u008dHC[\u0092:\u009bÅ.Èþ\u0005þ¾%N\u008dRtoâÇÙD\u009aNr\bØ\u000fÅj$çÜ\u0098TDÞ¢ëQ\u0000}Àc\t\u0098_ç¥\u0005t\u0098óbè!É¶\u0088´³"
                        .length();
                     label46:
                     while (true) {
                        int var56 = var7;
                        var7 += 8;
                        byte[] var12 = var9.substring(var56, var7).getBytes("ISO-8859-1");
                        long[] var45 = var11;
                        int var57 = var8++;
                        long var67 = (var12[0] & 255L) << 56
                           | (var12[1] & 255L) << 48
                           | (var12[2] & 255L) << 40
                           | (var12[3] & 255L) << 32
                           | (var12[4] & 255L) << 24
                           | (var12[5] & 255L) << 16
                           | (var12[6] & 255L) << 8
                           | var12[7] & 255L;
                        // while (true) {
                           long var13 = var67;
                           byte[] var15 = var5.doFinal(
                              new byte[]{
                                 (byte)(var13 >>> 56),
                                 (byte)(var13 >>> 48),
                                 (byte)(var13 >>> 40),
                                 (byte)(var13 >>> 32),
                                 (byte)(var13 >>> 24),
                                 (byte)(var13 >>> 16),
                                 (byte)(var13 >>> 8),
                                 (byte)var13
                              }
                           );
                           long var75 = (var15[0] & 255L) << 56
                              | (var15[1] & 255L) << 48
                              | (var15[2] & 255L) << 40
                              | (var15[3] & 255L) << 32
                              | (var15[4] & 255L) << 24
                              | (var15[5] & 255L) << 16
                              | (var15[6] & 255L) << 8
                              | var15[7] & 255L;
                           switch (var72) {
                              case 0:
                                 var45[var57] = var75;
                                 if (var7 >= var10) {
                                    q = var11;
                                    r = new Integer[14];
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(30530647742998L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    var10001 = -424380123393364853L;
                                    byte[] var4 = var0.doFinal(
                                       new byte[]{
                                          (byte)250L,
                                          (byte)64028L,
                                          (byte)16391244L,
                                          (byte)4196158598L,
                                          (byte)1074216601271L,
                                          (byte)274999449925478L,
                                          (byte)70399859180922604L,
                                          (byte)-424380123393364853L
                                       }
                                    );
                                    long var70 = (var4[0] & 255L) << 56
                                       | (var4[1] & 255L) << 48
                                       | (var4[2] & 255L) << 40
                                       | (var4[3] & 255L) << 32
                                       | (var4[4] & 255L) << 24
                                       | (var4[5] & 255L) << 16
                                       | (var4[6] & 255L) << 8
                                       | var4[7] & 255L;
                                    // t = var70;
                                    g = MinecraftClient.getInstance();
                                    GlProgram var47 = ShaderPrograms.d;
                                    Object[] var32 = new Object[]{var16[0], 73654548629413L};
                                    GlProgram var31 = var47;
                                    h = var31.dReturningInt(var32);
                                    GlProgram var48 = ShaderPrograms.d;
                                    Object[] var34 = new Object[]{var16[1], 73654548629413L};
                                    GlProgram var33 = var48;
                                    i = var33.dReturningInt(var34);
                                    GlProgram var49 = ShaderPrograms.d;
                                    Object[] var36 = new Object[]{var16[3], 73654548629413L};
                                    GlProgram var35 = var49;
                                    j = var35.dReturningInt(var36);
                                    GlProgram var50 = ShaderPrograms.d;
                                    String var61 = var16[2];
                                    Object[] var10005 = new Object[]{null, null, 104709695459224L};
                                    var10005[1] = 0;
                                    var10005[0] = var61;
                                    Object[] var38 = var10005;
                                    GlProgram var37 = var50;
                                    var37.aReturningVoid(var38);
                                    break;
                                 }
                                 break;
                              default:
                                 var45[var57] = var75;
                                 if (var7 < var10) {
                                    continue label46;
                                 }

                                 var9 = "\u007fÇ\u0094s\u009a¦Y\u0011\u0080G\u009anÂ\u00009#";
                                 var10 = "\u007fÇ\u0094s\u009a¦Y\u0011\u0080G\u009anÂ\u00009#".length();
                                 var7 = 0;
                           }

                           int var58 = var7;
                           var7 += 8;
                           var12 = var9.substring(var58, var7).getBytes("ISO-8859-1");
                           var45 = var11;
                           var57 = var8++;
                           var67 = (var12[0] & 255L) << 56
                              | (var12[1] & 255L) << 48
                              | (var12[2] & 255L) << 40
                              | (var12[3] & 255L) << 32
                              | (var12[4] & 255L) << 24
                              | (var12[5] & 255L) << 16
                              | (var12[6] & 255L) << 8
                              | var12[7] & 255L;
                           var72 = 0;
                        }
                     }
                  }

                  var20 = var21.charAt(var41);
                  break;
               default:
                  var16[var22++] = var63;
                  if ((var41 += var20) < var23) {
                     var20 = var21.charAt(var41);
                     continue label64;
                  }

                  var21 = "8+Úü\u0007\u008e\u0099gÊ¿\u0005\u0003¦_Ðv\bÔ£r\u0090êéq\u009a";
                  var23 = "8+Úü\u0007\u008e\u0099gÊ¿\u0005\u0003¦_Ðv\bÔ£r\u0090êéq\u009a".length();
                  var20 = 16;
                  var41 = -1;
            }

            var42 = var21.substring(++var41, var41 + var20);
            var52 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 22874;
      if (r[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = q[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])s.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/am", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         r[var3] = var15;
      }

      return r[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/am_C0028",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/am" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = v[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = u[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 15;
            yield var15;
         }
         case 1 -> {
            byte var16 = 14;
            yield var16;
         }
         case 2 -> {
            byte var17 = 23;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 47;
            yield var19;
         }
         case 5 -> {
            byte var20 = 59;
            yield var20;
         }
         case 6 -> {
            byte var21 = 3;
            yield var21;
         }
         case 7 -> {
            byte var22 = 8;
            yield var22;
         }
         case 8 -> {
            byte var23 = 29;
            yield var23;
         }
         case 9 -> {
            byte var24 = 32;
            yield var24;
         }
         case 10 -> {
            byte var25 = 36;
            yield var25;
         }
         case 11 -> {
            byte var26 = 22;
            yield var26;
         }
         case 12 -> {
            byte var27 = 46;
            yield var27;
         }
         case 13 -> {
            byte var28 = 45;
            yield var28;
         }
         case 14 -> {
            byte var29 = 35;
            yield var29;
         }
         case 15 -> {
            byte var30 = 12;
            yield var30;
         }
         case 16 -> {
            byte var31 = 49;
            yield var31;
         }
         case 17 -> {
            byte var32 = 38;
            yield var32;
         }
         case 18 -> {
            byte var33 = 42;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 27;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 10;
            yield var38;
         }
         case 24 -> {
            byte var39 = 7;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 56;
            yield var43;
         }
         case 29 -> {
            byte var44 = 54;
            yield var44;
         }
         case 30 -> {
            byte var45 = 50;
            yield var45;
         }
         case 31 -> {
            byte var46 = 21;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 2;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 19;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 24;
            yield var55;
         }
         case 41 -> {
            byte var56 = 43;
            yield var56;
         }
         case 42 -> {
            byte var57 = 53;
            yield var57;
         }
         case 43 -> {
            byte var58 = 41;
            yield var58;
         }
         case 44 -> {
            byte var59 = 26;
            yield var59;
         }
         case 45 -> {
            byte var60 = 31;
            yield var60;
         }
         case 46 -> {
            byte var61 = 9;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 13;
            yield var63;
         }
         case 49 -> {
            byte var64 = 16;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 63;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 5;
            yield var70;
         }
         case 56 -> {
            byte var71 = 6;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 60;
            yield var73;
         }
         case 59 -> {
            byte var74 = 52;
            yield var74;
         }
         case 60 -> {
            byte var75 = 44;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 57;
            yield var77;
         }
         default -> 25;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            v[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      u[0] = "rOr!\"GwZy!!@xSrc`wQ\u000f%";
      u[1] = int.class;
      v[1] = "java/lang/Integer";
      u[2] = float.class;
      v[2] = "java/lang/Float";
      u[3] = void.class;
      v[3] = "java/lang/Void";
      u[4] = "\u0001#\u0002!]\u000f\u0017#\u0007{N\u0018\u0000h\u0004}B\f\u0011/\u0013j\t\u001b\u000f";
      u[5] = "Ki*\f;\\>I!\u0003*\u0013_G*\b.I+";
      u[6] = "(Wx\t(a-Bs\t+f\"KxKjQ\u000b\u0014,";
      u[7] = "\r&?\u0014$9\b34\u0014'>\u0007:?Vf\t.gh";
      u[8] = "eiLO,5siI\u0015?\"d\"J\u001336ue]\u0004x$l";
      u[9] = "}@e_\\6vOt\u0010?;cB{{\n9rQgW\u001d4";
      u[10] = "^t\u00117\roHt\u0014m\u001ex_?\u0017k\u0012lNx\u0000|Y}n";
      u[11] = "\u001eM,D\u001a6km'K\u000by\nc,@\u000f#~";
      u[12] = "EQ\u001d\u001f\u0017WSQ\u0018E\u0004@D\u001a\u001bC\bTU]\fTCFd";
      u[13] = "'=\";\u001c\bR\u001d)4\rG3\u0013\"?\t\u001dG";
      u[14] = "yD,`nT\fd'o\u007f\u001bmj,d{A\u0019";
      u[15] = "jOvN\u0006\\\u001fo}A\u0017\u0013~avJ\u0013I\n";
      u[16] = ".PMqWL[pF~F\u0003:~MuBYN";
      u[17] = boolean.class;
      v[17] = "java/lang/Boolean";
      u[18] = "\u0014\"U*\u0011Va\u0002^%\u0000\u0019\u0000\fU.\u0004Ct";
      u[19] = "V\n4n^lV\n#2RcLA#,RvK0sq\u0003";
      u[20] = "\\\u00169X^\u001aJ\u0016<\u0002M\r]]?\u0004A\u0019L\u001a(\u0013\n\fu";
      u[21] = ");#yK.\\\u001b(vZa=\u0015#}^;I";
      u[22] = "\u0001!c5>\ft\u0001h:/C\u0015\u000fc1+\u0019a";
      u[23] = "\u000bWJQ&\u0000~wA^7O\u001fyJU3\u0015k";
      u[24] = "\u0001\u001f\u0017+\u0003 \u0017\u001f\u0012q\u00107\u0000T\u0011w\u001c#\u0011\u0013\u0006`W27";
      u[25] = "v\u0006-<f}\u0003&&3w2b(-8sh\u0016";
      u[26] = "\u0018\\F\u0018Qm\u0018\\QD]b\u0002\u0017QZ]w\u0005f\u0003\u0006\b5";
      u[27] = "I\n\u000e\fUQ_\n\u000bVFFHA\bPJRY\u0006\u001fG\u0001B\u0019";
      u[28] = "dFCE=r\u0011fHJ,=phCA(g\u0004";
      u[29] = "5OJ({T@oA'j\u001b!aJ,nAU";
      u[30] = "XDz&\u001dGSKki|IX@o3";
      u[31] = "C5}1IH\u0018v*v(L}jh3EF\u001al/!\u0012%Gc(t\u0012UGhhs(";
      u[32] = "NU{rs\u001d\u000bXe,N\u0017uZzi#\u001e\u0012\\={t}\f\u0002|*\"\u0001\u001c_c\u0012";
      u[33] = "@|z\f\u0003k\u001b?-Kbo~~i\u001bXmE \u007f\u000e\u001c\u0006@?xO\t=\u001e)m\u000bb";
      u[34] = "\u001bu\u0015!\u0010\u0000F\"\u000b&,\u000b$}\u00140A\u0001C{S\"\u0016b\u001bu\u0015!\u0010\u0000F\"\u000b&,";
      u[35] = "\tXy(Q!G\u0019=y019]\u007f;\b7EM\"$0";
      u[36] = "T\u0017\u0011\u0000\u001c4R\u0004\u0017\u001dw0X\u0007O\u0001\u001b\u0002\tG\u001fWw,\u000e\u0004\u0017\n\u000b<S\u001b/";
      u[37] = "\u0005YF[\u0000\u0006\u0006]\u0018H|\tg\u0000\\Q\u0011\u0003\u0000\u0006\u001bCF`\u0005YF[\u0000\u0006\u0006]\u0018H|";
      u[38] = ".\u001b\u001b0$>(\b\u001d-O:\"\u000bE1#\bsJ\u001dhO&t\b\u001d:36)\u0017%";
      u[39] = "\u000e.Y\nGp@o\u001d[&a>+_\u0019\u001efB;\u0002\u0006&";
      u[40] = "\u001dW\u001aA`m@\u0000\u0004F\\e\"_\u001bP1lEY\\Bf\u000f\u0018V[\u0017f\u007f\u0018]\u001b\u0010\\";
      u[41] = "F}$BYlNj \u0012bbGf)L\u000eP\u0013't\u0012bkMw \u0010\tcZsp+";
      u[42] = ")gaMR\u0001t0\u007fJn\brkbJnY|5%\u001d\u001eYwu\"'";
      u[43] = "!xh8&y|/v?\u001av\u001epi)wxyv.; \u001b$y)n k$rii\u001a";
      u[44] = "Mq\u000b\u001bZ\u0013Ef\u000fKa\u001dLj\u0006\u0015\r/\u001b,XBZx@zX\u0014\n\u0019Fi^\ta";
      u[45] = "U\u001f3f\u0010LW\u001cw\u001c@V7GlrHH\u000f\u001bc\u001cV\t\u0015\u0019a`FT\n!4r\u001fL\u000eC6a\u0012Hj\u0018c,QV\b\u001ap!U2PK4 \u0015BP@t'/";
      u[46] = "7\u001e\u0014BKfl]C\u0005*b\tA\u0001@GhnGFR\u0010\u000bbMA\u0002T3tA\u0013I*";
      u[47] = ",}$WI<.~`-\u0019&N%{C\u00118vzt-\u000fyl{vQ\u001f$sC#CF<w!!PK8\u0013yp\u0014Jxcy{TMB";
      u[48] = "\u001a \u0000\u0003\u000ee\u001ah\u0015\u0015r}u2\u0007\t\u001fw\u00124@\u001bH\u0014\u001a \u0000\u0003\u000ee\u001ah\u0015\u0015r";
      u[49] = "@\u0001^O\u0003v\u001bB\t\bbp~^KM\u000fx\u0019X\f_X\u001bDW\u000b\nXkD\\K\rb";
      u[50] = "\u0016ZN\u0012C\u001d\u0015^\u0010\u0001?\u0012t\u0003T\u0018R\u0018\u0013\u0005\u0013\n\u0005{N\n\u0014_\u0005\u000bN\u0001TX?";
      u[51] = "@&eC\u0007Z\u0006}\"F=H\u0018\b0\\\\Y\u0011\u001d6PAZ\u0006,[Y\u0006XD-'I[G|{1\u0019\u0001\u001d\f{:Y\u0006'";
      u[52] = "PdIwY^\u0017'\u000b%=@\t\u0010S-Qa\u00173W&WR\u00034_1=VV%\n'AF\u000b:22\u0006PU6N\"[Om`Xr\u0001\u0015\u001d`S2\u0006/";
      u[53] = "\u0018\u007fVQY\u0003\u0005n@\u00120\u0005uw]\u0012]\n\u0012q\u001a\u0000\ni\f/[Q\\\u0015\u001crDi";
      u[54] = "u\u0019\u0007P1p2ZE\u0002Un,i\u0006\u00050l\"Z\u0012\u00028{\u0014J\f\u0010({%\u001d0l,:7\u001f\u0010\u0010<g('\u0005W*9$[\u0015\n5\u00011\u001c\u0003T9}!A\u001cl,:7\u001f\u0010\u0010<g('\u0005W*9$[\u0015\n5\u0001rMEPoqrF\u0005WU";
      u[55] = "2\u00146@S\u0004uWt\u00127\u001ak`,\u001a[)bZ1\u0001M\u0018\u000fSv\u0003\u000f\u0019sC+\u001c7\f4Uu\u0010K\u001ciJMF]L3\u0010=FV\f4*";
      u[56] = "Yo%i?]\u00048;n\u0003Tfg$xn\\\u0001acj9?\\nd?9O\\e$8\u0003";
      u[57] = "9d%F`%$u3\u0005\t&Tl.\u0005d,3ji\u00173OnenB3?nn.E\t";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = u[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(v[var4]);
            u[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = u[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            u[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  u[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(2179453574112191L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = u[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  u[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(2179453574112191L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        u[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(2179453574112191L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 85;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 219;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 120;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 163;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 220;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 208;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 85;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 219;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 120;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/am_C0028",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/am" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Consumer invokeBinding1(DualPassBlurRenderer var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/am_C0028;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/am_C0028", "lambda$new$0", "(Ldev/zprestige/prestige/dt_C0202;)V"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((DualPassBlurRenderer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Consumer invokeBinding2(DualPassBlurRenderer var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/am_C0028;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 5, "dev/zprestige/prestige/am_C0028", "lambda$new$1", "(Ldev/zprestige/prestige/dt_C0202;)V"),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((DualPassBlurRenderer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
