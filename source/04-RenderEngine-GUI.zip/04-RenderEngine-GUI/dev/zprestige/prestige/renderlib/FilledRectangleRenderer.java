package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.NumberUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL20;

public class FilledRectangleRenderer extends PrimitiveRenderer {
   private static FilledRectangleRenderer a = null;
   private static Map b = null;
   private final int c;
   private static final long d = 56609648728153L;
   private static String[] e = null;
   private static String[] f = null;
   private static Map g = new HashMap(13);
   private static long[] h = null;
   private static Integer[] i = null;
   private static Map j = null;
   private static final Object[] k = new Object[93];
   private static final String[] l = new String[93];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;

   private FilledRectangleRenderer(long var1) {
      super("shaders/rounded_pos_color.vert", "shaders/rounded_pos_color.frag", ((56609648728153L ^ (56609648728153L ^ var1)) ^ 27472488939802L));
      var1 = 56609648728153L ^ var1;
      long var3 = var1 ^ 94662511308677L;
      long var5 = var1 ^ 27472488939802L;
      short var10001 = 23000;
      long var10002 = 8447413009359390985L ^ var1;
      short var13 = 32664;
      long var10003 = 4058970104345554760L ^ var1;

      Object[] var8 = new Object[0];
      FilledRectangleRenderer var7 = this;
      GlProgram var12 = var7.aReturningfM_C0295(var8);
      short var14 = 21257;
      var10003 = 8112306678759637978L ^ var1;
      Object[] var10 = new Object[]{"roundness", var3};
      GlProgram var9 = var12;
      this.c = var9.dReturningInt(var10);
   }

   public static void aReturningVoid(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var5 = (RenderContext)var0[1];
      float var6 = (Float)var0[2];
      float var9 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var7 = (Float)var0[5];
      Color var8 = (Color)var0[6];
      float var4 = (Float)var0[7];
      long var2 = (Long)var0[8];
      var2 = 56609648728153L ^ var2;
      long var11 = var2 ^ 67486338833733L;
      FilledRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10008 = invokeBinding1(var8, 3675183440523793567L, var2);
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var4), var11};
      var10012[7] = var10008;
      var10012[6] = var7;
      var10012[5] = var1;
      var10012[4] = var9;
      var10012[3] = var6;
      var10012[2] = var10003;
      var10012[1] = var5;
      var10012[0] = var10;
      invokeBinding2(var10000, var10012, 3677114767178273797L, var2);
   }

   public static void bReturningVoid(Object[] var0) {
      MeshBufferManager var1 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      float var10 = (Float)var0[2];
      float var2 = (Float)var0[3];
      float var4 = (Float)var0[4];
      float var6 = (Float)var0[5];
      Color var3 = (Color)var0[6];
      Vector4f var5 = (Vector4f)var0[7];
      long var7 = (Long)var0[8];
      var7 = 56609648728153L ^ var7;
      long var11 = var7 ^ 102452224819715L;
      FilledRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10008 = invokeBinding3(var3, 7802134033552821209L, var7);
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, var5, var11};
      var10012[7] = var10008;
      var10012[6] = var6;
      var10012[5] = var4;
      var10012[4] = var2;
      var10012[3] = var10;
      var10012[2] = var10003;
      var10012[1] = var9;
      var10012[0] = var1;
      invokeBinding4(var10000, var10012, 7800758097952525123L, var7);
   }

   public static void cReturningVoid(Object[] var0) {
      MeshBufferManager var1 = (MeshBufferManager)var0[0];
      RenderContext var7 = (RenderContext)var0[1];
      Matrix4f var10 = (Matrix4f)var0[2];
      float var9 = (Float)var0[3];
      float var6 = (Float)var0[4];
      float var4 = (Float)var0[5];
      float var8 = (Float)var0[6];
      Color var5 = (Color)var0[7];
      float var11 = (Float)var0[8];
      long var2 = (Long)var0[9];
      var2 = 56609648728153L ^ var2;
      long var12 = var2 ^ 139408791562619L;
      FilledRectangleRenderer var10000 = a;
      Color var14 = var5;
      int var10008 = var14.getRGB();
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var11), var12};
      var10012[7] = var10008;
      var10012[6] = var8;
      var10012[5] = var4;
      var10012[4] = var6;
      var10012[3] = var9;
      var10012[2] = var10;
      var10012[1] = var7;
      var10012[0] = var1;
      Object[] var16 = var10012;
      FilledRectangleRenderer var15 = var10000;
      var15.eReturningVoid(var16);
   }

   public static void dReturningVoid(Object[] var0) {
      MeshBufferManager var8 = (MeshBufferManager)var0[0];
      RenderContext var11 = (RenderContext)var0[1];
      Matrix4f var4 = (Matrix4f)var0[2];
      float var3 = (Float)var0[3];
      float var5 = (Float)var0[4];
      float var10 = (Float)var0[5];
      float var7 = (Float)var0[6];
      Color var9 = (Color)var0[7];
      Vector4f var6 = (Vector4f)var0[8];
      long var1 = (Long)var0[9];
      var1 = 56609648728153L ^ var1;
      long var12 = var1 ^ 76463939806623L;
      FilledRectangleRenderer var10000 = a;
      int var10008 = invokeBinding5(var9, -8369193108110758843L, var1);
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, var6, var12};
      var10012[7] = var10008;
      var10012[6] = var7;
      var10012[5] = var10;
      var10012[4] = var5;
      var10012[3] = var3;
      var10012[2] = var4;
      var10012[1] = var11;
      var10012[0] = var8;
      invokeBinding6(var10000, var10012, -8368316419246805793L, var1);
   }

   private void eReturningVoid(Object[] var1) {
      Matrix4f var12 = (Matrix4f)var1[2];
      float var6 = (Float)var1[3];
      float var11 = (Float)var1[4];
      float var9 = (Float)var1[5];
      float var4 = (Float)var1[6];
      int var5 = (Integer)var1[7];
      Vector4f var2 = (Vector4f)var1[8];
      long var7 = (Long)var1[9];
      var7 = 56609648728153L ^ var7;
      long var13 = var7 ^ 52729691283741L;
      long var15 = var7 ^ 76604199680468L;
      long var17 = var7 ^ 8891533143944L;
      Object[] var21 = new Object[]{var2, var13};
      FilledRectangleRenderer var20 = this;
      DrawPipeline var19 = var20.aReturningdn_C0192(var21);
      Object[] var22 = new Object[]{var17};
      RenderCommandBatcher var10000 = ShapeRenderer.aReturningf4(var22);
      Object[] var24 = new Object[]{new PipelineRenderCommand(var19, invokeBinding7(var5, var12, var6, var11, var4, var9)), var15};
      RenderCommandBatcher var23 = var10000;
      var23.bReturningVoid(var24);
   }

   public static void fReturningVoid(Object[] var0) {
      MeshBufferManager var3 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      float var7 = (Float)var0[2];
      float var8 = (Float)var0[3];
      float var2 = (Float)var0[4];
      float var10 = (Float)var0[5];
      float var6 = (Float)var0[6];
      float var1 = (Float)var0[7];
      Color var11 = (Color)var0[8];
      float var12 = (Float)var0[9];
      long var4 = (Long)var0[10];
      var4 = 56609648728153L ^ var4;
      long var13 = var4 ^ 60272185151574L;
      FilledRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10010 = invokeBinding8(var11, -8057872388198811725L, var4);
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, new Vector4f(var12), var13};
      var10014[9] = var10010;
      var10014[8] = var1;
      var10014[7] = var6;
      var10014[6] = var10;
      var10014[5] = var2;
      var10014[4] = var8;
      var10014[3] = var7;
      var10014[2] = var10003;
      var10014[1] = var9;
      var10014[0] = var3;
      invokeBinding9(var10000, var10014, -8059112821852912442L, var4);
   }

   public static void gReturningVoid(Object[] var0) {
      MeshBufferManager var6 = (MeshBufferManager)var0[0];
      RenderContext var4 = (RenderContext)var0[1];
      float var3 = (Float)var0[2];
      float var2 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var11 = (Float)var0[5];
      float var5 = (Float)var0[6];
      float var12 = (Float)var0[7];
      Color var10 = (Color)var0[8];
      Vector4f var9 = (Vector4f)var0[9];
      long var7 = (Long)var0[10];
      var7 = 56609648728153L ^ var7;
      long var13 = var7 ^ 87335118875573L;
      FilledRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10010 = invokeBinding10(var10, -6066394335796523952L, var7);
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, var9, var13};
      var10014[9] = var10010;
      var10014[8] = var12;
      var10014[7] = var5;
      var10014[6] = var11;
      var10014[5] = var1;
      var10014[4] = var2;
      var10014[3] = var3;
      var10014[2] = var10003;
      var10014[1] = var4;
      var10014[0] = var6;
      invokeBinding11(var10000, var10014, -6067687726797652187L, var7);
   }

   public static void hReturningVoid(Object[] var0) {
      MeshBufferManager var4 = (MeshBufferManager)var0[0];
      RenderContext var7 = (RenderContext)var0[1];
      Matrix4f var10 = (Matrix4f)var0[2];
      float var12 = (Float)var0[3];
      float var2 = (Float)var0[4];
      float var11 = (Float)var0[5];
      float var1 = (Float)var0[6];
      float var9 = (Float)var0[7];
      float var8 = (Float)var0[8];
      Color var3 = (Color)var0[9];
      float var13 = (Float)var0[10];
      long var5 = (Long)var0[11];
      var5 = 56609648728153L ^ var5;
      long var14 = var5 ^ 105446045030224L;
      FilledRectangleRenderer var10000 = a;
      int var10010 = invokeBinding12(var3, -7554006658723467083L, var5);
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, new Vector4f(var13), var14};
      var10014[9] = var10010;
      var10014[8] = var8;
      var10014[7] = var9;
      var10014[6] = var1;
      var10014[5] = var11;
      var10014[4] = var2;
      var10014[3] = var12;
      var10014[2] = var10;
      var10014[1] = var7;
      var10014[0] = var4;
      invokeBinding13(var10000, var10014, -7553048259040099392L, var5);
   }

   public static void iReturningVoid(Object[] var0) {
      MeshBufferManager var5 = (MeshBufferManager)var0[0];
      RenderContext var8 = (RenderContext)var0[1];
      Matrix4f var10 = (Matrix4f)var0[2];
      float var7 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var2 = (Float)var0[5];
      float var6 = (Float)var0[6];
      float var4 = (Float)var0[7];
      float var3 = (Float)var0[8];
      Color var11 = (Color)var0[9];
      Vector4f var9 = (Vector4f)var0[10];
      long var12 = (Long)var0[11];
      var12 = 56609648728153L ^ var12;
      long var14 = var12 ^ 43865450276190L;
      FilledRectangleRenderer var10000 = a;
      int var10010 = invokeBinding14(var11, -1935211979023039813L, var12);
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, null, var9, var14};
      var10014[9] = var10010;
      var10014[8] = var3;
      var10014[7] = var4;
      var10014[6] = var6;
      var10014[5] = var2;
      var10014[4] = var1;
      var10014[3] = var7;
      var10014[2] = var10;
      var10014[1] = var8;
      var10014[0] = var5;
      invokeBinding15(var10000, var10014, -1936452584272154162L, var12);
   }

   private void jReturningVoid(Object[] var1) {
      MeshBufferManager var4 = (MeshBufferManager)var1[0];
      Matrix4f var6 = (Matrix4f)var1[2];
      float var2 = (Float)var1[3];
      float var9 = (Float)var1[4];
      float var3 = (Float)var1[5];
      float var12 = (Float)var1[6];
      float var14 = (Float)var1[7];
      float var5 = (Float)var1[8];
      int var13 = (Integer)var1[9];
      Vector4f var8 = (Vector4f)var1[10];
      long var10 = (Long)var1[11];
      var10 = 56609648728153L ^ var10;
      long var15 = var10 ^ 60479715530895L;
      long var17 = var10 ^ 10792333744386L;
      long var19 = var10 ^ 122202859543143L;
      long var21 = var10 ^ 54056729721755L;
      long var23 = var10 ^ 59980522064234L;
      long var25 = var10 ^ 66469932903388L;
      float var27 = invokeBinding16(var12 - var2, -2871315497021408735L, var10);
      float var28 = invokeBinding17(var14 - var9, -2871315497021408735L, var10);
      GlBufferMeshBuilder var10000 = (GlBufferMeshBuilder)invokeBinding19(
         invokeBinding18(this, new Object[]{var4, var8, var19}, -2872968385350969777L, var10), new Object[]{var15}, -2865830408957319326L, var10
      );
      Object[] var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var5;
      var10007[2] = var14;
      var10007[1] = var2;
      var10007[0] = var6;
      var10000 = invokeBinding22(
         invokeBinding21(
            invokeBinding20(var10000, var10007, -2871879129168837181L, var10), new Object[]{new float[]{0.0F, 0.0F}, var17}, -2865934736208679428L, var10
         ),
         new Object[]{new float[]{var27, var28}, var17},
         -2865934736208679428L,
         var10
      );
      Object[] var10004 = new Object[]{null, var21};
      var10004[0] = var13;
      var10000 = invokeBinding23(var10000, var10004, -2871504702575826645L, var10);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var5;
      var10007[2] = var14;
      var10007[1] = var12;
      var10007[0] = var6;
      var10000 = invokeBinding26(
         invokeBinding25(
            invokeBinding24(var10000, var10007, -2871879129168837181L, var10), new Object[]{new float[]{var27, 0.0F}, var17}, -2865934736208679428L, var10
         ),
         new Object[]{new float[]{var27, var28}, var17},
         -2865934736208679428L,
         var10
      );
      var10004 = new Object[]{null, var21};
      var10004[0] = var13;
      var10000 = invokeBinding27(var10000, var10004, -2871504702575826645L, var10);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var3;
      var10007[2] = var9;
      var10007[1] = var12;
      var10007[0] = var6;
      var10000 = invokeBinding30(
         invokeBinding29(
            invokeBinding28(var10000, var10007, -2871879129168837181L, var10), new Object[]{new float[]{var27, var28}, var17}, -2865934736208679428L, var10
         ),
         new Object[]{new float[]{var27, var28}, var17},
         -2865934736208679428L,
         var10
      );
      var10004 = new Object[]{null, var21};
      var10004[0] = var13;
      var10000 = invokeBinding31(var10000, var10004, -2871504702575826645L, var10);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var3;
      var10007[2] = var9;
      var10007[1] = var2;
      var10007[0] = var6;
      var10000 = invokeBinding34(
         invokeBinding33(
            invokeBinding32(var10000, var10007, -2871879129168837181L, var10), new Object[]{new float[]{0.0F, var28}, var17}, -2865934736208679428L, var10
         ),
         new Object[]{new float[]{var27, var28}, var17},
         -2865934736208679428L,
         var10
      );
      var10004 = new Object[]{null, var21};
      var10004[0] = var13;
      invokeBinding37(
         (GlBufferMeshBuilder)invokeBinding36(
            invokeBinding35(var10000, var10004, -2871504702575826645L, var10), new Object[]{PrimitiveMode.QUADS, var25}, -2865461601526739494L, var10
         ),
         new Object[0],
         -2865679222100484698L,
         var10
      );
   }

   protected DrawPipeline aReturningdn_C0192(Object[] var1) {
      Vector4f var4 = (Vector4f)var1[0];
      long var2 = (Long)var1[1];
      var2 = 56609648728153L ^ var2;
      long var5 = var2 ^ 57492166696238L;
      long var7 = var2 ^ 114262763005021L;
      Object[] var12 = new Object[]{var4, var7};
      Vector4f var10 = NumberUtil.aReturningVector4f(var12);
      int var10000 = Event.bReturningInt();
      Vector4f var14 = var10;
      Map var13 = b;
      DrawPipeline var11 = (DrawPipeline)var13.get(var14);
      int var9 = var10000;
      int var29 = var9;
      DrawPipeline var28 = var11;
      DrawPipeline var27 = var28;
      DrawPipeline var26 = var28;
      if (var29 == 0) {
         DrawPipeline var30 = var26;
         if (var30 == null) {
            VertexFormat var10002 = VertexFormats.e;
            short var10005 = 10576;
            long var10006 = 5069913481623410851L ^ var2;
            RenderState[] var32 = new RenderState[]{RenderState.a, null, null, null, null, null};
            Object[] var17 = new Object[0];
            FilledRectangleRenderer var16 = this;
            Object[] var18 = new Object[]{var16.aReturningfM_C0295(var17)};
            var32[1] = RenderState.aReturninggH_C0339(var18);
            short var10008 = 14716;
            long var10009 = 3377121205145667726L ^ var2;
            Object[] var10011 = new Object[]{null, true};
            var10011[0] = 2884;
            Object[] var19 = var10011;
            var32[2] = RenderState.aReturninggF_C0335(var19);
            var10011 = new Object[]{null, true};
            var10011[0] = true;
            Object[] var20 = var10011;
            var32[3] = RenderState.aReturninggI_C0341(var20);
            var10008 = 16703;
            var10009 = 2915027173454704840L ^ var2;
            short var35 = 30774;
            long var10010 = 1653974219176790471L ^ var2;
            var10011 = new Object[]{null, 515};
            var10011[0] = 515;
            Object[] var21 = var10011;
            var32[4] = RenderState.aReturninggD_C0331(var21);
            Object[] var22 = new Object[]{invokeBinding38(this, var10)};
            var32[5] = RenderState.aReturningfP_C0301(var22);
            var11 = new DrawPipeline(var10002, 4, false, var32, var5);
            DrawPipeline var25 = var11;
            Vector4f var24 = var10;
            Map var23 = b;
            var23.put(var24, var25);
         }

         var27 = var11;
      }

      return var27;
   }

   protected GlBufferMeshBuilder aReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      Vector4f var4 = (Vector4f)var1[1];
      long var2 = (Long)var1[2];
      var2 = 56609648728153L ^ var2;
      long var6 = var2 ^ 8811004366108L;
      long var8 = var2 ^ 70850095130153L;
      return invokeBinding40(
         var5, new Object[]{invokeBinding39(this, new Object[]{var4, var6}, -7341678053942969093L, var2), var8}, -7348704738173407435L, var2
      );
   }

   private void lambda$getRenderLayer$1(Vector4f var1, RenderPass var2) {
      Vector4f var5 = var1;
      Vector4f var6 = var1;
      Vector4f var7 = var1;
      Vector4f var8 = var1;
      float var13 = var8.w;
      float var12 = var7.z;
      float var11 = var6.y;
      float var10 = var5.x;
      int var9 = this.c;
      GL20.glUniform4f(var9, var10, var11, var12, var13);
   }

   private static void lambda$drawInternal$0(int var0, Matrix4f var1, float var2, float var3, float var4, float var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 125219309302972L ^ 134605434336262L;
      var10001 = 125219309302972L ^ 53851899127968L;
      var10001 = 125219309302972L ^ 52345010565933L;
      var10001 = 125219309302972L ^ 62903550728023L;
      var10001 = 125219309302972L ^ 124356454893397L;
      var10001 = 125219309302972L ^ 20446120844006L;
      var10001 = 125219309302972L ^ 80014842800288L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var25 = var10003;
      int var24 = ShapeRenderer.bReturningInt(var25);
      Object[] var27 = new Object[]{12707221340346L};
      MeshDataConsumer var26 = var7;
      MeshDataConsumer var10000 = var26.kReturningVoid(var27);
      float var92 = var3 + var4;
      Float var28 = var6;
      float var10004 = var28;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var92;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var30 = var10007;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.dReturningMeshDataConsumer(var30);
      Object[] var32 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var31 = var10000;
      var10000 = var31.bReturningMeshDataConsumer(var32);
      Object[] var34 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var33 = var10000;
      var10000 = var33.bReturningMeshDataConsumer(var34);
      Object[] var94 = new Object[]{null, 103875423078289L};
      var94[0] = var24;
      Object[] var36 = var94;
      MeshDataConsumer var35 = var10000;
      var10000 = var35.eReturningMeshDataConsumer(var36);
      float var10002 = var2 + var5;
      float var93 = var3 + var4;
      Float var37 = var6;
      var10004 = var37;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var93;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var39 = var10007;
      MeshDataConsumer var38 = var10000;
      var10000 = var38.dReturningMeshDataConsumer(var39);
      Object[] var41 = new Object[]{new float[]{var5, 0.0F}, 62839871708188L};
      MeshDataConsumer var40 = var10000;
      var10000 = var40.bReturningMeshDataConsumer(var41);
      Object[] var43 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var42 = var10000;
      var10000 = var42.bReturningMeshDataConsumer(var43);
      Object[] var96 = new Object[]{null, 103875423078289L};
      var96[0] = var24;
      Object[] var45 = var96;
      MeshDataConsumer var44 = var10000;
      var10000 = var44.eReturningMeshDataConsumer(var45);
      var10002 = var2 + var5;
      Float var46 = var6;
      var10004 = var46;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var48 = var10007;
      MeshDataConsumer var47 = var10000;
      var10000 = var47.dReturningMeshDataConsumer(var48);
      Object[] var50 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var49 = var10000;
      var10000 = var49.bReturningMeshDataConsumer(var50);
      Object[] var52 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var51 = var10000;
      var10000 = var51.bReturningMeshDataConsumer(var52);
      Object[] var98 = new Object[]{null, 103875423078289L};
      var98[0] = var24;
      Object[] var54 = var98;
      MeshDataConsumer var53 = var10000;
      var10000 = var53.eReturningMeshDataConsumer(var54);
      Float var55 = var6;
      var10004 = var55;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var57 = var10007;
      MeshDataConsumer var56 = var10000;
      var10000 = var56.dReturningMeshDataConsumer(var57);
      Object[] var59 = new Object[]{new float[]{0.0F, var4}, 62839871708188L};
      MeshDataConsumer var58 = var10000;
      var10000 = var58.bReturningMeshDataConsumer(var59);
      Object[] var61 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var60 = var10000;
      var10000 = var60.bReturningMeshDataConsumer(var61);
      Object[] var100 = new Object[]{null, 103875423078289L};
      var100[0] = var24;
      Object[] var63 = var100;
      MeshDataConsumer var62 = var10000;
      var10000 = var62.eReturningMeshDataConsumer(var63);
      Object[] var65 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var64 = var10000;
      var10000 = var64.iReturningVoid(var65);
      Object[] var67 = new Object[]{80089257141227L};
      MeshDataConsumer var66 = var10000;
      var66.hReturningMeshDataConsumer(var67);
   }

   static {

      {

      long var10001 = 57510213060955L ^ 21814302210338L;
      var10001 = 57510213060955L ^ 38899359766093L;
      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(57510213060955L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[3];
      String var15 = "ª4m¨5¥8rbµæwô\u0018WU\u0088ß³Óý´_NÊ\u001b¦Òöë\u001c;\u0092Æ\u009f\u009dý\u008dø@Æª\u0090é¸ÿä¢\u007f¯MmC9\u00ad\u00920\u009eqãWäd\u007fIúwÒ3§f@¤ð\u008d9ÍÕ2f\u001d)JÌxa\u0083?ìB\u001dÍ\u0097W\u0090Uj\u0017Ðv¿9¬\u000eø 3\"(ìÝá\u001c.V:\u000bÆò0Èq\u001eR:!Ð©\u0083Sö\u008fßh\u0090v\be";
      int var17 = "ª4m¨5¥8rbµæwô\u0018WU\u0088ß³Óý´_NÊ\u001b¦Òöë\u001c;\u0092Æ\u009f\u009dý\u008dø@Æª\u0090é¸ÿä¢\u007f¯MmC9\u00ad\u00920\u009eqãWäd\u007fIúwÒ3§f@¤ð\u008d9ÍÕ2f\u001d)JÌxa\u0083?ìB\u001dÍ\u0097W\u0090Uj\u0017Ðv¿9¬\u000eø 3\"(ìÝá\u001c.V:\u000bÆò0Èq\u001eR:!Ð©\u0083Sö\u008fßh\u0090v\be"
         .length();
      char var14 = '8';
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var39 = a(var19).intern();
         
         if ((var13 += var14) >= var17) {
            e = var18;
            break;
         }
         var14 = var15.charAt(var13);
            f = new String[3];
            j = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(57510213060955L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[5];
            String var4 = "\u001e&4\u008añ\u001aù@\u007f\u0091Xç;\u0097%[eºÀåÂß2}";
            int var5 = "\u001e&4\u008añ\u001aù@\u007f\u0091Xç;\u0097%[eºÀåÂß2}".length();
            label32:
            while (true) {
               int var35 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var35, var2).getBytes("ISO-8859-1");
               long[] var30 = var6;
               int var36 = var3++;
               long var42 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               
                  long var8 = var42;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var48 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var45) {
                     case 0:
                        var30[var36] = var48;
                        if (var2 >= var5) {
                           h = var6;
                           i = new Integer[5];
                           a = new FilledRectangleRenderer(43538795065465L);
                           short var31 = 18908;
                           var10001 = 1005316102703331170L;
                           Object[] var47 = new Object[]{null, 25489915207446L};
                           var47[0] = 128;
                           Object[] var26 = var47;
                           b = NumberUtil.aReturningMap(var26);
                           break;
                        }
                        break;
                     default:
                        var30[var36] = var48;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "£=\u0090«\u008foÞ\u0016ôÙÚG»KË\u0006";
                        var5 = "£=\u0090«\u008foÞ\u0016ôÙÚG»KË\u0006".length();
                        var2 = 0;
                  }

                  int var37 = var2;
                  var2 += 8;
                  var7 = var4.substring(var37, var2).getBytes("ISO-8859-1");
                  var30 = var6;
                  var36 = var3++;
                  var42 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var45 = 0;
               }
            }
         }

      }

      
    }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 14577;
      if (f[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])g.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/df", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = e[var5].getBytes("ISO-8859-1");
         f[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return f[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/df_C0176",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/df" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32445;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/df", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/df_C0176",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/df" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 26;
            yield var16;
         }
         case 2 -> {
            byte var17 = 33;
            yield var17;
         }
         case 3 -> {
            byte var18 = 28;
            yield var18;
         }
         case 4 -> {
            byte var19 = 35;
            yield var19;
         }
         case 5 -> {
            byte var20 = 23;
            yield var20;
         }
         case 6 -> {
            byte var21 = 13;
            yield var21;
         }
         case 7 -> {
            byte var22 = 49;
            yield var22;
         }
         case 8 -> {
            byte var23 = 57;
            yield var23;
         }
         case 9 -> {
            byte var24 = 12;
            yield var24;
         }
         case 10 -> {
            byte var25 = 18;
            yield var25;
         }
         case 11 -> {
            byte var26 = 51;
            yield var26;
         }
         case 12 -> {
            byte var27 = 22;
            yield var27;
         }
         case 13 -> {
            byte var28 = 11;
            yield var28;
         }
         case 14 -> {
            byte var29 = 6;
            yield var29;
         }
         case 15 -> {
            byte var30 = 41;
            yield var30;
         }
         case 16 -> {
            byte var31 = 40;
            yield var31;
         }
         case 17 -> {
            byte var32 = 29;
            yield var32;
         }
         case 18 -> {
            byte var33 = 53;
            yield var33;
         }
         case 19 -> {
            byte var34 = 52;
            yield var34;
         }
         case 20 -> {
            byte var35 = 5;
            yield var35;
         }
         case 21 -> {
            byte var36 = 2;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 4;
            yield var38;
         }
         case 24 -> {
            byte var39 = 9;
            yield var39;
         }
         case 25 -> {
            byte var40 = 34;
            yield var40;
         }
         case 26 -> {
            byte var41 = 24;
            yield var41;
         }
         case 27 -> {
            byte var42 = 39;
            yield var42;
         }
         case 28 -> {
            byte var43 = 58;
            yield var43;
         }
         case 29 -> {
            byte var44 = 27;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 44;
            yield var46;
         }
         case 32 -> {
            byte var47 = 19;
            yield var47;
         }
         case 33 -> {
            byte var48 = 8;
            yield var48;
         }
         case 34 -> {
            byte var49 = 37;
            yield var49;
         }
         case 35 -> {
            byte var50 = 56;
            yield var50;
         }
         case 36 -> {
            byte var51 = 50;
            yield var51;
         }
         case 37 -> {
            byte var52 = 1;
            yield var52;
         }
         case 38 -> {
            byte var53 = 25;
            yield var53;
         }
         case 39 -> {
            byte var54 = 61;
            yield var54;
         }
         case 40 -> {
            byte var55 = 15;
            yield var55;
         }
         case 41 -> {
            byte var56 = 42;
            yield var56;
         }
         case 42 -> {
            byte var57 = 14;
            yield var57;
         }
         case 43 -> {
            byte var58 = 32;
            yield var58;
         }
         case 44 -> {
            byte var59 = 55;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 16;
            yield var62;
         }
         case 48 -> {
            byte var63 = 47;
            yield var63;
         }
         case 49 -> {
            byte var64 = 0;
            yield var64;
         }
         case 50 -> {
            byte var65 = 60;
            yield var65;
         }
         case 51 -> {
            byte var66 = 48;
            yield var66;
         }
         case 52 -> {
            byte var67 = 54;
            yield var67;
         }
         case 53 -> {
            byte var68 = 38;
            yield var68;
         }
         case 54 -> {
            byte var69 = 7;
            yield var69;
         }
         case 55 -> {
            byte var70 = 17;
            yield var70;
         }
         case 56 -> {
            byte var71 = 10;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 21;
            yield var74;
         }
         case 60 -> {
            byte var75 = 59;
            yield var75;
         }
         case 61 -> {
            byte var76 = 31;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 45;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      k[0] = "\u001d.ts^\u0019\u000b.q)M\u000e\u001cer/A\u001a\r\"e8\n\b\u0017";
      k[1] = "qHr%4}\u0004hy*%2efr!!h\u0011";
      k[2] = "C\u0014D\u0014ILU\u0014ANZ[B_BHVOS\u0018U_\u001d^v";
      k[3] = "\u0014\"W9JY\u0002\"RcYN\u0015iQeUZ\u0004.Fr\u001eM\u0016";
      k[4] = "w<b\r\u0011\r\u0002\u001ci\u0002\u0000Bc\u0012b\t\u0004\u0018\u0017";
      k[5] = "\"FD\u00151\u00114FAO\"\u0006#\rBI.\u00122JU^e\u0005(";
      k[6] = "\t=\u0014d@\u0012\u001f=\u0011>S\u0005\bv\u00128_\u0011\u00191\u0005/\u0014\u0001U";
      k[7] = "HE\u0019d>@=e\u0012k/\u000f\\k\u0019`+U(";
      k[8] = "S\u0019\u0002\u001ec&E\u0019\u0007Dp1RR\u0004B|%C\u0015\u0013U70z";
      k[9] = "6\u0007E\u001d\u001e>C'N\u0012\u000fq\")E\u0019\u000b+V";
      k[10] = int.class;
      l[10] = "java/lang/Integer";
      k[11] = ":m\u001c'e.'xD\u0005$#?~";
      k[12] = "B\u000eV5H\u00107.]:Y_V V1]\u0005\"";
      k[13] = void.class;
      l[13] = "java/lang/Void";
      k[14] = "?cl~KyJCgqZ6+Mlz^l_";
      k[15] = "7@\u0013{O,B`\u0018t^c#n\u0013\u007fZ9W";
      k[16] = "M>SuJ\r[>V/Y\u001aLuU)U\u000e]2B>\u001e\u001ej";
      k[17] = "C_A\u001a\rp6\u007fJ\u0015\u001c?WqA\u001e\u0018e#";
      k[18] = "N(!\u0012%0;\b*\u001d4\u007fZ\u0006!\u00160%.";
      k[19] = "v\u000e4@eT\u0003.?Ot\u001bb 4DpA\u0016";
      k[20] = "nq#Mi{\u001bQ(Bx4z_#I|n\u000e";
      k[21] = "Op\u0010\"18:P\u001b- w[^\u0010&$-/";
      k[22] = "^\"\u0011\u0005F\u0004U-\u0000J%\t@+";
      k[23] = float.class;
      l[23] = "java/lang/Float";
      k[24] = "\u000f#V%\u007flz\u0003]*n#\u001b\rV!jyo";
      k[25] = "Nn_D\u001c\u0011;NTK\r^Z@_@\t\u0004.";
      k[26] = "\u0001m*\u001d+\u000e\u0017m/G8\u0019\u0000&,A4\r\u0011a;V\u007f\u001a\u0013";
      k[27] = "(I\u001d&t<]i\u0016)es<g\u001d\"a)H";
      k[28] = "\u0001\b\bkfn\n\u0007\u0019$\u000en\u0004\b\n";
      k[29] = "5\fqC\u001ag@,zL\u000b(!\"qG\u000frU";
      k[30] = "V|vcc`#\\}lr/BRvgvu6";
      k[31] = "X\np\u0011AeZ\u00149iNiC\u0017e\u000bM";
      k[32] = "+22-G_.'9-DX!.2o\u0005o\bre";
      k[33] = "\u0002J_!\u000b$\u0014JZ{\u00183\u0003\u0001Y}\u0014'\u0012FNj_2S";
      k[34] = "3b:n\u0017eFB1a\u0006*'L:j\u0002pS";
      k[35] = "\u0001Y=\u0018\u001bq\u001fQ'Wxe\u001b";
      k[36] = "\u001aXfur}oxmzc2\u000evfqghz";
      k[37] = "\u000f\u0003R[-\u0010\u0019\u0003W\u0001>\u0007\u000eHT\u00072\u0013\u001f\u000fC\u0010y\u0006_";
      k[38] = "%\u001byAAPP;rNP\u001f15yETEE";
      k[39] = "kFJZ\t#\u001efAU\u0018l\u007fhJ^\u001c6\u000b";
      k[40] = "1n#|\\z'n&&Om0%% Cy!b27\bl\u0005";
      k[41] = "O
      k[42] = "QOjN\u0013XGOo\u0014\u0000OP\u0004l\u0012\f[AC{\u0005GOq";
      k[43] = "0D\u000es#x&D\u000b)0o1\u000f\b/<{ H\u001f8wi\u0011";
      k[44] = "!\u0000r\u0007E\u0000*\u000fcH&\r?\u0002l#\u0013\u000f.\u0011p\u000f\u0004\u0002";
      k[45] = "(h*L'.]H!C6a<F*H2;H";
      k[46] = "h\u000bN\u0007\u0002z\u001d+E\b\u00135|%N\u0003\u0017o\b";
      k[47] = "V; \u0000#\u0012@;%Z0\u0005Wp&\\<\u0011F71Kw\u0005t";
      k[48] = "oe\u001c\u001c#;\u001aE\u0017\u00132t{K\u001c\u00186.\u000f";
      k[49] = "\u0002Ud.\u001aB\tZua{L\u0002Qq;";
      k[50] = ")\u0013f\b-\u001b\\3m\u0007<T==f\f8\u000eI";
      k[51] = "\t=\u0019t+\u0010\u001f=\u001c.8\u0007\bv\u001f(4\u0013\u00191\b?\u007f\u0007$";
      k[52] = "Z44pI\u001b/\u0014?\u007fXTN\u001a4t\\\u000e:";
      k[53] = "~(\r#\u0018|h(\by\u000bk\u007fc\u000b\u007f\u0007\u007fn$\u001chLkR";
      k[54] = "f\u0002yOQtsWyO`)\fRp[\u001f\u007f<\u0016*]P/\f\u0001!\u0005\u001bu<\u0014t\u0005\u001bD";
      k[55] = "E&\u00179\u0012?\u0001?\u0012q,*<vL&S{\f2\u0016 \u001c+<~E&P0\u00044\u000b,^@";
      k[56] = "g\u0011\u0000H\u0002\n?\u000f\u0018\b}\u0015^JA\u001c\u0002Nn\u000e\u001b\u001aM\u001e^J\u001b\nF\n!\u0012\u0005\u0012\u0006u";
      k[57] = "m\u000f@\b[\u0018z\u0013@I6\u0012\u0017G\u0005\u0017I@'\u0003_\u0011\u0006\u0010\u0017\u0002E\u0012R\u0007-\u0012LG\\{";
      k[58] = ")H^Q->'\f\u0004PGeU\rIS'\u007f5^\u0003C%\u000f";
      k[59] = "n^(\n4i{\u000b(\n\u00058\u0004\u000e!\u001ezb4J{\u001852\u0004]p@~h4H%@~Y";
      k[60] = "b&d\u0011)K:8|QV^[}%E)\u000fk9\u007fCf_[}\u007fSmK$%aK-4";
      k[61] = "y0M\u000f<B?0Ts,)ysY\f~\u0019=)_C.)y)OH:V!7W\bE";
      k[62] = ";B<WBl.\u0017<Ws?Q\u00125C\fgaVoEC7QAd\u001d\bmaT1\u001d\b\\";
      k[63] = "|0\u001d\u0019\rM`8F\u0018f\u0013}\f\u0019\u001d\b\u001bc4C\u0012fBk8\u001f\f\u0006\u0011!(\u001d|\b\fei\u001cA_\u0004!4\u007f\u0012\u0016\u0000!2BE\u001eD|Q\u0011\f\u001aDzlF\u0004^\u0019\u0019?\u000f\u0000^\u001f$h\u0007D\u0003|(`\u0010\u0000\u0016Db.\u001a\u000ef";
      k[64] = "\u001bN8aG\u001cCP !8\u000f\"\u0015y5GX\u0012Q#3\b\b\"\u0015##\u0003\u001c]M=;Cc";
      k[65] = "\u0001o8w-~\u0007 2%C?e~%4{,X)-p&";
      k[66] = "\u0007\u001bmPd*\u0010\u0007m\u0011\t }S(OvrM\u0017rI9\"}\u0010a]y$\u001e\u0007}]8I";
      k[67] = "s\u0017oo4\u0011{\u0001zxI\u001fy\u000f\u0000q%\r.\u0011ea,\u000e}sql4Jv\u0016ae7\u0019\u0014";
      k[68] = "`M=c\u001bZwQ=\"vP\u001a\u0005x|\t\u0002*A\"zFR\u001aN2o\r\bpB+yO9";
      k[69] = "';RctF--\bb\u0016BAi[vi\u0010q-\u0001p&@A7\u0007vyV ?\u0011cn+";
      k[70] = "\u007f+(F:\u0015j~(F\u000bO\u0015{!Rt\u001e%?{T;N\u0015(p\fp\u0014%=%\fp%";
      k[71] = ">!\u001f)V\u00008\u007f\u00145'\u0011\u0004%]*XG4a\u0007,\u0017\u0017\u0004-T*[\f<g\u001a U|";
      k[72] = "x]C/\u0000:}M\u0006.1h|]8\u007fA}.E\u0005(I9s&VaM9u\u001b\u0001i\td\u0016";
      k[73] = "\u0018!6_\u0004$\u001e\u007f=Cu:\"%t\\\nc\u0012a.ZE3\"-}\\\t(\u001ag3V\u0007X";
      k[74] = "\u001f\t4h0F\b\u00154)]LeAqw\"\u001eU\u0005+qmNeAp&bT\u0003\u001e%(g^e";
      k[75] = "nKx\u001fj\u0013h\u0004rM\u0004]\nZe\\<A7\rm\u0018a";
      k[76] = "a\u0006o(xka\u0002$sCk\u0000\u0004,~<90@vxsi\u0000D}r3<\u007f\u0000dw{\u0002";
      k[77] = "*l\u001a?.brr\u0002\u007fQp\u00137[k.&#s\u0001mav\u00137\u0001}jblo\u001fe*\u001d";
      k[78] = "5:v^O=m\"u\u001dw5\tx3C\bg9<iEG7\t\u007f0\u0013M=395J\u0018\\";
      k[79] = "&`\u0002\u0000'= >\t\u001cV(\u001c#@S;\u007fp#\u0005W4AbeG\u0001h-b C\u000eV";
      k[80] = "ud\f\u001b|\u0017s:\u0007\u0007\r\u0002O`N\u0018rP\u007f$\u0014\u001e=\u0000O`\u0014\u000e6\u001408\n\u0016vk";
      k[81] = "\u000e8BfC`\u001bmBfr0dhKr\rkT,\u0011tB;d;\u001a,\taT.O,\tP";
      k[82] = "<s\u0005j\u0005\u0006<wN1>\u0005]qF<ATm5\u001c:\u000e\u0004]v\f:^\u001f=%F*\\o";
      k[83] = "ndd\tH\u001cyxdH%\u0016\u0014,!\u0016ZD$h{\u0010\u0015\u0014\u0014j}\u001b\u001a\u001byod\u0010\u0014\u007f";
      k[84] = "^\u00006TwwT\u0016lU\u0015s8R?Aj!\b\u0016eG%q8\u000fxC*t\t\t7Ix\u001a";
      k[85] = "%}CX\u0005Oz=\u000bGf\u0019#dZ_8\u001e#~^#\b\u0007;;P\u001e_\u000f\u007ff3";
      k[86] = "f0IV\u000b\u000e`\u007fC\u0004eM\u0002!T\u0015]\\?v\\Q\u0000";
      k[87] = "!feS\u0012cgc<\u0006s5\u001fdb\u0006\fb/ 8\u0000C2\u001fc(\u0000\u0013)\u007f0b\u0010\u0011Y";
      k[88] = "WV{9\u001aMQ\u0019qkt\r3GfzL\u001f\u000e\u0010n>\u0011";
      k[89] = "\u00126\u0011\fX0\u0014h\u001a\u0010)%(2S\u000fVw\u0018v\t\t\u0019'(0\nZB\"\u00163\u000b\tIL";
      k[90] = "lD$\u001a):6\u0007=EFo>F\u001bj\f\u0000mH(E6`>\u00028GF";
      k[91] = "~e-s\u001d\u0003vs8d`\u001ad}Bm\f\u001f#c'}\u0005\u001cp\u00013p\u001dX{d#y\u001e\u000b\u0019p.aZ\u0000|`'b\tb";
      k[92] = "WxGa\u0010\fB-Ga!P=(Nu^\u0007\rl\u0014s\u0011W={\u001f+Z\r\rnJ+Z<";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(3492069420688966L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(3492069420688966L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(3492069420688966L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 213;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 102;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 36;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 104;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 105;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 87;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 213;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 102;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 36;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/df_C0176",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/df" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiConsumer invokeBinding7(int var0, Matrix4f var1, float var2, float var3, float var4, float var5) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/df_C0176",
                     "lambda$drawInternal$0",
                     "(ILorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = c(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = c(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = c(MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = c(
                  MethodHandles.lookup(), "i", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding16(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = c(MethodHandles.lookup(), "W", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float invokeBinding17(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = c(MethodHandles.lookup(), "W", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static GlBufferMeshBuilder invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MeshDataConsumer invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cC_C0115;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MeshDataConsumer)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding25(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache25;
         MethodHandle var9 = bindingCache25;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache25 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding26(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding27(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache27;
         MethodHandle var9 = bindingCache27;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache27 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding28(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding29(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding30(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache30;
         MethodHandle var9 = bindingCache30;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache30 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding32(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache32;
         MethodHandle var9 = bindingCache32;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache32 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding34(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache34;
         MethodHandle var9 = bindingCache34;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache34 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding35(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache35;
         MethodHandle var9 = bindingCache35;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache35 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MeshDataConsumer invokeBinding36(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache36;
         MethodHandle var9 = bindingCache36;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache36 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cC_C0115;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MeshDataConsumer)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding37(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache37;
         MethodHandle var9 = bindingCache37;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache37 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Consumer invokeBinding38(FilledRectangleRenderer var0, Vector4f var1) {
         MethodHandle var6 = bindingCache38;
         MethodHandle var5 = bindingCache38;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache38 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/df_C0176;Lorg/joml/Vector4f;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/df_C0176",
                     "lambda$getRenderLayer$1",
                     "(Lorg/joml/Vector4f;Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var3.invokeExact((FilledRectangleRenderer)var0, (Vector4f)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static DrawPipeline invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DrawPipeline)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding40(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache40;
         MethodHandle var9 = bindingCache40;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache40 = c(
                  MethodHandles.lookup(),
                  "i",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
