package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RLUniforms;
import it.unimi.dsi.fastutil.Pair;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.lwjgl.opengl.GL11;

public abstract class FramebufferEffect extends PrimitiveRenderer {
   protected RenderPassSequence c;
   protected int d;
   protected int e;
   protected boolean f;
   public ManagedGlFramebuffer g;
   public ManagedGlTexture h;
   private static final int i;
   protected final Map j;
   private Consumer k;
   private boolean l;
   private static final long n = 105011071835600L;
   private static final long[] s;
   private static final Integer[] t;
   private static final Map u = new HashMap(13);
   private static final Object[] D = new Object[77];
   private static final String[] E = new String[77];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   protected FramebufferEffect(String var1, String var2, long var3) {
      super(var1, var2, false, ((105011071835600L ^ (105011071835600L ^ var3)) ^ 95825290190623L));
      var3 = 105011071835600L ^ var3;
      long var5 = var3 ^ 46376099211033L;
      long var7 = var3 ^ 95825290190623L;
      long var9 = var3 ^ 118995383557337L;

      this.d = -1;
      this.e = -1;
      this.f = dev.prestige.recovery.SourceSupport.asBoolean(0);
      Object[] var11 = new Object[]{var5};
      this.g = ManagedGlFramebuffer.aReturningbR_C0091(var11);
      short var10001 = 3497;
      long var10002 = 4047335900496119499L ^ var3;
      Object[] var10004 = new Object[]{null, var9};
      var10004[0] = 3553;
      Object[] var12 = var10004;
      this.h = ManagedGlTexture.aReturningbT_C0095(var12);
      short var14 = 5825;
      long var10005 = 6167622709193694628L ^ var3;
      this.j = new EffectTextureCache(this, 16, 0.75F, true);
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
   }

   public void aReturningVoid(Object[] var1) {
      MeshBufferManager var2 = (MeshBufferManager)var1[0];
      long var3 = (Long)var1[2];
      var3 = 105011071835600L ^ var3;
      long var6 = var3 ^ 62682885158296L;
      long var8 = var3 ^ 24196572504571L;
      long var10 = var3 ^ 17744485917382L;
      Object[] var13 = new Object[]{var8};
      FramebufferEffect var12 = this;
      var12.gReturningVoid(var13);
      Object[] var15 = new Object[]{var10};
      FramebufferEffect var14 = this;
      var14.fReturningVoid(var15);
      Object[] var17 = new Object[]{var6};
      MeshBufferManager var16 = var2;
      Stream var10000 = var16.aReturningStream(var17);
      Predicate var19 = invokeBinding1();
      Stream var18 = var10000;
      var10000 = var18.filter(var19);
      Consumer var21 = invokeBinding2();
      Stream var20 = var10000;
      var20.forEach(var21);
   }

   public void bReturningVoid(Object[] var1) {
      long var2 = (Long)var1[2];
      var2 = 105011071835600L ^ var2;
      long var6 = var2 ^ 50709314152768L;
      long var8 = var2 ^ 92380852372942L;
      int var10 = Event.bReturningInt();
      int var52 = var10;
      FramebufferEffect var51 = this;
      FramebufferEffect var40 = var51;
      FramebufferEffect var39 = var51;
      if (var52 == 0) {
         boolean var53 = var39.f;
         if (!var53) {
            return;
         }

         FramebufferEffect var54 = this;
         var40 = var54;
      }

      int var56 = var10;
      FramebufferEffect var55 = var40;
      FramebufferEffect var42 = var55;
      FramebufferEffect var41 = var55;
      if (var56 == 0) {
         RenderPassSequence var57 = var41.c;
         if (var57 == null) {
            return;
         }

         var42 = this;
      }

      int var59 = var10;
      byte var58 = ((byte)((var42.l) ? 1 : 0));
      byte var44 = var58;
      byte var43 = var58;
      if (var59 == 0) {
         byte var60 = var43;
         if (var60 == 0) {
            return;
         }

         this.l = dev.prestige.recovery.SourceSupport.asBoolean(0);
         short var10000 = 22347;
         long var10001 = 4789626407481273205L ^ var2;
         var44 = ((byte)((GL11.glGetBoolean(2884)) ? 1 : 0));
      }

      byte var11 = var44;
      short var71 = 22099;
      long var83 = 6388153155315100284L ^ var2;
      byte var12 = ((byte)((GL11.glGetBoolean(3042)) ? 1 : 0));
      var71 = 17042;
      var83 = 2974865367369678522L ^ var2;
      byte var13 = ((byte)((GL11.glGetBoolean(2929)) ? 1 : 0));
      var71 = 31720;
      var83 = 2299588063670912966L ^ var2;
      GL11.glDisable(2884);
      var71 = 22313;
      var83 = 1216445144885259008L ^ var2;
      GL11.glEnable(3042);
      var71 = 22745;
      var83 = 3514216205576594683L ^ var2;
      var71 = 770;
      short var88 = 9720;
      long var10002 = 3333139435762096603L ^ var2;
      GL11.glBlendFunc(770, 771);
      var71 = 24353;
      var83 = 885097801473385216L ^ var2;
      GL11.glDisable(2929);
      RenderPassSequence var78 = this.c;
      Object[] var28 = new Object[]{var8};
      RenderPassSequence var27 = var78;
      var27.aReturningVoid(var28);
      int var62 = var10;
      byte var61 = var13;
      byte var46 = var61;
      byte var45 = var61;
      if (var62 == 0) {
         byte var63 = var45;
         if (var63 != 0) {
            var71 = 24353;
            var83 = 885097801473385216L ^ var2;
            GL11.glEnable(2929);
         }

         var46 = var11;
      }

      int var65 = var10;
      byte var64 = var46;
      byte var48 = var64;
      byte var47 = var64;
      if (var65 == 0) {
         byte var66 = var47;
         if (var66 != 0) {
            var71 = 31720;
            var83 = 2299588063670912966L ^ var2;
            GL11.glEnable(2884);
         }

         var48 = var12;
      }

      label46: {
         int var68 = var10;
         byte var67 = var48;
         short var50 = var67;
         byte var49 = var67;
         if (var68 == 0) {
            byte var69 = var49;
            if (var69 != 0) {
               break label46;
            }

            var71 = 22313;
            var83 = 1216445144885259008L ^ var2;
            var50 = 3042;
         }

         short var36 = var50;
         GL11.glDisable(var36);
      }

      ManagedGlFramebuffer var82 = this.g;
      Object[] var10007 = new Object[]{null, null, null, null, var6};
      var10007[3] = 0.0F;
      var10007[2] = 0.0F;
      var10007[1] = 0.0F;
      var10007[0] = 0.0F;
      Object[] var38 = var10007;
      ManagedGlFramebuffer var37 = var82;
      var37.eReturningVoid(var38);
   }

   public final GlBufferMeshBuilder aReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      int var4 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 105011071835600L ^ var2;
      long var6 = var2 ^ 101247002883775L;
      this.l = dev.prestige.recovery.SourceSupport.asBoolean(1);
      Object[] var10005 = new Object[]{null, null, var6};
      var10005[1] = var4;
      var10005[0] = var5;
      Object[] var9 = var10005;
      FramebufferEffect var8 = this;
      return var8.bReturningGlBufferMeshBuilder(var9);
   }

   protected abstract GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1);

   public abstract RenderPassSequence aReturningc4(Object[] var1);

   protected abstract void cReturningVoid(Object[] var1);

   public final void dReturningVoid(Object[] var1) {
      Consumer var2 = (Consumer)var1[0];
      this.k = var2;
   }

   protected final void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 105011071835600L ^ var2;
      long var4 = var2 ^ 105461353580456L;
      int var10000 = Event.bReturningInt();
      Object[] var9 = new Object[0];
      FramebufferEffect var8 = this;
      GlProgram var10001 = var8.aReturningfM_C0295(var9);
      Object[] var11 = new Object[0];
      GlProgram var10 = var10001;
      int var12 = var10.aReturningInt(var11);
      RLUniforms var7 = RLUniforms.aReturningVoid(var12);
      int var6 = var10000;
      int var23 = var6;
      FramebufferEffect var22 = this;
      FramebufferEffect var21 = var22;
      FramebufferEffect var20 = var22;
      if (var23 == 0) {
         Consumer var24 = var20.k;
         if (var24 != null) {
            RLUniforms var15 = var7;
            Consumer var14 = this.k;
            var14.accept(var15);
            int var25 = var6;
            if (var25 == 0) {
               return;
            }
         }

         FramebufferEffect var26 = this;
         var21 = var26;
      }

      Object[] var19 = new Object[]{var7, var4};
      FramebufferEffect var18 = var21;
      var18.cReturningVoid(var19);
   }

   protected void fReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 105011071835600L ^ var2;
      long var4 = var2 ^ 50060757367526L;
      long var6 = var2 ^ 46501179160107L;
      long var8 = var2 ^ 20819540100603L;
      long var10 = var2 ^ 96490605533009L;
      long var12 = var2 ^ 58380016733499L;
      int var14 = Event.bReturningInt();
      MinecraftClient var17 = a;
      Window var10000 = var17.getWindow();
      int var50 = var14;
      Window var49 = var10000;
      Window var40 = var49;
      Window var39 = var49;
      if (var50 == 0) {
         Window var51 = var39;
         if (var51 == null) {
            return;
         }

         MinecraftClient var19 = a;
         var40 = var19.getWindow();
      }

      Window var20 = var40;
      int var15 = var20.getFramebufferWidth();
      MinecraftClient var21 = a;
      Window var22 = var21.getWindow();
      int var16 = var22.getFramebufferHeight();
      int var53 = var14;
      int var52 = var15;
      int var42 = var52;
      int var41 = var52;
      if (var53 == 0) {
         int var54 = var41;
         if (var54 <= 0) {
            return;
         }

         var42 = var16;
      }

      FramebufferEffect var48;
      label56: {
         int var56 = var14;
         int var55 = var42;
         int var45 = var55;
         int var43 = var55;
         if (var56 == 0) {
            int var57 = var43;
            if (var57 <= 0) {
               return;
            }

            int var59 = var14;
            FramebufferEffect var58 = this;
            var48 = var58;
            FramebufferEffect var44 = var58;
            if (var59 != 0) {
               break label56;
            }

            int var60 = var44.d;
            var45 = var60;
         }

         int var62 = var15;
         int var61 = var45;
         if (var61 == var62) {
            int var64 = var14;
            FramebufferEffect var63 = this;
            var48 = var63;
            FramebufferEffect var46 = var63;
            if (var64 != 0) {
               break label56;
            }

            FramebufferEffect var65 = var46;
            FramebufferEffect var47 = var65;
            int var67 = var16;
            int var66 = var47.e;
            if (var66 == var67) {
               return;
            }
         }

         this.d = var15;
         this.e = var16;
         ManagedGlTexture var10001 = this.h;
         int var10002 = this.d;
         int var10003 = this.e;
         Object[] var10006 = new Object[]{null, null, var4};
         var10006[1] = var10003;
         var10006[0] = var10002;
         Object[] var29 = var10006;
         ManagedGlTexture var28 = var10001;
         this.h = var28.cReturningbT_C0095(var29);
         ManagedGlTexture var70 = this.h;
         short var74 = 11961;
         long var77 = 1935882249709047285L ^ var2;
         Object[] var10004 = new Object[]{null, var8};
         var10004[0] = 9729;
         Object[] var31 = var10004;
         ManagedGlTexture var30 = var70;
         var30.bReturningVoid(var31);
         ManagedGlTexture var71 = this.h;
         short var75 = 24441;
         long var78 = 4299091814427376694L ^ var2;
         var10004 = new Object[]{null, var12};
         var10004[0] = 33071;
         Object[] var33 = var10004;
         ManagedGlTexture var32 = var71;
         var32.eReturningVoid(var33);
         ManagedGlFramebuffer var72 = this.g;
         short var76 = 17545;
         long var79 = 3142770217743919048L ^ var2;
         Object[] var10005 = new Object[]{null, this.h, var10};
         var10005[0] = 36064;
         Object[] var35 = var10005;
         ManagedGlFramebuffer var34 = var72;
         var34.bReturningVoid(var35);
         FramebufferEffect var68 = this;
         var48 = var68;
      }

      ManagedGlFramebuffer var73 = var48.g;
      Object[] var10007 = new Object[]{null, null, null, null, var6};
      var10007[3] = 0.0F;
      var10007[2] = 0.0F;
      var10007[1] = 0.0F;
      var10007[0] = 0.0F;
      Object[] var38 = var10007;
      ManagedGlFramebuffer var37 = var73;
      var37.eReturningVoid(var38);
   }

   protected void gReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 105011071835600L ^ var2;
      long var4 = var2 ^ 40786668324792L;
      long var6 = var2 ^ 48825852998934L;
      long var8 = var2 ^ 22873596397254L;
      long var10 = var2 ^ 62643891993700L;
      long var12 = var2 ^ 90036365694060L;
      long var14 = var2 ^ 56325978754566L;
      int var16 = Event.bReturningInt();
      int var37 = var16;
      FramebufferEffect var36 = this;
      FramebufferEffect var35 = var36;
      FramebufferEffect var34 = var36;
      if (var37 == 0) {
         boolean var38 = var34.f;
         if (var38) {
            return;
         }

         MinecraftClient var18 = a;
         Window var19 = var18.getWindow();
         this.d = var19.getFramebufferWidth();
         MinecraftClient var20 = a;
         Window var21 = var20.getWindow();
         this.e = var21.getFramebufferHeight();
         ManagedGlTexture var10000 = this.h;
         short var10001 = 18918;
         long var10002 = 3647371185218644381L ^ var2;
         int var48 = this.d;
         int var10003 = this.e;
         Object[] var10006 = new Object[]{null, null, null, var4};
         var10006[2] = var10003;
         var10006[1] = var48;
         var10006[0] = 33323;
         Object[] var23 = var10006;
         ManagedGlTexture var22 = var10000;
         var22.cReturningVoid(var23);
         var10000 = this.h;
         var10001 = 4832;
         var10002 = 5066691537002967689L ^ var2;
         Object[] var10004 = new Object[]{null, var8};
         var10004[0] = 9729;
         Object[] var25 = var10004;
         ManagedGlTexture var24 = var10000;
         var24.bReturningVoid(var25);
         var10000 = this.h;
         var10001 = 17896;
         var10002 = 3226128458978256283L ^ var2;
         var10004 = new Object[]{null, var14};
         var10004[0] = 33071;
         Object[] var27 = var10004;
         ManagedGlTexture var26 = var10000;
         var26.eReturningVoid(var27);
         ManagedGlFramebuffer var43 = this.g;
         var10001 = 12781;
         var10002 = 3903154920606765469L ^ var2;
         Object[] var10005 = new Object[]{null, this.h, var12};
         var10005[0] = 36064;
         Object[] var29 = var10005;
         ManagedGlFramebuffer var28 = var43;
         var28.bReturningVoid(var29);
         ManagedGlFramebuffer var44 = this.g;
         Object[] var10007 = new Object[]{null, null, null, null, var6};
         var10007[3] = 0.0F;
         var10007[2] = 0.0F;
         var10007[1] = 0.0F;
         var10007[0] = 0.0F;
         Object[] var31 = var10007;
         ManagedGlFramebuffer var30 = var44;
         var30.eReturningVoid(var31);
         Object[] var33 = new Object[]{var10};
         FramebufferEffect var32 = this;
         this.c = var32.aReturningc4(var33);
         FramebufferEffect var39 = this;
         var35 = var39;
      }

      var35.f = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   private static void lambda$render$1(Pair var0) {
      long var10001 = 53176337001159L ^ 53489766996270L;
      Pair var5 = var0;
      GlBufferMeshBuilder var10000 = (GlBufferMeshBuilder)var5.value();
      Object[] var7 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      GlBufferMeshBuilder var6 = var10000;
      var6.iReturningVoid(var7);
   }

   private static boolean lambda$render$0(Pair var0) {
      Pair var3 = var0;
      DrawPipeline var10000 = (DrawPipeline)var3.key();
      Object[] var5 = new Object[0];
      DrawPipeline var4 = var10000;
      return var4.bReturningBoolean(var5);
   }

   static {

      {

      b();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(56956407083867L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[18];
      String var6 = "Å\u0092È §6go£\u009e½½,Ì®Î$2@ÓEàL²\u008c\u000ed\u0085¶N\u0004\u008fÖB6ïr\u001e\u0016Jg\b\u0095ÚÜ4\u0015ñf\u0082¤V´\u0014Ï¤Í\u0089Z,$Ä\u0092@ÞSÅÖýJã«`\u0000Ô¬x¦^<¥!ÁU\u0002ä¬\u0097\u0097×\u0096_\\#býãË\u008aÐb\u0017\tÇ¤±\"Âfà\u0090\u008e\u009f\u0010É\u0091x\u0001¿Õ`\u00945Ûxã0Ô";
      int var7 = "Å\u0092È §6go£\u009e½½,Ì®Î$2@ÓEàL²\u008c\u000ed\u0085¶N\u0004\u008fÖB6ïr\u001e\u0016Jg\b\u0095ÚÜ4\u0015ñf\u0082¤V´\u0014Ï¤Í\u0089Z,$Ä\u0092@ÞSÅÖýJã«`\u0000Ô¬x¦^<¥!ÁU\u0002ä¬\u0097\u0097×\u0096_\\#býãË\u008aÐb\u0017\tÇ¤±\"Âfà\u0090\u008e\u009f\u0010É\u0091x\u0001¿Õ`\u00945Ûxã0Ô"
         .length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     s = var8;
                     t = new Integer[18];
                     i = 128;
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "&û*é\u009e\u008a¿C¨\u001c\u0014ã¾°ÀL";
                  var7 = "&û*é\u009e\u008a¿C¨\u001c\u0014ã¾°ÀL".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException b(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15319;
      if (t[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = s[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])u.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               u.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/c_", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         t[var3] = var15;
      }

      return t[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c_",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = E[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = D[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 34;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 18;
            yield var18;
         }
         case 4 -> {
            byte var19 = 3;
            yield var19;
         }
         case 5 -> {
            byte var20 = 39;
            yield var20;
         }
         case 6 -> {
            byte var21 = 47;
            yield var21;
         }
         case 7 -> {
            byte var22 = 57;
            yield var22;
         }
         case 8 -> {
            byte var23 = 5;
            yield var23;
         }
         case 9 -> {
            byte var24 = 29;
            yield var24;
         }
         case 10 -> {
            byte var25 = 32;
            yield var25;
         }
         case 11 -> {
            byte var26 = 43;
            yield var26;
         }
         case 12 -> {
            byte var27 = 21;
            yield var27;
         }
         case 13 -> {
            byte var28 = 7;
            yield var28;
         }
         case 14 -> {
            byte var29 = 30;
            yield var29;
         }
         case 15 -> {
            byte var30 = 22;
            yield var30;
         }
         case 16 -> {
            byte var31 = 20;
            yield var31;
         }
         case 17 -> {
            byte var32 = 1;
            yield var32;
         }
         case 18 -> {
            byte var33 = 46;
            yield var33;
         }
         case 19 -> {
            byte var34 = 55;
            yield var34;
         }
         case 20 -> {
            byte var35 = 10;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 48;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 9;
            yield var39;
         }
         case 25 -> {
            byte var40 = 52;
            yield var40;
         }
         case 26 -> {
            byte var41 = 50;
            yield var41;
         }
         case 27 -> {
            byte var42 = 41;
            yield var42;
         }
         case 28 -> {
            byte var43 = 44;
            yield var43;
         }
         case 29 -> {
            byte var44 = 25;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 59;
            yield var46;
         }
         case 32 -> {
            byte var47 = 62;
            yield var47;
         }
         case 33 -> {
            byte var48 = 11;
            yield var48;
         }
         case 34 -> {
            byte var49 = 23;
            yield var49;
         }
         case 35 -> {
            byte var50 = 37;
            yield var50;
         }
         case 36 -> {
            byte var51 = 6;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 33;
            yield var53;
         }
         case 39 -> {
            byte var54 = 56;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 45;
            yield var56;
         }
         case 42 -> {
            byte var57 = 19;
            yield var57;
         }
         case 43 -> {
            byte var58 = 38;
            yield var58;
         }
         case 44 -> {
            byte var59 = 13;
            yield var59;
         }
         case 45 -> {
            byte var60 = 61;
            yield var60;
         }
         case 46 -> {
            byte var61 = 42;
            yield var61;
         }
         case 47 -> {
            byte var62 = 26;
            yield var62;
         }
         case 48 -> {
            byte var63 = 36;
            yield var63;
         }
         case 49 -> {
            byte var64 = 49;
            yield var64;
         }
         case 50 -> {
            byte var65 = 4;
            yield var65;
         }
         case 51 -> {
            byte var66 = 8;
            yield var66;
         }
         case 52 -> {
            byte var67 = 54;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 31;
            yield var69;
         }
         case 55 -> {
            byte var70 = 15;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 51;
            yield var72;
         }
         case 58 -> {
            byte var73 = 28;
            yield var73;
         }
         case 59 -> {
            byte var74 = 12;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 2;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 27;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            E[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      D[0] = "\rkW[@\u001d\u001bkR\u0001S\n\f Q\u0007_\u001e\u001dgF\u0010\u0014\t\u0007";
      D[1] = "q>6c\u007f \u0004\u001e=lnoe\u00106gj5\u0011";
      D[2] = boolean.class;
      E[2] = "java/lang/Boolean";
      D[3] = "#\u00024K:S'\u001f4Z'Sd\u0010{M O>\u001fv\u0010\u0004[#\u0004";
      D[4] = "fB\u001fvOmmM\u000e9.cfF\nc";
      D[5] = "1#\u0019'K\t'#\u001c}X\u001e0h\u001f{T\n!/\bl\u001f\u001a\n";
      D[6] = "(\u0001\u0014dqY#\u000e\u0005+\u0012T6\u0003\n@'V'\u0010\u0016l0[";
      D[7] = "^\u0005~\u000b LH\u0005{Q3[_NxW?ON\to@t]\u007f";
      D[8] = int.class;
      E[8] = "java/lang/Integer";
      D[9] = "\u0013t\n`d<\u0013t\u001d<h3\t?\u001d\"h&\u000eNO~=d";
      D[10] = "'\\\u0017p\u001d,1\\\u0012*\u000e;&\u0017\u0011,\u0002/7P\u0006;I>\u0017";
      D[11] = "8W9\u0012EVMw2\u001dT\u0019,y9\u0016PCX";
      D[12] = "~O`$wJ\u000bok+f\u0005ja` b_\u001e";
      D[13] = void.class;
      E[13] = "java/lang/Void";
      D[14] = "\u001eT'oL?\bT\"5_(\u001f\u001f!3S<\u000eX6$\u0018-(";
      D[15] = "s#8r&p\u0006\u00033}7?g\r8v3e\u0013";
      D[16] = "1'w:A\"D\u0007|5Pm%\tw>T7Q";
      D[17] = "FFr\"\u001a93fy-\u000bvRhr&\u000f,&";
      D[18] = "\u000f=\bI(N\u000f=\u001f\u0015$A\u0015v\u001f\u000b$T\u0012\u0007OVu";
      D[19] = "b\u0014<_*\u0005\u001747P;Jv:<[?\u0010\u0002";
      D[20] = "ke-&Z\"\u001eE&)Km\u007fK-\"O7\u000b";
      D[21] = "I\\yrSF<|r}B\t]ryvFS)";
      D[22] = ":]8\b\u0007=,]=R\u0014*;\u0016>T\u0018>*Q)CS.j";
      D[23] = "km5\u0003U\u0007\u001eM>\fDH\u007fC5\u0007@\u0012\u000b";
      D[24] = ">\"|j\u0019c;7wj\u001ad4>|([S\u001da*";
      D[25] = "PPq&~ %pz)ooD~q\"k50";
      D[26] = ",E:=\fkYe12\u001d$8k:9\u0019~L";
      D[27] = "2tJ^[v,|P\u0011\u0006w*p]R[P,gY^\u0018";
      D[28] = ";gm\u00031F%owLyF?eo\u000bp]\u007fEt\flF<ci";
      D[29] = "hK\u001f\u00008\t\u001dk\u0014\u000f)F|e\u001f\u0004-\u001c\b";
      D[30] = "(K\u0000jZQ>K\u00050IF)\u0000\u00066ER8G\u0011!\u000e@\"";
      D[31] = "h(\u001fRb\u0019\u001d\b\u0014]sV|\u0006\u001fVw\f\b";
      D[32] = "@\u001f-X+x^\u00177\u0017cxD\u001d/Pjc\u0004.)\\adI\u001f/\\";
      D[33] = "=JY\u0012NkHjR\u001d_$)dY\u0016[~]";
      D[34] = "\u001en<{6\u0004\bn9!%\u0013\u001f%:')\u0007\u000eb-0b\u0016+";
      D[35] = "\u001d\u0004X_\u001fD\u000b\u0004]\u0005\fS\u001cO^\u0003\u0000G\r\bI\u0014KWA";
      D[36] = "\u0000\u0000P\u0018%\u000fu [\u00174@\u0014.P\u001c0\u001a`";
      D[37] = "Z~k\u0006y\u0006L~n\\j\u0011[5mZf\u0005JrzM-\u0010s";
      D[38] = "RYz`v:DY\u007f:e-S\u0012|<i9BUk+\"-O";
      D[39] = "n=\u0010\u0015{o\u001b\u001d\u001b\u001aj z\u0013\u0010\u0011nz\u000e";
      D[40] = "\u0016\u001c?k1kc<4d $\u00022?o$~v";
      D[41] = "_jd\bV\u001cIjaRE\u000b^!bTI\u001fOfuC\u0002\u000fx";
      D[42] = "a$=\u0002h\u0016\u0014\u00046\ryYu\n=\u0006}\u0003\u0001";
      D[43] = "@}&9?kF$:~E0{&o~$jB+o~:ZG+ aucJ+ \u007fE";
      D[44] = "3o.e6r64t?K$\u000e8n:*$28}7tN";
      D[45] = "\u0015g@u@W\u001bw\u0007l=N*v\u0014zDE[q\u00011\u0006'\u0015g@u@W\u001bw\u0007l=";
      D[46] = "!(<N<cc&=\u001f\\or+?D0]#ko\u0012\\7n5>I`7}8`#";
      D[47] = "Lt@\u0018Q3H/L\u001b`0I6d\u001b\u000b>..[\b\u000edL,G\u001f\u0001^\u001f-E\u001b\u0019&N+\u0017O`";
      D[48] = "; \u001dH>\"p#UXY @.\u0001T #1)\u0014\u001fbA; \u001dH>\"p#UXY";
      D[49] = "m,\u001fC\u00198=+\\\u0003e*f\u001a\u0004Q\u0003)L-\u0006Wexs2\u0001VYx`?_<X4`1\n\u0000X'mo`\r\u0004)k)\u0018\\\u0002{?P";
      D[50] = "MpQ\u0016\u001fU\u000f~PG\u007fY\u001esR\u001c\u0013kO2\nE\u007f\u0001\u0002mS\u0011C\u0001\u0011`\r{";
      D[51] = "G*o^\"\u0015I:(G_\u000ex;;Q&\u0007\t<.\u001adeG*o^\"\u0015I:(G_";
      D[52] = "wk/}>Zy{hdC@Hz{r:H9}n9x*ygyk:R(a+?C";
      D[53] = ",+0.Y`*r,i#8\u00170&gZ3f73,\u0018Qy,0{Si(7y&#";
      D[54] = "\u0019'\u001e\u0003`<I ]C\u001c.\u0012\u0017\u0000\u0007u+\u00126aAm#\u00171]A~.I[P\u001dp(\u000f#\u0001\u001b\"|v";
      D[55] = "\u0013Msk\u000fK\u0015\u0014o,u\u0010(Ve\"\f\u0018YQpiNzN[o?\u0007\u0004UJ32u";
      D[56] = "pJ/\u0010eLv\u00133W\u001f\u0013KQ9Yf\u001f:V,\u0012$}zL;@f\u0005+Ji\u0014\u001f";
      D[57] = "YeW\u001c\u0006#\tb\u0014\\z1RTN\n\u0010:[\u0019\u0015\u0012\u0018?\\%\u0015\u0001\u0015a6(I\u000f\u0013'NyO]G^";
      D[58] = "N;\u0013\u0002\u0001\u0016Hb\u000fE{Lu \u0005K\u0002E\u0004'\u0010\u0000@'D=\u0007R\u0002_\u0015;U\u0006{";
      D[59] = "y <Z.[w0{CSFF1hU*I76}\u001eh+w,jL*S&*8\u0018S";
      D[60] = "%\u001c\u001c\u0018/C(\bX\u0006VC#\u001eB\u0006:qtX\u001cQm&p\u001dA\f6O2\u0013@]V";
      D[61] = "g`3\u0007\u001fX|\u007f9C~_\u001fz-N\u0007Tn}8\u0005E6\"w!_\u0014\n\"d,\u0001~";
      D[62] = "\u0012||\u0001\u001c$\u0015g;Xr>Eg\u0005\u0002I?Bz}D\u001b0Y\u0016";
      D[63] = "\\@8n\u001dWSM>fg\u00055Uky\u001e\u000eDR~2\\l\\@8n\u001dWSM>fg";
      D[64] = "K;5\u000b.FMb)LT\u0018p #B-\u0015\u0001'6\towA=![-\u000f\u0010;s\u000fT";
      D[65] = "yf0`~,?jq\r$\u0014>4<t,e9!w6N-'$15'vz5&\r";
      D[66] = " \u00118r6K(\u0010?r\nKG\u0007mfs@6\u0000x-1\"?\u001ds/kL$\u0002yk\n";
      D[67] = "M16\u001f\t\u000b_gc\u001b1R4k{\u0010PQ\bkh\u001d\u000e;M16\u001f\t\u000b_gc\u001b1";
      D[68] = "9!6j~lh:\u007f7\u000e=W= vw6&:5=5Tf \"ow,7&p;\u000e";
      D[69] = "\u001c\\]M\u001fq\u0013Q[Ee'uI\u000eZ\u001c(\u0004N\u001b\u0011^JDT\fC\u001c2\u0015R^\u0017e";
      D[70] = "\f\t*H\u0012\r\\\u000ei\bn\u001f\u0007:8K$\u0017\u0004\u00118^\bp^\u00047V\u0004L^\u0017:\bnI\u0006\u000b(\u000f\u0007\u0012[\u001a?7";
      D[71] = "j!\u0011\u0014\u000ezm:VM`}9/\u0015A`8k)\u0002@\u0018~9&\u0019,";
      D[72] = "\b\u000b?<a_\u0000\u001du/Z]l\u0018!=#V\u001d\u001f4va4\u000e\\&'kY\n\u0007*$Z";
      D[73] = "\u0000j[c^x\u000fg]k$)i\u007f\bt]!\u0018x\u001d?\u001fCXb\nm];\tdX9$";
      D[74] = "C\u0001Q)\b\u0007GZ]*9\u0004@]D.CjDDTzGUKZ\u0004!9\b\u0019PRrT\fB\\QC";
      D[75] = "oGT\raOaW\u0013\u0014\u001cTPV\u0000\u0002e]!Q\u0015I'?aK\u0002\u001beG0MPO\u001c";
      D[76] = "C,l\u0011.VA0{\u001e\u0014]J5{\u0007h4\u001aet\u0015xL\\7{\u000e\u0014\u0005@2\u007f\u0006lTF`+\u007f";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = D[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(E[var4]);
            D[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = D[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            D[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  D[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(314656892915002L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = D[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = E[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  D[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(314656892915002L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        D[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(314656892915002L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 234;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 238;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 212;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 70;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 254;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 246;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 234;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 238;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 212;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite f(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c_",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c_" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Predicate invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "test",
                  SourceSupport.methodType("()Ljava/util/function/Predicate;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c_", "lambda$render$0", "(Lit/unimi/dsi/fastutil/Pair;)Z"),
                  SourceSupport.methodType("(Lit/unimi/dsi/fastutil/Pair;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Predicate)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("()Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c_", "lambda$render$1", "(Lit/unimi/dsi/fastutil/Pair;)V"),
                  SourceSupport.methodType("(Lit/unimi/dsi/fastutil/Pair;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
