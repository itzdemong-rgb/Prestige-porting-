package dev.zprestige.prestige.renderlib;


import dev.prestige.recovery.SourceSupport;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Vector4f;

public class FramebufferPanel {
   public ManagedGlFramebuffer a;
   public ManagedGlTexture b;
   private int c;
   private int d;
   private static final MinecraftClient e;
   private Vector4f f;
   private Vector4f g;
   private float h;
   private float i;
   private Color j;
   private boolean k;
   private long l;
   private static final long m = 49909045147455L;
   private static final long[] n;
   private static final Integer[] o;
   private static final Map p = new HashMap(13);
   private static final long q;
   private static final Object[] r = new Object[38];
   private static final String[] s = new String[38];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;

   public FramebufferPanel(long var1) {
      super();
      var1 = 49909045147455L ^ var1;
      long var3 = var1 ^ 85246165273832L;
      long var5 = var1 ^ 12729882261288L;
      long var7 = var1 ^ 99528006884906L;

      this.a = invokeBinding1(new Object[]{var3}, -2647521930843955643L, var1);
      int var10001 = invokeBinding2(20915, 5288403366563382264L ^ var1);
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var10001;
      this.b = invokeBinding3(var10004, -2647296565934492636L, var1);
      this.f = new Vector4f(0.0F, 0.0F, 0.0F, 0.0F);
      this.g = new Vector4f(0.0F, 0.0F, 0.0F, 0.0F);
      this.k = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.l = q;
      this.c = invokeBinding5(invokeBinding4(e, -2643742285046911180L, var1), -2647377273834868094L, var1);
      this.d = invokeBinding7(invokeBinding6(e, -2643742285046911180L, var1), -2647738455826870796L, var1);
      invokeBinding8(this, new Object[]{var7}, -2644059316241993123L, var1);
   }

    private void aReturningVoid(Object[] objectArray) {
        int n;
        long l;
        block4: {
            long l2;
            long l3;
            long l4;
            long l5;
            block5: {
                l = (Long)objectArray[0];
                long l6 = l = 0x2D645AE8373FL ^ l;
                l5 = l6 ^ 0x6671EE5C2E44L;
                l4 = l6 ^ 0x57A4202A2F3AL;
                l3 = l6 ^ 0x7053E54827FAL;
                l2 = l6 ^ 0x7C72998ADE3DL;
                int n2 = FramebufferPanel.invokeBinding9(3627370511109564495L, l);
                try {
                    try {
                        n = (((this.k) ? 1 : 0));
                        if (n2 != 0) break block4;
                        if (n == 0) break block5;
                    }
                    catch (MatchException matchException) {
                        throw FramebufferPanel.invokeBinding10(matchException, 3628414654245333205L, l);
                    }
                    FramebufferPanel.invokeBinding11(this.b, 3626969740179459874L, l);
                }
                catch (MatchException matchException) {
                    throw FramebufferPanel.invokeBinding12(matchException, 3628414654245333205L, l);
                }
            }
            Object[] objectArray2 = new Object[2];
            objectArray2[1] = l2;
            objectArray2[0] = FramebufferPanel.invokeBinding13(31315, 0x63EF7236DBFCC10EL ^ l);
            this.b = FramebufferPanel.invokeBinding14(objectArray2, 3627541944970386737L, l);
            Object[] objectArray3 = new Object[4];
            objectArray3[3] = l5;
            objectArray3[2] = this.d;
            objectArray3[1] = this.c;
            objectArray3[0] = FramebufferPanel.invokeBinding15(14534, 0x5D97A388F53F839AL ^ l);
            FramebufferPanel.invokeBinding16(this.b, objectArray3, 3628613836228293732L, l);
            Object[] objectArray4 = new Object[2];
            objectArray4[1] = l4;
            objectArray4[0] = FramebufferPanel.invokeBinding17(9595, 0x1F910DAEABC9E23L ^ l);
            FramebufferPanel.invokeBinding18(this.b, objectArray4, 3626712092720103823L, l);
            Object[] objectArray5 = new Object[2];
            objectArray5[1] = l3;
            objectArray5[0] = FramebufferPanel.invokeBinding19(11581, 0x5D77EC5245079667L ^ l);
            FramebufferPanel.invokeBinding20(this.b, objectArray5, 3628349485129591005L, l);
            FramebufferPanel.invokeBinding22(FramebufferPanel.invokeBinding21(6214, 0x201384447BB2A31FL ^ l), this.a.a, 3626895819370292033L, l);
            FramebufferPanel.invokeBinding26(FramebufferPanel.invokeBinding23(9410, 0x4FAB7B9506E49F99L ^ l), FramebufferPanel.invokeBinding24(23700, 0x78939D290C6667CBL ^ l), FramebufferPanel.invokeBinding25(31315, 0x63EF7236DBFCC10EL ^ l), this.b.a, 0, 3628220614284035418L, l);
            n = FramebufferPanel.invokeBinding27(9410, 0x4FAB7B9506E49F99L ^ l);
        }
        FramebufferPanel.invokeBinding28(n, 0, 3626895819370292033L, l);
        this.k = ((((int)(1) & 1) != 0));
    }

    private boolean aReturningBoolean(Object[] objectArray) {
        int n;
        block26: {
            block27: {
                int n2;
                block24: {
                    int n3;
                    int n4;
                    int n5;
                    long l;
                    long l2;
                    block22: {
                        block23: {
                            int n6;
                            block20: {
                                block21: {
                                    Window window;
                                    block18: {
                                        block19: {
                                            l2 = (Long)objectArray[0];
                                            l = (l2 = 0x2D645AE8373FL ^ l2) ^ 0x689E2F6734B9L;
                                            n5 = FramebufferPanel.invokeBinding29(3589729236457794505L, l2);
                                            try {
                                                try {
                                                    window = FramebufferPanel.invokeBinding30(e, 3592949450181477799L, l2);
                                                    if (n5 != 0) break block18;
                                                    if (window != null) break block19;
                                                }
                                                catch (MatchException matchException) {
                                                    throw FramebufferPanel.invokeBinding31(matchException, 3593012809397594963L, l2);
                                                }
                                                return false;
                                            }
                                            catch (MatchException matchException) {
                                                throw FramebufferPanel.invokeBinding32(matchException, 3593012809397594963L, l2);
                                            }
                                        }
                                        window = FramebufferPanel.invokeBinding33(e, 3592949450181477799L, l2);
                                    }
                                    n4 = FramebufferPanel.invokeBinding34(window, 3589811449242359825L, l2);
                                    n3 = FramebufferPanel.invokeBinding36(FramebufferPanel.invokeBinding35(e, 3592949450181477799L, l2), 3590043986482800487L, l2);
                                    try {
                                        try {
                                            try {
                                                n6 = n4;
                                                if (n5 != 0) break block20;
                                                if (n6 <= 0) break block21;
                                            }
                                            catch (MatchException matchException) {
                                                throw FramebufferPanel.invokeBinding37(matchException, 3593012809397594963L, l2);
                                            }
                                            n2 = n3;
                                            if (n5 != 0) break block22;
                                        }
                                        catch (MatchException matchException) {
                                            throw FramebufferPanel.invokeBinding38(matchException, 3593012809397594963L, l2);
                                        }
                                        if (n2 > 0) break block23;
                                    }
                                    catch (MatchException matchException) {
                                        throw FramebufferPanel.invokeBinding39(matchException, 3593012809397594963L, l2);
                                    }
                                }
                                n6 = 0;
                            }
                            return n6 != 0;
                        }
                        n2 = this.c;
                    }
                    try {
                        block25: {
                            try {
                                try {
                                    try {
                                        if (n5 != 0) break block24;
                                        if (n2 != n4) break block25;
                                    }
                                    catch (MatchException matchException) {
                                        throw FramebufferPanel.invokeBinding40(matchException, 3593012809397594963L, l2);
                                    }
                                    n = this.d;
                                    if (n5 != 0) break block26;
                                }
                                catch (MatchException matchException) {
                                    throw FramebufferPanel.invokeBinding41(matchException, 3593012809397594963L, l2);
                                }
                                if (n == n3) break block27;
                            }
                            catch (MatchException matchException) {
                                throw FramebufferPanel.invokeBinding42(matchException, 3593012809397594963L, l2);
                            }
                        }
                        this.c = n4;
                        this.d = n3;
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l;
                        FramebufferPanel.invokeBinding43(this, objectArray2, 3593124923021498574L, l2);
                        n2 = 1;
                    }
                    catch (MatchException matchException) {
                        throw FramebufferPanel.invokeBinding44(matchException, 3593012809397594963L, l2);
                    }
                }
                return n2 != 0;
            }
            n = 0;
        }
        return n != 0;
    }

    public void bReturningVoid(Object[] objectArray) {
        block11: {
            FramebufferPanel bU_C00972;
            long l;
            long l2;
            block10: {
                block9: {
                    boolean bl;
                    block8: {
                        l2 = (Long)objectArray[0];
                        l = (Long)objectArray[1];
                        long l3 = (l = 0x2D645AE8373FL ^ l) ^ 0x5803E16BBFADL;
                        Object[] objectArray2 = new Object[1];
                        objectArray2[0] = l3;
                        boolean bl2 = FramebufferPanel.invokeBinding46(this, objectArray2, -5097731589521385170L, l);
                        int n = FramebufferPanel.invokeBinding45(-5097947634194461810L, l);
                        try {
                            try {
                                try {
                                    bl = bl2;
                                    if (n == 0) break block8;
                                    if (bl) break block9;
                                }
                                catch (MatchException matchException) {
                                    throw FramebufferPanel.invokeBinding47(matchException, -5093985167600393279L, l);
                                }
                                bU_C00972 = this;
                                if (n == 0) break block10;
                            }
                            catch (MatchException matchException) {
                                throw FramebufferPanel.invokeBinding48(matchException, -5093985167600393279L, l);
                            }
                            long l4 = bU_C00972.l - l2;
                            bl = l4 == 0L ? ((((int)(0) & 1) != 0)) : (l4 < 0L ? ((((int)(-1) & 1) != 0)) : ((((int)(1) & 1) != 0)));
                        }
                        catch (MatchException matchException) {
                            throw FramebufferPanel.invokeBinding49(matchException, -5093985167600393279L, l);
                        }
                    }
                    if (!bl) break block11;
                }
                bU_C00972 = this;
            }
            Object[] objectArray3 = new Object[1];
            objectArray3[0] = l2;
            FramebufferPanel.invokeBinding50(bU_C00972, objectArray3, -5097531517876953418L, l);
        }
    }

   private void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      this.l = var2;
   }

   public void dReturningVoid(Object[] var1) {
      Vector4f var2 = (Vector4f)var1[0];
      this.f = var2;
   }

   public Vector4f aReturningVector4f(Object[] var1) {
      return this.f;
   }

   public void eReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.h = var2;
   }

   public float aReturningFloat(Object[] var1) {
      return this.h;
   }

   public void fReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      this.i = var2;
   }

   public float bReturningFloat(Object[] var1) {
      return this.i;
   }

   public void gReturningVoid(Object[] var1) {
      Vector4f var2 = (Vector4f)var1[0];
      this.g = var2;
   }

   public Vector4f bReturningVector4f(Object[] var1) {
      return this.g;
   }

   public void hReturningVoid(Object[] var1) {
      Color var2 = (Color)var1[0];
      this.j = var2;
   }

   public Color aReturningColor(Object[] var1) {
      return this.j;
   }

   static {

      {

      aReturningVoid();
      Cipher var5;
      Cipher var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(7138693145602L << var6 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var11 = new long[8];
      String var9 = "µØ!\fîí±\u0097æR\u000f/ú\u007fõV]\u0082Rt\u001foø\u008cù\u0019Î\u0087hGâ\u0090cAÒ\u000ew\u008aû\u001a´ô\u001eüz½Ó¬";
      int var10 = "µØ!\fîí±\u0097æR\u000f/ú\u007fõV]\u0082Rt\u001foø\u008cù\u0019Î\u0087hGâ\u0090cAÒ\u000ew\u008aû\u001a´ô\u001eüz½Ó¬".length();
      label33:
      while (true) {
         int var10001 = var7;
         var7 += 8;
         byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
         long[] var17 = var11;
         var10001 = var8++;
         long var23 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         // while (true) {
            long var13 = var23;
            byte[] var15 = var5.doFinal(
               new byte[]{
                  (byte)(var13 >>> 56),
                  (byte)(var13 >>> 48),
                  (byte)(var13 >>> 40),
                  (byte)(var13 >>> 32),
                  (byte)(var13 >>> 24),
                  (byte)(var13 >>> 16),
                  (byte)(var13 >>> 8),
                  (byte)var13
               }
            );
            long var30 = (var15[0] & 255L) << 56
               | (var15[1] & 255L) << 48
               | (var15[2] & 255L) << 40
               | (var15[3] & 255L) << 32
               | (var15[4] & 255L) << 24
               | (var15[5] & 255L) << 16
               | (var15[6] & 255L) << 8
               | var15[7] & 255L;
            switch (var27) {
               case 0:
                  var17[var10001] = var30;
                  if (var7 >= var10) {
                     n = var11;
                     o = new Integer[8];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(7138693145602L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var21 = -1684387433251972998L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)232L,
                           (byte)59551L,
                           (byte)15245274L,
                           (byte)3902790285L,
                           (byte)999114313152L,
                           (byte)255773264167138L,
                           (byte)65477955626787416L,
                           (byte)-1684387433251972998L
                        }
                     );
                     long var26 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     // q = var26;
                     e = MinecraftClient.getInstance();
                     break;
                  }
                  break;
               default:
                  var17[var10001] = var30;
                  if (var7 < var10) {
                     continue label33;
                  }

                  var9 = "YF\u0017jV;Ë\u0018\u0087\u0085\u001bÚÅ\u0096\u001aZ";
                  var10 = "YF\u0017jV;Ë\u0018\u0087\u0085\u001bÚÅ\u0096\u001aZ".length();
                  var7 = 0;
            }

            int var20 = var7;
            var7 += 8;
            var12 = var9.substring(var20, var7).getBytes("ISO-8859-1");
            var17 = var11;
            var10001 = var8++;
            var23 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            var27 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2318;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])p.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bU", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bU_C0097",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = s[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = r[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 35;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 46;
            yield var18;
         }
         case 4 -> {
            byte var19 = 27;
            yield var19;
         }
         case 5 -> {
            byte var20 = 19;
            yield var20;
         }
         case 6 -> {
            byte var21 = 2;
            yield var21;
         }
         case 7 -> {
            byte var22 = 4;
            yield var22;
         }
         case 8 -> {
            byte var23 = 11;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 26;
            yield var25;
         }
         case 11 -> {
            byte var26 = 32;
            yield var26;
         }
         case 12 -> {
            byte var27 = 33;
            yield var27;
         }
         case 13 -> {
            byte var28 = 40;
            yield var28;
         }
         case 14 -> {
            byte var29 = 50;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 30;
            yield var31;
         }
         case 17 -> {
            byte var32 = 55;
            yield var32;
         }
         case 18 -> {
            byte var33 = 10;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 13;
            yield var35;
         }
         case 21 -> {
            byte var36 = 14;
            yield var36;
         }
         case 22 -> {
            byte var37 = 22;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 6;
            yield var39;
         }
         case 25 -> {
            byte var40 = 38;
            yield var40;
         }
         case 26 -> {
            byte var41 = 18;
            yield var41;
         }
         case 27 -> {
            byte var42 = 39;
            yield var42;
         }
         case 28 -> {
            byte var43 = 53;
            yield var43;
         }
         case 29 -> {
            byte var44 = 24;
            yield var44;
         }
         case 30 -> {
            byte var45 = 41;
            yield var45;
         }
         case 31 -> {
            byte var46 = 54;
            yield var46;
         }
         case 32 -> {
            byte var47 = 16;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 47;
            yield var49;
         }
         case 35 -> {
            byte var50 = 45;
            yield var50;
         }
         case 36 -> {
            byte var51 = 8;
            yield var51;
         }
         case 37 -> {
            byte var52 = 12;
            yield var52;
         }
         case 38 -> {
            byte var53 = 28;
            yield var53;
         }
         case 39 -> {
            byte var54 = 9;
            yield var54;
         }
         case 40 -> {
            byte var55 = 15;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 51;
            yield var57;
         }
         case 43 -> {
            byte var58 = 1;
            yield var58;
         }
         case 44 -> {
            byte var59 = 23;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 52;
            yield var61;
         }
         case 47 -> {
            byte var62 = 21;
            yield var62;
         }
         case 48 -> {
            byte var63 = 43;
            yield var63;
         }
         case 49 -> {
            byte var64 = 58;
            yield var64;
         }
         case 50 -> {
            byte var65 = 7;
            yield var65;
         }
         case 51 -> {
            byte var66 = 44;
            yield var66;
         }
         case 52 -> {
            byte var67 = 62;
            yield var67;
         }
         case 53 -> {
            byte var68 = 56;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 3;
            yield var72;
         }
         case 58 -> {
            byte var73 = 48;
            yield var73;
         }
         case 59 -> {
            byte var74 = 25;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 60;
            yield var76;
         }
         case 62 -> {
            byte var77 = 36;
            yield var77;
         }
         default -> 57;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            s[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      r[0] = "\u0006X\u0016\u0010\"b\u0006X\u0001L.m\u001c\u0013\u0001R.x\u001bbQ\u000f\u007f";
      r[1] = "\u001crbLyd\nrg\u0016js\u001d9d\u0010fg\f~s\u0007-u=";
      r[2] = int.class;
      s[2] = "java/lang/Integer";
      r[3] = ")\u0017\u0007dg}?\u0017\u0002>tj(\\\u00018x~9\u001b\u0016/3o\u0018";
      r[4] = "\u0016}0\u007f\u0013ec];p\u0002*\u0002S0{\u0006pv";
      r[5] = boolean.class;
      s[5] = "java/lang/Boolean";
      r[6] = "\u0013W*\u0007qYfw!\b`\u0016\u0007y*\u0003dLs";
      r[7] = void.class;
      s[7] = "java/lang/Void";
      r[8] = "\u001f_ x3-\u0014P17P \u0001]>\\e\"\u0010N\"pr/";
      r[9] = "9]!H{{9]6\u0014wt#\u00166\nwa$gdV\"#";
      r[10] = "q}Nw@\u000e\u0004]ExQAeSNsU\u001b\u0011";
      r[11] = "\u0013:)\u0018\u001aq\u0005:,B\tf\u0012q/D\u0005r\u000368SNc%";
      r[12] = "rB_@>!\u0007bTO/nfl_D+4\u0012";
      r[13] = "C\u001ew;\u000e&U\u001era\u001d1BUqg\u0011%S\u0012fpZ4s";
      r[14] = "(~#%:8]^(*+w<P#!/-H";
      r[15] = "ev:\u001efd\u0010V1\u0011w+qX:\u001asq\u0005";
      r[16] = "#4\u0017\u0001\"F&!\u001c\u0001!A)(\u0017C`v\u0000u@";
      r[17] = "v\u0000\u0004|o\u007f\u0003 \u000fs~0b.\u0004xzj\u0016";
      r[18] = "??\u0002)KGJ\u001f\t&Z\b+\u0011\u0002-^R_";
      r[19] = "e6%^O\nn94\u0011.\u0004e20K";
      r[20] = "O1\u001fdT9Ij\t\u001fC\u0002\u000e`\b\u007f\u0017~\b`\u0003\")";
      r[21] = "qK1\n943\u000f7\u0004\\-NZ(\u000fm\"%J2_9DqK1\n943\u000f7\u0004\\";
      r[22] = "\tX\u0002BU\f\t\n\u0003\u001b'U8XJ\u0016\u0016ZSHPFB<\tX\u0002BU\f\t\n\u0003\u001b'";
      r[23] = "\t!{@^\"\f\"vA wZ?zHLE\u000b\u007f*\u001e +Y/z\u0011\\-Y$'/";
      r[24] = "D@[Ys3ACVX\rf\u0017^ZQaTF\u001f\u0002\b\r:\u0014NZ\bq<\u0014E\u00076";
      r[25] = "\u001f};p\"\t\u0019&-\u000b42^,,kaNX,'6_";
      r[26] = "[&!\u0018(p[t AZ*j&iLk&\u00016s\u001c?@W'~Hc=P3lLZ";
      r[27] = "C\t\u0017^?gN\u0006\u000f#g:R\b\u0015OUn\u0013UK#o6K\u0015O\u0013b9Sh";
      r[28] = ";\u000b;!U\tcW2c4\u0005\u0001\u00023p\u0005\nj\u0012) Ql:\u0017/g\u000e\u00038\u001bvz4";
      r[29] = "vH\u001e\u001f\u00069!G\u0011Xc;x<\u0015\u0000\u000f\u001af\u001f\u0011\u000b\t)r\u0018\u0019\u001ccmr\u001a\u0014X\u001fkr\u0011IfZ:p\u0016J\u001a\\:{Kt[\t:sO\t\\\u001d(wv";
      r[30] = "+\u0016^X\u0010X+D_\u0001b\u0003~\u001a\u0014\nbUp\u0013\u0000^\u001fRd\u0001\u0004g";
      r[31] = "va(m!\u0004.=!/@\nLh <q\u0007'x:l%aqi78y\u001cv}%<@";
      r[32] = ">V\u0010\u000b>\biY\u001fL[\n0&\u0000\u001b>\b>\u0015\u0014\u001c6\u001f\b\u0005\n\u000e&\u001f9R6rb\u000b8\bD\u000ed\u000b3UzK5\t4V\u0006M5\u0002ihC\u001c7\u0005j\u0014E\u001c<XTQ\u0014\u001e;[(W\u0014\u0015fem\u0006\u0016\u0012e\u0019k\u0006\u001dO[X>\u0006\u0015K&_*\u0014\u0011r";
      r[33] = "Ea\u001bRYEE3\u001a\u000b+\u0018taS\u0006\u001a\u0013\u001fqIVNuI`D\u0002\u0012\bNtV\u0006+";
      r[34] = "eYlXO\u0015=\u0005e\u001a.\u0019_\u0006lR\u0015\u000b4Ap\rQpbJ-YU\u001b%Vr\u001d.";
      r[35] = "\u001f{%w\r{\u0012t=\nU&\u000ez'fgqH$p10u\u0010{/t\u0000p\u0013v.\n";
      r[36] = "Xtdw|0\u0000(m5\u001d<b}l&,3\tmvvxU_|{\"$(Xhi&\u001d";
      r[37] = "+xo\u0003\u00195+*nZkn\u001ax'WZcqh=\u0007\u000e\u0005'y0SRx m\"Wk";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = r[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(s[var4]);
            r[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = r[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            r[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  r[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1377231373906537L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = r[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = s[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  r[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1377231373906537L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        r[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1377231373906537L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 111;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 108;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 77;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 98;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 197;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 229;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 111;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 108;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 77;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bU_C0097",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bU" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static ManagedGlFramebuffer invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bR_C0091;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ManagedGlFramebuffer)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static ManagedGlTexture invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bT_C0095;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ManagedGlTexture)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Window invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Window invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding9(long var0, long var2) {
         MethodHandle var8 = bindingCache9;
         MethodHandle var7 = bindingCache9;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache9 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding12(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache12;
         MethodHandle var8 = bindingCache12;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache12 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding13(int var0, long var1) {
         MethodHandle var7 = bindingCache13;
         MethodHandle var6 = bindingCache13;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache13 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static ManagedGlTexture invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bT_C0095;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ManagedGlTexture)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding15(int var0, long var1) {
         MethodHandle var7 = bindingCache15;
         MethodHandle var6 = bindingCache15;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache15 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding17(int var0, long var1) {
         MethodHandle var7 = bindingCache17;
         MethodHandle var6 = bindingCache17;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache17 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding19(int var0, long var1) {
         MethodHandle var7 = bindingCache19;
         MethodHandle var6 = bindingCache19;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache19 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding22(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding23(int var0, long var1) {
         MethodHandle var7 = bindingCache23;
         MethodHandle var6 = bindingCache23;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache23 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding24(int var0, long var1) {
         MethodHandle var7 = bindingCache24;
         MethodHandle var6 = bindingCache24;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache24 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding25(int var0, long var1) {
         MethodHandle var7 = bindingCache25;
         MethodHandle var6 = bindingCache25;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache25 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding26(int var0, int var1, int var2, int var3, int var4, long var5, long var7) {
         MethodHandle var13 = bindingCache26;
         MethodHandle var12 = bindingCache26;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache26 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(IIIIIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var10.invokeExact((int)var0, (int)var1, (int)var2, (int)var3, (int)var4, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static int invokeBinding27(int var0, long var1) {
         MethodHandle var7 = bindingCache27;
         MethodHandle var6 = bindingCache27;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache27 = a(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding28(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding29(long var0, long var2) {
         MethodHandle var8 = bindingCache29;
         MethodHandle var7 = bindingCache29;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache29 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Window invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Window invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Window invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = b(MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding43(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache43;
         MethodHandle var9 = bindingCache43;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache43 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding45(long var0, long var2) {
         MethodHandle var8 = bindingCache45;
         MethodHandle var7 = bindingCache45;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache45 = b(MethodHandles.lookup(), "å", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static boolean invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (boolean)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding47(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding48(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache48;
         MethodHandle var8 = bindingCache48;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache48 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = b(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding50(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache50;
         MethodHandle var9 = bindingCache50;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache50 = b(
                  MethodHandles.lookup(), "Å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
