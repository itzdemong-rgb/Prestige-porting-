package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.RaycastUtil;
import dev.zprestige.prestige.client.management.MsdfFontManager;
import dev.zprestige.prestige.renderlib.font.MsdfFont;



import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.client.Prestige;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.client.texture.AtlasManager;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.SpriteContents;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.ComponentType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.DefaultedRegistry;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public class GameRenderUtil implements MinecraftAccess {
   private static final MinecraftClient b;
   public static DrawContext a;
   public static MatrixStack c;
   public static Matrix4f d;
   public static Matrix4f e;
   public static Matrix4f f;
   public static MeshBufferManager g;
   public static RenderContext h;
   private static final int[] i;
   private static boolean j;
   private static final Matrix4f k;
   private static final Matrix4f l;
   private static final Vector3f m;
   private static final Vector4f n;
   private static long o;
   private static long p;
   private static final Matrix4f q;
   private static final float[] r;
   private static int s;
   private static final Vector4f t;
   private static final Color u;
   private static final Color v;
   private static float w;
   private static Color x;
   private static final Identifier y;
   private static final long z = 46097011089910L;
   private static final String[] A;
   private static final String[] B;
   private static final Map C = new HashMap(13);
   private static final long[] D;
   private static final Integer[] E;
   private static final Map F;
   private static final long[] G;
   private static final Long[] H;
   private static final Map I;
   private static final Object[] J = new Object[190];
   private static final String[] K = new String[190];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;

   public static void aReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 46097011089910L ^ var1;
      short var10000 = 20461;
      long var10001 = 6094546492423352411L ^ var1;
      var10000 = 2978;
      int[] var4 = i;
      GL11.glGetIntegerv(2978, var4);
      j = true;
   }

   private static int[] aReturningArrayOfInt(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 46097011089910L ^ var1;
      int var3 = Event.bReturningInt();
      int var10 = var3;
      boolean var9 = j;
      boolean var8 = var9;
      boolean var7 = var9;
      if (var10 == 0) {
         boolean var11 = var7;
         if (var11) {
            return i;
         }

         short var10000 = 9304;
         long var10001 = 4386340916132615202L ^ var1;
         var10000 = 2978;
         int[] var6 = i;
         GL11.glGetIntegerv(2978, var6);
         boolean var12 = true;
         var8 = var12;
      }

      j = var8;
      return i;
   }

   private static long aReturningLong(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 46097011089910L ^ var1;
      int var15 = Event.bReturningInt();
      Object[] var6 = new Object[0];
      long var4 = RenderThreadUtil.aReturningLong(var6);
      int var3 = var15;
      int var13 = var3;
      long var11 = var4;
      long var9 = var11;
      long var7 = var11;
      if (var13 == 0) {
         long var16;
         int var14 = (var16 = var7 - o) == 0L ? 0 : (var16 < 0L ? -1 : 1);
         if (((var14) != 0)) {
            o = var4;
            p = System.currentTimeMillis();
         }

         var9 = p;
      }

      return var9;
   }

   public static Vec3d aReturningVec3d(Object[] var0) {
      Vec3d var1 = (Vec3d)var0[0];
      long var2 = (Long)var0[1];
      var2 = 46097011089910L ^ var2;
      long var4 = var2 ^ 49736236222533L;
      MinecraftClient var20 = b;
      EntityRenderManager var21 = var20.getEntityRenderDispatcher();
      Camera var6 = var21.camera;
      MinecraftClient var22 = b;
      Window var23 = var22.getWindow();
      int var7 = var23.getHeight();
      Object[] var24 = new Object[]{var4};
      int[] var8 = aReturningArrayOfInt(var24);
      Vector3f var9 = m;
      Camera var25 = var6;
      Vec3d var10 = var25.getCameraPos();
      Vec3d var26 = var1;
      Vec3d var27 = var10;
      double var11 = var26.x - var27.x;
      Vec3d var28 = var1;
      Vec3d var29 = var10;
      double var13 = var28.y - var29.y;
      Vec3d var30 = var1;
      Vec3d var31 = var10;
      double var15 = var30.z - var31.z;
      float var10001 = (float)var11;
      float var10002 = (float)var13;
      float var10003 = (float)var15;
      float var36 = 1.0F;
      float var35 = var10003;
      float var34 = var10002;
      float var33 = var10001;
      Vector4f var32 = n;
      Vector4f var10000 = var32.set(var33, var34, var35, var36);
      Matrix4f var38 = f;
      Vector4f var37 = var10000;
      Vector4f var17 = var37.mul((Matrix4fc)var38);
      Matrix4f var40 = d;
      Matrix4f var39 = k;
      Matrix4f var18 = var39.set((Matrix4fc)var40);
      Matrix4f var42 = e;
      Matrix4f var41 = l;
      Matrix4f var19 = var41.set((Matrix4fc)var42);
      Matrix4f var44 = var19;
      Matrix4f var43 = var18;
      Matrix4f var62 = var43.mul((Matrix4fc)var44);
      Vector4f var45 = var17;
      var10001 = var45.x();
      Vector4f var46 = var17;
      var10002 = var46.y();
      Vector4f var47 = var17;
      var10003 = var47.z();
      Vector3f var53 = var9;
      int[] var52 = var8;
      float var51 = var10003;
      float var50 = var10002;
      float var49 = var10001;
      Matrix4f var48 = var62;
      var48.project(var49, var50, var51, var52, var53);
      Vector3f var54 = var9;
      var10002 = var54.x;
      MinecraftClient var55 = b;
      Window var56 = var55.getWindow();
      double var66 = var10002 / var56.getScaleFactor();
      var10003 = var7;
      Vector3f var57 = var9;
      var10003 -= var57.y;
      MinecraftClient var58 = b;
      Window var59 = var58.getWindow();
      double var70 = var10003 / var59.getScaleFactor();
      Vector3f var60 = var9;
      return new Vec3d(var66, var70, var60.z);
   }

   private static double aReturningDouble(Object[] var0) {
      double var1 = (Double)var0[0];
      double var3 = (Double)var0[1];
      long var5 = (Long)var0[2];
      var5 = 46097011089910L ^ var5;
      long var7 = var5 ^ 45209136679372L;
      double var10001 = var1 - var3;
      Object[] var9 = new Object[]{var7};
      return var3 + var10001 * aReturningFloat(var9);
   }

   public static Vec3d bReturningVec3d(Object[] var0) {
      Entity var1 = (Entity)var0[0];
      long var2 = (Long)var0[1];
      var2 = 46097011089910L ^ var2;
      long var4 = var2 ^ 13181353774528L;
      long var6 = var2 ^ 42827843399230L;
      Object[] var15 = new Object[]{var1, var4};
      Vec3d var8 = RaycastUtil.cReturningVec3d(var15);
      Entity var16 = var1;
      double var10000 = var16.getX();
      Vec3d var17 = var8;
      double var10001 = var17.x;
      Object[] var10004 = new Object[]{null, null, var6};
      var10004[1] = var10001;
      var10004[0] = var10000;
      Object[] var18 = var10004;
      double var9 = aReturningDouble(var18);
      Entity var19 = var1;
      var10000 = var19.getY();
      Vec3d var20 = var8;
      var10001 = var20.y;
      var10004 = new Object[]{null, null, var6};
      var10004[1] = var10001;
      var10004[0] = var10000;
      Object[] var21 = var10004;
      double var11 = aReturningDouble(var21);
      Entity var22 = var1;
      var10000 = var22.getZ();
      Vec3d var23 = var8;
      var10001 = var23.z;
      var10004 = new Object[]{null, null, var6};
      var10004[1] = var10001;
      var10004[0] = var10000;
      Object[] var24 = var10004;
      double var13 = aReturningDouble(var24);
      return new Vec3d(var9, var11, var13);
   }

    public static Color aReturningColor(Object[] objectArray) {
        long l;
        long l2;
        int n;
        int n2;
        block5: {
            int n3;
            int n4;
            int n5;
            Color color;
            block4: {
                color = (Color)objectArray[0];
                n2 = (Integer)objectArray[1];
                n = (Integer)objectArray[2];
                l2 = (Long)objectArray[3];
                l = (l2 = 0x29ECCBF8A1F6L ^ l2) ^ 0x4ABFCAE93648L;
                n5 = GameRenderUtil.invokeBinding2(color, 7477992676949768929L, l2);
                int n6 = GameRenderUtil.invokeBinding1(7479419734057362586L, l2);
                try {
                    try {
                        n4 = n5;
                        n3 = s;
                        if (n6 != 0) break block4;
                        if (n4 == n3) break block5;
                    }
                    catch (MatchException matchException) {
                        throw GameRenderUtil.invokeBinding3(matchException, 7490162326962166531L, l2);
                    }
                    n4 = GameRenderUtil.invokeBinding4(color, 7493121864102852365L, l2);
                    n3 = GameRenderUtil.invokeBinding5(color, 7492139815925109206L, l2);
                }
                catch (MatchException matchException) {
                    throw GameRenderUtil.invokeBinding6(matchException, 7490162326962166531L, l2);
                }
            }
            GameRenderUtil.invokeBinding8(n4, n3, GameRenderUtil.invokeBinding7(color, 7478235555274520677L, l2), r, 7492574773513856037L, l2);
            s = n5;
        }
        Object[] objectArray2 = new Object[1];
        objectArray2[0] = l;
        float f = GameRenderUtil.invokeBinding11(((float)(GameRenderUtil.invokeBinding9(objectArray2, 7476338354214844403L, l2) % GameRenderUtil.invokeBinding10(14385, 0x4E302508ECDE7AE4L ^ l2)) / 1000.0f + (float)n2 / (float)n * 2.0f) % 2.0f - 1.0f, 7476114499150185689L, l2);
        return new Color(GameRenderUtil.invokeBinding12(r[0], r[1], 0.25f + 0.75f * f, 7476035996493246831L, l2));
    }

   public static Color bReturningColor(Object[] var0) {
      int var1;
      int var3;
      long var6;
      long var39;
      label14: {
         Color var2 = (Color)var0[0];
         var1 = (Integer)var0[1];
         var3 = (Integer)var0[2];
         long var4 = (Long)var0[3];
         var39 = 46097011089910L ^ var4;
         var6 = var39 ^ 107060109460348L;
         int var10000 = Event.cReturningInt();
         Color var11 = var2;
         int var9 = var11.getRGB();
         int var8 = var10000;
         int var34 = var8;
         int var33 = s;
         int var32 = var9;
         int var30 = var32;
         int var31 = var33;
         int var28 = var32;
         int var29 = var33;
         if (var34 != 0) {
            int var36 = var29;
            int var35 = var28;
            if (var35 == var36) {
               break label14;
            }

            Color var13 = var2;
            var10000 = var13.getRed();
            Color var14 = var2;
            int var38 = var14.getGreen();
            int var37 = var10000;
            var30 = var37;
            var31 = var38;
         }

         Color var16 = var2;
         int var10002 = var16.getBlue();
         float[] var20 = r;
         int var19 = var10002;
         int var18 = var31;
         int var17 = var30;
         Color.RGBtoHSB(var17, var18, var19, var20);
         s = var9;
      }

      Object[] var21 = new Object[]{var6};
      long var41 = aReturningLong(var21);
      short var10003 = 20582;
      long var10004 = 4861763551900198789L ^ var39;
      float var22 = ((float)(var41 % 2000L) / 1000.0F + (float)var1 / var3 * 2.0F) % 2.0F - 1.0F;
      float var10 = 0.5F + 0.5F * Math.abs(var22);
      float var42 = r[0];
      float var43 = r[1];
      float var24 = 1.0F;
      float var23 = var10;
      float var27 = Math.min(var23, var24);
      float var26 = var43;
      float var25 = var42;
      return new Color(Color.HSBtoRGB(var25, var26, var27));
   }

   public static Vec3d cReturningVec3d(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 46097011089910L ^ var1;
      long var3 = var1 ^ 126814684398924L;
      MinecraftClient var5 = b;
      Object[] var6 = new Object[]{var5.getCameraEntity(), var3};
      return RaycastUtil.aReturningVec3d(var6);
   }

   public static void bReturningVoid(Object[] var0) {
      float var3 = (Float)var0[0];
      float var6 = (Float)var0[1];
      float var4 = (Float)var0[2];
      Color var5 = (Color)var0[3];
      long var1 = (Long)var0[4];
      var1 = 46097011089910L ^ var1;
      long var7 = var1 ^ 46831992311943L;
      Object[] var10006 = new Object[]{null, null, null, var5, var7};
      var10006[2] = var4;
      var10006[1] = var6;
      var10006[0] = var3;
      invokeBinding13(var10006, 4451697535954237451L, var1);
   }

   public static void cReturningVoid(Object[] var0) {
      Matrix4f var6 = (Matrix4f)var0[0];
      float var1 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var2 = (Float)var0[3];
      Color var7 = (Color)var0[4];
      long var4 = (Long)var0[5];
      var4 = 46097011089910L ^ var4;
      long var8 = var4 ^ 33921240739366L;
      Color var10 = var7;
      int var10004 = var10.getRGB();
      Object[] var10007 = new Object[]{null, null, null, null, null, var8};
      var10007[4] = var10004;
      var10007[3] = var2;
      var10007[2] = var3;
      var10007[1] = var1;
      var10007[0] = var6;
      Object[] var11 = var10007;
      ShapeRenderer.y(var11);
   }

   public static void dReturningVoid(Object[] var0) {
      float var4 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var5 = (Float)var0[2];
      Color var6 = (Color)var0[3];
      long var2 = (Long)var0[4];
      var2 = 46097011089910L ^ var2;
      long var7 = var2 ^ 80311798372339L;
      Object[] var10007 = new Object[]{null, null, null, null, var6, var7};
      var10007[3] = 1.0F;
      var10007[2] = var5;
      var10007[1] = var1;
      var10007[0] = var4;
      invokeBinding14(var10007, -7197482555628752646L, var2);
   }

   public static void eReturningVoid(Object[] var0) {
      Matrix4f var7 = (Matrix4f)var0[0];
      float var5 = (Float)var0[1];
      float var2 = (Float)var0[2];
      float var6 = (Float)var0[3];
      Color var1 = (Color)var0[4];
      long var3 = (Long)var0[5];
      var3 = 46097011089910L ^ var3;
      long var8 = var3 ^ 69640242186L;
      Color var10 = var1;
      int var10005 = var10.getRGB();
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10005;
      var10008[4] = 1.0F;
      var10008[3] = var6;
      var10008[2] = var2;
      var10008[1] = var5;
      var10008[0] = var7;
      Object[] var11 = var10008;
      ShapeRenderer.A(var11);
   }

    public static void fReturningVoid(Object[] objectArray) {
        Color color;
        Color color2;
        Color color3;
        Color color4;
        float f;
        float f10;
        float f11;
        float f12;
        Color color5;
        long l;
        long l2;
        boolean bl;
        boolean bl2;
        boolean bl3;
        boolean bl4;
        float f13;
        float f14;
        float f15;
        float f16;
        block13: {
            float f17;
            float f18;
            block12: {
                f16 = ((Float)objectArray[0]).floatValue();
                f15 = ((Float)objectArray[1]).floatValue();
                f14 = ((Float)objectArray[2]).floatValue();
                f13 = ((Float)objectArray[3]).floatValue();
                bl4 = (Boolean)objectArray[4];
                bl3 = (Boolean)objectArray[5];
                bl2 = (Boolean)objectArray[6];
                bl = (Boolean)objectArray[7];
                f18 = ((Float)objectArray[8]).floatValue();
                l2 = (Long)objectArray[9];
                l = (l2 = 0x29ECCBF8A1F6L ^ l2) ^ 0x70156EDFA4FEL;
                color5 = u;
                int n = GameRenderUtil.invokeBinding15(-2163860376663186770L, l2);
                try {
                    try {
                        f17 = f18;
                        if (n != 0) break block12;
                        if (f17 == w) break block13;
                    }
                    catch (MatchException matchException) {
                        throw GameRenderUtil.invokeBinding16(matchException, -2177993863964369609L, l2);
                    }
                    f17 = f18;
                }
                catch (MatchException matchException) {
                    throw GameRenderUtil.invokeBinding17(matchException, -2177993863964369609L, l2);
                }
            }
            w = f17;
            x = new Color(0.0f, 0.0f, 0.0f, f18);
        }
        Color color6 = x;
        try {
            f12 = f16;
            f11 = f15;
            f10 = f14;
            f = f13;
            color4 = bl4 ? color6 : color5;
        }
        catch (MatchException matchException) {
            throw GameRenderUtil.invokeBinding18(matchException, -2177993863964369609L, l2);
        }
        try {
            color3 = bl3 ? color6 : color5;
        }
        catch (MatchException matchException) {
            throw GameRenderUtil.invokeBinding19(matchException, -2177993863964369609L, l2);
        }
        try {
            color2 = bl2 ? color6 : color5;
        }
        catch (MatchException matchException) {
            throw GameRenderUtil.invokeBinding20(matchException, -2177993863964369609L, l2);
        }
        try {
            color = bl ? color6 : color5;
        }
        catch (MatchException matchException) {
            throw GameRenderUtil.invokeBinding21(matchException, -2177993863964369609L, l2);
        }
        Object[] objectArray2 = new Object[9];
        objectArray2[8] = l;
        objectArray2[7] = color;
        objectArray2[6] = color2;
        objectArray2[5] = color3;
        objectArray2[4] = color4;
        objectArray2[3] = Float.valueOf(f);
        objectArray2[2] = Float.valueOf(f10);
        objectArray2[1] = Float.valueOf(f11);
        objectArray2[0] = Float.valueOf(f12);
        GameRenderUtil.invokeBinding22(objectArray2, -2163105833205964270L, l2);
    }

   public static void gReturningVoid(Object[] var0) {
      float var3 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var9 = (Float)var0[2];
      float var6 = (Float)var0[3];
      Color var2 = (Color)var0[4];
      Color var7 = (Color)var0[5];
      Color var8 = (Color)var0[6];
      Color var10 = (Color)var0[7];
      long var4 = (Long)var0[8];
      var4 = 46097011089910L ^ var4;
      long var11 = var4 ^ 69551738190580L;
      Object[] var10010 = new Object[]{null, null, null, null, var8, var10, var7, var2, var11};
      var10010[3] = var6;
      var10010[2] = var9;
      var10010[1] = var1;
      var10010[0] = var3;
      invokeBinding23(var10010, -1947553384261909220L, var4);
   }

   public static void hReturningVoid(Object[] var0) {
      float var5 = (Float)var0[0];
      float var7 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var4 = (Float)var0[3];
      Color var3 = (Color)var0[4];
      float var8 = (Float)var0[5];
      long var1 = (Long)var0[6];
      var1 = 46097011089910L ^ var1;
      long var9 = var1 ^ 63988467369434L;
      Color var11 = new Color(1.0F, 1.0F, 1.0F, var8);
      Color var12 = new Color(
         invokeBinding24(var3, 2012799821243960095L, var1) / 255.0F,
         invokeBinding25(var3, 2011808383562264004L, var1) / 255.0F,
         invokeBinding26(var3, 2006929755797062775L, var1) / 255.0F,
         var8
      );
      Color var13 = new Color(0.0F, 0.0F, 0.0F, 0.0F);
      Color var14 = new Color(0.0F, 0.0F, 0.0F, var8);
      Object[] var10010 = new Object[]{null, null, null, null, var11, var12, var12, var11, var9};
      var10010[3] = var4;
      var10010[2] = var6;
      var10010[1] = var7;
      var10010[0] = var5;
      invokeBinding27(var10010, 2006041305088424498L, var1);
      var10010 = new Object[]{null, null, null, null, var14, var14, var13, var13, var9};
      var10010[3] = var4;
      var10010[2] = var6;
      var10010[1] = var7;
      var10010[0] = var5;
      invokeBinding28(var10010, 2006041305088424498L, var1);
   }

   public static void iReturningVoid(Object[] var0) {
      float var4 = (Float)var0[0];
      float var5 = (Float)var0[1];
      float var3 = (Float)var0[2];
      Color var6 = (Color)var0[3];
      long var1 = (Long)var0[4];
      var1 = 46097011089910L ^ var1;
      long var7 = var1 ^ 140684376428926L;
      int var9 = invokeBinding29(var6, -3241738869078323675L, var1);
      Matrix4f var10000 = q;
      float var10003 = var4 + 2.5F;
      float var10004 = var5 + 2.5F * var3;
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var7};
      var10008[5] = var9;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var5;
      var10008[1] = var4;
      var10008[0] = var10000;
      invokeBinding30(var10008, -3225798262471956770L, var1);
      var10000 = q;
      float var10001 = var4 + 5.0F;
      var10003 = var4 + 2.5F;
      var10004 = var5 + 2.5F * var3;
      var10008 = new Object[]{null, null, null, null, null, null, var7};
      var10008[5] = var9;
      var10008[4] = var10004;
      var10008[3] = var10003;
      var10008[2] = var5;
      var10008[1] = var10001;
      var10008[0] = var10000;
      invokeBinding31(var10008, -3225798262471956770L, var1);
   }

   public static void jReturningVoid(Object[] var0) {
      float var5 = (Float)var0[0];
      float var4 = (Float)var0[1];
      float var1 = (Float)var0[2];
      float var6 = (Float)var0[3];
      Color var7 = (Color)var0[4];
      float var8 = (Float)var0[5];
      long var2 = (Long)var0[6];
      var2 = 46097011089910L ^ var2;
      long var9 = var2 ^ 109183724030382L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var9};
      var10011[8] = 0.25F;
      var10011[7] = var8;
      var10011[6] = var7;
      var10011[5] = var6;
      var10011[4] = var1;
      var10011[3] = var4;
      var10011[2] = var5;
      var10011[1] = var10001;
      var10011[0] = var10000;
      invokeBinding32(var10011, 5063909543532351684L, var2);
   }

   public static void kReturningVoid(Object[] var0) {
      float var6 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var2 = (Float)var0[3];
      Color var9 = (Color)var0[4];
      float var8 = (Float)var0[5];
      float var7 = (Float)var0[6];
      long var4 = (Long)var0[7];
      var4 = 46097011089910L ^ var4;
      long var10 = var4 ^ 64112015498579L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var10};
      var10011[8] = var7;
      var10011[7] = var8;
      var10011[6] = var9;
      var10011[5] = var2;
      var10011[4] = var3;
      var10011[3] = var1;
      var10011[2] = var6;
      var10011[1] = var10001;
      var10011[0] = var10000;
      invokeBinding33(var10011, -7873479741460052935L, var4);
   }

   public static void lReturningVoid(Object[] var0) {
      Matrix4f var3 = (Matrix4f)var0[0];
      float var2 = (Float)var0[1];
      float var9 = (Float)var0[2];
      float var4 = (Float)var0[3];
      float var8 = (Float)var0[4];
      Color var7 = (Color)var0[5];
      float var1 = (Float)var0[6];
      long var5 = (Long)var0[7];
      var5 = 46097011089910L ^ var5;
      long var10 = var5 ^ 122291299742915L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, null, var10};
      var10012[9] = 0.25F;
      var10012[8] = var1;
      var10012[7] = var7;
      var10012[6] = var8;
      var10012[5] = var4;
      var10012[4] = var9;
      var10012[3] = var2;
      var10012[2] = var3;
      var10012[1] = var10001;
      var10012[0] = var10000;
      Object[] var12 = var10012;
      ShapeRenderer.C(var12);
   }

   public static void mReturningVoid(Object[] var0) {
      float var5 = (Float)var0[0];
      float var8 = (Float)var0[1];
      float var4 = (Float)var0[2];
      float var7 = (Float)var0[3];
      Color var6 = (Color)var0[4];
      float var3 = (Float)var0[5];
      long var1 = (Long)var0[6];
      var1 = 46097011089910L ^ var1;
      long var9 = var1 ^ 97064128256578L;
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var9};
      var10008[5] = var3;
      var10008[4] = var6;
      var10008[3] = var7;
      var10008[2] = var4;
      var10008[1] = var8;
      var10008[0] = var5;
      invokeBinding34(var10008, -1834350372602935147L, var1);
   }

   public static void nReturningVoid(Object[] var0) {
      Matrix4f var5 = (Matrix4f)var0[0];
      float var2 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var4 = (Float)var0[3];
      float var9 = (Float)var0[4];
      Color var3 = (Color)var0[5];
      float var1 = (Float)var0[6];
      long var7 = (Long)var0[7];
      var7 = 46097011089910L ^ var7;
      long var10 = var7 ^ 52537152658777L;
      float var13 = var1;
      Vector4f var12 = t;
      Object[] var10009 = new Object[]{null, null, null, null, null, var3, var12.set(var13), var10};
      var10009[4] = var9;
      var10009[3] = var4;
      var10009[2] = var6;
      var10009[1] = var2;
      var10009[0] = var5;
      Object[] var14 = var10009;
      ShapeRenderer.u(var14);
   }

   public static void o(Object[] var0) {
      float var11 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var9 = (Float)var0[2];
      float var7 = (Float)var0[3];
      float var4 = (Float)var0[4];
      Color var10 = (Color)var0[5];
      Color var6 = (Color)var0[6];
      Color var8 = (Color)var0[7];
      Color var5 = (Color)var0[8];
      long var2 = (Long)var0[9];
      var2 = 46097011089910L ^ var2;
      long var12 = var2 ^ 130025425495714L;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
      var10011[8] = var4;
      var10011[7] = var5;
      var10011[6] = var8;
      var10011[5] = var6;
      var10011[4] = var10;
      var10011[3] = var7;
      var10011[2] = var9;
      var10011[1] = var1;
      var10011[0] = var11;
      invokeBinding35(var10011, 4288893680790290345L, var2);
   }

   public static void p(Object[] var0) {
      Matrix4f var10 = (Matrix4f)var0[0];
      float var12 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var7 = (Float)var0[3];
      float var6 = (Float)var0[4];
      float var1 = (Float)var0[5];
      Color var9 = (Color)var0[6];
      Color var8 = (Color)var0[7];
      Color var2 = (Color)var0[8];
      Color var11 = (Color)var0[9];
      long var4 = (Long)var0[10];
      var4 = 46097011089910L ^ var4;
      long var13 = var4 ^ 18695151151944L;
      float var16 = var1;
      Vector4f var15 = t;
      Object[] var10012 = new Object[]{null, null, null, null, null, var9, var8, var2, var11, var15.set(var16), var13};
      var10012[4] = var6;
      var10012[3] = var7;
      var10012[2] = var3;
      var10012[1] = var12;
      var10012[0] = var10;
      Object[] var17 = var10012;
      ShapeRenderer.w(var17);
   }

   public static void q(Object[] var0) {
      float var5 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var7 = (Float)var0[3];
      Color var2 = (Color)var0[4];
      long var3 = (Long)var0[5];
      var3 = 46097011089910L ^ var3;
      long var8 = var3 ^ 4555137096186L;
      Object[] var10007 = new Object[]{null, null, null, null, var2, var8};
      var10007[3] = var7;
      var10007[2] = var6;
      var10007[1] = var1;
      var10007[0] = var5;
      invokeBinding36(var10007, 6443770682569797660L, var3);
   }

   public static void r(Object[] var0) {
      Matrix4f var7 = (Matrix4f)var0[0];
      float var4 = (Float)var0[1];
      float var1 = (Float)var0[2];
      float var6 = (Float)var0[3];
      float var5 = (Float)var0[4];
      Color var8 = (Color)var0[5];
      long var2 = (Long)var0[6];
      var2 = 46097011089910L ^ var2;
      long var9 = var2 ^ 48389743139965L;
      Object[] var10008 = new Object[]{null, null, null, null, null, var8, var9};
      var10008[4] = var5;
      var10008[3] = var6;
      var10008[2] = var1;
      var10008[1] = var4;
      var10008[0] = var7;
      Object[] var11 = var10008;
      ShapeRenderer.lReturningVoid(var11);
   }

   public static void s(Object[] var0) {
      float var5 = (Float)var0[0];
      float var6 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var1 = (Float)var0[3];
      Color var2 = (Color)var0[4];
      long var3 = (Long)var0[5];
      var3 = 46097011089910L ^ var3;
      long var8 = var3 ^ 32371812996765L;
      int var10 = invokeBinding37(var2, -7719058512900208186L, var3);
      Matrix4f var10000 = q;
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10;
      var10008[4] = var1;
      var10008[3] = var7;
      var10008[2] = var6;
      var10008[1] = var5;
      var10008[0] = var10000;
      invokeBinding38(var10008, -7721198288251444931L, var3);
      var10000 = q;
      var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10;
      var10008[4] = var6;
      var10008[3] = var7;
      var10008[2] = var1;
      var10008[1] = var5;
      var10008[0] = var10000;
      invokeBinding39(var10008, -7721198288251444931L, var3);
   }

   public static void t(Object[] var0) {
      float var1 = (Float)var0[0];
      float var2 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var3 = (Float)var0[3];
      Color var6 = (Color)var0[4];
      long var4 = (Long)var0[5];
      var4 = 46097011089910L ^ var4;
      long var8 = var4 ^ 112497892876180L;
      Matrix4f var10000 = q;
      int var10005 = invokeBinding40(var6, 6800275139529278329L, var4);
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10005;
      var10008[4] = var3;
      var10008[3] = var7;
      var10008[2] = var2;
      var10008[1] = var1;
      var10008[0] = var10000;
      invokeBinding41(var10008, 6797857159635213112L, var4);
   }

   public static void u(Object[] var0) {
      float var8 = (Float)var0[0];
      float var4 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var7 = (Float)var0[3];
      ManagedGlTexture var6 = (ManagedGlTexture)var0[4];
      Color var5 = (Color)var0[5];
      long var1 = (Long)var0[6];
      var1 = 46097011089910L ^ var1;
      long var9 = var1 ^ 90168244956681L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, null, var5, var9};
      var10010[6] = var7;
      var10010[5] = var3;
      var10010[4] = var4;
      var10010[3] = var8;
      var10010[2] = var6;
      var10010[1] = var10001;
      var10010[0] = var10000;
      invokeBinding42(var10010, -7026343687731477302L, var1);
   }

   public static void v(Object[] var0) {
      float var4 = (Float)var0[0];
      float var2 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var1 = (Float)var0[3];
      Matrix4f var3 = (Matrix4f)var0[4];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[5];
      Color var6 = (Color)var0[6];
      long var8 = (Long)var0[7];
      var8 = 46097011089910L ^ var8;
      long var10 = var8 ^ 138292308965472L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, var3, var6, var10};
      var10011[6] = var1;
      var10011[5] = var7;
      var10011[4] = var2;
      var10011[3] = var4;
      var10011[2] = var5;
      var10011[1] = var10001;
      var10011[0] = var10000;
      Object[] var12 = var10011;
      TexturedRectangleRenderer.dReturningVoid(var12);
   }

   public static void w(Object[] var0) {
      float var2 = (Float)var0[0];
      float var6 = (Float)var0[1];
      float var9 = (Float)var0[2];
      float var3 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var12 = (Float)var0[5];
      float var4 = (Float)var0[6];
      float var1 = (Float)var0[7];
      float var13 = (Float)var0[8];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[9];
      Color var11 = (Color)var0[10];
      long var7 = (Long)var0[11];
      var7 = 46097011089910L ^ var7;
      long var14 = var7 ^ 26186809143163L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10015 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var11, var14};
      var10015[11] = var13;
      var10015[10] = var1;
      var10015[9] = var4;
      var10015[8] = var12;
      var10015[7] = var10;
      var10015[6] = var3;
      var10015[5] = var9;
      var10015[4] = var6;
      var10015[3] = var2;
      var10015[2] = var5;
      var10015[1] = var10001;
      var10015[0] = var10000;
      invokeBinding43(var10015, 3804524253128098787L, var7);
   }

   public static void x(Object[] var0) {
      float var8 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var2 = (Float)var0[2];
      float var14 = (Float)var0[3];
      float var12 = (Float)var0[4];
      float var1 = (Float)var0[5];
      float var7 = (Float)var0[6];
      float var9 = (Float)var0[7];
      float var6 = (Float)var0[8];
      Matrix4f var13 = (Matrix4f)var0[9];
      ManagedGlTexture var4 = (ManagedGlTexture)var0[10];
      Color var5 = (Color)var0[11];
      long var10 = (Long)var0[12];
      var10 = 46097011089910L ^ var10;
      long var15 = var10 ^ 75225308986653L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, new Vector4f(var6), var5, var15};
      var10016[11] = var9;
      var10016[10] = var7;
      var10016[9] = var1;
      var10016[8] = var12;
      var10016[7] = var14;
      var10016[6] = var2;
      var10016[5] = var3;
      var10016[4] = var8;
      var10016[3] = var4;
      var10016[2] = var13;
      var10016[1] = var10001;
      var10016[0] = var10000;
      Object[] var17 = var10016;
      TexturedRectangleRenderer.E(var17);
   }

   public static void y(Object[] var0) {
      float var2 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var4 = (Float)var0[2];
      float var6 = (Float)var0[3];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[4];
      Color var1 = (Color)var0[5];
      Color var9 = (Color)var0[6];
      long var7 = (Long)var0[7];
      var7 = 46097011089910L ^ var7;
      long var10 = var7 ^ 21027365070960L;
      MeshBufferManager var10000 = g;
      RenderContext var10001 = h;
      Object[] var10015 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, TextureTintMode.MULTIPLY, var10};
      var10015[11] = 0.0F;
      var10015[10] = var9;
      var10015[9] = var1;
      var10015[8] = var9;
      var10015[7] = var1;
      var10015[6] = var6;
      var10015[5] = var4;
      var10015[4] = var3;
      var10015[3] = var2;
      var10015[2] = var5;
      var10015[1] = var10001;
      var10015[0] = var10000;
      invokeBinding44(var10015, -4562815524289693610L, var7);
   }

   public static boolean aReturningBoolean(Object[] var0) {
      Matrix4f var1;
      float var2;
      float var3;
      float var4;
      ItemStack var7;
      long var8;
      long var10;
      long var12;
      long var14;
      long var16;
      long var18;
      long var20;
      long var22;
      int var24;
      Identifier var25;
      long var109;
      label41: {
         var7 = (ItemStack)var0[0];
         var2 = (Float)var0[1];
         var3 = (Float)var0[2];
         var4 = (Float)var0[3];
         var1 = (Matrix4f)var0[4];
         long var5 = (Long)var0[5];
         var109 = 46097011089910L ^ var5;
         var8 = var109 ^ 66956576260376L;
         var10 = var109 ^ 114231452280895L;
         var12 = var109 ^ 97009186601472L;
         var14 = var109 ^ 32903766577474L;
         var16 = var109 ^ 130472313981828L;
         var18 = var109 ^ 136412206870781L;
         var20 = var109 ^ 19647684427622L;
         var22 = var109 ^ 36061931802118L;
         int var10000 = Event.cReturningInt();
         ComponentType var37 = DataComponentTypes.ITEM_MODEL;
         ItemStack var36 = var7;
         var25 = (Identifier)var36.get(var37);
         var24 = var10000;
         int var96 = var24;
         Identifier var95 = var25;
         Identifier var88 = var95;
         Identifier var87 = var95;
         if (var96 != 0) {
            Identifier var97 = var87;
            if (var97 != null) {
               break label41;
            }

            DefaultedRegistry var111 = Registries.ITEM;
            ItemStack var39 = var7;
            Item var41 = var39.getItem();
            DefaultedRegistry var40 = var111;
            Identifier var98 = var40.getId(var41);
            var88 = var98;
         }

         var25 = var88;
      }

      Identifier var10002 = y;
      Identifier var43 = var25;
      String var10003 = var43.getNamespace();
      Identifier var44 = var25;
      String var10004 = var44.getPath();
      short var10005 = 6018;
      long var10006 = 1522898631253060772L ^ var109;
      String var46 = "item/" + var10004;
      String var45 = var10003;
      SpriteIdentifier var26 = new SpriteIdentifier(var10002, Identifier.of(var45, var46));
      MinecraftClient var47 = b;
      AtlasManager var112 = var47.getAtlasManager();
      SpriteIdentifier var49 = var26;
      AtlasManager var48 = var112;
      Sprite var27 = var48.getSprite(var49);
      Sprite var50 = var27;
      SpriteContents var51 = var50.getContents();
      Identifier var113 = var51.getId();
      int var100 = var24;
      Identifier var99 = var113;
      Identifier var90 = var99;
      Identifier var89 = var99;
      if (var100 != 0) {
         Identifier var52 = var89;
         String var114 = var52.getPath();
         short var10001 = 12309;
         long var120 = 3573557544266484530L ^ var109;
         String var54 = "missingno";
         String var53 = var114;
         boolean var101 = var53.equals(var54);
         if (var101) {
            return false;
         }

         Sprite var57 = var27;
         var90 = var57.getAtlasId();
      }

      Identifier var28 = var90;
      Sprite var58 = var27;
      float var29 = var58.getMinU();
      Sprite var59 = var27;
      float var30 = var59.getMaxU();
      Sprite var60 = var27;
      float var31 = var60.getMinV();
      Sprite var61 = var27;
      float var32 = var61.getMaxV();
      float var33 = 16.0F * var4;
      float var128 = var29 * var33;
      float var135 = var33 - var32 * var33;
      float var140 = (var30 - var29) * var33;
      float var10007 = (var32 - var31) * var33;
      Object[] var62 = new Object[]{var28, var18};
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, null, var1, ManagedGlTexture.dReturningbT_C0095(var62), Color.WHITE, var10};
      var10014[8] = 0.0F;
      var10014[7] = var10007;
      var10014[6] = var140;
      var10014[5] = var135;
      var10014[4] = var128;
      var10014[3] = var33;
      var10014[2] = var33;
      var10014[1] = var3;
      var10014[0] = var2;
      Object[] var63 = var10014;
      x(var63);
      ItemStack var64 = var7;
      int var115 = var64.getCount();
      int var103 = var24;
      int var102 = var115;
      int var92 = var102;
      int var91 = var102;
      if (var103 != 0) {
         byte var105 = 1;
         int var104 = var91;
         if (var104 > var105) {
            ItemStack var66 = var7;
            int var67 = var66.getCount();
            String var34 = String.valueOf(var67);
            MsdfFontManager var116 = Prestige.c;
            Object[] var69 = new Object[]{var14};
            MsdfFontManager var68 = var116;
            MsdfFont var117 = var68.aReturningcx_C0158(var69);
            float var123 = var2 + var33;
            MsdfFontManager var129 = Prestige.c;
            Object[] var71 = new Object[]{var14};
            MsdfFontManager var70 = var129;
            MsdfFont var130 = var70.aReturningcx_C0158(var71);
            Object[] var73 = new Object[]{var34, var12};
            MsdfFont var72 = var130;
            float var124 = var123 - var72.aReturningFloat(var73) * var4;
            float var131 = var3 + var33;
            MsdfFontManager var136 = Prestige.c;
            Object[] var75 = new Object[]{var14};
            MsdfFontManager var74 = var136;
            MsdfFont var137 = var74.aReturningcx_C0158(var75);
            Object[] var77 = new Object[]{var8};
            MsdfFont var76 = var137;
            float var132 = var131 - var76.cReturningFloat(var77) * var4;
            Object[] var10009 = new Object[]{null, null, null, null, null, Color.WHITE, var16};
            var10009[4] = var4;
            var10009[3] = var132;
            var10009[2] = var124;
            var10009[1] = var34;
            var10009[0] = var1;
            Object[] var79 = var10009;
            MsdfFont var78 = var117;
            var78.w(var79);
         }

         ItemStack var80 = var7;
         var92 = (((var80.isItemBarVisible()) ? 1 : 0));
      }

      int var107 = var24;
      int var106 = var92;
      int var94 = var106;
      int var93 = var106;
      if (var107 != 0) {
         int var108 = var93;
         if (var108 != 0) {
            int var110 = (int)(var2 + 2.0F * var4);
            int var35 = (int)(var3 + 16.0F * var4);
            float var118 = var110;
            float var121 = var35;
            float var125 = var110 + 13.0F * var4;
            float var133 = var35 + var4;
            Color var138 = v;
            Object[] var142 = new Object[]{null, null, null, null, null, null, null, var22};
            var142[6] = 2.0F;
            var142[5] = var138;
            var142[4] = var133;
            var142[3] = var125;
            var142[2] = var121;
            var142[1] = var118;
            var142[0] = var1;
            Object[] var82 = var142;
            nReturningVoid(var82);
            var118 = var110;
            float var122 = var35;
            float var126 = var110;
            ItemStack var83 = var7;
            float var127 = var126 + var83.getItemBarStep() * var4;
            float var134 = var35 + var4;
            ItemStack var84 = var7;
            int var141 = var84.getItemBarColor();
            Object[] var10010 = new Object[]{null, var20};
            var10010[0] = var141;
            Object[] var85 = var10010;
            Color var139 = new Color(aReturningInt(var85));
            var142 = new Object[]{null, null, null, null, null, null, null, var22};
            var142[6] = 2.0F;
            var142[5] = var139;
            var142[4] = var134;
            var142[3] = var127;
            var142[2] = var122;
            var142[1] = var118;
            var142[0] = var1;
            Object[] var86 = var142;
            nReturningVoid(var86);
         }

         var94 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var94);
   }

   public static int aReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 46097011089910L ^ var2;
      short var10001 = 32545;
      long var10002 = 3724477837305620772L ^ var2;
      return var1 | 0xFF000000;
   }

   public static float aReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 46097011089910L ^ var1;
      MinecraftClient var3 = b;
      RenderTickCounter var4 = var3.getRenderTickCounter();
      return var4.getTickProgress(false);
   }

   static {

      {

      aReturningVoid();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(67120351846583L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[2];
      String var26 = "ä5\u009eÄøäÀ\u007f\u00126\u0001o°¼äe \u0005sù\u0099\tcàêGÝ'\b:\u009e_Z\u000fñ\u0098\u0089gìF\u0087ö%2¼\u0085´\u008eI";
      int var28 = "ä5\u009eÄøäÀ\u007f\u00126\u0001o°¼äe \u0005sù\u0099\tcàêGÝ'\b:\u009e_Z\u000fñ\u0098\u0089gìF\u0087ö%2¼\u0085´\u008eI".length();
      char var25 = 16;
      int var24 = -1;

      while (true) {
         byte[] var30 = var22.doFinal(var26.substring(++var24, var24 + var25).getBytes("ISO-8859-1"));
         String var49 = a(var30).intern();
         int var10001 = -1;
         var29[var27++] = var49;
         if ((var24 += var25) >= var28) {
            A = var29;
            B = new String[2];
            F = new HashMap(13);
            Cipher var11;
            var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var12 = 1; var12 < 8; var12++) {
               var10003[var12] = (byte)(67120351846583L << var12 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var17 = new long[4];
            String var15 = "UEAë0Â@á?\u008cª\u000b\u009c\u0014¤¼";
            int var16 = "UEAë0Â@á?\u008cª\u000b\u009c\u0014¤¼".length();
            label59:
            while (true) {
               var10001 = var13;
               var13 += 8;
               byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
               long[] var35 = var17;
               var10001 = var14++;
               long var52 = (var18[0] & 255L) << 56
                  | (var18[1] & 255L) << 48
                  | (var18[2] & 255L) << 40
                  | (var18[3] & 255L) << 32
                  | (var18[4] & 255L) << 24
                  | (var18[5] & 255L) << 16
                  | (var18[6] & 255L) << 8
                  | var18[7] & 255L;
               // while (true) {
                  long var19 = var52;
                  byte[] var21 = var11.doFinal(
                     new byte[]{
                        (byte)(var19 >>> 56),
                        (byte)(var19 >>> 48),
                        (byte)(var19 >>> 40),
                        (byte)(var19 >>> 32),
                        (byte)(var19 >>> 24),
                        (byte)(var19 >>> 16),
                        (byte)(var19 >>> 8),
                        (byte)var19
                     }
                  );
                  long var63 = (var21[0] & 255L) << 56
                     | (var21[1] & 255L) << 48
                     | (var21[2] & 255L) << 40
                     | (var21[3] & 255L) << 32
                     | (var21[4] & 255L) << 24
                     | (var21[5] & 255L) << 16
                     | (var21[6] & 255L) << 8
                     | var21[7] & 255L;
                  switch (var58) {
                     case 0:
                        var35[var10001] = var63;
                        if (var13 >= var16) {
                           D = var17;
                           E = new Integer[4];
                           I = new HashMap(13);
                           Cipher var0;
                           var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                           var10002 = SecretKeyFactory.getInstance("DES");
                           var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                           for (int var1 = 1; var1 < 8; var1++) {
                              var10003[var1] = (byte)(67120351846583L << var1 * 8 >>> 56);
                           }

                           var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                           long[] var6 = new long[4];
                           String var4 = "! \u0006ÒC÷Q¹ÆYÆ }ìn\u0088";
                           int var5 = "! \u0006ÒC÷Q¹ÆYÆ }ìn\u0088".length();
                           label43:
                           while (true) {
                              int var44 = var2;
                              var2 += 8;
                              byte[] var7 = var4.substring(var44, var2).getBytes("ISO-8859-1");
                              long[] var37 = var6;
                              var44 = var3++;
                              long var55 = (var7[0] & 255L) << 56
                                 | (var7[1] & 255L) << 48
                                 | (var7[2] & 255L) << 40
                                 | (var7[3] & 255L) << 32
                                 | (var7[4] & 255L) << 24
                                 | (var7[5] & 255L) << 16
                                 | (var7[6] & 255L) << 8
                                 | var7[7] & 255L;
                              // while (true) {
                                 long var8 = var55;
                                 byte[] var10 = var0.doFinal(
                                    new byte[]{
                                       (byte)(var8 >>> 56),
                                       (byte)(var8 >>> 48),
                                       (byte)(var8 >>> 40),
                                       (byte)(var8 >>> 32),
                                       (byte)(var8 >>> 24),
                                       (byte)(var8 >>> 16),
                                       (byte)(var8 >>> 8),
                                       (byte)var8
                                    }
                                 );
                                 var63 = (var10[0] & 255L) << 56
                                    | (var10[1] & 255L) << 48
                                    | (var10[2] & 255L) << 40
                                    | (var10[3] & 255L) << 32
                                    | (var10[4] & 255L) << 24
                                    | (var10[5] & 255L) << 16
                                    | (var10[6] & 255L) << 8
                                    | var10[7] & 255L;
                                 switch (var61) {
                                    case 0:
                                       var37[var44] = var63;
                                       if (var2 >= var5) {
                                          G = var6;
                                          H = new Long[4];
                                          b = MinecraftClient.getInstance();
                                          short var38 = 14106;
                                          d = new Matrix4f();
                                          long var47 = 7526933913680646699L;
                                          e = new Matrix4f();
                                          f = new Matrix4f();
                                          i = new int[4];
                                          j = false;
                                          k = new Matrix4f();
                                          l = new Matrix4f();
                                          m = new Vector3f();
                                          n = new Vector4f();
                                          o = Long.MIN_VALUE;
                                          short var39 = 3257;
                                          long var48 = 2354054791020292490L;
                                          p = 0L;
                                          q = new Matrix4f();
                                          r = new float[3];
                                          s = 1;
                                          t = new Vector4f();
                                          u = new Color(0, 0, 0, 0);
                                          v = new Color(0, 0, 0, 200);
                                          w = Float.NaN;
                                          x = u;
                                          y = SpriteAtlasTexture.ITEMS_ATLAS_TEXTURE;
                                          break;
                                       }
                                       break;
                                    default:
                                       var37[var44] = var63;
                                       if (var2 < var5) {
                                          continue label43;
                                       }

                                       var4 = "ðÄyG¬1\u0088vZHÉ\u0003¿ÌgÈ";
                                       var5 = "ðÄyG¬1\u0088vZHÉ\u0003¿ÌgÈ".length();
                                       var2 = 0;
                                 }

                                 int var46 = var2;
                                 var2 += 8;
                                 var7 = var4.substring(var46, var2).getBytes("ISO-8859-1");
                                 var37 = var6;
                                 var44 = var3++;
                                 var55 = (var7[0] & 255L) << 56
                                    | (var7[1] & 255L) << 48
                                    | (var7[2] & 255L) << 40
                                    | (var7[3] & 255L) << 32
                                    | (var7[4] & 255L) << 24
                                    | (var7[5] & 255L) << 16
                                    | (var7[6] & 255L) << 8
                                    | var7[7] & 255L;
                                 var61 = 0;
                              }
                           }
                        }
                        break;
                     default:
                        var35[var10001] = var63;
                        if (var13 < var16) {
                           continue label59;
                        }

                        var15 = "H\u0091ô\u008a\u0095qçæj'6\r\r\u0014µQ";
                        var16 = "H\u0091ô\u008a\u0095qçæj'6\r\r\u0014µQ".length();
                        var13 = 0;
                  }

                  int var43 = var13;
                  var13 += 8;
                  var18 = var15.substring(var43, var13).getBytes("ISO-8859-1");
                  var35 = var17;
                  var10001 = var14++;
                  var52 = (var18[0] & 255L) << 56
                     | (var18[1] & 255L) << 48
                     | (var18[2] & 255L) << 40
                     | (var18[3] & 255L) << 32
                     | (var18[4] & 255L) << 24
                     | (var18[5] & 255L) << 16
                     | (var18[6] & 255L) << 8
                     | var18[7] & 255L;
                  var58 = 0;
               }
            }
         }

         var25 = var26.charAt(var24);
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 29467;
      if (B[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])C.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               C.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dw", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = A[var5].getBytes("ISO-8859-1");
         B[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return B[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dw_C0208",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 16554;
      if (E[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = D[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])F.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               F.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dw", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         E[var3] = var15;
      }

      return E[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dw_C0208",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9523;
      if (H[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = G[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])I.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               I.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dw", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         H[var3] = var15;
      }

      return H[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dw_C0208",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = K[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = J[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 5;
            yield var16;
         }
         case 2 -> {
            byte var17 = 25;
            yield var17;
         }
         case 3 -> {
            byte var18 = 60;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 30;
            yield var20;
         }
         case 6 -> {
            byte var21 = 62;
            yield var21;
         }
         case 7 -> {
            byte var22 = 52;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 55;
            yield var24;
         }
         case 10 -> {
            byte var25 = 13;
            yield var25;
         }
         case 11 -> {
            byte var26 = 29;
            yield var26;
         }
         case 12 -> {
            byte var27 = 15;
            yield var27;
         }
         case 13 -> {
            byte var28 = 4;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 16;
            yield var30;
         }
         case 16 -> {
            byte var31 = 23;
            yield var31;
         }
         case 17 -> {
            byte var32 = 46;
            yield var32;
         }
         case 18 -> {
            byte var33 = 24;
            yield var33;
         }
         case 19 -> {
            byte var34 = 54;
            yield var34;
         }
         case 20 -> {
            byte var35 = 45;
            yield var35;
         }
         case 21 -> {
            byte var36 = 38;
            yield var36;
         }
         case 22 -> {
            byte var37 = 41;
            yield var37;
         }
         case 23 -> {
            byte var38 = 42;
            yield var38;
         }
         case 24 -> {
            byte var39 = 8;
            yield var39;
         }
         case 25 -> {
            byte var40 = 22;
            yield var40;
         }
         case 26 -> {
            byte var41 = 20;
            yield var41;
         }
         case 27 -> {
            byte var42 = 51;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 32;
            yield var44;
         }
         case 30 -> {
            byte var45 = 36;
            yield var45;
         }
         case 31 -> {
            byte var46 = 35;
            yield var46;
         }
         case 32 -> {
            byte var47 = 49;
            yield var47;
         }
         case 33 -> {
            byte var48 = 0;
            yield var48;
         }
         case 34 -> {
            byte var49 = 39;
            yield var49;
         }
         case 35 -> {
            byte var50 = 11;
            yield var50;
         }
         case 36 -> {
            byte var51 = 12;
            yield var51;
         }
         case 37 -> {
            byte var52 = 27;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 19;
            yield var54;
         }
         case 40 -> {
            byte var55 = 59;
            yield var55;
         }
         case 41 -> {
            byte var56 = 63;
            yield var56;
         }
         case 42 -> {
            byte var57 = 56;
            yield var57;
         }
         case 43 -> {
            byte var58 = 58;
            yield var58;
         }
         case 44 -> {
            byte var59 = 14;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 47;
            yield var61;
         }
         case 47 -> {
            byte var62 = 53;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 10;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 1;
            yield var66;
         }
         case 52 -> {
            byte var67 = 44;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 3;
            yield var69;
         }
         case 55 -> {
            byte var70 = 28;
            yield var70;
         }
         case 56 -> {
            byte var71 = 34;
            yield var71;
         }
         case 57 -> {
            byte var72 = 37;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 57;
            yield var74;
         }
         case 60 -> {
            byte var75 = 2;
            yield var75;
         }
         case 61 -> {
            byte var76 = 48;
            yield var76;
         }
         case 62 -> {
            byte var77 = 9;
            yield var77;
         }
         default -> 50;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            K[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      J[0] = "\u0012$2u\u0003\u0000\u0004$7/\u0010\u0017\u0013o4)\u001c\u0003\u0002(#>W\u00113";
      J[1] = int.class;
      K[1] = "java/lang/Integer";
      J[2] = "7\u0013(w\\-!\u0013--O:6X.+C.'\u001f9<\b9$";
      J[3] = "\u001b-5@p\u0013\u0010\"$\u000f\u0013\u001e\u0005/+d&\u001c\u0014<7H1\u0011";
      J[4] = "\u00036hOW\b\b9y\u0000*\u001d\u001a#{C";
      J[5] = long.class;
      K[5] = "java/lang/Long";
      J[6] = "R\u0011UuvxD\u0011P/eoSZS)i{B\u001dD>\"l\\";
      J[7] = "Y\u0018P\u0001|\r,8[\u000emBM6P\u0005i\u00189";
      J[8] = "3\u0011G2\u001bl6\u0004L2\u0018k9\rGpY\\\u0010R\u0011";
      J[9] = "\"1";
      J[10] = void.class;
      K[10] = "java/lang/Void";
      J[11] = "L\u0000nUo\u001cZ\u0000k\u000f|\u000bMKh\tp\u001f\\\f\u007f\u001e;\bO";
      J[12] = "dT5.=l\u0011t>!,#pz5*(y\u0004";
      J[13] = "Z\u0000quqLL\u0000t/b[[Kw)nOJ\f`>%XH";
      J[14] = "=d\u00172\nEHD\u001c=\u001b\n)J\u00176\u001fP]";
      J[15] = "\u001f>w~%\u000ej\u001e|q4A\u000b\u0010wz0\u001b\u007f";
      J[16] = "z]\u000b/2\u001a\u000f}\u0000 #Uns\u000b+'\u000f\u001a";
      J[17] = "bu9`z\u0016\u0017U2okYv[9do\u0003\u0002";
      J[18] = "\u007f\u007f\u001b)f\u0017\n_\u0010&wXkQ\u001b-s\u0002\u001f";
      J[19] = "ut\u0001&]\u001e\u0000T\n)LQaZ\u0001\"H\u000b\u0015";
      J[20] = "b(UVi;\u007f=\rt(6g;";
      J[21] = "Y{\u000349X,[\b;(\u0017MU\u00030,M9";
      J[22] = "\u001d&r~TV\u0016)c17[\u0003/";
      J[23] = float.class;
      K[23] = "java/lang/Float";
      J[24] = "-B";
      J[25] = "t{";
      J[26] = "\u0014]G=C\u000fa}L2R@\u0000sG9V\u001at";
      J[27] = "\"T~R\ryWtu]\u001c66z~V\u0018lB";
      J[28] = "3?AH5>F\u001fJG$q'\u0011AL +S";
      J[29] = "\u0011=\t\u001c>id\u001d\u0002\u0013/&\u0005\u0013\t\u0018+|q";
      J[30] = "&fY\b\u0006O$x\u0010p\tC={L\u0012\n";
      J[31] = "gfI=\n;\u0012FB2\u001btsHI9\u001f.\u0007";
      J[32] = "OK3j's:k8e6<[e3n2f/";
      J[33] = "TSi\tTk!sb\u0006E$@}i\rA~4";
      J[34] = "jN}8\u0003\u0013jNjd\u000f\u001cp\u0005jz\u000f\twt;\"]";
      J[35] = double.class;
      K[35] = "java/lang/Double";
      J[36] = "e+!!T\u001ce+6}X\u0013\u007f`6cX\u0006x\u0011d=\u0000B";
      J[37] = "%C%\u0019\u0018v3C C\u000ba$\b#E\u0007u5O4RLer";
      J[38] = "I&-\u0012\u0007!<\u0006&\u001d\u0016n]\b-\u0016\u00124)";
      J[39] = "%9$\"\u0010jP\u0019/-\u0001%1\u0017$&\u0005\u007fE";
      J[40] = "^8]$P\"^8Jx\\-DsJf\\8C\u0002\u0018=\u0004r";
      J[41] = "\u001co-[G\u0011\u001co:\u0007K\u001e\u0006$:\u0019K\u000b\u0001U`F\u0019I";
      J[42] = "\"B\u0001(Io)M\u0010g(a\"F\u0014=";
      J[43] = "c\u0016R]MWc\u0016E\u0001AXy]E\u001fAM~,\u0017B\u0016\u0007:";
      J[44] = "^7a{xv^7v'tyD|v9tlC\r!b&/";
      J[45] = "+4J\u000e\u0005\u001b+4]R\t\u00141\u007f]L\t\u00016\u000e\u000f\u0010]J";
      J[46] = "\u0002OI\u0011wa\u0014OLKdv\u0003\u0004OMhb\u0012CXZ#s2";
      J[47] = "\u000eI\u0017\r\u0006n{i\u001c\u0002\u0017!\u001ag\u0017\t\u0013{n";
      J[48] = "\u0015#\u0018J\u0000B\u0015#\u000f\u0016\fM\u000fh\u000f\b\fX\b\u0019^][\u001b";
      J[49] = "\u0011-\u0018\u0005sS\u001a\"\tJ\u000eK\t%\u0000\u0003";
      J[50] = "X\u0007S( LX\u0007Dt,CBLDj,VE=\u00161t\u0017";
      J[51] = "X6\\ql*N6Y+\u007f=Y}Z-s)H:M:89P:O1btl!O,b3[6";
      J[52] = "`!lA|fv!i\u001boqajj\u001dcep-}\n(u~";
      J[53] = "8s\u000f[!t.s\n\u00012c98\t\u0007>w(\u007f\u001e\u0010ug$";
      J[54] = "3t\b.rCFT\u0003!c\f'Z\b*gVS";
      J[55] = boolean.class;
      K[55] = "java/lang/Boolean";
      J[56] = "ZHJU,|/hAZ=3NfJQ9i:";
      J[57] = "Jf\u0013\\p/Jf\u0004\u0000| P-\u0004\u001e|5W\\TC-";
      J[58] = "rAF\u0000F\u001b\u0007aM\u000fWTfoF\u0004S\u000e\u0012";
      J[59] = "R\u007f\u0001k\u0011\tR\u007f\u00167\u001d\u0006H4\u0016)\u001d\u0013OEBrJT";
      J[60] = "kHL]GjkH[\u0001Keq\u0003[\u001fKpvr\u0001@\u00197";
      J[61] = "\u000byfX\u0015\u0005~YmW\u0004J\u001fWf\\\u0000\u0010k";
      J[62] = "Mt)\u0012\u0003F8T\"\u001d\u0012\tYZ)\u0016\u0016S-";
      J[63] = "p1}glC\u0005\u0011vh}\fd\u001f}cyV\u0010";
      J[64] = "q\u0011+o8\u0007q\u0011<34\bkZ<-4\u001dl+hxg\\";
      J[65] = "8*d.A:M\no!Pu,\u0004d*T/X";
      J[66] = "Y\u0013k{E_Y\u0013|'IPCX|9IED)(l\u001a\u0005";
      J[67] = "1pjn\u0012z3n#\u0016\u001dv*m\u007fs\u001e";
      J[68] = ".WM(%q,I\u0004K.j3LR2)";
      J[69] = "|d";
      J[70] = "MP+\u0012\u00002ONbq\u000b)PK4\b\f>";
      J[71] = "\u0017>O^J\u0016\u0017>X\u0002F\u0019\ruX\u001cF\f\n\u0004\u0003I\u001f";
      J[72] = "l\r\u001a\u0012oIl\r\rNcFvF\rPcSq7Z\r:\u0014";
      J[73] = "7Y_\u000e7\u001d7YHR;\u0012-\u0012HL;\u0007*c\u001a\u0010nE";
      J[74] = "qD1/c\u0001\u0004d: rNej1+v\u0014\u0011";
      J[75] = "s/";
      J[76] = "7By \u0005\u007fBbr/\u00140#ly$\u0010jW";
      J[77] = "zh\u0017<!0\u000fH\u001c30\u007fnF\u001784%\u001a";
      J[78] = "\u0001\u0001]7u\u0019t!V8dV\u0015/]3`\fa";
      J[79] = "<eZ}ZZIEQrK\u0015(KZyOO\\";
      J[80] = "\b/XUY+}\u000fSZHd\u001c\u0001XQL>h";
      J[81] = ";\u0001i,YFN!b#H\t//i(LS[";
      J[82] = "d\u000b>\t[%\u0011+5\u0006Jjp%>\rN0\u0004";
      J[83] = "\u0003q\u0000:\u0011\u001f\u0003q\u0017f\u001d\u0010\u0019:\u0017x\u001d\u0005\u001eKM#KO";
      J[84] = "Zo \u0018s\u007f/O+\u0017b0NA \u001cfj:";
      J[85] = "r0v\u001dhC\u0007\u0010}\u0012y\ff\u001ev\u0019}V\u0012";
      J[86] = "pg&R\b.pg1\u000e\u0004!j,1\u0010\u00044m]cLP~";
      J[87] = "A\u0007\u0019_!<E\u0013\u0001UOgP\t\u0018S#U\u0002N@\u000fw\u0002@\u0012\u0005\u000b0cVN\u0019ZO|V\u0013@N\u007fpF\u0014\u00074";
      J[88] = "\"E9\u0001pc7\u001el\u0014\r<4\u0002f\u001ca\u000ebG;D<Y(\u0004x\u0018s+6Ed{";
      J[89] = "\u001cRPk:\u001a]\u0012I0V5-TJl'\u0001N\nR`nN-RC(=\u0000\u001c\u0014\u001c`6~";
      J[90] = "\u0006F8/cw\u0007V1ra\u0005GV3qonC,:a:fQV0sgx?B&+akEH4v\u007f\u0005Q^lpl\u007f[L1n\u0002<P\u0016,+i`\u0001\u00137t\u0002<U\u0016=a39ZR:r\u0002<U\u0016=a39ZR:r\u0002";
      J[91] = "\u0002\b>ii\u0004CH'2\u0005)3\u000e$nt\u001fPP<b=P3\b-*n\u001e\u0002Nrbe`";
      J[92] = "'\u0007>.\u001c\u0000l\u0013y}}\u0003\u001eF2|\u001f[~\u00122c\u001fj$MmpL\npMrp}";
      J[93] = "W|)0'J_`13AUJy0+-g\u0019=nq|0Va\"=#J]}=5AACw!.;J_h)L1I^y669UFzP";
      J[94] = "\u000b\u0015q,g9LF-/VkM\u0003g%0|l\u0018x%\u0013aT\u001d|3V;V\u0005,r)mM\u001f`H";
      J[95] = "O1ti\u001c\u0016E#\u007fb'E=v(hBHVp}2\\L";
      J[96] = "gu!<6\u000ed/y04q!Lqj3\u0000!//r?InLwcw\u001a }1<?\u0011^";
      J[97] = "UBa\u0012|K@\u00194\u0007\u0001\u0014C\u0005>\u000fm&\u0015@cW1q\u0017Ca\u0012o\u001aCG \u000b=q";
      J[98] = "~\n\u000fD|\rv\u0016\u0017G\u001a\u0012c\u000f\u0016_v 7IF\u0003 w\u007f\u0017\u0004Ix\rt\u000b\u001bA\u001a";
      J[99] = "\u001bg#~GD\u001fj\"$\u0003/Gn }[Cu=d#\u0007\u0010\":f\"FAInbc_\u0013\"m.%_AXg<xA/";
      J[100] = "\u0003(\u0012X\u0010t\u0006'V_\u0003EHBFCZ&T8LQ\u00078";
      J[101] = "=<7P]2||.\u000b1$\f:-W@)od5[\tf\f<$\u0013Z(=z{[QV";
      J[102] = "\u0004\u0005\u000fg\u0018\t\rZ\u0012>z^\u0004H27\u00161\u0018N\u00169\u0004C\u0006\u000f\nZ";
      J[103] = "tgaM\u000fL\u007f{~Em[|~zX\u00166yjl\r\u000fM`ekFm\u000f?<iR\u0006[;}p\u0000m";
      J[104] = "\u001f#}(\u001eE\u00133zod\u0010\f4{w\b\"]u$-d\u001b\u0013px~\u001e\u0011\u0001-f\u0010";
      J[105] = "\u0003j]k1H\u000bvEhWW\u001eoDp;eJ)\u0014,i2\u0002wVf5H\tkInW";
      J[106] = "\u0010^xTGy[J?\u0007&c)\u001c#TWlJB;X\u001e#)\u001a*\u0010Mm\u0018\\uXF\u0013";
      J[107] = "w\u0010s\u001b\u0001\u00156Pj@m\bF\u0016i\u001c\u001c\u000e%Hq\u0010UAF\u0010`X\u0006\u000fwV?\u0010\rq";
      J[108] = "\u001ai\u00039\f_[)\u001ab`F+o\u0019>\u0011DH1\u00012X\u000b+i\u0010z\u000bE\u001a/O2\u0000;";
      J[109] = "\bPNUp^\rTO\u0007\u0012J\u001dL\u0016\u000f~xJ\u000bMR+/\u0017O\n\tsS\b\u000e\u0017\u0007\u0012";
      J[110] = "\u0000$`\u000b\u001d@\u0007{=Z\u001ap\\y{\u0001\u0018\u001cn-?[EI9hn\u001eN\u0012Bqa\u0019\u0005pIm~\u001d\u0019\nAqf\u001e\u007f";
      J[111] = "J7iZN\nIm1VLu\u0018\u000e9\fK\u0004\fmg\u0014GMC\u000en\u0018O\u0016\u001dtd\n\u0012\bs";
      J[112] = "?\u0011J\u007f6\u00136NW&TD?\\b89F4 \\8*H,RBy6+";
      J[113] = "\rE\u0003\"Z\u000fJ\u0012\u0018s\r6Q\u0014\u000f\u007f[ZcEN/\u0005\b4\t\nf@PN\u0001\u0016~C6";
      J[114] = "LmJ]_\u0010Ib\u000eZL!\u0004\u0007\u001eF\u0015B\u001b}\u0014TH\\";
      J[115] = "UUT-PZR\u000e\u00056m\u00111\u0000\u001cd\u000e\u000fK\n\u000e9\u0010a";
      J[116] = "!^L|/$&\u0005\u001dg\u0012nE\u000b\u00045qq?\u0001\u0016ho\u001f";
      J[117] = ")=;;8\bh}\"`T\u001d\u0018;!<%\u0013{e90l\\\u0018=(x?\u0012){w04l";
      J[118] = "TI*8\u001d\bS\u0012{# A0\u001cbqC]J\u0016p,]3";
      J[119] = "SB}8\u001c/F\u0019(-apE\u0005\"%\rB\u0017HzsadV\u000by3]r\u0016\u0003!B";
      J[120] = "oF,g\u001bcwF?\\J\u0018\u007fF#?_ja\u0007?\\";
      J[121] = "!\u007f!\u0011\u0003w$c/\u0006f}&it\u00121*|9(~\u0001l;eq\u0002\u001e-&k";
      J[122] = "Xvpnn2Tfw)\u0014gKav1xU\u001a )i\u0014lT%u8nfFxkV";
      J[123] = "T8wo\\\u0014\u001f,0<=\u0017mz,oL\u0001\u000e$4c\u0005Nm$5/\\\u001f\u0011;t2R~";
      J[124] = "\\?i\u0004o\u0001X4.\u0005\u0006\u0014`mw\tw\u0002\u00033o\u0005>M`owI7G\u001f9lS{}";
      J[125] = "\\GW\"\u0019\u0004\rQH#fRc\u0019R%\u0017A\u0000GJ)^\u000ec\u001f[a\r@RY\u0004)\u0006>";
      J[126] = "HA^^%8A\u001eC\u0007GZj:E\u0004\u0007[opH\u00199c[\u0002VX%\u0000T\nG\u00009rJK[c6z[\u0013G\u0011(;GpY\u00115mC\u001aB\u001c70%\u0010K\u0011*fO\u000bF\u0013w\u0000";
      J[127] = "Z\t\\|V\u0018\u001bIE':\u0003k\u000fF{K\u0003\bQ^w\u0002Lk\tO?Q\u0002ZO\u0010wZ|";
      J[128] = "6\rt\t\u0015\b~\f8AWnj[ySM\u0002X\b<\u0002\u0014P\u000f\u000faLI\u0015d\u000blM\u0013Q\u000f";
      J[129] = ",\u001bK\bg)+@\u001a\u0013Zi%\\q\u0017(*+N\u000b\u001d:w5 \u0015B`cu\u001b\u0012\u00191xH";
      J[130] = "(^Y\u0001\u0019Q`_\u0015I[7t\bT[A[FZ\u0012\u0004\u001e\f\u0011\u0019ZZMY/\u001dNBG7";
      J[131] = "&U3GcO \u0000iYg$vmkD9U`\u000e5\\5\u001c/mk\u001bl\u0014&\u0012hA4\u0018$m";
      J[132] = "c=z.\u0003&df+5>fjz@1L%dh:;^xz\u0006.-\u0006~i|$?[`\u0007h2g]s}b :C\u001ditx<Pgcf%\">y<<1b\u0005~gm*_";
      J[133] = "T}t\u0017tn\u0001.r\u001aiR\u0003!fCw\u0005P|2\u0016*R\u0016%p\u001b%#\u000eqsN";
      J[134] = "8KI\u0003j|y\u000bPX\u0006~\tMS\u0004wgj\u0013K\b>(\tKZ@mf8\r\u0005\bf\u0018";
      J[135] = "/^?nv3dJx=\u00170\u0016\u001cdnf&uB|b/i\u0016Tx,t'dJ90\u0017";
      J[136] = "B\u0015[WNM\u001b\u0004X\u0003Bs\u001e\u0015]\bE\u001f,D\u001cP\u001ds\n\u0002_\u000b\\\u0001\u0014CCh";
      J[137] = "\n$4h|P\u0003{)1\u001e\u0007\ni\t\u001aTh\u0016o-6`\u001a\b.1U";
      J[138] = ",@sFoJ Pt\u0001\u0015\u001f?Wu\u0019y-n\u0016%C/z\"Rl\u0002s\u0000*Nt\u0001\u0015";
      J[139] = "\u0010\rJ8_!\u0005V\u001f-\"~\u0006J\u0015%NLV\u0006Ks\u001e\u001b\u0010S\u000e~\u001cj\b\u0007\r+\"g\u0002ID Y~\rN\u000fB";
      J[140] = "*-H\u0011:s{;W\u0010E\u0004\u0015sM\u001646v-U\u001a}y\u0015uDR.7$3\u001b\u001a%I";
      J[141] = "&#5\u0019\r>;u`\u0000m-Y#<_\u001c>:}$SUqYec\f\u0017!&x5Y\u000eA";
      J[142] = "\u0001\f\t\u0013_;\u0004\b\bA=/\u0014\u0010QIQ\u001dCW\n\u0017\u0002J\u001e\u0013MO\\6\u0001RPA=";
      J[143] = "DA\u0011;G{\u0005\u0001\b`+UuG\u000b<Z`\u0016\u0019\u00130\u0013/uA\u0002x@aD\u0007]0K\u001f";
      J[144] = "x\u0001LY\u000b:3\u0015\u000b\nj9AC\u0017Y\u001b/\"\u001d\u000fUR`AA\u0017\u0019[j>\u0017\f\u0003\u0017P";
      J[145] = "R\u0017\nZtNZ\u001f\u000e\u0001\u001a\u0012]\u001eq\u000bhO_\u0016\u000b\u0001z\u0012Ax\u001f\u0017\"\u0014R\u0002\u0015\u0005\u007f\n<\u0016\u0003]y\u0019F\u001c\u0011\u0000gw";
      J[146] = "~|54$Xk'`!Y\u0007h;j)55>~7~abt=t-'\u0010j|hN";
      J[147] = "\u001f*KzH\f\u001cp\u0013vJsO\u0013\u001b,M\u0002YpE4AK\u0016\u0013L8I\u0010HiF*\u0014\u000e&";
      J[148] = "\u0011ut)O.\u0019}pr!~\u0015a\u000fxS/\u001cturAr\u0002\u001aad\u0019t\u0011`kvDj\u007f";
      J[149] = "o\u0005\u0012\u0003}DfZ\u000fZ\u001f<Y~\tYE3H4\u001bL'\u001flN\u0011^z\u0001\u0002Z\u0007\u0006|\u0012xP\u0015[b|lFM]q\u0006fT\u0010C\u001f\rxJ\u0016@m\u00139Vu";
      J[150] = "u\u0003V|M]=\u0002\u001a4\u000f;)U[&\u0015W\u001b\u0002\u001dxB\u0000L\u0001J<MWrX[?\u0019[L";
      J[151] = "**^@5\b/._\u0012W\u001c?6\u0006\u001a;.hq]Dgy55\u001a\u001c6\u0005*t\u0007\u0012W";
      J[152] = "t|@\u001c\u0002\n<}\fT@l(*MFZ\u0000\u001a~\f\u0018\u0004lt+\u0001BDW+?K\u001a\fl";
      J[153] = "y\u0012p\u0015\u001a\u00012\u00067F{\u0002@P+\u0015\n\u0014#\u000e3\u0019C[@P\"\u0013\u0003S+\fs\u0016\u0018\f@";
      J[154] = "\u0005=\u0011lF \u0000!\u001f{#*\u0002+Dot}X{\u001a\u0003D;\u001f'A\u007f[z\u0002)";
      J[155] = "],\u0014.\u0007zX0\u001a9bpZ:A-5'\u0000j\u001cA\u0005aG6D=\u001a Z8";
      J[156] = "?\u0006\u0018C#H~F\u0001\u0018OP\u000e\u0000\u0002D>Sm^\u001aHw\u001c\u000e\u0006\u000b\u0000$R?@TH/,";
      J[157] = ";/i\u0006\u0015k7?nAo>(8oY\u0003\fyy>\u0005o57|lP\u0015?%!r>";
      J[158] = "Vt^N~E\u001d`\u0019\u001d\u001fFo6\u0005NnP\fh\u001dB'\u001foa\u0011J|A\u0015k\u0003\u0017b/";
      J[159] = "w}8<\u001f.p&i'\"pn\"\u0002tN-y4?(Ye~(\u0002)\u0019/b{9.B~yF";
      J[160] = "7V\u0016\u0010~\\4T\u0012\u001fx5`Q\u0002\u001emb0\fSD>5~I\u0016\u0006gOvU\u000e\u0005";
      J[161] = "yz\u0010 \u0000p k\u0013t\fN%z\u0016\u007f\u000b\"\u0017+V.QN1m\u0014|\u0012</,\b\u001f";
      J[162] = "bhz+i('vj7\u0013|;Wu4Ru#uw%im_ib6pm-w#*\u0013*0\"`pxva'{/\u0013,0`s6\"jo(xH";
      J[163] = "l5/?6\u0016m%&b4d.2?\u0003n\bm51>2\u001f%2-\u0003n\u000e9c\"qo\u001e0> \u0003";
      J[164] = "P)\u0003bo3\u0001?\u001cc\u0010cow\u0006eav\f)\u001ei(9oq\u000f!{w^7Pip\t";
      J[165] = "M\u000e5\u0001a?U\u000e&:1D]\u000e:Y%6CO&:";
      J[166] = "\r\u0016,O5GLV5\u0014YS<\u00106H(\\_N.Da\u0013<\u0016?\f2]\rP`D9#";
      J[167] = "\u0005@\u0007:My\f\u001f\u001ac/\u001e(0<J/,Y\u0016]e\u0017%\u0006\u000b\u0004";
      J[168] = "`lBb g+x\u00051AbY.\u0019b0r:p\u0001ny=Y(\u0010&*shnOn!\r";
      J[169] = "d;S]\u0016\u001c%{J\u0006z\u0006U=IZ\u000b\u00076cQVBHU;@\u001e\u0011\u0006d}\u001fV\u001ax";
      J[170] = "]3L\u0014\u0002{X{GO\u007f}$2C\u0012\u000eiGl[\u001eG&$m^\u001f\u0010s@hB\u0011\u0007\u0016";
      J[171] = ":IQ\u0007{\u000fe]\u001b_34mD\f\u0007nc?\u001bQ]\u0002\rnJ\b\u0002`\n2\u001c\u001bS";
      J[172] = "HZZ\u0017(@\t\u001aCLD@y\\@\u00105[\u001a\u0002X\u001c|\u0014yZIT/ZH\u001c\u0016\u001c$$";
      J[173] = "AR\u0001\u001a\t\f\tSMRKj\u001d\u0004\f@Q\u0006/PM\u001d\u000fjAR\u0001\u001a\t\f\tSMRKj";
      J[174] = "wHyWw.p\u0014/D&L+Hj^q \u0019\u001a/\u0007+rNCm\u000fy)*Fq\u0001nL";
      J[175] = "CrS\u0013)d\u00022JHExrtI\u00144\u007f\u0011*Q\u0018}0rr@P.~C4\u001f\u0018%\u0000";
      J[176] = "\u0001d\u00007\u0004\u000b\u0004kD0\u0017:H\u000eT,NYVt^>\u0013G";
      J[177] = "t\u0019\u0019)\r\u0007u\t\u0010t\u000fu(\u000e\u0011\u0015U\u0019u\u0019\u0007(\t\u000e=\u001e\u001b\u0015U\u001f!O\u0014gT\u000f(\u0012\u0016\u0015";
      J[178] = "%\r54 \"dM,oL$\u0014\u000b/3=9wU7?tv\u0014\r&w'8%Ky?,F";
      J[179] = " \f\u0018\u0014*~%D\u0013OWzY\r\u0017\u0012&l:S\u000f\u001eo#YR\n\u001f8v=W\u0016\u0011/\u0013";
      J[180] = "y\u0005Jl._(\u0013UmQ.F[Ok \u001a%\u0005WgiUF]F/:\u001bw\u001b\u0019g1e";
      J[181] = "tJ\u0018[sj}\u0015\u0005\u0002\u0011=t\u00075\u0002l?\u0019\n\u0005\u0018r,k\u0014D\u0004\u0011";
      J[182] = "l\bEy\u007fu`\u0018B>\u0005 \u007f\u001fC&i\u0012.^\u0013|<E+_S|c|l\bH-4E";
      J[183] = "Yr\u0010> \u000e\bd\u000f?_Kf,\u00159.K\u0005r\r5g\u0004f*\u001c}4JWlC5?4";
      J[184] = "p\u0004Ts\u0002\u001a{\u0018K{`\u001eh\u0004[o'\u000e\u0001\u0011\\|\u0003\u001es\u000f\u001d``\u0011e\u0012W`\u001a\u001ay\r_\u0002";
      J[185] = "\bfe\u0013:\u0018@g)[x~T0hIb\u0012fd)\u0017=~I=,\u0014g\u000fL9-F\u0005";
      J[186] = "\u001b\bnMV\u000eP\u001c)\u001e7\u0002\"J5MF\u001bA\u0014-A\u000fT\"L<\t\\\u001a\u0013\ncAWd";
      J[187] = "VaQ\u0011\u000f\rC:\u0004\u0004rR@&\u000e\f\u001e`\u0012kRTrFW$\r\u0015\u0000X\u00168n";
      J[188] = "\u00177Dd!K\u001b'C#[\u001e\u0004 B;7,Ua\u0013`[\u0015\u001bdA2!\u001f\t9_\\";
      J[189] = "yJ,0\u0012q;\u0012$|T\u0017.By(\u0001@|\u001a-s]\u0017y\u0013s&\u000f'~L.w\b";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = J[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(K[var4]);
            J[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = J[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = K[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            J[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  J[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(2975978283694479L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = J[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = K[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  J[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(2975978283694479L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        J[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(2975978283694479L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 107;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 244;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 99;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 186;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 241;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 73;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 107;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 244;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 99;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dw_C0208",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dw" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static float[] invokeBinding8(int var0, int var1, int var2, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache8;
         MethodHandle var11 = bindingCache8;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache8 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(IIILjava/lang/Object;JJ)[F", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (float[])var9.invokeExact((int)var0, (int)var1, (int)var2, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static long invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = c(MethodHandles.lookup(), "b", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static float invokeBinding11(float var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(FJJ)F", MethodHandles.lookup())).dynamicInvoker();
         }

         return (float)var6.invokeExact((float)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding12(float var0, float var1, float var2, long var3, long var5) {
         MethodHandle var11 = bindingCache12;
         MethodHandle var10 = bindingCache12;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache12 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(FFFJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var8.invokeExact((float)var0, (float)var1, (float)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static void invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding14(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache14;
         MethodHandle var8 = bindingCache14;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache14 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding15(long var0, long var2) {
         MethodHandle var8 = bindingCache15;
         MethodHandle var7 = bindingCache15;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache15 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static MatchException invokeBinding16(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache16;
         MethodHandle var8 = bindingCache16;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache16 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding18(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache18;
         MethodHandle var8 = bindingCache18;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache18 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding19(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache19;
         MethodHandle var8 = bindingCache19;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache19 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding20(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache20;
         MethodHandle var8 = bindingCache20;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache20 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding21(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = d(
                  MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding22(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache22;
         MethodHandle var8 = bindingCache22;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache22 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding24(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache24;
         MethodHandle var8 = bindingCache24;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache24 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding26(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding28(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache28;
         MethodHandle var8 = bindingCache28;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache28 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding29(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache29;
         MethodHandle var8 = bindingCache29;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache29 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding30(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache30;
         MethodHandle var8 = bindingCache30;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache30 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding31(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache31;
         MethodHandle var8 = bindingCache31;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache31 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding32(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache32;
         MethodHandle var8 = bindingCache32;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache32 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding33(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache33;
         MethodHandle var8 = bindingCache33;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache33 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding35(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache35;
         MethodHandle var8 = bindingCache35;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache35 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = d(MethodHandles.lookup(), "ñ", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding41(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache41;
         MethodHandle var8 = bindingCache41;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache41 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding42(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = d(MethodHandles.lookup(), "I", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
