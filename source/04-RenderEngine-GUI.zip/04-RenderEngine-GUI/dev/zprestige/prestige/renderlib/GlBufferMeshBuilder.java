package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.ManagedGlBuffer;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.system.MemoryUtil;

public class GlBufferMeshBuilder implements MeshDataConsumer, AutoCloseable {
   public VertexFormat a;
   private final ManagedGlBuffer b;
   private final ManagedGlBuffer c;
   private final Cleanable d;
   private ByteBuffer e;
   private ByteBuffer f;
   private final Vector4f g;
   private int h;
   private static final long i = 84489954106903L;
   private static final long[] o;
   private static final Integer[] p;
   private static final Map q = new HashMap(13);
   private static final long[] r;
   private static final Long[] s;
   private static final Map t;
   private static final Object[] w = new Object[74];
   private static final String[] x = new String[74];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;

   public GlBufferMeshBuilder(VertexFormat var1, ManagedGlBuffer var2, ManagedGlBuffer var3, long var4) {
      super();
      var4 = 84489954106903L ^ var4;
      long var6 = var4 ^ 137954520776088L;

      this.g = new Vector4f();
      this.h = 0;
      this.a = var1;
      this.b = var2;
      this.c = var3;
      short var10002 = 32477;
      long var10003 = 221614439127897108L ^ var4;
      Object[] var9 = new Object[0];
      ManagedGlBuffer var8 = var2;
      AtomicLong var10 = var8.aReturningAtomicLong(var9);
      var10003 = var10.get();
      short var10004 = 11699;
      long var10005 = 4464936838706870840L ^ var4;
      Object[] var10007 = new Object[]{null, null, null, var6};
      var10007[2] = 10;
      var10007[1] = var10003;
      var10007[0] = 0L;
      Object[] var12 = var10007;
      ManagedGlBuffer var11 = var2;
      this.e = var11.aReturningByteBuffer(var12);
      var10002 = 32477;
      var10003 = 221614439127897108L ^ var4;
      Object[] var14 = new Object[0];
      ManagedGlBuffer var13 = var3;
      AtomicLong var15 = var13.aReturningAtomicLong(var14);
      var10003 = var15.get();
      var10004 = 11699;
      var10005 = 4464936838706870840L ^ var4;
      var10007 = new Object[]{null, null, null, var6};
      var10007[2] = 10;
      var10007[1] = var10003;
      var10007[0] = 0L;
      Object[] var17 = var10007;
      ManagedGlBuffer var16 = var3;
      this.f = var16.aReturningByteBuffer(var17);
      Cleaner var10001 = RenderThreadUtil.a;
      Runnable var20 = invokeBinding1(var2, var3);
      GlBufferMeshBuilder var19 = this;
      Cleaner var18 = var10001;
      this.d = var18.register(var19, var20);
   }

   @Override
   public int cReturningInt(Object[] var1) {
      return this.h;
   }

   @Override
   public void bReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var5 = var2 ^ 136300662917958L;
      long var7 = var2 ^ 91234023938695L;
      long var9 = var2 ^ 114160296230891L;
      ByteBuffer var15 = this.e;
      int var10000 = var15.remaining();
      int var40 = var4;
      int var39 = var10000;
      if (var39 < var40) {
         ByteBuffer var17 = this.e;
         int var11 = var17.limit();
         var10000 = var11 << 1;
         ByteBuffer var18 = this.e;
         int var20 = var11 + (var4 - var18.remaining());
         int var19 = var10000;
         int var12 = Math.max(var19, var20);
         ByteBuffer var21 = this.e;
         int var13 = var21.position();
         int var22 = var13;
         ByteBuffer var14 = MemoryUtil.memAlloc(var22);
         ByteBuffer var23 = this.e;
         var23.flip();
         ByteBuffer var25 = var14;
         ByteBuffer var24 = this.e;
         MemoryUtil.memCopy(var24, var25);
         ManagedGlBuffer var42 = this.b;
         Object[] var27 = new Object[]{var7};
         ManagedGlBuffer var26 = var42;
         var26.dReturningVoid(var27);
         ManagedGlBuffer var43 = this.b;
         ManagedGlBuffer var10001 = this.b;
         Object[] var29 = new Object[0];
         ManagedGlBuffer var28 = var10001;
         int var44 = var28.bReturningInt(var29);
         long var10002 = var12;
         Object[] var10005 = new Object[]{null, null, var9};
         var10005[1] = var10002;
         var10005[0] = var44;
         Object[] var31 = var10005;
         ManagedGlBuffer var30 = var43;
         var30.aReturningVoid(var31);
         var10001 = this.b;
         short var46 = 28944;
         long var10003 = 5602384293846707462L ^ var2;
         var10003 = var12;
         short var10004 = 802;
         long var48 = 8760760082310963828L ^ var2;
         Object[] var10007 = new Object[]{null, null, null, var5};
         var10007[2] = 10;
         var10007[1] = var10003;
         var10007[0] = 0L;
         Object[] var33 = var10007;
         ManagedGlBuffer var32 = var10001;
         this.e = var32.aReturningByteBuffer(var33);
         ByteBuffer var35 = this.e;
         ByteBuffer var34 = var14;
         MemoryUtil.memCopy(var34, var35);
         int var37 = var13;
         ByteBuffer var36 = this.e;
         var36.position(var37);
         ByteBuffer var38 = var14;
         MemoryUtil.memFree(var38);
      }
   }

   @Override
   public void aReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var5 = var2 ^ 138210733639770L;
      long var7 = var2 ^ 93180835977627L;
      long var9 = var2 ^ 107276653378807L;
      int var11 = Event.bReturningInt();
      ByteBuffer var16 = this.f;
      int var10000 = var16.remaining();
      int var44 = var11;
      int var43 = var10000;
      int var42 = var43;
      int var41 = var43;
      if (var44 == 0) {
         int var46 = var4;
         int var45 = var41;
         if (var45 >= var46) {
            return;
         }

         ByteBuffer var19 = this.f;
         var42 = var19.limit();
      }

      int var12 = var42;
      var10000 = var12 << 1;
      ByteBuffer var20 = this.f;
      int var22 = var12 + (var4 - var20.remaining());
      int var21 = var10000;
      int var13 = Math.max(var21, var22);
      ByteBuffer var23 = this.f;
      int var14 = var23.position();
      int var24 = var14;
      ByteBuffer var15 = MemoryUtil.memAlloc(var24);
      ByteBuffer var25 = this.f;
      var25.flip();
      ByteBuffer var27 = var15;
      ByteBuffer var26 = this.f;
      MemoryUtil.memCopy(var26, var27);
      ManagedGlBuffer var48 = this.c;
      Object[] var29 = new Object[]{var7};
      ManagedGlBuffer var28 = var48;
      var28.dReturningVoid(var29);
      ManagedGlBuffer var49 = this.c;
      ManagedGlBuffer var10001 = this.c;
      Object[] var31 = new Object[0];
      ManagedGlBuffer var30 = var10001;
      int var50 = var30.bReturningInt(var31);
      long var10002 = var13;
      Object[] var10005 = new Object[]{null, null, var9};
      var10005[1] = var10002;
      var10005[0] = var50;
      Object[] var33 = var10005;
      ManagedGlBuffer var32 = var49;
      var32.aReturningVoid(var33);
      var10001 = this.c;
      short var52 = 32477;
      long var10003 = 221615241103581654L ^ var2;
      var10003 = var13;
      short var10004 = 11699;
      long var54 = 4464937146678497274L ^ var2;
      Object[] var10007 = new Object[]{null, null, null, var5};
      var10007[2] = 10;
      var10007[1] = var10003;
      var10007[0] = 0L;
      Object[] var35 = var10007;
      ManagedGlBuffer var34 = var10001;
      this.f = var34.aReturningByteBuffer(var35);
      ByteBuffer var37 = this.f;
      ByteBuffer var36 = var15;
      MemoryUtil.memCopy(var36, var37);
      int var39 = var14;
      ByteBuffer var38 = this.f;
      var38.position(var39);
      ByteBuffer var40 = var15;
      MemoryUtil.memFree(var40);
   }

   public GlBufferMeshBuilder aReturningGlBufferMeshBuilder(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      var2 = 84489954106903L ^ var2;
      long var5 = var2 ^ 49373481650387L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = 4;
      invokeBinding2(this, var10004, -4589835982706080514L, var2);
      invokeBinding3(this.e, var4, -4591095789904155558L, var2);
      return this;
   }

   public GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      float[] var4 = (float[])var1[0];
      long var2 = (Long)var1[1];
      var2 = 84489954106903L ^ var2;
      long var5 = var2 ^ 62516076566455L;
      int var10001 = 4 * var4.length;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var10001;
      Object[] var12 = var10004;
      GlBufferMeshBuilder var11 = this;
      var11.bReturningVoid(var12);
      float[] var7 = var4;
      int var8 = var7.length;
      while (true) {
         int var16 = var8;
         int var15 = var9;
         if (var15 >= var16) {
            return this;
         }

         float var10 = var7[var9];
         float var14 = var10;
         ByteBuffer var13 = this.e;
         var13.putFloat(var14);
         var9++;
      }
   }

   public GlBufferMeshBuilder cReturningGlBufferMeshBuilder(Object[] var1) {
      float var3 = (Float)var1[0];
      float var2 = (Float)var1[1];
      float var4 = (Float)var1[2];
      long var5 = (Long)var1[3];
      var5 = 84489954106903L ^ var5;
      long var7 = var5 ^ 9053506583477L;
      short var10001 = 24009;
      long var10002 = 7746340081113745195L ^ var5;
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = 12;
      Object[] var10 = var10004;
      GlBufferMeshBuilder var9 = this;
      var9.bReturningVoid(var10);
      float var12 = var3;
      ByteBuffer var11 = this.e;
      var11.putFloat(var12);
      float var14 = var2;
      ByteBuffer var13 = this.e;
      var13.putFloat(var14);
      float var16 = var4;
      ByteBuffer var15 = this.e;
      var15.putFloat(var16);
      return this;
   }

   public GlBufferMeshBuilder dReturningGlBufferMeshBuilder(Object[] var1) {
      Matrix4f var2 = (Matrix4f)var1[0];
      float var5 = (Float)var1[1];
      float var7 = (Float)var1[2];
      float var6 = (Float)var1[3];
      long var3 = (Long)var1[4];
      var3 = 84489954106903L ^ var3;
      long var8 = var3 ^ 8272845686751L;
      Vector4f var15 = this.g;
      float var14 = 1.0F;
      float var13 = var6;
      float var12 = var7;
      float var11 = var5;
      Matrix4f var10 = var2;
      var10.transform(var11, var12, var13, var14, var15);
      short var10001 = 6394;
      long var10002 = 4976580662325182065L ^ var3;
      Object[] var10004 = new Object[]{null, var8};
      var10004[0] = 12;
      Object[] var17 = var10004;
      GlBufferMeshBuilder var16 = this;
      var16.bReturningVoid(var17);
      Vector4f var18 = this.g;
      float var20 = var18.x;
      ByteBuffer var19 = this.e;
      var19.putFloat(var20);
      Vector4f var21 = this.g;
      float var23 = var21.y;
      ByteBuffer var22 = this.e;
      var22.putFloat(var23);
      Vector4f var24 = this.g;
      float var26 = var24.z;
      ByteBuffer var25 = this.e;
      var25.putFloat(var26);
      return this;
   }

   public GlBufferMeshBuilder eReturningGlBufferMeshBuilder(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 84489954106903L ^ var2;
      long var5 = var2 ^ 143640065326L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = 4;
      Object[] var8 = var10004;
      GlBufferMeshBuilder var7 = this;
      var7.bReturningVoid(var8);
      int var10 = var4;
      ByteBuffer var9 = this.e;
      var9.putInt(var10);
      return this;
   }

   public GlBufferMeshBuilder fReturningGlBufferMeshBuilder(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 84489954106903L ^ var2;
      long var5 = var2 ^ 38994151319315L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = 4;
      invokeBinding4(this, var10004, -1398461700102391115L, var2);
      invokeBinding5(this.f, this.h + var4, -1398692262560759084L, var2);
      return this;
   }

   public GlBufferMeshBuilder gReturningGlBufferMeshBuilder(Object[] var1) {
      int[] var4 = (int[])var1[0];
      long var2 = (Long)var1[1];
      var2 = 84489954106903L ^ var2;
      long var5 = var2 ^ 16297981048646L;
      int var10001 = 4 * var4.length;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var10001;
      Object[] var13 = var10004;
      GlBufferMeshBuilder var12 = this;
      var12.aReturningVoid(var13);
      int[] var8 = var4;
      int var10000 = Event.bReturningInt();
      int var9 = var8.length;
      int var7 = var10000;

      GlBufferMeshBuilder var17;
      while (true) {
         int var19 = var9;
         int var18 = var10;
         if (var18 < var19) {
            int var11 = var8[var10];
            int var21 = var7;
            GlBufferMeshBuilder var20 = this;
            var17 = var20;
            GlBufferMeshBuilder var16 = var20;
            if (var21 != 0) {
               break;
            }

            int var15 = this.h + var11;
            ByteBuffer var14 = var16.f;
            var14.putInt(var15);
            var10++;
            int var22 = var7;
            if (var22 == 0) {
               continue;
            }
         }

         var17 = this;
         break;
      }

      return var17;
   }

   @Override
   public int aReturningInt(Object[] var1) {
      SourceSupport.discard(var1[0]);
      ByteBuffer var4 = this.e;
      return var4.position() / this.a.b;
   }

   @Override
   public int bReturningInt(Object[] var1) {
      SourceSupport.discard(var1[0]);
      ByteBuffer var4 = this.f;
      return var4.position() / 4;
   }

   public GlBufferMeshBuilder hReturningGlBufferMeshBuilder(Object[] var1) {
      this.h = 0;
      return this;
   }

   public GlBufferMeshBuilder i(Object[] var1) {
      int var2 = (Integer)var1[0];
      this.h = var2;
      return this;
   }

   @Override
   public void close() {
      Cleanable var3 = this.d;
      var3.clean();
   }

   public void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 84489954106903L ^ var2;
      invokeBinding6(this.e, 0, -7788848444646638704L, var2);
      invokeBinding7(this.f, 0, -7788848444646638704L, var2);
      this.h = 0;
   }

   public void dReturningVoid(Object[] var1) {
      VertexFormat var2 = (VertexFormat)var1[0];
      this.a = var2;
   }

   @Override
   public MeshDataConsumer j(Object[] var1) {
      int var4 = (Integer)var1[0];
      SourceSupport.discard(var1[1]);
      Object[] var6 = new Object[]{var4};
      GlBufferMeshBuilder var5 = this;
      return var5.iReturningVoid(var6);
   }

   @Override
   public MeshDataConsumer hReturningMeshDataConsumer(Object[] var1) {
      SourceSupport.discard(var1[0]);
      Object[] var5 = new Object[0];
      GlBufferMeshBuilder var4 = this;
      return var4.hReturningGlBufferMeshBuilder(var5);
   }

   @Override
   public MeshDataConsumer gReturningMeshDataConsumer(Object[] var1) {
      int[] var2 = (int[])var1[0];
      long var3 = (Long)var1[1];
      long var5 = var3 ^ 110625486446390L;
      Object[] var8 = new Object[]{var2, var5};
      GlBufferMeshBuilder var7 = this;
      return var7.gReturningGlBufferMeshBuilder(var8);
   }

   @Override
   public MeshDataConsumer fReturningMeshDataConsumer(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var5 = var2 ^ 84252829420032L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var4;
      return invokeBinding8(this, var10004, 8691642215094179100L, var2);
   }

   @Override
   public MeshDataConsumer eReturningMeshDataConsumer(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var5 = var3 ^ 92205817685055L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var2;
      Object[] var8 = var10004;
      GlBufferMeshBuilder var7 = this;
      return var7.eReturningGlBufferMeshBuilder(var8);
   }

   @Override
   public MeshDataConsumer dReturningMeshDataConsumer(Object[] var1) {
      Matrix4f var3 = (Matrix4f)var1[0];
      float var2 = (Float)var1[1];
      float var6 = (Float)var1[2];
      float var7 = (Float)var1[3];
      long var4 = (Long)var1[4];
      long var8 = var4 ^ 82578531650883L;
      Object[] var10007 = new Object[]{null, null, null, null, var8};
      var10007[3] = var7;
      var10007[2] = var6;
      var10007[1] = var2;
      var10007[0] = var3;
      Object[] var11 = var10007;
      GlBufferMeshBuilder var10 = this;
      return var10.dReturningGlBufferMeshBuilder(var11);
   }

   @Override
   public MeshDataConsumer cReturningMeshDataConsumer(Object[] var1) {
      float var6 = (Float)var1[0];
      float var5 = (Float)var1[1];
      float var2 = (Float)var1[2];
      long var3 = (Long)var1[3];
      long var7 = var3 ^ 132519828925690L;
      Object[] var10006 = new Object[]{null, null, null, var7};
      var10006[2] = var2;
      var10006[1] = var5;
      var10006[0] = var6;
      Object[] var10 = var10006;
      GlBufferMeshBuilder var9 = this;
      return var9.cReturningGlBufferMeshBuilder(var10);
   }

   @Override
   public MeshDataConsumer bReturningMeshDataConsumer(Object[] var1) {
      float[] var2 = (float[])var1[0];
      long var3 = (Long)var1[1];
      long var5 = var3 ^ 13713354317099L;
      Object[] var8 = new Object[]{var2, var5};
      GlBufferMeshBuilder var7 = this;
      return var7.bReturningGlBufferMeshBuilder(var8);
   }

   @Override
   public MeshDataConsumer aReturningMeshDataConsumer(Object[] var1) {
      float var4 = (Float)var1[0];
      long var2 = (Long)var1[1];
      long var5 = var2 ^ 121446986560870L;
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var4;
      return invokeBinding9(this, var10004, 7728126338093356862L, var2);
   }

   private static void lambda$new$1(ManagedGlBuffer var0, ManagedGlBuffer var1) {
      long var10001 = 14692337082415L ^ 44320577163135L;
      Object[] var6 = new Object[]{invokeBinding10(var0, var1), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var6);
   }

   private static void lambda$new$0(ManagedGlBuffer var0, ManagedGlBuffer var1) {
      long var10001 = 40741171889611L ^ 60079179012059L;
      Object[] var7 = new Object[]{21618936746512L};
      ManagedGlBuffer var6 = var0;
      var6.dReturningVoid(var7);
      Object[] var9 = new Object[]{21618936746512L};
      ManagedGlBuffer var8 = var1;
      var8.dReturningVoid(var9);
   }

   static {

      {

      b();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(30587405413062L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var19 = new long[4];
      String var17 = "\u0004&ð65ø\u0006\u001d^ÎBüçòK3";
      int var18 = "\u0004&ð65ø\u0006\u001d^ÎBüçòK3".length();
      label41:
      while (true) {
         int var10001 = var15;
         var15 += 8;
         byte[] var20 = var17.substring(var10001, var15).getBytes("ISO-8859-1");
         long[] var25 = var19;
         var10001 = var16++;
         long var31 = (var20[0] & 255L) << 56
            | (var20[1] & 255L) << 48
            | (var20[2] & 255L) << 40
            | (var20[3] & 255L) << 32
            | (var20[4] & 255L) << 24
            | (var20[5] & 255L) << 16
            | (var20[6] & 255L) << 8
            | var20[7] & 255L;
         // while (true) {
            long var21 = var31;
            byte[] var23 = var13.doFinal(
               new byte[]{
                  (byte)(var21 >>> 56),
                  (byte)(var21 >>> 48),
                  (byte)(var21 >>> 40),
                  (byte)(var21 >>> 32),
                  (byte)(var21 >>> 24),
                  (byte)(var21 >>> 16),
                  (byte)(var21 >>> 8),
                  (byte)var21
               }
            );
            long var38 = (var23[0] & 255L) << 56
               | (var23[1] & 255L) << 48
               | (var23[2] & 255L) << 40
               | (var23[3] & 255L) << 32
               | (var23[4] & 255L) << 24
               | (var23[5] & 255L) << 16
               | (var23[6] & 255L) << 8
               | var23[7] & 255L;
            switch (var34) {
               case 0:
                  var25[var10001] = var38;
                  if (var15 >= var18) {
                     o = var19;
                     p = new Integer[4];
                     t = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(30587405413062L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     String var4 = "\"Sÿ\tq\u0089\u009eY\\·D³Ýú\u009e\u0081";
                     int var5 = "\"Sÿ\tq\u0089\u009eY\\·D³Ýú\u009e\u0081".length();
                     do {
                        int var29 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var29, var2).getBytes("ISO-8859-1");
                        var29 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        var38 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var29] = var38;
                     } while (var2 < var5);

                     r = var6;
                     s = new Long[2];
                     break;
                  }
                  break;
               default:
                  var25[var10001] = var38;
                  if (var15 < var18) {
                     continue label41;
                  }

                  var17 = "\u008aw(\u001a½ZiÏÁË\u009fî\u0098\u0018hå";
                  var18 = "\u008aw(\u001a½ZiÏÁË\u009fî\u0098\u0018hå".length();
                  var15 = 0;
            }

            int var28 = var15;
            var15 += 8;
            var20 = var17.substring(var28, var15).getBytes("ISO-8859-1");
            var25 = var19;
            var10001 = var16++;
            var31 = (var20[0] & 255L) << 56
               | (var20[1] & 255L) << 48
               | (var20[2] & 255L) << 40
               | (var20[3] & 255L) << 32
               | (var20[4] & 255L) << 24
               | (var20[5] & 255L) << 16
               | (var20[6] & 255L) << 8
               | var20[7] & 255L;
            var34 = 0;
         }
      }
   
      }

      
}

   private static MatchException b(MatchException var0) {
      return var0;
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10688;
      if (p[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = o[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])q.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               q.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bQ", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         p[var3] = var15;
      }

      return p[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bQ_C0089",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 5248;
      if (s[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = r[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])t.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               t.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bQ", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         s[var3] = var15;
      }

      return s[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bQ_C0089",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = x[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = w[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 11;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 47;
            yield var17;
         }
         case 3 -> {
            byte var18 = 55;
            yield var18;
         }
         case 4 -> {
            byte var19 = 50;
            yield var19;
         }
         case 5 -> {
            byte var20 = 6;
            yield var20;
         }
         case 6 -> {
            byte var21 = 29;
            yield var21;
         }
         case 7 -> {
            byte var22 = 27;
            yield var22;
         }
         case 8 -> {
            byte var23 = 19;
            yield var23;
         }
         case 9 -> {
            byte var24 = 24;
            yield var24;
         }
         case 10 -> {
            byte var25 = 56;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 7;
            yield var27;
         }
         case 13 -> {
            byte var28 = 0;
            yield var28;
         }
         case 14 -> {
            byte var29 = 42;
            yield var29;
         }
         case 15 -> {
            byte var30 = 49;
            yield var30;
         }
         case 16 -> {
            byte var31 = 4;
            yield var31;
         }
         case 17 -> {
            byte var32 = 53;
            yield var32;
         }
         case 18 -> {
            byte var33 = 39;
            yield var33;
         }
         case 19 -> {
            byte var34 = 30;
            yield var34;
         }
         case 20 -> {
            byte var35 = 20;
            yield var35;
         }
         case 21 -> {
            byte var36 = 60;
            yield var36;
         }
         case 22 -> {
            byte var37 = 35;
            yield var37;
         }
         case 23 -> {
            byte var38 = 54;
            yield var38;
         }
         case 24 -> {
            byte var39 = 18;
            yield var39;
         }
         case 25 -> {
            byte var40 = 13;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 41;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 21;
            yield var44;
         }
         case 30 -> {
            byte var45 = 31;
            yield var45;
         }
         case 31 -> {
            byte var46 = 37;
            yield var46;
         }
         case 32 -> {
            byte var47 = 22;
            yield var47;
         }
         case 33 -> {
            byte var48 = 46;
            yield var48;
         }
         case 34 -> {
            byte var49 = 9;
            yield var49;
         }
         case 35 -> {
            byte var50 = 17;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 51;
            yield var52;
         }
         case 38 -> {
            byte var53 = 8;
            yield var53;
         }
         case 39 -> {
            byte var54 = 43;
            yield var54;
         }
         case 40 -> {
            byte var55 = 26;
            yield var55;
         }
         case 41 -> {
            byte var56 = 57;
            yield var56;
         }
         case 42 -> {
            byte var57 = 28;
            yield var57;
         }
         case 43 -> {
            byte var58 = 63;
            yield var58;
         }
         case 44 -> {
            byte var59 = 34;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 48;
            yield var61;
         }
         case 47 -> {
            byte var62 = 2;
            yield var62;
         }
         case 48 -> {
            byte var63 = 58;
            yield var63;
         }
         case 49 -> {
            byte var64 = 10;
            yield var64;
         }
         case 50 -> {
            byte var65 = 38;
            yield var65;
         }
         case 51 -> {
            byte var66 = 59;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 15;
            yield var68;
         }
         case 54 -> {
            byte var69 = 14;
            yield var69;
         }
         case 55 -> {
            byte var70 = 32;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 12;
            yield var72;
         }
         case 58 -> {
            byte var73 = 1;
            yield var73;
         }
         case 59 -> {
            byte var74 = 3;
            yield var74;
         }
         case 60 -> {
            byte var75 = 62;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 16;
            yield var77;
         }
         default -> 61;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            x[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      w[0] = "\u0017`x$0j\u0001`}~#}\u0016+~x/i\u0007liodx\"";
      w[1] = "gQi+\u0017`\u0012qb$\u0006/s\u007fi/\u0002u\u0007";
      w[2] = "*bk\u007fpm_B`pa\">Lk{exJ";
      w[3] = void.class;
      x[3] = "java/lang/Void";
      w[4] = "*QIZ\u0017H)_\u0011y@R%rJ]_C2";
      w[5] = float.class;
      x[5] = "java/lang/Float";
      w[6] = int.class;
      x[6] = "java/lang/Integer";
      w[7] = "\b\u001dz/s7}=q bx\u001c3z+f\"h";
      w[8] = "zs@`h?q|Q/\u000b2dz";
      w[9] = ",FL04.:FIj'9-\rJl+-<J]{`<\u0018";
      w[10] = "\r_ImCKx\u007fBbR\u0004\u0019qIiV^m";
      w[11] = " \u0001`){cU!k&j,4/`-nv@";
      w[12] = "g\u0014&[lzl\u001b7\u0014\u000fwy\u00168\u007f:uh\u0005$S-x";
      w[13] = "'0ud=DR\u0010~k,\u000b3\u001eu`(QG";
      w[14] = "\ro}3\u0017@\bzv3\bN\u0011i\u007fpUz\u0007puo\u0002b\u0016tv";
      w[15] = "y'JPGIz)\u0012s\u001cAu#N";
      w[16] = "\u0001J<\rmVtj7\u0002|\u0019\u0015d<\txCa";
      w[17] = "Jy\bJ\u0013DTq\u0012\u0005^^N{\u000bYOTNlPJI^Mq\u001d\u0005|EOu\u0017Hq^N\u007f";
      w[18] = long.class;
      x[18] = "java/lang/Long";
      w[19] = "\t\u0003@oj+\u0002\fQ 6\"\u0005Lub!&\r\u0007D";
      w[20] = "\u0015.jcT`\u001e!{,5n\u0015*\u007fv";
      w[21] = " V\u0016)i.+Y\u0007f\u00157$Y\u0001*+'";
      w[22] = "C;)F\u001c9H48\t@0Ot\u001cKW4G?-\u0003q9L;1FP9L";
      w[23] = "*M\u0013?F\u000f_m\u00180W@>c\u0013;S\u001aJ";
      w[24] = "CK+n3I6k a\"\u0006We+j&\\#";
      w[25] = "B$GT/\u00027\u0004L[>MV\nGP:\u0017\"";
      w[26] = "\t!2C\u0005_|\u00019L\u0014\u0010\u001d\u000f2G\u0010Ji";
      w[27] = "\u001an\t\bT\toN\u0002\u0007EF\u000e@\t\fA\u001cz";
      w[28] = "Pd`L10%DkC \u007fDJ`H$%0";
      w[29] = "t\u0003ZGAd\u0001#QHP+`-ZCTq\u0014";
      w[30] = "{q/wU\u0012mq*-F\u0005z:)+J\u0011k}><\u0001\u0003Z";
      w[31] = "rNE?UUdN@eFBs\u0005CcJVbBTt\u0001A|";
      w[32] = "\u0001\u0002\bjP\u000bt\"\u0003eAD\u0015,\bnE\u001ea";
      w[33] = "$|\u0016\u0018LTQ\\\u001d\u0017]\u001b0R\u0016\u001cYAD";
      w[34] = "F~QF\r\u000e3^ZI\u001cARPQB\u0018\u001b&";
      w[35] = "[&\u000fp\u00036Y8F\u0013\b-F=\u0010j\u000f";
      w[36] = "&a!|\bn$\u007fh\u0004\u0007b=|4f\u0004";
      w[37] = "H\u0011b\u001bWE\u0019UfN9B\u001c\u001d\rJ_X\bRa\u001cX\u0018\rm1\u0010FZJ\u0001g\u0017\u0006_uQk\tD\u0018\u0019\u0007lIA'";
      w[38] = "C\u001cu)\u001e0\u0006UjT\u0000\\\u001dRv)]8C\f1k`e\n\u0012v*\f C\r\u000b";
      w[39] = "O\u001a\bW8\u001b\nS\u0017*,w\u0011T\u000bW{\u0013O\nL\u0015FM\u001cS\u0018W$\u0012\u0018\u0006\u0011*";
      w[40] = "q\u0011&Q*\u0018{\b?RI\u0010\u0012S0\u00164E~\u00057V1z";
      w[41] = "s8M\r8\u000f6qRp,cz2I\u0019'X(,\u0003\rFS02Z\u0011}\u0001.xNp";
      w[42] = "\u0000|\u001a#;\u0004E5\u0005^,h^2\u0019#x\f\u0000l^aEQIr\u0019 )\u0014\u0000md";
      w[43] = "Lf}O\u0018\u0000\t/b2\fl\u0012(~O[\bLv9\rfU\u0005h~L\n\u0010Lw\u0003";
      w[44] = "{@x\u0007\u0007PhSlSxZ|A\u001eQ\u0018Hq[d\\\u0019[s=";
      w[45] = "\u0000#\u0019Rov\u0011y\u000fJ\u000f*\u0004x-Qb\"iwYJnt\u000f%\u0018JtOSwZEr-\fs\u000fL\u000f";
      w[46] = "(2dbBu*pls;$\u0016+9bFprug%\u0004M-tis]sv%:x;";
      w[47] = "\u0002L9@7>\u0012\\#\u0001\tj\b_7\u001b\t;\u0006\u000b0\u0000kd\u0002^9}";
      w[48] = " !e\t[o{p6\u0002=)|bj\u0019\\6}\u00197\u0003B,$ua\u0004\u0002)\u001b\"3\u000bQ7%ybXZQ";
      w[49] = "so1\n\u0017Wib1KfLnjfJ\bWnf\u0000\n\u0005Qv2`\b\u0001Ti\u0003;R\u0007R%c9V\u0002M\u00148cP\u0004\u0001t:gU\u001b0/`aSWP-ddLfHq~b\r\f[/|:1\u001eUia<[\r\u000bk9\u0000";
      w[50] = "\u000e;\u0006r\b>Kr\u0019\u000f\u001aRPu\u0005rK6\u000e+B0vkG5\u0005q\u001a.\u000e*x";
      w[51] = "ls\u000b[\u001a5\u007f-\t\u0003&/\u0014-\u0015XDnt/\u0011][";
      w[52] = "\u0006'u] |Cnj 1\u0010Xiv]ct\u000671\u001f^)O)v^2l\u00066\u000b";
      w[53] = "\nj(~_AQ;{u9\u0007L.\bv^\u0016MR}qX\u001d\u00002\u007fu]\u00021i~|U\u0019\u000f2//^\u007f";
      w[54] = "B\u001b=F3+\u0019JnMUq\u0018F2VU)\u001f\\.\u00159\u007f\u0018\u001c+*";
      w[55] = "8%S\u0012($k$N\u0016A?93_U=(.\\SN~'?5\u0006\u001114T2\u0004B!:$`\u0004S#E:\"Y\u0013\u007fz*2CRA";
      w[56] = "qI\u000ej\u0006}4\u0000\u0011\u0017\u0013\u0011/\u0007\rjEuqYJ(x(8G\ri\u0014mqXp";
      w[57] = "\u0005KE\f-\"^\u001a\u0016\u0007KdY\bJ\u001c*{Xs\u0017\u00064a\u0001\u001fA\u0001td>";
      w[58] = " lB;4|{=\u00110R:f(m1.B'2S*m.q5\u0013/Ry#:@1l\"riKW";
      w[59] = ",z\u0015=\u001a\u0013w+F6|Cs#\u0003QG\u0015y.\u001do\u001cD*%{";
      w[60] = "\u0001\u007f\u001c$V\u0013D6\u0003YE\u007f_1\u001f$\u0015\u001b\u0001oXf(FHq\u001f'D\u0003\u0001nb";
      w[61] = "&Ax}8?$\u0003plAk\u0018X%}<:|\u0006{:~\u0007\"U\"n<e}QwgA";
      w[62] = "K\r@v\fyIOHgu(u\u0014\u001dv\b|\u0011JC1JAO\u0019\u001ae\b#\u0010\u001dOlu";
      w[63] = "9;!\u001a\u0007\u0016|r>g\u0010zgu\"\u001aD\u001e9+eXy@jr1\u001a\u001b\u001fn'8g";
      w[64] = "OnVS\u000f\u001fM,^BvMqw\u000bS\u000b\u001a\u0015)U\u0014I'MvJSIK\u001bq\nVv";
      w[65] = "+$XRV7+(\u0019DodO=\u001eE\u00127+c@\u0002P\nu0\u0019V\u0012h*4L_o";
      w[66] = "#A\u0011v]\u000f0\u001f\u0013.a\u0017[\u001f\u000fu\u0003T;\u001d\u000bp\u001c";
      w[67] = "\u007f(\n\b&O$yY\u0003@\u000b)u\r\u0005&\u0010\"\u007fdX&\u000e9/\b\u000e!N<\u0010";
      w[68] = "oOUr\u001b\bm\r]cbYQV\br\u001f\r5\bV5]0;LP2\u001dU(_Dfb";
      w[69] = "[\u0004y-\u0003*HZ{u?1#Zg.]qCXc+B";
      w[70] = "s69N<f6\u007f&3,\n-x:N\u007fns&}\fB3:8:M.vs'G";
      w[71] = "C\\\u0013O9\b\u0006\u0015\f2&d\u001d\u0012\u0010Oz\u0000CLW\rG]\nR\u0010L+\u0018CMm";
      w[72] = "L\u0014\u001c)8z]N\n1X&HO/4<$N*Z6'>\u001aF\f1g;%\u0011^>4%\u001bJ\u000fm?C";
      w[73] = "gmWf%Mv7A~E\u0011c6fx=\u0005\u000eh\u0015q)\u001203D\"\"t5kCs#Jn:\u0010xENdjCb'\u0011`?J\u001f";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = w[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(x[var4]);
            w[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = w[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = x[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            w[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  w[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(1470388912198198L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = w[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = x[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  w[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(1470388912198198L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        w[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(1470388912198198L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 193;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 201;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 83;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 216;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 181;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 200;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 193;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 201;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 83;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite e(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bQ_C0089",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bQ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(ManagedGlBuffer var0, ManagedGlBuffer var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/bP_C0087;Ldev/zprestige/prestige/bP_C0087;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/bQ_C0089",
                     "lambda$new$1",
                     "(Ldev/zprestige/prestige/bP_C0087;Ldev/zprestige/prestige/bP_C0087;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var3.invokeExact((ManagedGlBuffer)var0, (ManagedGlBuffer)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static void invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = e(MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ByteBuffer invokeBinding3(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = e(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;FJJ)Ljava/nio/ByteBuffer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ByteBuffer)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = e(MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ByteBuffer invokeBinding5(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = e(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;IJJ)Ljava/nio/ByteBuffer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ByteBuffer)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ByteBuffer invokeBinding6(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = e(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;IJJ)Ljava/nio/ByteBuffer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ByteBuffer)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static ByteBuffer invokeBinding7(Object var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache7;
         MethodHandle var9 = bindingCache7;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache7 = e(
                  MethodHandles.lookup(), "µ", SourceSupport.methodType("(Ljava/lang/Object;IJJ)Ljava/nio/ByteBuffer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (ByteBuffer)var7.invokeExact((Object)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = e(
                  MethodHandles.lookup(),
                  "µ",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = e(
                  MethodHandles.lookup(),
                  "µ",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Runnable invokeBinding10(ManagedGlBuffer var0, ManagedGlBuffer var1) {
         MethodHandle var6 = bindingCache10;
         MethodHandle var5 = bindingCache10;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/bP_C0087;Ldev/zprestige/prestige/bP_C0087;)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/bQ_C0089",
                     "lambda$new$0",
                     "(Ldev/zprestige/prestige/bP_C0087;Ldev/zprestige/prestige/bP_C0087;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var3.invokeExact((ManagedGlBuffer)var0, (ManagedGlBuffer)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }
}
