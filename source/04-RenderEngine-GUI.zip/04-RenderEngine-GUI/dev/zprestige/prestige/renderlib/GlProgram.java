package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

public final class GlProgram implements AutoCloseable {
   private final int a;
   private final Cleanable b;
   private final int c;
   private final int d;
   private static final long e = 124488648318860L;
   private static final String[] f;
   private static final String[] g;
   private static final Map h = new HashMap(13);
   private static final long i;
   private static final Object[] j = new Object[24];
   private static final String[] k = new String[24];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public GlProgram(int var1, long var2) {
      super();
      var2 = 124488648318860L ^ var2;

      this.a = var1;
      Cleaner var10001 = RenderThreadUtil.a;
      Runnable var6 = invokeBinding1(var1);
      GlProgram var5 = this;
      Cleaner var4 = var10001;
      this.b = var4.register(var5, var6);
      Object[] var8 = new Object[0];
      GlProgram var7 = this;
      int var16 = var7.aReturningInt(var8);
      short var10002 = 226;
      long var10003 = 1650343052269407239L ^ var2;
      String var10 = "projMat";
      int var9 = var16;
      this.c = GL20.glGetUniformLocation(var9, var10);
      Object[] var12 = new Object[0];
      GlProgram var11 = this;
      int var17 = var11.aReturningInt(var12);
      var10002 = 3381;
      var10003 = 9156980661750514129L ^ var2;
      String var14 = "viewMat";
      int var13 = var17;
      this.d = GL20.glGetUniformLocation(var13, var14);
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   @Override
   public void close() {
      Cleanable var3 = this.b;
      var3.clean();
   }

   public int bReturningInt(Object[] var1) {
      return this.c;
   }

   public int cReturningInt(Object[] var1) {
      return this.d;
   }

   public int dReturningInt(Object[] var1) {
      String var2 = (String)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 124488648318860L ^ var3;
      String var6 = var2;
      int var5 = this.a;
      return GL20.glGetUniformLocation(var5, var6);
   }

   public void aReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      int var3 = (Integer)var1[1];
      long var4 = (Long)var1[2];
      var4 = 124488648318860L ^ var4;
      long var6 = var4 ^ 119840000939953L;
      int var9 = (int)i;
      int var8 = GL11.glGetInteger(var9);
      int var10 = this.a;
      GL20.glUseProgram(var10);
      Object[] var12 = new Object[]{var2, var6};
      GlProgram var11 = this;
      int var10000 = var11.dReturningInt(var12);
      int var14 = var3;
      int var13 = var10000;
      GL20.glUniform1i(var13, var14);
      int var15 = var8;
      GL20.glUseProgram(var15);
   }

   private static void lambda$new$1(int var0) {
      long var10001 = 6269514244654L ^ 35873175440766L;
      Object[] var5 = new Object[]{invokeBinding2(var0), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var5);
   }

   private static void lambda$new$0(int var0) {
      int var3 = var0;
      GL20.glDeleteProgram(var3);
   }

   static {

      {

      aReturningVoid();
      Cipher var7;
      Cipher var10000 = var7 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var8 = 1; var8 < 8; var8++) {
         var10003[var8] = (byte)(67029084378219L << var8 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var14 = new String[2];
      String var11 = "´Æ\u001f\u0095ì°\u009byûH\b·ë`\u008f¿\u0010æãâ«\u0017\u0080VÒû¿Õ\u0097©¬ê\u007f";
      int var13 = "´Æ\u001f\u0095ì°\u009byûH\b·ë`\u008f¿\u0010æãâ«\u0017\u0080VÒû¿Õ\u0097©¬ê\u007f".length();
      char var10 = 16;
      int var9 = -1;

      while (true) {
         byte[] var15 = var7.doFinal(var11.substring(++var9, var9 + var10).getBytes("ISO-8859-1"));
         String var21 = a(var15).intern();
         
         if ((var9 += var10) >= var13) {
            f = var14;
            g = new String[2];
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(67029084378219L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long var19 = 771380393152422814L;
            byte[] var4 = var0.doFinal(
               new byte[]{
                  (byte)10L,
                  (byte)2740L,
                  (byte)701566L,
                  (byte)179600993L,
                  (byte)45977854320L,
                  (byte)11770330706061L,
                  (byte)3013204660751651L,
                  (byte)771380393152422814L
               }
            );
            long var24 = (var4[0] & 255L) << 56
               | (var4[1] & 255L) << 48
               | (var4[2] & 255L) << 40
               | (var4[3] & 255L) << 32
               | (var4[4] & 255L) << 24
               | (var4[5] & 255L) << 16
               | (var4[6] & 255L) << 8
               | var4[7] & 255L;
            var10001 = -1;
            i = var24;
            break;
         }

         var10 = var11.charAt(var9);
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 8036;
      if (g[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])h.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fM", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = f[var5].getBytes("ISO-8859-1");
         g[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return g[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fM_C0295",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fM" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = k[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = j[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 49;
            yield var15;
         }
         case 1 -> {
            byte var16 = 25;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 46;
            yield var18;
         }
         case 4 -> {
            byte var19 = 19;
            yield var19;
         }
         case 5 -> {
            byte var20 = 3;
            yield var20;
         }
         case 6 -> {
            byte var21 = 51;
            yield var21;
         }
         case 7 -> {
            byte var22 = 54;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 12;
            yield var24;
         }
         case 10 -> {
            byte var25 = 34;
            yield var25;
         }
         case 11 -> {
            byte var26 = 31;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 43;
            yield var28;
         }
         case 14 -> {
            byte var29 = 61;
            yield var29;
         }
         case 15 -> {
            byte var30 = 45;
            yield var30;
         }
         case 16 -> {
            byte var31 = 0;
            yield var31;
         }
         case 17 -> {
            byte var32 = 2;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 56;
            yield var34;
         }
         case 20 -> {
            byte var35 = 9;
            yield var35;
         }
         case 21 -> {
            byte var36 = 55;
            yield var36;
         }
         case 22 -> {
            byte var37 = 48;
            yield var37;
         }
         case 23 -> {
            byte var38 = 28;
            yield var38;
         }
         case 24 -> {
            byte var39 = 29;
            yield var39;
         }
         case 25 -> {
            byte var40 = 4;
            yield var40;
         }
         case 26 -> {
            byte var41 = 8;
            yield var41;
         }
         case 27 -> {
            byte var42 = 63;
            yield var42;
         }
         case 28 -> {
            byte var43 = 39;
            yield var43;
         }
         case 29 -> {
            byte var44 = 50;
            yield var44;
         }
         case 30 -> {
            byte var45 = 35;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 30;
            yield var47;
         }
         case 33 -> {
            byte var48 = 16;
            yield var48;
         }
         case 34 -> {
            byte var49 = 47;
            yield var49;
         }
         case 35 -> {
            byte var50 = 59;
            yield var50;
         }
         case 36 -> {
            byte var51 = 15;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 38;
            yield var53;
         }
         case 39 -> {
            byte var54 = 14;
            yield var54;
         }
         case 40 -> {
            byte var55 = 33;
            yield var55;
         }
         case 41 -> {
            byte var56 = 36;
            yield var56;
         }
         case 42 -> {
            byte var57 = 27;
            yield var57;
         }
         case 43 -> {
            byte var58 = 52;
            yield var58;
         }
         case 44 -> {
            byte var59 = 21;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 17;
            yield var61;
         }
         case 47 -> {
            byte var62 = 58;
            yield var62;
         }
         case 48 -> {
            byte var63 = 13;
            yield var63;
         }
         case 49 -> {
            byte var64 = 11;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 57;
            yield var67;
         }
         case 53 -> {
            byte var68 = 40;
            yield var68;
         }
         case 54 -> {
            byte var69 = 26;
            yield var69;
         }
         case 55 -> {
            byte var70 = 22;
            yield var70;
         }
         case 56 -> {
            byte var71 = 23;
            yield var71;
         }
         case 57 -> {
            byte var72 = 7;
            yield var72;
         }
         case 58 -> {
            byte var73 = 44;
            yield var73;
         }
         case 59 -> {
            byte var74 = 10;
            yield var74;
         }
         case 60 -> {
            byte var75 = 41;
            yield var75;
         }
         case 61 -> {
            byte var76 = 62;
            yield var76;
         }
         case 62 -> {
            byte var77 = 20;
            yield var77;
         }
         default -> 1;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            k[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      j[0] = "Pd8`9}Fd=:*jQ/><&~@h)+mi^";
      j[1] = "S]\r\\o\u001d&}\u0006S~RGs\rXz\b3";
      j[2] = void.class;
      k[2] = "java/lang/Void";
      j[3] = "\u001ePQ\u000b9 \u0015_@De)\u0012\u001fd\u0006r-\u001aTU";
      j[4] = "g\u001f\u0013kXIl\u0010\u0002$9Gg\u001b\u0006~";
      j[5] = "\u007f0;T&\u0017t?*\u001bZ\u000e{?,Wd\u001e";
      j[6] = "Vkz|)g]dk3unZ$OqbjRo~9DgYkb|egY";
      j[7] = "\"w\u0002+\u0003]'b\t+\u0000Z(k\u0002iAm\u00017U";
      j[8] = int.class;
      k[8] = "java/lang/Integer";
      j[9] = "Q8f\\\u001d%Z7w\u0013p!Z+CXB<^7sX";
      j[10] = "a\u0003`&sVw\u0003e|`A`HfzlUq\u000fqm'@H";
      j[11] = "VY%\u001e\u001a\u0001#y.\u0011\u000bNBw%\u001a\u000f\u00146";
      j[12] = "~\u000e0!\u001be{\u001b;!\u0018bt\u00120cYU]Mf";
      j[13] = "\rgLu*\u0002xGGz;M\u0019ILq?\u0017m";
      j[14] = "iT\u0006;YCj\u0016\u0017/9E01\u000e%WM.\tQ%9\u0017$V\u0007?XZ9\u0000TD\u0004Zn\u0003\u0013%IG8Ph}XJ+P\u0014!GS=l";
      j[15] = ").\nL\u001a*a,D@y>~-\u0015Z\u0005)iBOJ\u0000zs)\u0011AI;\u0013~L\u001f@6\"+\u001bD\u0010D/?\u0014G\u0010+m=\u0006Yy";
      j[16] = "iQC11Vj\u0013R%QP04V#\tE3\u0006W'4?i\u0019\u0017!*^$\u0004ArQ\u00065\tRr-Z*\u0010DN";
      j[17] = "\f!Myg\u0011\b;R-V\u00193p\r\u007f6M\n(Z ,u\u000e1\n,-\u0014C,\\\u007fV";
      j[18] = "+\u001fJ\u000bpop\u001fW\u0017Jd\u007f2K\u0017\u000bmg\u0010I\u00060\u000b&\r\u001c\u00041jk\u0010JWJ6kGI\u0010+{v\u0011\u001ak";
      j[19] = "\u0013\"t\u0005IN\u0010`e\u0011)HJUw\u0006tAOt}\u0000LcIqs\u0006H@H\u001a'\n\u0013HU{j\u0017E\u001b.$a\u0017\u0017]G`bBV'\u0013j \u0015RF^wvF)";
      j[20] = "J\u0013E'}&\b\u0011W9\u0014\"\u0012\u0003L'\u0014p\u0017\u000eZ}h,\b\u0017LA";
      j[21] = "s5eHN%w/z\u001c\u007f(Ld%N\u001fyu<r\u0011\u0005Aq%\"\u001d\u0004 <8tN\u007f";
      j[22] = "\u000b- Tl~Z. l8FQ/~\fn\u007f\tx!\u0016V\u007f\u0001r=P*#\u001ek+l";
      j[23] = "&wdFj\u001e%5uR\n\u0018\u007f\u0003g]g\u000bv\u0017p^e\rr*\n\u0004zMt4kIg\u001b'O3Xj\b'3oGs\u001e\u001b";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = j[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            j[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  j[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(340584766984400L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  j[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(340584766984400L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        j[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(340584766984400L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 79;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 119;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 228;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 243;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 250;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 79;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 119;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fM_C0295",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fM" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fM_C0295", "lambda$new$1", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Runnable invokeBinding2(int var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/fM_C0295", "lambda$new$0", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
