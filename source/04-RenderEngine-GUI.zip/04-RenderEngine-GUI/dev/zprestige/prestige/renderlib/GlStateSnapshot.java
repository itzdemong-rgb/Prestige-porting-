package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL30C;

public record GlStateSnapshot(
   boolean aD,
   boolean aE,
   boolean aF,
   boolean aG,
   int aH,
   int aI,
   int aJ,
   int aK,
   int aL,
   int[] aM,
   int aN,
   int aO,
   int aP,
   int aQ,
   int aR,
   int aS,
   int[] aT,
   int aU,
   int aV
) {
   private static final int a;
   private static final long b = 95544433736494L;
   private static final long[] c;
   private static final Integer[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[25];
   private static final String[] g = new String[25];

   public static GlStateSnapshot aReturninggo_C0354() {
      boolean var3 = GL30C.glIsEnabled(2929);
      int var10000 = Event.cReturningInt();
      boolean var4 = GL30C.glIsEnabled(2884);
      boolean var5 = GL30C.glIsEnabled(3042);
      boolean var6 = GL30C.glIsEnabled(3089);
      int var7 = GL30C.glGetInteger(35725);
      int var8 = GL30C.glGetInteger(34229);
      int var9 = GL30C.glGetInteger(34964);
      int var10 = GL30C.glGetInteger(34965);
      int var2 = var10000;
      int var11 = GL30C.glGetInteger(34016);
      int[] var12 = new int[8];
      while (true) {
         byte var44 = 8;
         int var43 = var13;
         if (var43 < var44) {
            int var31 = 33984 + var13;
            GL30C.glActiveTexture(var31);
            var12[var13] = GL30C.glGetInteger(32873);
            var13++;
            int var45 = var2;
            if (var45 == 0) {
               break;
            }

            int var46 = var2;
            if (var46 != 0) {
               continue;
            }
         }

         int var34 = var11;
         GL30C.glActiveTexture(var34);
         short var47 = 23827;
         long var10001 = 311540970650760442L;
         var13 = GL30C.glGetInteger(32777);
         break;
      }

      int var14 = GL30C.glGetInteger(34877);
      short var48 = 21508;
      long var56 = 9023532663735188985L;
      int var15 = GL30C.glGetInteger(32969);
      var48 = 6570;
      var56 = 8187113556090302536L;
      int var16 = GL30C.glGetInteger(32968);
      var48 = 27399;
      var56 = 958209992947942094L;
      int var17 = GL30C.glGetInteger(32971);
      var48 = 3616;
      var56 = 3015086851014141911L;
      int var18 = GL30C.glGetInteger(32970);
      var48 = 11304;
      int[] var19 = new int[4];
      var56 = 1043181098910713309L;
      var48 = 3088;
      int[] var42 = var19;
      GL30C.glGetIntegerv(3088, var42);
      var48 = 26606;
      var56 = 6112823599359053342L;
      int var20 = GL30C.glGetInteger(36006);
      var48 = 25698;
      var56 = 8907674720431361423L;
      int var21 = GL30C.glGetInteger(36010);
      return new GlStateSnapshot(var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var21, var20);
   }

   public void aReturningVoid() {
      int var3;
      label74: {
         var3 = Event.cReturningInt();
         int var59 = var3;
         byte var58 = ((byte)((this.aD) ? 1 : 0));
         short var51 = var58;
         byte var50 = var58;
         if (var59 != 0) {
            byte var60 = var50;
            if (var60 != 0) {
               GL30C.glEnable(2929);
               int var61 = var3;
               if (var61 != 0) {
                  break label74;
               }
            }

            short var62 = 2929;
            var51 = var62;
         }

         short var9 = var51;
         GL30C.glDisable(var9);
      }

      label67: {
         int var64 = var3;
         byte var63 = ((byte)((this.aE) ? 1 : 0));
         short var53 = var63;
         byte var52 = var63;
         if (var64 != 0) {
            byte var65 = var52;
            if (var65 != 0) {
               GL30C.glEnable(2884);
               int var66 = var3;
               if (var66 != 0) {
                  break label67;
               }
            }

            short var67 = 2884;
            var53 = var67;
         }

         short var14 = var53;
         GL30C.glDisable(var14);
      }

      label60: {
         int var69 = var3;
         byte var68 = ((byte)((this.aF) ? 1 : 0));
         short var55 = var68;
         byte var54 = var68;
         if (var69 != 0) {
            byte var70 = var54;
            if (var70 != 0) {
               GL30C.glEnable(3042);
               int var71 = var3;
               if (var71 != 0) {
                  break label60;
               }
            }

            short var72 = 3042;
            var55 = var72;
         }

         short var19 = var55;
         GL30C.glDisable(var19);
      }

      label53: {
         int var74 = var3;
         byte var73 = ((byte)((this.aG) ? 1 : 0));
         short var57 = var73;
         byte var56 = var73;
         if (var74 != 0) {
            byte var75 = var56;
            if (var75 != 0) {
               GL30C.glEnable(3089);
               int var76 = var3;
               if (var76 != 0) {
                  break label53;
               }
            }

            short var77 = 3089;
            var57 = var77;
         }

         short var24 = var57;
         GL30C.glDisable(var24);
      }

      int var25 = this.aH;
      GL30C.glUseProgram(var25);
      short var10000 = 12005;
      long var10001 = 3289930289683695363L;
      char var82 = '袒';
      int var27 = this.aJ;
      GL30C.glBindBuffer(34962, var27);
      var10000 = 13801;
      var10001 = 5330305767793138701L;
      char var84 = '袓';
      int var29 = this.aK;
      GL30C.glBindBuffer(34963, var29);
      int var30 = this.aI;
      GL30C.glBindVertexArray(var30);
      while (true) {
         int var79 = this.aM.length;
         int var78 = var4;
         if (var78 < var79) {
            int var31 = 33984 + var4;
            GL30C.glActiveTexture(var31);
            var10000 = 20939;
            var10001 = 3607558278029146145L;
            var10000 = 3553;
            int var33 = this.aM[var4];
            GL30C.glBindTexture(3553, var33);
            var4++;
            int var80 = var3;
            if (var80 == 0) {
               break;
            }

            int var81 = var3;
            if (var81 != 0) {
               continue;
            }
         }

         int var35 = this.aL;
         GL30C.glActiveTexture(var35);
         var10000 = 18791;
         int var37 = this.aO;
         int var36 = this.aN;
         GL30C.glBlendEquationSeparate(var36, var37);
         var10001 = 5285910295704232085L;
         int var41 = this.aS;
         int var40 = this.aR;
         int var39 = this.aQ;
         int var38 = this.aP;
         GL30C.glBlendFuncSeparate(var38, var39, var40, var41);
         int var10002 = this.aT[0];
         int var10003 = this.aT[1];
         int var10004 = this.aT[2];
         int var45 = this.aT[3];
         int var44 = var10004;
         int var43 = var10003;
         int var42 = var10002;
         GL30C.glScissor(var42, var43, var44, var45);
         char var88 = '貨';
         int var47 = this.aU;
         GL30C.glBindFramebuffer(36008, var47);
         var10000 = 23746;
         var10001 = 4149068261743686968L;
         char var90 = '販';
         int var49 = this.aV;
         GL30C.glBindFramebuffer(36009, var49);
         break;
      }
   }

   static {

      {

      b();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(105423307417098L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[33];
      String var6 = "\u001f\u0099\u0090\u0017w®\u0092Ã}\bÐw¯\fW\u0003FCðõªËm¢ö¦\u0099\u0019ª_Q\u0010lTM6P/æ\u001dó\u0089<õû\u000bÕ\u0093õ¶\u000f}¢zu×\u001fz\u0016&\u0014\u00adv/8!,fO¢g\u0010¯w..Ê¢³\u0001!\u0097}ØàRzowÑRÿ²KDn1\u001dÏ¿x«ª\u001aOÁ³}®\u0012Ö`d\"ú!}WÄïpmÝ\u000fð#ø}\u0011Ö´l\u001eîê3~EDJ=\u0001\u008fHëÈ\u001d»ç\u0001\u0013\f\u001blê#:\u001d¶\u0080\u0095Rsñ¦\r/àj\u0001«\u0015#\u009cêVhÖÉ0\u008aêXgÊ}5~LM\\\u001d¬\u0096Im\u0094_7¾\u001fh\u009d\u008a»H\u0017¼ú\u00077Ø\u001dYóç<q´ä¥v\u008a»¡%c\r§m\u0005ÒøúzòÏ;\u0004]y\u001cp\u0096Ib\u009a³";
      int var7 = "\u001f\u0099\u0090\u0017w®\u0092Ã}\bÐw¯\fW\u0003FCðõªËm¢ö¦\u0099\u0019ª_Q\u0010lTM6P/æ\u001dó\u0089<õû\u000bÕ\u0093õ¶\u000f}¢zu×\u001fz\u0016&\u0014\u00adv/8!,fO¢g\u0010¯w..Ê¢³\u0001!\u0097}ØàRzowÑRÿ²KDn1\u001dÏ¿x«ª\u001aOÁ³}®\u0012Ö`d\"ú!}WÄïpmÝ\u000fð#ø}\u0011Ö´l\u001eîê3~EDJ=\u0001\u008fHëÈ\u001d»ç\u0001\u0013\f\u001blê#:\u001d¶\u0080\u0095Rsñ¦\r/àj\u0001«\u0015#\u009cêVhÖÉ0\u008aêXgÊ}5~LM\\\u001d¬\u0096Im\u0094_7¾\u001fh\u009d\u008a»H\u0017¼ú\u00077Ø\u001dYóç<q´ä¥v\u008a»¡%c\r§m\u0005ÒøúzòÏ;\u0004]y\u001cp\u0096Ib\u009a³"
         .length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         // while (true) {
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     c = var8;
                     d = new Integer[33];
                     a = 8;
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "\u008e1M\u0084æT#-O\u0012<àà¿ó\u0000";
                  var7 = "\u008e1M\u0084æT#-O\u0012<àà¿ó\u0000".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 10729;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])e.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/go", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/go_C0354",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/go" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 17;
            yield var15;
         }
         case 1 -> {
            byte var16 = 0;
            yield var16;
         }
         case 2 -> {
            byte var17 = 34;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 23;
            yield var19;
         }
         case 5 -> {
            byte var20 = 5;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 39;
            yield var22;
         }
         case 8 -> {
            byte var23 = 52;
            yield var23;
         }
         case 9 -> {
            byte var24 = 56;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 6;
            yield var26;
         }
         case 12 -> {
            byte var27 = 13;
            yield var27;
         }
         case 13 -> {
            byte var28 = 18;
            yield var28;
         }
         case 14 -> {
            byte var29 = 14;
            yield var29;
         }
         case 15 -> {
            byte var30 = 37;
            yield var30;
         }
         case 16 -> {
            byte var31 = 47;
            yield var31;
         }
         case 17 -> {
            byte var32 = 9;
            yield var32;
         }
         case 18 -> {
            byte var33 = 26;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 21;
            yield var35;
         }
         case 21 -> {
            byte var36 = 61;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 43;
            yield var38;
         }
         case 24 -> {
            byte var39 = 24;
            yield var39;
         }
         case 25 -> {
            byte var40 = 46;
            yield var40;
         }
         case 26 -> {
            byte var41 = 54;
            yield var41;
         }
         case 27 -> {
            byte var42 = 27;
            yield var42;
         }
         case 28 -> {
            byte var43 = 12;
            yield var43;
         }
         case 29 -> {
            byte var44 = 45;
            yield var44;
         }
         case 30 -> {
            byte var45 = 53;
            yield var45;
         }
         case 31 -> {
            byte var46 = 30;
            yield var46;
         }
         case 32 -> {
            byte var47 = 32;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 48;
            yield var49;
         }
         case 35 -> {
            byte var50 = 36;
            yield var50;
         }
         case 36 -> {
            byte var51 = 8;
            yield var51;
         }
         case 37 -> {
            byte var52 = 15;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 4;
            yield var54;
         }
         case 40 -> {
            byte var55 = 28;
            yield var55;
         }
         case 41 -> {
            byte var56 = 38;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 58;
            yield var59;
         }
         case 45 -> {
            byte var60 = 20;
            yield var60;
         }
         case 46 -> {
            byte var61 = 49;
            yield var61;
         }
         case 47 -> {
            byte var62 = 35;
            yield var62;
         }
         case 48 -> {
            byte var63 = 62;
            yield var63;
         }
         case 49 -> {
            byte var64 = 51;
            yield var64;
         }
         case 50 -> {
            byte var65 = 63;
            yield var65;
         }
         case 51 -> {
            byte var66 = 2;
            yield var66;
         }
         case 52 -> {
            byte var67 = 31;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 41;
            yield var69;
         }
         case 55 -> {
            byte var70 = 25;
            yield var70;
         }
         case 56 -> {
            byte var71 = 42;
            yield var71;
         }
         case 57 -> {
            byte var72 = 57;
            yield var72;
         }
         case 58 -> {
            byte var73 = 55;
            yield var73;
         }
         case 59 -> {
            byte var74 = 10;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 44;
            yield var76;
         }
         case 62 -> {
            byte var77 = 50;
            yield var77;
         }
         default -> 7;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      f[0] = "G<$\u0004\u0015AB)/\u0004\u0016FM $FWqd}si";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = void.class;
      g[2] = "java/lang/Void";
      f[3] = ";a|\u001c\"h-ayF1\u007f:*z@=k+mmWv\u007f0";
      f[4] = "YRI\u001b+{R]XTHvGPW?}tVCK\u0013jy";
      f[5] = "\u000f7=\u0018\tJ\u001978B\u001a]\u000e|;D\u0016I\u001f;,S][.";
      f[6] = "k~";
      f[7] = boolean.class;
      g[7] = "java/lang/Boolean";
      f[8] = "^\u007f0]@]Up!\u0012!S^{%H";
      f[9] = "N\u000e!\u001e\u001dm\u0013E8\u007fOe>S<\u0019LO\tQ:$My\u001dM8\u0003M\u0001M\t`@Jf\u001a\\h\r 8J\u0006n\u0015Go\u001f\u000e#\u007f\u0019?E\b;\u0018NjMEQF\u001e0K]6\u0011K8\u00067h\u0011\u001c|\u001f]m\u0018Q?t";
      f[10] = "\u0013\u001a\u0001\u001f8\u0010NQ\u0018~j\u0018dE\u0018\u0014a\u0011)\u001aOO:\u0016NM\u001aGw|\u0010MM\u0003n\u0016\u0015D\u0000@\u0005";
      f[11] = "X RyQO[:\fr*Gb`F|ZK\u0013<CfQ.X!YhO_\u0004$Cc*";
      f[12] = "\u001c\u001ab\u0015\u001d3AQ{tO;lG\u007f\u0012L\u0012_^{\bA8@x\u007f\fI%O_\u007ft\u0019a\u0017\u001cx\u0013N4\u001fQ\u0012M\u001en\u0019Iu\u001aKfT#+\u001a\u001c\"MI.\u0013Qa&";
      f[13] = "{N,FM>p\fi\u0002s*@\u000f*ML+'X\u007fE\u0001A";
      f[14] = "e%$Bla8n=#>i\u0004w5X*j%\u001cm\u001d`25{:Hh\u007f_%j\u0012ng8r?\u001a#\rf\"e\u001c;j1wmQQ4a-kI6c4%&#hcca?Imj.\"T";
      f[15] = "U{.Sm\f\b072?\u0004&)\"S.\r3/.N-\u001a\u0002Bg\fa_\u0005%0Yi\u0012o{0\u000e-\u000b\u0005~9Cn`";
      f[16] = "^ZJ*\u0000\u0019\u0003\u0011SKR\u0011.\u0002\\'a\u0018\u0014\u001fG1Pu]]\u000btW\u0012\n\b\u00039=LZR\u0005!Z\u001b\u000fZHK\u0004\u001bX\u001eQ!\u0001\u0012\u0015]:";
      f[17] = "1pk6fgl;rW4oD$g\u0016=wf&v-[25x$=<e`piWb5:vq05`2;\u001b";
      f[18] = "ww\u001dlDA*<\u0004\r\u0016I\u0002#\u0011L\u001fQ !\u0000w\u0007-tp\\2\u0013J#%T\u007fy\u0011r3\fbG]t?\u0002\r@Cq3\u0006gEJ<pm";
      f[19] = "1\u0015!?~\u001fl^8^,\u0017AM72\u001d\u001eqP<.\n\tqE ^zM:\u0013;9-\u00182^Qg-OvG;b$\u00025,";
      f[20] = "E\u0006\u001dw\u001es\u0018M\u0004\u0016L{3^\u0016\u007fI{\u0012?T(\u0012 \u0015X\u0003}\u001am\u007f\u0006\u0003*^t\u0015\u0003\ng\u001d\u001f";
      f[21] = "hN\u0007T#h5\u0005\u001e5q`\u0013\f:Swn6\u001a\u001b5':cH\u001dRpok\u0005w\b!<cH\u0012J}miw";
      f[22] = "d\u0017_@d\u00069\\F!6\u000e\u0014OIM\u0013\u00170@B[YS`\u001f\u0010K>\u00045\u0017]!`To\u0011EF7\u0001g\\/\u00187V#EE\u001d>\u001b`.";
      f[23] = "\u0003xU,\u0011{^3LMCss C!bmP$H'QyW,_M\u0015)\b~O*B|\u00003%t\u0012&\u0006+B#G.KA\u001c#\u0010jR+\u0019*])9";
      f[24] = "-N\u0003dPNp\u0005\u001a\u0005\u0002FJ\f\u001e]\u0017Ex\r\u001a`m\u001b)FLo\nL|N\u0001\u0005TL+\n\u0018oQEfIs";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(578700866519623L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(578700866519623L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(578700866519623L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 208;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 235;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 253;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 164;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 74;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 208;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 235;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 253;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/go_C0354",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/go" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
