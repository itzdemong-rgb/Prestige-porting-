package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.IntFunction;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.jetbrains.annotations.NotNull;
import org.lwjgl.opengl.GL30;

public final class GlVertexArray implements AutoCloseable {
   private final int a;
   private final VertexBufferBinding[] b;
   private final Cleanable c;
   private int d;
   public static final boolean e;
   private static final long f = 115840403136947L;
   private static final String g;
   private static final long[] h;
   private static final Integer[] i;
   private static final Map j;
   private static final Object[] k = new Object[61];
   private static final String[] l = new String[61];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   private GlVertexArray(int var1, VertexBufferBinding[] var2, long var3) {
      super();
      var3 = 115840403136947L ^ var3;

      this.a = var1;
      short var10001 = 1208;
      long var10002 = 8129949629402422148L ^ var3;
      this.b = new VertexBufferBinding[16];
      VertexBufferBinding[] var18 = var2;
      if (var18 != null) {
         byte var24 = 0;
         byte var10003 = 0;
         int var9 = var2.length;
         VertexBufferBinding[] var7 = this.b;
         VertexBufferBinding[] var5 = var2;
         System.arraycopy(var5, 0, var7, 0, var9);
      }

      VertexBufferBinding[] var20 = var2;
      GlVertexArray var19 = this;
      GlVertexArray var15 = var19;
      GlVertexArray var14 = var19;
      GlVertexArray var16;
      int var17;
      if (var20 == null) {
         byte var22 = 0;
         GlVertexArray var21 = var14;
         var16 = var21;
         var17 = var22;
      } else {
         var17 = var2.length;
         var16 = var15;
      }

      var16.d = var17;
      Cleaner var25 = RenderThreadUtil.a;
      Runnable var13 = invokeBinding1(var1);
      GlVertexArray var12 = this;
      Cleaner var11 = var25;
      this.c = var11.register(var12, var13);
   }

   public static GlVertexArray aReturningf7(Object[] var0) {
      ManagedGlBuffer var1 = (ManagedGlBuffer)var0[0];
      VertexFormat var2 = (VertexFormat)var0[1];
      long var3 = (Long)var0[2];
      var3 = 115840403136947L ^ var3;
      long var5 = var3 ^ 111347351948929L;
      long var7 = var3 ^ 71087996616582L;
      Object[] var9 = new Object[]{var1, var2, var7};
      Object[] var10 = new Object[]{aReturningList(var9), var5};
      return b(var10);
   }

   @NotNull
   public static List aReturningList(Object[] var0) {
      ManagedGlBuffer var3 = (ManagedGlBuffer)var0[0];
      VertexFormat var4 = (VertexFormat)var0[1];
      long var1 = (Long)var0[2];
      var1 = 115840403136947L ^ var1;
      long var5 = var1 ^ 118359172329667L;
      ArrayList var7 = new ArrayList(var4.a.length);
      while (true) {
         int var14 = var4.a.length;
         int var13 = var8;
         if (var13 >= var14) {
            return var7;
         }

         Object[] var10006 = new Object[]{null, null, var5};
         var10006[1] = var8;
         var10006[0] = var3;
         Object[] var10 = var10006;
         VertexFormat var9 = var4;
         VertexBufferBinding var12 = var9.aReturningVoid(var10);
         ArrayList var11 = var7;
         var11.add(var12);
         var8++;
      }
   }

   public static GlVertexArray b(Object[] var0) {
      List var1 = (List)var0[0];
      long var2 = (Long)var0[1];
      var2 = 115840403136947L ^ var2;
      long var4 = var2 ^ 74252689317895L;
      long var6 = var2 ^ 22331455026182L;
      int var8 = GL30.glGenVertexArrays();
      GlVertexArray var9 = new GlVertexArray(var8, null, var4);
      List var12 = var1;
      if (var12 != null) {
         Object[] var11 = new Object[]{var1, var6};
         GlVertexArray var10 = var9;
         var10.aReturningVoid(var11);
      }

      return var9;
   }

   @Override
   public void close() {
      Cleanable var3 = this.c;
      var3.clean();
   }

   public void aReturningVoid(Object[] var1) {
      List var4 = (List)var1[0];
      long var2 = (Long)var1[1];
      var2 = 115840403136947L ^ var2;
      List var12 = var4;
      int var5 = var12.size();
      boolean var58 = e;
      if (!var58) {
         short var10001 = 2268;
         long var10002 = 8880087345824891874L ^ var2;
         byte var60 = 16;
         int var59 = var5;
         if (var59 > var60) {
            throw new AssertionError(g + var5 + ")");
         }
      }

      IntFunction var16 = invokeBinding2();
      List var15 = var4;
      VertexBufferBinding[] var6 = ((dev.zprestige.prestige.renderlib.VertexBufferBinding[])(Object)(var15.toArray(var16)));
      int var62 = var5;
      int var61 = this.d;
      if (var61 == var62) {
         byte var73 = 0;
         byte var10004 = 0;
         int var22 = var6.length;
         VertexBufferBinding[] var20 = var6;
         int var19 = this.d;
         VertexBufferBinding[] var17 = this.b;
         boolean var63 = Arrays.equals(var17, 0, var19, var20, 0, var22);
         if (var63) {
            return;
         }
      }

      int var26 = var5;
      int var25 = this.d;
      int var7 = Math.max(var25, var26);
      int var28 = var5;
      int var27 = this.d;
      int var8 = Math.min(var27, var28);
      int var29 = this.a;
      GL30.glBindVertexArray(var29);
      int var9 = var8;

      while (true) {
         int var65 = var7;
         int var64 = var9;
         if (var64 >= var65) {
            var9 = 0;

            while (true) {
               int var69 = var5;
               int var68 = var9;
               if (var68 >= var69) {
                  GL30.glBindVertexArray(0);
                  Object var52 = null;
                  VertexBufferBinding[] var51 = this.b;
                  Arrays.fill(var51, var52);
                  byte var77 = 0;
                  byte var79 = 0;
                  int var57 = var5;
                  VertexBufferBinding[] var55 = this.b;
                  VertexBufferBinding[] var53 = var6;
                  System.arraycopy(var53, 0, var55, 0, var57);
                  this.d = var5;
                  return;
               }

               int var35 = var9;
               List var34 = var4;
               VertexBufferBinding var10 = (VertexBufferBinding)var34.get(var35);
               short var10000 = 8081;
               long var74 = 845864111740130478L ^ var2;
               char var72 = '袒';
               ManagedGlBuffer var75 = var10.recoveryAccess_read_bZ();
               Object[] var37 = new Object[0];
               ManagedGlBuffer var36 = var75;
               int var39 = var36.aReturningInt(var37);
               GL30.glBindBuffer(34962, var39);
               VertexAttribute var11 = var10.recoveryAccess_read_b0();
               VertexAttribute var40 = var11;
               int var76 = var40.b3();
               VertexAttribute var41 = var11;
               int var78 = var41.b4();
               VertexAttribute var42 = var11;
               boolean var10003 = var42.b6();
               long var48 = var10.recoveryAccess_read_b2();
               int var47 = var10.recoveryAccess_read_b1();
               boolean var46 = var10003;
               int var45 = var78;
               int var44 = var76;
               int var43 = var9;
               GL30.glVertexAttribPointer(var43, var44, var45, var46, var47, var48);
               var9++;
            }
         }

         int var67 = this.d;
         int var66 = var9;
         if (var66 >= var67) {
            int var31 = var9;
            GL30.glEnableVertexAttribArray(var31);
         } else {
            int var33 = var9;
            GL30.glDisableVertexAttribArray(var33);
         }

         var9++;
      }
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   private static VertexBufferBinding[] lambda$rebind$2(int var0) {
      return new VertexBufferBinding[var0];
   }

   private static void lambda$new$1(int var0) {
      long var10001 = 76194637203597L ^ 105963579418589L;
      Object[] var5 = new Object[]{invokeBinding3(var0), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var5);
   }

   private static void lambda$new$0(int var0) {
      int var3 = var0;
      GL30.glDeleteVertexArrays(var3);
   }

   static {

      aReturningVoid();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(24185804170114L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var13 = var11.doFinal("Úb\u00035ö«h\u0092±oÝFÕèè\u009a&!\u001a}ßß%$".getBytes("ISO-8859-1"));
      String var20 = a(var13).intern();
      int var10001 = -1;
      g = var20;
      j = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(24185804170114L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[3];
      String var4 = "MbùÛ7M»\u0010kådØò¼\u0087)2§\u0010ûä\u0012Ý\u000b";
      int var5 = "MbùÛ7M»\u0010kådØò¼\u0087)2§\u0010ûä\u0012Ý\u000b".length();
      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         // var6[var10001] = var10004;
      } while (var2 < var5);

      h = var6;
      i = new Integer[3];
      Class<GlVertexArray> var16 = GlVertexArray.class;
      e = dev.prestige.recovery.SourceSupport.asBoolean((!var16.desiredAssertionStatus() ? 1 : 0));
   
      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15106;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/f7", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f7",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 16;
            yield var15;
         }
         case 1 -> {
            byte var16 = 60;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 23;
            yield var18;
         }
         case 4 -> {
            byte var19 = 31;
            yield var19;
         }
         case 5 -> {
            byte var20 = 22;
            yield var20;
         }
         case 6 -> {
            byte var21 = 52;
            yield var21;
         }
         case 7 -> {
            byte var22 = 3;
            yield var22;
         }
         case 8 -> {
            byte var23 = 4;
            yield var23;
         }
         case 9 -> {
            byte var24 = 49;
            yield var24;
         }
         case 10 -> {
            byte var25 = 7;
            yield var25;
         }
         case 11 -> {
            byte var26 = 18;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 53;
            yield var28;
         }
         case 14 -> {
            byte var29 = 58;
            yield var29;
         }
         case 15 -> {
            byte var30 = 0;
            yield var30;
         }
         case 16 -> {
            byte var31 = 38;
            yield var31;
         }
         case 17 -> {
            byte var32 = 50;
            yield var32;
         }
         case 18 -> {
            byte var33 = 46;
            yield var33;
         }
         case 19 -> {
            byte var34 = 54;
            yield var34;
         }
         case 20 -> {
            byte var35 = 34;
            yield var35;
         }
         case 21 -> {
            byte var36 = 62;
            yield var36;
         }
         case 22 -> {
            byte var37 = 63;
            yield var37;
         }
         case 23 -> {
            byte var38 = 37;
            yield var38;
         }
         case 24 -> {
            byte var39 = 30;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 12;
            yield var41;
         }
         case 27 -> {
            byte var42 = 56;
            yield var42;
         }
         case 28 -> {
            byte var43 = 51;
            yield var43;
         }
         case 29 -> {
            byte var44 = 27;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 57;
            yield var46;
         }
         case 32 -> {
            byte var47 = 35;
            yield var47;
         }
         case 33 -> {
            byte var48 = 55;
            yield var48;
         }
         case 34 -> {
            byte var49 = 25;
            yield var49;
         }
         case 35 -> {
            byte var50 = 42;
            yield var50;
         }
         case 36 -> {
            byte var51 = 29;
            yield var51;
         }
         case 37 -> {
            byte var52 = 45;
            yield var52;
         }
         case 38 -> {
            byte var53 = 21;
            yield var53;
         }
         case 39 -> {
            byte var54 = 28;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 26;
            yield var56;
         }
         case 42 -> {
            byte var57 = 1;
            yield var57;
         }
         case 43 -> {
            byte var58 = 10;
            yield var58;
         }
         case 44 -> {
            byte var59 = 15;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 9;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 47;
            yield var64;
         }
         case 50 -> {
            byte var65 = 36;
            yield var65;
         }
         case 51 -> {
            byte var66 = 44;
            yield var66;
         }
         case 52 -> {
            byte var67 = 8;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 48;
            yield var70;
         }
         case 56 -> {
            byte var71 = 13;
            yield var71;
         }
         case 57 -> {
            byte var72 = 2;
            yield var72;
         }
         case 58 -> {
            byte var73 = 17;
            yield var73;
         }
         case 59 -> {
            byte var74 = 59;
            yield var74;
         }
         case 60 -> {
            byte var75 = 14;
            yield var75;
         }
         case 61 -> {
            byte var76 = 20;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 40;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      k[0] = "\u0012\u007fn|\u001f:\fwt3}&\u000bj";
      k[1] = "3c\u0010U>R8l\u0001\u001a_\\3g\u0005@";
      k[2] = boolean.class;
      l[2] = "java/lang/Boolean";
      k[3] = "DI}2\rARIxh\u001eVE\u0002{n\u0012BTElyYW\u0017";
      k[4] = "[o!\u000f\u001bwP`0@xzEm?+MxT~#\u0007Zu";
      k[5] = "_\u001a/aprI\u001a*;ce^Q)=oqO\u0016>*$d\u0003";
      k[6] = "47[]\u0019qA\u0017PR\b> \u0019[Y\fdT";
      k[7] = " \u0013\u000eAHw6\u0013\u000b\u001b[`!X\b\u001dWt0\u001f\u001f\n\u001c`\u000b";
      k[8] = " \u0007Z\f&G+\bKCKG+\u0015_";
      k[9] = "\u001dHu5\u0013\u001f\u0016GdzO\u0016\u0011\u0007@8X\u0012\u0019Lqp~\u001f\u0012Hm5_\u001f\u0012";
      k[10] = void.class;
      l[10] = "java/lang/Void";
      k[11] = "JM\u0014}}O\\M\u0011'nXK\u0006\u0012!bLZA\u00056)[D";
      k[12] = "\bQI#l\u0007}qB,}H\u001c\u007fI'y\u0012h";
      k[13] = "\u000b3>HW\u0013\u0000</\u00074\u001e\u0015:";
      k[14] = int.class;
      l[14] = "java/lang/Integer";
      k[15] = "\u0000IVi`K\u0016IS3s\\\u0001\u0002P5\u007fH\u0010EG\"4Y4";
      k[16] = "VpWd)\u001e#P\\k8QB^W`<\u000b6";
      k[17] = "2e7&D77p<&G08y7d\u0006\u0007\u0011$`";
      k[18] = "[DC)t,MDFsg;Z\u000fEuk/KHRb ;o";
      k[19] = "9\fqxdQ'\u0004k7,Q=\u000esp%J}$im\fQ=\u000esp%J";
      k[20] = "\u0002C5S,0wc>\\=\u007f\u0016m5W9%b";
      k[21] = "\u0018<r\u000e\u000f/\u00064hA`(\u0000<}\u001c";
      k[22] = "!ZDD\u001a)TzOK\u000bf5tD@\u000f<A";
      k[23] = "nXJRv\u0018eW[\u001d\u000b\rwMY^";
      k[24] = long.class;
      l[24] = "java/lang/Long";
      k[25] = "\u0017fL:KgbFG5Z(\u0003HL>^rw";
      k[26] = "\u001cf0mFjiF;bW%\bH0iS\u007f|";
      k[27] = ")1p 0#\\\u0011{/!l=\u001fp$%6I";
      k[28] = "\u000e\u001bI]dc{;BRu,\u001a5IYqvn";
      k[29] = "w\u0017bGKi\u00027iHZ&c9bC^|\u0017";
      k[30] = "<\u001a#?W^7\u00152p\u000bW0U\u00162\u001cS8\u001e'";
      k[31] = "\u0000T\u000b`9\u0017\u000b[\u001a/E\u000e\u0004[\u001cc{\u001e";
      k[32] = "6\u001a\u001d)m9|O\u001c&P-nQ~/l$eY\u0001>l48!\u0017z<*\u007f^\u0006z,w\u0007HB*20xYB:oH";
      k[33] = "\u0013IXmGo\u0015\u0014N%{|I\u0014Lr{(@\t[y\u0018~N\u0019E\u0014";
      k[34] = "}\u0001\u001e~L$|H\u0007y6 s?\u000fd[3z-\u000fzJ\"g:\u0018z_>ls\u000b<Z-o\f\u001a<Jp\u0017L\u000fpH\"t\u001a\u0001`VO";
      k[35] = "5v\u0018\u0014\u0010r4?\u0001\u0013jv;N\u0005\f\u0006G2~\u0018\u0007\u001aP%~\r\u001bjpch\u0006\u0012\u0015acx[jUt/z\t\t\u0003z?dd";
      k[36] = "\u001515o\u0007+G0?)nqBNg/\u0002y\u00061v/\u0012$~";
      k[37] = "z[\u001c\u0000[O!\u0000\u001d\u001e>Rs\u0004\f\u000bBEdk\u0012\u0017_N~\u001b\u0016JY({W\u0003\u0017NMdV\u0001\u000b>\u0016.\u0016\u0014LF\u0010s\u0000\\p";
      k[38] = "pJ2z\u0001\u007f-\u00032?osKQ~9\rx$\u000b<b\u001e\u001av\u000b;:\u000bwu^9eo";
      k[39] = "W0j6\u0002]\u00051`pk\u0007\u0002Oh&\u0014VS?:4\f\u0001<";
      k[40] = "[\u0014lLPiZ]uK*mU*qIChU\u000bN_P~\\\u0016YNVxP\fYHPk@fy\u000eF`I\u0019h\u000eV=1Y}BToR\u000fsRJ\u0002";
      k[41] = "\u000b\b\f/\u0015l\nA\u0015(oh\u0005$\u001d+\u0013j\u00113\f-\u0015f\u000b\"\u00170\t{\f\u0000p8Sk\u0003\u0002\u000f)S{^z\u0019m\u0003e\u0019\u0005\bm\u00138a\u0013L=\r\u007f\u001e\u0002L-P\u0007X\u0016\u000fj\u0000w\n\u0004\u0017=on]\u0016\u0012)\u0010\u007f]\u0006OQ\u000f>\u0018@\u000fiRgXCpn\u0002w\u001f\u0017\u00138\fg\u0001z";
      k[42] = "l.+v0;&{*y\r/<sHp1&?m7a16b\u0015!%a(%j0%qu]|tuo2\"mte2J";
      k[43] = "'}F\u001ac\fu|L\\\nVw\u0002\u0014Zf^4}\u0005Zv\u0003L";
      k[44] = "\u0017\u0000{;R\\\u001dJp *Y-S+~HQB\ti%[3\u0017\u0000{;R\\\u001dJp *";
      k[45] = "\u0004d7\"\u0005\u001c\u001c~,=:\u000emynfX\u0005\u0002#,=Kg\u0004&<>B\u0018\u0015&,c:";
      k[46] = "^\u007f_`^[\u0003v\u0019o2Pnu\u001d;P\\\u0001/_`C>Q{S\u007f_]\u0007uCa2";
      k[47] = "9\u0000FXv<8I__\f87=W@R:)\u000eWVE-)\u001bK]\f>o\u001eX^s/o\u000e\u0005&";
      k[48] = "/\u001d]7$x(\u0016\u0015\u0007?)&sS`7#*\u0003W=1Es\u001fS<95!\rKkV";
      k[49] = "q\u0006%\t\u0005Gv\rm9\f\u001bf\u0005TPK\u0016v\u0010+AK\u0006+h";
      k[50] = "\u0012]V76\u0002\u0018\u0017],N\u0004(VV2\u007f\tJW^)<m\u0013\u0003By*\u000f\u0012\u000bY:N";
      k[51] = "vnS\u00177\u0003qe\u001b'*So\u0000K\u001b)\\k\u007fZ\u001b9\u0001\u0013\u007fEF#^c{\u0018@E";
      k[52] = ".bTR&0$(_I^6\u00141\u0004\u0017<={kFL/_+?JS3<}1ZM^";
      k[53] = "\u001b\t\t3*\u0001\u001a@\u00104P\u0005\u00151\u0014+< \f\u0015\u001b *j\u0018G\u0019/(\u0015\tG\trP\u0003M\u0017\u00175/\u0012M\u0007JMo\u0007\u0001\u0005\u0018.9\t\u0011\u001bu";
      k[54] = "7\u0019QH>)0\u0012\u0019x0s\u001b\rZ\u0011=\u0014>\u001bIH5(m\u001cPHLwlMB\u001a#-.\u0016Qx";
      k[55] = "I\u0000\u00058:LHI\u001c?@HG?\u001f/*CN,\u0014<<JS;\u0005::FI;\u0003<)V#\u001bE*\"_\\\nE:\u007f'\u001c\u001f\t8-DJ\u0011\u0019&@";
      k[56] = "}sVWX]+%\u0017\u001c!Zr+\u0003lB\n)-\u0005\u0003\u0018Hr>g\u0013FUu/\u0017\u0017\u001bS\u0013p\n\u001c_Yp&\u0004\fA4";
      k[57] = "Ml==AX\u0011j~>/\r\u001dr&xB\r9r<oU\u001d\u0011n!YS\b\ft<\u0002\u0016\r\u000f2(rD\u001f\u0017eG";
      k[58] = "6\b]_i>4\u0002\u0017\u001b\t:#HF\u0015b4!C/\u001bn2?R_\u001f34Y[\u0013\bk+&J\u0013\u00186S&UN\u0002i#\"\bHd`o5PW\u001bqo%\r/\r5?;JP\u001c5/f2\u0010\ty-4QF\u0007i3Y";
      k[59] = "79'PDHaof\u001b=L x\u007f\u000fF!:;,\t_N`yw\u001a=Heit\u0013BYey)kT\u001d5gn\u0014E\u001d%:\u0016\b\u0003\u001b;gyRA@(\u0005\u007fWQC!znWA\u001eYl*\u0007_Y&}*\u0017\u0002!`iiPRQ2{q\u0007=";
      k[60] = "/l\u0007\u000fZ`%&\f\u0014\"f\u0015?WJ@mze\u0015\u0011S\u000fp2\u0018@P2w9Pp";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(92196859910496L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(92196859910496L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(92196859910496L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 77;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 197;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 249;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 181;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 102;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 114;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 77;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 197;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 249;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f7",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f7" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/f7", "lambda$new$1", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntFunction invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/IntFunction;", MethodHandles.lookup()),
                  SourceSupport.methodType("(I)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/f7", "lambda$rebind$2", "(I)[Ldev/zprestige/prestige/gO_C0353;"),
                  SourceSupport.methodType("(I)[Ldev/zprestige/prestige/gO_C0353;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntFunction)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Runnable invokeBinding3(int var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/f7", "lambda$new$0", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
