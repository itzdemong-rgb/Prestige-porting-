package dev.zprestige.prestige.renderlib;

public class GraphicsResourceMarker {
}
