package dev.zprestige.prestige.renderlib;


import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ManagedGlBuffer implements AutoCloseable {
   private static final Logger a;
   private final int b;
   private final AtomicLong c;
   private final Cleanable d;
   private int e;
   private static final long f = 64283272676030L;
   private static final long[] g;
   private static final Integer[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Long[] k;
   private static final Map l;
   private static final Object[] m = new Object[46];
   private static final String[] n = new String[46];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;

   public ManagedGlBuffer(int var1, AtomicLong var2, long var3) {
      super();
      var3 = 64283272676030L ^ var3;

      short var10001 = 25908;
      long var10002 = 5339724582859725926L ^ var3;
      this.e = 35044;
      this.b = var1;
      this.c = var2;
      Cleaner var9 = RenderThreadUtil.a;
      Runnable var7 = invokeBinding1(var1);
      ManagedGlBuffer var6 = this;
      Cleaner var5 = var9;
      this.d = var5.register(var6, var7);
   }

   public static ManagedGlBuffer a() {
      long var10001 = 24527466225535L ^ 120988104792540L;
      return new ManagedGlBuffer(GL15.glGenBuffers(), new AtomicLong(0L), 132246403761827L);
   }

   public void aReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var5 = (Long)var1[2];
      var5 = 64283272676030L ^ var5;
      short var10000 = 26166;
      long var10001 = 7989705153275915953L ^ var5;
      int var7 = GL11.glGetInteger(34964);
      var10000 = 21140;
      var10001 = 4072470051532626455L ^ var5;
      char var22 = '袒';
      int var10 = this.b;
      GL15.glBindBuffer(34962, var10);
      var10000 = 21140;
      var10001 = 4072470051532626455L ^ var5;
      char var24 = '袒';
      int var14 = var2;
      long var12 = var3;
      GL15.glBufferData(34962, var12, var14);
      var10000 = 21140;
      var10001 = 4072470051532626455L ^ var5;
      char var26 = '袒';
      int var16 = var7;
      GL15.glBindBuffer(34962, var16);
      this.e = var2;
      long var18 = var3;
      AtomicLong var17 = this.c;
      var17.set(var18);
   }

   public void bReturningVoid(Object[] var1) {
      int var3 = (Integer)var1[0];
      ByteBuffer var2 = (ByteBuffer)var1[1];
      long var4 = (Long)var1[2];
      var4 = 64283272676030L ^ var4;
      int var6 = invokeBinding3(invokeBinding2(11542, 3629398864094193216L ^ var4), 3897746674435028437L, var4);
      invokeBinding5(invokeBinding4(1823, 9133589519808744525L ^ var4), this.b, 3897498049118840083L, var4);
      invokeBinding7(invokeBinding6(21140, 4072507889113078213L ^ var4), var2, var3, 3897988189002005157L, var4);
      invokeBinding9(invokeBinding8(21140, 4072507889113078213L ^ var4), var6, 3897498049118840083L, var4);
      this.e = var3;
      invokeBinding11(this.c, invokeBinding10(var2, 3898552597135674712L, var4), 3897598894594015042L, var4);
   }

   public void cReturningVoid(Object[] var1) {
      long var5 = (Long)var1[0];
      ByteBuffer var4 = (ByteBuffer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 64283272676030L ^ var2;
      int var7 = invokeBinding13(invokeBinding12(26166, 7989761579446505700L ^ var2), 833378236032665682L, var2);
      invokeBinding15(invokeBinding14(21140, 4072422556305695810L ^ var2), this.b, 833697233331132564L, var2);
      invokeBinding17(invokeBinding16(21140, 4072422556305695810L ^ var2), var5, var4, 837029365029490540L, var2);
      invokeBinding19(invokeBinding18(21140, 4072422556305695810L ^ var2), var7, 833697233331132564L, var2);
   }

   public ByteBuffer aReturningByteBuffer(Object[] var1) {
      long var5 = (Long)var1[0];
      long var7 = (Long)var1[1];
      int var2 = (Integer)var1[2];
      long var3 = (Long)var1[3];
      var3 = 64283272676030L ^ var3;
      short var10000 = 26166;
      long var10001 = 7989736086054214172L ^ var3;
      int var9 = GL11.glGetInteger(34964);
      var10000 = 21140;
      var10001 = 4072465508723273402L ^ var3;
      char var24 = '袒';
      int var13 = this.b;
      GL15.glBindBuffer(34962, var13);
      var10000 = 21140;
      var10001 = 4072465508723273402L ^ var3;
      char var26 = '袒';
      int var19 = var2;
      long var17 = var7;
      long var15 = var5;
      ByteBuffer var10 = GL30.glMapBufferRange(34962, var15, var17, var19);
      var10000 = 21140;
      var10001 = 4072465508723273402L ^ var3;
      char var28 = '袒';
      int var21 = var9;
      GL15.glBindBuffer(34962, var21);
      return var10;
   }

   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 64283272676030L ^ var2;
      short var10000 = 26166;
      long var10001 = 7989693255953386461L ^ var2;
      int var4 = GL11.glGetInteger(34964);
      var10000 = 21140;
      var10001 = 4072490744423989115L ^ var2;
      char var13 = '袒';
      int var7 = this.b;
      GL15.glBindBuffer(34962, var7);
      var10000 = 21140;
      var10001 = 4072490744423989115L ^ var2;
      GL15.glUnmapBuffer(34962);
      var10000 = 21140;
      var10001 = 4072490744423989115L ^ var2;
      char var16 = '袒';
      int var10 = var4;
      GL15.glBindBuffer(34962, var10);
   }

   public void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = (Long)var1[1];
      long var6 = (Long)var1[2];
      var6 = 64283272676030L ^ var6;
      int var8 = invokeBinding21(invokeBinding20(26166, 7989800962000512338L ^ var6), 9090213896926576100L, var6);
      invokeBinding23(invokeBinding22(21140, 4072391828081988084L ^ var6), this.b, 9090462250850446626L, var6);
      invokeBinding25(invokeBinding24(21140, 4072391828081988084L ^ var6), var2, var4, 9090261302439402909L, var6);
      invokeBinding27(invokeBinding26(21140, 4072391828081988084L ^ var6), var8, 9090462250850446626L, var6);
   }

   public void fReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      long var5 = (Long)var1[2];
      long var7 = (Long)var1[3];
      long var9 = (Long)var1[4];
      var9 = 64283272676030L ^ var9;
      invokeBinding29(invokeBinding28(10250, 2855515368911256811L ^ var9), this.b, -1610898877505045855L, var9);
      invokeBinding31(invokeBinding30(1899, 5969831472167916425L ^ var9), var2, -1610898877505045855L, var9);
      invokeBinding34(
         invokeBinding32(5124, 6619427607444521186L ^ var9), invokeBinding33(18548, 3364520470264011921L ^ var9), var3, var5, var7, -1609388533886007472L, var9
      );
   }

    public void gReturningVoid(final Object[] array) {
      Object[] recoveryStack=new Object[16];
      Object[] recoveryLocals=new Object[11];
      recoveryLocals[0]=this;
      recoveryLocals[1]=array;
      int recoveryPc=0, recoveryAt=0;
      recoveryFlow: while(true) {
            switch(recoveryPc){
               case 0 -> {
                  recoveryAt=0; { recoveryStack[0]=recoveryLocals[1];  }
                  recoveryAt=1; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=2; { recoveryStack[2]=0; }
                  recoveryAt=3; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=4; { recoveryStack[1]=((java.lang.Integer)recoveryStack[1]); }
                  recoveryAt=5; { recoveryStack[1]=((java.lang.Integer)recoveryStack[1]).intValue(); }
                  recoveryAt=6; { recoveryLocals[2]=recoveryStack[1];  }
                  recoveryAt=7; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=8; { recoveryStack[2]=1; }
                  recoveryAt=9; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=10; { recoveryStack[1]=((java.nio.ByteBuffer)recoveryStack[1]); }
                  recoveryAt=11; { recoveryLocals[3]=recoveryStack[1];  }
                  recoveryAt=12; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=13; { recoveryStack[2]=2; }
                  recoveryAt=14; { recoveryStack[1]=((Object[])recoveryStack[1])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[2])]; }
                  recoveryAt=15; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]); }
                  recoveryAt=16; { recoveryStack[1]=((java.lang.Long)recoveryStack[1]).longValue(); }
                  recoveryAt=17; { recoveryLocals[4]=recoveryStack[1];  }
                  recoveryAt=19; { recoveryStack[0]=64283272676030L; }
                  recoveryAt=20; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=21; { recoveryStack[0]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]); }
                  recoveryAt=22; { recoveryLocals[4]=recoveryStack[0];  }
                  recoveryAt=23; { recoveryStack[0]=recoveryLocals[4];  }
                  recoveryAt=24; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=25; { recoveryStack[2]=33554575650708L; }
                  recoveryAt=26; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=27; { recoveryLocals[6]=recoveryStack[1];  }
                  recoveryAt=28; { recoveryStack[1]=recoveryStack[0]; }
                  recoveryAt=29; { recoveryStack[2]=83977631420947L; }
                  recoveryAt=30; { recoveryStack[1]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]); }
                  recoveryAt=31; { recoveryLocals[8]=recoveryStack[1];  }
                  recoveryAt=33; { recoveryStack[0]=-2651770188458739667L; }
                  recoveryAt=34; { recoveryStack[1]=recoveryLocals[4];  }
                  recoveryAt=35; { recoveryStack[0]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding35(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=36; { recoveryLocals[10]=recoveryStack[0];  }
                  recoveryAt=39; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=40; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])==0){recoveryPc=102; continue recoveryFlow;} recoveryPc=42; continue recoveryFlow; }
               }
               case 42 -> {
                  recoveryAt=42; { recoveryStack[0]=recoveryLocals[3];  }
                  recoveryAt=43; { recoveryStack[1]=-2652527696598327182L; }
                  recoveryAt=44; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=45; { recoveryStack[0]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding36(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=46; { recoveryStack[0]=(long)dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0]); }
                  recoveryAt=47; { recoveryStack[1]=recoveryLocals[0];  }
                  recoveryAt=48; { recoveryStack[1]=((dev.zprestige.prestige.renderlib.ManagedGlBuffer)recoveryStack[1]).c; }
                  recoveryAt=49; { recoveryStack[2]=-2648734149275312306L; }
                  recoveryAt=50; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=51; { recoveryStack[1]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding37(((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=52; { recoveryStack[0]=Long.compare(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1])); }
                  recoveryAt=53; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])<=0){recoveryPc=107; continue recoveryFlow;} recoveryPc=55; continue recoveryFlow; }
               }
               case 55 -> {
                  recoveryAt=55; { recoveryPc=65; continue recoveryFlow; }
               }
               case 58 -> {
                  recoveryAt=58; { recoveryStack[1]=-2651532488098329001L; }
                  recoveryAt=59; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=60; { recoveryStack[0]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding38(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=61; { throw (Throwable)recoveryStack[0]; }
               }
               case 65 -> {
                  recoveryAt=65; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=66; { recoveryStack[1]=recoveryLocals[2];  }
                  recoveryAt=67; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=68; { recoveryStack[3]=recoveryLocals[6];  }
                  recoveryAt=69; { recoveryStack[4]=3; }
                  recoveryAt=70; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=71; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=72; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=74; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=75; { recoveryStack[6]=2; }
                  recoveryAt=76; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=77; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=78; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=79; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=80; { recoveryStack[5]=1; }
                  recoveryAt=81; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=82; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=83; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=84; { Object recoveryTemp=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=85; { recoveryStack[3]=java.lang.Integer.valueOf(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])); }
                  recoveryAt=86; { recoveryStack[4]=0; }
                  recoveryAt=87; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=88; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=89; { recoveryStack[2]=-2652199547268134496L; }
                  recoveryAt=90; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=91; { dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding39(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=93; { recoveryPc=102; continue recoveryFlow; }
               }
               case 96 -> {
                  recoveryAt=96; { recoveryStack[1]=-2651532488098329001L; }
                  recoveryAt=97; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=98; { recoveryStack[0]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding40(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=99; { throw (Throwable)recoveryStack[0]; }
               }
               case 102 -> {
                  recoveryAt=102; { recoveryStack[0]=recoveryLocals[10];  }
                  recoveryAt=103; { if(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[0])!=0){recoveryPc=150; continue recoveryFlow;} recoveryPc=107; continue recoveryFlow; }
               }
               case 107 -> {
                  recoveryAt=107; { recoveryStack[0]=recoveryLocals[0];  }
                  recoveryAt=108; { recoveryStack[1]=18898; }
                  recoveryAt=109; { recoveryStack[2]=3493611718709773608L; }
                  recoveryAt=110; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=111; { recoveryStack[2]=dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])^dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3]); }
                  recoveryAt=112; { recoveryStack[1]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding41(dev.prestige.recovery.SourceSupport.asInt(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=113; { recoveryStack[2]=recoveryLocals[3];  }
                  recoveryAt=114; { recoveryStack[3]=recoveryLocals[8];  }
                  recoveryAt=115; { recoveryStack[4]=3; }
                  recoveryAt=116; { recoveryStack[4]=new java.lang.Object[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]; }
                  recoveryAt=117; { Object recoveryTemp=recoveryStack[4];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=118; { Object recoveryTemp=recoveryStack[5];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=120; { recoveryStack[5]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[5])); }
                  recoveryAt=121; { recoveryStack[6]=2; }
                  recoveryAt=122; { Object recoveryTemp=recoveryStack[6];recoveryStack[6]=recoveryStack[5];recoveryStack[5]=recoveryTemp; }
                  recoveryAt=123; { ((Object[])recoveryStack[4])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[5])]=recoveryStack[6]; }
                  recoveryAt=124; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=125; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=126; { recoveryStack[5]=1; }
                  recoveryAt=127; { Object recoveryTemp=recoveryStack[5];recoveryStack[5]=recoveryStack[4];recoveryStack[4]=recoveryTemp; }
                  recoveryAt=128; { ((Object[])recoveryStack[3])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[4])]=recoveryStack[5]; }
                  recoveryAt=129; { Object recoveryTemp=recoveryStack[2];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryStack[1];recoveryStack[1]=recoveryTemp; }
                  recoveryAt=130; { Object recoveryTemp=recoveryStack[3];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryStack[2];recoveryStack[2]=recoveryTemp; }
                  recoveryAt=132; { recoveryStack[3]=java.lang.Long.valueOf(dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=133; { recoveryStack[4]=0; }
                  recoveryAt=134; { Object recoveryTemp=recoveryStack[4];recoveryStack[4]=recoveryStack[3];recoveryStack[3]=recoveryTemp; }
                  recoveryAt=135; { ((Object[])recoveryStack[2])[dev.prestige.recovery.SourceSupport.asInt(recoveryStack[3])]=recoveryStack[4]; }
                  recoveryAt=136; { recoveryStack[2]=-2648869174591984672L; }
                  recoveryAt=137; { recoveryStack[3]=recoveryLocals[4];  }
                  recoveryAt=138; { dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding42(((java.lang.Object)recoveryStack[0]),((java.lang.Object)recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[3])); }
                  recoveryAt=140; { recoveryPc=150; continue recoveryFlow; }
               }
               case 143 -> {
                  recoveryAt=143; { recoveryStack[1]=-2651532488098329001L; }
                  recoveryAt=144; { recoveryStack[2]=recoveryLocals[4];  }
                  recoveryAt=145; { recoveryStack[0]=dev.zprestige.prestige.renderlib.ManagedGlBuffer.invokeBinding43(((java.lang.Object)recoveryStack[0]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[1]),dev.prestige.recovery.SourceSupport.asLong(recoveryStack[2])); }
                  recoveryAt=146; { throw (Throwable)recoveryStack[0]; }
               }
               case 150 -> {
                  recoveryAt=150; { return; }
               }
               default -> throw new AssertionError(recoveryPc);
            }
         } catch(Throwable recoveryFailure){
            if(recoveryAt>=37 && recoveryAt<54 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=58; continue recoveryFlow;}
            if(recoveryAt>=41 && recoveryAt<92 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=96; continue recoveryFlow;}
            if(recoveryAt>=100 && recoveryAt<139 && recoveryFailure instanceof java.lang.MatchException){recoveryStack[0]=recoveryFailure; recoveryPc=143; continue recoveryFlow;}
            throw dev.prestige.recovery.SourceSupport.rethrow(recoveryFailure);
         }
      }
   }

   @Override
   public void close() {
      Cleanable var3 = this.d;
      var3.clean();
   }

   public int aReturningInt(Object[] var1) {
      return this.b;
   }

   public int bReturningInt(Object[] var1) {
      return this.e;
   }

   public AtomicLong aReturningAtomicLong(Object[] var1) {
      return this.c;
   }

   private static void lambda$new$1(int var0) {
      long var10001 = 107631635443821L ^ 75797896355645L;
      Object[] var5 = new Object[]{invokeBinding44(var0), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var5);
   }

   private static void lambda$new$0(int var0) {
      int var3 = var0;
      GL15.glDeleteBuffers(var3);
   }

   static {

      {

      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(16976392006838L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var17 = new long[9];
      String var15 = "\u00adÐO£Ë)\u008a¤óÍ¸¡B¶ÔùÄ_«o\u0095>§÷A\u008dT\u0082p%\\0¢R÷£\u000fóE*þi¡IA2\u0018ü\u009cg\u009c6\u0006\u0083Ï\u001b";
      int var16 = "\u00adÐO£Ë)\u008a¤óÍ¸¡B¶ÔùÄ_«o\u0095>§÷A\u008dT\u0082p%\\0¢R÷£\u000fóE*þi¡IA2\u0018ü\u009cg\u009c6\u0006\u0083Ï\u001b".length();
      label41:
      while (true) {
         int var10001 = var13;
         var13 += 8;
         byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
         long[] var26 = var17;
         var10001 = var14++;
         long var32 = (var18[0] & 255L) << 56
            | (var18[1] & 255L) << 48
            | (var18[2] & 255L) << 40
            | (var18[3] & 255L) << 32
            | (var18[4] & 255L) << 24
            | (var18[5] & 255L) << 16
            | (var18[6] & 255L) << 8
            | var18[7] & 255L;
         // while (true) {
            long var19 = var32;
            byte[] var21 = var11.doFinal(
               new byte[]{
                  (byte)(var19 >>> 56),
                  (byte)(var19 >>> 48),
                  (byte)(var19 >>> 40),
                  (byte)(var19 >>> 32),
                  (byte)(var19 >>> 24),
                  (byte)(var19 >>> 16),
                  (byte)(var19 >>> 8),
                  (byte)var19
               }
            );
            long var39 = (var21[0] & 255L) << 56
               | (var21[1] & 255L) << 48
               | (var21[2] & 255L) << 40
               | (var21[3] & 255L) << 32
               | (var21[4] & 255L) << 24
               | (var21[5] & 255L) << 16
               | (var21[6] & 255L) << 8
               | var21[7] & 255L;
            switch (var35) {
               case 0:
                  var26[var10001] = var39;
                  if (var13 >= var16) {
                     g = var17;
                     h = new Integer[9];
                     l = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(16976392006838L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     String var4 = "Î{å\u0012\b\bRòg<\u0085\u009aí(à\u0092";
                     int var5 = "Î{å\u0012\b\bRòg<\u0085\u009aí(à\u0092".length();
                     do {
                        int var30 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var30, var2).getBytes("ISO-8859-1");
                        var30 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        var39 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        // var6[var30] = var39;
                     } while (var2 < var5);

                     j = var6;
                     k = new Long[2];
                     Class<ManagedGlBuffer> var24 = ManagedGlBuffer.class;
                     a = LoggerFactory.getLogger(var24);
                     break;
                  }
                  break;
               default:
                  var26[var10001] = var39;
                  if (var13 < var16) {
                     continue label41;
                  }

                  var15 = "F\u0090IÜT \u000f:²\u0019\u008be[þÙ\f";
                  var16 = "F\u0090IÜT \u000f:²\u0019\u008be[þÙ\f".length();
                  var13 = 0;
            }

            int var29 = var13;
            var13 += 8;
            var18 = var15.substring(var29, var13).getBytes("ISO-8859-1");
            var26 = var17;
            var10001 = var14++;
            var32 = (var18[0] & 255L) << 56
               | (var18[1] & 255L) << 48
               | (var18[2] & 255L) << 40
               | (var18[3] & 255L) << 32
               | (var18[4] & 255L) << 24
               | (var18[5] & 255L) << 16
               | (var18[6] & 255L) << 8
               | var18[7] & 255L;
            var35 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32071;
      if (h[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = g[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])i.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bP", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         h[var3] = var15;
      }

      return h[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bP_C0087",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6080;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bP", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bP_C0087",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 59;
            yield var15;
         }
         case 1 -> {
            byte var16 = 46;
            yield var16;
         }
         case 2 -> {
            byte var17 = 40;
            yield var17;
         }
         case 3 -> {
            byte var18 = 18;
            yield var18;
         }
         case 4 -> {
            byte var19 = 55;
            yield var19;
         }
         case 5 -> {
            byte var20 = 21;
            yield var20;
         }
         case 6 -> {
            byte var21 = 6;
            yield var21;
         }
         case 7 -> {
            byte var22 = 42;
            yield var22;
         }
         case 8 -> {
            byte var23 = 45;
            yield var23;
         }
         case 9 -> {
            byte var24 = 27;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 61;
            yield var26;
         }
         case 12 -> {
            byte var27 = 37;
            yield var27;
         }
         case 13 -> {
            byte var28 = 41;
            yield var28;
         }
         case 14 -> {
            byte var29 = 49;
            yield var29;
         }
         case 15 -> {
            byte var30 = 54;
            yield var30;
         }
         case 16 -> {
            byte var31 = 56;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 15;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 26;
            yield var36;
         }
         case 22 -> {
            byte var37 = 17;
            yield var37;
         }
         case 23 -> {
            byte var38 = 36;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 47;
            yield var40;
         }
         case 26 -> {
            byte var41 = 5;
            yield var41;
         }
         case 27 -> {
            byte var42 = 38;
            yield var42;
         }
         case 28 -> {
            byte var43 = 51;
            yield var43;
         }
         case 29 -> {
            byte var44 = 60;
            yield var44;
         }
         case 30 -> {
            byte var45 = 10;
            yield var45;
         }
         case 31 -> {
            byte var46 = 22;
            yield var46;
         }
         case 32 -> {
            byte var47 = 48;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 25;
            yield var49;
         }
         case 35 -> {
            byte var50 = 1;
            yield var50;
         }
         case 36 -> {
            byte var51 = 52;
            yield var51;
         }
         case 37 -> {
            byte var52 = 0;
            yield var52;
         }
         case 38 -> {
            byte var53 = 7;
            yield var53;
         }
         case 39 -> {
            byte var54 = 63;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 39;
            yield var56;
         }
         case 42 -> {
            byte var57 = 30;
            yield var57;
         }
         case 43 -> {
            byte var58 = 28;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 44;
            yield var60;
         }
         case 46 -> {
            byte var61 = 3;
            yield var61;
         }
         case 47 -> {
            byte var62 = 24;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 14;
            yield var64;
         }
         case 50 -> {
            byte var65 = 8;
            yield var65;
         }
         case 51 -> {
            byte var66 = 58;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 11;
            yield var69;
         }
         case 55 -> {
            byte var70 = 34;
            yield var70;
         }
         case 56 -> {
            byte var71 = 35;
            yield var71;
         }
         case 57 -> {
            byte var72 = 33;
            yield var72;
         }
         case 58 -> {
            byte var73 = 20;
            yield var73;
         }
         case 59 -> {
            byte var74 = 2;
            yield var74;
         }
         case 60 -> {
            byte var75 = 9;
            yield var75;
         }
         case 61 -> {
            byte var76 = 12;
            yield var76;
         }
         case 62 -> {
            byte var77 = 43;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      m[0] = "n4il+!k!bl(&d(i.i\u0011Mw;";
      m[1] = int.class;
      n[1] = "java/lang/Integer";
      m[2] = long.class;
      n[2] = "java/lang/Long";
      m[3] = void.class;
      n[3] = "java/lang/Void";
      m[4] = "Zy^\\s\u000fDqD\u0013>\u0015^{]O/\u001f^l\u0006\\)\u0015]qK\u0013\u001c\u000e_uA^\u0011\u0015^\u007f";
      m[5] = "OZA\u0000\u0011#JOJ\u0000\u0012$EFABS\u0013l\u0019\u0017";
      m[6] = "8FZNI\t.F_\u0014Z\u001e9\r\\\u0012V\n(JK\u0005\u001d\u001d6";
      m[7] = "0*Pt>5E\n[{/z$\u0004Pp+ P";
      m[8] = "~]/K\fPuR>\u0004PYr\u0012\u001aFG]zY+";
      m[9] = "Opkk:iD\u007fz$[gOt~~";
      m[10] = "{AKM\u0012OpNZ\u0002nV\u007fN\\NPF";
      m[11] = "4w<yr_?x-6.V88\tt9R0s8<\u001f_;w$y>_;";
      m[12] = "\u001fxR=Fa\u001amY=Ef\u0015dR\u007f\u0004Q<9\u0004";
      m[13] = "hu\u000b\f\u001d,~u\u000eV\u000e;i>\rP\u0002/xy\u001aGI>\\";
      m[14] = "Am|1tY4Mw>e\u0016UC|5aL!";
      m[15] = "Nd\u0019xARXd\u001c\"REO/\u001f$^Q^h\b3\u0015Co";
      m[16] = "/K\u001bP/\u0017$D\n\u001fL\u001a1I\u0005ty\u0018 Z\u0019Xn\u0015";
      m[17] = "g;a\u0005|\u0003d59&+\u0019h\u0018b\u00024\b\u007f";
      m[18] = "p4\r_/[\u0005\u0014\u0006P>\u0014d\u001a\r[:N\u0010";
      m[19] = "dp\u0001~\u0002mae\n~\u0001jnl\u0001<@]G1V";
      m[20] = boolean.class;
      n[20] = "java/lang/Boolean";
      m[21] = "t\f^\u0000\bz}JS\u00007y|\u0019\\\\=wx\nV\\\u0002";
      m[22] = "D\u0018aK!\u0015O\u0017p\u0004L\u0015O\nd";
      m[23] = "i5>q@\u0014`s3q\u007f\u0017a <-";
      m[24] = "z\t}L\u000bMpYou[BWN~\u001bY\\QZl\u001c4\\fQo\u0011W\u0018&V\u0010LK\u001cpJr\r\n\\v3j\u000eVYyP.NQ&'Va\u0013QA-NnD4";
      m[25] = "5(\u0000v\u001aze\"\u0012v+\u007f=W\r1Pp\u001cp\u00114F|\u0013d\u0007\"Fj\u0003p\u000f#F\u0010#b\u000b3Osg\"\fL\u0012oct\u0010.S.#riuT*4`\u000b4\u0015j2\u0019S)Zv<~Y1U!Y";
      m[26] = "\u0016s0\u0000:\t\u001c#\"9j\u0006;(;UO\u001f\u001f'0C\u0005\u0018\n+\"]f\\J,]C~\u0000\u000e->\u0007>\u0007qs8Hc\u0007\u0016y G4b";
      m[27] = "\u000blNKN\u0011\u0017hM\u001b\"C\b)p@MC\b/4ICV\u000ee\u0004YYK\u001aU[HFJ\u001a3\u000fHD\u0011e";
      m[28] = "BE\u0002\u0010\u0018\u001c\u0018F\u000b\u0010aZ\u0015DbF\u001e\u001b\u0015A\u0000\u0007_[\u00138X\u001a\u0010G\u001d_R\u0002\u001f\u0010x";
      m[29] = "1+JVY-o-G\u0011+\u007f\u0000%V\u0003Pv;3\u001d\u0002@\u0014:+W\nNs03X]+";
      m[30] = "\u000bMj\"\u0004\u0010\u000fV<ea@Tyh% IL[j4\u001b/JMg&\u0005L\u000e\r`Y\u001bTRIa:_\u0014U6";
      m[31] = "W%}\t\u0000h\r&t\ty:\u0000$\u001d_\u0006o\u0000!\u007f\u001eG/\u0006X";
      m[32] = "ErKiG.Or\u0014f<.\u0011K\u0012}M\u000b\bn\u001bhF\u001a\bj9l@(uz\u000egC%\u0016>N`<;\u000eb\na_\u007fNeu<C{\u0018y\u0017}\u0002;\u001e\u0000Lz\u0006,\fb\r;F*u9\n?Q8\u0017xK\u007fWAOe\u0004cY&E}\u000b4<";
      m[33] = ".pD\u0000Hx$ V9\u0018w\u00037GW\u001ai\u0005#UPwi2(V]\u0014-r/)R\u001b,w;E\t\u001ctxJSB\u0015l-)\u0017\u0002\u0012\u0013s/X_\u0012ty7W\bw";
      m[34] = "&Ko\u001e$jkK,J\u001bk}^7\u0011\u001b:|B8\u0012|0dMow";
      m[35] = "|l\u0012\u000b\u0000Hv<\u00002PGW;\u001b_CNQ+\u0011\\RY`V\u0005I]\\\u007f5A\tZ#!3\u000eTZD++\u0001\u0003?";
      m[36] = "o \u0004[\"i8<\u001aZHr\u0006\"\rG7}efM@H";
      m[37] = "\u001d\b,/\b\u000bCEygl\u0014!\u001e39\u0017\u0018\u001a\bx8\u0007z\u001b\u001020\t\u001d\u0011\b=gl";
      m[38] = "\u00199\u00199\u007fE\u0013i\u000b\u0000/J1n\u0012J=@\u0010n\u000e{@T\u0005a\u000bd#\u0010Eft";
      m[39] = "GZ\u0014^p|\u0019\\\u0019\u0019\u0002,vU\u001f\u001cd%\u000b]\u0005\u001b>E\u001cX\u0000\u0002b8\u0014B\u0007X\u0002";
      m[40] = "\u0017|p^o\u0005R~sA\u000b\u000eD/rJw\u0019S@-Vo\u001bOzwLl\u001d)\u007f\u007fUq\u0015\u0018z-\u0000wt\u00168\"X4\u001e[8a\f\u000b";
      m[41] = "E\u0011-N\u001e]\u001e\u0016uAoKC\u0018{\u0011\tPH\u0012\u0012\n\u0014SQ\u0019qNTT.";
      m[42] = "/\u0016k(]+\u007f\u001cy(l.'bkj&<-Ioh6(%Ho\u0012\u0016:!XfqRz&';mV,:Ez,\u0016*C\u001e}(\u00018!_<h\u0007A9\\`m\b\"}\u001cg\u0012\u0007-|\u0019s~\\*$\u0016\u0002";
      m[43] = "Zk<{E\u0007P;.B\u0015\bw,?,\u0017\u0016f,;\u000e\u0013\u0010TQ+9\u0018\u0013Y2oy\u001fl\u0004.k/\u0003\u000eEo+)z\u0007Qno3\u0016\\V6`B@\tL74%J\u0011C`Q";
      m[44] = "\\5N<\u0011;Ve\\\u0005A4fiFlV\u001aFaMhTPAtAzJ3\u00054F\u0005CiX`\u001efN1]\u007f#";
      m[45] = "\u0016q]z\nTHwP=x\u0007'\u007fA/\u0003\u000f\u001ci\n.\u0013m\u001dq@&\u001d\n\u0017iOqx";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(678748248853642L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(678748248853642L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(678748248853642L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 239;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 114;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 105;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 77;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 223;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 244;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 239;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 114;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 105;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bP_C0087",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bP" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "lambda$new$1", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding3(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding5(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding7(int var0, Object var1, int var2, long var3, long var5) {
         MethodHandle var11 = bindingCache7;
         MethodHandle var10 = bindingCache7;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache7 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(ILjava/lang/Object;IJJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var8.invokeExact((int)var0, (Object)var1, (int)var2, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding8(int var0, long var1) {
         MethodHandle var7 = bindingCache8;
         MethodHandle var6 = bindingCache8;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache8 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding9(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding10(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache10;
         MethodHandle var8 = bindingCache10;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache10 = c(MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding11(Object var0, long var1, long var3, long var5) {
         MethodHandle var11 = bindingCache11;
         MethodHandle var10 = bindingCache11;
         MethodHandle var8 = var10;
         if (var11 == null) {
            var8 = bindingCache11 = c(MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;JJJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var8.invokeExact((Object)var0, (long)var1, (long)var3, (long)var5);
      } catch (Throwable var12) {
         throw SourceSupport.rethrow(var12);
      }
   }

   private static int invokeBinding12(int var0, long var1) {
         MethodHandle var7 = bindingCache12;
         MethodHandle var6 = bindingCache12;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache12 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding13(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding14(int var0, long var1) {
         MethodHandle var7 = bindingCache14;
         MethodHandle var6 = bindingCache14;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache14 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding15(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding16(int var0, long var1) {
         MethodHandle var7 = bindingCache16;
         MethodHandle var6 = bindingCache16;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache16 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding17(int var0, long var1, Object var3, long var4, long var6) {
         MethodHandle var12 = bindingCache17;
         MethodHandle var11 = bindingCache17;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache17 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IJLjava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var9.invokeExact((int)var0, (long)var1, (Object)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static int invokeBinding18(int var0, long var1) {
         MethodHandle var7 = bindingCache18;
         MethodHandle var6 = bindingCache18;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache18 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding19(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding20(int var0, long var1) {
         MethodHandle var7 = bindingCache20;
         MethodHandle var6 = bindingCache20;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache20 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding21(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache21;
         MethodHandle var8 = bindingCache21;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache21 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding22(int var0, long var1) {
         MethodHandle var7 = bindingCache22;
         MethodHandle var6 = bindingCache22;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache22 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding23(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding24(int var0, long var1) {
         MethodHandle var7 = bindingCache24;
         MethodHandle var6 = bindingCache24;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache24 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding25(int var0, long var1, long var3, long var5, long var7) {
         MethodHandle var13 = bindingCache25;
         MethodHandle var12 = bindingCache25;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache25 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IJJJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var10.invokeExact((int)var0, (long)var1, (long)var3, (long)var5, (long)var7);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static int invokeBinding26(int var0, long var1) {
         MethodHandle var7 = bindingCache26;
         MethodHandle var6 = bindingCache26;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache26 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding27(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache27;
         MethodHandle var9 = bindingCache27;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache27 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding28(int var0, long var1) {
         MethodHandle var7 = bindingCache28;
         MethodHandle var6 = bindingCache28;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache28 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding29(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding30(int var0, long var1) {
         MethodHandle var7 = bindingCache30;
         MethodHandle var6 = bindingCache30;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache30 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding31(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding32(int var0, long var1) {
         MethodHandle var7 = bindingCache32;
         MethodHandle var6 = bindingCache32;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache32 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding33(int var0, long var1) {
         MethodHandle var7 = bindingCache33;
         MethodHandle var6 = bindingCache33;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache33 = a(MethodHandles.lookup(), "y", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding34(int var0, int var1, long var2, long var4, long var6, long var8, long var10) {
         MethodHandle var16 = bindingCache34;
         MethodHandle var15 = bindingCache34;
         MethodHandle var13 = var15;
         if (var16 == null) {
            var13 = bindingCache34 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(IIJJJJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var13.invokeExact((int)var0, (int)var1, (long)var2, (long)var4, (long)var6, (long)var8, (long)var10);
      } catch (Throwable var17) {
         throw SourceSupport.rethrow(var17);
      }
   }

   private static int invokeBinding35(long var0, long var2) {
         MethodHandle var8 = bindingCache35;
         MethodHandle var7 = bindingCache35;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache35 = c(MethodHandles.lookup(), "ô", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static int invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = c(MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding37(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache37;
         MethodHandle var8 = bindingCache37;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache37 = c(MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;JJ)J", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (long)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MatchException invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = c(
                  MethodHandles.lookup(), "ô", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = c(
                  MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = c(
                  MethodHandles.lookup(), "ô", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static long invokeBinding41(int var0, long var1) {
         MethodHandle var7 = bindingCache41;
         MethodHandle var6 = bindingCache41;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache41 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding42(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache42;
         MethodHandle var9 = bindingCache42;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache42 = c(
                  MethodHandles.lookup(), "ß", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MatchException invokeBinding43(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = c(
                  MethodHandles.lookup(), "ô", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/MatchException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MatchException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Runnable invokeBinding44(int var0) {
         MethodHandle var5 = bindingCache44;
         MethodHandle var4 = bindingCache44;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache44 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "lambda$new$0", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
