package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL30;

public class ManagedGlFramebuffer implements AutoCloseable {
   public final int a;
   private final Cleanable b;
   private static final long c = 80752397857952L;
   private static final String d;
   private static final long[] e;
   private static final Integer[] f;
   private static final Map g;
   private static final Object[] h = new Object[29];
   private static final String[] i = new String[29];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;

   public ManagedGlFramebuffer(int var1, long var2) {
      super();
      long var10000 = 80752397857952L ^ var2;

      this.a = var1;
      Cleaner var10001 = RenderThreadUtil.a;
      Runnable var6 = invokeBinding1(var1);
      ManagedGlFramebuffer var5 = this;
      Cleaner var4 = var10001;
      this.b = var4.register(var5, var6);
   }

   public static ManagedGlFramebuffer aReturningbR_C0091(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 80752397857952L ^ var1;
      long var3 = var1 ^ 97231410328056L;
      return new ManagedGlFramebuffer(GL30.glGenFramebuffers(), var3);
   }

   public void aReturningVoid(Object[] var1) {
      int var3 = (Integer)var1[0];
      int var2 = (Integer)var1[1];
      long var4 = (Long)var1[2];
      var4 = 80752397857952L ^ var4;
      short var10000 = 5781;
      long var10001 = 5543198402818859721L ^ var4;
      int var6 = GL11.glGetInteger(36006);
      var10000 = 32374;
      var10001 = 412678043158514213L ^ var4;
      char var19 = '赀';
      int var9 = this.a;
      GL30.glBindFramebuffer(36160, var9);
      var10000 = 32374;
      var10001 = 412678043158514213L ^ var4;
      char var21 = '赀';
      short var10002 = 1355;
      long var10003 = 5247876077200961809L ^ var4;
      var10002 = 3553;
      int var13 = var2;
      int var11 = var3;
      GL30.glFramebufferTexture2D(36160, var11, 3553, var13, 0);
      var10000 = 32374;
      var10001 = 412678043158514213L ^ var4;
      char var23 = '赀';
      int var16 = var6;
      GL30.glBindFramebuffer(36160, var16);
   }

   public void bReturningVoid(Object[] var1) {
      int var5 = (Integer)var1[0];
      ManagedGlTexture var4 = (ManagedGlTexture)var1[1];
      long var2 = (Long)var1[2];
      var2 = 80752397857952L ^ var2;
      long var6 = var2 ^ 112562757169712L;
      int var10002 = var4.a;
      Object[] var10005 = new Object[]{null, null, var6};
      var10005[1] = var10002;
      var10005[0] = var5;
      Object[] var9 = var10005;
      ManagedGlFramebuffer var8 = this;
      var8.aReturningVoid(var9);
   }

   public void cReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 80752397857952L ^ var2;
      int var4 = invokeBinding3(invokeBinding2(5781, 5543095296394088572L ^ var2), -3511895155450847296L, var2);
      invokeBinding5(invokeBinding4(14715, 4255784444459909011L ^ var2), this.a, -3512152778549927351L, var2);
      int var5 = invokeBinding7(invokeBinding6(32374, 412715054872639632L ^ var2), -3512398421564931058L, var2);

      try {
         invokeBinding9(invokeBinding8(32374, 412715054872639632L ^ var2), var4, -3512152778549927351L, var2);
         int var8 = invokeBinding10(16238, 6349393354001938819L ^ var2);
         int var7 = var5;
         if (var7 != var8) {
            throw new IllegalStateException(d + var5);
         }
      } catch (IllegalStateException var9) {
         throw invokeBinding11(var9, -3512782269790781404L, var2);
      }
   }

   public void dReturningVoid(Object[] var1) {
      int var9 = (Integer)var1[0];
      int var7 = (Integer)var1[1];
      int var5 = (Integer)var1[2];
      int var13 = (Integer)var1[3];
      int var14 = (Integer)var1[4];
      int var3 = (Integer)var1[5];
      int var4 = (Integer)var1[6];
      int var10 = (Integer)var1[7];
      int var8 = (Integer)var1[8];
      int var6 = (Integer)var1[9];
      int var2 = (Integer)var1[10];
      long var11 = (Long)var1[11];
      var11 = 80752397857952L ^ var11;
      int var15 = invokeBinding13(invokeBinding12(21893, 703979366582812016L ^ var11), -6821741819851066921L, var11);
      int var16 = invokeBinding15(invokeBinding14(5781, 5543218443228233323L ^ var11), -6821741819851066921L, var11);
      invokeBinding17(invokeBinding16(16704, 6327877150128662971L ^ var11), this.a, -6821506872074892194L, var11);
      invokeBinding19(invokeBinding18(18107, 3745130746419932745L ^ var11), var9, -6821506872074892194L, var11);
      invokeBinding20(var7, var5, var7 + var13, var5 + var14, var3, var4, var3 + var10, var4 + var8, var6, var2, -6821092493621623834L, var11);
      invokeBinding22(invokeBinding21(32748, 6209542688113743632L ^ var11), var15, -6821506872074892194L, var11);
      invokeBinding24(invokeBinding23(18107, 3745130746419932745L ^ var11), var16, -6821506872074892194L, var11);
   }

   public void eReturningVoid(Object[] var1) {
      float var2 = (Float)var1[0];
      float var7 = (Float)var1[1];
      float var4 = (Float)var1[2];
      float var3 = (Float)var1[3];
      long var5 = (Long)var1[4];
      var5 = 80752397857952L ^ var5;
      short var10000 = 5781;
      long var10001 = 5543147252708181283L ^ var5;
      int var8 = GL11.glGetInteger(36006);
      var10000 = 18107;
      var10001 = 3745060105915815169L ^ var5;
      char var19 = '販';
      int var11 = this.a;
      GL30.glBindFramebuffer(36009, var11);
      var10000 = 26908;
      var10001 = 103636888387254948L ^ var5;
      var10000 = 6144;
      byte var26 = 0;
      float[] var14 = new float[]{var2, var7, var4, var3};
      GL30.glClearBufferfv(6144, 0, var14);
      var10000 = 18107;
      var10001 = 3745060105915815169L ^ var5;
      char var23 = '販';
      int var16 = var8;
      GL30.glBindFramebuffer(36009, var16);
   }

   public void fReturningVoid(Object[] var1) {
      float var5 = (Float)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      var3 = 80752397857952L ^ var3;
      int var6 = invokeBinding26(invokeBinding25(14594, 1717925340185375309L ^ var3), -9015512083840986527L, var3);
      invokeBinding28(invokeBinding27(21246, 8313656105424902581L ^ var3), this.a, -9015333614348128280L, var3);
      invokeBinding30(invokeBinding29(29172, 8896888119739447985L ^ var3), 0, var5, var2, -9015253449086777608L, var3);
      invokeBinding32(invokeBinding31(18107, 3745124491206053375L ^ var3), var6, -9015333614348128280L, var3);
   }

   @Override
   public void close() throws Exception {
      Cleanable var3 = this.b;
      var3.clean();
   }

   private static void lambda$new$1(int var0) {
      long var10001 = 95127923375943L ^ 127093750812695L;
      Object[] var5 = new Object[]{invokeBinding33(var0), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var5);
   }

   private static void lambda$new$0(int var0) {
      int var3 = var0;
      GL30.glDeleteFramebuffers(var3);
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(114102111857220L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var15 = var13.doFinal("¢y¡O(\u008cyÝõLk]#ºd?\u0080 ^b\u009fTC@`_?\u001bqþÙñÝ@üQN\u0083N\u009e".getBytes("ISO-8859-1"));
      String var22 = a(var15).intern();
      int var10001 = -1;
      d = var22;
      g = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(114102111857220L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[13];
      String var4 = "\u009f¢\u001då\u008eð\u0082\u0012\"\u00102\u0084\u0007¸?Èlí\u0014)ö{XLþú\u0090\u0001§\\\u00844ºîgpéÑ'\u0019=&\u0099IÇpÿÓÿ4¦ÀM\u009dè|ï\u000e\b¯Ö\u0007\u0083}\u0090Õ\u0092ã\u008dºðM²à2Û\n6wr:vJ\u0003õJv\u0015";
      int var5 = "\u009f¢\u001då\u008eð\u0082\u0012\"\u00102\u0084\u0007¸?Èlí\u0014)ö{XLþú\u0090\u0001§\\\u00844ºîgpéÑ'\u0019=&\u0099IÇpÿÓÿ4¦ÀM\u009dè|ï\u000e\b¯Ö\u0007\u0083}\u0090Õ\u0092ã\u008dºðM²à2Û\n6wr:vJ\u0003õJv\u0015"
         .length();
      label29:
      while (true) {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var18 = var6;
         var10001 = var3++;
         long var24 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         // while (true) {
            long var8 = var24;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var29 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var27) {
               case 0:
                  var18[var10001] = var29;
                  if (var2 >= var5) {
                     e = var6;
                     f = new Integer[13];
                     break;
                  }
                  break;
               default:
                  var18[var10001] = var29;
                  if (var2 < var5) {
                     continue label29;
                  }

                  var4 = "L\u0019¾6¢c8¥\u0097¸N0\u0016bÄ\u0004";
                  var5 = "L\u0019¾6¢c8¥\u0097¸N0\u0016bÄ\u0004".length();
                  var2 = 0;
            }

            int var21 = var2;
            var2 += 8;
            var7 = var4.substring(var21, var2).getBytes("ISO-8859-1");
            var18 = var6;
            var10001 = var3++;
            var24 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var27 = 0;
         }
      }
   
      }

      
}

   private static IllegalStateException a(IllegalStateException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2473;
      if (f[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = e[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])g.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bR", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         f[var3] = var15;
      }

      return f[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bR_C0091",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = i[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = h[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 43;
            yield var15;
         }
         case 1 -> {
            byte var16 = 13;
            yield var16;
         }
         case 2 -> {
            byte var17 = 57;
            yield var17;
         }
         case 3 -> {
            byte var18 = 60;
            yield var18;
         }
         case 4 -> {
            byte var19 = 47;
            yield var19;
         }
         case 5 -> {
            byte var20 = 49;
            yield var20;
         }
         case 6 -> {
            byte var21 = 26;
            yield var21;
         }
         case 7 -> {
            byte var22 = 28;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 14;
            yield var24;
         }
         case 10 -> {
            byte var25 = 24;
            yield var25;
         }
         case 11 -> {
            byte var26 = 12;
            yield var26;
         }
         case 12 -> {
            byte var27 = 6;
            yield var27;
         }
         case 13 -> {
            byte var28 = 56;
            yield var28;
         }
         case 14 -> {
            byte var29 = 5;
            yield var29;
         }
         case 15 -> {
            byte var30 = 35;
            yield var30;
         }
         case 16 -> {
            byte var31 = 36;
            yield var31;
         }
         case 17 -> {
            byte var32 = 22;
            yield var32;
         }
         case 18 -> {
            byte var33 = 59;
            yield var33;
         }
         case 19 -> {
            byte var34 = 32;
            yield var34;
         }
         case 20 -> {
            byte var35 = 15;
            yield var35;
         }
         case 21 -> {
            byte var36 = 25;
            yield var36;
         }
         case 22 -> {
            byte var37 = 20;
            yield var37;
         }
         case 23 -> {
            byte var38 = 38;
            yield var38;
         }
         case 24 -> {
            byte var39 = 45;
            yield var39;
         }
         case 25 -> {
            byte var40 = 61;
            yield var40;
         }
         case 26 -> {
            byte var41 = 1;
            yield var41;
         }
         case 27 -> {
            byte var42 = 46;
            yield var42;
         }
         case 28 -> {
            byte var43 = 9;
            yield var43;
         }
         case 29 -> {
            byte var44 = 55;
            yield var44;
         }
         case 30 -> {
            byte var45 = 39;
            yield var45;
         }
         case 31 -> {
            byte var46 = 33;
            yield var46;
         }
         case 32 -> {
            byte var47 = 63;
            yield var47;
         }
         case 33 -> {
            byte var48 = 29;
            yield var48;
         }
         case 34 -> {
            byte var49 = 10;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 16;
            yield var51;
         }
         case 37 -> {
            byte var52 = 41;
            yield var52;
         }
         case 38 -> {
            byte var53 = 27;
            yield var53;
         }
         case 39 -> {
            byte var54 = 37;
            yield var54;
         }
         case 40 -> {
            byte var55 = 50;
            yield var55;
         }
         case 41 -> {
            byte var56 = 4;
            yield var56;
         }
         case 42 -> {
            byte var57 = 18;
            yield var57;
         }
         case 43 -> {
            byte var58 = 21;
            yield var58;
         }
         case 44 -> {
            byte var59 = 34;
            yield var59;
         }
         case 45 -> {
            byte var60 = 48;
            yield var60;
         }
         case 46 -> {
            byte var61 = 62;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 44;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 19;
            yield var65;
         }
         case 51 -> {
            byte var66 = 54;
            yield var66;
         }
         case 52 -> {
            byte var67 = 2;
            yield var67;
         }
         case 53 -> {
            byte var68 = 11;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 3;
            yield var70;
         }
         case 56 -> {
            byte var71 = 40;
            yield var71;
         }
         case 57 -> {
            byte var72 = 53;
            yield var72;
         }
         case 58 -> {
            byte var73 = 58;
            yield var73;
         }
         case 59 -> {
            byte var74 = 30;
            yield var74;
         }
         case 60 -> {
            byte var75 = 42;
            yield var75;
         }
         case 61 -> {
            byte var76 = 0;
            yield var76;
         }
         case 62 -> {
            byte var77 = 23;
            yield var77;
         }
         default -> 51;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            i[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      h[0] = "%!K \u0007\u00143!Nz\u0014\u0003$jM|\u0018\u00175-ZkS\u0006\u0013";
      h[1] = "@\u0014/IK\n54$FZET:/M^\u001f ";
      h[2] = void.class;
      i[2] = "java/lang/Void";
      h[3] = "\u0016f\u000fPI\u0000\u0013s\u0004PJ\u0007\u001cz\u000f\u0012\u000b05'X";
      h[4] = int.class;
      i[4] = "java/lang/Integer";
      h[5] = "?z&7\"R4u7x~[35\u0013:i_;~\"";
      h[6] = "\b}\u0006W)\u0006\u0003r\u0017\u0018H\b\by\u0013B";
      h[7] = "]gW)m\u0018VhFf\u0011\u0001Yh@*/\u0011";
      h[8] = "o5esgLd:t<;EczP~,Ak1a6\nL`5}s+L`";
      h[9] = "\u0018q\u0010-\u000e#\u001dd\u001b-\r$\u0012m\u0010oL\u0013;2F";
      h[10] = float.class;
      i[10] = "java/lang/Float";
      h[11] = "\bH\t<hK\u001eH\ff{\\\t\u0003\u000f`wH\u0018D\u0018w<_\u0006";
      h[12] = "yO\u000f\u0005m\u0010\fo\u0004\n|_ma\u000f\u0001x\u0005\u0019";
      h[13] = "\u0013\u0011\u000b%\"{\u0018\u001e\u001ajE{\u0015\u0015\u001a%`D\r\u0011\t!Io\u001a\u0015\r0ex\u0017";
      h[14] = "\u0015\u001a";
      h[15] = "L\u001br^^\u0004\n\u0012a\u000e.\u0004\u0012=|U`\u0011\u001f\u0017|YS\u0005\u0018\u001fkH.Q\t\u001caX@S\u001aOs3";
      h[16] = "y%*>G\u0017!,yhv\u0003#\u000e*%7\n;,(4\fl}>))\u001d\u0002\u007f-z;vV8/72\u0018T+|%Y";
      h[17] = "cq6tlG58 w\u000fU:l#p\u000f\u0004f:sqa\u0002>ju\u0016";
      h[18] = "< F\u001aaPz)UJ\u0011Pb\u0005H\u0013|Ck\u0007_\u001etRl4K\u0019|E}I\u001f\b\u007fOm'\u001d\u001b,]\u0006s\u001dL(XhuE\u001c.?";
      h[19] = "\t\n).\u0000~X\u001f6-kv6_)+Z$JR??\u0000\u0018\fWuv\fv\n\u000f%pk";
      h[20] = "p\u0014Jf\ba6\u001dY6xa.6Mf\u0011t\u0000\u0000Ge\u0015t$\u001c)1\u0007`:\u0016G3\u00143(}\u0013t\u0016~!\u0013\u0011gElJBD3G\u007f-\rId\u0003\u000ep\u0002G{\u0013`r\u0011\u0014ix4rF\u0010l\u00162*\u0016\u0016\u000b";
      h[21] = "\u001b\rRZ3\u0018]\u0004A\nC\u0018E.PQ/9[\rTZ)\nO\n\\MCM^\nA\\-OMYS7y\bO\u0014ZY{\u001b\u001c\u00061\r{L\u0018\u0003_\u000b#\u001c\u001ed";
      h[22] = "!pV\tb\te5_^\u0005BwbEOyU`\r\u0018\u0004\u007fDgq\u001d\beJ\u001a0DXy\\}n\u001fEg8'}XVfAq4NU\u0005";
      h[23] = "~i=3*38`.cZ3 K:33&\u000e}007&*~^d%24k0f6a&\u0000d!4,/nf2g>Di4f:3!n;gg\\~8eg=2x`5aZ";
      h[24] = "6\u0003#\t\rjp\n0Y}jh$:\r\u0018hf\u0017.\n\u0010\u007fP\u00070\u0018\u0000\u007faP\fdGzb\u001a+\nEi1\b@^\u0002k|\u0001.\\\u00118njz\u001b\u0013ug\u0004x\b@g\fP?\n\rnbR,Y\u001f\u00056\u0015.\u0014\u0016k4\u0006}\u0006}?4Qy\u0003\u00139l\u0001\u007fd";
      h[25] = "&Y \f'u`P3\\Wux{#\f<yRJ*\u0004:pa^-\f-A`Y?\u001c,\u001a&O-\u0011<t$\\~\u0003W c^3\n9\"p\r!a";
      h[26] = "`\u0007l>1\u007fqT!N$\u0013;Yy\u007fqo6Om%M)3\u0005$)#/kU\"N";
      h[27] = "\f<E3_\u007fJ5Vc/\u007fR\u001fB?S^L<C3EmX;K$/*I;V5A(ZhD^\u0015oX%M0\u0017|\u000b7&dP~F>HfC-TU\u001c!A`];\u001e2\u0012r6oY0_{XmJcM\u0010\f*H.D~\u000e9\u001b</*I;V5A(ZhD^\u0015oX%M0\u0017|\u000b7&dP~F>HfC-TU\u001c!A`];\u001e2\u0012r6o\u001ee\u0016wXiF5\u0010\u0010";
      h[28] = "\u00145s\u0010\u0019V\u0005f>`\f:Nli\u0019\u0007X\u0015~h\u001be\u000b\u001fg{\u0002\u0007P\rfy`";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = h[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(i[var4]);
            h[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            h[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  h[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(430989527798279L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = h[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = i[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  h[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(430989527798279L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        h[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(430989527798279L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 68;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 221;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 120;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 78;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 186;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 84;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 68;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 221;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 120;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bR_C0091",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bR" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bR_C0091", "lambda$new$1", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding3(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding5(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding7(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding8(int var0, long var1) {
         MethodHandle var7 = bindingCache8;
         MethodHandle var6 = bindingCache8;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache8 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding9(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static IllegalStateException invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = b(
                  MethodHandles.lookup(), "T", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/IllegalStateException;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (IllegalStateException)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding12(int var0, long var1) {
         MethodHandle var7 = bindingCache12;
         MethodHandle var6 = bindingCache12;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache12 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding13(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding14(int var0, long var1) {
         MethodHandle var7 = bindingCache14;
         MethodHandle var6 = bindingCache14;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache14 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding15(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding16(int var0, long var1) {
         MethodHandle var7 = bindingCache16;
         MethodHandle var6 = bindingCache16;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache16 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding17(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache17;
         MethodHandle var9 = bindingCache17;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache17 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding18(int var0, long var1) {
         MethodHandle var7 = bindingCache18;
         MethodHandle var6 = bindingCache18;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache18 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding19(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding20(
      int var0, int var1, int var2, int var3, int var4, int var5, int var6, int var7, int var8, int var9, long var10, long var12
   ) {
         MethodHandle var18 = bindingCache20;
         MethodHandle var17 = bindingCache20;
         MethodHandle var15 = var17;
         if (var18 == null) {
            var15 = bindingCache20 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIIIIIIIIIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var15.invokeExact((int)var0, (int)var1, (int)var2, (int)var3, (int)var4, (int)var5, (int)var6, (int)var7, (int)var8, (int)var9, (long)var10, (long)var12);
      } catch (Throwable var19) {
         throw SourceSupport.rethrow(var19);
      }
   }

   private static int invokeBinding21(int var0, long var1) {
         MethodHandle var7 = bindingCache21;
         MethodHandle var6 = bindingCache21;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache21 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding22(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding23(int var0, long var1) {
         MethodHandle var7 = bindingCache23;
         MethodHandle var6 = bindingCache23;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache23 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding24(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding25(int var0, long var1) {
         MethodHandle var7 = bindingCache25;
         MethodHandle var6 = bindingCache25;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache25 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding26(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache26;
         MethodHandle var8 = bindingCache26;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache26 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IJJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding27(int var0, long var1) {
         MethodHandle var7 = bindingCache27;
         MethodHandle var6 = bindingCache27;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache27 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding28(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding29(int var0, long var1) {
         MethodHandle var7 = bindingCache29;
         MethodHandle var6 = bindingCache29;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache29 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding30(int var0, int var1, float var2, int var3, long var4, long var6) {
         MethodHandle var12 = bindingCache30;
         MethodHandle var11 = bindingCache30;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache30 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIFIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var9.invokeExact((int)var0, (int)var1, (float)var2, (int)var3, (long)var4, (long)var6);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static int invokeBinding31(int var0, long var1) {
         MethodHandle var7 = bindingCache31;
         MethodHandle var6 = bindingCache31;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache31 = a(MethodHandles.lookup(), "u", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding32(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache32;
         MethodHandle var9 = bindingCache32;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache32 = b(MethodHandles.lookup(), "T", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Runnable invokeBinding33(int var0) {
         MethodHandle var5 = bindingCache33;
         MethodHandle var4 = bindingCache33;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache33 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bR_C0091", "lambda$new$0", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
