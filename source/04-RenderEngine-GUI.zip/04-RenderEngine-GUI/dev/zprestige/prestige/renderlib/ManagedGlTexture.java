package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.ref.Cleaner.Cleanable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.texture.TextureManager;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL11;

public class ManagedGlTexture implements AutoCloseable {
   public final int a;
   private final Cleanable b;
   private final int c;
   private volatile boolean d;
   private int e;
   private static final long f = 39270590053797L;
   private static final String[] g;
   private static final String[] h;
   private static final Map i = new HashMap(13);
   private static final long[] j;
   private static final Integer[] k;
   private static final Map l;
   private static final Object[] m = new Object[51];
   private static final String[] n = new String[51];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;

   public ManagedGlTexture(int var1, int var2, long var3) {
      this(var1, var2, true, ((39270590053797L ^ (39270590053797L ^ var3)) ^ 119307919490672L));
      var3 = 39270590053797L ^ var3;
      long var5 = var3 ^ 119307919490672L;

   }

   private ManagedGlTexture(int var1, int var2, boolean var3, long var4) {
      super();
      long var10000 = 39270590053797L ^ var4;

      this.d = dev.prestige.recovery.SourceSupport.asBoolean(0);
      this.c = var1;
      this.a = var2;
      boolean var14 = var3;
      ManagedGlTexture var13 = this;
      ManagedGlTexture var10 = var13;
      ManagedGlTexture var9 = var13;
      ManagedGlTexture var11;
      Cleanable var12;
      if (var14) {
         Cleaner var10001 = RenderThreadUtil.a;
         Runnable var8 = invokeBinding1(var2);
         ManagedGlTexture var7 = this;
         Cleaner var6 = var10001;
         Cleanable var16 = var6.register(var7, var8);
         ManagedGlTexture var15 = var9;
         var11 = var15;
         var12 = var16;
      } else {
         var12 = null;
         var11 = var10;
      }

      this.b = var12;
   }

   public static ManagedGlTexture aReturningbT_C0095(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 39270590053797L ^ var2;
      long var4 = var2 ^ 100202652812773L;
      return new ManagedGlTexture(var1, GL11.glGenTextures(), var4);
   }

   public static ManagedGlTexture bReturningbT_C0095(Object[] var0) {
      int var1 = (Integer)var0[0];
      int var4 = (Integer)var0[1];
      long var2 = (Long)var0[2];
      var2 = 39270590053797L ^ var2;
      long var5 = var2 ^ 127767094035344L;
      return new ManagedGlTexture(var1, var4, false, var5);
   }

   private int aReturningInt(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 39270590053797L ^ var3;
      int var5 = Event.cReturningInt();
      int var9 = var5;
      int var8 = var2;
      int var7 = var8;
      int var6 = var8;
      if (var9 != 0) {
         int var10 = var6;
         switch (var10) {
            case 3553:
               short var13 = 11201;
               long var15 = 2249000423509067768L ^ var3;
               return 32873;
            case 32879:
               short var12 = 25496;
               long var14 = 2469855970718633900L ^ var3;
               return 32874;
            default:
               short var10000 = 15205;
               long var10001 = 1577968256720312146L ^ var3;
               var7 = 32873;
         }
      }

      return var7;
   }

   private int bReturningInt(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 39270590053797L ^ var2;
      long var4 = var2 ^ 129393917456590L;
      int var10001 = this.c;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var8 = var10004;
      ManagedGlTexture var7 = this;
      int var9 = var7.aReturningInt(var8);
      int var6 = GL11.glGetInteger(var9);
      int var11 = this.a;
      int var10 = this.c;
      GL11.glBindTexture(var10, var11);
      return var6;
   }

   private void aReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 39270590053797L ^ var2;
      int var6 = var4;
      int var5 = this.c;
      GL11.glBindTexture(var5, var6);
   }

   public void bReturningVoid(Object[] var1) {
      int var2 = (Integer)var1[0];
      long var3 = (Long)var1[1];
      var3 = 39270590053797L ^ var3;
      long var5 = var3 ^ 134951260703205L;
      long var7 = var3 ^ 53950207044511L;
      Object[] var11 = new Object[]{var7};
      ManagedGlTexture var10 = this;
      int var9 = var10.bReturningInt(var11);
      short var10001 = 21213;
      long var10002 = 5354305381380662708L ^ var3;
      var10001 = 10241;
      int var14 = var2;
      int var12 = this.c;
      GL11.glTexParameteri(var12, 10241, var14);
      var10001 = 5228;
      var10002 = 3195126226828321551L ^ var3;
      var10001 = 10240;
      int var17 = var2;
      int var15 = this.c;
      GL11.glTexParameteri(var15, 10240, var17);
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var9;
      Object[] var19 = var10004;
      ManagedGlTexture var18 = this;
      var18.aReturningVoid(var19);
   }

   public void cReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      int var6 = (Integer)var1[1];
      int var5 = (Integer)var1[2];
      long var2 = (Long)var1[3];
      var2 = 39270590053797L ^ var2;
      long var7 = var2 ^ 82914469660827L;
      long var9 = var2 ^ 844172569313L;
      int var11 = Event.bReturningInt();
      int var42 = var11;
      byte var41 = ((byte)((this.d) ? 1 : 0));
      int var38 = var41;
      byte var37 = var41;
      if (var42 == 0) {
         byte var43 = var37;
         if (var43 != 0) {
            short var62 = 20607;
            long var10003 = 6456649542728077124L ^ var2;
            throw new IllegalStateException("already inited - this is an immutable texture!");
         }

         this.d = dev.prestige.recovery.SourceSupport.asBoolean(1);
         this.e = var4;
         var38 = var4;
      }

      int var12;
      label26: {
         int var45 = var11;
         int var44 = var38;
         int var40 = var44;
         int var39 = var44;
         if (var45 == 0) {
            int var46 = var39;
            switch (var46) {
               case 33321:
                  short var10000 = 27722;
                  long var10001 = 3935384555124628063L ^ var2;
                  var12 = 6403;
                  int var47 = var11;
                  if (var47 == 0) {
                     break label26;
                  }
               case 33323:
                  short var52 = 24875;
                  long var55 = 8352739890409740081L ^ var2;
                  var12 = 33319;
                  int var48 = var11;
                  if (var48 == 0) {
                     break label26;
                  }
               case 32849:
                  short var53 = 23358;
                  long var56 = 3933700320804252960L ^ var2;
                  var12 = 6407;
                  int var49 = var11;
                  if (var49 == 0) {
                     break label26;
                  }
               case 32856:
               default:
                  short var54 = 5814;
                  long var57 = 6437612238197448870L ^ var2;
                  short var50 = 6408;
                  var40 = var50;
            }
         }

         var12 = var40;
      }

      Object[] var19 = new Object[]{var9};
      ManagedGlTexture var18 = this;
      int var13 = var18.bReturningInt(var19);
      short var58 = 0;
      byte var10005 = 0;
      short var10007 = 28060;
      long var10008 = 1897655600848739214L ^ var2;
      var10007 = 5121;
      ByteBuffer var28 = (ByteBuffer)null;
      int var26 = var12;
      int var24 = var5;
      int var23 = var6;
      int var22 = var4;
      int var20 = this.c;
      GL11.glTexImage2D(var20, 0, var22, var23, var24, 0, var26, 5121, var28);
      var58 = 19522;
      long var10002 = 4298118977273018947L ^ var2;
      int var29 = this.c;
      GL11.glTexParameteri(var29, 33084, 0);
      var58 = 18939;
      var10002 = 8264751678112219108L ^ var2;
      int var32 = this.c;
      GL11.glTexParameteri(var32, 33085, 0);
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = var13;
      Object[] var36 = var10004;
      ManagedGlTexture var35 = this;
      var35.aReturningVoid(var36);
   }

   public void dReturningVoid(Object[] var1) {
      int var8 = (Integer)var1[0];
      int var3 = (Integer)var1[1];
      int var2 = (Integer)var1[2];
      int var10 = (Integer)var1[3];
      int var5 = (Integer)var1[4];
      int var9 = (Integer)var1[5];
      ByteBuffer var4 = (ByteBuffer)var1[6];
      long var6 = (Long)var1[7];
      var6 = 39270590053797L ^ var6;
      long var11 = var6 ^ 47439460418241L;
      long var13 = var6 ^ 106140842467515L;
      Object[] var17 = new Object[]{var13};
      ManagedGlTexture var16 = this;
      int var15 = var16.bReturningInt(var17);
      byte var10001 = 0;
      ByteBuffer var26 = var4;
      int var25 = var9;
      int var24 = var5;
      int var23 = var10;
      int var22 = var2;
      int var21 = var3;
      int var20 = var8;
      int var18 = this.c;
      GL11.glTexSubImage2D(var18, 0, var20, var21, var22, var23, var24, var25, var26);
      Object[] var10004 = new Object[]{null, var11};
      var10004[0] = var15;
      Object[] var28 = var10004;
      ManagedGlTexture var27 = this;
      var27.aReturningVoid(var28);
   }

   public void eReturningVoid(Object[] var1) {
      int var4 = (Integer)var1[0];
      long var2 = (Long)var1[1];
      var2 = 39270590053797L ^ var2;
      long var5 = var2 ^ 102576915136805L;
      long var7 = var2 ^ 25179372594015L;
      Object[] var11 = new Object[]{var7};
      ManagedGlTexture var10 = this;
      int var9 = var10.bReturningInt(var11);
      short var10001 = 20206;
      long var10002 = 877089428806676812L ^ var2;
      var10001 = 10242;
      int var14 = var4;
      int var12 = this.c;
      GL11.glTexParameteri(var12, 10242, var14);
      var10001 = 5668;
      var10002 = 7371924641665771918L ^ var2;
      var10001 = 10243;
      int var17 = var4;
      int var15 = this.c;
      GL11.glTexParameteri(var15, 10243, var17);
      Object[] var10004 = new Object[]{null, var5};
      var10004[0] = var9;
      Object[] var19 = var10004;
      ManagedGlTexture var18 = this;
      var18.aReturningVoid(var19);
   }

   public void fReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 39270590053797L ^ var2;
      invokeBinding3(invokeBinding2(6868, 8356045349239578679L ^ var2), -1348037236522398267L, var2);
      invokeBinding5(invokeBinding4(15857, 1718521303144810256L ^ var2), this.a, -1348209575454453717L, var2);
   }

   public ManagedGlTexture cReturningbT_C0095(Object[] var1) {
      int var5 = (Integer)var1[0];
      int var4 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      var2 = 39270590053797L ^ var2;
      long var6 = var2 ^ 49522768462790L;
      long var8 = var2 ^ 60512277836735L;
      int var10 = Event.bReturningInt();
      int var21 = var10;
      byte var20 = ((byte)((this.d) ? 1 : 0));
      int var19 = var20;
      byte var18 = var20;
      if (var21 == 0) {
         byte var22 = var18;
         if (var22 == 0) {
            short var10002 = 4547;
            long var24 = 5481542951141617818L ^ var2;
            throw new IllegalStateException("not inited");
         }

         ManagedGlTexture var14 = this;
         var14.close();
         var19 = this.c;
      }

      Object[] var10003 = new Object[]{null, var8};
      var10003[0] = var19;
      Object[] var15 = var10003;
      ManagedGlTexture var11 = aReturningbT_C0095(var15);
      int var10001 = this.e;
      Object[] var10006 = new Object[]{null, null, null, var6};
      var10006[2] = var4;
      var10006[1] = var5;
      var10006[0] = var10001;
      Object[] var17 = var10006;
      ManagedGlTexture var16 = var11;
      var16.cReturningVoid(var17);
      return var11;
   }

   @Override
   public void close() {
      int var3 = Event.bReturningInt();
      int var10 = var3;
      Cleanable var9 = this.b;
      Cleanable var8 = var9;
      Cleanable var7 = var9;
      if (var10 == 0) {
         Cleanable var11 = var7;
         if (var11 == null) {
            return;
         }

         Cleanable var12 = this.b;
         var8 = var12;
      }

      Cleanable var6 = var8;
      var6.clean();
   }

   public static ManagedGlTexture dReturningbT_C0095(Object[] var0) {
      Identifier var1 = (Identifier)var0[0];
      long var2 = (Long)var0[1];
      var2 = 39270590053797L ^ var2;
      long var4 = var2 ^ 112031041219754L;
      MinecraftClient var7 = MinecraftAccess.b;
      TextureManager var10000 = var7.getTextureManager();
      Identifier var9 = var1;
      TextureManager var8 = var10000;
      AbstractTexture var10 = var8.getTexture(var9);
      GlTexture var11 = (GlTexture)var10.getGlTexture();
      int var6 = var11.getGlId();
      short var14 = 16106;
      long var10001 = 8004693630928120869L ^ var2;
      Object[] var10004 = new Object[]{null, null, var4};
      var10004[1] = var6;
      var10004[0] = 3553;
      Object[] var12 = var10004;
      return bReturningbT_C0095(var12);
   }

   private static void lambda$new$1(int var0) {
      long var10001 = 121480647079719L ^ 82942413674615L;
      Object[] var5 = new Object[]{invokeBinding6(var0), 40767356301136L};
      RenderThreadUtil.fReturningVoid(var5);
   }

   private static void lambda$new$0(int var0) {
      int var3 = var0;
      GL11.glDeleteTextures(var3);
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(31043022664772L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var20 = new String[2];
      String var17 = "\u0003\nÍ'\u008f\u0092?g\r\u0007\u009bêÃÎÕºÊpvÎæðã\u001f\u0005ë 7kYñ\u0002Hw\u0017°mq¨\u0011ß\u007f²:\u0004\u009dj\u009dé8`ÖÕ¹\u00826øt²ü\u0092Vý-\"N$n\u0096\u0097Ù¨f\u0018]¹ôâ«ð\u0004\u0016ÀÇ$i£\u0097édÔl©VÆÖq7\u0016\u0013ÿ\u0013\u008eß.";
      int var19 = "\u0003\nÍ'\u008f\u0092?g\r\u0007\u009bêÃÎÕºÊpvÎæðã\u001f\u0005ë 7kYñ\u0002Hw\u0017°mq¨\u0011ß\u007f²:\u0004\u009dj\u009dé8`ÖÕ¹\u00826øt²ü\u0092Vý-\"N$n\u0096\u0097Ù¨f\u0018]¹ôâ«ð\u0004\u0016ÀÇ$i£\u0097édÔl©VÆÖq7\u0016\u0013ÿ\u0013\u008eß."
         .length();
      char var16 = ' ';
      int var15 = -1;

      while (true) {
         byte[] var21 = var13.doFinal(var17.substring(++var15, var15 + var16).getBytes("ISO-8859-1"));
         String var30 = a(var21).intern();
         int var10001 = -1;
         var20[var18++] = var30;
         if ((var15 += var16) >= var19) {
            g = var20;
            h = new String[2];
            l = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(31043022664772L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[17];
            String var4 = "\u009d\f<\u0083\u008cz¥Ã\u0094ÿeS¼zÇ[\u0082ö¯¦ßþ\u009a\u0085}9Jg\u009dë\u0092\u0090E¨¡Ñ.\u0092\u008djTóx\u008c\u009dUÑ°P\u0092~´Ø\u00137qI\u001dt\u0002\u008d\u0094¼å¬\u009da\u0097ÿYF\u000fGrð\u009cÜë³:Ô\ríaüÑ\u0014°ìyá\u008a\u0087Û¥\u0004\u0084\u007fmñxñ±ÉÚ\u0012l«Ý\u0087øJ\u0012#¤¤\u0004\u000eF\f";
            int var5 = "\u009d\f<\u0083\u008cz¥Ã\u0094ÿeS¼zÇ[\u0082ö¯¦ßþ\u009a\u0085}9Jg\u009dë\u0092\u0090E¨¡Ñ.\u0092\u008djTóx\u008c\u009dUÑ°P\u0092~´Ø\u00137qI\u001dt\u0002\u008d\u0094¼å¬\u009da\u0097ÿYF\u000fGrð\u009cÜë³:Ô\ríaüÑ\u0014°ìyá\u008a\u0087Û¥\u0004\u0084\u007fmñxñ±ÉÚ\u0012l«Ý\u0087øJ\u0012#¤¤\u0004\u000eF\f"
               .length();
            label32:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var25 = var6;
               var10001 = var3++;
               long var33 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               // while (true) {
                  long var8 = var33;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var38 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var36) {
                     case 0:
                        var25[var10001] = var38;
                        if (var2 >= var5) {
                           j = var6;
                           k = new Integer[17];
                           break;
                        }
                        break;
                     default:
                        var25[var10001] = var38;
                        if (var2 < var5) {
                           continue label32;
                        }

                        var4 = "|ßíZ\u000ea}\u0091T\u001b\u0095³':¢è";
                        var5 = "|ßíZ\u000ea}\u0091T\u001b\u0095³':¢è".length();
                        var2 = 0;
                  }

                  int var29 = var2;
                  var2 += 8;
                  var7 = var4.substring(var29, var2).getBytes("ISO-8859-1");
                  var25 = var6;
                  var10001 = var3++;
                  var33 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var36 = 0;
               }
            }
         }

         var16 = var17.charAt(var15);
      }
   
      }

      
}

   private static IllegalStateException a(IllegalStateException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 32393;
      if (h[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])i.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               i.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/bT", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = g[var5].getBytes("ISO-8859-1");
         h[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return h[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bT_C0095",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 6050;
      if (k[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = j[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])l.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               l.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/bT", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         k[var3] = var15;
      }

      return k[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bT_C0095",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = n[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = m[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 42;
            yield var15;
         }
         case 1 -> {
            byte var16 = 40;
            yield var16;
         }
         case 2 -> {
            byte var17 = 45;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 34;
            yield var19;
         }
         case 5 -> {
            byte var20 = 6;
            yield var20;
         }
         case 6 -> {
            byte var21 = 3;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 8;
            yield var23;
         }
         case 9 -> {
            byte var24 = 18;
            yield var24;
         }
         case 10 -> {
            byte var25 = 4;
            yield var25;
         }
         case 11 -> {
            byte var26 = 52;
            yield var26;
         }
         case 12 -> {
            byte var27 = 39;
            yield var27;
         }
         case 13 -> {
            byte var28 = 55;
            yield var28;
         }
         case 14 -> {
            byte var29 = 21;
            yield var29;
         }
         case 15 -> {
            byte var30 = 24;
            yield var30;
         }
         case 16 -> {
            byte var31 = 50;
            yield var31;
         }
         case 17 -> {
            byte var32 = 35;
            yield var32;
         }
         case 18 -> {
            byte var33 = 33;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 5;
            yield var35;
         }
         case 21 -> {
            byte var36 = 30;
            yield var36;
         }
         case 22 -> {
            byte var37 = 36;
            yield var37;
         }
         case 23 -> {
            byte var38 = 20;
            yield var38;
         }
         case 24 -> {
            byte var39 = 37;
            yield var39;
         }
         case 25 -> {
            byte var40 = 49;
            yield var40;
         }
         case 26 -> {
            byte var41 = 26;
            yield var41;
         }
         case 27 -> {
            byte var42 = 62;
            yield var42;
         }
         case 28 -> {
            byte var43 = 29;
            yield var43;
         }
         case 29 -> {
            byte var44 = 54;
            yield var44;
         }
         case 30 -> {
            byte var45 = 58;
            yield var45;
         }
         case 31 -> {
            byte var46 = 12;
            yield var46;
         }
         case 32 -> {
            byte var47 = 46;
            yield var47;
         }
         case 33 -> {
            byte var48 = 38;
            yield var48;
         }
         case 34 -> {
            byte var49 = 11;
            yield var49;
         }
         case 35 -> {
            byte var50 = 23;
            yield var50;
         }
         case 36 -> {
            byte var51 = 28;
            yield var51;
         }
         case 37 -> {
            byte var52 = 22;
            yield var52;
         }
         case 38 -> {
            byte var53 = 1;
            yield var53;
         }
         case 39 -> {
            byte var54 = 0;
            yield var54;
         }
         case 40 -> {
            byte var55 = 2;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 57;
            yield var57;
         }
         case 43 -> {
            byte var58 = 19;
            yield var58;
         }
         case 44 -> {
            byte var59 = 13;
            yield var59;
         }
         case 45 -> {
            byte var60 = 32;
            yield var60;
         }
         case 46 -> {
            byte var61 = 59;
            yield var61;
         }
         case 47 -> {
            byte var62 = 41;
            yield var62;
         }
         case 48 -> {
            byte var63 = 63;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 51;
            yield var65;
         }
         case 51 -> {
            byte var66 = 9;
            yield var66;
         }
         case 52 -> {
            byte var67 = 17;
            yield var67;
         }
         case 53 -> {
            byte var68 = 15;
            yield var68;
         }
         case 54 -> {
            byte var69 = 14;
            yield var69;
         }
         case 55 -> {
            byte var70 = 56;
            yield var70;
         }
         case 56 -> {
            byte var71 = 61;
            yield var71;
         }
         case 57 -> {
            byte var72 = 47;
            yield var72;
         }
         case 58 -> {
            byte var73 = 44;
            yield var73;
         }
         case 59 -> {
            byte var74 = 27;
            yield var74;
         }
         case 60 -> {
            byte var75 = 43;
            yield var75;
         }
         case 61 -> {
            byte var76 = 16;
            yield var76;
         }
         case 62 -> {
            byte var77 = 60;
            yield var77;
         }
         default -> 31;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            n[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      m[0] = "\t6EQ$q\u00029T\u001exx\u0005yp\\o|\r2A";
      m[1] = "s\u0014qEOdx\u001b`\n.js\u0010dP";
      m[2] = "b<\rX\u000b\u0016i3\u001c\u0017w\u000ff3\u001a[I\u001f";
      m[3] = "u7s37$~8b|k-yxF>|)q3wvZ$z7k3{$z";
      m[4] = "\u000f\u001f_lc1\n\nTl`6\u0005\u0003_.!\u0001,\\\t";
      m[5] = int.class;
      n[5] = "java/lang/Integer";
      m[6] = ")h|qL\u0017*f$R\u001b\r&K\u007fv\u0004\u001c1";
      m[7] = void.class;
      n[7] = "java/lang/Void";
      m[8] = ">L\u0006\bN((L\u0003R]??\u0007\u0000TQ+.@\u0017C\u001a:\u000e";
      m[9] = "vmqJbS}b`\u0005\u0005Spi`J lhmsN\tG\u007fiw_%Pr";
      m[10] = "HlZo{\u0004^l_5h\u0013I'\\3d\u0007X`K$/\u0015i";
      m[11] = "M4\u007fgX\u000b8\u0014thIDY\u001a\u007fcM\u001e-";
      m[12] = "L\t\u0013\b_>9)\u0018\u0007NqX'\u0013\fJ+,";
      m[13] = "/8\u0014,7\u0002Z\u0018\u001f#&M;\u0016\u0014(\"\u0017O";
      m[14] = "/!x\"nK9!}x}\\.j~~qH?-ii:_!";
      m[15] = "JRK./y?r@!>6^|K*:l*";
      m[16] = "\u0003EHG\u0000,\u0006PCG\u0003+\tYH\u0005B\u001c \u0006\u001c";
      m[17] = "\u001fulN5\\\u001fu{\u00129S\u0005>{\f9F\u0002O)Pn\u0005";
      m[18] = "dHrFqkdHe\u001a}d~\u0003e\u0004}qyr4Q*2";
      m[19] = "hS@\t\u0004\u001ehSWU\b\u0011r\u0018WK\b\u0004ui\u0005\u0017]C";
      m[20] = "\u0018o\u0000vyl\u0018o\u0017*uc\u0002$\u00174uv\u0005UEh,3N";
      m[21] = "\tgAs2{\tgV/>t\u0013,V1>a\u0014]\u0006lo";
      m[22] = "\u0007l46iz\u000eb7\u007f*w\bb#}7qJw<`p`\u0016f*6Ce\u0011W<`p`\u0016f";
      m[23] = "0kIg8mEKBh)\"$EIc-xP";
      m[24] = "vM_g\u001c8\u0003mTh\rwbc_c\t-\u0016";
      m[25] = "LzJi\u001a%9ZAf\u000bjXTJm\u000f0,";
      m[26] = "'|1\r*e,|)\u000bPwx\u001b.\u0018\u0011}u(.R\u001c\u0018 {x\u0010:}&.x\u000eP$ |;\u00025\"u|%hl$'?)\rjq'!CTl#d-&R9#zG\u007fTk`v\"y\u0001k~\u001c{\u007fS(ry}*S6\u0018 {x\u0010:}&.x\u000eP$ |;\u00025\"u|%hlva*3\u0010/|}6CUhu{$}Q:ivG";
      m[27] = "+w\f\u000f>5n.\u0001\u0001G'\u0014t[\u000b?'qr\u000e\u000b!M";
      m[28] = "\bb\u001d4|`\noI9Ee5`\u0000)/6\fn\u00007!\f\bb\u001d4|`\noI9E";
      m[29] = "BV2G\u0001e@[fJ8c\u007fT/ZR3FZ/D\\\tC\bmCRlE]m]8";
      m[30] = "]\b.]KvV\b6[1d\u0002|1Dpm\u001a^3UK\u000bZ\u000fg@[n\\Zg^17Z\b$RT1\u000f\b:8";
      m[31] = "4\u0000\u0007tLXl\u0000[5%\fj]V/%Z6]X*\u001b^dAUI";
      m[32] = "\u007f~vCC\t:'{M:\u001a@}!GB\u001b%{tG\\q";
      m[33] = "V\u0007\u0019g\u0015cT\nMj,d\u000f\u0002\u0006v,2S\b\u001ax\u00126\u0001\u0014\u0017\u001b";
      m[34] = "SS@#!\tXSX%[\u001b\f4_6\u0003\u001d\u0012\u0001W+'\u0019\u0012\t2zgO\u0010\u0002W|2O\u000eh\u000ez`\f\u0002\r\b/`\u0012hT\u000e}#\u001e\rR[}=tUP_!8JQ\u0002C,[";
      m[35] = "\\\u00128M}h\b\u0013kGA1\\W5N-\u0003\u000f\u001bi\u0013~T\r\u0017nQ+1\u000bBnOA";
      m[36] = "\u001f<1\t iC?$q!nL,:\r6y#t(O0rO$+J*\u0003\u001a\"yA&2\u001c7x\u001a[9\u0013u|\u0018da\u0013)=q";
      m[37] = "|\u001f\u0015k(}i\u0005U>\u0016z|\u0012H3zH(S\u0013m\u0016t*VO3v}/W\u0015T";
      m[38] = ",\u0012)\u0007\u0018m'\u00121\u0001b\u007fsf6\u0004>}gU&\u0018\u000fk\u0017\u0015gY\u001azr\u00132Y\u0004\u0010";
      m[39] = "3\\ o}s1QtbDv\u000e^=r.%7P=l \u001f2\u0002\u007fk.z4W\u007fuD";
      m[40] = "\u0007S@.\u001ac\t\u001fFxfe\u0006\u0011[r\nWU]\u0003-Z\u0000\u0005\u0012Q/[cVS\u0004df";
      m[41] = "q\n\u000b.<Ks\u0007_#\u0005NLV^=8G2\u0018\u0001=<'rY\u0000oeY<\u0006\u0000k\u0005";
      m[42] = "7\b\u001do\u001a_<\b\u0005i`Mho\u0002z;_fr\nc\u000fO6\u007fo6\\\u0019tY\n0\t\u0019j3S6[ZfVUc[D\f\u000fS1\u0018Hi\t\u00061\u0006\"0\u000fTr\nG6ZTl`\u001e0\b\u0017`\u0005\u0018e\b\t\n\\\u001e7K\u0005oZK7Uo6\\\u0019tY\n0\t\u0019j3S6[ZfVUc[D\f\u000f\u0001w\rRtL\u000bk\u0011\"1\u000b\u0002m\u0003\u001c5Y\u001e``";
      m[43] = "fe\u0007*\r\u0018o`\u0006pj\u001d`\"_*\u0006/1`\u0006|j\u0013m9T \u0001\u001f`#XM\u0006FveC.\b\np3?";
      m[44] = "0*\u001e~?H;*\u0006xEZo[\r})ifa\u0010f?X\u000b-P =_n+\u0005 #57-Wc/P1xW}E\b3|\u000bx{\fa`\u0006\u001b";
      m[45] = "\u001f\b\u0004Oy$\u0014\b\u001cI\u00036@\u007f\u001bNn%Io\u001bZ\u007f$^^\r*?e\u001fK\u001cO90\u001fUv\u0017;4CPH\u0013i(N3";
      m[46] = "cJ?PV_#F>\u0011-\u0001R[y\bGUkUy\u0016Ioo\u0003m\u000eNQkQq\u0003-";
      m[47] = "\u001b!/k]@\u0018u;39\u0013\u0015S(vX\u0002\u001cF.zE\u0001\u000bwC6\u0005G\tp&0PG\u0017\u001a~2T\u001b\u0012$z`H\u0016q";
      m[48] = "St\u001ffa=QyKkX8nv\u0002{2kWx\u0002e<QS.\u0016};oW|\npX";
      m[49] = "jL\fXr\rhAXUK\nWN\u0011E![n@\u0011[/aj\u0016\u0005C(_nD\u0019NK";
      m[50] = "OP@X\u000b\u007fM]\u0014U2yrR]EX)K\\][V\u0013OP@X\u000b\u007fM]\u0014U2";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = m[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(n[var4]);
            m[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            m[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  m[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(130269440281534L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = m[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = n[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  m[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(130269440281534L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        m[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(130269440281534L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 193;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 69;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 207;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 181;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 105;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 233;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 193;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 69;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 207;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/bT_C0095",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/bT" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Runnable invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bT_C0095", "lambda$new$1", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding3(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "é", SourceSupport.methodType("(IJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding4(int var0, long var1) {
         MethodHandle var7 = bindingCache4;
         MethodHandle var6 = bindingCache4;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache4 = b(MethodHandles.lookup(), "x", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding5(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = c(MethodHandles.lookup(), "é", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Runnable invokeBinding6(int var0) {
         MethodHandle var5 = bindingCache6;
         MethodHandle var4 = bindingCache6;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache6 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType("(I)Ljava/lang/Runnable;", MethodHandles.lookup()),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bT_C0095", "lambda$new$0", "(I)V"),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
