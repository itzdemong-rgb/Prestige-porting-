package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import it.unimi.dsi.fastutil.Pair;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.ARBVertexArrayObject;

public class MeshBufferManager {
   private final WeakHashMap a = new WeakHashMap();
   private final Set b = new LinkedHashSet();
   public static final boolean c;
   private static final long d = 73828207227264L;
   private static final String e;
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final long i;
   private static final Object[] j = new Object[57];
   private static final String[] k = new String[57];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public GlBufferMeshBuilder aReturningGlBufferMeshBuilder(Object[] var1) {
      DrawPipeline var2 = (DrawPipeline)var1[0];
      long var3 = (Long)var1[1];
      var3 = 73828207227264L ^ var3;
      long var5 = var3 ^ 27805790644486L;
      short var10002 = 17773;
      long var10003 = 3449801704157491733L ^ var3;
      short var10 = 10451;
      long var10004 = 8899780194663292840L ^ var3;
      Object[] var10006 = new Object[]{null, null, null, var5};
      var10006[2] = 128;
      var10006[1] = 128;
      var10006[0] = var2;
      Object[] var8 = var10006;
      MeshBufferManager var7 = this;
      return var7.bReturningGlBufferMeshBuilder(var8);
   }

   public GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      DrawPipeline var4 = (DrawPipeline)var1[0];
      int var6 = (Integer)var1[1];
      int var5 = (Integer)var1[2];
      long var2 = (Long)var1[3];
      var2 = 73828207227264L ^ var2;
      long var7 = var2 ^ 55969590785402L;
      long var9 = var2 ^ 103584747151715L;
      long var11 = var2 ^ 48875384602157L;
      long var13 = var2 ^ 34541325214296L;
      int var10000 = Event.cReturningInt();
      DrawPipeline var22 = var4;
      Set var21 = this.b;
      var21.add(var22);
      int var15 = var10000;
      DrawPipeline var24 = var4;
      WeakHashMap var23 = this.a;
      SharedMeshBuffers var16 = (SharedMeshBuffers)var23.get(var24);
      int var49 = var15;
      SharedMeshBuffers var48 = var16;
      Object var47 = var48;
      SharedMeshBuffers var43 = var48;
      if (var49 != 0) {
         SharedMeshBuffers var50 = var43;
         if (var50 != null) {
            AtomicReference var26 = var16.recoveryAccess_read_aj();
            var10000 = (int)var26.get();
            int var52 = var15;
            Object var51 = var10000;
            Object var46 = var51;
            Object var44 = var51;
            if (var52 != 0) {
               Object var53 = var44;
               Object var45 = var53;
               Object var54 = var45;
               if (var54 == null) {
                  GlBufferMeshBuilder var57 = new GlBufferMeshBuilder(var4.a, var16.recoveryAccess_read_ag(), var16.recoveryAccess_read_ah(), var7);
                  GlBufferMeshBuilder var32 = var57;
                  AtomicReference var31 = var16.recoveryAccess_read_aj();
                  var31.set(var32);
                  return var57;
               }

               AtomicReference var29 = var16.recoveryAccess_read_aj();
               Object var55 = var29.get();
               var46 = var55;
            }

            return (GlBufferMeshBuilder)var46;
         }

         Object[] var33 = new Object[]{invokeBinding1(), var9};
         var47 = RenderThreadUtil.aReturningObject(var33);
      }

      ManagedGlBuffer var17 = (ManagedGlBuffer)var47;
      Object[] var34 = new Object[]{invokeBinding2(), var9};
      ManagedGlBuffer var18 = (ManagedGlBuffer)RenderThreadUtil.aReturningObject(var34);
      short var10001 = 12812;
      long var10002 = 7501789031224876531L ^ var2;
      var10002 = (long)var6 * var4.a.b;
      Object[] var10005 = new Object[]{null, null, var13};
      var10005[1] = var10002;
      var10005[0] = 35048;
      Object[] var36 = var10005;
      ManagedGlBuffer var35 = var17;
      var35.aReturningVoid(var36);
      var10001 = 21660;
      var10002 = 7684228736403569504L ^ var2;
      var10002 = var5 * i;
      var10005 = new Object[]{null, null, var13};
      var10005[1] = var10002;
      var10005[0] = 35048;
      Object[] var38 = var10005;
      ManagedGlBuffer var37 = var18;
      var37.aReturningVoid(var38);
      GlBufferMeshBuilder var19 = new GlBufferMeshBuilder(var4.a, var17, var18, var7);
      Object[] var39 = new Object[]{var17, var4.a, var11};
      GlVertexArray var20 = GlVertexArray.aReturningf7(var39);
      WeakHashMap var58 = this.a;
      SharedMeshBuffers var42 = new SharedMeshBuffers(var17, var18, var20, new AtomicReference<>(var19));
      DrawPipeline var41 = var4;
      WeakHashMap var40 = var58;
      var40.put(var41, var42);
      return var19;
   }

   private void aReturningVoid(Object[] var1) {
      RenderContext var2;
      DrawPipeline var3;
      long var6;
      long var8;
      long var10;
      int var12;
      SharedMeshBuffers var13;
      Object var41;
      label36: {
         var2 = (RenderContext)var1[0];
         var3 = (DrawPipeline)var1[1];
         long var4 = (Long)var1[2];
         var4 = 73828207227264L ^ var4;
         var6 = var4 ^ 107863810170775L;
         var8 = var4 ^ 119104919502794L;
         var10 = var4 ^ 121776077533779L;
         int var10000 = Event.cReturningInt();
         DrawPipeline var18 = var3;
         WeakHashMap var17 = this.a;
         var13 = (SharedMeshBuffers)var17.get(var18);
         var12 = var10000;
         boolean var47 = c;
         if (!var47) {
            int var49 = var12;
            SharedMeshBuffers var48 = var13;
            var41 = var48;
            SharedMeshBuffers var39 = var48;
            if (var49 == 0) {
               break label36;
            }

            SharedMeshBuffers var50 = var39;
            SharedMeshBuffers var40 = var50;
            SharedMeshBuffers var51 = var40;
            if (var51 == null) {
               throw new AssertionError();
            }
         }

         AtomicReference var22 = var13.recoveryAccess_read_aj();
         var41 = var22.get();
      }

      GlBufferMeshBuilder var14 = (GlBufferMeshBuilder)var41;
      int var53 = var12;
      byte var52 = ((byte)((c) ? 1 : 0));
      int var46 = var52;
      byte var42 = var52;
      if (var53 != 0) {
         GlBufferMeshBuilder var45;
         label28: {
            byte var54 = var42;
            if (var54 == 0) {
               int var56 = var12;
               GlBufferMeshBuilder var55 = var14;
               var45 = var55;
               GlBufferMeshBuilder var43 = var55;
               if (var56 == 0) {
                  break label28;
               }

               GlBufferMeshBuilder var57 = var43;
               GlBufferMeshBuilder var44 = var57;
               GlBufferMeshBuilder var58 = var44;
               if (var58 == null) {
                  throw new AssertionError(e);
               }
            }

            var45 = var14;
         }

         Object[] var28 = new Object[]{var8};
         GlBufferMeshBuilder var27 = var45;
         var46 = var27.bReturningInt(var28);
      }

      int var15 = var46;
      Object[] var30 = new Object[]{var10};
      GlBufferMeshBuilder var29 = var14;
      int var16 = var29.aReturningInt(var30);
      GlBufferMeshBuilder var31 = var14;
      var31.close();
      Object var33 = null;
      AtomicReference var32 = var13.recoveryAccess_read_aj();
      var32.set(var33);
      GlVertexArray var60 = var13.recoveryAccess_read_ai();
      Object[] var35 = new Object[0];
      GlVertexArray var34 = var60;
      int var36 = var34.aReturningInt(var35);
      ARBVertexArrayObject.glBindVertexArray(var36);
      Object[] var38 = new Object[]{var2, var13.recoveryAccess_read_ai(), var13.recoveryAccess_read_ah(), new MeshDrawRange(var3.a, var16, var15), var6};
      DrawPipeline var37 = var3;
      var37.aReturningVoid(var38);
      ARBVertexArrayObject.glBindVertexArray(0);
   }

   public void bReturningVoid(Object[] var1) {
      RenderContext var2 = (RenderContext)var1[0];
      long var3 = (Long)var1[1];
      var3 = 73828207227264L ^ var3;
      long var5 = var3 ^ 111905419071603L;
      int var10000 = Event.cReturningInt();
      Set var10 = this.b;
      Iterator var8 = var10.iterator();
      int var7 = var10000;

      while (true) {
         Iterator var11 = var8;
         boolean var18 = var11.hasNext();
         if (var18) {
            Iterator var12 = var8;
            DrawPipeline var9 = (DrawPipeline)var12.next();
            Object[] var14 = new Object[]{var2, var9, var5};
            MeshBufferManager var13 = this;
            var13.aReturningVoid(var14);
            int var19 = var7;
            if (var19 == 0) {
               break;
            }

            int var20 = var7;
            if (var20 != 0) {
               continue;
            }
         }

         Set var16 = this.b;
         var16.clear();
         WeakHashMap var17 = this.a;
         var17.size();
         break;
      }
   }

   public Stream aReturningStream(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 73828207227264L ^ var2;
      Set var4 = this.b;
      Stream var7 = var4.stream();
      Function var6 = invokeBinding3(this);
      Stream var5 = var7;
      return var5.map(var6);
   }

   private Pair lambda$getAllActiveBuffers$0(DrawPipeline var1) {
      DrawPipeline var5 = var1;
      WeakHashMap var4 = this.a;
      AtomicReference var6 = ((SharedMeshBuffers)var4.get(var5)).recoveryAccess_read_aj();
      GlBufferMeshBuilder var8 = (GlBufferMeshBuilder)var6.get();
      DrawPipeline var7 = var1;
      return Pair.of(var7, var8);
   }

   static {

      {

      aReturningVoid();
      Cipher var16;
      Cipher var10000 = var16 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var17 = 1; var17 < 8; var17++) {
         var10003[var17] = (byte)(70819192807591L << var17 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var18 = var16.doFinal(
         "E\r¾\u0090ø0>\ta\u008f\u0013¹_y\u0092\u001d\u0000HÐæÆ\u0098+¤\u0083\u0082Iª)G\u0098\u00032Ý\u001dõ\\H²ßh\u0016³\u009f\u0017\u0013\u0003\u008bÂ\u0015tÌ\u0096\u001b¡m\u0088½\u009f\u0019¨\u0012y¥"
            .getBytes("ISO-8859-1")
      );
      String var31 = a(var18).intern();
      int var10001 = -1;
      e = var31;
      h = new HashMap(13);
      Cipher var5;
      var10000 = var5 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var6 = 1; var6 < 8; var6++) {
         var10003[var6] = (byte)(70819192807591L << var6 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var11 = new long[4];
      String var9 = "~£?<ò]k£ßc\u008fÅ\u0015¦}'";
      int var10 = "~£?<ò]k£ßc\u008fÅ\u0015¦}'".length();
      label47:
      while (true) {
         var10001 = var7;
         var7 += 8;
         byte[] var12 = var9.substring(var10001, var7).getBytes("ISO-8859-1");
         long[] var24 = var11;
         var10001 = var8++;
         long var33 = (var12[0] & 255L) << 56
            | (var12[1] & 255L) << 48
            | (var12[2] & 255L) << 40
            | (var12[3] & 255L) << 32
            | (var12[4] & 255L) << 24
            | (var12[5] & 255L) << 16
            | (var12[6] & 255L) << 8
            | var12[7] & 255L;
         
            long var13 = var33;
            byte[] var15 = var5.doFinal(
               new byte[]{
                  (byte)(var13 >>> 56),
                  (byte)(var13 >>> 48),
                  (byte)(var13 >>> 40),
                  (byte)(var13 >>> 32),
                  (byte)(var13 >>> 24),
                  (byte)(var13 >>> 16),
                  (byte)(var13 >>> 8),
                  (byte)var13
               }
            );
            long var41 = (var15[0] & 255L) << 56
               | (var15[1] & 255L) << 48
               | (var15[2] & 255L) << 40
               | (var15[3] & 255L) << 32
               | (var15[4] & 255L) << 24
               | (var15[5] & 255L) << 16
               | (var15[6] & 255L) << 8
               | var15[7] & 255L;
            switch (var38) {
               case 0:
                  var24[var10001] = var41;
                  if (var7 >= var10) {
                     f = var11;
                     g = new Integer[4];
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(70819192807591L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long var29 = 8934701906844587376L;
                     byte[] var4 = var0.doFinal(
                        new byte[]{
                           (byte)123L,
                           (byte)31742L,
                           (byte)8126064L,
                           (byte)2080272395L,
                           (byte)532549733331L,
                           (byte)136332731732858L,
                           (byte)34901179323611669L,
                           (byte)8934701906844587376L
                        }
                     );
                     long var36 = (var4[0] & 255L) << 56
                        | (var4[1] & 255L) << 48
                        | (var4[2] & 255L) << 40
                        | (var4[3] & 255L) << 32
                        | (var4[4] & 255L) << 24
                        | (var4[5] & 255L) << 16
                        | (var4[6] & 255L) << 8
                        | var4[7] & 255L;
                     
                     Class<MeshBufferManager> var21 = MeshBufferManager.class;
                     c = dev.prestige.recovery.SourceSupport.asBoolean((!var21.desiredAssertionStatus() ? 1 : 0));
                     break;
                  }
                  break;
               default:
                  var24[var10001] = var41;
                  if (var7 < var10) {
                     continue label47;
                  }

                  var9 = ">jÔÈÊo ¡Â^Ö%9\u001bîó";
                  var10 = ">jÔÈÊo ¡Â^Ö%9\u001bîó".length();
                  var7 = 0;
            }

            int var28 = var7;
            var7 += 8;
            var12 = var9.substring(var28, var7).getBytes("ISO-8859-1");
            var24 = var11;
            var10001 = var8++;
            var33 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            var38 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15066;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/an", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/an_C0030",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/an" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = k[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = j[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 62;
            yield var15;
         }
         case 1 -> {
            byte var16 = 44;
            yield var16;
         }
         case 2 -> {
            byte var17 = 43;
            yield var17;
         }
         case 3 -> {
            byte var18 = 5;
            yield var18;
         }
         case 4 -> {
            byte var19 = 58;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 19;
            yield var21;
         }
         case 7 -> {
            byte var22 = 38;
            yield var22;
         }
         case 8 -> {
            byte var23 = 21;
            yield var23;
         }
         case 9 -> {
            byte var24 = 33;
            yield var24;
         }
         case 10 -> {
            byte var25 = 53;
            yield var25;
         }
         case 11 -> {
            byte var26 = 39;
            yield var26;
         }
         case 12 -> {
            byte var27 = 15;
            yield var27;
         }
         case 13 -> {
            byte var28 = 29;
            yield var28;
         }
         case 14 -> {
            byte var29 = 9;
            yield var29;
         }
         case 15 -> {
            byte var30 = 52;
            yield var30;
         }
         case 16 -> {
            byte var31 = 45;
            yield var31;
         }
         case 17 -> {
            byte var32 = 1;
            yield var32;
         }
         case 18 -> {
            byte var33 = 56;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 50;
            yield var35;
         }
         case 21 -> {
            byte var36 = 59;
            yield var36;
         }
         case 22 -> {
            byte var37 = 10;
            yield var37;
         }
         case 23 -> {
            byte var38 = 7;
            yield var38;
         }
         case 24 -> {
            byte var39 = 17;
            yield var39;
         }
         case 25 -> {
            byte var40 = 41;
            yield var40;
         }
         case 26 -> {
            byte var41 = 14;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 23;
            yield var43;
         }
         case 29 -> {
            byte var44 = 8;
            yield var44;
         }
         case 30 -> {
            byte var45 = 28;
            yield var45;
         }
         case 31 -> {
            byte var46 = 36;
            yield var46;
         }
         case 32 -> {
            byte var47 = 34;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 12;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 42;
            yield var52;
         }
         case 38 -> {
            byte var53 = 49;
            yield var53;
         }
         case 39 -> {
            byte var54 = 27;
            yield var54;
         }
         case 40 -> {
            byte var55 = 6;
            yield var55;
         }
         case 41 -> {
            byte var56 = 47;
            yield var56;
         }
         case 42 -> {
            byte var57 = 46;
            yield var57;
         }
         case 43 -> {
            byte var58 = 35;
            yield var58;
         }
         case 44 -> {
            byte var59 = 11;
            yield var59;
         }
         case 45 -> {
            byte var60 = 16;
            yield var60;
         }
         case 46 -> {
            byte var61 = 55;
            yield var61;
         }
         case 47 -> {
            byte var62 = 63;
            yield var62;
         }
         case 48 -> {
            byte var63 = 37;
            yield var63;
         }
         case 49 -> {
            byte var64 = 24;
            yield var64;
         }
         case 50 -> {
            byte var65 = 22;
            yield var65;
         }
         case 51 -> {
            byte var66 = 54;
            yield var66;
         }
         case 52 -> {
            byte var67 = 30;
            yield var67;
         }
         case 53 -> {
            byte var68 = 25;
            yield var68;
         }
         case 54 -> {
            byte var69 = 31;
            yield var69;
         }
         case 55 -> {
            byte var70 = 26;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 60;
            yield var72;
         }
         case 58 -> {
            byte var73 = 18;
            yield var73;
         }
         case 59 -> {
            byte var74 = 0;
            yield var74;
         }
         case 60 -> {
            byte var75 = 61;
            yield var75;
         }
         case 61 -> {
            byte var76 = 4;
            yield var76;
         }
         case 62 -> {
            byte var77 = 13;
            yield var77;
         }
         default -> 51;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            k[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      j[0] = "A\u0002C\u000fx7W\u0002FUk @IESg4Q\u000eRD,&K";
      j[1] = "a\u0017*h\u00009\u00147!g\u0011vu9*l\u0015,\u0001";
      j[2] = void.class;
      k[2] = "java/lang/Void";
      j[3] = "\"\u0018{W\u0018X<\u0010a\u0018eH<";
      j[4] = "\u00062y&\u0013(\u0018:cit)\t!n3R/";
      j[5] = "c!>ynKu!;#}\\bj8%qHs-/2:ZB";
      j[6] = int.class;
      k[6] = "java/lang/Integer";
      j[7] = "M1ke\u0019uF>z*zxS3uAOzB imXw";
      j[8] = "V\u001a\u001f`ex]\u0015\u000e/\u0004vV\u001e\nu";
      j[9] = ":pEi\rz$x_&tj1z{iPg\u001dpC";
      j[10] = boolean.class;
      k[10] = "java/lang/Boolean";
      j[11] = "m&&(x:s.<g5 i$%;$*i3~(\" j.3g\u0017;h*9*\u0004*a\"\",8,b";
      j[12] = "wM?%O4sP?4R40_p#U(jP}~q<wK";
      j[13] = "\u0011\u0019+\u0001<x\u0007\u0019.[/o\u0010R-]#{\u0001\u0015:Jhl\u001f";
      j[14] = "#kc0\f\u0018VKh?\u001dW7Ec4\u0019\rC";
      j[15] = "]qk\"M,Kqnx^;\\:m~R/M}zi\u0019:\u000e";
      j[16] = "I:t1<o<\u001a\u007f>- ]\u0014t5)z)";
      j[17] = "\u0018\u0007X\t2\u000e\u000e\u0007]S!\u0019\u0019L^U-\r\b\u000bIBf\u001c,";
      j[18] = "rDK`t)\u0007d@oeffjKda<\u0012";
      j[19] = "\u0007ith5P\u0019an'hQ\u001fmcd5v\u0019zghv";
      j[20] = "\rdZ(z\u0011\u0013l@g2\u0011\tfX ;\nICY'7\u0010\u000ejB";
      j[21] = "5\u001flMZ\u001e@?gBKQ!1lIO\u000bU";
      j[22] = "fLb^Z\u0016pLg\u0004I\u0001g\u0007d\u0002E\u0015v@s\u0015\u000e\u0004S";
      j[23] = "eU3kgq\u0010u8dv>q{3ord\u0005";
      j[24] = ":r\u0013b^i,r\u00168M~;9\u0015>Aj*~\u0002)\n}0";
      j[25] = "Wp,U\f\u000e\"P'Z\u001dAC^,Q\u0019\u001b7";
      j[26] = "Wb\u0005\u0006\u000e\u0004Rw\u000e\u0006\r\u0003]~\u0005DL2jR4M\u0010\u0007]h#Z\u0010\u0012A_\u0000B\u0007\u0010L";
      j[27] = ",q9s$\u0016YQ2|5Y8_9w1\u0003L";
      j[28] = "g8\u001d\u0018\u007f_\u0012\u0018\u0016\u0017n\u0010s\u0016\u001d\u001cjJ\u0007";
      j[29] = "hBA\nfGcMPE\u000bGcPD";
      j[30] = "}l2gC\u001bl7\u007fm-\u0002\u00176/m\u0015\u0011-&0e\u0013k+?6:RTy?6,-";
      j[31] = "O.\u0003|\\_\u001d1@8!\n\u001d.98_\u0003\b4B;\u001bZ\rR";
      j[32] = "\n/.hJ\u0002S:'|s\u000bY-K'\r\u0002L70$I[IQvd\u0015\u001cR*u L\u00194";
      j[33] = "4h6[1wk/*k1F72~S\"|'-vUX|l7~\u00122&'\"=k";
      j[34] = "L~W*\u0016)\u00139K\u001a\u0015\u0018O$\u001f\"\u0005\"_;\u0017$\u007fvR5\u0014t\u001b$R<^\u001a";
      j[35] = "<$\b\u0019\u000e\u007f>d\t\u001c\u007fl\u0000$\u0006\u001f\u0019x?v\u0006\u001f\u000f\u0007";
      j[36] = "\b\u0014.[5I\u0002\u0019-\u001b\u0005\u0013\r\u0007GIdL\r\u0002wJ{\u000bY\u007f+Ol\tT@!BoId";
      j[37] = "O\u000b\u0007dO-\u0007X\u0019rq \u0019\nw%\u000f/\r\u0000\f&Kv\bfH(H(E\u000f\u0018}\u00173u";
      j[38] = "WsQdf=\u00132\u0015i\f%\u0000}\u0013\u00021=\u000bu\ty2yRpo";
      j[39] = "|S*\u0012\u0015F%F#\u0006,[#_\"`\u0010K;K0_BK;]O";
      j[40] = "\u001dl:G?\u0007\u000em8\u0015\u0006\u000f\u0018Ea\u001ej>\u0011u|\u0015v)\u0006ui\t\u0006\\\u0017vf\u00079\u000e\u0017vpx<Y\u0019>y\u0012f\u0012\f}\u0000";
      j[41] = "\u000f_\u001b\u00027lK\u001e_\u000f]r\\Zc\t-n5\u001e\u0015]<\"\\N@\u0002'\u0012";
      j[42] = "l:8\rb\u001c>%{I\u001f]>:\u0002Ia@+ yJ%\u0019.F8Mz\u0017*,b\u0006oTS";
      j[43] = "\u001cXt\u001b7(NX}QY&rEe\u0010a6HUz\u0018gLNL|G&s\u001cL|QY";
      j[44] = "@g:j\u0001M\u001f6b`8Vq5<;\u0000EK%#3\u0006?L):r^DOmcw8";
      j[45] = "w65O\u0007afmxEix\u001dl(EQk'|7MW\u0011w65O\u0007afmxEi";
      j[46] = "C`N~\u0016!Ra\u00191l!(o\u0010qT2\u0012\u007f\u000fyRH\u00124\u0015q\u0015\"H\u007f\u00002l";
      j[47] = "8a.>3@p20(\rE~a$+qCx\fd<3Bhr }wO\u0002";
      j[48] = "Y\u0011!:bC\u000b\u0011(p\fN7\f014]\r\u001c/92'\u000b\u0005)fs\u0018Y\u0005)p\f";
      j[49] = "j\u001c]>_\u001c8\u001cTt1\u0013`\u0004Wi1B=\u0006\u001d}[\u0018v\u0013^\u0004";
      j[50] = "/cxQ,\u001ap$da,+s`f\u0011{M*9aZE\u0016w>q_#O.9:a";
      j[51] = "\u0018\u0014s]<k\nG\"\u0005@rx\u001f\"\u0005xaB\u000f=\r~\u001bBD'\u00059q\u0018\u000f2F@";
      j[52] = "T`?\fP\u001a\u001c3!\u001an\u0005\u0012w\"\u0019\u000b~\u0002f&\u000f^A\bk%On";
      j[53] = "\u000b\u0015\u0004i\n\u001b_\r\u001c1i\u001aUwK~\u000f\u0005]\fH:V\u0000;J\bf\u0011\u001b@IL?\u0014}\u000b\u0015\u0004i\n\u001b_\r\u001c1i";
      j[54] = "Y\u001b\" \u001d([L\"e${W\r.fI{s\r4q^k[\u0011)GX~F\u000b4\u001c\u001b'\u0003\u0017\u007fuKr\\\fO";
      j[55] = "&#><h|np *Vsx#':V\"%+\u007f9<xn><@";
      j[56] = "L> ~^0\u0015+)jg.\u000f<E1\u00190\n&>2]i\u000f@xr\u0001.\u0014;{6X+r};j\u001f0\t~\u007f3\u001aV";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = j[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(k[var4]);
            j[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            j[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  j[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(597112423839930L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = j[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = k[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  j[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(597112423839930L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        j[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(597112423839930L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 238;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 102;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 243;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 230;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 99;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 203;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 238;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 102;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 243;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/an_C0030",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/an" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Supplier invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Supplier invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding3(MeshBufferManager var0) {
         MethodHandle var5 = bindingCache3;
         MethodHandle var4 = bindingCache3;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/an_C0030;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/an_C0030",
                     "lambda$getAllActiveBuffers$0",
                     "(Ldev/zprestige/prestige/dn_C0192;)Lit/unimi/dsi/fastutil/Pair;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dn_C0192;)Lit/unimi/dsi/fastutil/Pair;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((MeshBufferManager)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
