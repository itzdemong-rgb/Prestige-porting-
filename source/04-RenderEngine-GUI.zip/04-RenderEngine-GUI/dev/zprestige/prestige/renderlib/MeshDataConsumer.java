package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.GraphicsCapabilities;
import dev.zprestige.prestige.renderlib.PrimitiveMode;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public interface MeshDataConsumer {
   long j = 86711643427615L;
   Object[] u = new Object[20];
   String[] v = new String[20];

   String k = RecoveryInitialization.k;
   long[] l = RecoveryInitialization.l;
   Integer[] m = RecoveryInitialization.m;
   Map n = RecoveryInitialization.n;

   MeshDataConsumer aReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer bReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer cReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer dReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer eReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer fReturningMeshDataConsumer(Object[] var1);

   MeshDataConsumer gReturningMeshDataConsumer(Object[] var1);

   int aReturningInt(Object[] var1);

   int bReturningInt(Object[] var1);

   MeshDataConsumer hReturningMeshDataConsumer(Object[] var1);

   void aReturningVoid(Object[] var1);

   void bReturningVoid(Object[] var1);

   int cReturningInt(Object[] var1);

   default MeshDataConsumer i(Object[] var1) {
      PrimitiveMode var2 = (PrimitiveMode)var1[0];
      long var3 = (Long)var1[1];
      var3 = 86711643427615L ^ var3;
      long var5 = var3 ^ 88166520521584L;
      long var7 = var3 ^ 90974581559017L;
      long var9 = var3 ^ 10105743338365L;
      long var11 = var3 ^ 52401268727066L;
      boolean var60 = GraphicsCapabilities.a;
      if (!var60) {
         Object[] var19 = new Object[0];
         MeshDataConsumer var18 = this;
         int var61 = var18.cReturningInt(var19);
         if (var61 == 0) {
            Object[] var22 = new Object[]{var5};
            MeshDataConsumer var21 = this;
            int var62 = var21.bReturningInt(var22);
            if (var62 != 0) {
               throw new AssertionError(k);
            }
         }
      }

      Object[] var26 = new Object[]{var7};
      MeshDataConsumer var25 = this;
      int var10000 = var25.aReturningInt(var26);
      Object[] var28 = new Object[0];
      MeshDataConsumer var27 = this;
      int var13 = var10000 - var27.cReturningInt(var28);
      PrimitiveMode var29 = var2;
      int var63 = GraphicsCapabilities.b[var29.ordinal()];
      switch (var63) {
         case 1:
            int var94 = var13 / 3 * 3 * 4;
            Object[] var103 = new Object[]{null, var9};
            var103[0] = var94;
            Object[] var32 = var103;
            MeshDataConsumer var31 = this;
            var31.aReturningVoid(var32);
            byte var86 = 0;

            while (true) {
               int var65 = var13;
               byte var64 = var86;
               if (var64 >= var65) {
                  byte var66 = 0;
                  return this;
               }

               Object[] var34 = new Object[]{new int[]{var86, var86 + 1, var86 + 2}, var11};
               MeshDataConsumer var33 = this;
               var33.gReturningMeshDataConsumer(var34);
               var86 += 3;
            }
         case 2:
            int var91 = var13 / 4;
            short var96 = 27069;
            long var98 = 7897944009640254246L ^ var3;
            var91 = var91 * 6 * 4;
            Object[] var102 = new Object[]{null, var9};
            var102[0] = var91;
            Object[] var37 = var102;
            MeshDataConsumer var36 = this;
            var36.aReturningVoid(var37);
            byte var85 = 0;

            while (true) {
               int var68 = var13;
               byte var67 = var85;
               if (var67 >= var68) {
                  byte var69 = 0;
                  return this;
               }

               short var93 = 9344;
               long var97 = 3604041690592663066L ^ var3;
               Object[] var39 = new Object[]{new int[]{var85, var85 + 1, var85 + 2, var85 + 2, var85 + 3, var85}, var11};
               MeshDataConsumer var38 = this;
               var38.gReturningMeshDataConsumer(var39);
               var85 += 4;
            }
         case 3:
            int var90 = (var13 - 2) * 3 * 4;
            Object[] var101 = new Object[]{null, var9};
            var101[0] = var90;
            Object[] var42 = var101;
            MeshDataConsumer var41 = this;
            var41.aReturningVoid(var42);
            int var84 = 1;

            while (true) {
               int var71 = var13 - 1;
               int var70 = var84;
               if (var70 >= var71) {
                  byte var72 = 0;
                  return this;
               }

               Object[] var44 = new Object[]{new int[]{0, var84, var84 + 1}, var11};
               MeshDataConsumer var43 = this;
               var43.gReturningMeshDataConsumer(var44);
               var84++;
            }
         case 4:
            int var89 = (var13 - 1) * 2 * 4;
            Object[] var100 = new Object[]{null, var9};
            var100[0] = var89;
            Object[] var47 = var100;
            MeshDataConsumer var46 = this;
            var46.aReturningVoid(var47);
            while (true) {
               int var74 = var13 - 1;
               int var73 = var83;
               if (var73 >= var74) {
                  byte var75 = 0;
                  return this;
               }

               Object[] var49 = new Object[]{new int[]{var83, var83 + 1}, var11};
               MeshDataConsumer var48 = this;
               var48.gReturningMeshDataConsumer(var49);
               var83++;
            }
         case 5:
            int var82 = var13 / 2 - 1;
            short var10002 = 9344;
            long var10003 = 3604041690592663066L ^ var3;
            int var87 = var82 * 6 * 4;
            Object[] var99 = new Object[]{null, var9};
            var99[0] = var87;
            Object[] var52 = var99;
            MeshDataConsumer var51 = this;
            var51.aReturningVoid(var52);
            while (true) {
               int var77 = var82;
               int var76 = var16;
               if (var76 >= var77) {
                  byte var78 = 0;
                  return this;
               }

               int var17 = var16 * 2;
               short var88 = 9344;
               long var95 = 3604041690592663066L ^ var3;
               Object[] var54 = new Object[]{new int[]{var17, var17 + 1, var17 + 3, var17 + 3, var17 + 2, var17}, var11};
               MeshDataConsumer var53 = this;
               var53.gReturningMeshDataConsumer(var54);
               var16++;
            }
         case 6:
            int var10001 = var13 / 2 * 2 * 4;
            Object[] var10004 = new Object[]{null, var9};
            var10004[0] = var10001;
            Object[] var56 = var10004;
            MeshDataConsumer var55 = this;
            var55.aReturningVoid(var56);
            byte var15 = 0;

            while (true) {
               int var80 = var13;
               byte var79 = var15;
               if (var79 >= var80) {
                  byte var59 = 0;
                  return this;
               }

               Object[] var58 = new Object[]{new int[]{var15, var15 + 1}, var11};
               MeshDataConsumer var57 = this;
               var57.gReturningMeshDataConsumer(var58);
               var15 += 2;
            }
         default:
            throw new MatchException(null, null);
      }
   }

   MeshDataConsumer j(Object[] var1);

   default MeshDataConsumer k(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 86711643427615L ^ var2;
      long var4 = var2 ^ 98715810856378L;
      long var6 = var2 ^ 132725664328411L;
      Object[] var9 = new Object[]{var4};
      MeshDataConsumer var8 = this;
      int var10001 = var8.aReturningInt(var9);
      Object[] var10004 = new Object[]{null, var6};
      var10004[0] = var10001;
      Object[] var11 = var10004;
      MeshDataConsumer var10 = this;
      return var10.jReturningVoid(var11);
   }



   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 21101;
      if (m[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = l[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])n.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cC", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         m[var3] = var15;
      }

      return m[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cC_C0115",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = v[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = u[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 19;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 35;
            yield var17;
         }
         case 3 -> {
            byte var18 = 42;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 8;
            yield var20;
         }
         case 6 -> {
            byte var21 = 57;
            yield var21;
         }
         case 7 -> {
            byte var22 = 63;
            yield var22;
         }
         case 8 -> {
            byte var23 = 41;
            yield var23;
         }
         case 9 -> {
            byte var24 = 29;
            yield var24;
         }
         case 10 -> {
            byte var25 = 47;
            yield var25;
         }
         case 11 -> {
            byte var26 = 50;
            yield var26;
         }
         case 12 -> {
            byte var27 = 7;
            yield var27;
         }
         case 13 -> {
            byte var28 = 24;
            yield var28;
         }
         case 14 -> {
            byte var29 = 49;
            yield var29;
         }
         case 15 -> {
            byte var30 = 44;
            yield var30;
         }
         case 16 -> {
            byte var31 = 12;
            yield var31;
         }
         case 17 -> {
            byte var32 = 3;
            yield var32;
         }
         case 18 -> {
            byte var33 = 28;
            yield var33;
         }
         case 19 -> {
            byte var34 = 46;
            yield var34;
         }
         case 20 -> {
            byte var35 = 30;
            yield var35;
         }
         case 21 -> {
            byte var36 = 36;
            yield var36;
         }
         case 22 -> {
            byte var37 = 60;
            yield var37;
         }
         case 23 -> {
            byte var38 = 38;
            yield var38;
         }
         case 24 -> {
            byte var39 = 4;
            yield var39;
         }
         case 25 -> {
            byte var40 = 17;
            yield var40;
         }
         case 26 -> {
            byte var41 = 53;
            yield var41;
         }
         case 27 -> {
            byte var42 = 48;
            yield var42;
         }
         case 28 -> {
            byte var43 = 25;
            yield var43;
         }
         case 29 -> {
            byte var44 = 0;
            yield var44;
         }
         case 30 -> {
            byte var45 = 40;
            yield var45;
         }
         case 31 -> {
            byte var46 = 18;
            yield var46;
         }
         case 32 -> {
            byte var47 = 16;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 37;
            yield var49;
         }
         case 35 -> {
            byte var50 = 9;
            yield var50;
         }
         case 36 -> {
            byte var51 = 23;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 31;
            yield var53;
         }
         case 39 -> {
            byte var54 = 27;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 51;
            yield var56;
         }
         case 42 -> {
            byte var57 = 26;
            yield var57;
         }
         case 43 -> {
            byte var58 = 34;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 56;
            yield var60;
         }
         case 46 -> {
            byte var61 = 11;
            yield var61;
         }
         case 47 -> {
            byte var62 = 6;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 20;
            yield var64;
         }
         case 50 -> {
            byte var65 = 32;
            yield var65;
         }
         case 51 -> {
            byte var66 = 10;
            yield var66;
         }
         case 52 -> {
            byte var67 = 43;
            yield var67;
         }
         case 53 -> {
            byte var68 = 33;
            yield var68;
         }
         case 54 -> {
            byte var69 = 45;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 2;
            yield var71;
         }
         case 57 -> {
            byte var72 = 21;
            yield var72;
         }
         case 58 -> {
            byte var73 = 14;
            yield var73;
         }
         case 59 -> {
            byte var74 = 52;
            yield var74;
         }
         case 60 -> {
            byte var75 = 62;
            yield var75;
         }
         case 61 -> {
            byte var76 = 59;
            yield var76;
         }
         case 62 -> {
            byte var77 = 5;
            yield var77;
         }
         default -> 54;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            v[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      u[0] = "$7oTy\u000127j\u000ej\u0016%|i\bf\u00024;~\u001f-\u0012\u0003";
      u[1] = "\u0007\\n?u+r|e0dd\u0013rn;`>g";
      u[2] = int.class;
      v[2] = "java/lang/Integer";
      u[3] = "@4\u0019[,\t5\u0014\u0012T=FT\u001a\u0019_9\u001c ";
      u[4] = "K7G\u0010fU>\u0017L\u001fw\u001a_\u0019G\u0014s@+";
      u[5] = void.class;
      v[5] = "java/lang/Void";
      u[6] = "k\u0011#{[I\u001e1(tJ\u0006\u007f?#\u007fN\\\u000b";
      u[7] = "]\b,h\u000b~V\u0007='hsC\n2L]qR\u0019.`J|";
      u[8] = "1iWJkNDI\\Ez\u0001%GWN~[Q";
      u[9] = "\u0013yzkj\u000ffYqd{@\u0007Wzo\u007f\u001as";
      u[10] = "$\u0007\u0001i;z2\u0007\u00043(m%L\u00075$y4\u000b\u0010\"oa";
      u[11] = "kR\nz\u001a?`]\u001b5{1kV\u001fo";
      u[12] = "6uG\u00116.5|\u001fof\u0010onXR6a)nH_\tw)h\\P7t 0\"";
      u[13] = "\u001a\u0005Z\u0002YL\u0019\f\u0002|\u0004rC\u001eEAY\u0003\u0005\u001eULf\u0015\u0005\u0018ACX\u0016\f@?";
      u[14] = "\t}d\u001e\u0012\u0013\nt<`D-Pf{]\u0012\\\u0016fkP-\u0011RhpXF]Vi0`";
      u[15] = "\u0003eT E`\u0000l\f^\u0011^Z~KcE/\u001c~[nzg\np_'\u0018g\u0019z\u000b^";
      u[16] = "Yv)XW(Z\u007fq&\u0001\u0016\u0003l&D\u000bv\u0001v,Eh+\\d.E\b)Fn/&";
      u[17] = "m\u0000c\u001cCLn\t;b\u0016r4\u001b|_C\u0003r\u001blR|Kd\u0015h\u001b\u001eKw\u001f<b";
      u[18] = "\u001d1s\u0005V\u000e\u001e8+{\u00000D*lFVA\u0002*|Ki\t\u0014$x\u0002\u000b\t\u0007.,{";
      u[19] = ":QQcI\nuWV6-\u0012\u007f_\u000e=D\u0011\u0005\n\u00016C\fg\n\u0012<\u0017u";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = u[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(v[var4]);
            u[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = u[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            u[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  u[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(805340747276512L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = u[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = v[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  u[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(805340747276512L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        u[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(805340747276512L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 254;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 84;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 74;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 70;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 108;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 181;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 254;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 84;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 74;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cC_C0115",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cC" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   final class RecoveryInitialization {
      static String k;
      static long[] l;
      static Integer[] m;
      static Map n;
      static {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(136731451904932L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      byte[] var15 = var13.doFinal(
         "_8\u008f\u001còd\u000e\u0083ó\u0083\u0083.·çW*\u0093ï2·rú\u0091jÍT?Ý\u008a¯Üg»ªÁÆ[¨L8á\rQ®®c¢\t\u0081°\u0090Á<OGK\u008e.»§ÎÃP\"f®fQq&j\u0005Å|\u0005i4%ÑñÊ\u0088©¤[\u009f\u0003½öÝó\u0012?;\u0013¼\u008e\u0095I\u0084µ\u0011$jÖûìÌ,\u0095\u0097\u009f^hrY\u008d4CZgMV!\u0097\r\u009a7"
            .getBytes("ISO-8859-1")
      );
      String var19 = a(var15).intern();
      int var10001 = -1;
      k = var19;
      n = new HashMap(13);
      Cipher var0;
      var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(136731451904932L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[2];
      String var4 = "\u0091ü\u0089\u0015÷\u008c\u0004_Ùõ\t\u0014¡ï\u0001M";
      int var5 = "\u0091ü\u0089\u0015÷\u008c\u0004_Ùõ\t\u0014¡ï\u0001M".length();
      do {
         var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         var10001 = var3++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var0.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var10004 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         
      } while (var2 < var5);

      l = var6;
      m = new Integer[2];
      if (GraphicsCapabilities.a) {
      }
   
         } catch (Throwable failure) { throw SourceSupport.rethrow(failure); }
      }
   }
}
