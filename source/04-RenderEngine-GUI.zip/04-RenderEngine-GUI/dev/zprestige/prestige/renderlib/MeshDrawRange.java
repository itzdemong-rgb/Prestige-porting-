package dev.zprestige.prestige.renderlib;

public record MeshDrawRange(VertexFormat a2, int a3, int a4) {
}
