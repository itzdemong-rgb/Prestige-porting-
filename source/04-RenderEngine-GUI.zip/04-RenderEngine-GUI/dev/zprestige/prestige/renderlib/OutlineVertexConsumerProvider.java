package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;

public class OutlineVertexConsumerProvider implements VertexConsumerProvider {
   private final VertexConsumerProvider a;
   private static final long b = 61093324083076L;
   private static final Object[] c = new Object[26];
   private static final String[] d = new String[26];
   private static volatile MethodHandle bindingCache1;

   public OutlineVertexConsumerProvider(VertexConsumerProvider var1) {
      this.a = var1;
   }

   public VertexConsumer getBuffer(RenderLayer var1) {
      VertexConsumer var7;
      Optional var27;
      label22: {
         long var10001 = 69606588472763L ^ 134650987672932L;
         int var10000 = Event.bReturningInt();
         RenderLayer var10 = var1;
         VertexConsumerProvider var9 = this.a;
         var7 = var9.getBuffer(var10);
         int var6 = var10000;
         int var29 = var6;
         RenderLayer var28 = var1;
         RenderLayer var26 = var28;
         RenderLayer var23 = var28;
         if (var29 == 0) {
            RenderLayer var11 = var23;
            boolean var30 = var11.isOutline();
            if (!var30) {
               RenderLayer var13 = var1;
               Optional var35 = var13.getAffectedOutline();
               int var32 = var6;
               Optional var31 = var35;
               var27 = var31;
               Optional var24 = var31;
               if (var32 != 0) {
                  break label22;
               }

               Optional var33 = var24;
               Optional var25 = var33;
               Optional var15 = var25;
               boolean var34 = var15.isEmpty();
               if (var34) {
                  return var7;
               }
            }

            var26 = var1;
         }

         Object[] var18 = new Object[]{var26, 76108627388639L};
         var27 = RenderLayerUtil.aReturningOptional(var18);
      }

      Optional var8 = var27;
      Function var20 = invokeBinding1(var7);
      Optional var19 = var8;
      Optional var36 = var19.map(var20);
      VertexConsumer var22 = var7;
      Optional var21 = var36;
      return ((net.minecraft.client.render.VertexConsumer)(Object)(var21.orElse(var22)));
   }

   private static VertexConsumer lambda$getBuffer$0(VertexConsumer var0, Integer var1) {
      long var10001 = 61287921403072L ^ 45984537466124L;
      Integer var6 = var1;
      int var8 = var6;
      Object[] var10004 = new Object[]{null, null, 33462774763980L};
      var10004[1] = var8;
      var10004[0] = var0;
      Object[] var7 = var10004;
      return RenderLayerUtil.aReturningVertexConsumer(var7);
   }

   static {
      aReturningVoid();
   }

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 58;
            yield var15;
         }
         case 1 -> {
            byte var16 = 56;
            yield var16;
         }
         case 2 -> {
            byte var17 = 35;
            yield var17;
         }
         case 3 -> {
            byte var18 = 15;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 8;
            yield var20;
         }
         case 6 -> {
            byte var21 = 21;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 30;
            yield var23;
         }
         case 9 -> {
            byte var24 = 16;
            yield var24;
         }
         case 10 -> {
            byte var25 = 25;
            yield var25;
         }
         case 11 -> {
            byte var26 = 20;
            yield var26;
         }
         case 12 -> {
            byte var27 = 33;
            yield var27;
         }
         case 13 -> {
            byte var28 = 42;
            yield var28;
         }
         case 14 -> {
            byte var29 = 39;
            yield var29;
         }
         case 15 -> {
            byte var30 = 38;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 32;
            yield var32;
         }
         case 18 -> {
            byte var33 = 47;
            yield var33;
         }
         case 19 -> {
            byte var34 = 50;
            yield var34;
         }
         case 20 -> {
            byte var35 = 17;
            yield var35;
         }
         case 21 -> {
            byte var36 = 2;
            yield var36;
         }
         case 22 -> {
            byte var37 = 55;
            yield var37;
         }
         case 23 -> {
            byte var38 = 37;
            yield var38;
         }
         case 24 -> {
            byte var39 = 12;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 1;
            yield var41;
         }
         case 27 -> {
            byte var42 = 52;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 40;
            yield var44;
         }
         case 30 -> {
            byte var45 = 45;
            yield var45;
         }
         case 31 -> {
            byte var46 = 41;
            yield var46;
         }
         case 32 -> {
            byte var47 = 59;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 51;
            yield var49;
         }
         case 35 -> {
            byte var50 = 53;
            yield var50;
         }
         case 36 -> {
            byte var51 = 4;
            yield var51;
         }
         case 37 -> {
            byte var52 = 3;
            yield var52;
         }
         case 38 -> {
            byte var53 = 54;
            yield var53;
         }
         case 39 -> {
            byte var54 = 44;
            yield var54;
         }
         case 40 -> {
            byte var55 = 61;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 63;
            yield var57;
         }
         case 43 -> {
            byte var58 = 49;
            yield var58;
         }
         case 44 -> {
            byte var59 = 57;
            yield var59;
         }
         case 45 -> {
            byte var60 = 7;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 48;
            yield var62;
         }
         case 48 -> {
            byte var63 = 29;
            yield var63;
         }
         case 49 -> {
            byte var64 = 24;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 46;
            yield var66;
         }
         case 52 -> {
            byte var67 = 0;
            yield var67;
         }
         case 53 -> {
            byte var68 = 10;
            yield var68;
         }
         case 54 -> {
            byte var69 = 62;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 43;
            yield var71;
         }
         case 57 -> {
            byte var72 = 11;
            yield var72;
         }
         case 58 -> {
            byte var73 = 19;
            yield var73;
         }
         case 59 -> {
            byte var74 = 28;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 13;
            yield var76;
         }
         case 62 -> {
            byte var77 = 26;
            yield var77;
         }
         default -> 18;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "\u0019&3\u0006\u0013$\u0007.)Ir!\u0007.*\t\\=";
      c[1] = "$\t\f !\n/\u0006\u001do@\u0004$\r\u00195";
      c[2] = ",[)eLQ,[>9@^6\u0010>'@K1alr\u0013\t";
      c[3] = boolean.class;
      d[3] = "java/lang/Boolean";
      c[4] = "wyaB/Fayd\u0018<Qv2g\u001e0Egup\t{WV";
      c[5] = int.class;
      d[5] = "java/lang/Integer";
      c[6] = "\u0002RK;1/\u0014RNa\"8\u0003\u0019Mg.,\u0012^Zpe<<";
      c[7] = "\u0014\"42\u0014p\u001f-%}w}\n *\u0016B\u007f\u001b36:Ur";
      c[8] = "/\u001e\f\u0006\u001e\u00119\u001e\t\\\r\u0006.U\nZ\u0001\u0012?\u0012\u001dMJ\u0002\u0012";
      c[9] = "|Uh\u000b*.\tuc\u0004;ah{h\u000f?;\u001c";
      c[10] = "Sw\u001bx\u0015\u001fM\u007f\u00017]\u001fWu\u0019pT\u0004\u0017P\u0018wX\u001ePy\u0003";
      c[11] = "D\u0003a\b\u0003-D\u0003vT\u000f\"^HvJ\u000f7Y9!\u0013Ws";
      c[12] = "9L}ID}9Lj\u0015Hr#\u0007j\u000bHg$v=R\u0011,";
      c[13] = "k^MV\u000eQ\u001e~FY\u001f\u001e\u007fpMR\u001bD\u000b";
      c[14] = "*\u001b-1y\u000b!\u0014<~\u001e\t4\u001f<5%";
      c[15] = "/\u001d`:r6\u007f\tmFd6\u0003\b\u007f+\u0003u'\nhy<5-Q}F:%(\u0000;yz/s\u0015\u0004";
      c[16] = "T\u000b\u0016\rQo\u0019\u001e\u0012[8g\u0003\t\"\n\\{\buG\u001fAg\u001cL\r\u0013@me";
      c[17] = "\u0018 \u0013*\u0005f[7\u0018 oqL-H7\u0003C\u001bm\u0012aR\u0014\u001b1O5T*@iQ*o";
      c[18] = "`V\u0010\u001aq9&\u0017L\u0016\u000e9[T\t\to*b\u001e\u0005\beS";
      c[19] = "}gh@mj-se<yyd\u00163Rbku|vLz~\u001cw}X`af'iU\u001c";
      c[20] = "4gIDfKdsD8vJ\u0018sUDf1ovJ],\u000f4.TB\u0017";
      c[21] = "[T\u0013J%;\u0018C\u0018@O,\u000fYHW#\u001eX\u001e\u0012\u0000~I\u0003TLL>3S@A0";
      c[22] = "nAX?(\u001em]_5H\u0013R\u001a\u0002d9\u00101W\u0013dvzoF]+\"\u0019\"W]dH";
      c[23] = "`\u0010\u00023[\taP@97\u000b2\u0015Y?[9`R\u0005g\bnf\u0018\u0002\"]\u001c%\u000f\t(7^9\u0006K:E\u0004`\u0017\\X";
      c[24] = "\u000e\u001emP\u0013sBI~\u001fc+0\u001fl^\u0012z\u0000\u001ea[\u001fB\u0000Hh\u0013\u00010Z\u0011y\u0004c";
      c[25] = "\r\u0012=gv\nAE.(\u0006R3\u0013<iw\u0003\u0003\u00121lz;RS3*wA\u0002G>V";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(131602165947278L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(131602165947278L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(131602165947278L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 77;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 67;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 254;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 181;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 72;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 74;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 77;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 67;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 254;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cZ_C0161",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cZ" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(VertexConsumer var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Lnet/minecraft/client/render/VertexConsumer;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cZ_C0161",
                     "lambda$getBuffer$0",
                     "(Lnet/minecraft/client/render/VertexConsumer;Ljava/lang/Integer;)Lnet/minecraft/client/render/VertexConsumer;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Lnet/minecraft/client/render/VertexConsumer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((VertexConsumer)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
