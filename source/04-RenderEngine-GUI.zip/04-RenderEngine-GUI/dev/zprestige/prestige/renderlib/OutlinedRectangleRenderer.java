package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.api.util.NumberUtil;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL20;

public class OutlinedRectangleRenderer extends PrimitiveRenderer {
   private static final OutlinedRectangleRenderer a;
   private static final Map b;
   private static final Matrix4f c;
   private static final ThreadLocal d;
   private final int e;
   private final int f;
   private static final long g = 101562774853064L;
   private static final String[] h;
   private static final String[] i;
   private static final Map j = new HashMap(13);
   private static final long[] k;
   private static final Integer[] l;
   private static final Map m;
   private static final Object[] n = new Object[90];
   private static final String[] p = new String[90];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;

   private OutlinedRectangleRenderer(long var1) {
      super("shaders/rounded_pos_color.vert", "shaders/rounded_outline_pos_color.frag", ((101562774853064L ^ (101562774853064L ^ var1)) ^ 7745435913246L));
      var1 = 101562774853064L ^ var1;
      long var3 = var1 ^ 81292546351745L;
      long var5 = var1 ^ 7745435913246L;
      short var10001 = 8152;
      long var10002 = 3598137275782180762L ^ var1;
      short var18 = 28908;
      long var10003 = 2482441939873382572L ^ var1;

      Object[] var8 = new Object[0];
      OutlinedRectangleRenderer var7 = this;
      GlProgram var16 = var7.aReturningfM_C0295(var8);
      short var19 = 10585;
      var10003 = 1298435425271978266L ^ var1;
      Object[] var10 = new Object[]{"roundness", var3};
      GlProgram var9 = var16;
      this.e = var9.dReturningInt(var10);
      Object[] var12 = new Object[0];
      OutlinedRectangleRenderer var11 = this;
      GlProgram var17 = var11.aReturningfM_C0295(var12);
      short var20 = 25524;
      var10003 = 5998746352586347509L ^ var1;
      Object[] var14 = new Object[]{"outlineThickness", var3};
      GlProgram var13 = var17;
      this.f = var13.dReturningInt(var14);
   }

   public static void aReturningVoid(Object[] var0) {
      MeshBufferManager var4 = (MeshBufferManager)var0[0];
      RenderContext var11 = (RenderContext)var0[1];
      float var10 = (Float)var0[2];
      float var5 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var9 = (Float)var0[5];
      Color var6 = (Color)var0[6];
      float var7 = (Float)var0[7];
      float var8 = (Float)var0[8];
      long var2 = (Long)var0[9];
      var2 = 101562774853064L ^ var2;
      long var12 = var2 ^ 30980547986788L;
      OutlinedRectangleRenderer var10000 = a;
      Matrix4f var10003 = c;
      int var10008 = invokeBinding1(var6, 417814146813688682L, var2);
      Vector4f var10009 = invokeBinding3((Vector4f)invokeBinding2(d, 417038548048473585L, var2), var7, 416617128219315504L, var2);
      Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, var12};
      var10013[9] = var8;
      var10013[8] = var10009;
      var10013[7] = var10008;
      var10013[6] = var9;
      var10013[5] = var1;
      var10013[4] = var5;
      var10013[3] = var10;
      var10013[2] = var10003;
      var10013[1] = var11;
      var10013[0] = var4;
      invokeBinding4(var10000, var10013, 417942078590161808L, var2);
   }

   public static void bReturningVoid(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      float var4 = (Float)var0[2];
      float var5 = (Float)var0[3];
      float var3 = (Float)var0[4];
      float var11 = (Float)var0[5];
      Color var2 = (Color)var0[6];
      Vector4f var8 = (Vector4f)var0[7];
      float var6 = (Float)var0[8];
      long var9 = (Long)var0[9];
      var9 = 101562774853064L ^ var9;
      long var12 = var9 ^ 116662007119030L;
      OutlinedRectangleRenderer var10000 = a;
      Matrix4f var10003 = c;
      int var10008 = invokeBinding5(var2, -279739981738114376L, var9);
      Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, var12};
      var10013[9] = var6;
      var10013[8] = var8;
      var10013[7] = var10008;
      var10013[6] = var11;
      var10013[5] = var3;
      var10013[4] = var5;
      var10013[3] = var4;
      var10013[2] = var10003;
      var10013[1] = var1;
      var10013[0] = var7;
      invokeBinding6(var10000, var10013, -279607815125931454L, var9);
   }

   public static void cReturningVoid(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var11 = (RenderContext)var0[1];
      Matrix4f var4 = (Matrix4f)var0[2];
      float var1 = (Float)var0[3];
      float var12 = (Float)var0[4];
      float var2 = (Float)var0[5];
      float var9 = (Float)var0[6];
      Color var3 = (Color)var0[7];
      float var10 = (Float)var0[8];
      float var8 = (Float)var0[9];
      long var5 = (Long)var0[10];
      var5 = 101562774853064L ^ var5;
      long var13 = var5 ^ 133956029171646L;
      OutlinedRectangleRenderer var10000 = a;
      Color var15 = var3;
      int var10008 = var15.getRGB();
      ThreadLocal var16 = d;
      Vector4f var10009 = (Vector4f)var16.get();
      float var18 = var10;
      Vector4f var17 = var10009;
      var10009 = var17.set(var18);
      Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, var13};
      var10013[9] = var8;
      var10013[8] = var10009;
      var10013[7] = var10008;
      var10013[6] = var9;
      var10013[5] = var2;
      var10013[4] = var12;
      var10013[3] = var1;
      var10013[2] = var4;
      var10013[1] = var11;
      var10013[0] = var7;
      Object[] var20 = var10013;
      OutlinedRectangleRenderer var19 = var10000;
      var19.eReturningVoid(var20);
   }

   public static void dReturningVoid(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var4 = (RenderContext)var0[1];
      Matrix4f var8 = (Matrix4f)var0[2];
      float var7 = (Float)var0[3];
      float var12 = (Float)var0[4];
      float var9 = (Float)var0[5];
      float var11 = (Float)var0[6];
      Color var3 = (Color)var0[7];
      Vector4f var5 = (Vector4f)var0[8];
      float var6 = (Float)var0[9];
      long var1 = (Long)var0[10];
      var1 = 101562774853064L ^ var1;
      long var13 = var1 ^ 60196236479994L;
      OutlinedRectangleRenderer var10000 = a;
      int var10008 = invokeBinding7(var3, 959958665718297588L, var1);
      Object[] var10013 = new Object[]{null, null, null, null, null, null, null, null, null, null, var13};
      var10013[9] = var6;
      var10013[8] = var5;
      var10013[7] = var10008;
      var10013[6] = var11;
      var10013[5] = var9;
      var10013[4] = var12;
      var10013[3] = var7;
      var10013[2] = var8;
      var10013[1] = var4;
      var10013[0] = var10;
      invokeBinding8(var10000, var10013, 960109537443584782L, var1);
   }

   private void eReturningVoid(Object[] var1) {
      Matrix4f var11 = (Matrix4f)var1[2];
      float var8 = (Float)var1[3];
      float var6 = (Float)var1[4];
      float var12 = (Float)var1[5];
      float var9 = (Float)var1[6];
      int var10 = (Integer)var1[7];
      Vector4f var5 = (Vector4f)var1[8];
      float var7 = (Float)var1[9];
      long var3 = (Long)var1[10];
      var3 = 101562774853064L ^ var3;
      long var14 = var3 ^ 6461103856299L;
      long var16 = var3 ^ 39986887869336L;
      long var18 = var3 ^ 79566978436343L;
      Object[] var10005 = new Object[]{null, null, var16};
      var10005[1] = var7;
      var10005[0] = var5;
      Object[] var27 = var10005;
      OutlinedRectangleRenderer var26 = this;
      DrawPipeline var20 = var26.aReturningdn_C0192(var27);
      Vector4f var28 = var5;
      float var21 = var28.x;
      Vector4f var29 = var5;
      float var22 = var29.y;
      Vector4f var30 = var5;
      float var23 = var30.z;
      Vector4f var31 = var5;
      float var24 = var31.w;
      float var25 = var7;
      Object[] var32 = new Object[]{var18};
      RenderCommandBatcher var10000 = ShapeRenderer.aReturningf4(var32);
      Object[] var34 = new Object[]{new PipelineRenderCommand(var20, invokeBinding9(var10, var21, var22, var23, var24, var25, var12, var9, var11, var8, var6)), var14};
      RenderCommandBatcher var33 = var10000;
      var33.bReturningVoid(var34);
   }

   private static void fReturningVoid(Object[] var0) {
      MeshDataConsumer var4 = (MeshDataConsumer)var0[0];
      Matrix4f var10 = (Matrix4f)var0[1];
      float var14 = (Float)var0[2];
      int var3 = (Integer)var0[3];
      float var2 = (Float)var0[4];
      float var12 = (Float)var0[5];
      float var13 = (Float)var0[6];
      float var16 = (Float)var0[7];
      float var1 = (Float)var0[8];
      float var8 = (Float)var0[9];
      float var9 = (Float)var0[10];
      float var15 = (Float)var0[11];
      float var11 = (Float)var0[12];
      float var5 = (Float)var0[13];
      long var6 = (Long)var0[14];
      var6 = 101562774853064L ^ var6;
      long var17 = var6 ^ 19397268465019L;
      long var19 = var6 ^ 16241919540982L;
      long var21 = var6 ^ 116118472795515L;
      float var10003 = var16 + var8;
      Object[] var10007 = new Object[]{null, null, null, null, var17};
      var10007[3] = var14;
      var10007[2] = var10003;
      var10007[1] = var13;
      var10007[0] = var10;
      Object[] var24 = var10007;
      MeshDataConsumer var23 = var4;
      MeshDataConsumer var10000 = var23.dReturningMeshDataConsumer(var24);
      Object[] var26 = new Object[]{new float[]{var9, var15}, var21};
      MeshDataConsumer var25 = var10000;
      var10000 = var25.bReturningMeshDataConsumer(var26);
      Object[] var28 = new Object[]{new float[]{var2, var12}, var21};
      MeshDataConsumer var27 = var10000;
      var10000 = var27.bReturningMeshDataConsumer(var28);
      Object[] var10004 = new Object[]{null, var19};
      var10004[0] = var3;
      Object[] var30 = var10004;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.eReturningMeshDataConsumer(var30);
      float var10002 = var13 + var1;
      var10003 = var16 + var8;
      var10007 = new Object[]{null, null, null, null, var17};
      var10007[3] = var14;
      var10007[2] = var10003;
      var10007[1] = var10002;
      var10007[0] = var10;
      Object[] var32 = var10007;
      MeshDataConsumer var31 = var10000;
      var10000 = var31.dReturningMeshDataConsumer(var32);
      Object[] var34 = new Object[]{new float[]{var11, var15}, var21};
      MeshDataConsumer var33 = var10000;
      var10000 = var33.bReturningMeshDataConsumer(var34);
      Object[] var36 = new Object[]{new float[]{var2, var12}, var21};
      MeshDataConsumer var35 = var10000;
      var10000 = var35.bReturningMeshDataConsumer(var36);
      var10004 = new Object[]{null, var19};
      var10004[0] = var3;
      Object[] var38 = var10004;
      MeshDataConsumer var37 = var10000;
      var10000 = var37.eReturningMeshDataConsumer(var38);
      var10002 = var13 + var1;
      var10007 = new Object[]{null, null, null, null, var17};
      var10007[3] = var14;
      var10007[2] = var16;
      var10007[1] = var10002;
      var10007[0] = var10;
      Object[] var40 = var10007;
      MeshDataConsumer var39 = var10000;
      var10000 = var39.dReturningMeshDataConsumer(var40);
      Object[] var42 = new Object[]{new float[]{var11, var5}, var21};
      MeshDataConsumer var41 = var10000;
      var10000 = var41.bReturningMeshDataConsumer(var42);
      Object[] var44 = new Object[]{new float[]{var2, var12}, var21};
      MeshDataConsumer var43 = var10000;
      var10000 = var43.bReturningMeshDataConsumer(var44);
      var10004 = new Object[]{null, var19};
      var10004[0] = var3;
      Object[] var46 = var10004;
      MeshDataConsumer var45 = var10000;
      var10000 = var45.eReturningMeshDataConsumer(var46);
      var10007 = new Object[]{null, null, null, null, var17};
      var10007[3] = var14;
      var10007[2] = var16;
      var10007[1] = var13;
      var10007[0] = var10;
      Object[] var48 = var10007;
      MeshDataConsumer var47 = var10000;
      var10000 = var47.dReturningMeshDataConsumer(var48);
      Object[] var50 = new Object[]{new float[]{var9, var5}, var21};
      MeshDataConsumer var49 = var10000;
      var10000 = var49.bReturningMeshDataConsumer(var50);
      Object[] var52 = new Object[]{new float[]{var2, var12}, var21};
      MeshDataConsumer var51 = var10000;
      var10000 = var51.bReturningMeshDataConsumer(var52);
      var10004 = new Object[]{null, var19};
      var10004[0] = var3;
      Object[] var54 = var10004;
      MeshDataConsumer var53 = var10000;
      var53.eReturningMeshDataConsumer(var54);
   }

   protected DrawPipeline aReturningdn_C0192(Object[] var1) {
      Vector4f var2 = (Vector4f)var1[0];
      float var3 = (Float)var1[1];
      long var4 = (Long)var1[2];
      var4 = 101562774853064L ^ var4;
      long var6 = var4 ^ 18192547811653L;
      long var8 = var4 ^ 73847249545270L;
      Object[] var13 = new Object[]{var2, var8};
      RoundedCornerStyle var11 = new RoundedCornerStyle(NumberUtil.aReturningVector4f(var13), var3);
      int var10000 = Event.cReturningInt();
      RoundedCornerStyle var15 = var11;
      Map var14 = b;
      DrawPipeline var12 = (DrawPipeline)var14.get(var15);
      int var10 = var10000;
      int var30 = var10;
      DrawPipeline var29 = var12;
      DrawPipeline var28 = var29;
      DrawPipeline var27 = var29;
      if (var30 != 0) {
         DrawPipeline var31 = var27;
         if (var31 == null) {
            VertexFormat var10002 = VertexFormats.e;
            short var10005 = 21935;
            long var10006 = 8547366491664257189L ^ var4;
            RenderState[] var33 = new RenderState[]{RenderState.a, null, null, null, null, null};
            Object[] var18 = new Object[0];
            OutlinedRectangleRenderer var17 = this;
            Object[] var19 = new Object[]{var17.aReturningfM_C0295(var18)};
            var33[1] = RenderState.aReturninggH_C0339(var19);
            short var10008 = 1638;
            long var10009 = 1412924525862437742L ^ var4;
            Object[] var10011 = new Object[]{null, true};
            var10011[0] = 2884;
            Object[] var20 = var10011;
            var33[2] = RenderState.aReturninggF_C0335(var20);
            var10011 = new Object[]{null, true};
            var10011[0] = true;
            Object[] var21 = var10011;
            var33[3] = RenderState.aReturninggI_C0341(var21);
            var10008 = 14220;
            var10009 = 6831928465667748487L ^ var4;
            short var36 = 23629;
            long var10010 = 8512715256351889732L ^ var4;
            var10011 = new Object[]{null, 515};
            var10011[0] = 515;
            Object[] var22 = var10011;
            var33[4] = RenderState.aReturninggD_C0331(var22);
            Object[] var23 = new Object[]{invokeBinding10(this, var11)};
            var33[5] = RenderState.aReturningfP_C0301(var23);
            var12 = new DrawPipeline(var10002, 4, false, var33, var6);
            DrawPipeline var26 = var12;
            RoundedCornerStyle var25 = var11;
            Map var24 = b;
            var24.put(var25, var26);
         }

         var28 = var12;
      }

      return var28;
   }

   private void lambda$getRenderLayer$1(RoundedCornerStyle var1, RenderPass var2) {
      int var10000 = this.e;
      RoundedCornerStyle var5 = var1;
      Vector4f var6 = var5.br();
      float var10001 = var6.x;
      RoundedCornerStyle var7 = var1;
      Vector4f var8 = var7.br();
      float var10002 = var8.y;
      RoundedCornerStyle var9 = var1;
      Vector4f var10 = var9.br();
      float var10003 = var10.z;
      RoundedCornerStyle var11 = var1;
      Vector4f var12 = var11.br();
      float var17 = var12.w;
      float var16 = var10003;
      float var15 = var10002;
      float var14 = var10001;
      int var13 = var10000;
      GL20.glUniform4f(var13, var14, var15, var16, var17);
      var10000 = this.f;
      RoundedCornerStyle var18 = var1;
      float var20 = var18.bs();
      int var19 = var10000;
      GL20.glUniform1f(var19, var20);
   }

   private static void lambda$drawInternal$0(
      int var0,
      float var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      Matrix4f var8,
      float var9,
      float var10,
      Float var11,
      MeshDataConsumer var12
   ) {
      label17: {
         long var10001 = 13945939197719L ^ 7841195392941L;
         var10001 = 13945939197719L ^ 331177513912L;
         var10001 = 13945939197719L ^ 75283016752380L;
         var10001 = 13945939197719L ^ 13555200068862L;
         var10001 = 13945939197719L ^ 122963126276429L;
         int var10000 = Event.bReturningInt();
         Object[] var10004 = new Object[]{null, 109378316676698L};
         var10004[0] = var0;
         Object[] var29 = var10004;
         int var26 = ShapeRenderer.bReturningInt(var29);
         float var31 = var2;
         float var30 = var1;
         float var66 = Math.max(var30, var31);
         float var33 = var4;
         float var32 = var3;
         float var35 = Math.max(var32, var33);
         float var34 = var66;
         float var27 = Math.max(var34, var35);
         int var25 = var10000;
         float var28 = 2.0F * var5 + var27 + 2.0F;
         Object[] var37 = new Object[]{12707221340346L};
         MeshDataConsumer var36 = var12;
         var36.kReturningVoid(var37);
         int var57 = var25;
         if (var57 == 0) {
            float var60 = var28 * 2.0F;
            float var39 = var7;
            float var38 = var6;
            float var79;
            int var58 = (var79 = var60 - Math.min(var38, var39)) == 0.0F ? 0 : (var79 < 0.0F ? -1 : 1);
            if (var58 >= 0) {
               Float var41 = var11;
               float var10002 = var41;
               Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, 14165095197871L};
               var10016[13] = var7;
               var10016[12] = var6;
               var10016[11] = 0.0F;
               var10016[10] = 0.0F;
               var10016[9] = var7;
               var10016[8] = var6;
               var10016[7] = var10;
               var10016[6] = var9;
               var10016[5] = var7;
               var10016[4] = var6;
               var10016[3] = var26;
               var10016[2] = var10002;
               var10016[1] = var8;
               var10016[0] = var12;
               Object[] var42 = var10016;
               fReturningVoid(var42);
               int var59 = var25;
               if (var59 == 0) {
                  break label17;
               }
            }

            Float var44 = var11;
            float var67 = var44;
            float var10011 = var7 - var28;
            Object[] var75 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, 14165095197871L};
            var75[13] = var7;
            var75[12] = var6;
            var75[11] = var10011;
            var75[10] = 0.0F;
            var75[9] = var28;
            var75[8] = var6;
            var75[7] = var10;
            var75[6] = var9;
            var75[5] = var7;
            var75[4] = var6;
            var75[3] = var26;
            var75[2] = var67;
            var75[1] = var8;
            var75[0] = var12;
            Object[] var45 = var75;
            fReturningVoid(var45);
            Float var46 = var11;
            var67 = var46;
            float var10007 = var10 + var7 - var28;
            var75 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, 14165095197871L};
            var75[13] = var28;
            var75[12] = var6;
            var75[11] = 0.0F;
            var75[10] = 0.0F;
            var75[9] = var28;
            var75[8] = var6;
            var75[7] = var10007;
            var75[6] = var9;
            var75[5] = var7;
            var75[4] = var6;
            var75[3] = var26;
            var75[2] = var67;
            var75[1] = var8;
            var75[0] = var12;
            Object[] var47 = var75;
            fReturningVoid(var47);
            Float var48 = var11;
            var67 = var48;
            var10007 = var10 + var28;
            float var10009 = var7 - 2.0F * var28;
            float var10013 = var7 - var28;
            var75 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, 14165095197871L};
            var75[13] = var10013;
            var75[12] = var28;
            var75[11] = var28;
            var75[10] = 0.0F;
            var75[9] = var10009;
            var75[8] = var28;
            var75[7] = var10007;
            var75[6] = var9;
            var75[5] = var7;
            var75[4] = var6;
            var75[3] = var26;
            var75[2] = var67;
            var75[1] = var8;
            var75[0] = var12;
            Object[] var49 = var75;
            fReturningVoid(var49);
         }

         Float var51 = var11;
         float var70 = var51;
         float var10006 = var9 + var6 - var28;
         float var72 = var10 + var28;
         float var73 = var7 - 2.0F * var28;
         float var10010 = var6 - var28;
         float var74 = var7 - var28;
         Object[] var78 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, 14165095197871L};
         var78[13] = var74;
         var78[12] = var6;
         var78[11] = var28;
         var78[10] = var10010;
         var78[9] = var73;
         var78[8] = var28;
         var78[7] = var72;
         var78[6] = var10006;
         var78[5] = var7;
         var78[4] = var6;
         var78[3] = var26;
         var78[2] = var70;
         var78[1] = var8;
         var78[0] = var12;
         Object[] var52 = var78;
         fReturningVoid(var52);
      }

      Object[] var54 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var53 = var12;
      MeshDataConsumer var61 = var53.iReturningVoid(var54);
      Object[] var56 = new Object[]{80089257141227L};
      MeshDataConsumer var55 = var61;
      var55.hReturningMeshDataConsumer(var56);
   }

   static {

      {

      long var10001 = 20809999522207L ^ 76560842566003L;
      var10001 = 20809999522207L ^ 6338867775113L;
      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(20809999522207L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[4];
      String var15 = "\u00ad£\n¶j\u0099\bêJDÄ¶Ê\u000fÑí\u008b8ð¡ªöóýÊ\u0080Ê\u0093ç,\u000fÒ8ç¡Nó\u0091ÉwrÉ|\nQ\u0094Ü¯\r<\u0011Q{\u0014\u0099ª¹\u0097ô\n\t\u0080/¥^Â\r\u0098A#G\u0005\u001a´\u0015W\n\u0006|e¯£\u0085\u009eµïU¨:";
      int var17 = "\u00ad£\n¶j\u0099\bêJDÄ¶Ê\u000fÑí\u008b8ð¡ªöóýÊ\u0080Ê\u0093ç,\u000fÒ8ç¡Nó\u0091ÉwrÉ|\nQ\u0094Ü¯\r<\u0011Q{\u0014\u0099ª¹\u0097ô\n\t\u0080/¥^Â\r\u0098A#G\u0005\u001a´\u0015W\n\u0006|e¯£\u0085\u009eµïU¨:"
         .length();
      char var14 = ' ';
      int var30 = -1;

      label54:
      while (true) {
         String var31 = var15.substring(++var30, var30 + var14);
         
            byte[] var19 = var11.doFinal(var31.getBytes("ISO-8859-1"));
            String var46 = a(var19).intern();
            switch (var37) {
               case 0:
                  var18[var16++] = var46;
                  if ((var30 += var14) >= var17) {
                     h = var18;
                     i = new String[4];
                     m = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(20809999522207L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[5];
                     String var4 = "\u0096\u001e7À\u009dÜ\b\u0085¼9ã\u0084\u008c\u0084·;\u00812?ýY\t\u0087Å";
                     int var5 = "\u0096\u001e7À\u009dÜ\b\u0085¼9ã\u0084\u008c\u0084·;\u00812?ýY\t\u0087Å".length();
                     label36:
                     while (true) {
                        int var41 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var41, var2).getBytes("ISO-8859-1");
                        long[] var34 = var6;
                        int var42 = var3++;
                        long var50 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var50;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var56 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var53) {
                              case 0:
                                 var34[var42] = var56;
                                 if (var2 >= var5) {
                                    k = var6;
                                    l = new Integer[5];
                                    a = new OutlinedRectangleRenderer(95986100875500L);
                                    short var35 = 9527;
                                    var10001 = 322457964028814108L;
                                    Object[] var55 = new Object[]{null, 25489915207446L};
                                    var55[0] = 128;
                                    Object[] var26 = var55;
                                    b = NumberUtil.aReturningMap(var26);
                                    c = new Matrix4f();
                                    Supplier var27 = invokeBinding11();
                                    d = ThreadLocal.withInitial(var27);
                                    break;
                                 }
                                 break;
                              default:
                                 var34[var42] = var56;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u008bú+\u0018çj\n\u0010\u00ad }A´¨A\u0011";
                                 var5 = "\u008bú+\u0018çj\n\u0010\u00ad }A´¨A\u0011".length();
                                 var2 = 0;
                           }

                           int var43 = var2;
                           var2 += 8;
                           var7 = var4.substring(var43, var2).getBytes("ISO-8859-1");
                           var34 = var6;
                           var42 = var3++;
                           var50 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var53 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var30);
                  break;
               default:
                  var18[var16++] = var46;
                  if ((var30 += var14) < var17) {
                     var14 = var15.charAt(var30);
                     continue label54;
                  }

                  var15 = "Ï÷Àe;\u009cy13:·\u0099Ö\u0010\u008f£B/\u0003ua%\u001eØc\u007fr\u001d\u0005\u0080\u0089sOö{uÑ¬è9@OÃØéó´Å9ó \u000e8Ø(\u001d{-°ezå\u0091\u009f\u0001©À\u0014>\u0081cI}já°Ýèl0PõÑ[rß\u001b~[¬6èÆ\u008a\u0086*5gnîÑZË\u0082¢";
                  var17 = "Ï÷Àe;\u009cy13:·\u0099Ö\u0010\u008f£B/\u0003ua%\u001eØc\u007fr\u001d\u0005\u0080\u0089sOö{uÑ¬è9@OÃØéó´Å9ó \u000e8Ø(\u001d{-°ezå\u0091\u009f\u0001©À\u0014>\u0081cI}já°Ýèl0PõÑ[rß\u001b~[¬6èÆ\u008a\u0086*5gnîÑZË\u0082¢"
                     .length();
                  var14 = '(';
                  var30 = -1;
            }

            var31 = var15.substring(++var30, var30 + var14);
            var37 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 5479;
      if (i[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])j.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/de", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = h[var5].getBytes("ISO-8859-1");
         i[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return i[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/de_C0174",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/de" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 17967;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])m.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/de", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/de_C0174",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/de" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = n[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 61;
            yield var15;
         }
         case 1 -> {
            byte var16 = 53;
            yield var16;
         }
         case 2 -> {
            byte var17 = 9;
            yield var17;
         }
         case 3 -> {
            byte var18 = 63;
            yield var18;
         }
         case 4 -> {
            byte var19 = 38;
            yield var19;
         }
         case 5 -> {
            byte var20 = 25;
            yield var20;
         }
         case 6 -> {
            byte var21 = 59;
            yield var21;
         }
         case 7 -> {
            byte var22 = 60;
            yield var22;
         }
         case 8 -> {
            byte var23 = 29;
            yield var23;
         }
         case 9 -> {
            byte var24 = 1;
            yield var24;
         }
         case 10 -> {
            byte var25 = 24;
            yield var25;
         }
         case 11 -> {
            byte var26 = 46;
            yield var26;
         }
         case 12 -> {
            byte var27 = 51;
            yield var27;
         }
         case 13 -> {
            byte var28 = 7;
            yield var28;
         }
         case 14 -> {
            byte var29 = 8;
            yield var29;
         }
         case 15 -> {
            byte var30 = 4;
            yield var30;
         }
         case 16 -> {
            byte var31 = 30;
            yield var31;
         }
         case 17 -> {
            byte var32 = 49;
            yield var32;
         }
         case 18 -> {
            byte var33 = 19;
            yield var33;
         }
         case 19 -> {
            byte var34 = 31;
            yield var34;
         }
         case 20 -> {
            byte var35 = 62;
            yield var35;
         }
         case 21 -> {
            byte var36 = 0;
            yield var36;
         }
         case 22 -> {
            byte var37 = 28;
            yield var37;
         }
         case 23 -> {
            byte var38 = 5;
            yield var38;
         }
         case 24 -> {
            byte var39 = 44;
            yield var39;
         }
         case 25 -> {
            byte var40 = 27;
            yield var40;
         }
         case 26 -> {
            byte var41 = 3;
            yield var41;
         }
         case 27 -> {
            byte var42 = 40;
            yield var42;
         }
         case 28 -> {
            byte var43 = 11;
            yield var43;
         }
         case 29 -> {
            byte var44 = 12;
            yield var44;
         }
         case 30 -> {
            byte var45 = 33;
            yield var45;
         }
         case 31 -> {
            byte var46 = 42;
            yield var46;
         }
         case 32 -> {
            byte var47 = 15;
            yield var47;
         }
         case 33 -> {
            byte var48 = 34;
            yield var48;
         }
         case 34 -> {
            byte var49 = 50;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 55;
            yield var51;
         }
         case 37 -> {
            byte var52 = 6;
            yield var52;
         }
         case 38 -> {
            byte var53 = 2;
            yield var53;
         }
         case 39 -> {
            byte var54 = 17;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 39;
            yield var57;
         }
         case 43 -> {
            byte var58 = 57;
            yield var58;
         }
         case 44 -> {
            byte var59 = 32;
            yield var59;
         }
         case 45 -> {
            byte var60 = 45;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 41;
            yield var62;
         }
         case 48 -> {
            byte var63 = 26;
            yield var63;
         }
         case 49 -> {
            byte var64 = 21;
            yield var64;
         }
         case 50 -> {
            byte var65 = 20;
            yield var65;
         }
         case 51 -> {
            byte var66 = 54;
            yield var66;
         }
         case 52 -> {
            byte var67 = 56;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 14;
            yield var69;
         }
         case 55 -> {
            byte var70 = 36;
            yield var70;
         }
         case 56 -> {
            byte var71 = 18;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 37;
            yield var73;
         }
         case 59 -> {
            byte var74 = 47;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 48;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      n[0] = "b7\u000bBJ\u0015\u007f\"S`\u000b\u0018g$";
      n[1] = int.class;
      p[1] = "java/lang/Integer";
      n[2] = "xL\u0004T2%nL\u0001\u000e!2y\u0007\u0002\b-&h@\u0015\u001ff1y";
      n[3] = "p9|6>.\u0005\u0019w9/ad\u0017|2+;\u0010";
      n[4] = void.class;
      p[4] = "java/lang/Void";
      n[5] = "0J\u0015\u0001r';E\u0004N\u0011*.H\u000b%$(?[\u0017\t3%";
      n[6] = "{Mz&BrmM\u007f|Qez\u0006|z]qkAkm\u0016cZ";
      n[7] = "+O\u0007Mc\b @\u0016\u0002\u0000\u00055F";
      n[8] = float.class;
      p[8] = "java/lang/Float";
      n[9] = "DU-{HYRU(![NE\u001e+'WZTY<0\u001cJc";
      n[10] = "2{\u0013fNiG[\u0018i_&&U\u0013b[|R";
      n[11] = "'bOo; RBD`*o3LOk.5G";
      n[12] = "t%[\"\u0007&\u0001\u0005P-\u0016i`\u000b[&\u00123\u0014";
      n[13] = "S5\rHYkE5\b\u0012J|R~\u000b\u0014FhC9\u001c\u0003\r\u007fA";
      n[14] = "VUg6&/#ul97`B{g23:6";
      n[15] = "CzdzP-Huu58-Fzf";
      n[16] = "\"'m!@MW\u0007f.Q\u00026\tm%UXB";
      n[17] = "o\u0003)}\u0011\\y\u0003,'\u0002KnH/!\u000e_\u007f\u000f86EJ>";
      n[18] = "t\u0003u'\u000b5\u0001#~(\u001az`-u#\u001e \u0014";
      n[19] = "\u007fK3X\u001a{aC)\u0017yoe";
      n[20] = "$\u001b\u001f\u000f\t\u001e/\u0014\u000e@s\u001a<\u001f\b\nk\u001d-\u001b\u0005";
      n[21] = "HlB{\u001f|VdX4W|Ln@s^g\f^AjAeKhF";
      n[22] = "Sn;ZM\u000eEn>\u0000^\u0019R%=\u0006R\rCb*\u0011\u0019\u0018g";
      n[23] = "{\u0004i]`V\u000e$bRq\u0019o*iYuC\u001b";
      n[24] = "Z\u0006AhX~L\u0006D2Ki[MG4G}J\nP#\fiz";
      n[25] = "\u0006'RW\u0013^\u0010'W\r\u0000I\u0007lT\u000b\f]\u0016+C\u001cGMZ";
      n[26] = "vfooFi\u0003Fd`W&bHokS|\u0016";
      n[27] = "M\u001d\u001d'qL[\u001d\u0018}b[LV\u001b{nO]\u0011\fl%Zd";
      n[28] = "H\u0004=:(_=$659\u0010\\*=>=J(";
      n[29] = "\u000e\u0019O%6v{9D*'9\u001a7O!#cn";
      n[30] = "\u0002\u00046\u0014O\u0014\u0014\u00043N\\\u0003\u0003O0HP\u0017\u0012\b'_\u001b\u0003 ";
      n[31] = "B6p}\u000077\u0016{r\u0011xV\u0018py\u0015\"\"";
      n[32] = "W5!\u000e[yU+hvTuL(4\u0014W";
      n[33] = "#d6V$\u0002(k'\u0019E\f#`#C";
      n[34] = "zEv\u000e\"q\u000fe}\u00013>nkv\n7d\u001a";
      n[35] = "Pa`V\u0001CFae\f\u0012TQ*f\n\u001e@@mq\u001dUT}";
      n[36] = "\u000fR\u0005\u0012bfzr\u000e\u001ds)\u001b|\u0005\u0016wso";
      n[37] = "\u0010\u0014\u00181;\u0001\u0006\u0014\u001dk(\u0016\u0011_\u001em$\u0002\u0000\u0018\tzo\u0016<";
      n[38] = "X.\u001dmIq-\u000e\u0016bX>L\u0000\u001di\\d8";
      n[39] = "Rhhp-)W}cp..Xth2o\u0019q(?";
      n[40] = "\u0002\u000f\u000e\r\u0004\f\u0014\u000f\u000bW\u0017\u001b\u0003D\bQ\u001b\u000f\u0012\u0003\u001fFP\u001b$";
      n[41] = "tRU$I\u0010\u0001r^+X_`|U \\\u0005\u0014";
      n[42] = "J^gIc\u0010?~lFr_^pgMv\u0005*";
      n[43] = "\u0018k'Ku,mK,Ddc\fE'O`9x";
      n[44] = "V\u0014n%/e@\u0014k\u007f<rW_hy0fF\u0018\u007fn{s\u0006";
      n[45] = "MZ'5\u007fO8z,:n\u0000Yt'1jZ-";
      n[46] = ".pXJ\u0005\u0011[PSE\u0014^:^XN\u0010\u0004N";
      n[47] = "?fa{p)JFjtaf+Ha\u007fe<_";
      n[48] = "R.b1\u0000\u001dD.gk\u0013\nSedm\u001f\u001eB\"szT\tX";
      n[49] = "\b\u0012!\"rUSG{#\u0011\u00026\u0007`1h\u000f]\u001dz+/o\b\u0012!\"rUSG{#\u0011";
      n[50] = "j\b*f\u0003wj\u0007'zqp\u0017\u00111v\bz|\u000b+lO\u001a,\u0004\"#\u0011u|Pt#q";
      n[51] = "lX}GeFxFaZ^\u0014\u0002DgS'\u001di^}I`}mC{H8\u0016eP \u0007^";
      n[52] = "\u0011\u0007W,AyP\u0006Xl$|-\u0011\u0011;\u0014rC\u0012\u0015h$";
      n[53] = "g~D\u0015\\+<+\u001e\u0014?pYk\u0005\u0006Fq2q\u001f\u001c\u0001\u0011g~D\u0015\\+<+\u001e\u0014?";
      n[54] = "?dNcy\\mb]5\u0002Ec>>1;N2=\u0007r>\\xX\u00006l\u0010gaC3~Z\u0002f\u0007a2E;%\u0002sx ";
      n[55] = "uX}Q\u007f\u0003.\r'P\u001cZKM<BeY W&X\"9uX}Q\u007f\u0003.\r'P\u001c";
      n[56] = "\n\u00143}P=\u0011\f;j9+\u0014)1uW#\n\u0011kz9>I\u001fgpW=MLW*\u0000*@\u0011ni\u00058\nti-Wt\u0015M*(E>pJnz\t!I\tkhCDNM9$\\}\rH+n9\u007f\u001a\u001fitV/NIi\u0014";
      n[57] = "]f(Y\fx\u001cg'\u0019i|apnNYs\u000fsj\u001di";
      n[58] = "z\u0002\u0007\u0016j@e\u0007\fB\f\u000e\u001fSOH<\u001b&\u0010JZv";
      n[59] = "ri&ztlfw:gO>\u001cu<n67wo&tqWri&ztlfw:gO";
      n[60] = "g:\u0000P\u0013Ls6\u0005\u0019\u007f\u001df \u007fFF\u001dv`\u0010Z\u000f\f3\\\u0019\u0019\u0010\u000f73\u0005P\u0001J\u000b";
      n[61] = " \u00078*8%4\u0019$7\u0003wN\u001b\">z~%\u00018$=\u001e)U(<o ,\u001ek-\u0003";
      n[62] = "6k\bD\u007f~=oCO\u0015u]{JIl|6aPS+\u001c1bMRy\"%nH\u001b\u0015";
      n[63] = "\u0015d5eJ_N1od)\u000f+qtvP\u0005@knl\u0017e\u0015d5eJ_N1od)";
      n[64] = "\u000e\u001344 kE\u0012?8K1\u000fn:0%k\u0011Wy57!t";
      n[65] = "\t)\bekgJvRzZb09Oo#k[#Uud\u000b@*\t~;lNx[>Z";
      n[66] = "L\u001b\u0012\r'sX\u0005\u000e\u0010\u001c!\"\u0007\b\u0019e(I\u001d\u0012\u0003\"H[GN\u0013x/\u001a\u001fOJ\u001c";
      n[67] = "\u007f\u0013?{.wh\u0013j|J}\u007f\r\u000e{s}oMag:l*q";
      n[68] = "\u0011O\r=\u001f\u0005R\u0010W\".\u0000(\u001c\u000eaW\u0019DZ\u000ffRi\u0014\u001c\u000f%^\u0005R\u001d\b .";
      n[69] = "\bD/P\u001b{\u0017A$\u0004}>\u0000W^^D+]Ng\u001dA9\u0017+;\u000f\fu\u000b\u0015$\n\u0007!m";
      n[70] = "p\u0012\u0015\u001e\u0003#o\u0017\u001eJeb\u0015C]@Ux,\u0000XR\u001f";
      n[71] = "'H6M~lj]$E\u0001n\u0016[?Hxg}A%R?\u0007kB$XsjkM)D\u0001";
      n[72] = "ko\"(T pw*?=6uR  S>kj\u007f/=#(dv%S ,7F\u007f\u00047!j\u007f<\u0001%k\u000f}+Vgq`-\u007f\u0000g\u0011";
      n[73] = "mnz5M*?hic639\"\ng\u000f8`73$\n**R4`Xf5kweJ,Pl37\u00063i/6%LV";
      n[74] = "\u0013J\u0012\u001a.W\u000bXIFTEs_\u000e\u0015-L\u0018E\u0014\u000fj,\u0011\u0011JE%^\u000fF\u0014ET";
      n[75] = ":`=b8\u0010a5gc[J\u0004u|q\"Joofke*:`=b8\u0010a5gc[";
      n[76] = "]-Wq3-\u00108EyL,l>^t5&\u0007$DnrF\u0016xM/((\u0015|\u001e\u001f";
      n[77] = "\u001a-\\xZm\u000e3@ea?t1Fl\u00186\u001f+\\v_V\u0010\u007fC9[3\u00123Wca";
      n[78] = "^w\u00124 \u0015UsY?J\u001e5gP93\u0017^}J#twPwYb,IOrR6J";
      n[79] = "]`\u001d0I\\\u0004j\u0017>)\u0002Pc\u00172w\u0005Py\u0013N\u0017UZ4\u001bwTPH~~";
      n[80] = "W'R0m\u0007H\"Yd\u000bK2v\u001an;\\\u000b5\u001f|q";
      n[81] = "\u0007Vv-[8\u0010V#*?\"\u000bH'\nY<\u0016U./?0\u0018I8$R?\u0006S<KR?[R#.E?\u000eUG";
      n[82] = "W\u000e-\bjkIYs\b\u001bu5@iXby^ZsB%\u0019O\u0006z\u0003\u007fwL\u0002)3";
      n[83] = "5iO'Hs*lDs.<P8\u0007y\u001e(i{\u0002kT";
      n[84] = "\b.)\u00190MR\"m~%\u001d\u0014\b_4J\nQ9 \u001a$\tUj\u0010";
      n[85] = "-dbay\u001ffeim\u0012E-\u001973c\u001f1'(6hKW";
      n[86] = "\u0018\u0012\u0012pLv[MHo}w!\u0002Uz\u0004zJ\u0018O`C\u001a\u001a\u0017F/\u001duJC\u0010/}";
      n[87] = "NK\u0015\u0011\t'ZG\u0010Xea_Qj\u0007\\v_\u0011\u0005\u001b\u0015g\u001a-\fX\nd\u001eB\u0010\u0011\u001b!\"KS\u000e\u0018%MW\u001a\u001f]\u0019";
      n[88] = "\u000b\u0011xz_PHN\"enR2\u0001?p\u0017\\Y\u001b%jP<\t\u0014,%\u000eSY@z%n";
      n[89] = "\u001etF\u0006),E!\u001c\u0007Jz a\u0007\u00153vK{\u001d\u000ft\u0016\u001etF\u0006),E!\u001c\u0007J";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = n[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = n[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            n[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  n[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(2340019513418796L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = n[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  n[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(2340019513418796L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        n[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(2340019513418796L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 186;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 117;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 210;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 231;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 229;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 233;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 186;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 117;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 210;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/de_C0174",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/de" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Object invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Vector4f invokeBinding3(Object var0, float var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = c(
                  MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;FJJ)Lorg/joml/Vector4f;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Vector4f)var7.invokeExact((Object)var0, (float)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = c(MethodHandles.lookup(), "å", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiConsumer invokeBinding9(
      int var0, float var1, float var2, float var3, float var4, float var5, float var6, float var7, Matrix4f var8, float var9, float var10
   ) {
         MethodHandle var15 = bindingCache9;
         MethodHandle var14 = bindingCache9;
         MethodHandle var12 = var14;
         if (var15 == null) {
            var12 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(IFFFFFFFLorg/joml/Matrix4f;FF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/de_C0174",
                     "lambda$drawInternal$0",
                     "(IFFFFFFFLorg/joml/Matrix4f;FFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var12.invokeExact((int)var0, (float)var1, (float)var2, (float)var3, (float)var4, (float)var5, (float)var6, (float)var7, (Matrix4f)var8, (float)var9, (float)var10);
      } catch (Throwable var16) {
         throw SourceSupport.rethrow(var16);
      }
   }

   private static Consumer invokeBinding10(OutlinedRectangleRenderer var0, RoundedCornerStyle var1) {
         MethodHandle var6 = bindingCache10;
         MethodHandle var5 = bindingCache10;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache10 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/de_C0174;Ldev/zprestige/prestige/gB_C0327;)Ljava/util/function/Consumer;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/de_C0174",
                     "lambda$getRenderLayer$1",
                     "(Ldev/zprestige/prestige/gB_C0327;Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var3.invokeExact((OutlinedRectangleRenderer)var0, (RoundedCornerStyle)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Supplier invokeBinding11() {
         MethodHandle var4 = bindingCache11;
         MethodHandle var3 = bindingCache11;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache11 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 8, "org/joml/Vector4f", "<init>", "()V"),
                  SourceSupport.methodType("()Lorg/joml/Vector4f;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
