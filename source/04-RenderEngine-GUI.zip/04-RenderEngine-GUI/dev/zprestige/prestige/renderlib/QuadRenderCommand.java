package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;

public final class QuadRenderCommand implements RenderCommand {
   private final RenderBatchKey a;
   private final float b;
   private final float c;
   private final float d;
   private final float e;
   private final float f;
   private final float g;
   private final float h;
   private final float i;
   private final int j;
   private final Matrix4f k;
   private static final long l = 66891222133848L;
   private static final long[] m;
   private static final Integer[] n;
   private static final Map o = new HashMap(13);
   private static final Object[] p = new Object[22];
   private static final String[] q = new String[22];

   public QuadRenderCommand(
      RenderBatchKey var1, float var2, float var3, float var4, float var5, int var6, float var7, float var8, float var9, float var10, Matrix4f var11, long var12
   ) {
      super();
      var12 = 66891222133848L ^ var12;

      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var7;
      this.g = var8;
      this.h = var9;
      this.i = var10;
      this.k = var11;
      int var10001 = 27974;
      long var10002 = 7906748399695807533L ^ var12;
      int var10000 = var6 >>> 24;
      var10001 = (short)9215;
      var10002 = 2028244411444562576L ^ var12;
      int var14 = var10000 & 0xFF;
      var10001 = (short)18733;
      var10002 = 7163954165387681861L ^ var12;
      var10000 = var6 >>> 16;
      var10001 = (short)31916;
      var10002 = 2599532262757291456L ^ var12;
      int var15 = var10000 & 0xFF;
      var10001 = (short)8561;
      var10002 = 595925767792527387L ^ var12;
      var10000 = var6 >>> 8;
      var10001 = (short)31916;
      var10002 = 2599532262757291456L ^ var12;
      int var16 = var10000 & 0xFF;
      var10001 = (short)31916;
      var10002 = 2599532262757291456L ^ var12;
      int var17 = var6 & 0xFF;
      short var35 = 10260;
      long var10003 = 6561481440159203705L ^ var12;
      var10001 = var14 << 24;
      short var36 = 25263;
      long var10004 = 5294781740063116235L ^ var12;
      var10001 |= var17 << 16;
      short var37 = 25662;
      var10004 = 5704967631179894103L ^ var12;
      this.j = var10001 | var16 << 8 | var15;
   }

   @Override
   public void aReturningVoid(Object[] var1) {
      long var2;
      MeshDataConsumer var5;
      long var14;
      long var16;
      var5 = (MeshDataConsumer)var1[0];
      float var4 = (Float)var1[1];
      var2 = (Long)var1[2];
      long var6 = var2 ^ 101332350750857L;
      long var8 = var2 ^ 25011147312175L;
      long var10 = var2 ^ 46861899452924L;
      long var12 = var2 ^ 10851337557922L;
      var14 = var2 ^ 59550832782815L;
      var16 = var2 ^ 34569589339096L;
      long var18 = var2 ^ 121499987233839L;
      int var20 = Event.bReturningInt();
      Object[] var22 = new Object[]{var6};
      MeshDataConsumer var21 = var5;
      var21.kReturningVoid(var22);
      int var81 = var20;
      label16:
      if (var81 == 0) {
         Matrix4f var82 = this.k;
         if (var82 == null) {
            float var10001 = this.b;
            float var10002 = this.e;
            Object[] var10006 = new Object[]{null, null, null, var10};
            var10006[2] = var4;
            var10006[1] = var10002;
            var10006[0] = var10001;
            Object[] var25 = var10006;
            MeshDataConsumer var24 = var5;
            MeshDataConsumer var10000 = var24.cReturningMeshDataConsumer(var25);
            int var107 = this.j;
            Object[] var10004 = new Object[]{null, var12};
            var10004[0] = var107;
            Object[] var27 = var10004;
            MeshDataConsumer var26 = var10000;
            var10000 = var26.eReturningMeshDataConsumer(var27);
            Object[] var29 = new Object[]{new float[]{this.f, this.i}, var18};
            MeshDataConsumer var28 = var10000;
            var10000 = var28.bReturningMeshDataConsumer(var29);
            var10001 = this.b;
            var10002 = this.c;
            var10006 = new Object[]{null, null, null, var10};
            var10006[2] = var4;
            var10006[1] = var10002;
            var10006[0] = var10001;
            Object[] var31 = var10006;
            MeshDataConsumer var30 = var10000;
            var10000 = var30.cReturningMeshDataConsumer(var31);
            int var109 = this.j;
            var10004 = new Object[]{null, var12};
            var10004[0] = var109;
            Object[] var33 = var10004;
            MeshDataConsumer var32 = var10000;
            var10000 = var32.eReturningMeshDataConsumer(var33);
            Object[] var35 = new Object[]{new float[]{this.f, this.g}, var18};
            MeshDataConsumer var34 = var10000;
            var10000 = var34.bReturningMeshDataConsumer(var35);
            var10001 = this.d;
            var10002 = this.c;
            var10006 = new Object[]{null, null, null, var10};
            var10006[2] = var4;
            var10006[1] = var10002;
            var10006[0] = var10001;
            Object[] var37 = var10006;
            MeshDataConsumer var36 = var10000;
            var10000 = var36.cReturningMeshDataConsumer(var37);
            int var111 = this.j;
            var10004 = new Object[]{null, var12};
            var10004[0] = var111;
            Object[] var39 = var10004;
            MeshDataConsumer var38 = var10000;
            var10000 = var38.eReturningMeshDataConsumer(var39);
            Object[] var41 = new Object[]{new float[]{this.h, this.g}, var18};
            MeshDataConsumer var40 = var10000;
            var10000 = var40.bReturningMeshDataConsumer(var41);
            var10001 = this.d;
            var10002 = this.e;
            var10006 = new Object[]{null, null, null, var10};
            var10006[2] = var4;
            var10006[1] = var10002;
            var10006[0] = var10001;
            Object[] var43 = var10006;
            MeshDataConsumer var42 = var10000;
            var10000 = var42.cReturningMeshDataConsumer(var43);
            int var113 = this.j;
            var10004 = new Object[]{null, var12};
            var10004[0] = var113;
            Object[] var45 = var10004;
            MeshDataConsumer var44 = var10000;
            var10000 = var44.eReturningMeshDataConsumer(var45);
            Object[] var47 = new Object[]{new float[]{this.h, this.i}, var18};
            MeshDataConsumer var46 = var10000;
            var46.bReturningMeshDataConsumer(var47);
            int var83 = var20;
            if (var83 == 0) {
               break label16;
            }
         }

         Matrix4f var114 = this.k;
         float var126 = this.b;
         float var10003 = this.e;
         Object[] var10007 = new Object[]{null, null, null, null, var8};
         var10007[3] = var4;
         var10007[2] = var10003;
         var10007[1] = var126;
         var10007[0] = var114;
         Object[] var50 = var10007;
         MeshDataConsumer var49 = var5;
         MeshDataConsumer var95 = var49.dReturningMeshDataConsumer(var50);
         int var115 = this.j;
         Object[] var137 = new Object[]{null, var12};
         var137[0] = var115;
         Object[] var52 = var137;
         MeshDataConsumer var51 = var95;
         var95 = var51.eReturningMeshDataConsumer(var52);
         Object[] var54 = new Object[]{new float[]{this.f, this.i}, var18};
         MeshDataConsumer var53 = var95;
         var95 = var53.bReturningMeshDataConsumer(var54);
         var114 = this.k;
         var126 = this.b;
         var10003 = this.c;
         var10007 = new Object[]{null, null, null, null, var8};
         var10007[3] = var4;
         var10007[2] = var10003;
         var10007[1] = var126;
         var10007[0] = var114;
         Object[] var56 = var10007;
         MeshDataConsumer var55 = var95;
         var95 = var55.dReturningMeshDataConsumer(var56);
         int var117 = this.j;
         var137 = new Object[]{null, var12};
         var137[0] = var117;
         Object[] var58 = var137;
         MeshDataConsumer var57 = var95;
         var95 = var57.eReturningMeshDataConsumer(var58);
         Object[] var60 = new Object[]{new float[]{this.f, this.g}, var18};
         MeshDataConsumer var59 = var95;
         var95 = var59.bReturningMeshDataConsumer(var60);
         var114 = this.k;
         var126 = this.d;
         var10003 = this.c;
         var10007 = new Object[]{null, null, null, null, var8};
         var10007[3] = var4;
         var10007[2] = var10003;
         var10007[1] = var126;
         var10007[0] = var114;
         Object[] var62 = var10007;
         MeshDataConsumer var61 = var95;
         var95 = var61.dReturningMeshDataConsumer(var62);
         int var119 = this.j;
         var137 = new Object[]{null, var12};
         var137[0] = var119;
         Object[] var64 = var137;
         MeshDataConsumer var63 = var95;
         var95 = var63.eReturningMeshDataConsumer(var64);
         Object[] var66 = new Object[]{new float[]{this.h, this.g}, var18};
         MeshDataConsumer var65 = var95;
         var95 = var65.bReturningMeshDataConsumer(var66);
         var114 = this.k;
         var126 = this.d;
         var10003 = this.e;
         var10007 = new Object[]{null, null, null, null, var8};
         var10007[3] = var4;
         var10007[2] = var10003;
         var10007[1] = var126;
         var10007[0] = var114;
         Object[] var68 = var10007;
         MeshDataConsumer var67 = var95;
         var95 = var67.dReturningMeshDataConsumer(var68);
         int var121 = this.j;
         var137 = new Object[]{null, var12};
         var137[0] = var121;
         Object[] var70 = var137;
         MeshDataConsumer var69 = var95;
         var95 = var69.eReturningMeshDataConsumer(var70);
         Object[] var72 = new Object[]{new float[]{this.h, this.i}, var18};
         MeshDataConsumer var71 = var95;
         MeshDataConsumer var84 = var71.bReturningMeshDataConsumer(var72);
      }

      short var122 = 24671;
      long var130 = 2714535785242709559L ^ var2;
      Object[] var75 = new Object[]{new int[]{0, 1, 2, 2, 3, 0}, var14};
      MeshDataConsumer var74 = var5;
      MeshDataConsumer var106 = var74.gReturningMeshDataConsumer(var75);
      Object[] var77 = new Object[]{var16};
      MeshDataConsumer var76 = var106;
      var76.hReturningMeshDataConsumer(var77);
   }

   @Override
   public RenderBatchKey aReturninggA_C0325(Object[] var1) {
      return this.a;
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(7926257743442L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[9];
      String var6 = "\u0016\u0096?¬'ÄÈ±d+n{ËÃ¬Od³Ô¦*\u0097°\u0002ã2\"Åc´²\u0018Òpv}ÆTçGå.\u0084\u0092Ð\u008f>.\u001eÚ\u0082ËY½ÍÊ";
      int var7 = "\u0016\u0096?¬'ÄÈ±d+n{ËÃ¬Od³Ô¦*\u0097°\u0002ã2\"Åc´²\u0018Òpv}ÆTçGå.\u0084\u0092Ð\u008f>.\u001eÚ\u0082ËY½ÍÊ".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     m = var8;
                     n = new Integer[9];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "+ÒåÅ\u001f9Ä«\u001dÙ»\nÐ{ìÐ";
                  var7 = "+ÒåÅ\u001f9Ä«\u001dÙ»\nÐ{ìÐ".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 32345;
      if (n[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = m[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])o.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               o.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/ak", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         n[var3] = var15;
      }

      return n[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ak_C0024",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ak" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = q[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = p[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 40;
            yield var15;
         }
         case 1 -> {
            byte var16 = 10;
            yield var16;
         }
         case 2 -> {
            byte var17 = 15;
            yield var17;
         }
         case 3 -> {
            byte var18 = 11;
            yield var18;
         }
         case 4 -> {
            byte var19 = 25;
            yield var19;
         }
         case 5 -> {
            byte var20 = 62;
            yield var20;
         }
         case 6 -> {
            byte var21 = 54;
            yield var21;
         }
         case 7 -> {
            byte var22 = 30;
            yield var22;
         }
         case 8 -> {
            byte var23 = 31;
            yield var23;
         }
         case 9 -> {
            byte var24 = 48;
            yield var24;
         }
         case 10 -> {
            byte var25 = 50;
            yield var25;
         }
         case 11 -> {
            byte var26 = 35;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 52;
            yield var28;
         }
         case 14 -> {
            byte var29 = 41;
            yield var29;
         }
         case 15 -> {
            byte var30 = 16;
            yield var30;
         }
         case 16 -> {
            byte var31 = 5;
            yield var31;
         }
         case 17 -> {
            byte var32 = 19;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 59;
            yield var34;
         }
         case 20 -> {
            byte var35 = 32;
            yield var35;
         }
         case 21 -> {
            byte var36 = 39;
            yield var36;
         }
         case 22 -> {
            byte var37 = 26;
            yield var37;
         }
         case 23 -> {
            byte var38 = 63;
            yield var38;
         }
         case 24 -> {
            byte var39 = 29;
            yield var39;
         }
         case 25 -> {
            byte var40 = 56;
            yield var40;
         }
         case 26 -> {
            byte var41 = 36;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 53;
            yield var43;
         }
         case 29 -> {
            byte var44 = 33;
            yield var44;
         }
         case 30 -> {
            byte var45 = 1;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 3;
            yield var47;
         }
         case 33 -> {
            byte var48 = 8;
            yield var48;
         }
         case 34 -> {
            byte var49 = 28;
            yield var49;
         }
         case 35 -> {
            byte var50 = 44;
            yield var50;
         }
         case 36 -> {
            byte var51 = 2;
            yield var51;
         }
         case 37 -> {
            byte var52 = 60;
            yield var52;
         }
         case 38 -> {
            byte var53 = 46;
            yield var53;
         }
         case 39 -> {
            byte var54 = 22;
            yield var54;
         }
         case 40 -> {
            byte var55 = 18;
            yield var55;
         }
         case 41 -> {
            byte var56 = 27;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 51;
            yield var58;
         }
         case 44 -> {
            byte var59 = 13;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 61;
            yield var61;
         }
         case 47 -> {
            byte var62 = 47;
            yield var62;
         }
         case 48 -> {
            byte var63 = 14;
            yield var63;
         }
         case 49 -> {
            byte var64 = 43;
            yield var64;
         }
         case 50 -> {
            byte var65 = 4;
            yield var65;
         }
         case 51 -> {
            byte var66 = 21;
            yield var66;
         }
         case 52 -> {
            byte var67 = 38;
            yield var67;
         }
         case 53 -> {
            byte var68 = 57;
            yield var68;
         }
         case 54 -> {
            byte var69 = 9;
            yield var69;
         }
         case 55 -> {
            byte var70 = 23;
            yield var70;
         }
         case 56 -> {
            byte var71 = 7;
            yield var71;
         }
         case 57 -> {
            byte var72 = 6;
            yield var72;
         }
         case 58 -> {
            byte var73 = 58;
            yield var73;
         }
         case 59 -> {
            byte var74 = 17;
            yield var74;
         }
         case 60 -> {
            byte var75 = 20;
            yield var75;
         }
         case 61 -> {
            byte var76 = 34;
            yield var76;
         }
         case 62 -> {
            byte var77 = 49;
            yield var77;
         }
         default -> 42;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            q[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      p[0] = "\u0019\u0013Pq\u0001\u001e\u000f\u0013U+\u0012\t\u0018XV-\u001e\u001d\t\u001fA:U\r>";
      p[1] = "\u0017nG-AebNL\"P*\u0003@G)Tpw";
      p[2] = "t\u0006\u0002%x(b\u0006\u0007\u007fk?uM\u0004yg+d\n\u0013n,9U";
      p[3] = int.class;
      q[3] = "java/lang/Integer";
      p[4] = "\f\u0003x@fuy#sOw:\u0018-xDs`l";
      p[5] = "2&(M\u0019T$&-\u0017\nC3m.\u0011\u0006W\"*9\u0006ME=";
      p[6] = "\u0001K%Y67\nD4\u0016U:\u001fI;}`8\u000eZ'Qw5";
      p[7] = "_oA\u0000 F*OJ\u000f1\tKAA\u00045S?";
      p[8] = "Y..\u0002Fx,\u000e%\rW7M\u0000.\u0006Sm9";
      p[9] = "\u000fD\u001bg]\fzd\u0010hLC\u001bj\u001bcH\u0019o";
      p[10] = " jS\u0018\u001f\u0017UJX\u0017\u000eX4DS\u001c\n\u0002@";
      p[11] = "\u0000\u00116oQ2u1=`@}\u0014?6kD'`";
      p[12] = "k\u0004H\u0004M-`\u000bYK,#k\u0000]\u0011";
      p[13] = "A6\u0014\u001e\u001e3\u00173[dH\u0002B1\u0004Y\u001ezM6P\u0007%>\u00072\u0010_\u0014h\u0002}j";
      p[14] = "b\u0019\u0019q(\u00024\u001cV\u000bs3a\u001e\t6(Kn\u0019]h\u0013\u000f$\u001d\u001d0\"Y!Rg";
      p[15] = "\";#e1Kt>l\u001fez!<3\"1\u0002.;g|\nFd?'$;\u0010ap]";
      p[16] = "&i=\u0005e\tplr\u007f58%n-Be@*iy\u001c^\u0004`m9DoRe\"C";
      p[17] = "r]}H]\u00119CyQa@K\u001c)\u001b\u001eJ:\\yJP*";
      p[18] = "xsV!0\u0017.v\u0019[a&{tFf0^ts\u00128\u000b\u001a>wR`:L;8(";
      p[19] = "A%\u007fv1$\u0017 0\fi\u0015B\"o11mM%;o\n)\u0007!{7;\u007f\u0002n\u0001";
      p[20] = "1zC0\\zo#\u001e!8u\r}K1G'm:F%\u0003\u001c1-W>\u0003|v Cz8";
      p[21] = "<\u0019\u000f/ifj\u001c@U>W?\u001e\u001fhi/0\u0019K6Rkz\u001d\u000bnc=\u007fRq";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = p[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(q[var4]);
            p[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = p[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            p[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  p[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(862944476773978L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = p[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = q[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  p[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(862944476773978L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        p[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(862944476773978L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 65;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 199;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 223;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 243;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 119;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 250;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 65;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 199;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 223;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/ak_C0024",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/ak" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
