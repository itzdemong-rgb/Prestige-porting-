package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import org.lwjgl.opengl.GL20;

public record RLUniforms(int bl) {
   private static final Map a = new HashMap();
   private static final long b = 97105168166876L;
   private static final Object[] c = new Object[36];
   private static final String[] d = new String[36];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   public static RLUniforms a(int var0) {
      return new RLUniforms(var0);
   }

   private int a(String var1) {
      Map var10000 = a;
      int var4 = this.bl;
      Integer var10001 = var4;
      Function var7 = invokeBinding1();
      Integer var6 = var10001;
      Map var5 = var10000;
      var10000 = (Map)var5.computeIfAbsent(var6, var7);
      Function var10 = invokeBinding2(this);
      String var9 = var1;
      Map var8 = var10000;
      Integer var11 = (Integer)var8.computeIfAbsent(var9, var10);
      return var11;
   }

   public RLUniforms a(String var1, int var2) {
      String var6 = var1;
      RLUniforms var5 = this;
      int var10000 = var5.aReturningVoid(var6);
      int var8 = var2;
      int var7 = var10000;
      GL20.glUniform1i(var7, var8);
      return this;
   }

   public RLUniforms a(String var1, int var2, int var3) {
      String var7 = var1;
      RLUniforms var6 = this;
      int var10000 = var6.aReturningVoid(var7);
      int var10 = var3;
      int var9 = var2;
      int var8 = var10000;
      GL20.glUniform2i(var8, var9, var10);
      return this;
   }

   public RLUniforms a(String var1, int var2, int var3, int var4) {
      String var8 = var1;
      RLUniforms var7 = this;
      int var10000 = var7.aReturningVoid(var8);
      int var12 = var4;
      int var11 = var3;
      int var10 = var2;
      int var9 = var10000;
      GL20.glUniform3i(var9, var10, var11, var12);
      return this;
   }

   public RLUniforms a(String var1, int var2, int var3, int var4, int var5) {
      String var9 = var1;
      RLUniforms var8 = this;
      int var10000 = var8.aReturningVoid(var9);
      int var14 = var5;
      int var13 = var4;
      int var12 = var3;
      int var11 = var2;
      int var10 = var10000;
      GL20.glUniform4i(var10, var11, var12, var13, var14);
      return this;
   }

   public RLUniforms a(String var1, float var2) {
      String var6 = var1;
      RLUniforms var5 = this;
      int var10000 = var5.aReturningVoid(var6);
      float var8 = var2;
      int var7 = var10000;
      GL20.glUniform1f(var7, var8);
      return this;
   }

   public RLUniforms a(String var1, float var2, float var3) {
      String var7 = var1;
      RLUniforms var6 = this;
      int var10000 = var6.aReturningVoid(var7);
      float var10 = var3;
      float var9 = var2;
      int var8 = var10000;
      GL20.glUniform2f(var8, var9, var10);
      return this;
   }

   public RLUniforms a(String var1, float var2, float var3, float var4) {
      String var8 = var1;
      RLUniforms var7 = this;
      int var10000 = var7.aReturningVoid(var8);
      float var12 = var4;
      float var11 = var3;
      float var10 = var2;
      int var9 = var10000;
      GL20.glUniform3f(var9, var10, var11, var12);
      return this;
   }

   public RLUniforms a(String var1, float var2, float var3, float var4, float var5) {
      String var9 = var1;
      RLUniforms var8 = this;
      int var10000 = var8.aReturningVoid(var9);
      float var14 = var5;
      float var13 = var4;
      float var12 = var3;
      float var11 = var2;
      int var10 = var10000;
      GL20.glUniform4f(var10, var11, var12, var13, var14);
      return this;
   }

   public RLUniforms a(String var1, boolean var2, float[] var3) {
      String var7 = var1;
      RLUniforms var6 = this;
      int var10000 = var6.aReturningVoid(var7);
      float[] var10 = var3;
      boolean var9 = var2;
      int var8 = var10000;
      GL20.glUniformMatrix4fv(var8, var9, var10);
      return this;
   }

   public RLUniforms b(String var1, boolean var2, float[] var3) {
      String var7 = var1;
      RLUniforms var6 = this;
      int var10000 = var6.aReturningVoid(var7);
      float[] var10 = var3;
      boolean var9 = var2;
      int var8 = var10000;
      GL20.glUniformMatrix3fv(var8, var9, var10);
      return this;
   }

   public RLUniforms c(String var1, boolean var2, float[] var3) {
      String var7 = var1;
      RLUniforms var6 = this;
      int var10000 = var6.aReturningVoid(var7);
      float[] var10 = var3;
      boolean var9 = var2;
      int var8 = var10000;
      GL20.glUniformMatrix2fv(var8, var9, var10);
      return this;
   }

   public RLUniforms a(String var1, Color var2) {
      String var6 = var1;
      RLUniforms var5 = this;
      int var10000 = var5.aReturningVoid(var6);
      Color var7 = var2;
      float var10001 = var7.getRed() / 255.0F;
      Color var8 = var2;
      float var10002 = var8.getGreen() / 255.0F;
      Color var9 = var2;
      float var10003 = var9.getBlue() / 255.0F;
      Color var10 = var2;
      float var15 = var10.getAlpha() / 255.0F;
      float var14 = var10003;
      float var13 = var10002;
      float var12 = var10001;
      int var11 = var10000;
      GL20.glUniform4f(var11, var12, var13, var14, var15);
      return this;
   }

   public RLUniforms b(String var1, float var2, float var3, float var4, float var5) {
      String var9 = var1;
      RLUniforms var8 = this;
      int var10000 = var8.aReturningVoid(var9);
      float var14 = var5;
      float var13 = var4;
      float var12 = var3;
      float var11 = var2;
      int var10 = var10000;
      GL20.glUniform4f(var10, var11, var12, var13, var14);
      return this;
   }

   private Integer lambda$getLocation$1(String var1) {
      String var5 = var1;
      int var4 = this.bl;
      int var6 = GL20.glGetUniformLocation(var4, var5);
      return var6;
   }

   private static Map lambda$getLocation$0(Integer var0) {
      return new HashMap();
   }

   static {
      aReturningVoid();
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = d[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = c[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 19;
            yield var15;
         }
         case 1 -> {
            byte var16 = 49;
            yield var16;
         }
         case 2 -> {
            byte var17 = 61;
            yield var17;
         }
         case 3 -> {
            byte var18 = 30;
            yield var18;
         }
         case 4 -> {
            byte var19 = 5;
            yield var19;
         }
         case 5 -> {
            byte var20 = 37;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 52;
            yield var22;
         }
         case 8 -> {
            byte var23 = 12;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 22;
            yield var25;
         }
         case 11 -> {
            byte var26 = 6;
            yield var26;
         }
         case 12 -> {
            byte var27 = 25;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 56;
            yield var29;
         }
         case 15 -> {
            byte var30 = 3;
            yield var30;
         }
         case 16 -> {
            byte var31 = 9;
            yield var31;
         }
         case 17 -> {
            byte var32 = 62;
            yield var32;
         }
         case 18 -> {
            byte var33 = 51;
            yield var33;
         }
         case 19 -> {
            byte var34 = 21;
            yield var34;
         }
         case 20 -> {
            byte var35 = 7;
            yield var35;
         }
         case 21 -> {
            byte var36 = 10;
            yield var36;
         }
         case 22 -> {
            byte var37 = 55;
            yield var37;
         }
         case 23 -> {
            byte var38 = 50;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 8;
            yield var40;
         }
         case 26 -> {
            byte var41 = 24;
            yield var41;
         }
         case 27 -> {
            byte var42 = 44;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 53;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 0;
            yield var46;
         }
         case 32 -> {
            byte var47 = 32;
            yield var47;
         }
         case 33 -> {
            byte var48 = 36;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 39;
            yield var50;
         }
         case 36 -> {
            byte var51 = 41;
            yield var51;
         }
         case 37 -> {
            byte var52 = 47;
            yield var52;
         }
         case 38 -> {
            byte var53 = 17;
            yield var53;
         }
         case 39 -> {
            byte var54 = 58;
            yield var54;
         }
         case 40 -> {
            byte var55 = 14;
            yield var55;
         }
         case 41 -> {
            byte var56 = 33;
            yield var56;
         }
         case 42 -> {
            byte var57 = 20;
            yield var57;
         }
         case 43 -> {
            byte var58 = 4;
            yield var58;
         }
         case 44 -> {
            byte var59 = 27;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 11;
            yield var61;
         }
         case 47 -> {
            byte var62 = 48;
            yield var62;
         }
         case 48 -> {
            byte var63 = 29;
            yield var63;
         }
         case 49 -> {
            byte var64 = 31;
            yield var64;
         }
         case 50 -> {
            byte var65 = 57;
            yield var65;
         }
         case 51 -> {
            byte var66 = 1;
            yield var66;
         }
         case 52 -> {
            byte var67 = 59;
            yield var67;
         }
         case 53 -> {
            byte var68 = 15;
            yield var68;
         }
         case 54 -> {
            byte var69 = 54;
            yield var69;
         }
         case 55 -> {
            byte var70 = 60;
            yield var70;
         }
         case 56 -> {
            byte var71 = 2;
            yield var71;
         }
         case 57 -> {
            byte var72 = 35;
            yield var72;
         }
         case 58 -> {
            byte var73 = 13;
            yield var73;
         }
         case 59 -> {
            byte var74 = 40;
            yield var74;
         }
         case 60 -> {
            byte var75 = 23;
            yield var75;
         }
         case 61 -> {
            byte var76 = 42;
            yield var76;
         }
         case 62 -> {
            byte var77 = 26;
            yield var77;
         }
         default -> 38;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            d[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      c[0] = "T|\u001e\u0002b\u000bIiF #\u0006Qo";
      c[1] = int.class;
      d[1] = "java/lang/Integer";
      c[2] = "@D\u0004w[mEQ\u000fwXjJX\u00045\u0019]c\u0004S";
      c[3] = float.class;
      d[3] = "java/lang/Float";
      c[4] = void.class;
      d[4] = "java/lang/Void";
      c[5] = "[mZZX1Mm_\u0000K&Z&\\\u0006G2KaK\u0011\f&F";
      c[6] = "\u000bA::WZ\u0000N+u*B\u0013I\"<";
      c[7] = boolean.class;
      d[7] = "java/lang/Boolean";
      c[8] = "D-";
      c[9] = "D;%G\u0004;O44\bc9Z?4CX";
      c[10] = ";\u0017?(TL%\u001f%g7X!";
      c[11] = ":\u001a\u0012q9S1\u0015\u0003>X]:\u001e\u0007d";
      c[12] = "\"Rc\u0003,%<ZyLd%&Pa\u000bm>fu`\fa$!\\{";
      c[13] = "c\u000b";
      c[14] = "\u001ab\u0015y*\u0016\u0011m\u00046G\u0012\u0011q0}u\u000f\u0015m\u0000}";
      c[15] = "0|";
      c[16] = "#hA;\r\u0014``Q!3\ttgG5t\u0019\u001dr\nb\\\u000flhT73IvxYfP\n~hCX";
      c[17] = "CM\u0017C#\u000b\u0014A\u0010PB[\u001e}\f\\,S\u0000E/T>N\u001bPVS<4\u000b\u0010PR:E\u0011N\u0005=\u007fX\u001fK\u0014FyF\u001e\u001cjT<V\u001e\u001fZ\u0000=PK QT$\u000e\u001c\u001dZQ{Dz";
      c[18] = "V7V S\r\u0001;Q32]\u000b\u0007M?\\U\u0015?\u0012?2C_`D&CY\u00015+/\u0002\b\u0000\"Z5\\]oaB8\bTRjGgB2";
      c[19] = "EG\fL\b\u000f\u0012K\u000b_i_\u0018w\u0017S\u0007W\u0006OK\\iAL\u0010\u001eJ\u0018[\u0012Eq\bXQ\u001eT\u0012X\tS\u0012*K\u0003\bR\u0002I\u001bR\n^|\u0011\u0018TSVA\u001a\u001d\u000b\u00190";
      c[20] = "rB9\u000e^\u0018%N>\u001d?H/r\"\u0011Q@1J\u007f\u001e?V{\u0015+\bNL%@DJ\u000eF)Q'\u001a_D%/~A^E5L.\u0010\\IK\u0015u\u0011]Y(E$\u0013Q'pF\"JY\u001a{C}\u0000?";
      c[21] = "DX5h[H\u0013T2{:\u0018\u0019h.wT\u0010\u0007Pqx:\u0006M\u000f'nK\u001c\u0013ZH,\u000b\u0016\u001fK+|Z\u0014\u00135s\u007f\\M\u001b\bxz\u0003\u0007}";
      c[22] = "\u0005v?\\q\r\u0003(%=|\u001bEZ;Es\u001f9bo\u0007|\u000eHx1R\u0013";
      c[23] = "!')\u0013x5~%7J\u00119y\".\u000fm?_)\u001f\u0018j?x;VMi7'96\ri#aGf\u0013pi|!m\u001c\u007fc\u001ex.\u0017(,~8.\u0003nR";
      c[24] = "3<L|5\u00075bV\u001d8\u0011s\u0013H`:|~i\u0016r/\rd7C\u001d";
      c[25] = "\u0015h\u0002'RNBd\u000543\u001eHX\u00198]\u0016V`C73\u0000\u001c?\u0010!B\u001aBj\u007fc\u0002\u0010N{\u001c3S\u0012B\u0005EhR\u0013Rf\u00159P\u001f,?N8Q\u000fOo\u001f:]q\u00164\u001e;M\u0012Fe\u001c73JEcE?\u000eA@<\u000fY";
      c[26] = "jZyy2'=V~jSw7jbf=\u007f)RAn/b2G>i-\u0018\"\u0007>h+i8Yk\u0007nt6\\z|hj7\u000b\u0004n-z7\b4:,|b7?n5\"5\n4kjhS";
      c[27] = "\tIC\u0017\\\\^ED\u0004=\fTyX\bS\u0004JA\u0004\b=\u0012\u0000\u001eQ\u0011L\b^K>\u0018\rY_\\O\u0002S\f0U\u000eSR\u001bAOP\u0006=XYB\u0004\u000f\u0000S\\\u001dNi";
      c[28] = "#k\u000fqL\u0004tg\bb-T~[\u0014nC\\`cIn-J*<\u001dw\\Ptir~\u001d\u0001u~\u0003dCT\u001awB5BCkm\u001c`-J*<\u001dw\\Ptir4D] `O?A\u0002j\u0006";
      c[29] = "Z\u0000\u000b\tSi\u0019\b\u001b\u0013mk\u0002\u0017.\u0003\tw\tk\u0001ZWe\u001c\u001a\u001b\u0004\u0002\n";
      c[30] = "Af6cdbE`4jXq}a'm hF>:8>\u0018\fmro i\u00163'\u0000";
      c[31] = "?s\n9tFh\u007f\r*\u0015\u0016bC\u0011&{\u001e|{2.i\u0003gnL)kyw.M(m\bmp\u0018G(\u0015cu\t<.\u000bb\"w.k\u001bb!Gzj\u001d7\u001eL.sC`#G+,\t\u0006";
      c[32] = "\t\t1\u0013d}^\u00056\u0000\u0005-T+!\u0011X$Q\n+\u0017`\u0006W\u000f%\u0011d%Vd=]?-H\u0015'\u0003jB\u0001\u001c!\u00145%\u0000](\b\u00053\u0000^#\u0015t)^\u000bL";
      c[33] = "M\"\u0011\u0001%f\u001a.\u0016\u0012D6\u0010\u0012\n\u001e*>\u000e*P\u001eD(Du\u0003\u000752\u001a l\u000etc\u001b7\u001d\u0014*6t>\\E+!\u0005$\u0002\u0010D(Du\u0003\u000752\u001a l\u000etc\u001b7\u001d\u0014*6tt\u0005\u0019~?I\u007f\u0000F4Y";
      c[34] = "=\u001bo2PA;EuS]W}$b?2K1D`+CQo\u0011\u000f";
      c[35] = "\u0005f\b9WY\u00038\u0012XZOEL\u00125XD9rXbZZHh\u000675";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = c[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(d[var4]);
            c[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            c[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  c[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(783175537289336L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = c[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = d[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  c[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(783175537289336L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        c[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(783175537289336L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 100;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 162;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 192;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 219;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 201;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 194;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 100;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 162;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 192;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gy_C0374",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gy" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/gy_C0374", "lambda$getLocation$0", "(Ljava/lang/Integer;)Ljava/util/Map;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ljava/util/Map;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Function invokeBinding2(RLUniforms var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/gy_C0374;)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/gy_C0374", "lambda$getLocation$1", "(Ljava/lang/String;)Ljava/lang/Integer;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/String;)Ljava/lang/Integer;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var2.invokeExact((RLUniforms)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
