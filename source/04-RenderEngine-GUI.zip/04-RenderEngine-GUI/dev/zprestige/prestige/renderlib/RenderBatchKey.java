package dev.zprestige.prestige.renderlib;

import org.joml.Vector4f;

public record RenderBatchKey(Vector4f bp, DrawPipeline bq) {
}
