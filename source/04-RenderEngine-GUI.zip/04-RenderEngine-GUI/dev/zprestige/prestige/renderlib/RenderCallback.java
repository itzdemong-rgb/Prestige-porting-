package dev.zprestige.prestige.renderlib;

public interface RenderCallback {
   void a(MeshBufferManager var1, RenderContext var2);
}
