package dev.zprestige.prestige.renderlib;

public interface RenderCommand {
   void aReturningVoid(Object[] var1);

   RenderBatchKey aReturninggA_C0325(Object[] var1);
}
