package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;

public class RenderCommandBatcher {
   protected ManagedGlBuffer a;
   protected ManagedGlBuffer b;
   protected GlVertexArray c;
   private boolean d = dev.prestige.recovery.SourceSupport.asBoolean(0);
   private final List e = new ArrayList();
   public float f = 0.0F;
   private static final long g = 126588821645197L;
   private static final long[] h;
   private static final Integer[] i;
   private static final Map j = new HashMap(13);
   private static final long[] k;
   private static final Long[] l;
   private static final Map m;
   private static final Object[] n = new Object[79];
   private static final String[] o = new String[79];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;

   private void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 126588821645197L ^ var2;
      long var4 = var2 ^ 78751414990570L;
      long var6 = var2 ^ 63529087714966L;
      long var8 = var2 ^ 132596240565677L;
      int var10 = Event.cReturningInt();
      int var23 = var10;
      RenderCommandBatcher var22 = this;
      RenderCommandBatcher var21 = var22;
      RenderCommandBatcher var20 = var22;
      if (var23 != 0) {
         boolean var24 = var20.d;
         if (var24) {
            return;
         }

         Object[] var13 = new Object[]{invokeBinding1(), var6};
         this.a = (ManagedGlBuffer)RenderThreadUtil.aReturningObject(var13);
         Object[] var14 = new Object[]{invokeBinding2(), var6};
         this.b = (ManagedGlBuffer)RenderThreadUtil.aReturningObject(var14);
         Object[] var15 = new Object[]{null, var4};
         this.c = GlVertexArray.bReturningVoid(var15);
         ManagedGlBuffer var10000 = this.a;
         short var10001 = 5937;
         long var10002 = 5037810697066344344L ^ var2;
         short var28 = 24233;
         long var10003 = 2365055574024313499L ^ var2;
         Object[] var10005 = new Object[]{null, null, var8};
         var10005[1] = 65536L;
         var10005[0] = 35048;
         Object[] var17 = var10005;
         ManagedGlBuffer var16 = var10000;
         var16.aReturningVoid(var17);
         var10000 = this.b;
         var10001 = 30409;
         var10002 = 8178537552944828003L ^ var2;
         short var30 = 24063;
         var10003 = 9107307873298930124L ^ var2;
         var10005 = new Object[]{null, null, var8};
         var10005[1] = 16384L;
         var10005[0] = 35048;
         Object[] var19 = var10005;
         ManagedGlBuffer var18 = var10000;
         var18.aReturningVoid(var19);
         var21 = this;
      }

      var21.d = dev.prestige.recovery.SourceSupport.asBoolean(1);
   }

   public void bReturningVoid(Object[] var1) {
      RenderCommand var4 = (RenderCommand)var1[0];
      long var2 = (Long)var1[1];
      long var10000 = 126588821645197L ^ var2;
      List var8 = this.e;
      RenderCommandDepth var6 = new RenderCommandDepth(var4, this.f);
      List var5 = var8;
      var5.add(var6);
      float var7 = this.f;
      this.f = Math.nextUp(var7);
   }

   public void cReturningVoid(Object[] var1) {
      RenderContext var2 = (RenderContext)var1[0];
      long var3 = (Long)var1[1];
      var3 = 126588821645197L ^ var3;
      long var5 = var3 ^ 107921224984954L;
      long var7 = var3 ^ 68762634721559L;
      long var9 = var3 ^ 41507019143826L;
      long var11 = var3 ^ 10868562300021L;
      long var13 = var3 ^ 89149247547591L;
      long var15 = var3 ^ 47868976929487L;
      long var17 = var3 ^ 27206788852757L;
      long var19 = var3 ^ 135668536904967L;
      long var21 = var3 ^ 45196626663254L;
      long var23 = var3 ^ 135642398673132L;
      long var25 = var3 ^ 121759210955374L;
      int var27 = Event.bReturningInt();
      List var40 = this.e;
      int var10000 = (((var40.isEmpty()) ? 1 : 0));
      int var123 = var27;
      byte var122 = (byte)var10000;
      byte var112 = var122;
      byte var111 = var122;
      if (var123 == 0) {
         byte var124 = var111;
         if (var124 != 0) {
            this.f = 0.0F;
            return;
         }

         Object[] var44 = new Object[]{var17};
         RenderCommandBatcher var43 = this;
         var43.aReturningVoid(var44);
         var112 = 0;
      }

      int var28 = var112;

      label103:
      while (true) {
         int var113 = var28;

         label100:
         while (true) {
            List var45 = this.e;
            int var126 = var45.size();
            int var125 = var113;
            if (var125 >= var126) {
               break;
            }

            int var47 = var28;
            List var46 = this.e;
            RenderCommandDepth var48 = (RenderCommandDepth)var46.get(var47);
            RenderCommand var151 = var48.bX();
            Object[] var50 = new Object[0];
            RenderCommand var49 = var151;
            RenderBatchKey var29 = var49.aReturninggA_C0325(var50);
            int var30 = var28;
            int var127 = var27;
            if (var127 != 0) {
               return;
            }

            int var31 = var28 + 1;

            List var118;
            int var119;
            while (true) {
               List var51 = this.e;
               int var129 = var51.size();
               int var128 = var31;
               if (var128 < var129) {
                  int var132 = var27;
                  int var131 = var31;
                  List var130 = this.e;
                  var118 = var130;
                  var119 = var131;
                  List var114 = var130;
                  int var115 = var131;
                  if (var132 != 0) {
                     break;
                  }

                  int var53 = var115;
                  List var52 = var114;
                  RenderCommandDepth var54 = (RenderCommandDepth)var52.get(var53);
                  RenderCommand var152 = var54.bX();
                  Object[] var56 = new Object[0];
                  RenderCommand var55 = var152;
                  RenderBatchKey var153 = var55.aReturninggA_C0325(var56);
                  RenderBatchKey var58 = var29;
                  RenderBatchKey var57 = var153;
                  var10000 = (((var57.equals(var58)) ? 1 : 0));
                  int var134 = var27;
                  byte var133 = ((byte)(var10000));
                  var113 = var133;
                  byte var116 = var133;
                  if (var134 != 0) {
                     continue label100;
                  }

                  byte var135 = var116;
                  byte var117 = var135;
                  byte var136 = var117;
                  if (var136 != 0) {
                     var31++;
                     int var137 = var27;
                     if (var137 == 0) {
                        continue;
                     }
                  }
               }

               var119 = var30;
               var118 = this.e;
               break;
            }

            List var32;
            Vector4f var33;
            label83: {
               int var63 = var31;
               int var62 = var119;
               List var61 = var118;
               var32 = var61.subList(var62, var63);
               RenderBatchKey var64 = var29;
               var33 = var64.bp();
               int var138 = var27;
               if (var138 == 0) {
                  Vector4f var139 = var33;
                  if (var139 == null) {
                     break label83;
                  }

                  var10000 = (short)351;
                  long var10001 = 4402429520621302383L ^ var3;
                  GL11.glEnable(3089);
               }

               Object[] var68 = new Object[]{var19};
               int var34 = RenderThreadUtil.cReturningInt(var68);
               Object[] var69 = new Object[]{var25};
               float var35 = RenderThreadUtil.aReturningFloat(var69);
               Vector4f var70 = var33;
               var10000 = (int)(var70.x * var35);
               float var160 = var34;
               Vector4f var71 = var33;
               var160 -= var71.y * var35;
               Vector4f var72 = var33;
               int var162 = (int)(var160 - var72.w * var35);
               Vector4f var73 = var33;
               int var10002 = (int)(var73.z * var35);
               Vector4f var74 = var33;
               int var78 = (int)(var74.w * var35);
               int var77 = var10002;
               int var76 = var162;
               int var75 = var10000;
               GL11.glScissor(var75, var76, var77, var78);
            }

            RenderBatchKey var79 = var29;
            DrawPipeline var149 = var79.bq();
            GlVertexArray var157 = this.c;
            ManagedGlBuffer var163 = this.a;
            Object[] var81 = new Object[0];
            DrawPipeline var80 = var149;
            Object[] var82 = new Object[]{var163, var80.aReturningf8(var81), var11};
            Object[] var84 = new Object[]{GlVertexArray.aReturningList(var82), var13};
            GlVertexArray var83 = var157;
            var83.aReturningVoid(var84);
            Object[] var86 = new Object[0];
            DrawPipeline var85 = var149;
            GlBufferMeshBuilder var37 = new GlBufferMeshBuilder(var85.aReturningf8(var86), this.a, this.b, var7);

            int var36;
            int var150;
            try {
               List var87 = var32;
               Iterator var38 = var87.iterator();

               int var142;
               do {
                  Iterator var88 = var38;
                  boolean var140 = var88.hasNext();
                  if (!var140) {
                     break;
                  }

                  Iterator var89 = var38;
                  RenderCommandDepth var39 = (RenderCommandDepth)var89.next();
                  RenderCommandDepth var90 = var39;
                  RenderCommand var158 = var90.bX();
                  RenderCommandDepth var91 = var39;
                  float var165 = var91.bY();
                  Object[] var10005 = new Object[]{null, null, var5};
                  var10005[1] = var165;
                  var10005[0] = var37;
                  Object[] var93 = var10005;
                  RenderCommand var92 = var158;
                  var92.aReturningVoid(var93);
                  int var141 = var27;
                  if (var141 != 0) {
                     continue label103;
                  }

                  var142 = var27;
               } while (var142 == 0);

               Object[] var95 = new Object[]{var21};
               GlBufferMeshBuilder var94 = var37;
               var150 = var94.aReturningInt(var95);
               Object[] var97 = new Object[]{var15};
               GlBufferMeshBuilder var96 = var37;
               var36 = var96.bReturningInt(var97);
            } catch (Throwable var147) {
                  GlBufferMeshBuilder var99 = var37;
                  var99.close();
               } catch (Throwable var146) {
                  var147.addSuppressed(var146);
               }

               throw var147;
            }

            GlBufferMeshBuilder var98 = var37;
            var98.close();
            GlVertexArray var166 = this.c;
            ManagedGlBuffer var10003 = this.b;
            Object[] var103 = new Object[0];
            DrawPipeline var102 = var149;
            Object[] var105 = new Object[]{var2, var166, var10003, new MeshDrawRange(var102.aReturningf8(var103), var150, var36), var9};
            DrawPipeline var104 = var149;
            var104.aReturningVoid(var105);
            int var143 = var27;
            if (var143 == 0) {
               Vector4f var144 = var33;
               if (var144 != null) {
                  short var159 = 11349;
                  long var164 = 4975619006752251750L ^ var3;
                  GL11.glDisable(3089);
               }

               var28 = var31;
            }

            int var145 = var27;
            if (var145 == 0) {
               continue label103;
            }
            break;
         }

         Object[] var110 = new Object[]{var23};
         RenderCommandBatcher var109 = this;
         var109.dReturningVoid(var110);
         return;
      }
   }

   public void dReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      long var10000 = 126588821645197L ^ var2;
      this.f = 0.0F;
      List var4 = this.e;
      var4.clear();
   }

   static {

      {

      aReturningVoid();
      Cipher var13;
      Cipher var10000 = var13 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var14 = 1; var14 < 8; var14++) {
         var10003[var14] = (byte)(94033315919273L << var14 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var19 = new long[4];
      String var17 = "\u0093÷Pó\u00ado\u0000ÓùTß~á\u0096#\u001f";
      int var18 = "\u0093÷Pó\u00ado\u0000ÓùTß~á\u0096#\u001f".length();
      label41:
      while (true) {
         int var10001 = var15;
         var15 += 8;
         byte[] var20 = var17.substring(var10001, var15).getBytes("ISO-8859-1");
         long[] var25 = var19;
         var10001 = var16++;
         long var31 = (var20[0] & 255L) << 56
            | (var20[1] & 255L) << 48
            | (var20[2] & 255L) << 40
            | (var20[3] & 255L) << 32
            | (var20[4] & 255L) << 24
            | (var20[5] & 255L) << 16
            | (var20[6] & 255L) << 8
            | var20[7] & 255L;
         
            long var21 = var31;
            byte[] var23 = var13.doFinal(
               new byte[]{
                  (byte)(var21 >>> 56),
                  (byte)(var21 >>> 48),
                  (byte)(var21 >>> 40),
                  (byte)(var21 >>> 32),
                  (byte)(var21 >>> 24),
                  (byte)(var21 >>> 16),
                  (byte)(var21 >>> 8),
                  (byte)var21
               }
            );
            long var38 = (var23[0] & 255L) << 56
               | (var23[1] & 255L) << 48
               | (var23[2] & 255L) << 40
               | (var23[3] & 255L) << 32
               | (var23[4] & 255L) << 24
               | (var23[5] & 255L) << 16
               | (var23[6] & 255L) << 8
               | var23[7] & 255L;
            switch (var34) {
               case 0:
                  var25[var10001] = var38;
                  if (var15 >= var18) {
                     h = var19;
                     i = new Integer[4];
                     m = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(94033315919273L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[2];
                     String var4 = "Ôêw5\u0015Ed\u001eÉî\u0019\u0092\u0095V$§";
                     int var5 = "Ôêw5\u0015Ed\u001eÉî\u0019\u0092\u0095V$§".length();
                     do {
                        int var29 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var29, var2).getBytes("ISO-8859-1");
                        var29 = var3++;
                        long var8 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        byte[] var10 = var0.doFinal(
                           new byte[]{
                              (byte)(var8 >>> 56),
                              (byte)(var8 >>> 48),
                              (byte)(var8 >>> 40),
                              (byte)(var8 >>> 32),
                              (byte)(var8 >>> 24),
                              (byte)(var8 >>> 16),
                              (byte)(var8 >>> 8),
                              (byte)var8
                           }
                        );
                        var38 = (var10[0] & 255L) << 56
                           | (var10[1] & 255L) << 48
                           | (var10[2] & 255L) << 40
                           | (var10[3] & 255L) << 32
                           | (var10[4] & 255L) << 24
                           | (var10[5] & 255L) << 16
                           | (var10[6] & 255L) << 8
                           | var10[7] & 255L;
                        
                     } while (var2 < var5);

                     k = var6;
                     l = new Long[2];
                     break;
                  }
                  break;
               default:
                  var25[var10001] = var38;
                  if (var15 < var18) {
                     continue label41;
                  }

                  var17 = "\u0018Á\u009e¯ZÚ.éç\"ø\b\u0001¸®\u009a";
                  var18 = "\u0018Á\u009e¯ZÚ.éç\"ø\b\u0001¸®\u009a".length();
                  var15 = 0;
            }

            int var28 = var15;
            var15 += 8;
            var20 = var17.substring(var28, var15).getBytes("ISO-8859-1");
            var25 = var19;
            var10001 = var16++;
            var31 = (var20[0] & 255L) << 56
               | (var20[1] & 255L) << 48
               | (var20[2] & 255L) << 40
               | (var20[3] & 255L) << 32
               | (var20[4] & 255L) << 24
               | (var20[5] & 255L) << 16
               | (var20[6] & 255L) << 8
               | var20[7] & 255L;
            var34 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 19067;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/f4", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f4",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14051;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])m.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/f4", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f4",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = o[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = n[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 34;
            yield var15;
         }
         case 1 -> {
            byte var16 = 49;
            yield var16;
         }
         case 2 -> {
            byte var17 = 56;
            yield var17;
         }
         case 3 -> {
            byte var18 = 0;
            yield var18;
         }
         case 4 -> {
            byte var19 = 15;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 9;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 30;
            yield var24;
         }
         case 10 -> {
            byte var25 = 1;
            yield var25;
         }
         case 11 -> {
            byte var26 = 21;
            yield var26;
         }
         case 12 -> {
            byte var27 = 41;
            yield var27;
         }
         case 13 -> {
            byte var28 = 53;
            yield var28;
         }
         case 14 -> {
            byte var29 = 7;
            yield var29;
         }
         case 15 -> {
            byte var30 = 61;
            yield var30;
         }
         case 16 -> {
            byte var31 = 3;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 11;
            yield var33;
         }
         case 19 -> {
            byte var34 = 22;
            yield var34;
         }
         case 20 -> {
            byte var35 = 44;
            yield var35;
         }
         case 21 -> {
            byte var36 = 23;
            yield var36;
         }
         case 22 -> {
            byte var37 = 46;
            yield var37;
         }
         case 23 -> {
            byte var38 = 47;
            yield var38;
         }
         case 24 -> {
            byte var39 = 52;
            yield var39;
         }
         case 25 -> {
            byte var40 = 58;
            yield var40;
         }
         case 26 -> {
            byte var41 = 14;
            yield var41;
         }
         case 27 -> {
            byte var42 = 28;
            yield var42;
         }
         case 28 -> {
            byte var43 = 10;
            yield var43;
         }
         case 29 -> {
            byte var44 = 51;
            yield var44;
         }
         case 30 -> {
            byte var45 = 13;
            yield var45;
         }
         case 31 -> {
            byte var46 = 19;
            yield var46;
         }
         case 32 -> {
            byte var47 = 8;
            yield var47;
         }
         case 33 -> {
            byte var48 = 39;
            yield var48;
         }
         case 34 -> {
            byte var49 = 24;
            yield var49;
         }
         case 35 -> {
            byte var50 = 43;
            yield var50;
         }
         case 36 -> {
            byte var51 = 26;
            yield var51;
         }
         case 37 -> {
            byte var52 = 2;
            yield var52;
         }
         case 38 -> {
            byte var53 = 32;
            yield var53;
         }
         case 39 -> {
            byte var54 = 6;
            yield var54;
         }
         case 40 -> {
            byte var55 = 40;
            yield var55;
         }
         case 41 -> {
            byte var56 = 54;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 55;
            yield var58;
         }
         case 44 -> {
            byte var59 = 48;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 25;
            yield var61;
         }
         case 47 -> {
            byte var62 = 37;
            yield var62;
         }
         case 48 -> {
            byte var63 = 45;
            yield var63;
         }
         case 49 -> {
            byte var64 = 20;
            yield var64;
         }
         case 50 -> {
            byte var65 = 60;
            yield var65;
         }
         case 51 -> {
            byte var66 = 18;
            yield var66;
         }
         case 52 -> {
            byte var67 = 31;
            yield var67;
         }
         case 53 -> {
            byte var68 = 16;
            yield var68;
         }
         case 54 -> {
            byte var69 = 63;
            yield var69;
         }
         case 55 -> {
            byte var70 = 42;
            yield var70;
         }
         case 56 -> {
            byte var71 = 27;
            yield var71;
         }
         case 57 -> {
            byte var72 = 12;
            yield var72;
         }
         case 58 -> {
            byte var73 = 38;
            yield var73;
         }
         case 59 -> {
            byte var74 = 29;
            yield var74;
         }
         case 60 -> {
            byte var75 = 5;
            yield var75;
         }
         case 61 -> {
            byte var76 = 36;
            yield var76;
         }
         case 62 -> {
            byte var77 = 17;
            yield var77;
         }
         default -> 59;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            o[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      n[0] = "\u001d$\f*jm\u000b$\tpyz\u001co\nvun\r(\u001da>z7";
      n[1] = "b\u0011F\bFit\u0011CRU~cZ@TYjr\u001dWC\u0012}m";
      n[2] = "\u0015'\u000fi\u007f/\u0003'\n3l8\u0014l\t5`,\u0005+\u001e\"+>4";
      n[3] = int.class;
      o[3] = "java/lang/Integer";
      n[4] = "o\u001cbcSYy\u001cg9@NnWd?LZ\u007f\u0010s(\u0007O?";
      n[5] = ",h\tg'.'g\u0018(]*4f\bgk.#";
      n[6] = "R3Opx8L;U?\u001a$K&";
      n[7] = "\b\u001a~qo,\u0016\u0012d>\b-\u0007\tid.+";
      n[8] = "<\u001eve\tB9\u000b}e\nE6\u0002v'Kr\u001f] ";
      n[9] = void.class;
      o[9] = "java/lang/Void";
      n[10] = "=Y\n\b[H?GCpTD&D\u001f\u0012W";
      n[11] = float.class;
      o[11] = "java/lang/Float";
      n[12] = "TWD,V\bBWAvE\u001fU\u001cBpI\u000bD[Ug\u0002\u001fq";
      n[13] = "|k%_Q:wd4\u001004|o0J";
      n[14] = boolean.class;
      o[14] = "java/lang/Boolean";
      n[15] = "2*RfM^$*W<^I3aT:R]\"&C-\u0019J8";
      n[16] = "$\u007f|RX'Q_w]Ih0Q|VM2D";
      n[17] = "V\\\\rIC@\\Y(ZTW\u0017Z.V@FPM9\u001dU\n";
      n[18] = "^<y\n;9H<|P(._w\u007fV$:N0hAo-P";
      n[19] = "GnF9%\u00012NM64NS@F=0\u0014'";
      n[20] = "\u007fj#gm\u000bij&=~\u001c~!%;r\bof2,9\u0019J";
      n[21] = "`Dq\u0003w\u001a\u0015dz\ffUtjq\u0007b\u000f\u0000";
      n[22] = "h|gx\\H\u001d\\lwM\u0007|Rg|I]\b";
      n[23] = "\u0012,C^U<g\fHQDs\u0006\u0002CZ@)r";
      n[24] = "k;\u0016%d\u001e\u001e\u001b\u001d*uQ\u007f\u0015\u0016!q\u000b\u000b";
      n[25] = "ms=Qp\f\u0018S6^aCy]=Ue\u0019\r";
      n[26] = "$o\u001a\u001e\u0017/QO\u0011\u0011\u0006`0A\u001a\u001a\u0002:D";
      n[27] = "\u007ff ,aZif%vrM~-&p~Yoj1g5L,";
      n[28] = "U|h{\u0007. \\ct\u0016aARh\u007f\u0012;5";
      n[29] = "+jO,&Y^JD#7\u0016?DO(3LK";
      n[30] = ":k])s?OKV&bp.E]-f*Z";
      n[31] = "=1\u0000\u0007URH\u0011\u000b\bD\u001d)\u001f\u0000\u0003@G]";
      n[32] = "oQQVq?\u001aqZY`p{\u007fQRd*\u000f";
      n[33] = "DB(c\u001fCRB-9\fTE\t.?\u0000@TN9(KQp";
      n[34] = "BH6\u0003\u0002'7h=\f\u0013hVf6\u0007\u00172\"";
      n[35] = "\u001e1^\u001bT\u0017k\u0011U\u0014EX\n\u001f^\u001fA\u0002~";
      n[36] = "ukdjAX~du%\"Ukb";
      n[37] = "*iq\by)(=bp(\tG:,\n00:oa\u001b$Y";
      n[38] = "{RE\u0003)42CV_\u0010;B\u0016N[+arRKTaQ";
      n[39] = "\u0006f\"5&qAd\"3Gt<!s.~e^avq9\u001d\u0000&+t?\u007f@#t3G";
      n[40] = "xz\u000bdtL\"h\nc\u000b\u001c8o\u0014rw\u001a>\u0002S#sG!\u007f\u0011an\u000fD";
      n[41] = "\u0014-\u0005j\u0018k]<\u00166!e-i\u000e2\u001a>\u001d-\u000b=P\u000e";
      n[42] = "Z2vlo*\u00011%|\u0012\"\u0003\u001a*n{'\u0003;K/{$\\f{k~+\u0016Vupu0\u00009sgp7g";
      n[43] = "`/%nqu *z)\t~0x\u001d*qo&y=,d{\\(}40o>hxkw\u0017bq!*nxdf$-\t";
      n[44] = "\u00155>DEsVo!V}j*om_\fbT3lU\u0012";
      n[45] = "%\u0019N6yK~\u001a\u001d&\u0004C|&\u0018.\u007fW\u007f\u0007sumE#MC1hJi}I&m\u0017(M\r#b]\u0018G\u001a&?\u001c(\u0003\u001f)u,\"\u0014\u001at4\u001cf\u0011\u0015>\u0004\u0012}\u001a\u000e(k\u0014j\u001f\tO";
      n[46] = "flG\u0000u2'hRBH'/nR\u001b3JgqW@!)7jK\u0004H#g#_\u0005y!5q\u0003\u007f";
      n[47] = "_\f\u0006&\u007fIOIR.\u0010Y6\u0015J&iTD\tI|.0\\\u0000Y&!RZ\u001bE'\u0010";
      n[48] = "\u001dzF\fw2_8[D\u0012)M2B6#-L}WUs6P9>";
      n[49] = "@5\riBV\u001b6^y?^\u0019\u001cVyUU\u0010Q\nyV\nMaN|Y@}oUwBV\u0012iBrE1";
      n[50] = "\u00182\u001e8\r\n\u0002;N;i\u0005s$Z6\u0010\b\u00018YlWlC}\\$\u0011\u0012\u001f|V:i";
      n[51] = "\u001ai,<%RX+1t@ON*\u0012k0S'8e6$U\u0016:7dx/";
      n[52] = "umx5m_/\u007fy2\u0012\u000f2Xx2n\u001fI|,zv\u0014x~~(*n";
      n[53] = "\u0017\u0014c(7:\u001dE|.K0\u0002\neJ3V_Dbf3(\u0003EhxKfQ\u0001ho5:P\u000bv\u0017";
      n[54] = "9q\u0019!GEk;\u0007z}KT-\u001c~\u0004E&1\u001f$C!n#\b&M\u0011*&\u0007l}";
      n[55] = "T_\u000b\u00029\u0002\u0017\u0005\u0014\u0010\u0001\u0014k\u0005X\u0019p\u0013\u0015YY\u0013n";
      n[56] = "R\u0015\u0003h_HH\u001cSk;G9\u0003GfBJK\u001fD<\u0005.\b\u0006V:RMX\u001dJ~;";
      n[57] = "<R\u0017\u0004mXf@\u0016\u0003\u0012\u0002dG\u001b\u0001\u0012WeM\u000f\u001c}QrH\b{";
      n[58] = "+CR3\"V1J\u00020F[@U\u0016=?T2I\u0015gx0z[\u0002ev\u0000>^\r/F";
      n[59] = "V\u001c?\u001cj9\u0003Q.\b\u0003-oG8\rz \u001d[;W=DQE\"\u0013d+WR'\u0014\u0003";
      n[60] = "=\u0017\u000fvP\u001e6\u0003_:h\n[\u0019Cd\u0011\u0007)\u0005@>Vce\u001bYz\u000f\fc\f\\}h";
      n[61] = "/hgFZ\u001b-<t>\u000b:B28E\u0010\u0013<n9O\u000ek";
      n[62] = "Xao\u001d#$\u001fco\u001bB$b}x\u0006;,\u0010a{\\|H\\\u007fb\u0018%'Zhg\u001fB";
      n[63] = "Ly';c\u0006\u001e39`Y\u000b!%\"d \u0006S9!>gb\u001b+6<iR_.9vY";
      n[64] = "X;fQm\u0013\nqx\nW\u001cQge\u0000WIPgc\n8OGbdm";
      n[65] = "\"4I#iJz8R1\u0012O@:U#kA2&Vy,%\"4I#iJz8R1\u0012";
      n[66] = "\u0010\u007fPY\u0003\u0013\u0000:\u0004Ql\u0003yf\u001cY\u0015\u000e\u000bz\u001f\u0003RjGd\u0006G\u000b\u0005As\u0003@l";
      n[67] = "NR;\u00182u\u0014@:\u001fM?\u0013X3gw-\u001b\u0011nW3(\u0014[^";
      n[68] = "pmR\"\u001271iG`/%9\u0012G#\u001e,/kWfJ$@";
      n[69] = "C55_;K\u0019'4XD\u0013\u0013!P\u0011&\u0016@$3A=\n\u0004M9\u0011t\u001e\u0005|;C&B\u007f";
      n[70] = "_\u0004\u0012.8N\u0007\b\t<CH=\n\u000e.:EO\u0016\rt}!\u0003\b\u00140$N\u0005\u001f\u00117C";
      n[71] = "=F<\u0013\u000esgT=\u0014q-lBYV\u0018+:\u000ei\u0012\u001d$p>h\u000e\u001d}h]8\u0015\u00019\u0001";
      n[72] = "\u0016\u0007\u0015S\u0005PU]\nA=K)]FHLAW\u0001GBR";
      n[73] = "\f/\u000eSr\"Ou\u0011AJ:3u]H;3M)\\B%";
      n[74] = "f0\bSh*3}\u0019G\u0001>_k\u000fBx3-w\f\u0018?Wos\u000e^</.w\u001b\u001c\u0001";
      n[75] = "\u0000\u0019\\\u0005\u001a^Z\u000b]\u0002e\u0014A\u000b}\u001b\u001e\u0013<[P\u0013^_\f\u001fU\u001c\u0014o\u0006\bPAU_B\r_\u000beSD\u0004F\u0005T\tV\u0005Az";
      n[76] = ">5Hs`V\u007f1]1]DvJ\u000bf0N6#H</\\\u000e";
      n[77] = "V}K!NY\u0011\u007fK'/\\la\\:VQ\u001e}_`\u00115RcF$HZTtC#/";
      n[78] = "a%\\(to9)G:\u000fi\u0003+@(vdq7Cr1\u0000?4X4p1e&Y3\u000f";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = n[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            n[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  n[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(968675308995808L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  n[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(968675308995808L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        n[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(968675308995808L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 235;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 186;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 204;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 223;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 218;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 107;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 235;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 186;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 204;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/f4",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/f4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Supplier invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Supplier invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
