package dev.zprestige.prestige.renderlib;

public record RenderCommandDepth(RenderCommand bX, float bY) {
}
