package dev.zprestige.prestige.renderlib;

import java.util.ArrayList;
import net.minecraft.util.math.Vec3d;

public record RenderCommandList(ArrayList<Vec3d> bV, boolean bW) {

    public final java.util.ArrayList<net.minecraft.util.math.Vec3d> recoveryAccess_read_bV() { return this.bV; }

    public final boolean recoveryAccess_read_bW() { return this.bW; }
}
