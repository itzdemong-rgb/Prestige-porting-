package dev.zprestige.prestige.renderlib;

import net.minecraft.client.render.Camera;
import org.joml.Matrix4f;

public record RenderContext(Matrix4f bm, Matrix4f bn, Camera bo) {

    public final net.minecraft.client.render.Camera recoveryAccess_read_bo() { return this.bo; }
}
