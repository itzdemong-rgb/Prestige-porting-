package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.ManagedGlBuffer;
import dev.zprestige.prestige.renderlib.RenderPassBuilder;
import dev.zprestige.prestige.api.util.NumberUtil;
import dev.zprestige.prestige.renderlib.GlVertexArray;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.RenderContext;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalDouble;
import java.util.OptionalInt;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;
import org.lwjgl.system.MemoryStack;

public class RenderPass {
   private final IntSupplier a;
   private final OptionalInt b;
   private final OptionalDouble c;
   public final GlProgram d;
   private final int e;
   private final int f;
   private static final long g = 131353753398834L;
   private static final String[] h;
   private static final String[] i;
   private static final Map j = new HashMap(13);
   private static final long[] k;
   private static final Integer[] l;
   private static final Map m;
   private static final long[] n;
   private static final Long[] o;
   private static final Map p;
   private static final Object[] q = new Object[74];
   private static final String[] r = new String[74];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;

   public RenderPass(RenderPassBuilder var1, long var2) {
      super();
      var2 = 131353753398834L ^ var2;

      short var10002 = 20773;
      long var10003 = 885751697012400183L ^ var2;
      String var5 = "targetFramebuffer cannot be null";
      IntSupplier var4 = var1.recoveryAccess_read_a();
      this.a = Objects.requireNonNull(var4, var5);
      var10002 = 6146;
      var10003 = 6518810729787779346L ^ var2;
      String var7 = "clearColor cannot be null";
      OptionalInt var6 = var1.recoveryAccess_read_b();
      this.b = Objects.requireNonNull(var6, var7);
      var10002 = 30201;
      var10003 = 1791429687347774698L ^ var2;
      String var9 = "clearDepth cannot be null";
      OptionalDouble var8 = var1.recoveryAccess_read_c();
      this.c = Objects.requireNonNull(var8, var9);
      var10002 = 5567;
      var10003 = 3055032342488376494L ^ var2;
      String var11 = "shaderProgram cannot be null";
      GlProgram var10 = var1.recoveryAccess_read_d();
      this.d = Objects.requireNonNull(var10, var11);
      GlProgram var10001 = var1.recoveryAccess_read_d();
      Object[] var13 = new Object[0];
      GlProgram var12 = var10001;
      this.e = var12.bReturningInt(var13);
      var10001 = var1.recoveryAccess_read_d();
      Object[] var15 = new Object[0];
      GlProgram var14 = var10001;
      this.f = var14.cReturningInt(var15);
   }

   public static RenderPassBuilder aReturningdu_C0204(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 131353753398834L ^ var1;
      long var3 = var1 ^ 32626212301517L;
      return new RenderPassBuilder(var3);
   }

   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 131353753398834L ^ var2;
      long var4 = var2 ^ 76587579517402L;
      short var10000 = 26798;
      long var10001 = 6297757158457351561L ^ var2;
      char var15 = '赀';
      IntSupplier var6 = this.a;
      int var8 = var6.getAsInt();
      GL30.glBindFramebuffer(36160, var8);
      Object[] var10 = new Object[]{var4};
      RenderPass var9 = this;
      var9.eReturningVoid(var10);
      GlProgram var16 = this.d;
      Object[] var12 = new Object[0];
      GlProgram var11 = var16;
      int var13 = var11.aReturningInt(var12);
      GL30.glUseProgram(var13);
   }

   
   
   public void bReturningVoid(Object[] var1) {
      RenderContext var4 = (RenderContext)var1[0];
      long var2 = (Long)var1[1];
      var2 = 131353753398834L ^ var2;
      int var10000 = Event.bReturningInt();
      GlProgram var10001 = this.d;
      Object[] var11 = new Object[0];
      GlProgram var10 = var10001;
      var10.aReturningInt(var11);
      int var5 = var10000;
      MemoryStack var7 = MemoryStack.stackPush();

      try {
         label62: {
            short var69 = 30612;
            long var10002 = 4298170115449006737L ^ var2;
            MemoryStack var12 = var7;
            FloatBuffer var8 = var12.mallocFloat(16);
            short var70 = 203;
            var10002 = 695709436853181893L ^ var2;
            MemoryStack var14 = var7;
            FloatBuffer var9 = var14.mallocFloat(16);
            int var51 = var5;
            int var50 = this.e;
            int var41 = var50;
            int var40 = var50;
            if (var51 == 0) {
               int var52 = var40;
               if (var52 >= 0) {
                  RenderContext var17 = var4;
                  Matrix4f var67 = var17.bm();
                  FloatBuffer var19 = var8;
                  Matrix4f var18 = var67;
                  var18.get(var19);
                  FloatBuffer var20 = var8;
                  var20.rewind();
                  byte var71 = 0;
                  FloatBuffer var23 = var8;
                  int var21 = this.e;
                  GL30.glUniformMatrix4fv(var21, false, var23);
               }

               var41 = this.f;
            }

            int var54 = var5;
            int var53 = var41;
            int var43 = var53;
            int var42 = var53;
            if (var54 == 0) {
               int var55 = var42;
               if (var55 < 0) {
                  break label62;
               }

               RenderContext var26 = var4;
               Matrix4f var68 = var26.bn();
               FloatBuffer var28 = var9;
               Matrix4f var27 = var68;
               var27.get(var28);
               FloatBuffer var29 = var9;
               var29.rewind();
               int var56 = this.f;
               var43 = var56;
            }

            byte var72 = 0;
            FloatBuffer var33 = var9;
            int var31 = var43;
            GL30.glUniformMatrix4fv(var31, false, var33);
      } catch (Throwable var65) {
         int var61 = var5;
         MemoryStack var60 = var7;
         MemoryStack var48 = var60;
         MemoryStack var47 = var60;
         if (var61 == 0) {
            MemoryStack var62 = var47;
            if (var62 == null) {
               throw var65;
            }

            try {
               var48 = var7;
            } catch (Throwable var64) {
               var65.addSuppressed(var64);
               throw var65;
            }
         }

         try {
            MemoryStack var37 = var48;
            var37.close();
         } catch (Throwable var63) {
            var65.addSuppressed(var63);
         }

         throw var65;
      }

      int var58 = var5;
      MemoryStack var57 = var7;
      MemoryStack var45 = var57;
      MemoryStack var44 = var57;
      if (var58 == 0) {
         MemoryStack var59 = var44;
         if (var59 == null) {
            return;
         }

         var45 = var7;
      }

      MemoryStack var35 = var45;
      var35.close();
   }

   public void cReturningVoid(Object[] var1) {
      GlVertexArray var3 = (GlVertexArray)var1[0];
      ManagedGlBuffer var8 = (ManagedGlBuffer)var1[1];
      int var5 = (Integer)var1[2];
      int var2 = (Integer)var1[3];
      int var4 = (Integer)var1[4];
      long var6 = (Long)var1[5];
      var6 = 131353753398834L ^ var6;
      invokeBinding2(invokeBinding1(var3, new Object[0], 9068451296763304207L, var6), 9068764574201146253L, var6);
      invokeBinding5(
         invokeBinding3(30947, 8994139200398755467L ^ var6), invokeBinding4(var8, new Object[0], 9061689657802376896L, var6), 9061258977035603958L, var6
      );
      invokeBinding8(
         var5, var2, invokeBinding6(10754, 4205392863717807208L ^ var6), invokeBinding7(4276, 6003503296598868409L ^ var6), var4, 9069115168939741588L, var6
      );
      invokeBinding9(0, 9068764574201146253L, var6);
      invokeBinding11(invokeBinding10(10849, 1166075347349918722L ^ var6), 0, 9061258977035603958L, var6);
   }

   public void dReturningVoid(Object[] var1) {
      GlVertexArray var6 = (GlVertexArray)var1[0];
      ManagedGlBuffer var7 = (ManagedGlBuffer)var1[1];
      int var3 = (Integer)var1[2];
      int var2 = (Integer)var1[3];
      long var4 = (Long)var1[4];
      var4 = 131353753398834L ^ var4;
      Object[] var9 = new Object[0];
      GlVertexArray var8 = var6;
      int var10 = var8.aReturningInt(var9);
      GL30.glBindVertexArray(var10);
      short var10000 = 10849;
      long var10001 = 1166014117130599493L ^ var4;
      char var18 = '袓';
      Object[] var12 = new Object[0];
      ManagedGlBuffer var11 = var7;
      int var14 = var11.aReturningInt(var12);
      GL30.glBindBuffer(34963, var14);
      short var10002 = 1150;
      long var10003 = 2103337686904951381L ^ var4;
      var10002 = 5125;
      short var22 = 32328;
      long var10004 = 5405700930960148227L ^ var4;
      int var16 = var2;
      int var15 = var3;
      GL30.glDrawElements(var15, var16, 5125, 0L);
      GL30.glBindVertexArray(0);
      var10000 = 10849;
      var10001 = 1166014117130599493L ^ var4;
      GL30.glBindBuffer(34963, 0);
   }

   private void eReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 131353753398834L ^ var2;
      long var4 = var2 ^ 63199509869433L;
      long var6 = var2 ^ 122826067443875L;
      long var8 = var2 ^ 102685741635747L;
      long var10 = var2 ^ 104592297675611L;
      int var10000 = Event.bReturningInt();
      int var12 = var10000;
      OptionalInt var15 = this.b;
      short var57 = ((short)((var15.isPresent()) ? 1 : 0));
      int var47 = var12;
      byte var46 = (byte)var57;
      byte var41 = var46;
      byte var40 = var46;
      if (var47 == 0) {
         byte var48 = var40;
         if (var48 != 0) {
            OptionalInt var17 = this.b;
            int var14 = var17.getAsInt();
            Object[] var10003 = new Object[]{null, var6};
            var10003[0] = var14;
            Object[] var18 = var10003;
            float var58 = NumberUtil.cReturningFloat(var18);
            Object[] var10004 = new Object[]{null, var4};
            var10004[0] = var14;
            Object[] var19 = var10004;
            float var10001 = NumberUtil.dReturningFloat(var19);
            Object[] var10005 = new Object[]{null, var10};
            var10005[0] = var14;
            Object[] var20 = var10005;
            float var10002 = NumberUtil.eReturningFloat(var20);
            Object[] var10006 = new Object[]{null, var8};
            var10006[0] = var14;
            Object[] var21 = var10006;
            float var25 = NumberUtil.bReturningFloat(var21);
            float var24 = var10002;
            float var23 = var10001;
            float var22 = var58;
            GL30.glClearColor(var22, var23, var24, var25);
            short var60 = 6066;
            long var63 = 6869202911714108796L ^ var2;
            var13 = 0 | 16384;
         }

         OptionalDouble var26 = this.c;
         var41 = ((byte)((var26.isPresent()) ? 1 : 0));
      }

      int var50 = var12;
      byte var49 = var41;
      int var43 = var49;
      byte var42 = var49;
      if (var50 == 0) {
         byte var51 = var42;
         if (var51 != 0) {
            OptionalDouble var28 = this.c;
            double var29 = var28.getAsDouble();
            GL30.glClearDepth(var29);
            short var61 = 24206;
            long var64 = 894421664062090308L ^ var2;
            var13 |= 256;
         }

         var43 = var13;
      }

      int var53 = var12;
      int var52 = var43;
      int var45 = var52;
      int var44 = var52;
      if (var53 == 0) {
         int var54 = var44;
         if (var54 == 0) {
            return;
         }

         var57 = 21527;
         long var62 = 8521655642046244571L ^ var2;
         GL30.glDisable(3089);
         GL30.glDepthMask(true);
         GL30.glColorMask(true, true, true, true);
         int var55 = var13;
         var45 = var55;
      }

      int var39 = var45;
      GL30.glClear(var39);
   }

   static {

      {

      aReturningVoid();
      Cipher var24;
      Cipher var10000 = var24 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var25 = 1; var25 < 8; var25++) {
         var10003[var25] = (byte)(106901408353107L << var25 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var31 = new String[4];
      String var28 = "\u009e\u0084\u0090\u0095¶¢ù[4h|\u0080àeÆ#[\u0098\u0006&C4ì\u0081WRÔ\u009e°~lY9Î¸\u008cz\u0088ºS ó\u0006}!\u0090«qíì\u0019Qåq\u008e¥Z\u0098ý?\u0011B\f\u00148\u008bý ¼ù¬\u0085\u009b-Ô\u0088¨`ª\u0085Ã]bbéã7\u0092\u008dÛ\u0012\u001d\u0005\u0085\u009cXìió[µaÂ9\u0016×[DW>µM¹\b¶ë\u0088t\u0080.¿";
      int var30 = "\u009e\u0084\u0090\u0095¶¢ù[4h|\u0080àeÆ#[\u0098\u0006&C4ì\u0081WRÔ\u009e°~lY9Î¸\u008cz\u0088ºS ó\u0006}!\u0090«qíì\u0019Qåq\u008e¥Z\u0098ý?\u0011B\f\u00148\u008bý ¼ù¬\u0085\u009b-Ô\u0088¨`ª\u0085Ã]bbéã7\u0092\u008dÛ\u0012\u001d\u0005\u0085\u009cXìió[µaÂ9\u0016×[DW>µM¹\b¶ë\u0088t\u0080.¿"
         .length();
      char var27 = '@';
      int var35 = -1;

      label72:
      while (true) {
         String var36 = var28.substring(++var35, var35 + var27);
         int var10001 = -1;

         while (true) {
            byte[] var32 = var24.doFinal(var36.getBytes("ISO-8859-1"));
            String var50 = a(var32).intern();
            switch (var10001) {
               case 0:
                  var31[var29++] = var50;
                  if ((var35 += var27) >= var30) {
                     h = var31;
                     i = new String[4];
                     m = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(106901408353107L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[10];
                     String var15 = "\u008eõ©5Õg#\f\u008eÐ\u001c ûªJ?\u0084Ùèz\u0091\u0010&«5Í\u0094!¸x\u000eG\u009eã-þ\u0087ÔY©\u008b\u0018½¥0\u00065o\\\u0003^äâM\u0014\u0016*û\u0099_?\u0090ÊR";
                     int var16 = "\u008eõ©5Õg#\f\u008eÐ\u001c ûªJ?\u0084Ùèz\u0091\u0010&«5Í\u0094!¸x\u000eG\u009eã-þ\u0087ÔY©\u008b\u0018½¥0\u00065o\\\u0003^äâM\u0014\u0016*û\u0099_?\u0090ÊR"
                        .length();
                     label54:
                     while (true) {
                        var10001 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var10001, var13).getBytes("ISO-8859-1");
                        long[] var39 = var17;
                        var10001 = var14++;
                        long var54 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var54;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var62 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var58) {
                              case 0:
                                 var39[var10001] = var62;
                                 if (var13 >= var16) {
                                    k = var17;
                                    l = new Integer[10];
                                    p = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(106901408353107L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[2];
                                    String var4 = "K\u0087AV×\u0011qs¼&ð\u0006n>À»";
                                    int var5 = "K\u0087AV×\u0011qs¼&ð\u0006n>À»".length();
                                    do {
                                       int var47 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var47, var2).getBytes("ISO-8859-1");
                                       var47 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var62 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       
                                    } while (var2 < var5);

                                    n = var6;
                                    o = new Long[2];
                                    break;
                                 }
                                 break;
                              default:
                                 var39[var10001] = var62;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "+»\u0082\u0082\u0089bÍÜ\"oVòÈP#\u009d";
                                 var16 = "+»\u0082\u0082\u0089bÍÜ\"oVòÈP#\u009d".length();
                                 var13 = 0;
                           }

                           int var46 = var13;
                           var13 += 8;
                           var18 = var15.substring(var46, var13).getBytes("ISO-8859-1");
                           var39 = var17;
                           var10001 = var14++;
                           var54 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var58 = 0;
                        }
                     }
                  }

                  var27 = var28.charAt(var35);
                  break;
               default:
                  var31[var29++] = var50;
                  if ((var35 += var27) < var30) {
                     var27 = var28.charAt(var35);
                     continue label72;
                  }

                  var28 = "ø¦\u008a8\u000f³\u0018õ\u0005|Æ÷Ý¬cEú\u0002\u008aÖ¹\\¨OÖ\u0090ýði-Uñ¾FI\u001f\u0088\u001alÝzòÊÝ|§\u0001\u007f¼\u0084ckÚ>ÿ¬8\r«ói\u000bBAYÂ\u0014+\b\\*!åNel³FE©3|b\u000baÁ\u0010\u0013i\fßr\u008dÄ?$W2ñÖÞk_\u001b&e\u000e\f\u0082\u0091³Ãm";
                  var30 = "ø¦\u008a8\u000f³\u0018õ\u0005|Æ÷Ý¬cEú\u0002\u008aÖ¹\\¨OÖ\u0090ýði-Uñ¾FI\u001f\u0088\u001alÝzòÊÝ|§\u0001\u007f¼\u0084ckÚ>ÿ¬8\r«ói\u000bBAYÂ\u0014+\b\\*!åNel³FE©3|b\u000baÁ\u0010\u0013i\fßr\u008dÄ?$W2ñÖÞk_\u001b&e\u000e\f\u0082\u0091³Ãm"
                     .length();
                  var27 = '8';
                  var35 = -1;
            }

            var36 = var28.substring(++var35, var35 + var27);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27202;
      if (i[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])j.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dt", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = h[var5].getBytes("ISO-8859-1");
         i[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return i[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dt_C0202",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dt" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 954;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])m.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dt", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dt_C0202",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dt" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 27869;
      if (o[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = n[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])p.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               p.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dt", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         o[var3] = var15;
      }

      return o[var3];
   }

   private static long c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = c(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dt_C0202",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dt" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = r[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = q[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 57;
            yield var15;
         }
         case 1 -> {
            byte var16 = 58;
            yield var16;
         }
         case 2 -> {
            byte var17 = 4;
            yield var17;
         }
         case 3 -> {
            byte var18 = 15;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 27;
            yield var20;
         }
         case 6 -> {
            byte var21 = 17;
            yield var21;
         }
         case 7 -> {
            byte var22 = 28;
            yield var22;
         }
         case 8 -> {
            byte var23 = 32;
            yield var23;
         }
         case 9 -> {
            byte var24 = 61;
            yield var24;
         }
         case 10 -> {
            byte var25 = 41;
            yield var25;
         }
         case 11 -> {
            byte var26 = 16;
            yield var26;
         }
         case 12 -> {
            byte var27 = 18;
            yield var27;
         }
         case 13 -> {
            byte var28 = 39;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 35;
            yield var30;
         }
         case 16 -> {
            byte var31 = 29;
            yield var31;
         }
         case 17 -> {
            byte var32 = 43;
            yield var32;
         }
         case 18 -> {
            byte var33 = 14;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 48;
            yield var36;
         }
         case 22 -> {
            byte var37 = 42;
            yield var37;
         }
         case 23 -> {
            byte var38 = 0;
            yield var38;
         }
         case 24 -> {
            byte var39 = 23;
            yield var39;
         }
         case 25 -> {
            byte var40 = 47;
            yield var40;
         }
         case 26 -> {
            byte var41 = 50;
            yield var41;
         }
         case 27 -> {
            byte var42 = 60;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 63;
            yield var44;
         }
         case 30 -> {
            byte var45 = 51;
            yield var45;
         }
         case 31 -> {
            byte var46 = 6;
            yield var46;
         }
         case 32 -> {
            byte var47 = 12;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 34;
            yield var49;
         }
         case 35 -> {
            byte var50 = 45;
            yield var50;
         }
         case 36 -> {
            byte var51 = 59;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 46;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 54;
            yield var55;
         }
         case 41 -> {
            byte var56 = 1;
            yield var56;
         }
         case 42 -> {
            byte var57 = 8;
            yield var57;
         }
         case 43 -> {
            byte var58 = 26;
            yield var58;
         }
         case 44 -> {
            byte var59 = 20;
            yield var59;
         }
         case 45 -> {
            byte var60 = 49;
            yield var60;
         }
         case 46 -> {
            byte var61 = 44;
            yield var61;
         }
         case 47 -> {
            byte var62 = 33;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 25;
            yield var64;
         }
         case 50 -> {
            byte var65 = 10;
            yield var65;
         }
         case 51 -> {
            byte var66 = 19;
            yield var66;
         }
         case 52 -> {
            byte var67 = 38;
            yield var67;
         }
         case 53 -> {
            byte var68 = 13;
            yield var68;
         }
         case 54 -> {
            byte var69 = 30;
            yield var69;
         }
         case 55 -> {
            byte var70 = 2;
            yield var70;
         }
         case 56 -> {
            byte var71 = 5;
            yield var71;
         }
         case 57 -> {
            byte var72 = 53;
            yield var72;
         }
         case 58 -> {
            byte var73 = 24;
            yield var73;
         }
         case 59 -> {
            byte var74 = 7;
            yield var74;
         }
         case 60 -> {
            byte var75 = 9;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 11;
            yield var77;
         }
         default -> 56;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            r[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      q[0] = "\u0019{YX<7\u0007sC\u0017] \u0019\u007fLMa";
      q[1] = "0*\u0019D>T;%\b\u000b_Z0.\fQ";
      q[2] = "1\u0019\b\u007fB\u0004:\u0016\u00190?\u001c)\u0011\u0010y";
      q[3] = "Bp2c8=Tp79+*C;4?'>R|#(l+k";
      q[4] = "\u0016\u0018\u00050|tc8\u000e?m;\u00026\u00054iav";
      q[5] = int.class;
      r[5] = "java/lang/Integer";
      q[6] = "'eP\bI\nRE[\u0007XE3KP\f\\\u001fG";
      q[7] = "\u0010\bX-om\u0015\u001dS-lj\u001a\u0014Xo-]3I\u000f";
      q[8] = void.class;
      r[8] = "java/lang/Void";
      q[9] = "l\u0005[n3ir\rA!{ih\u0007Yfrr(-C{Niv\u0014Afxn";
      q[10] = "Vd29Cg@d7cPpW/4e\\dFh#r\u0017sF";
      q[11] = "7&Au.\u001fB\u0006Jz?P#\bAq;\nW";
      q[12] = "\u0011t\n@oPdT\u0001O~\u001f\u0005Z\nDzEq";
      q[13] = "\u0019\rxPQA\u000f\r}\nBV\u0018F~\fNB\t\u0001i\u001b\u0005WJ";
      q[14] = "\u0016\u0010U3.(c0^<?g\u0002>U7;=v";
      q[15] = "Zh\u001d<\u0018\u0012_}\u0016<\u001b\u0015Pt\u001d~Z\"y)KQ";
      q[16] = long.class;
      r[16] = "java/lang/Long";
      q[17] = "\r\u001f<\rUj\u001b\u001f9WF}\fT:QJi\u001d\u0013-F\u0001x9";
      q[18] = "\u0005b~1B=pBu>Sr\u0011L~5W(e";
      q[19] = "G\"\u001b[n-L-\n\u0014\u0014)_,\u001a[\"-H";
      q[20] = "T)Nj3XQ<Ej,VH/L)qb^6F6&|O:J/";
      q[21] = "6'03\u001cs '5i\u000fd7l6o\u0003p&+!xHd(";
      q[22] = "\u000eO>G\u001aq\fQw$\u0011j\u0013T!]\u0016";
      q[23] = "l\u000b{@\u000bio\u0005#gIhg\u001eOTCac\u0018";
      q[24] = "M}\u007fL2P[}z\u0016!GL6y\u0010-S]qn\u0007fAl";
      q[25] = boolean.class;
      r[25] = "java/lang/Boolean";
      q[26] = "\u0003:[ e}\u001d2Ao\u0004x\u001d2B/*d 5Y";
      q[27] = "*+Eui\f<+@/z\u001b+`C)v\u000f:'T>=\u001a{";
      q[28] = "\u0019,!}0/l\f*r!`\r\u0002!y%:y";
      q[29] = float.class;
      r[29] = "java/lang/Float";
      q[30] = "@$\u0003?:|5\u0004\b0+3T\n\u0003;/i ";
      q[31] = "\u0013I\r=\u0017G\rA\u0017rvB\rA\u00142X^=G\u000e>UW";
      q[32] = double.class;
      r[32] = "java/lang/Double";
      q[33] = "\u001bwx\u0016\\dnWs\u0019M+\u000fYx\u0012Iq{";
      q[34] = "\u0017G\u001b\u001e8\u0016bg\u0010\u0011)Y\u0003i\u001b\u001a-\u0003w";
      q[35] = ")\f\u000e\nY*g\u0004\u0001N62\u0018R\u0017CX&eF\u0004ZZ[#RPR[;a\f\u001a\f6";
      q[36] = "n_]\u0017)Af\u000e[B\u0019\n\u007f[TMA\fxR?Ct\u0013:\u0002\u000fK%\u0015o2";
      q[37] = "&.}0\u0001\u001a6>~*|[$3e)\u0010!&.}0\u0001\u001a6>~*|";
      q[38] = "\u0006I\u0017\nCZZ\u0006\u0003\n~QfM\u000e\u000f\u001fV\u0006\u000fPEA;";
      q[39] = "uX\u001f1vMjM\u001f*\u0015\u0017og\\#n\u001brC&.oF+D\u001c*$Hm?";
      q[40] = "i8\u00022\u0005\u00108h\u001c-iD0\u0019\u001a$\u0000QTi\u0018s\bF4+F9V+jl\u0017#V\u0012+6\u00043i";
      q[41] = "JcC\\\u00120\u0010%\u0001c\u0003,\t\"\u001f\u0019\u0014\u0007\u001798\u001e\u001d%p#\u0015_\u0018<\u001a0\u0006Yyx\u00132ORG<\u0011;\u0010c\u0005*L>\u0003\t\u00169J_";
      q[42] = "8Y\u0001z\u0012mlM\u0017z)i5m\u0002uVK5L\u001dqOz*`\u001egUo7J\u0015p)=7\u001b\u0019qI\u007fiQG\u001c\u0012`k@\u0015|P>!\u001ex'O<0L\u0018e\u0011vn!\u0012qY|/\u0010\u001ezXlQ\u001a\u001e&Hk1X@l\u0016\u0006o\u001f\u0011v\u0016?.E\u0002f)";
      q[43] = "M\fx:=\fY\u0004a0L\u001cEvpg)FL\u001br;(\u0010 ";
      q[44] = "%@6\u001c\u0002\u0017:U6\u0007aC)[F\u0018 J8'4\u0005[M)Gv[\u0011\u0013D";
      q[45] = "QB#?y\u001eVZ'~\u0006I\u0002D\b;G@\u00138z&<G\u0002X8xv\u0019o";
      q[46] = "#g\u001a\"}ctm\u000ev\u0000v#n-oxg5o\rimsOn\u0013~0b39\u0019jd\u001fq<\u001fx?&0f\fh\u0000";
      q[47] = "\u000fiH/Ni^9V0\"=VIU2N\f_yH9R\u001bHy]%\"iT9U9B+\ns\u000bT\u001cl[i\u000bm]6Hy4";
      q[48] = "}\u001b\u0007\\\t\u0011f\u0013\u0014\u0002g\u001ft\u0015<B+\u0017d\u0003\u0011Tg\u0015rW\u0005]\u0016K(\u001bM9";
      q[49] = "$}n2I>nv$ ,i\u001e*a2B\u007fc>r+@\u0002%*&#Abgtl},";
      q[50] = "\u007fNt\nc?.\u0004-L_*AZoA1:<N|X3G\u007f\u0002{[`~>XhK_";
      q[51] = "<Q?\u0000z\n \u0011r]C\u0006^\u0006sM-\u0010#\u0012`T/m=\u000e1L&\u000eb\u0011\u007fYC";
      q[52] = "pr]\u0014cJ!\"C\u000b\u000f\u001e)T[\u0006p<)uD\u0002i\r6\u0018\u001a\t5\u0010 xXW\u007fNM#GUn\u001c-a\u0019\u001f0qv~\u001b\u000eb\u00114 QP\u000f\u001b h[\u0011>\u0017+iKo1O$r\u001eVp\u00157b!";
      q[53] = "e\u0011I~\u001fy/\u001a\u0003lz,_FF~\u00148\"RUg\u0016EdF\u0001o\u0017%&\u0018K1z";
      q[54] = "\u001a\r\u0002\u0003\u001e\u0019\u0001\u0005\u0011]p\u0019\u0005'\n\u000b\u000b\u0015\u0018\u0003p\u0006\nHA\u0004J\u0002AF\u0007\u007f";
      q[55] = "ED\u0014dZ\nM\u0015\u00121j_AM\u0012:\u0001tLN\u001f!j\u0001N\u0013\u00170\nC\u0010YI]\u0005XQV\u000bf\u0015HRLv";
      q[56] = ".)U<\u0014;\u007fyK#xow\u000fH<\u0011jw.)|\u001e:r.I>@p,C\u0017y\u0011j,zV#\u0002z\u0013";
      q[57] = "\u0013!Kg^LBqUx2\u0018J\u0000Sq[\re,S{HwM%\bmW\u0014\u0012:Fx2\u0014@tFyQK_:S\u001cQ\u0019\u0011:R\u007f\u000e\u0006_/7\u007f\\H_.T C\u0006JK\t\"[\u001d\u0011rHxH\r.";
      q[58] = "Uw {a\u001d\u0004=y=]\fki#,m\u0018\u0017>)89e\u0007`*p \u0019Pj>$]";
      q[59] = "BS>\u0006\u001cSV['\fmCI)6[\b\u0019CD4\u0007\tO/";
      q[60] = ":gC\"\r;&'\u000e\u007f41X0\u000foZ!%$\u001cvX\\;8MnQ?d'\u0003{4";
      q[61] = "TEXQXJ\u0005\u0015FN4\u001e\rr_Gl\u000b\u000e@^CQqRI\u001eKY\u0011\u0010\u0017T\u00154OWFN\u0015\r\u000e\rU^*";
      q[62] = "%3\u0007lz\rtc\u0019s\u0016Y|\u0015\u0016ojV]0\u0000t\u0016VbiDl,R)g\u0002\u0017(\bq3D.iRb#{";
      q[63] = "}E__\u0013'a\u0005\u0012\u0002*,\u001f\u0012\u0013\u0012D=b\u0006\u0000\u000bF@|\u001aQ\u0013O##\u0005\u001f\u0006*";
      q[64] = "t^\u001d}\u0015a%\u000e\u0003by5-\u007f\u0006b\u001e \f]\u001aey:3\u0004^}C>x\n\u0018\u0006\u0019 y\u000b\u001a<\u001dkwMaf\u0003jvO[bHd04\u0001|Ie2\u000e\u00057G#I\n_o\u0013epK\u0005|\u0003Z";
      q[65] = " \u001c8cR/(M>6bt)\u0016!7b!s\u00180e[`)\u000b Z";
      q[66] = "\u0007B+\"\bNMIa0m\u0018=\u0015$\"\u0003\u000f@\u00017;\u0001r\u0006\u0015c3\u0000\u0012DK)mm";
      q[67] = "[\u0011>6X\u007f\fF>\u007fei0\u001c*?\u000b}M\b9&\t\u0000\u000b\u001cm.\b`IB'pe";
      q[68] = "`+\u0000G+<1{\u001eXGh9\u000b\u001dZ+I'(\u0019Q-z3/\u0011FG<;{\u001dQ'~e1C<|ag \u0011\\>?-~|\u0002yn7~EC#}'A";
      q[69] = "qi\u0013[VF 9\rD:\u0012(I\u000eFV71m\u0001M@}weUAW\u001d5;\u001f\u001f:F*9\u000eMZ\u0004tsP \u0004C%iP\u0019E\u00196yo";
      q[70] = "}e\u001d\u0007U%\u007f9\u001cQ9'~uxX[1ltCHK2v\t\u0017U@7n2\u0007EC-\u0013";
      q[71] = "~>FLS0/nXS?d'\t\\VQl91\u007f^Cq\"$\u0006YA\u000bx2\u0000VRk:lJ\b?k9d\u0005L\u0005orjC7Pi:+G\f@y91:\t\u0001b)k\u0003H[q9T";
      q[72] = "P-r\u000f\f0Lm?R5=2z>B[*On-[YWQr|CP4\u000em2V5";
      q[73] = "/XD\u0012w\u0012~\bZ\r\u001bFvy\\\u0004rS^_@\u0015{)wY\u0006\u0019\u007fX)\u0003JQ\u001b\u0017,[RV\"VvHBi";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = q[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(r[var4]);
            q[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = q[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            q[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  q[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(82762403729222L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = q[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = r[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  q[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(82762403729222L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        q[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(82762403729222L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 165;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 164;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 226;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 99;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 192;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 76;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 165;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 164;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 226;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dt_C0202",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dt" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int invokeBinding1(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache1;
         MethodHandle var9 = bindingCache1;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache1 = d(MethodHandles.lookup(), "À", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (int)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding2(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = d(MethodHandles.lookup(), "L", SourceSupport.methodType("(IJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding3(int var0, long var1) {
         MethodHandle var7 = bindingCache3;
         MethodHandle var6 = bindingCache3;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache3 = b(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding4(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache4;
         MethodHandle var9 = bindingCache4;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache4 = d(MethodHandles.lookup(), "À", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding5(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = d(MethodHandles.lookup(), "L", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding6(int var0, long var1) {
         MethodHandle var7 = bindingCache6;
         MethodHandle var6 = bindingCache6;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache6 = b(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static long invokeBinding7(int var0, long var1) {
         MethodHandle var7 = bindingCache7;
         MethodHandle var6 = bindingCache7;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache7 = c(MethodHandles.lookup(), "d", SourceSupport.methodType("(IJ)J", MethodHandles.lookup())).dynamicInvoker();
         }

         return (long)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding8(int var0, int var1, int var2, long var3, int var5, long var6, long var8) {
         MethodHandle var14 = bindingCache8;
         MethodHandle var13 = bindingCache8;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache8 = d(MethodHandles.lookup(), "L", SourceSupport.methodType("(IIIJIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var11.invokeExact((int)var0, (int)var1, (int)var2, (long)var3, (int)var5, (long)var6, (long)var8);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static void invokeBinding9(int var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = d(MethodHandles.lookup(), "L", SourceSupport.methodType("(IJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var6.invokeExact((int)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding10(int var0, long var1) {
         MethodHandle var7 = bindingCache10;
         MethodHandle var6 = bindingCache10;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache10 = b(MethodHandles.lookup(), "w", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding11(int var0, int var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = d(MethodHandles.lookup(), "L", SourceSupport.methodType("(IIJJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var7.invokeExact((int)var0, (int)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }
}
