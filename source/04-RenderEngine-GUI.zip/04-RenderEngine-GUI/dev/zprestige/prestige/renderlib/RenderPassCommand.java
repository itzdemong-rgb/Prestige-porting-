package dev.zprestige.prestige.renderlib;

import dev.zprestige.prestige.renderlib.RenderPass;
import java.util.function.Consumer;

public record RenderPassCommand(RenderPass bj, Consumer<dev.zprestige.prestige.renderlib.RenderPass> bk) {

    public final dev.zprestige.prestige.renderlib.RenderPass recoveryAccess_read_bj() { return this.bj; }

    public final java.util.function.Consumer<dev.zprestige.prestige.renderlib.RenderPass> recoveryAccess_read_bk() { return this.bk; }
}
