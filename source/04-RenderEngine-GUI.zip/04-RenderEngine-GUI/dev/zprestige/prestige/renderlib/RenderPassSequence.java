package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class RenderPassSequence {
   private static final ManagedGlBuffer a;
   private static final ManagedGlBuffer b;
   private static final GlVertexArray c;
   private final List d = new ArrayList();
   private static final long e = 136011518080179L;
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h = new HashMap(13);
   private static final Object[] i = new Object[51];
   private static final String[] j = new String[51];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;

   public RenderPassSequence aReturningc4(Object[] var1) {
      GlProgram var3 = (GlProgram)var1[0];
      Consumer var6 = (Consumer)var1[1];
      int var2 = (Integer)var1[2];
      long var4 = (Long)var1[3];
      var4 = 136011518080179L ^ var4;
      long var7 = var4 ^ 85042985144096L;
      Object[] var10 = new Object[]{var3, var6, invokeBinding1(var2), var7};
      RenderPassSequence var9 = this;
      return var9.bReturningVoid(var10);
   }

   public RenderPassSequence b(Object[] var1) {
      GlProgram var2 = (GlProgram)var1[0];
      Consumer var3 = (Consumer)var1[1];
      IntSupplier var6 = (IntSupplier)var1[2];
      long var4 = (Long)var1[3];
      var4 = 136011518080179L ^ var4;
      long var7 = var4 ^ 60908515293553L;
      long var9 = var4 ^ 22341542508821L;
      List var10000 = this.d;
      Object[] var11 = new Object[]{var7};
      RenderPassBuilder var10003 = RenderPass.aReturningdu_C0204(var11);
      Object[] var13 = new Object[]{var6};
      RenderPassBuilder var12 = var10003;
      var10003 = var12.bReturningVoid(var13);
      Object[] var15 = new Object[]{var2};
      RenderPassBuilder var14 = var10003;
      var10003 = var14.eReturningVoid(var15);
      Object[] var17 = new Object[]{var9};
      RenderPassBuilder var16 = var10003;
      RenderPassCommand var19 = new RenderPassCommand(var16.aReturningRenderPass(var17), var3);
      List var18 = var10000;
      var18.add(var19);
      return this;
   }

   public void aReturningVoid(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 136011518080179L ^ var2;
      long var4 = var2 ^ 35067641294383L;
      long var6 = var2 ^ 89374790602017L;
      int var10000 = Event.bReturningInt();
      List var12 = this.d;
      Iterator var9 = var12.iterator();
      int var8 = var10000;

      int var22;
      do {
         Iterator var13 = var9;
         boolean var21 = var13.hasNext();
         if (!var21) {
            break;
         }

         Iterator var14 = var9;
         RenderPassCommand var10 = (RenderPassCommand)var14.next();
         RenderPass var11 = var10.recoveryAccess_read_bj();
         Object[] var16 = new Object[]{var4};
         RenderPass var15 = var11;
         var15.aReturningVoid(var16);
         RenderPass var18 = var11;
         Consumer var17 = var10.recoveryAccess_read_bk();
         var17.accept(var18);
         GlVertexArray var10001 = c;
         ManagedGlBuffer var10002 = b;
         short var10004 = 7704;
         long var10005 = 2560006971178944311L ^ var2;
         Object[] var10007 = new Object[]{null, null, null, null, var6};
         var10007[3] = 6;
         var10007[2] = 4;
         var10007[1] = var10002;
         var10007[0] = var10001;
         Object[] var20 = var10007;
         RenderPass var19 = var11;
         var19.dReturningVoid(var20);
         var22 = var8;
      } while (var22 == 0);
   }

   private static int lambda$addPass$0(int var0) {
      return var0;
   }

   static {

      long var10001 = 138112242009592L ^ 80003106079951L;
      var10001 = 138112242009592L ^ 130388607198630L;
      var10001 = 138112242009592L ^ 28882262569407L;
      var10001 = 138112242009592L ^ 114360867434225L;
      var10001 = 138112242009592L ^ 100173105967748L;
      var10001 = 138112242009592L ^ 137884979770897L;
      var10001 = 138112242009592L ^ 132093518178509L;
      aReturningVoid();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(138112242009592L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var17 = new long[3];
      String var15 = "ÇX\u00897\"&\u000f\u0002»ãª\u0091 ñXÛòÖ\u0085ÍÆetÌ";
      int var16 = "ÇX\u00897\"&\u000f\u0002»ãª\u0091 ñXÛòÖ\u0085ÍÆetÌ".length();
      do {
         int var88 = var13;
         var13 += 8;
         byte[] var18 = var15.substring(var88, var13).getBytes("ISO-8859-1");
         int var89 = var14++;
         long var19 = (var18[0] & 255L) << 56
            | (var18[1] & 255L) << 48
            | (var18[2] & 255L) << 40
            | (var18[3] & 255L) << 32
            | (var18[4] & 255L) << 24
            | (var18[5] & 255L) << 16
            | (var18[6] & 255L) << 8
            | var18[7] & 255L;
         byte[] var21 = var11.doFinal(
            new byte[]{
               (byte)(var19 >>> 56),
               (byte)(var19 >>> 48),
               (byte)(var19 >>> 40),
               (byte)(var19 >>> 32),
               (byte)(var19 >>> 24),
               (byte)(var19 >>> 16),
               (byte)(var19 >>> 8),
               (byte)var19
            }
         );
         long var10004 = (var21[0] & 255L) << 56
            | (var21[1] & 255L) << 48
            | (var21[2] & 255L) << 40
            | (var21[3] & 255L) << 32
            | (var21[4] & 255L) << 24
            | (var21[5] & 255L) << 16
            | (var21[6] & 255L) << 8
            | var21[7] & 255L;
         
      } while (var13 < var16);

      f = var17;
      g = new Integer[3];
      Cipher var1;
      var10000 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      var10002 = SecretKeyFactory.getInstance("DES");
      var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(138112242009592L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[2];
      String var5 = "\u008f¼+Í\u0013Å«Î\u008bÙ\u000fÑ$îp2";
      int var6 = "\u008f¼+Í\u0013Å«Î\u008bÙ\u000fÑ$îp2".length();
      do {
         int var90 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var90, var3).getBytes("ISO-8859-1");
         int var91 = var4++;
         long var8 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         byte[] var10 = var1.doFinal(
            new byte[]{
               (byte)(var8 >>> 56),
               (byte)(var8 >>> 48),
               (byte)(var8 >>> 40),
               (byte)(var8 >>> 32),
               (byte)(var8 >>> 24),
               (byte)(var8 >>> 16),
               (byte)(var8 >>> 8),
               (byte)var8
            }
         );
         long var98 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         
      } while (var3 < var6);

      Object[] var41 = new Object[]{invokeBinding2(), 114179258184775L};
      a = (ManagedGlBuffer)RenderThreadUtil.aReturningObject(var41);
      Object[] var42 = new Object[]{invokeBinding3(), 114179258184775L};
      b = (ManagedGlBuffer)RenderThreadUtil.aReturningObject(var42);
      Object[] var43 = new Object[]{a, VertexFormats.f, 23770328656649L};
      c = GlVertexArray.aReturningf7(var43);
      ManagedGlBuffer var73 = a;
      long var93 = var0[0] * VertexFormats.f.b;
      Object[] var10005 = new Object[]{null, null, 42363904489340L};
      var10005[1] = var93;
      var10005[0] = 35044;
      Object[] var45 = var10005;
      ManagedGlBuffer var44 = var73;
      var44.aReturningVoid(var45);
      ManagedGlBuffer var74 = b;
      long var94 = var0[1];
      var10005 = new Object[]{null, null, 42363904489340L};
      var10005[1] = var94;
      var10005[0] = 35044;
      Object[] var47 = var10005;
      ManagedGlBuffer var46 = var74;
      var46.aReturningVoid(var47);
      GlBufferMeshBuilder var38 = new GlBufferMeshBuilder(VertexFormats.f, a, b, 12140622815326L);

      try {
         Object[] var10006 = new Object[]{null, null, null, 6320717933877L};
         var10006[2] = 1.0F;
         var10006[1] = 1.0F;
         var10006[0] = -1.0F;
         Object[] var49 = var10006;
         GlBufferMeshBuilder var48 = var38;
         GlBufferMeshBuilder var75 = var48.cReturningGlBufferMeshBuilder(var49);
         Object[] var51 = new Object[]{new float[]{0.0F, 1.0F}, 58686158913847L};
         GlBufferMeshBuilder var50 = var75;
         GlBufferMeshBuilder var76 = var50.bReturningGlBufferMeshBuilder(var51);
         var10006 = new Object[]{null, null, null, 6320717933877L};
         var10006[2] = 1.0F;
         var10006[1] = -1.0F;
         var10006[0] = -1.0F;
         Object[] var53 = var10006;
         GlBufferMeshBuilder var52 = var76;
         GlBufferMeshBuilder var77 = var52.cReturningGlBufferMeshBuilder(var53);
         Object[] var55 = new Object[]{new float[]{0.0F, 0.0F}, 58686158913847L};
         GlBufferMeshBuilder var54 = var77;
         GlBufferMeshBuilder var78 = var54.bReturningGlBufferMeshBuilder(var55);
         var10006 = new Object[]{null, null, null, 6320717933877L};
         var10006[2] = 1.0F;
         var10006[1] = -1.0F;
         var10006[0] = 1.0F;
         Object[] var57 = var10006;
         GlBufferMeshBuilder var56 = var78;
         GlBufferMeshBuilder var79 = var56.cReturningGlBufferMeshBuilder(var57);
         Object[] var59 = new Object[]{new float[]{1.0F, 0.0F}, 58686158913847L};
         GlBufferMeshBuilder var58 = var79;
         GlBufferMeshBuilder var80 = var58.bReturningGlBufferMeshBuilder(var59);
         var10006 = new Object[]{null, null, null, 6320717933877L};
         var10006[2] = 1.0F;
         var10006[1] = 1.0F;
         var10006[0] = 1.0F;
         Object[] var61 = var10006;
         GlBufferMeshBuilder var60 = var80;
         GlBufferMeshBuilder var81 = var60.cReturningGlBufferMeshBuilder(var61);
         Object[] var63 = new Object[]{new float[]{1.0F, 1.0F}, 58686158913847L};
         GlBufferMeshBuilder var62 = var81;
         var62.bReturningGlBufferMeshBuilder(var63);
         Object[] var65 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
         GlBufferMeshBuilder var64 = var38;
         var64.iReturningVoid(var65);
      } catch (Throwable var71) {
            GlBufferMeshBuilder var67 = var38;
            var67.close();
         } catch (Throwable var70) {
            var71.addSuppressed(var70);
         }

         throw var71;
      }

      GlBufferMeshBuilder var66 = var38;
      var66.close();
   
      
}

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12202;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/c4", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c4",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 23;
            yield var16;
         }
         case 2 -> {
            byte var17 = 7;
            yield var17;
         }
         case 3 -> {
            byte var18 = 52;
            yield var18;
         }
         case 4 -> {
            byte var19 = 49;
            yield var19;
         }
         case 5 -> {
            byte var20 = 24;
            yield var20;
         }
         case 6 -> {
            byte var21 = 30;
            yield var21;
         }
         case 7 -> {
            byte var22 = 25;
            yield var22;
         }
         case 8 -> {
            byte var23 = 45;
            yield var23;
         }
         case 9 -> {
            byte var24 = 28;
            yield var24;
         }
         case 10 -> {
            byte var25 = 9;
            yield var25;
         }
         case 11 -> {
            byte var26 = 31;
            yield var26;
         }
         case 12 -> {
            byte var27 = 42;
            yield var27;
         }
         case 13 -> {
            byte var28 = 53;
            yield var28;
         }
         case 14 -> {
            byte var29 = 1;
            yield var29;
         }
         case 15 -> {
            byte var30 = 56;
            yield var30;
         }
         case 16 -> {
            byte var31 = 27;
            yield var31;
         }
         case 17 -> {
            byte var32 = 57;
            yield var32;
         }
         case 18 -> {
            byte var33 = 44;
            yield var33;
         }
         case 19 -> {
            byte var34 = 29;
            yield var34;
         }
         case 20 -> {
            byte var35 = 10;
            yield var35;
         }
         case 21 -> {
            byte var36 = 60;
            yield var36;
         }
         case 22 -> {
            byte var37 = 33;
            yield var37;
         }
         case 23 -> {
            byte var38 = 35;
            yield var38;
         }
         case 24 -> {
            byte var39 = 15;
            yield var39;
         }
         case 25 -> {
            byte var40 = 39;
            yield var40;
         }
         case 26 -> {
            byte var41 = 58;
            yield var41;
         }
         case 27 -> {
            byte var42 = 40;
            yield var42;
         }
         case 28 -> {
            byte var43 = 2;
            yield var43;
         }
         case 29 -> {
            byte var44 = 19;
            yield var44;
         }
         case 30 -> {
            byte var45 = 46;
            yield var45;
         }
         case 31 -> {
            byte var46 = 59;
            yield var46;
         }
         case 32 -> {
            byte var47 = 6;
            yield var47;
         }
         case 33 -> {
            byte var48 = 14;
            yield var48;
         }
         case 34 -> {
            byte var49 = 17;
            yield var49;
         }
         case 35 -> {
            byte var50 = 38;
            yield var50;
         }
         case 36 -> {
            byte var51 = 47;
            yield var51;
         }
         case 37 -> {
            byte var52 = 8;
            yield var52;
         }
         case 38 -> {
            byte var53 = 55;
            yield var53;
         }
         case 39 -> {
            byte var54 = 11;
            yield var54;
         }
         case 40 -> {
            byte var55 = 61;
            yield var55;
         }
         case 41 -> {
            byte var56 = 41;
            yield var56;
         }
         case 42 -> {
            byte var57 = 21;
            yield var57;
         }
         case 43 -> {
            byte var58 = 13;
            yield var58;
         }
         case 44 -> {
            byte var59 = 51;
            yield var59;
         }
         case 45 -> {
            byte var60 = 48;
            yield var60;
         }
         case 46 -> {
            byte var61 = 16;
            yield var61;
         }
         case 47 -> {
            byte var62 = 36;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 3;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 4;
            yield var66;
         }
         case 52 -> {
            byte var67 = 37;
            yield var67;
         }
         case 53 -> {
            byte var68 = 50;
            yield var68;
         }
         case 54 -> {
            byte var69 = 62;
            yield var69;
         }
         case 55 -> {
            byte var70 = 34;
            yield var70;
         }
         case 56 -> {
            byte var71 = 22;
            yield var71;
         }
         case 57 -> {
            byte var72 = 5;
            yield var72;
         }
         case 58 -> {
            byte var73 = 43;
            yield var73;
         }
         case 59 -> {
            byte var74 = 26;
            yield var74;
         }
         case 60 -> {
            byte var75 = 20;
            yield var75;
         }
         case 61 -> {
            byte var76 = 63;
            yield var76;
         }
         case 62 -> {
            byte var77 = 32;
            yield var77;
         }
         default -> 0;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "N\u0006HE\u0001\u000fX\u0006M\u001f\u0012\u0018OMN\u0019\u001e\f^\nY\u000eU\u001c\u001e";
      i[1] = "0\fD7AjE,O8P%$\"D3T\u007fP";
      i[2] = "W|/I\u0001mA|*\u0013\u0012zV7)\u0015\u001enGp>\u0002U|v";
      i[3] = int.class;
      j[3] = "java/lang/Integer";
      i[4] = "Um4v8^Ke.9ZBLx";
      i[5] = "\u00061\r*gh\u00189\u0017e\u0000i\t\"\u001a?&o";
      i[6] = "\u0003\u0010*4s\u007f\u0015\u0010/n`h\u0002[,hl|\u0013\u001c;\u007f'k\u0013";
      i[7] = "\u000frpAT\u0016zR{NEY\u001b\\pEA\u0003o";
      i[8] = void.class;
      j[8] = "java/lang/Void";
      i[9] = "\t%\u0015/\u001f\u0012\u0002*\u0004`~\u001c\t!\u0000:";
      i[10] = boolean.class;
      j[10] = "java/lang/Boolean";
      i[11] = "(BDU0}]bOZ!2<lDQ%hH";
      i[12] = "\u0015gV'\u0001*\u000boLhI*\u0011eT/@1QEO(\\*\u0012cR";
      i[13] = "=\\lz\u0007H+\\i \u0014_<\u0017j&\u0018K-P}1S\\,";
      i[14] = "\"\u0010am\r\u001dW0jb\u001cR6>ai\u0018\bB";
      i[15] = "exl\u001eu7\u0010Xg\u0011dxqVl\u001a`\"\u0005";
      i[16] = "\u001f\u001bUD\u0016oj;^K\u0007 \u000b5U@\u0003z\u007f";
      i[17] = "\t0l;3b|\u0010g4\"-\u001d\u001el?&wi";
      i[18] = "%$rojf3$w5yq$ot3ue5(c$>r+";
      i[19] = "\u0002}7`\u0010&w]<o\u0001i\u0016S7d\u00053b";
      i[20] = "\u0002SF\u0013Fq\u0014SCIUf\u0003\u0018@OYr\u0012_WX\u0012gQ";
      i[21] = "k=\u001b,4o\u001e\u001d\u0010#% \u007f\u0013\u001b(!z\u000b";
      i[22] = "?q;\f\u0016?)q>V\u0005(>:=P\t</}*GB-\u000b";
      i[23] = "\u0003\u001be\u000eH\u0004v;n\u0001YK\u00175e\n]\u0011c";
      i[24] = "D\u0002\f<{}R\u0002\tfhjEI\n`d~T\u000e\u001dw/nc";
      i[25] = "_K3r\t\u001b*k8}\u0018TKe3v\u001c\u000e?";
      i[26] = "\u007f\u0002c_'ui\u0002f\u00054b~Ie\u00038vo\u000er\u0014sgJ";
      i[27] = "\u0016He+ vchn$19\u0002fe/5cv";
      i[28] = "m\u007f/,q\u0005fp>c\u000b\u0001uq.,=\u0005b";
      i[29] = "\\o'6PA)O,9A\u000eHA'2ET<";
      i[30] = "]\u0005\u0001%?xQ\u000b\u0004g\u0007+l\u0006Pc>(\t\u0006_4|F]\u0005\u0001%?xQ\u000b\u0004g\u0007";
      i[31] = "r_\r?\u0015'~Q\b}-sC\\\\y\u0014w&\\S.V\u0019r_\r?\u0015'~Q\b}-";
      i[32] = "X0i\u000b\u001cgZkoA~437mFG3V7b\u0011\u0005]\r/<\u0003\u00050\t/b\u0005~";
      i[33] = ":&H~\"F<;\u0014{AO\u0003{\u0015 <Xq>Gb %";
      i[34] = "}\u0007(2U8(S.(2<\u0010]ze\u000b;u]u2IU}\u0007(2U8(S.(2";
      i[35] = "QQs\u0014BSNNh\n.A?J4U\u0017FZJ;\u0002U(\u0002VyUARVD:R.";
      i[36] = "6%9V\u001e\u00019t5\u0011c]Vvx\u0017ZR3vw@\u0018<6%9V\u001e\u00019t5\u0011c";
      i[37] = "Dl:K4tA2s\u0004\tl%`}\u00060h@`rQr\u0006Dl:K4tA2s\u0004\t";
      i[38] = "\u0011\u0006MB\u000b,\u001c\\\u0016Nb&-\u0002\u0015\u0003[!H\u0002\u001aT\u0019O\u001c\u0001DEZq\u0010\u000fA\u0007b";
      i[39] = "p\u001cg'n\u007f P(dSy7Omw/\u007f1\",y>utNsz7jK";
      i[40] = "\tB\u000e/[\u0011\f\u001cG`f\b\fJ\r3f^\u0017_J1\u001c\n\u0005\u001cM^";
      i[41] = "_\u0000JP\u0019\u001bS\u000eO\u0012!Ln\u0003\u001b\u0016\u0018K\u000b\u0003\u0014AZ%R\u0007CWHF_]\u0018[!";
      i[42] = "\r-t\\\u0013p]a;\u001f.~Z\u007f\u0004[UyOhi_U'I\u0013;\u0007RhU)t\u000fAg6";
      i[43] = "\u0007j\"c3M\u0003&s5KB\tt\u0017r3S\u001fu7t&Gez>a'S\u0003~r0q+Xg>3$Q\fu}4K";
      i[44] = "]\u0003h|\u0006}PY3powa\u00070=Vp\u0004\u0007?j\u0014\u001e\\\u001b}=\u0000d\b\t>:o";
      i[45] = "\u000e\u000fD#_?Q\fM<`5X\u0018UN^([\u0011R#Z(\u0005\u0017)";
      i[46] = "CB9W+\u0011F\u001cp\u0018\u0016\b\"N~\u001a/\rGNqMmcCB9W+\u0011F\u001cp\u0018\u0016";
      i[47] = "S\fqn(yAP*\u0004(\u001eY\u0003'=,{Y\fp\u007fBw\nVqn%eV\r\u001b";
      i[48] = "+\u0002j~,\u0017t\u0001ca\u0013\u001by\u001eA~c\u0007\u0010Zeol\u0018*\u0015m|c{";
      i[49] = "\"!\u0019D7G/{BH^H\u001e%A\u0005gJ{%NR%$#9\f\u00051^w+O\u0002^";
      i[50] = ":x0J4\u0002s>/\u0019Y\u000bah [%b4x#Z\"\u000f0x}\\Y_uqqL#\u000bg2v#";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(689584592918912L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(689584592918912L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(689584592918912L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 81;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 67;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 235;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 202;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 121;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 119;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 81;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 67;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 235;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/c4",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/c4" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static IntSupplier invokeBinding1(int var0) {
         MethodHandle var5 = bindingCache1;
         MethodHandle var4 = bindingCache1;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("(I)Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/c4", "lambda$addPass$0", "(I)I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static Supplier invokeBinding2() {
         MethodHandle var4 = bindingCache2;
         MethodHandle var3 = bindingCache2;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Supplier invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/bP_C0087", "a", "()Ldev/zprestige/prestige/bP_C0087;"),
                  SourceSupport.methodType("()Ldev/zprestige/prestige/bP_C0087;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
