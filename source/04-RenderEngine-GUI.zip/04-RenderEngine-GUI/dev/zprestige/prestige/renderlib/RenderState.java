package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.renderlib.state.AlphaBlendState;
import dev.zprestige.prestige.renderlib.state.BlendFunctionState;
import dev.zprestige.prestige.renderlib.state.CapabilityState;
import dev.zprestige.prestige.renderlib.state.CustomRenderState;
import dev.zprestige.prestige.renderlib.state.DepthFunctionState;
import dev.zprestige.prestige.renderlib.state.DepthMaskState;
import dev.zprestige.prestige.renderlib.state.FramebufferState;
import dev.zprestige.prestige.renderlib.state.ProgramState;
import dev.zprestige.prestige.renderlib.state.RenderPassBuilderCallbackState;
import dev.zprestige.prestige.renderlib.state.RenderPassCallbackState;
import dev.zprestige.prestige.renderlib.state.ScissorState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.util.function.Consumer;
import java.util.function.IntSupplier;

public interface RenderState {
   FramebufferState a = new FramebufferState(invokeBinding1());

   default void a(RenderPassBuilder var1) {
   }

   default void a(RenderPass var1) {
   }

   default void aReturningVoid() {
   }

   default boolean aReturningBoolean() {
      return false;
   }

   static DepthMaskState aReturninggE_C0333(Object[] var0) {
      boolean var2 = (Boolean)var0[0];
      boolean var1 = (Boolean)var0[1];
      return new DepthMaskState(var2, var1);
   }

   static DepthMaskState bReturninggE_C0333(Object[] var0) {
      boolean var1 = (Boolean)var0[0];
      return new DepthMaskState(var1, var1);
   }

   static CapabilityState aReturninggF_C0335(Object[] var0) {
      int var1 = (Integer)var0[0];
      boolean var2 = (Boolean)var0[1];
      return new CapabilityState(var1, var2);
   }

   static CapabilityState bReturninggF_C0335(Object[] var0) {
      int var2 = (Integer)var0[0];
      boolean var1 = (Boolean)var0[1];
      boolean var3 = (Boolean)var0[2];
      return new CapabilityState(var2, var1, var3);
   }

   static ProgramState aReturninggH_C0339(Object[] var0) {
      GlProgram var1 = (GlProgram)var0[0];
      return new ProgramState(var1);
   }

   static FramebufferState aReturninggJ_C0343(Object[] var0) {
      int var1 = (Integer)var0[0];
      return new FramebufferState(var1);
   }

   static DepthFunctionState aReturninggD_C0331(Object[] var0) {
      int var2 = (Integer)var0[0];
      int var1 = (Integer)var0[1];
      return new DepthFunctionState(var2, var1);
   }

   static AlphaBlendState aReturninggI_C0341(Object[] var0) {
      boolean var2 = (Boolean)var0[0];
      boolean var1 = (Boolean)var0[1];
      return new AlphaBlendState(var2, var1);
   }

   static BlendFunctionState aReturninggC_C0329(Object[] var0) {
      boolean var6 = (Boolean)var0[0];
      boolean var2 = (Boolean)var0[1];
      int var3 = (Integer)var0[2];
      int var1 = (Integer)var0[3];
      int var4 = (Integer)var0[4];
      int var5 = (Integer)var0[5];
      return new BlendFunctionState(var6, var2, var3, var1, var4, var5);
   }

   static ScissorState aReturninggG_C0337(Object[] var0) {
      boolean var2 = (Boolean)var0[0];
      boolean var4 = (Boolean)var0[1];
      int var3 = (Integer)var0[2];
      int var1 = (Integer)var0[3];
      int var5 = (Integer)var0[4];
      int var6 = (Integer)var0[5];
      return new ScissorState(var2, var4, var3, var1, var5, var6);
   }

   static CustomRenderState aReturninggK_C0345(Object[] var0) {
      Consumer var1 = (Consumer)var0[0];
      return new CustomRenderState(var1);
   }

   static RenderState aReturningfP_C0301(Object[] var0) {
      Consumer var1 = (Consumer)var0[0];
      return new RenderPassCallbackState(var1);
   }

   static RenderState bReturningfP_C0301(Object[] var0) {
      Consumer var1 = (Consumer)var0[0];
      return new RenderPassBuilderCallbackState(var1);
   }

   private static IntSupplier invokeBinding1() {
         MethodHandle var4 = BindingCache.bindingCache1;
         MethodHandle var3 = BindingCache.bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = BindingCache.bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   final class BindingCache {
      static volatile MethodHandle bindingCache1;
   }
}
