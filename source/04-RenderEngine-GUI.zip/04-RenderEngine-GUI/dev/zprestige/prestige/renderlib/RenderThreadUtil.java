package dev.zprestige.prestige.renderlib;


import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.MinecraftAccess;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.ref.Cleaner;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.BufferManager;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.GlBackend;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.Camera;
import net.minecraft.client.texture.GlTexture;
import net.minecraft.client.util.Window;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;

public class RenderThreadUtil {
   public static final Cleaner a;
   public static final MeshBufferManager b;
   private static final List c;
   public static RenderContext d;
   private static Thread e;
   private static long f;
   private static final long g = 31296173861479L;
   private static final String[] h;
   private static final String[] i;
   private static final Map j = new HashMap(13);
   private static final long[] k;
   private static final Long[] l;
   private static final Map m;
   private static final Object[] n = new Object[92];
   private static final String[] o = new String[92];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;

   public static int a() {
      MinecraftClient var2 = MinecraftClient.getInstance();
      Framebuffer var3 = var2.getFramebuffer();
      GpuTexture var4 = var3.getColorAttachment();
      GlTexture var10000 = ((net.minecraft.client.texture.GlTexture)(Object)(Objects.requireNonNull(var4)));
      GlBackend var5 = (GlBackend)RenderSystem.getDevice();
      BufferManager var10001 = var5.getBufferManager();
      MinecraftClient var6 = MinecraftClient.getInstance();
      Framebuffer var7 = var6.getFramebuffer();
      GpuTexture var10 = var7.getDepthAttachment();
      BufferManager var9 = var10001;
      GlTexture var8 = var10000;
      return var8.getOrCreateFramebuffer(var9, var10);
   }

   public static int bReturningInt(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 31296173861479L ^ var1;
      MinecraftClient var3 = MinecraftClient.getInstance();
      Framebuffer var4 = var3.getFramebuffer();
      GpuTexture var5 = var4.getColorAttachment();
      GlTexture var6 = ((net.minecraft.client.texture.GlTexture)(Object)(Objects.requireNonNull(var5)));
      return var6.getGlId();
   }

   public static float aReturningFloat(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 31296173861479L ^ var1;
      MinecraftClient var3 = MinecraftClient.getInstance();
      Window var4 = var3.getWindow();
      return var4.getScaleFactor();
   }

   public static int cReturningInt(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 31296173861479L ^ var1;
      MinecraftClient var3 = MinecraftClient.getInstance();
      Window var4 = var3.getWindow();
      return var4.getFramebufferHeight();
   }

   public static int dReturningInt(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 31296173861479L ^ var1;
      return invokeBinding3(invokeBinding2(invokeBinding1(-3604707898311830945L, var1), -3610207431100045104L, var1), -3602884985538602422L, var1);
   }

   public static Vector3d aReturningVector3d(Object[] var0) {
      RenderContext var9 = (RenderContext)var0[0];
      double var1 = (Double)var0[1];
      double var3 = (Double)var0[2];
      double var5 = (Double)var0[3];
      long var7 = (Long)var0[4];
      var7 = 31296173861479L ^ var7;
      long var10 = var7 ^ 30895653308648L;
      Object[] var10007 = new Object[]{null, null, null, null, new Vector3d(), var10};
      var10007[3] = var5;
      var10007[2] = var3;
      var10007[1] = var1;
      var10007[0] = var9;
      Object[] var12 = var10007;
      return bReturningVector3d(var12);
   }

   public static Vector3d bReturningVector3d(Object[] var0) {
      RenderContext var10 = (RenderContext)var0[0];
      double var1 = (Double)var0[1];
      double var3 = (Double)var0[2];
      double var5 = (Double)var0[3];
      Vector3d var9 = (Vector3d)var0[4];
      long var7 = (Long)var0[5];
      long var10000 = 31296173861479L ^ var7;
      Camera var12 = var10.recoveryAccess_read_bo();
      Vec3d var11 = var12.getCameraPos();
      Vec3d var13 = var11;
      double var10001 = var1 - var13.x;
      Vec3d var14 = var11;
      double var10002 = var3 - var14.y;
      Vec3d var15 = var11;
      double var21 = var5 - var15.z;
      double var19 = var10002;
      double var17 = var10001;
      Vector3d var16 = var9;
      return var16.set(var17, var19, var21);
   }

   public static void aReturningVoid(Object[] var0) {
      Runnable var1 = (Runnable)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 31296173861479L ^ var2;
      synchronized (c) {
         List var6 = c;
         var6.add(var1);
      }
   }

   public static void bReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 31296173861479L ^ var1;
      long var3 = var1 ^ 82172922462963L;
      long var5 = var1 ^ 14679917960759L;
      invokeBinding5(new Object[]{invokeBinding4(new Object[]{var5}, -6930148262234255147L, var1), var3}, -6929392864284654414L, var1);
   }

   public static List aReturningList(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 31296173861479L ^ var1;
      int var13 = Event.cReturningInt();
      List var4 = c;
      synchronized (c){} 
      int var3 = var13;

      try {
         List var14 = c;
         if (var3 != 0) {
            List var7 = c;
            if (!var7.isEmpty()) {
               ArrayList var5 = new ArrayList(c);
               List var10 = c;
               var10.clear();
               
               return var5;
            }

            var14 = List.of();
            
         }

         return var14;
      } finally {
         
      }
   }

   public static void cReturningVoid(Object[] var0) {
      List var1 = (List)var0[0];
      long var2 = (Long)var0[1];
      long var10000 = 31296173861479L ^ var2;
      int var13 = Event.cReturningInt();
      List var7 = var1;
      Iterator var5 = var7.iterator();
      int var4 = var13;

      int var12;
      do {
         Iterator var8 = var5;
         boolean var11 = var8.hasNext();
         if (!var11) {
            break;
         }

         Iterator var9 = var5;
         Runnable var6 = (Runnable)var9.next();
         Runnable var10 = var6;
         var10.run();
         var12 = var4;
      } while (var12 != 0);
   }

   public static boolean aReturningBoolean(Object[] var0) {

      int var11;

      long var1 = (Long)var0[0];
      var1 = 31296173861479L ^ var1;
      int var10000 = invokeBinding6(5731457369883058277L, var1);
      List var4 = c;
      synchronized (c){} 
      int var3 = var10000;

      try {
         label40: {
            label39: {
               try {
                  var11 = (((invokeBinding7(c, 5734006249359986377L, var1)) ? 1 : 0));
                  if (var3 != 0) {
                     break label40;
                  }

                  if (var11 == 0) {
                     break label39;
                  }
               } catch (RuntimeException var8) {
                  throw invokeBinding8(var8, 5732370372847512891L, var1);
               }

               var11 = 0;
               break label40;
            }

            var11 = 1;
         }

         
         return dev.prestige.recovery.SourceSupport.asBoolean(var11);
      } finally {
         
      }
   
      
}

   public static void dReturningVoid(Object[] var0) {
      RenderContext var1 = (RenderContext)var0[0];
      long var2 = (Long)var0[1];
      var2 = 31296173861479L ^ var2;
      long var4 = var2 ^ 74133563899967L;
      GameRenderUtil.h = var1;
      GameRenderUtil.g = b;
      d = var1;
      net.fabricmc.fabric.api.event.Event var6 = RenderEvents.b;
      RenderCallback var10000 = (RenderCallback)var6.invoker();
      RenderContext var9 = var1;
      MeshBufferManager var8 = b;
      RenderCallback var7 = var10000;
      var7.aReturningVoid(var8, var9);
      MeshBufferManager var13 = b;
      Object[] var11 = new Object[]{var1, var4};
      MeshBufferManager var10 = var13;
      var10.bReturningVoid(var11);
   }

   public static void eReturningVoid(Object[] var0) {
      RenderContext var3 = (RenderContext)var0[0];
      long var1 = (Long)var0[1];
      var1 = 31296173861479L ^ var1;
      long var4 = var1 ^ 8685774722434L;
      long var6 = var1 ^ 112959573885342L;
      int var10000 = Event.cReturningInt();
      Object[] var9 = new Object[]{var6};
      hReturningVoid(var9);
      int var8 = var10000;
      int var32 = var8;
      MinecraftClient var31 = MinecraftAccess.b;
      MinecraftClient var28 = var31;
      MinecraftClient var27 = var31;
      if (var32 != 0) {
         MinecraftClient var10 = var27;
         ClientWorld var33 = var10.world;
         if (var33 == null) {
            return;
         }

         MinecraftClient var34 = MinecraftAccess.b;
         var28 = var34;
      }

      MinecraftClient var13 = var28;
      int var36 = var8;
      ClientPlayerEntity var35 = var13.player;
      Object var30 = var35;
      ClientPlayerEntity var29 = var35;
      if (var36 != 0) {
         ClientPlayerEntity var37 = var29;
         if (var37 == null) {
            return;
         }

         GameRenderUtil.h = var3;
         GameRenderUtil.g = b;
         net.fabricmc.fabric.api.event.Event var15 = RenderEvents.a;
         RenderCallback var39 = (RenderCallback)var15.invoker();
         RenderContext var18 = var3;
         MeshBufferManager var17 = b;
         RenderCallback var16 = var39;
         var16.aReturningVoid(var17, var18);
         MeshBufferManager var40 = b;
         Object[] var20 = new Object[]{var3, var4};
         MeshBufferManager var19 = var40;
         var19.bReturningVoid(var20);
         net.fabricmc.fabric.api.event.Event var21 = RenderEvents.c;
         var30 = var21.invoker();
      }

      RenderCallback var41 = (RenderCallback)var30;
      RenderContext var24 = var3;
      MeshBufferManager var23 = b;
      RenderCallback var22 = var41;
      var22.aReturningVoid(var23, var24);
      MeshBufferManager var42 = b;
      Object[] var26 = new Object[]{var3, var4};
      MeshBufferManager var25 = var42;
      var25.bReturningVoid(var26);
   }

   public static void fReturningVoid(Object[] var0) {
      Runnable var1 = (Runnable)var0[0];
      long var2 = (Long)var0[1];
      var2 = 31296173861479L ^ var2;
      long var4 = var2 ^ 73057059075819L;
      int var6 = Event.cReturningInt();
      Thread var10000 = Thread.currentThread();
      int var15 = var6;
      Thread var14 = var10000;
      Runnable var13 = var14;
      Thread var12 = var14;
      if (var15 != 0) {
         Thread var17 = e;
         Thread var16 = var12;
         if (var16 == var17) {
            Runnable var8 = var1;
            var8.run();
            int var18 = var6;
            if (var18 != 0) {
               return;
            }
         }

         Runnable var19 = var1;
         var13 = var19;
      }

      Object[] var11 = new Object[]{var13, var4};
      aReturningVoid(var11);
   }

   public static Object aReturningObject(Object[] var0) {
      Supplier var3 = (Supplier)var0[0];
      long var1 = (Long)var0[1];
      var1 = 31296173861479L ^ var1;
      long var4 = var1 ^ 800505490940L;
      Thread var26 = e;
      if (var26 != null) {
         Thread var10000 = Thread.currentThread();
         Thread var28 = e;
         Thread var27 = var10000;
         if (var27 != var28) {
            CompletableFuture var6 = new CompletableFuture();
            Object[] var12 = new Object[]{invokeBinding9(var6, var3), var4};
            aReturningVoid(var12);

            try {
               short var10001 = 13387;
               long var38 = 797165356942822431L ^ var1;
               long var36 = 30L;
               TimeUnit var16 = TimeUnit.SECONDS;
               CompletableFuture var13 = var6;
               return var13.get(30L, var16);
            } catch (InterruptedException var32) {
               Thread var17 = Thread.currentThread();
               var17.interrupt();
               short var37 = 17044;
               long var39 = 2645737198119947289L ^ var1;
               throw new RuntimeException("interrupted waiting on render thread", var32);
            } catch (TimeoutException var33) {
               short var10002 = 11478;
               long var10003 = 4819918121824871002L ^ var1;
               throw new RuntimeException("timed out waiting for render thread to execute supplier", var33);
            } catch (ExecutionException var34) {
               Throwable var29 = var34.getCause();
               Throwable var25;
               if (var29 == null) {
                  var25 = var34;
               } else {
                  var25 = var34.getCause();
               }

               Throwable var8 = var25;
               boolean var31 = var8 instanceof RuntimeException;
               if (var31) {
                  throw (RuntimeException)var8;
               }

               throw new RuntimeException(var8);
            }
         }
      }

      Supplier var10 = var3;
      return var10.get();
   }

   public static void gReturningVoid(Object[] var0) {
      Thread var1 = (Thread)var0[0];
      e = var1;
   }

   public static Thread aReturningThread(Object[] var0) {
      return e;
   }

   public static boolean bReturningBoolean(Object[] var0) {

      long var1 = (Long)var0[0];
      var1 = 31296173861479L ^ var1;
      int var3 = invokeBinding10(6961245318033018740L, var1);

      Thread var6;
      label29: {
         try {
            int var10 = var3;
            Thread var9 = e;
            var6 = var9;
            Thread var4 = var9;
            if (var10 != 0) {
               break label29;
            }

            Thread var11 = var4;
            if (var11 == null) {
               return false;
            }
         } catch (RuntimeException var16) {
            throw invokeBinding11(var16, 6961454358593897002L, var1);
         }

         var6 = invokeBinding12(6955116019011490033L, var1);
      }

      try {
         Thread var13 = e;
         Thread var12 = var6;
         if (var12 == var13) {
            return true;
         }
      } catch (RuntimeException var15) {
         throw invokeBinding13(var15, 6961454358593897002L, var1);
      }

      return false;
   
      
}

   public static long aReturningLong(Object[] var0) {
      return f;
   }

   public static void hReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 31296173861479L ^ var1;
      short var10001 = 2802;
      long var10002 = 4202876725087657664L ^ var1;
      f++;
   }

   private static void lambda$callOnRenderThread$0(CompletableFuture var0, Supplier var1) {
         Supplier var5 = var1;
         Object var7 = var5.get();
         CompletableFuture var6 = var0;
         var6.complete(var7);
      } catch (Throwable var11) {
         CompletableFuture var8 = var0;
         var8.completeExceptionally(var11);
      }
   }

   static {

      {

      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(98912673428799L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[2];
      String var15 = ",G\u000bý\u001a*\u000bróö4³\u0090*&\u0016D¶\u000b°)kf`Õbl§V,UFÖ\u0096PK£\u000f\u001cyý\u008d.»\u0018Ûyv\u0096!ø$\u0012?\u001bu¢î\n\u001aa÷åò+\u0099ú\u000e\u008eòX+]\u008c'õ\u0092\u0087Òþ\u0011x8/\u0002²ug\u000fõ%°\u009a\u0018\b¼@ígÍ\u0085º®\u008aë\u000fq\u0088'°l·ÔòÓÁ/Ú(\tVtûJ÷!Ûuô\u0003¤\t\u001e\u0082ë\u001b°$sÌ6\u0094\u008e³0Ôté\u0006\u0086\u008cª/ãz\u0003ÄÊ\u008bb\u008f";
      int var17 = ",G\u000bý\u001a*\u000bróö4³\u0090*&\u0016D¶\u000b°)kf`Õbl§V,UFÖ\u0096PK£\u000f\u001cyý\u008d.»\u0018Ûyv\u0096!ø$\u0012?\u001bu¢î\n\u001aa÷åò+\u0099ú\u000e\u008eòX+]\u008c'õ\u0092\u0087Òþ\u0011x8/\u0002²ug\u000fõ%°\u009a\u0018\b¼@ígÍ\u0085º®\u008aë\u000fq\u0088'°l·ÔòÓÁ/Ú(\tVtûJ÷!Ûuô\u0003¤\t\u001e\u0082ë\u001b°$sÌ6\u0094\u008e³0Ôté\u0006\u0086\u008cª/ãz\u0003ÄÊ\u008bb\u008f"
         .length();
      char var14 = '`';
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var27 = a(var19).intern();
         int var10001 = -1;
         var18[var16++] = var27;
         if ((var13 += var14) >= var17) {
            h = var18;
            i = new String[2];
            m = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(98912673428799L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[3];
            String var4 = "ú\u0088ßëNé\u0080\n¹\u0004¢ÞÛÔS\u0096¯\u0003<Ì'\u0095\u0092\u0085";
            int var5 = "ú\u0088ßëNé\u0080\n¹\u0004¢ÞÛÔS\u0096¯\u0003<Ì'\u0095\u0092\u0085".length();
            do {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               var10001 = var3++;
               long var8 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               byte[] var10 = var0.doFinal(
                  new byte[]{
                     (byte)(var8 >>> 56),
                     (byte)(var8 >>> 48),
                     (byte)(var8 >>> 40),
                     (byte)(var8 >>> 32),
                     (byte)(var8 >>> 24),
                     (byte)(var8 >>> 16),
                     (byte)(var8 >>> 8),
                     (byte)var8
                  }
               );
               long var10004 = (var10[0] & 255L) << 56
                  | (var10[1] & 255L) << 48
                  | (var10[2] & 255L) << 40
                  | (var10[3] & 255L) << 32
                  | (var10[4] & 255L) << 24
                  | (var10[5] & 255L) << 16
                  | (var10[6] & 255L) << 8
                  | var10[7] & 255L;
               
            } while (var2 < var5);

            k = var6;
            l = new Long[3];
            a = Cleaner.create();
            short var22 = 14841;
            b = new MeshBufferManager();
            long var26 = 4230167925289426830L;
            c = new ArrayList();
            d = null;
            f = -9223372036854775807L;
            break;
         }

         var14 = var15.charAt(var13);
      }
   
      }

      
}

   private static Exception a(Exception var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20652;
      if (i[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])j.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dj", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = h[var5].getBytes("ISO-8859-1");
         i[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return i[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dj_C0184",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dj" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 9846;
      if (l[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = k[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])m.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               m.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dj", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         l[var3] = var15;
      }

      return l[var3];
   }

   private static long b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = b(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dj_C0184",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dj" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = o[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = n[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 10;
            yield var15;
         }
         case 1 -> {
            byte var16 = 14;
            yield var16;
         }
         case 2 -> {
            byte var17 = 41;
            yield var17;
         }
         case 3 -> {
            byte var18 = 1;
            yield var18;
         }
         case 4 -> {
            byte var19 = 26;
            yield var19;
         }
         case 5 -> {
            byte var20 = 58;
            yield var20;
         }
         case 6 -> {
            byte var21 = 2;
            yield var21;
         }
         case 7 -> {
            byte var22 = 61;
            yield var22;
         }
         case 8 -> {
            byte var23 = 16;
            yield var23;
         }
         case 9 -> {
            byte var24 = 32;
            yield var24;
         }
         case 10 -> {
            byte var25 = 63;
            yield var25;
         }
         case 11 -> {
            byte var26 = 42;
            yield var26;
         }
         case 12 -> {
            byte var27 = 60;
            yield var27;
         }
         case 13 -> {
            byte var28 = 27;
            yield var28;
         }
         case 14 -> {
            byte var29 = 48;
            yield var29;
         }
         case 15 -> {
            byte var30 = 18;
            yield var30;
         }
         case 16 -> {
            byte var31 = 52;
            yield var31;
         }
         case 17 -> {
            byte var32 = 59;
            yield var32;
         }
         case 18 -> {
            byte var33 = 37;
            yield var33;
         }
         case 19 -> {
            byte var34 = 24;
            yield var34;
         }
         case 20 -> {
            byte var35 = 3;
            yield var35;
         }
         case 21 -> {
            byte var36 = 20;
            yield var36;
         }
         case 22 -> {
            byte var37 = 43;
            yield var37;
         }
         case 23 -> {
            byte var38 = 9;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 6;
            yield var40;
         }
         case 26 -> {
            byte var41 = 4;
            yield var41;
         }
         case 27 -> {
            byte var42 = 34;
            yield var42;
         }
         case 28 -> {
            byte var43 = 22;
            yield var43;
         }
         case 29 -> {
            byte var44 = 62;
            yield var44;
         }
         case 30 -> {
            byte var45 = 44;
            yield var45;
         }
         case 31 -> {
            byte var46 = 15;
            yield var46;
         }
         case 32 -> {
            byte var47 = 49;
            yield var47;
         }
         case 33 -> {
            byte var48 = 23;
            yield var48;
         }
         case 34 -> {
            byte var49 = 38;
            yield var49;
         }
         case 35 -> {
            byte var50 = 5;
            yield var50;
         }
         case 36 -> {
            byte var51 = 0;
            yield var51;
         }
         case 37 -> {
            byte var52 = 47;
            yield var52;
         }
         case 38 -> {
            byte var53 = 28;
            yield var53;
         }
         case 39 -> {
            byte var54 = 50;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 25;
            yield var56;
         }
         case 42 -> {
            byte var57 = 12;
            yield var57;
         }
         case 43 -> {
            byte var58 = 54;
            yield var58;
         }
         case 44 -> {
            byte var59 = 35;
            yield var59;
         }
         case 45 -> {
            byte var60 = 11;
            yield var60;
         }
         case 46 -> {
            byte var61 = 7;
            yield var61;
         }
         case 47 -> {
            byte var62 = 46;
            yield var62;
         }
         case 48 -> {
            byte var63 = 21;
            yield var63;
         }
         case 49 -> {
            byte var64 = 40;
            yield var64;
         }
         case 50 -> {
            byte var65 = 17;
            yield var65;
         }
         case 51 -> {
            byte var66 = 45;
            yield var66;
         }
         case 52 -> {
            byte var67 = 39;
            yield var67;
         }
         case 53 -> {
            byte var68 = 55;
            yield var68;
         }
         case 54 -> {
            byte var69 = 31;
            yield var69;
         }
         case 55 -> {
            byte var70 = 13;
            yield var70;
         }
         case 56 -> {
            byte var71 = 57;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 30;
            yield var73;
         }
         case 59 -> {
            byte var74 = 29;
            yield var74;
         }
         case 60 -> {
            byte var75 = 56;
            yield var75;
         }
         case 61 -> {
            byte var76 = 51;
            yield var76;
         }
         case 62 -> {
            byte var77 = 33;
            yield var77;
         }
         default -> 8;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            o[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      n[0] = "V\u0011\u0010\u007fz\u001dH\u0019\n07\u0007R\u0013\u0013l&\rR\u0004H];\u0005L\u001c\u0003j5\nP\u0015 k \u001dN\u0015";
      n[1] = "brMM7 i}\\\u0002M$z|LM{ m";
      n[2] = boolean.class;
      o[2] = "java/lang/Boolean";
      n[3] = "\u0015\u007fU\u007fNd\u000bwO0\u0006d\u0011}Ww\u000f\u007fQMVn\u0010}\u0016{Q";
      n[4] = ">( G\b\t5'1\bi\u0007>,5R";
      n[5] = "\u0019?`c\u0007>\u000f?e9\u0014)\u0018tf?\u0018=\t3q(S*\u0017";
      n[6] = "\u001e,1\u0004<*\u0015# KW>\u0017(7\u0011{)\u001a";
      n[7] = "J\ttwn,T\u0001n8#6N\u000bwd2<N\u001c,B)4E=l\u007f4";
      n[8] = "bn\u0016{j\u000f\u0017N\u001dt{@v@\u0016\u007f\u007f\u001a\u0002";
      n[9] = void.class;
      o[9] = "java/lang/Void";
      n[10] = "d1\u001fM\f\u000bo>\u000e\u0002v\u000f|5\bH";
      n[11] = "|h-\u001d\u0014Zb`7RY@xj.\u000eHJx}u9BJu|/\u0015UASq8\u0019J[\u007ff5";
      n[12] = long.class;
      o[12] = "java/lang/Long";
      n[13] = "\u00163\u0017\u0014<4c\u0013\u001c\u001b-{\u0002\u001d\u0017\u0010)!v";
      n[14] = "C\u000b\u0015IJnO\u001c\b\u0004Al\u0003\b\u0000\u0005^fN@\u0000\u0017E!H\u0018\u0004\tX!h\u0018\u0004\tX";
      n[15] = ")gs\u001dm\u000b?gvG~\u001c(,uAr\b9kbV9\u001a\b";
      n[16] = int.class;
      o[16] = "java/lang/Integer";
      n[17] = "{n\u001eP;-{n\t\f7\"a%\t\u001277fTYOf";
      n[18] = "\\\u0014qYiJ\\\u0014f\u0005eEF_f\u001bePA.3D<";
      n[19] = ">$\u0012f\u0007D($\u0017<\u0014S?o\u0014:\u0018G.(\u0003-SU4";
      n[20] = "\u0014u\u00185h\u0019aU\u0013:yV\u0000[\u00181}\ft";
      n[21] = "9O\u00053e\\9O\u0012oiS#\u0004\u0012qiF$uF)>";
      n[22] = "T/\u001dV]\u0019B/\u0018\fN\u000eUd\u001b\nB\u001aD#\f\u001d\t\r]";
      n[23] = "j\u0002?\u0011\u0017k|\u0002:K\u0004|kI9M\bhz\u000e.ZC|t";
      n[24] = "_RZY/-T]K\u0016S4[]MZm$";
      n[25] = "2<s3<QG\u001cx<-\u001e&\u0012s7)DR";
      n[26] = "Ys\u0014\u001d\u0018m[m]e\u0017aBn\u0001\u0000\u0016";
      n[27] = "\fI\u0019\u0002H,\fI\u000e^D#\u0016\u0002\u000e@D6\u0011s\\\u001c\u0011t";
      n[28] = "\u0007B\u0015FH\u001erb\u001eIYQ\u0013l\u0015B]\u000bg";
      n[29] = "qLo \t}oDuokahY";
      n[30] = "\u0010|dm\"ue\\ob3:\u0004Rdi7`p";
      n[31] = "X\u0003C>{HX\u0003TbwGBHT|wRE9\u0005$%";
      n[32] = double.class;
      o[32] = "java/lang/Double";
      n[33] = "L\"h;(zL\"\u007fg$uVi\u007fy$`Q\u0018($}'";
      n[34] = "\u001c/-\u001b&s\u0017 <Tzz\u0010`\u0018\u0016m~\u0018+)";
      n[35] = "{E[\no\r{ELVc\u0002a\u000eLHc\u0017f\u007f\u001e\u0014:R-";
      n[36] = "r\u0019/\u000foQr\u00198Sc^hR8McKo#j\u0011:\u000f(";
      n[37] = "\u0018NIX\nh\u0011@J\u0011Ie\u0017@^\u0013TcUUA\u000e\u0013r\tDWX w\u000euA\u000e\u0013r\tD";
      n[38] = "\bUV:\u0017}\u0016]Luvj\bQC/J";
      n[39] = "yrxS\rWyro\u000f\u0001Xc9o\u0011\u0001MdH>JV";
      n[40] = "O7%\u0015tkO72IxdU|2WxqR\r`\u000b!4\u0014";
      n[41] = "\u0011+*:w\u001f\u0018%)s4\u0012\u001e%=q)\u0014\\7>gn\u0015\u001f7iF\u007f\u001e\u0016!5Gc\u0003\u0006!*";
      n[42] = "!-)S '(#*\u001ac*.#>\u0018~,l1=\u000e9-/1j:==\u0006'2\u0014.-";
      n[43] = "\u0017G\u001d\u000f\u0016m\tO\u0007@ql\u0018T\n\u001aWj";
      n[44] = "fyMHZw=`\u0017W=-lg\u0015VQ\u001f?+I\u000b\u0003Hy{\u000f\u000e^$\u007f%\u001aR=19j\u0011O]9~\u007f\r1Wyor\u001eR@r0gu";
      n[45] = "M0)\u0017^]\u001f2l[#R$#%\tJSG4.V_8";
      n[46] = "\u0018>]t]\u0005\u0018-S{ Z\u0014<AcLhE|\u00115 UH.HoCBCq]\u0004";
      n[47] = "1y\u0017\u001a2 $}WZ@/>nND-4X+\u0016C t(`T_xN";
      n[48] = "\u0011\b3vIXH\u0019(.3Q*N,wIGN\u0013t|\n8\u0016\u0015-kL\\KM&(3";
      n[49] = ",\u0018'a\u0003hx\ro!8c{\nU \u0007hvL%kEt.v";
      n[50] = "+`CVZ\u0006/5\u0007\b(\u0005<w\u001eTD7j3D\f\u0018`(3\u000fWV\u0000 t\u001aK(";
      n[51] = "-,h$t#-?f+\t|!.t3eNpo,j\ts}<}?jdvchT";
      n[52] = "W0~cb}^mw \u0005\"H0|xy$N]{.='\fg6rw,4";
      n[53] = "\\um\u0005k\u0017\u001cy<M\u0014<,^\u001azX<a(=\f-\u0018\u0011h1]e";
      n[54] = "\t\u001fk1\u0001:[\u001d.}|4`\fg/\u00154\u0003\u001blp\u0000_";
      n[55] = "C!GG\u001f`\u00105\f\u0006\"{D-\u0016YNI\u0010lK\u0007\"tY`\u000f\u0003\\'M+N>";
      n[56] = "5@z0\u001e$fT1q#?2L+.O\rf\rqs# 4\r.;E$aIpI";
      n[57] = "X\u001a\u0015\u001c2gA[\u000eD\\h]\u0007\u000fN\u000b?\u0007WS\"99_\u000b\f_!y\u0000Q";
      n[58] = "\f\u0004K9S=\u0013\u0010\u000f*5:\u0007\u0014\u0017=Y\bUQNg\u000b_\u000e\u0018\td[>\u0017Y\u0012<5";
      n[59] = "K.clzw\u0012?x4\u0000~p0&{c)O>z{r\u0017N4\u007fvbl\u000feyv\u0000";
      n[60] = "\u0017l8xIw\u0001w$#%'{mwmFsDc+mWMEi.`G6\u00048(`%";
      n[61] = "[q_wo|\u0016-\u0015|W K>\u001b\u0013lyB.]c';^vg";
      n[62] = "Y\u000b\u0014INn\u0002\u0012NV)4S\u0015LWE\u0006\u0000Y\u0010\n\u0016QTXBYB2CS\u001dL)";
      n[63] = "RkP:_\u001b\u0001\u007f\u001b{b\u000bYv\u0005/5\\\u0007!]C\u000f\u0007Iy\u000b~\u0005\u0006Vw";
      n[64] = "')OF-?~8T\u001eW6\u001c7\nQ4a#9VQ%_\u007f>OS0avcF\u0010W";
      n[65] = "h\u0001\u000f\b&\u0000`PC\u000e\u0018\n\u0006\u0006\u001a\u0002}\u000f<\u0010\u0001\u001e&ch\u0018\u000fNaXw\u000eA\n\u0018]f\u000e\u0002\u0012c\u001c7\b\u0002p";
      n[66] = "=\u0007UBl\",XOxzx6BP\u0015mrS\u0001\u000b\u001cq%#JI\u0000)\u001fj\\Y\u0012qm6YFD\u0011";
      n[67] = "`\u0013om\u001c8yJ{~d:}\u001c\u00102\u0004$}\u0018ksU\"}z";
      n[68] = "\r1#}C6\u001cn9GQf\u001f\fr\"\u0006o\u001fl)5Nhc1\"w\u0007t\u0013q.&O\u000bX3&'\u0004{\u0013q:\u007f>";
      n[69] = "|+$\u0000\rvbv!Cf7p4N\u001bY/|/3\u0003\u0019p&H+A\u0005-z53\u0001Zw\u001d-q\u001d\u0007+`51B]L|+$\u0000\rvbv!Cf";
      n[70] = "\u0004?Kf\noW+\u0000'7t\u00033\u001ax[FTuD/\f\u0011\u000f1\u0006oJ+\u000f\"\b`7";
      n[71] = "d{E^^\u0013)'\u000fUfIp?;W\u0016U\u0019}\u001bW\fIk!\u001eHZ)";
      n[72] = "\u0005@RL):\f\u001d[\u000fNe\u001d`OF2uf\u0014LS$d\u0014HILr\u0004";
      n[73] = "}@RrT\u001bxXKm4\u000faWAoYd}@RrT\u001bxXKm4";
      n[74] = "g_$B~Av\u0000>xh\u001bl\u001a!\u0015\u007f\u0011D\u0012.\u0015{\u0000h\u0005#\u0011g\u0018xb;\u0012oGh\u0006\u007f\u001b}|0\u0004(\u0012c\u000el\u00017D\u0003";
      n[75] = "`T\u0005!\u0010Ei\t\fbw\u0010gT\u0014)wEc]\u00001\f\u00042[\u0000S";
      n[76] = "~\u0000\u0018*5\u0010'\u0011\u0003rO\u0010E\u001e]=,Nz\u0010\u0001==p{\u001a\u00040-\u000b:K\u00020O";
      n[77] = "\u0002E%\u001chx\u001b\u0004>D\u0006w\u0007X?NQ ]\ba\"c&\u0005T<_{fZ\u000e";
      n[78] = "\u0000k5rAF\u0019*.*/I\u0005v/ x\u001e_&rLJ\u0018\u0007z,1RXX ";
      n[79] = "yr~Rp\u0007pmi[\u001b\fmijQa\u001bFwqvf\u0012d\u0010,\u000f\u007f\u0016:`gMcN\u0000+(T{Lp`jH#v";
      n[80] = "f\u0012\u001cY\u0014\u0001z\u0019\rV}\u0002pT\u0000X\u00110#\u0018\\\u0007DgeH\u001a\u0000\u001e\u000bc\u0016\u000f\\}";
      n[81] = "\u0013\u0018AOw|J\tZ\u0017\rv(\u0006\u0004Xn\"\u0017\bXX\u007f\u001cI\u0001SVf&W\\V\u0015\r";
      n[82] = "tP8s\u0016Ip\u0005|-dJcGeq\bx5\u0003?)[/w\u0003tr\u001aO\u007fDand";
      n[83] = ")^Y\"ba \u0003Pa\u00056&_!k:;*\tQ x'r3\u00186h5*AD3wcJ";
      n[84] = "@~8Lgi\u0013js\rZyKcmY\r.\u0014>651o[wfIf(\u0010w";
      n[85] = "\u0003o2$dq\n2;g\u0003(\u000e\u0002);{=\u0007< fr~`";
      n[86] = ",YN[p:i\u000bP\u0000A)n\u001eFW'>O\u0004FW(.\u0013[\u0001H sk\u001eSV{B";
      n[87] = "\u001d\u001bgBV{\u001d\biM+$\u0011\u0019{UG\u0016@Y*\u000f++M\u000brYH<FTg2";
      n[88] = "*\u001d?\u0010)toO!K\u0018ms\\ \u000bbqm\\MOxhhB6\u000e)nh ";
      n[89] = "TM\u0002&meS\u0019K8\u0017rE\u000bu'i|C\u001a96w B\n\tzy}\u0017w";
      n[90] = ">!E}*\u0014djYg\u0013\u001el'pqn\nl[Er\u007fJ`?\u0001{mq";
      n[91] = "&\bsie:\u007f\u0019h1\u001f1\u001d\u00166~|d\"\u0018j~mZ#\u0012os}!bCis\u001f";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = n[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(o[var4]);
            n[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            n[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  n[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(326110470042276L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = n[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = o[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  n[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(326110470042276L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        n[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(326110470042276L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 117;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 114;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 74;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 104;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 211;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 68;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 117;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 114;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 74;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dj_C0184",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dj" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static MinecraftClient invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = c(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Lnet/minecraft/client/MinecraftClient;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (MinecraftClient)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Window invokeBinding2(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache2;
         MethodHandle var8 = bindingCache2;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache2 = c(
                  MethodHandles.lookup(), "Ó", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lnet/minecraft/client/util/Window;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Window)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "Ó", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static List invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = c(MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/List;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (List)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = c(MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup())).dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding6(long var0, long var2) {
         MethodHandle var8 = bindingCache6;
         MethodHandle var7 = bindingCache6;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache6 = c(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static boolean invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = c(MethodHandles.lookup(), "Ó", SourceSupport.methodType("(Ljava/lang/Object;JJ)Z", MethodHandles.lookup())).dynamicInvoker();
         }

         return (boolean)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Exception invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = c(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Runnable invokeBinding9(CompletableFuture var0, Supplier var1) {
         MethodHandle var6 = bindingCache9;
         MethodHandle var5 = bindingCache9;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache9 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "run",
                  SourceSupport.methodType(
                     "(Ljava/util/concurrent/CompletableFuture;Ljava/util/function/Supplier;)Ljava/lang/Runnable;", MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dj_C0184",
                     "lambda$callOnRenderThread$0",
                     "(Ljava/util/concurrent/CompletableFuture;Ljava/util/function/Supplier;)V"
                  ),
                  SourceSupport.methodType("()V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Runnable)var3.invokeExact((CompletableFuture)var0, (Supplier)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static int invokeBinding10(long var0, long var2) {
         MethodHandle var8 = bindingCache10;
         MethodHandle var7 = bindingCache10;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache10 = c(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding11(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache11;
         MethodHandle var8 = bindingCache11;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache11 = c(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Thread invokeBinding12(long var0, long var2) {
         MethodHandle var8 = bindingCache12;
         MethodHandle var7 = bindingCache12;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache12 = c(MethodHandles.lookup(), "D", SourceSupport.methodType("(JJ)Ljava/lang/Thread;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Thread)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Exception invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(
                  MethodHandles.lookup(), "D", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Exception;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Exception)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
