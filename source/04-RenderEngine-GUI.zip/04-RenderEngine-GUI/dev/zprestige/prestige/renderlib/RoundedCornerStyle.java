package dev.zprestige.prestige.renderlib;

import org.joml.Vector4f;

public record RoundedCornerStyle(Vector4f br, float bs) {
}
