package dev.zprestige.prestige.renderlib;

public class ScaleValue {
   public float a;

   public ScaleValue() {
   }
}
