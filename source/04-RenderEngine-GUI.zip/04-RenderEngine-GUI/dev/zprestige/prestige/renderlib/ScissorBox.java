package dev.zprestige.prestige.renderlib;

public record ScissorBox(int bR, int bS, int bT, int bU) {
}
