package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL20;

public class ShaderCompiler {
   public static final boolean a;
   private static final long b = 99894803113021L;
   private static final String[] c;
   private static final String[] d;
   private static final Map e = new HashMap(13);
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h;
   private static final Object[] i = new Object[40];
   private static final String[] j = new String[40];

   public static GlProgram aReturningfM_C0295(Object[] var0) {
      String var4 = (String)var0[0];
      String var1 = (String)var0[1];
      boolean var5 = (Boolean)var0[2];
      long var2 = (Long)var0[3];
      var2 = 99894803113021L ^ var2;
      long var6 = var2 ^ 118633543126806L;
      long var8 = var2 ^ 30830151823090L;
      short var10000 = 20238;
      long var10001 = 3401618813342858428L ^ var2;
      Object[] var10005 = new Object[]{null, null, null, var6};
      var10005[2] = var5;
      var10005[1] = var4;
      var10005[0] = 35633;
      Object[] var14 = var10005;
      int var10 = aReturningInt(var14);
      var10000 = 28589;
      var10001 = 3853982124942007324L ^ var2;
      var10005 = new Object[]{null, null, null, var6};
      var10005[2] = var5;
      var10005[1] = var1;
      var10005[0] = 35632;
      Object[] var15 = var10005;
      int var11 = aReturningInt(var15);
      int var12 = GL20.glCreateProgram();
      int var17 = var10;
      int var16 = var12;
      GL20.glAttachShader(var16, var17);
      int var19 = var11;
      int var18 = var12;
      GL20.glAttachShader(var18, var19);
      int var20 = var12;
      GL20.glLinkProgram(var20);
      short var32 = 5082;
      long var10002 = 7095502373162737770L ^ var2;
      int var21 = var12;
      int var28 = GL20.glGetProgrami(var21, 35714);
      if (var28 == 0) {
         int var23 = var12;
         String var13 = GL20.glGetProgramInfoLog(var23);
         String var25 = var13;
         PrintStream var24 = System.err;
         var24.println(var25);
         short var33 = 22242;
         long var10003 = 4573016068966276793L ^ var2;
         throw new RuntimeException("Program link failed. See error above");
      } else {
         int var26 = var10;
         GL20.glDeleteShader(var26);
         int var27 = var11;
         GL20.glDeleteShader(var27);
         return new GlProgram(var12, var8);
      }
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      String var5 = (String)var0[1];
      boolean var4 = (Boolean)var0[2];
      long var1 = (Long)var0[3];
      var1 = 99894803113021L ^ var1;
      boolean var35 = var4;
      if (var35) {
         short var47 = 14953;
         long var10004 = 6578810757943089432L ^ var1;
         throw new UnsupportedOperationException("SPIR-V shader loading was removed for GL 3.3 compatibility. Provide GLSL source instead: " + var5);
      }

      int var12 = var3;
      int var6 = GL20.glCreateShader(var12);

      String var7;
      {
         Class<ShaderCompiler> var13 = ShaderCompiler.class;
         ClassLoader var10000 = var13.getClassLoader();
         String var15 = var5;
         ClassLoader var14 = var10000;
         InputStream var8 = var14.getResourceAsStream(var15);

         try {
            boolean var36 = a;
            if (!var36) {
               InputStream var37 = var8;
               if (var37 == null) {
                  throw new AssertionError();
               }
            }

            InputStream var18 = var8;
            var7 = new String(var18.readAllBytes(), StandardCharsets.UTF_8);
         } catch (Throwable var42) {
            InputStream var39 = var8;
            if (var39 != null) {
                  InputStream var21 = var8;
                  var21.close();
               } catch (Throwable var41) {
                  var42.addSuppressed(var41);
               }
            }

            throw var42;
         }

         InputStream var38 = var8;
         if (var38 != null) {
            InputStream var19 = var8;
            var19.close();
         }
      } catch (IOException var43) {
         throw new RuntimeException(var43);
      }

      String var25 = var7;
      int var24 = var6;
      GL20.glShaderSource(var24, var25);
      int var26 = var6;
      GL20.glCompileShader(var26);
      short var10001 = 8672;
      long var10002 = 1212804736694139256L ^ var1;
      int var27 = var6;
      int var40 = GL20.glGetShaderi(var27, 35713);
      if (var40 == 0) {
         int var29 = var6;
         String var45 = GL20.glGetShaderInfoLog(var29);
         String var31 = var45;
         PrintStream var30 = System.err;
         var30.println(var31);
         short var46 = 19400;
         long var10003 = 1465136088663566523L ^ var1;
         throw new RuntimeException("Shader compile failed. See logs above for error");
      } else {
         return var6;
      }
   }

   static {

      {

      aReturningVoid();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(15984540948092L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[3];
      String var15 = "\u0015û\u001e\t©6\u001c9éÀ.1\u00ad$W¯µ\u0083v\u001a\u0002ÒR\u001c5ù\u0081È¬\u000e\u0003áÐV_²iÄs.XHo4?=£â\u0005>o\u0085n\u0085µjT¸Z¼\u0095T)¬\"t\u0083:b»n\u0081Ú`\u0011SÀ\u0013[\u0088>\u008föÓ3\u00977}RDñÕHÄìRVY<\u0013.\u0016v.³}pøíu»\u0006X\u008d60j`p\u0080IãeB\u008cÎ\u008eêw³½Þ¡L\u0004ÄÚìG©Í\u0084ï\u0013@}ùÈò`\u008a\u008cÊ\u009f+¸2©¬rÖ)r\u0010Ñ\u001fhÒl_ÍTE P_Xêãâ©;Â+¬dD\u008bT\u009d\u00891n]°\u008fø½ú¡©Í=\u008eÖ¤ª².Pî4\u0080®ÓS\u001erýê¹û¯+Ü\u008a@ÓÂ`\u0088a{%æöæk'jÁ\u0010{®t½èÁ¥Ä\u008a®¬\f2\u001b§G\u00ad\u001d\u008c\u0081\u0006\u0012ÿ\u0098«\\\u00ad\u001b?_\u0090@<\u0012Ò\u008eöÉt\u0092\u0016%µ¦æÖÉ\u0094";
      int var17 = "\u0015û\u001e\t©6\u001c9éÀ.1\u00ad$W¯µ\u0083v\u001a\u0002ÒR\u001c5ù\u0081È¬\u000e\u0003áÐV_²iÄs.XHo4?=£â\u0005>o\u0085n\u0085µjT¸Z¼\u0095T)¬\"t\u0083:b»n\u0081Ú`\u0011SÀ\u0013[\u0088>\u008föÓ3\u00977}RDñÕHÄìRVY<\u0013.\u0016v.³}pøíu»\u0006X\u008d60j`p\u0080IãeB\u008cÎ\u008eêw³½Þ¡L\u0004ÄÚìG©Í\u0084ï\u0013@}ùÈò`\u008a\u008cÊ\u009f+¸2©¬rÖ)r\u0010Ñ\u001fhÒl_ÍTE P_Xêãâ©;Â+¬dD\u008bT\u009d\u00891n]°\u008fø½ú¡©Í=\u008eÖ¤ª².Pî4\u0080®ÓS\u001erýê¹û¯+Ü\u008a@ÓÂ`\u0088a{%æöæk'jÁ\u0010{®t½èÁ¥Ä\u008a®¬\f2\u001b§G\u00ad\u001d\u008c\u0081\u0006\u0012ÿ\u0098«\\\u00ad\u001b?_\u0090@<\u0012Ò\u008eöÉt\u0092\u0016%µ¦æÖÉ\u0094"
         .length();
      char var14 = 144;
      int var13 = -1;

      while (true) {
         byte[] var19 = var11.doFinal(var15.substring(++var13, var13 + var14).getBytes("ISO-8859-1"));
         String var31 = a(var19).intern();
         int var10001 = -1;
         var18[var16++] = var31;
         if ((var13 += var14) >= var17) {
            c = var18;
            d = new String[3];
            h = new HashMap(13);
            Cipher var0;
            var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
            var10002 = SecretKeyFactory.getInstance("DES");
            var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

            for (int var1 = 1; var1 < 8; var1++) {
               var10003[var1] = (byte)(15984540948092L << var1 * 8 >>> 56);
            }

            var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
            long[] var6 = new long[4];
            String var4 = "Ë\u0085¶\u008a´Ñ'LØ\u009d«\u0011yÞÌ\u0080";
            int var5 = "Ë\u0085¶\u008a´Ñ'LØ\u009d«\u0011yÞÌ\u0080".length();
            label38:
            while (true) {
               var10001 = var2;
               var2 += 8;
               byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
               long[] var26 = var6;
               var10001 = var3++;
               long var34 = (var7[0] & 255L) << 56
                  | (var7[1] & 255L) << 48
                  | (var7[2] & 255L) << 40
                  | (var7[3] & 255L) << 32
                  | (var7[4] & 255L) << 24
                  | (var7[5] & 255L) << 16
                  | (var7[6] & 255L) << 8
                  | var7[7] & 255L;
               
                  long var8 = var34;
                  byte[] var10 = var0.doFinal(
                     new byte[]{
                        (byte)(var8 >>> 56),
                        (byte)(var8 >>> 48),
                        (byte)(var8 >>> 40),
                        (byte)(var8 >>> 32),
                        (byte)(var8 >>> 24),
                        (byte)(var8 >>> 16),
                        (byte)(var8 >>> 8),
                        (byte)var8
                     }
                  );
                  long var39 = (var10[0] & 255L) << 56
                     | (var10[1] & 255L) << 48
                     | (var10[2] & 255L) << 40
                     | (var10[3] & 255L) << 32
                     | (var10[4] & 255L) << 24
                     | (var10[5] & 255L) << 16
                     | (var10[6] & 255L) << 8
                     | var10[7] & 255L;
                  switch (var37) {
                     case 0:
                        var26[var10001] = var39;
                        if (var2 >= var5) {
                           f = var6;
                           g = new Integer[4];
                           Class<ShaderCompiler> var22 = ShaderCompiler.class;
                           a = dev.prestige.recovery.SourceSupport.asBoolean((!var22.desiredAssertionStatus() ? 1 : 0));
                           break;
                        }
                        break;
                     default:
                        var26[var10001] = var39;
                        if (var2 < var5) {
                           continue label38;
                        }

                        var4 = "{\u0013K\u0085×ø¶Ê¸éL\u0088¬itä";
                        var5 = "{\u0013K\u0085×ø¶Ê¸éL\u0088¬itä".length();
                        var2 = 0;
                  }

                  int var30 = var2;
                  var2 += 8;
                  var7 = var4.substring(var30, var2).getBytes("ISO-8859-1");
                  var26 = var6;
                  var10001 = var3++;
                  var34 = (var7[0] & 255L) << 56
                     | (var7[1] & 255L) << 48
                     | (var7[2] & 255L) << 40
                     | (var7[3] & 255L) << 32
                     | (var7[4] & 255L) << 24
                     | (var7[5] & 255L) << 16
                     | (var7[6] & 255L) << 8
                     | var7[7] & 255L;
                  var37 = 0;
               }
            }
         }

         var14 = var15.charAt(var13);
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 27300;
      if (d[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])e.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/fL", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = c[var5].getBytes("ISO-8859-1");
         d[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return d[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fL_C0293",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fL" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 4430;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/fL", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fL_C0293",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fL" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 23;
            yield var16;
         }
         case 2 -> {
            byte var17 = 0;
            yield var17;
         }
         case 3 -> {
            byte var18 = 49;
            yield var18;
         }
         case 4 -> {
            byte var19 = 17;
            yield var19;
         }
         case 5 -> {
            byte var20 = 25;
            yield var20;
         }
         case 6 -> {
            byte var21 = 43;
            yield var21;
         }
         case 7 -> {
            byte var22 = 45;
            yield var22;
         }
         case 8 -> {
            byte var23 = 41;
            yield var23;
         }
         case 9 -> {
            byte var24 = 42;
            yield var24;
         }
         case 10 -> {
            byte var25 = 35;
            yield var25;
         }
         case 11 -> {
            byte var26 = 7;
            yield var26;
         }
         case 12 -> {
            byte var27 = 56;
            yield var27;
         }
         case 13 -> {
            byte var28 = 26;
            yield var28;
         }
         case 14 -> {
            byte var29 = 36;
            yield var29;
         }
         case 15 -> {
            byte var30 = 19;
            yield var30;
         }
         case 16 -> {
            byte var31 = 62;
            yield var31;
         }
         case 17 -> {
            byte var32 = 30;
            yield var32;
         }
         case 18 -> {
            byte var33 = 51;
            yield var33;
         }
         case 19 -> {
            byte var34 = 52;
            yield var34;
         }
         case 20 -> {
            byte var35 = 29;
            yield var35;
         }
         case 21 -> {
            byte var36 = 12;
            yield var36;
         }
         case 22 -> {
            byte var37 = 34;
            yield var37;
         }
         case 23 -> {
            byte var38 = 24;
            yield var38;
         }
         case 24 -> {
            byte var39 = 10;
            yield var39;
         }
         case 25 -> {
            byte var40 = 63;
            yield var40;
         }
         case 26 -> {
            byte var41 = 59;
            yield var41;
         }
         case 27 -> {
            byte var42 = 31;
            yield var42;
         }
         case 28 -> {
            byte var43 = 3;
            yield var43;
         }
         case 29 -> {
            byte var44 = 8;
            yield var44;
         }
         case 30 -> {
            byte var45 = 55;
            yield var45;
         }
         case 31 -> {
            byte var46 = 54;
            yield var46;
         }
         case 32 -> {
            byte var47 = 11;
            yield var47;
         }
         case 33 -> {
            byte var48 = 58;
            yield var48;
         }
         case 34 -> {
            byte var49 = 20;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 38;
            yield var51;
         }
         case 37 -> {
            byte var52 = 28;
            yield var52;
         }
         case 38 -> {
            byte var53 = 40;
            yield var53;
         }
         case 39 -> {
            byte var54 = 13;
            yield var54;
         }
         case 40 -> {
            byte var55 = 44;
            yield var55;
         }
         case 41 -> {
            byte var56 = 15;
            yield var56;
         }
         case 42 -> {
            byte var57 = 4;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 61;
            yield var60;
         }
         case 46 -> {
            byte var61 = 37;
            yield var61;
         }
         case 47 -> {
            byte var62 = 2;
            yield var62;
         }
         case 48 -> {
            byte var63 = 39;
            yield var63;
         }
         case 49 -> {
            byte var64 = 9;
            yield var64;
         }
         case 50 -> {
            byte var65 = 60;
            yield var65;
         }
         case 51 -> {
            byte var66 = 16;
            yield var66;
         }
         case 52 -> {
            byte var67 = 22;
            yield var67;
         }
         case 53 -> {
            byte var68 = 47;
            yield var68;
         }
         case 54 -> {
            byte var69 = 1;
            yield var69;
         }
         case 55 -> {
            byte var70 = 5;
            yield var70;
         }
         case 56 -> {
            byte var71 = 33;
            yield var71;
         }
         case 57 -> {
            byte var72 = 53;
            yield var72;
         }
         case 58 -> {
            byte var73 = 46;
            yield var73;
         }
         case 59 -> {
            byte var74 = 27;
            yield var74;
         }
         case 60 -> {
            byte var75 = 57;
            yield var75;
         }
         case 61 -> {
            byte var76 = 6;
            yield var76;
         }
         case 62 -> {
            byte var77 = 14;
            yield var77;
         }
         default -> 32;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "_Vs\u0016,\bIVvL?\u001f^\u001duJ3\u000bOZb]x\u001ew";
      i[1] = "JcX\u001c>CAlISDGRmY\u001crCE";
      i[2] = "CLT\u007fuBHCE0\u0018BH^Q";
      i[3] = boolean.class;
      j[3] = "java/lang/Boolean";
      i[4] = "\u000f4r:\u0006R\n{M5XN\u0011\u0006p)MZ\b";
      i[5] = "\n;";
      i[6] = "nt}z'we{l5JwefxWfz`py";
      i[7] = void.class;
      j[7] = "java/lang/Void";
      i[8] = "{MB7repBSx\u000f}cEZ1";
      i[9] = "\u000eg1C\u0017V\u0005h \fjC\u0017r\"O";
      i[10] = "{Wuq\u0003=~\u0018SbD:eewbH5|";
      i[11] = "d,Z\u007f\u007fAa9Q\u007f|Fn0Z==qGl\r";
      i[12] = int.class;
      j[12] = "java/lang/Integer";
      i[13] = ",zr\u000em]'ucA\u0000Y'iW\n2D#ug\n";
      i[14] = "\u0012LIX \u000b\u0011B\u0011Zf\u0004\n^ZM 6\fLQ]o\u0017\u001cnWX|\u0016\u001dYL";
      i[15] = "#o#\u007fAd a{}\u0007k;}0jAI!o'm\n~";
      i[16] = "kJ(X)+\u001ej#W8d\u007fd(\\<>\u000b";
      i[17] = "x4G96us;VvW{x0R,";
      i[18] = "\u0019P(4;l_Pt1WnBo%7\u000f{AO2\"2@@N/\u000f0n&\u0010.7-e\u001b\u001f:1i\u0001\u0018\u0018:73c\u001c\u001a3sW";
      i[19] = "l4@?-526SeB\u007f:4QJ&a\u001d,An9\u0005l%[2 x9$TdB";
      i[20] = "\u0012\u001b\"=QAY\u0014\"\"h^F\u0005\u0003 \u0001JP=/-\u0004\\Qyt+\u0013\u0000A\u0003%#\r^+";
      i[21] = "\u00172\f\u00170MQ2P\u0012\\OL\t\u0016\u00055\\E\u001a\u0016\u000f3ZA'lX:\\R&QW.Z\u0016B";
      i[22] = "tMqv072M-s\\5/tmu51+fq`071=!o  /\u0000.{&dK\rwu&>v\u0002csbZwLw22k{Pk{\\";
      i[23] = "u6=d\u00035+4.>ln*8;5l9?9{6]5#%2X";
      i[24] = "g{K 7f6sU~]s6hj|&{&n[|\u0014g\u0000hJ|4y[*\bc!x9.\nje\u001c`}M-2,>\u007f^w]";
      i[25] = "#/A1\u001fU1%_H\u001a?)=Qq\rN/<[,s\u000f%\"[,N\u00001$\u001fH";
      i[26] = ".@:\u0007\u0002\u0019pBg\u0015oMjB]Z\u000b\u001a*F-\u0002\u0003Dq";
      i[27] = "E\"\u00054I7\u0003\"Y1%5\u001e\u001d\b7~:\u0013>\b1DZJ4\u00191AgE \u001fu%j\u001c.\u001f/\u0018e\b([K\u0015<\u0006(\u0001v\u001a(\u0000le";
      i[28] = "w#l>\u0001P1#0;mR,\u0018k$\u0015\\,>W!\u0004Q%)\fq\u000bA271~\u001fGvS00\u000b\u0006&b<,\u0017OH";
      i[29] = ">~Qw7\u00177h\u00006F\u0011k~fr>\u0000}\u007fFt+\u0014\u0007+Qc>\th\"G2\u007fx;c[4(I7\u007fG}F";
      i[30] = ":m*(21betsL9\u007fhvn('\u00057(`0%g3*itA9xv)\"p5dj`L";
      i[31] = "\f\u0000qb\u0003t\u001e\no\u001b\u0006\u001eU\u001d}c\u001eq\\\u000b,\"o'\u0000\u001dij\u0000.\u0016L(\u001b";
      i[32] = "\u001a\u000b&>|s\\\u000bz;\u0010qA0<,ybH &(|s_{v'ldAFy3j %K =jz\u0018D4;.\u001e";
      i[33] = "bk&<<m$kz9Po9@&*<m'@!>*k0\u001bv%,z9&y1*>]*z=n\u007fl!\u007f~/\u0000aj x>1mv<1P";
      i[34] = "HPdb/\u001b\u000eP8gC\u0019\u0013oia\u001b\f\u0010O~t&\u0017w\u0010ba9\u0012J\u001fvg}vGFxg'KHR~#CF\u0011\\~y~I\u0005Z:\u001d";
      i[35] = "\u001aRVX{\\Q]VGB@NK][/@jKGL8PBWZz>E_MG!x\u0017Q\n\u0001O{NOO<";
      i[36] = "b\u0000^1\u0018J$\u0000\u00024tH9<S*\u0019[0+^'\u0018J'p\u000e(\b]9M\u0001<\u000e\u0019]LO(OIl@S4\u0006'";
      i[37] = "MSNo\u0001\"\u000bS\u0012jm \u0016lCl6/\u001bOCj,)\u001cDjw\u0002OBERj\trMQT.mqJQRt\u000fuHX\u0016\u0010";
      i[38] = "1Rf\u0018.T9S`\u0007\u00104\u0004&\rO\u0010\u0000>\u0006bA\u007f\u0015`\u0005c";
      i[39] = "\u0004\u0015*p*\u0011B\u0015vuF\u0013_!+i%$A\u0002%u/\u0019;U,s<\u0018\u0006Z8ux|\u0007\u0014,4(M\u000b\b0}F";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(1238639812406232L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(1238639812406232L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(1238639812406232L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 36;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 250;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 71;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 198;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 210;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 232;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 36;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 250;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 71;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/fL_C0293",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/fL" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
