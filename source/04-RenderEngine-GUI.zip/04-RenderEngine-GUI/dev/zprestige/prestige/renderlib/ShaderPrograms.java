package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class ShaderPrograms {
   public static final GlProgram a;
   public static final GlProgram b;
   public static final GlProgram c;
   public static final GlProgram d;
   public static final GlProgram e;
   private static final Object[] f = new Object[5];
   private static final String[] g = new String[5];

   static {

      {

      long var10001 = 105766235130000L ^ 131512945938003L;
      aReturningVoid();
      Cipher var1;
      Cipher var10000 = var1 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(105766235130000L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var0 = new String[10];
      String var5 = "\"\u001dz\u0003É\u00911Z#{2E]@H3n¦\u0088°ãÖà\u008b \"\u001dz\u0003É\u00911Z\u000bâÛ\t\u0019\u0088Ø\u009cGL¸³XYiùr0\u0080¶c\u0017\u0081\u0089 \"\u001dz\u0003É\u00911Z\u000bâÛ\t\u0019\u0088Ø\u009cGL¸³XYiùçÃÂ=\u0007mÍ\u0089\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZ\u0089\u009a= ¥\u008b\\î\u0018\"\u001dz\u0003É\u00911ZæõÎ¨\u0014çªÊÖ\r¶\u0093e¥\u000bà\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZ\u0089\u009a= ¥\u008b\\î\u0018\"\u001dz\u0003É\u00911Z\u0099\u0091ÑxW=Â5ü+gQ&ØGp\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZy>þ¹p\u00adN;";
      int var7 = "\"\u001dz\u0003É\u00911Z#{2E]@H3n¦\u0088°ãÖà\u008b \"\u001dz\u0003É\u00911Z\u000bâÛ\t\u0019\u0088Ø\u009cGL¸³XYiùr0\u0080¶c\u0017\u0081\u0089 \"\u001dz\u0003É\u00911Z\u000bâÛ\t\u0019\u0088Ø\u009cGL¸³XYiùçÃÂ=\u0007mÍ\u0089\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZ\u0089\u009a= ¥\u008b\\î\u0018\"\u001dz\u0003É\u00911ZæõÎ¨\u0014çªÊÖ\r¶\u0093e¥\u000bà\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZ\u0089\u009a= ¥\u008b\\î\u0018\"\u001dz\u0003É\u00911Z\u0099\u0091ÑxW=Â5ü+gQ&ØGp\u0018\"\u001dz\u0003É\u00911ZÌmG\u0000iDJZy>þ¹p\u00adN;"
         .length();
      char var4 = 24;
      int var19 = -1;

      label28:
      while (true) {
         String var20 = var5.substring(++var19, var19 + var4);
         
            byte[] var8 = var1.doFinal(var20.getBytes("ISO-8859-1"));
            String var37 = a(var8).intern();
            switch (var27) {
               case 0:
                  var0[var6++] = var37;
                  if ((var19 += var4) >= var7) {
                     String var22 = var0[0];
                     String var31 = var0[8];
                     Object[] var10005 = new Object[]{null, null, null, 26034492851907L};
                     var10005[2] = false;
                     var10005[1] = var31;
                     var10005[0] = var22;
                     Object[] var13 = var10005;
                     a = ShaderCompiler.aReturningfM_C0295(var13);
                     String var23 = var0[5];
                     String var32 = var0[7];
                     var10005 = new Object[]{null, null, null, 26034492851907L};
                     var10005[2] = false;
                     var10005[1] = var32;
                     var10005[0] = var23;
                     Object[] var14 = var10005;
                     b = ShaderCompiler.aReturningfM_C0295(var14);
                     String var24 = var0[2];
                     String var33 = var0[1];
                     var10005 = new Object[]{null, null, null, 26034492851907L};
                     var10005[2] = false;
                     var10005[1] = var33;
                     var10005[0] = var24;
                     Object[] var15 = var10005;
                     c = ShaderCompiler.aReturningfM_C0295(var15);
                     String var25 = var0[6];
                     String var34 = var0[4];
                     var10005 = new Object[]{null, null, null, 26034492851907L};
                     var10005[2] = false;
                     var10005[1] = var34;
                     var10005[0] = var25;
                     Object[] var16 = var10005;
                     d = ShaderCompiler.aReturningfM_C0295(var16);
                     String var26 = var0[3];
                     String var35 = var0[9];
                     var10005 = new Object[]{null, null, null, 26034492851907L};
                     var10005[2] = false;
                     var10005[1] = var35;
                     var10005[0] = var26;
                     Object[] var17 = var10005;
                     e = ShaderCompiler.aReturningfM_C0295(var17);
                     break;
                  }

                  var4 = var5.charAt(var19);
                  break;
               default:
                  var0[var6++] = var37;
                  if ((var19 += var4) < var7) {
                     var4 = var5.charAt(var19);
                     continue label28;
                  }

                  var5 = "\"\u001dz\u0003É\u00911Z#{2E]@H3P\u0015ì¾\f\u0080b\u0019\u0018\"\u001dz\u0003É\u00911Z´¾\u000bþ\u0084ç\u0019-®\rÂ\u0090\u0086q§l";
                  var7 = "\"\u001dz\u0003É\u00911Z#{2E]@H3P\u0015ì¾\f\u0080b\u0019\u0018\"\u001dz\u0003É\u00911Z´¾\u000bþ\u0084ç\u0019-®\rÂ\u0090\u0086q§l"
                     .length();
                  var4 = 24;
                  var19 = -1;
            }

            var20 = var5.substring(++var19, var19 + var4);
            var27 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 46;
            yield var15;
         }
         case 1 -> {
            byte var16 = 0;
            yield var16;
         }
         case 2 -> {
            byte var17 = 16;
            yield var17;
         }
         case 3 -> {
            byte var18 = 12;
            yield var18;
         }
         case 4 -> {
            byte var19 = 52;
            yield var19;
         }
         case 5 -> {
            byte var20 = 57;
            yield var20;
         }
         case 6 -> {
            byte var21 = 7;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 24;
            yield var23;
         }
         case 9 -> {
            byte var24 = 23;
            yield var24;
         }
         case 10 -> {
            byte var25 = 32;
            yield var25;
         }
         case 11 -> {
            byte var26 = 36;
            yield var26;
         }
         case 12 -> {
            byte var27 = 55;
            yield var27;
         }
         case 13 -> {
            byte var28 = 5;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 49;
            yield var30;
         }
         case 16 -> {
            byte var31 = 54;
            yield var31;
         }
         case 17 -> {
            byte var32 = 33;
            yield var32;
         }
         case 18 -> {
            byte var33 = 38;
            yield var33;
         }
         case 19 -> {
            byte var34 = 43;
            yield var34;
         }
         case 20 -> {
            byte var35 = 4;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 19;
            yield var37;
         }
         case 23 -> {
            byte var38 = 61;
            yield var38;
         }
         case 24 -> {
            byte var39 = 45;
            yield var39;
         }
         case 25 -> {
            byte var40 = 53;
            yield var40;
         }
         case 26 -> {
            byte var41 = 9;
            yield var41;
         }
         case 27 -> {
            byte var42 = 29;
            yield var42;
         }
         case 28 -> {
            byte var43 = 21;
            yield var43;
         }
         case 29 -> {
            byte var44 = 8;
            yield var44;
         }
         case 30 -> {
            byte var45 = 15;
            yield var45;
         }
         case 31 -> {
            byte var46 = 2;
            yield var46;
         }
         case 32 -> {
            byte var47 = 41;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 63;
            yield var49;
         }
         case 35 -> {
            byte var50 = 28;
            yield var50;
         }
         case 36 -> {
            byte var51 = 58;
            yield var51;
         }
         case 37 -> {
            byte var52 = 40;
            yield var52;
         }
         case 38 -> {
            byte var53 = 13;
            yield var53;
         }
         case 39 -> {
            byte var54 = 1;
            yield var54;
         }
         case 40 -> {
            byte var55 = 17;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 26;
            yield var57;
         }
         case 43 -> {
            byte var58 = 37;
            yield var58;
         }
         case 44 -> {
            byte var59 = 10;
            yield var59;
         }
         case 45 -> {
            byte var60 = 35;
            yield var60;
         }
         case 46 -> {
            byte var61 = 50;
            yield var61;
         }
         case 47 -> {
            byte var62 = 48;
            yield var62;
         }
         case 48 -> {
            byte var63 = 30;
            yield var63;
         }
         case 49 -> {
            byte var64 = 27;
            yield var64;
         }
         case 50 -> {
            byte var65 = 11;
            yield var65;
         }
         case 51 -> {
            byte var66 = 47;
            yield var66;
         }
         case 52 -> {
            byte var67 = 6;
            yield var67;
         }
         case 53 -> {
            byte var68 = 18;
            yield var68;
         }
         case 54 -> {
            byte var69 = 39;
            yield var69;
         }
         case 55 -> {
            byte var70 = 31;
            yield var70;
         }
         case 56 -> {
            byte var71 = 56;
            yield var71;
         }
         case 57 -> {
            byte var72 = 22;
            yield var72;
         }
         case 58 -> {
            byte var73 = 25;
            yield var73;
         }
         case 59 -> {
            byte var74 = 3;
            yield var74;
         }
         case 60 -> {
            byte var75 = 42;
            yield var75;
         }
         case 61 -> {
            byte var76 = 44;
            yield var76;
         }
         case 62 -> {
            byte var77 = 62;
            yield var77;
         }
         default -> 60;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      f[0] = "\u0012za\u0011N\u0003\u0004zdK]\u0014\u00131gMQ\u0000\u0002vpZ\u001a\u0015:";
      f[1] = "\u0003|\u0013_Ctv\\\u0018PR;\u0017R\u0013[Vac";
      f[2] = "H\u001b::?B^\u001b?`,UIP<f AX\u0017+qkTa";
      f[3] = "\fU'z2\u0001\u0007Z65S\u000f\fQ2o";
      f[4] = "Ph\u0011\bFoR}\u001feM\u001e\u0000\u007f\u001a\u0018Y!\u0004x\b\u0005$'V&H\u001bKc@|\u000fe";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(254969339730179L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(254969339730179L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(254969339730179L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 100;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 114;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 36;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 73;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 222;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 225;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 100;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 114;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 36;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cm_C0136",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cm" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
