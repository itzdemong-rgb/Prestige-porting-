package dev.zprestige.prestige.renderlib;

import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector4f;

public class ShapeRenderer {
   public static AtomicReference a;
   private static final ThreadLocal b;
   private static final Matrix4f c;
   private static final ThreadLocal d;
   private static final long e = 11430233873117L;
   private static final long[] f;
   private static final Integer[] g;
   private static final Map h = new HashMap(13);
   private static final Object[] i = new Object[118];
   private static final String[] j = new String[118];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;
   private static volatile MethodHandle bindingCache50;
   private static volatile MethodHandle bindingCache51;
   private static volatile MethodHandle bindingCache52;
   private static volatile MethodHandle bindingCache53;
   private static volatile MethodHandle bindingCache54;
   private static volatile MethodHandle bindingCache55;
   private static volatile MethodHandle bindingCache56;
   private static volatile MethodHandle bindingCache57;
   private static volatile MethodHandle bindingCache58;
   private static volatile MethodHandle bindingCache59;
   private static volatile MethodHandle bindingCache60;
   private static volatile MethodHandle bindingCache61;
   private static volatile MethodHandle bindingCache62;
   private static volatile MethodHandle bindingCache63;
   private static volatile MethodHandle bindingCache64;
   private static volatile MethodHandle bindingCache65;
   private static volatile MethodHandle bindingCache66;
   private static volatile MethodHandle bindingCache67;
   private static volatile MethodHandle bindingCache68;
   private static volatile MethodHandle bindingCache69;
   private static volatile MethodHandle bindingCache70;
   private static volatile MethodHandle bindingCache71;
   private static volatile MethodHandle bindingCache72;
   private static volatile MethodHandle bindingCache73;
   private static volatile MethodHandle bindingCache74;
   private static volatile MethodHandle bindingCache75;
   private static volatile MethodHandle bindingCache76;
   private static volatile MethodHandle bindingCache77;
   private static volatile MethodHandle bindingCache78;
   private static volatile MethodHandle bindingCache79;
   private static volatile MethodHandle bindingCache80;
   private static volatile MethodHandle bindingCache81;
   private static volatile MethodHandle bindingCache82;
   private static volatile MethodHandle bindingCache83;
   private static volatile MethodHandle bindingCache84;
   private static volatile MethodHandle bindingCache85;
   private static volatile MethodHandle bindingCache86;
   private static volatile MethodHandle bindingCache87;
   private static volatile MethodHandle bindingCache88;
   private static volatile MethodHandle bindingCache89;
   private static volatile MethodHandle bindingCache90;
   private static volatile MethodHandle bindingCache91;
   private static volatile MethodHandle bindingCache92;
   private static volatile MethodHandle bindingCache93;
   private static volatile MethodHandle bindingCache94;
   private static volatile MethodHandle bindingCache95;

   public static void aReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      long var10000 = 11430233873117L ^ var1;
      int var3 = Event.cReturningInt();
      int var13 = var3;
      AtomicReference var12 = a;
      AtomicReference var11 = var12;
      AtomicReference var10 = var12;
      if (var13 != 0) {
         AtomicReference var4 = var10;
         Object var14 = var4.get();
         if (var14 != null) {
            return;
         }

         AtomicReference var15 = a;
         var11 = var15;
      }

      RenderCommandBatcher var9 = new RenderCommandBatcher();
      Object var8 = null;
      AtomicReference var7 = var11;
      var7.compareAndSet(var8, var9);
   }

   public static RenderCommandBatcher aReturningf4(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 11430233873117L ^ var1;
      long var3 = var1 ^ 38744116667477L;
      int var10000 = Event.bReturningInt();
      AtomicReference var7 = a;
      RenderCommandBatcher var6 = (RenderCommandBatcher)var7.get();
      int var5 = var10000;
      int var14 = var5;
      RenderCommandBatcher var13 = var6;
      RenderCommandBatcher var12 = var13;
      RenderCommandBatcher var11 = var13;
      if (var14 == 0) {
         RenderCommandBatcher var15 = var11;
         if (var15 == null) {
            Object[] var9 = new Object[]{var3};
            aReturningVoid(var9);
            AtomicReference var10 = a;
            var6 = (RenderCommandBatcher)var10.get();
         }

         var12 = var6;
      }

      return var12;
   }

   public static void bReturningVoid(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 11430233873117L ^ var1;
      long var3 = var1 ^ 140297941184440L;
      long var5 = var1 ^ 129807951325438L;
      Object[] var7 = new Object[]{var5};
      RenderCommandBatcher var10000 = aReturningf4(var7);
      Object[] var9 = new Object[]{GameRenderUtil.h, var3};
      RenderCommandBatcher var8 = var10000;
      var8.cReturningVoid(var9);
   }

   public static void cReturningVoid(Object[] var0) {
      RenderContext var1 = (RenderContext)var0[0];
      MeshBufferManager var3 = (MeshBufferManager)var0[1];
      ArrayList var6 = (ArrayList)var0[2];
      Color var2 = (Color)var0[3];
      long var4 = (Long)var0[4];
      var4 = 11430233873117L ^ var4;
      long var7 = var4 ^ 33884665454114L;
      long var9 = var4 ^ 65851084226852L;
      long var11 = var4 ^ 27466125770038L;
      long var13 = var4 ^ 34487131000775L;
      long var15 = var4 ^ 108566908643548L;
      long var17 = var4 ^ 23797746527601L;
      long var19 = var4 ^ 59339575370426L;
      int var21 = Event.cReturningInt();
      int var61 = var21;
      ArrayList var60 = var6;
      Object var59 = var60;
      ArrayList var58 = var60;
      if (var61 != 0) {
         ArrayList var28 = var58;
         boolean var62 = var28.isEmpty();
         if (var62) {
            return;
         }

         ThreadLocal var31 = b;
         var59 = var31.get();
      }

      Matrix4f var32 = (Matrix4f)var59;
      Matrix4f var22 = var32.identity();
      Object[] var34 = new Object[]{DrawPipelines.e, var19};
      MeshBufferManager var33 = var3;
      GlBufferMeshBuilder var23 = var33.aReturningGlBufferMeshBuilder(var34);
      Object[] var35 = new Object[]{var2, var15};
      int var24 = aReturningInt(var35);
      Object[] var37 = new Object[]{var7};
      GlBufferMeshBuilder var36 = var23;
      var36.kReturningVoid(var37);
      ThreadLocal var38 = d;
      Vector3d var25 = (Vector3d)var38.get();
      ArrayList var39 = var6;
      Iterator var26 = var39.iterator();

      while (true) {
         Iterator var40 = var26;
         boolean var63 = var40.hasNext();
         if (var63) {
            Iterator var41 = var26;
            Vec3d var27 = (Vec3d)var41.next();
            Vec3d var42 = var27;
            double var10001 = var42.x;
            Vec3d var43 = var27;
            double var10002 = var43.y;
            Vec3d var44 = var27;
            double var10003 = var44.z;
            Object[] var10007 = new Object[]{null, null, null, null, var25, var9};
            var10007[3] = var10003;
            var10007[2] = var10002;
            var10007[1] = var10001;
            var10007[0] = var1;
            Object[] var45 = var10007;
            RenderThreadUtil.bReturningVector3d(var45);
            Vector3d var46 = var25;
            float var68 = (float)var46.x;
            Vector3d var47 = var25;
            float var69 = (float)var47.y;
            Vector3d var48 = var25;
            float var10004 = (float)var48.z;
            var10007 = new Object[]{null, null, null, null, var13};
            var10007[3] = var10004;
            var10007[2] = var69;
            var10007[1] = var68;
            var10007[0] = var22;
            Object[] var50 = var10007;
            GlBufferMeshBuilder var49 = var23;
            GlBufferMeshBuilder var10000 = var49.dReturningGlBufferMeshBuilder(var50);
            Object[] var70 = new Object[]{null, var11};
            var70[0] = var24;
            Object[] var52 = var70;
            GlBufferMeshBuilder var51 = var10000;
            var51.eReturningGlBufferMeshBuilder(var52);
            int var64 = var21;
            if (var64 == 0) {
               break;
            }

            int var65 = var21;
            if (var65 != 0) {
               continue;
            }
         }

         Object[] var55 = new Object[]{PrimitiveMode.DEBUG_LINE_STRIP, var17};
         GlBufferMeshBuilder var54 = var23;
         GlBufferMeshBuilder var67 = (GlBufferMeshBuilder)var54.iReturningVoid(var55);
         Object[] var57 = new Object[0];
         GlBufferMeshBuilder var56 = var67;
         var56.hReturningGlBufferMeshBuilder(var57);
         break;
      }
   }

   public static void dReturningVoid(Object[] var0) {
      RenderContext var2 = (RenderContext)var0[0];
      MeshBufferManager var4 = (MeshBufferManager)var0[1];
      float var5 = (Float)var0[2];
      float var1 = (Float)var0[3];
      float var9 = (Float)var0[4];
      float var10 = (Float)var0[5];
      Color var8 = (Color)var0[6];
      Color var3 = (Color)var0[7];
      long var6 = (Long)var0[8];
      var6 = 11430233873117L ^ var6;
      long var11 = var6 ^ 57377000818646L;
      ThreadLocal var13 = b;
      Matrix4f var14 = (Matrix4f)var13.get();
      Matrix4f var10002 = var14.identity();
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, var8, var3, var11};
      var10011[6] = var10;
      var10011[5] = var9;
      var10011[4] = var1;
      var10011[3] = var5;
      var10011[2] = var10002;
      var10011[1] = var4;
      var10011[0] = var2;
      Object[] var15 = var10011;
      eReturningVoid(var15);
   }

   public static void eReturningVoid(Object[] var0) {
      RenderContext var5 = (RenderContext)var0[0];
      MeshBufferManager var3 = (MeshBufferManager)var0[1];
      Matrix4f var6 = (Matrix4f)var0[2];
      float var4 = (Float)var0[3];
      float var7 = (Float)var0[4];
      float var11 = (Float)var0[5];
      float var1 = (Float)var0[6];
      Color var2 = (Color)var0[7];
      Color var8 = (Color)var0[8];
      long var9 = (Long)var0[9];
      var9 = 11430233873117L ^ var9;
      long var12 = var9 ^ 40504744327979L;
      long var14 = var9 ^ 1701793711778L;
      long var16 = var9 ^ 8416744875446L;
      long var18 = var9 ^ 4035745607L;
      long var20 = var9 ^ 138405014663260L;
      long var22 = var9 ^ 12066736289265L;
      long var24 = var9 ^ 46889432152634L;
      double var10001 = var4;
      double var10002 = var7;
      double var10003 = var11;
      Object[] var10006 = new Object[]{null, null, null, null, var12};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var5;
      Object[] var40 = var10006;
      Vector3d var27 = RenderThreadUtil.aReturningVector3d(var40);
      int var10000 = Event.bReturningInt();
      Object[] var42 = new Object[]{DrawPipelines.b, var24};
      MeshBufferManager var41 = var3;
      GlBufferMeshBuilder var28 = var41.aReturningGlBufferMeshBuilder(var42);
      Vector3d var43 = var27;
      float var29 = (float)var43.x;
      Vector3d var44 = var27;
      float var30 = (float)var44.y;
      Vector3d var45 = var27;
      float var31 = (float)var45.z;
      Object[] var46 = new Object[]{var2, var20};
      int var32 = aReturningInt(var46);
      int var26 = var10000;
      Object[] var47 = new Object[]{var8, var20};
      int var33 = aReturningInt(var47);
      Object[] var49 = new Object[]{var14};
      GlBufferMeshBuilder var48 = var28;
      var48.kReturningVoid(var49);
      Object[] var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var6;
      Object[] var51 = var10007;
      GlBufferMeshBuilder var50 = var28;
      GlBufferMeshBuilder var72 = var50.dReturningGlBufferMeshBuilder(var51);
      Object[] var10004 = new Object[]{null, var16};
      var10004[0] = var32;
      Object[] var53 = var10004;
      GlBufferMeshBuilder var52 = var72;
      var52.eReturningGlBufferMeshBuilder(var53);
      while (true) {
         short var75 = 6775;
         long var76 = 8088087441139314387L ^ var9;
         byte var68 = 100;
         int var67 = var34;
         if (var67 <= var68) {
            float var35 = (float)((Math.PI * 2) * var34 / 100.0);
            double var54 = var35;
            float var36 = (float)Math.cos(var54);
            double var56 = var35;
            float var37 = (float)Math.sin(var56);
            float var38 = var29 + var1 * var36;
            float var39 = var31 + var1 * var37;
            var10007 = new Object[]{null, null, null, null, var18};
            var10007[3] = var39;
            var10007[2] = var30;
            var10007[1] = var38;
            var10007[0] = var6;
            Object[] var59 = var10007;
            GlBufferMeshBuilder var58 = var28;
            GlBufferMeshBuilder var73 = var58.dReturningGlBufferMeshBuilder(var59);
            var10004 = new Object[]{null, var16};
            var10004[0] = var33;
            Object[] var61 = var10004;
            GlBufferMeshBuilder var60 = var73;
            var60.eReturningGlBufferMeshBuilder(var61);
            var34++;
            int var69 = var26;
            if (var69 != 0) {
               break;
            }

            int var70 = var26;
            if (var70 == 0) {
               continue;
            }
         }

         Object[] var64 = new Object[]{PrimitiveMode.TRIANGLES_FAN, var22};
         GlBufferMeshBuilder var63 = var28;
         GlBufferMeshBuilder var74 = (GlBufferMeshBuilder)var63.iReturningVoid(var64);
         Object[] var66 = new Object[0];
         GlBufferMeshBuilder var65 = var74;
         var65.hReturningGlBufferMeshBuilder(var66);
         break;
      }
   }

   public static void fReturningVoid(Object[] var0) {
      RenderContext var12 = (RenderContext)var0[0];
      MeshBufferManager var9 = (MeshBufferManager)var0[1];
      float var8 = (Float)var0[2];
      float var10 = (Float)var0[3];
      float var4 = (Float)var0[4];
      float var5 = (Float)var0[5];
      float var7 = (Float)var0[6];
      float var1 = (Float)var0[7];
      Color var6 = (Color)var0[8];
      Color var11 = (Color)var0[9];
      long var2 = (Long)var0[10];
      var2 = 11430233873117L ^ var2;
      long var13 = var2 ^ 112883000305095L;
      long var15 = var2 ^ 74698524760142L;
      long var17 = var2 ^ 76809262693210L;
      long var19 = var2 ^ 85131069274670L;
      long var21 = var2 ^ 73103854750123L;
      long var23 = var2 ^ 69942678138544L;
      long var25 = var2 ^ 115282999092438L;
      long var27 = var2 ^ 16941192958847L;
      double var10001 = var8;
      double var10002 = var10;
      double var10003 = var4;
      Object[] var10006 = new Object[]{null, null, null, null, var13};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var12;
      Object[] var50 = var10006;
      Vector3d var30 = RenderThreadUtil.aReturningVector3d(var50);
      ThreadLocal var51 = b;
      Matrix4f var52 = (Matrix4f)var51.get();
      Matrix4f var31 = var52.identity();
      Object[] var54 = new Object[]{DrawPipelines.b, var25};
      MeshBufferManager var53 = var9;
      GlBufferMeshBuilder var32 = var53.aReturningGlBufferMeshBuilder(var54);
      Vector3d var55 = var30;
      float var33 = (float)var55.x;
      Vector3d var56 = var30;
      float var34 = (float)var56.y;
      int var10000 = Event.bReturningInt();
      Vector3d var57 = var30;
      float var35 = (float)var57.z;
      Object[] var58 = new Object[]{var6, var23};
      int var36 = aReturningInt(var58);
      int var29 = var10000;
      Object[] var59 = new Object[]{var11, var23};
      var10000 = aReturningInt(var59);
      short var113 = 6965;
      long var121 = 118015147772965243L ^ var2;
      int var37 = var10000 & 16777215;
      Object[] var61 = new Object[]{var15};
      GlBufferMeshBuilder var60 = var32;
      var60.kReturningVoid(var61);
      while (true) {
         short var114 = 6775;
         long var122 = 8088160164050366527L ^ var2;
         byte var95 = 100;
         int var94 = var38;
         if (var94 <= var95) {
            float var39 = (float)((Math.PI * 2) * var38 / 100.0);
            double var62 = var39;
            float var40 = (float)Math.cos(var62);
            double var64 = var39;
            float var41 = (float)Math.sin(var64);
            float var42 = var33 + (var5 + var7 / 2.0F + var1) * var40;
            float var43 = var35 + (var5 + var7 / 2.0F + var1) * var41;
            Object[] var10007 = new Object[]{null, null, null, null, var21};
            var10007[3] = var43;
            var10007[2] = var34;
            var10007[1] = var42;
            var10007[0] = var31;
            Object[] var67 = var10007;
            GlBufferMeshBuilder var66 = var32;
            GlBufferMeshBuilder var107 = var66.dReturningGlBufferMeshBuilder(var67);
            Object[] var10004 = new Object[]{null, var17};
            var10004[0] = var37;
            Object[] var69 = var10004;
            GlBufferMeshBuilder var68 = var107;
            var68.eReturningGlBufferMeshBuilder(var69);
            float var44 = var33 + (var5 + var7 / 2.0F) * var40;
            float var45 = var35 + (var5 + var7 / 2.0F) * var41;
            var10007 = new Object[]{null, null, null, null, var21};
            var10007[3] = var45;
            var10007[2] = var34;
            var10007[1] = var44;
            var10007[0] = var31;
            Object[] var71 = var10007;
            GlBufferMeshBuilder var70 = var32;
            GlBufferMeshBuilder var108 = var70.dReturningGlBufferMeshBuilder(var71);
            var10004 = new Object[]{null, var17};
            var10004[0] = var36;
            Object[] var73 = var10004;
            GlBufferMeshBuilder var72 = var108;
            var72.eReturningGlBufferMeshBuilder(var73);
            float var46 = var33 + (var5 - var7 / 2.0F) * var40;
            float var47 = var35 + (var5 - var7 / 2.0F) * var41;
            var10007 = new Object[]{null, null, null, null, var21};
            var10007[3] = var47;
            var10007[2] = var34;
            var10007[1] = var46;
            var10007[0] = var31;
            Object[] var75 = var10007;
            GlBufferMeshBuilder var74 = var32;
            GlBufferMeshBuilder var109 = var74.dReturningGlBufferMeshBuilder(var75);
            var10004 = new Object[]{null, var17};
            var10004[0] = var36;
            Object[] var77 = var10004;
            GlBufferMeshBuilder var76 = var109;
            var76.eReturningGlBufferMeshBuilder(var77);
            float var48 = var33 + (var5 - var7 / 2.0F - var1) * var40;
            float var49 = var35 + (var5 - var7 / 2.0F - var1) * var41;
            var10007 = new Object[]{null, null, null, null, var21};
            var10007[3] = var49;
            var10007[2] = var34;
            var10007[1] = var48;
            var10007[0] = var31;
            Object[] var79 = var10007;
            GlBufferMeshBuilder var78 = var32;
            GlBufferMeshBuilder var110 = var78.dReturningGlBufferMeshBuilder(var79);
            var10004 = new Object[]{null, var17};
            var10004[0] = var37;
            Object[] var81 = var10004;
            GlBufferMeshBuilder var80 = var110;
            var80.eReturningGlBufferMeshBuilder(var81);
            var38++;
            int var96 = var29;
            if (var96 != 0) {
               break;
            }

            int var97 = var29;
            if (var97 == 0) {
               continue;
            }
         }

         short var111 = 6775;
         long var115 = 8088160164050366527L ^ var2;
         var38 = 100;
         short var123 = 5066;
         long var128 = 3114895483547122061L ^ var2;
         int var116 = 100 * 18 * 4;
         Object[] var132 = new Object[]{null, var27};
         var132[0] = var116;
         Object[] var84 = var132;
         GlBufferMeshBuilder var83 = var32;
         var83.aReturningVoid(var84);
         break;
      }

      while (true) {
         int var99 = var38;
         int var98 = var103;
         if (var98 < var99) {
            int var104 = var103 * 4;
            var10000 = var103 + 1;
            short var117 = 16275;
            long var124 = 2462294858982249950L ^ var2;
            int var105 = var10000 % 101 * 4;
            short var118 = 28765;
            long var125 = 305647269493709342L ^ var2;
            Object[] var86 = new Object[]{new int[]{var104, var104 + 1, var105 + 1, var105 + 1, var105, var104}, var19};
            GlBufferMeshBuilder var85 = var32;
            var85.gReturningGlBufferMeshBuilder(var86);
            short var119 = 5690;
            long var126 = 701342257882954864L ^ var2;
            Object[] var88 = new Object[]{new int[]{var104 + 1, var104 + 2, var105 + 2, var105 + 2, var105 + 1, var104 + 1}, var19};
            GlBufferMeshBuilder var87 = var32;
            var87.gReturningGlBufferMeshBuilder(var88);
            short var120 = 5690;
            long var127 = 701342257882954864L ^ var2;
            Object[] var90 = new Object[]{new int[]{var104 + 2, var104 + 3, var105 + 3, var105 + 3, var105 + 2, var104 + 2}, var19};
            GlBufferMeshBuilder var89 = var32;
            var89.gReturningGlBufferMeshBuilder(var90);
            var103++;
            int var100 = var29;
            if (var100 != 0) {
               break;
            }

            int var101 = var29;
            if (var101 == 0) {
               continue;
            }
         }

         Object[] var93 = new Object[0];
         GlBufferMeshBuilder var92 = var32;
         var92.hReturningGlBufferMeshBuilder(var93);
         break;
      }
   }

   public static void gReturningVoid(Object[] var0) {
      RenderContext var1 = (RenderContext)var0[0];
      MeshBufferManager var7 = (MeshBufferManager)var0[1];
      float var10 = (Float)var0[2];
      float var8 = (Float)var0[3];
      float var3 = (Float)var0[4];
      float var2 = (Float)var0[5];
      float var6 = (Float)var0[6];
      float var9 = (Float)var0[7];
      Color var11 = (Color)var0[8];
      long var4 = (Long)var0[9];
      var4 = 11430233873117L ^ var4;
      long var12 = var4 ^ 75644833822698L;
      long var14 = var4 ^ 107300821404259L;
      long var16 = var4 ^ 114063535368567L;
      long var18 = var4 ^ 105665340889990L;
      long var20 = var4 ^ 32960588594333L;
      long var22 = var4 ^ 117524533410096L;
      long var24 = var4 ^ 82186789533435L;
      double var10001 = var10;
      double var10002 = var8;
      double var10003 = var3;
      Object[] var10006 = new Object[]{null, null, null, null, var12};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var1;
      Object[] var37 = var10006;
      Vector3d var26 = RenderThreadUtil.aReturningVector3d(var37);
      var10001 = var2;
      var10002 = var6;
      var10003 = var9;
      var10006 = new Object[]{null, null, null, null, var12};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var1;
      Object[] var38 = var10006;
      Vector3d var27 = RenderThreadUtil.aReturningVector3d(var38);
      ThreadLocal var39 = b;
      Matrix4f var40 = (Matrix4f)var39.get();
      Matrix4f var28 = var40.identity();
      Object[] var42 = new Object[]{DrawPipelines.e, var24};
      MeshBufferManager var41 = var7;
      GlBufferMeshBuilder var29 = var41.aReturningGlBufferMeshBuilder(var42);
      Object[] var43 = new Object[]{var11, var20};
      int var30 = aReturningInt(var43);
      Vector3d var44 = var26;
      float var31 = (float)var44.x;
      Vector3d var45 = var26;
      float var32 = (float)var45.y;
      Vector3d var46 = var26;
      float var33 = (float)var46.z;
      Vector3d var47 = var27;
      float var34 = (float)var47.x;
      Vector3d var48 = var27;
      float var35 = (float)var48.y;
      Vector3d var49 = var27;
      float var36 = (float)var49.z;
      Object[] var51 = new Object[]{var14};
      GlBufferMeshBuilder var50 = var29;
      GlBufferMeshBuilder var10000 = (GlBufferMeshBuilder)var50.kReturningVoid(var51);
      Object[] var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var53 = var10007;
      GlBufferMeshBuilder var52 = var10000;
      var10000 = var52.dReturningGlBufferMeshBuilder(var53);
      Object[] var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var55 = var10004;
      GlBufferMeshBuilder var54 = var10000;
      var10000 = var54.eReturningGlBufferMeshBuilder(var55);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var57 = var10007;
      GlBufferMeshBuilder var56 = var10000;
      var10000 = var56.dReturningGlBufferMeshBuilder(var57);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var59 = var10004;
      GlBufferMeshBuilder var58 = var10000;
      var10000 = var58.eReturningGlBufferMeshBuilder(var59);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var61 = var10007;
      GlBufferMeshBuilder var60 = var10000;
      var10000 = var60.dReturningGlBufferMeshBuilder(var61);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var63 = var10004;
      GlBufferMeshBuilder var62 = var10000;
      var10000 = var62.eReturningGlBufferMeshBuilder(var63);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var65 = var10007;
      GlBufferMeshBuilder var64 = var10000;
      var10000 = var64.dReturningGlBufferMeshBuilder(var65);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var67 = var10004;
      GlBufferMeshBuilder var66 = var10000;
      var10000 = var66.eReturningGlBufferMeshBuilder(var67);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var69 = var10007;
      GlBufferMeshBuilder var68 = var10000;
      var10000 = var68.dReturningGlBufferMeshBuilder(var69);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var71 = var10004;
      GlBufferMeshBuilder var70 = var10000;
      var10000 = var70.eReturningGlBufferMeshBuilder(var71);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var73 = var10007;
      GlBufferMeshBuilder var72 = var10000;
      var10000 = var72.dReturningGlBufferMeshBuilder(var73);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var75 = var10004;
      GlBufferMeshBuilder var74 = var10000;
      var10000 = var74.eReturningGlBufferMeshBuilder(var75);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var77 = var10007;
      GlBufferMeshBuilder var76 = var10000;
      var10000 = var76.dReturningGlBufferMeshBuilder(var77);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var79 = var10004;
      GlBufferMeshBuilder var78 = var10000;
      var10000 = var78.eReturningGlBufferMeshBuilder(var79);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var81 = var10007;
      GlBufferMeshBuilder var80 = var10000;
      var10000 = var80.dReturningGlBufferMeshBuilder(var81);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var83 = var10004;
      GlBufferMeshBuilder var82 = var10000;
      var10000 = var82.eReturningGlBufferMeshBuilder(var83);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var85 = var10007;
      GlBufferMeshBuilder var84 = var10000;
      var10000 = var84.dReturningGlBufferMeshBuilder(var85);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var87 = var10004;
      GlBufferMeshBuilder var86 = var10000;
      var10000 = var86.eReturningGlBufferMeshBuilder(var87);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var89 = var10007;
      GlBufferMeshBuilder var88 = var10000;
      var10000 = var88.dReturningGlBufferMeshBuilder(var89);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var91 = var10004;
      GlBufferMeshBuilder var90 = var10000;
      var10000 = var90.eReturningGlBufferMeshBuilder(var91);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var93 = var10007;
      GlBufferMeshBuilder var92 = var10000;
      var10000 = var92.dReturningGlBufferMeshBuilder(var93);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var95 = var10004;
      GlBufferMeshBuilder var94 = var10000;
      var10000 = var94.eReturningGlBufferMeshBuilder(var95);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var97 = var10007;
      GlBufferMeshBuilder var96 = var10000;
      var10000 = var96.dReturningGlBufferMeshBuilder(var97);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var99 = var10004;
      GlBufferMeshBuilder var98 = var10000;
      var10000 = var98.eReturningGlBufferMeshBuilder(var99);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var101 = var10007;
      GlBufferMeshBuilder var100 = var10000;
      var10000 = var100.dReturningGlBufferMeshBuilder(var101);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var103 = var10004;
      GlBufferMeshBuilder var102 = var10000;
      var10000 = var102.eReturningGlBufferMeshBuilder(var103);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var105 = var10007;
      GlBufferMeshBuilder var104 = var10000;
      var10000 = var104.dReturningGlBufferMeshBuilder(var105);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var107 = var10004;
      GlBufferMeshBuilder var106 = var10000;
      var10000 = var106.eReturningGlBufferMeshBuilder(var107);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var109 = var10007;
      GlBufferMeshBuilder var108 = var10000;
      var10000 = var108.dReturningGlBufferMeshBuilder(var109);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var111 = var10004;
      GlBufferMeshBuilder var110 = var10000;
      var10000 = var110.eReturningGlBufferMeshBuilder(var111);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var113 = var10007;
      GlBufferMeshBuilder var112 = var10000;
      var10000 = var112.dReturningGlBufferMeshBuilder(var113);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var115 = var10004;
      GlBufferMeshBuilder var114 = var10000;
      var10000 = var114.eReturningGlBufferMeshBuilder(var115);
      Object[] var117 = new Object[]{PrimitiveMode.DEBUG_LINE_STRIP, var22};
      GlBufferMeshBuilder var116 = var10000;
      var10000 = (GlBufferMeshBuilder)var116.iReturningVoid(var117);
      Object[] var119 = new Object[0];
      GlBufferMeshBuilder var118 = var10000;
      var118.hReturningGlBufferMeshBuilder(var119);
   }

   public static void hReturningVoid(Object[] var0) {
      RenderContext var1 = (RenderContext)var0[0];
      MeshBufferManager var11 = (MeshBufferManager)var0[1];
      float var9 = (Float)var0[2];
      float var5 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var6 = (Float)var0[6];
      float var2 = (Float)var0[7];
      Color var8 = (Color)var0[8];
      long var3 = (Long)var0[9];
      var3 = 11430233873117L ^ var3;
      long var12 = var3 ^ 97060411346990L;
      long var14 = var3 ^ 137559875120551L;
      long var16 = var3 ^ 135479116959411L;
      long var18 = var3 ^ 136961897413698L;
      long var20 = var3 ^ 1584575109977L;
      long var22 = var3 ^ 130195964370676L;
      long var24 = var3 ^ 94787080343871L;
      double var10001 = var9;
      double var10002 = var5;
      double var10003 = var10;
      Object[] var10006 = new Object[]{null, null, null, null, var12};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var1;
      Object[] var37 = var10006;
      Vector3d var26 = RenderThreadUtil.aReturningVector3d(var37);
      var10001 = var7;
      var10002 = var6;
      var10003 = var2;
      var10006 = new Object[]{null, null, null, null, var12};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var1;
      Object[] var38 = var10006;
      Vector3d var27 = RenderThreadUtil.aReturningVector3d(var38);
      ThreadLocal var39 = b;
      Matrix4f var40 = (Matrix4f)var39.get();
      Matrix4f var28 = var40.identity();
      Object[] var42 = new Object[]{DrawPipelines.b, var24};
      MeshBufferManager var41 = var11;
      GlBufferMeshBuilder var29 = var41.aReturningGlBufferMeshBuilder(var42);
      Object[] var43 = new Object[]{var8, var20};
      int var30 = aReturningInt(var43);
      Vector3d var44 = var26;
      float var31 = (float)var44.x;
      Vector3d var45 = var26;
      float var32 = (float)var45.y;
      Vector3d var46 = var26;
      float var33 = (float)var46.z;
      Vector3d var47 = var27;
      float var34 = (float)var47.x;
      Vector3d var48 = var27;
      float var35 = (float)var48.y;
      Vector3d var49 = var27;
      float var36 = (float)var49.z;
      Object[] var51 = new Object[]{var14};
      GlBufferMeshBuilder var50 = var29;
      GlBufferMeshBuilder var10000 = (GlBufferMeshBuilder)var50.kReturningVoid(var51);
      Object[] var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var53 = var10007;
      GlBufferMeshBuilder var52 = var10000;
      var10000 = var52.dReturningGlBufferMeshBuilder(var53);
      Object[] var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var55 = var10004;
      GlBufferMeshBuilder var54 = var10000;
      var10000 = var54.eReturningGlBufferMeshBuilder(var55);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var57 = var10007;
      GlBufferMeshBuilder var56 = var10000;
      var10000 = var56.dReturningGlBufferMeshBuilder(var57);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var59 = var10004;
      GlBufferMeshBuilder var58 = var10000;
      var10000 = var58.eReturningGlBufferMeshBuilder(var59);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var61 = var10007;
      GlBufferMeshBuilder var60 = var10000;
      var10000 = var60.dReturningGlBufferMeshBuilder(var61);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var63 = var10004;
      GlBufferMeshBuilder var62 = var10000;
      var10000 = var62.eReturningGlBufferMeshBuilder(var63);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var65 = var10007;
      GlBufferMeshBuilder var64 = var10000;
      var10000 = var64.dReturningGlBufferMeshBuilder(var65);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var67 = var10004;
      GlBufferMeshBuilder var66 = var10000;
      var10000 = var66.eReturningGlBufferMeshBuilder(var67);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var69 = var10007;
      GlBufferMeshBuilder var68 = var10000;
      var10000 = var68.dReturningGlBufferMeshBuilder(var69);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var71 = var10004;
      GlBufferMeshBuilder var70 = var10000;
      var10000 = var70.eReturningGlBufferMeshBuilder(var71);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var73 = var10007;
      GlBufferMeshBuilder var72 = var10000;
      var10000 = var72.dReturningGlBufferMeshBuilder(var73);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var75 = var10004;
      GlBufferMeshBuilder var74 = var10000;
      var10000 = var74.eReturningGlBufferMeshBuilder(var75);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var77 = var10007;
      GlBufferMeshBuilder var76 = var10000;
      var10000 = var76.dReturningGlBufferMeshBuilder(var77);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var79 = var10004;
      GlBufferMeshBuilder var78 = var10000;
      var10000 = var78.eReturningGlBufferMeshBuilder(var79);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var81 = var10007;
      GlBufferMeshBuilder var80 = var10000;
      var10000 = var80.dReturningGlBufferMeshBuilder(var81);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var83 = var10004;
      GlBufferMeshBuilder var82 = var10000;
      var10000 = var82.eReturningGlBufferMeshBuilder(var83);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var85 = var10007;
      GlBufferMeshBuilder var84 = var10000;
      var10000 = var84.dReturningGlBufferMeshBuilder(var85);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var87 = var10004;
      GlBufferMeshBuilder var86 = var10000;
      var10000 = var86.eReturningGlBufferMeshBuilder(var87);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var89 = var10007;
      GlBufferMeshBuilder var88 = var10000;
      var10000 = var88.dReturningGlBufferMeshBuilder(var89);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var91 = var10004;
      GlBufferMeshBuilder var90 = var10000;
      var10000 = var90.eReturningGlBufferMeshBuilder(var91);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var93 = var10007;
      GlBufferMeshBuilder var92 = var10000;
      var10000 = var92.dReturningGlBufferMeshBuilder(var93);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var95 = var10004;
      GlBufferMeshBuilder var94 = var10000;
      var10000 = var94.eReturningGlBufferMeshBuilder(var95);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var97 = var10007;
      GlBufferMeshBuilder var96 = var10000;
      var10000 = var96.dReturningGlBufferMeshBuilder(var97);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var99 = var10004;
      GlBufferMeshBuilder var98 = var10000;
      var10000 = var98.eReturningGlBufferMeshBuilder(var99);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var101 = var10007;
      GlBufferMeshBuilder var100 = var10000;
      var10000 = var100.dReturningGlBufferMeshBuilder(var101);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var103 = var10004;
      GlBufferMeshBuilder var102 = var10000;
      var10000 = var102.eReturningGlBufferMeshBuilder(var103);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var105 = var10007;
      GlBufferMeshBuilder var104 = var10000;
      var10000 = var104.dReturningGlBufferMeshBuilder(var105);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var107 = var10004;
      GlBufferMeshBuilder var106 = var10000;
      var10000 = var106.eReturningGlBufferMeshBuilder(var107);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var109 = var10007;
      GlBufferMeshBuilder var108 = var10000;
      var10000 = var108.dReturningGlBufferMeshBuilder(var109);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var111 = var10004;
      GlBufferMeshBuilder var110 = var10000;
      var10000 = var110.eReturningGlBufferMeshBuilder(var111);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var113 = var10007;
      GlBufferMeshBuilder var112 = var10000;
      var10000 = var112.dReturningGlBufferMeshBuilder(var113);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var115 = var10004;
      GlBufferMeshBuilder var114 = var10000;
      var10000 = var114.eReturningGlBufferMeshBuilder(var115);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var117 = var10007;
      GlBufferMeshBuilder var116 = var10000;
      var10000 = var116.dReturningGlBufferMeshBuilder(var117);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var119 = var10004;
      GlBufferMeshBuilder var118 = var10000;
      var10000 = var118.eReturningGlBufferMeshBuilder(var119);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var121 = var10007;
      GlBufferMeshBuilder var120 = var10000;
      var10000 = var120.dReturningGlBufferMeshBuilder(var121);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var123 = var10004;
      GlBufferMeshBuilder var122 = var10000;
      var10000 = var122.eReturningGlBufferMeshBuilder(var123);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var125 = var10007;
      GlBufferMeshBuilder var124 = var10000;
      var10000 = var124.dReturningGlBufferMeshBuilder(var125);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var127 = var10004;
      GlBufferMeshBuilder var126 = var10000;
      var10000 = var126.eReturningGlBufferMeshBuilder(var127);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var31;
      var10007[0] = var28;
      Object[] var129 = var10007;
      GlBufferMeshBuilder var128 = var10000;
      var10000 = var128.dReturningGlBufferMeshBuilder(var129);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var131 = var10004;
      GlBufferMeshBuilder var130 = var10000;
      var10000 = var130.eReturningGlBufferMeshBuilder(var131);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var133 = var10007;
      GlBufferMeshBuilder var132 = var10000;
      var10000 = var132.dReturningGlBufferMeshBuilder(var133);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var135 = var10004;
      GlBufferMeshBuilder var134 = var10000;
      var10000 = var134.eReturningGlBufferMeshBuilder(var135);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var33;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var137 = var10007;
      GlBufferMeshBuilder var136 = var10000;
      var10000 = var136.dReturningGlBufferMeshBuilder(var137);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var139 = var10004;
      GlBufferMeshBuilder var138 = var10000;
      var10000 = var138.eReturningGlBufferMeshBuilder(var139);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var141 = var10007;
      GlBufferMeshBuilder var140 = var10000;
      var10000 = var140.dReturningGlBufferMeshBuilder(var141);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var143 = var10004;
      GlBufferMeshBuilder var142 = var10000;
      var10000 = var142.eReturningGlBufferMeshBuilder(var143);
      var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = var36;
      var10007[2] = var32;
      var10007[1] = var34;
      var10007[0] = var28;
      Object[] var145 = var10007;
      GlBufferMeshBuilder var144 = var10000;
      var10000 = var144.dReturningGlBufferMeshBuilder(var145);
      var10004 = new Object[]{null, var16};
      var10004[0] = var30;
      Object[] var147 = var10004;
      GlBufferMeshBuilder var146 = var10000;
      var10000 = var146.eReturningGlBufferMeshBuilder(var147);
      Object[] var149 = new Object[]{PrimitiveMode.QUADS, var22};
      GlBufferMeshBuilder var148 = var10000;
      var10000 = (GlBufferMeshBuilder)var148.iReturningVoid(var149);
      Object[] var151 = new Object[0];
      GlBufferMeshBuilder var150 = var10000;
      var150.hReturningGlBufferMeshBuilder(var151);
   }

   public static void iReturningVoid(Object[] var0) {
      RenderContext var8 = (RenderContext)var0[0];
      MeshBufferManager var6 = (MeshBufferManager)var0[1];
      Matrix4f var5 = (Matrix4f)var0[2];
      float var1 = (Float)var0[3];
      float var9 = (Float)var0[4];
      float var2 = (Float)var0[5];
      int var7 = (Integer)var0[6];
      long var3 = (Long)var0[7];
      var3 = 11430233873117L ^ var3;
      long var10 = var3 ^ 48596901355637L;
      long var12 = var3 ^ 10343843634684L;
      long var14 = var3 ^ 16783842606824L;
      long var16 = var3 ^ 9777885465625L;
      long var18 = var3 ^ 2327442943663L;
      long var20 = var3 ^ 107324320264988L;
      long var22 = var3 ^ 37663308325220L;
      double var10001 = var1;
      double var10002 = var9;
      double var10003 = var2;
      Object[] var10006 = new Object[]{null, null, null, null, var10};
      var10006[3] = var10003;
      var10006[2] = var10002;
      var10006[1] = var10001;
      var10006[0] = var8;
      Vector3d var24 = invokeBinding1(var10006, 2116305350647810829L, var3);
      GlBufferMeshBuilder var25 = invokeBinding2(var6, new Object[]{DrawPipelines.c, var22}, 2116378521519631381L, var3);
      float var26 = (float)invokeBinding3(var24, 2110404442788053289L, var3);
      float var27 = (float)invokeBinding4(var24, 2115326782382665990L, var3);
      float var28 = (float)invokeBinding5(var24, 2112663495938633254L, var3);
      float var29 = (float)(invokeBinding6(var24, 2110404442788053289L, var3) + 1.0);
      float var30 = (float)(invokeBinding7(var24, 2115326782382665990L, var3) + 1.0);
      float var31 = (float)(invokeBinding8(var24, 2112663495938633254L, var3) + 1.0);
      Object[] var81 = new Object[]{null, var20};
      var81[0] = var7;
      int var32 = invokeBinding9(var81, 2112990003659661367L, var3);
      GlBufferMeshBuilder var10000 = (GlBufferMeshBuilder)invokeBinding10(var25, new Object[]{var12}, 2114074284282827406L, var3);
      Object[] var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding11(var10000, var10007, 2116485056451682437L, var3);
      Object[] var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding12(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding13(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding14(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding15(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding16(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding17(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding18(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding19(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding20(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding21(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding22(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding23(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding24(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding25(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding26(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding27(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding28(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding29(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding30(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding31(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding32(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding33(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding34(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding35(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding36(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding37(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding38(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding39(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding40(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding41(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding42(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding43(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding44(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding45(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding46(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding47(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding48(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var26;
      var10007[0] = var5;
      var10000 = invokeBinding49(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding50(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding51(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding52(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var28;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding53(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding54(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var30;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding55(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      var10000 = invokeBinding56(var10000, var10004, 2113784679957499208L, var3);
      var10007 = new Object[]{null, null, null, null, var16};
      var10007[3] = var31;
      var10007[2] = var27;
      var10007[1] = var29;
      var10007[0] = var5;
      var10000 = invokeBinding57(var10000, var10007, 2116485056451682437L, var3);
      var10004 = new Object[]{null, var14};
      var10004[0] = var32;
      invokeBinding60(
         (GlBufferMeshBuilder)invokeBinding59(
            invokeBinding58(var10000, var10004, 2113784679957499208L, var3), new Object[]{PrimitiveMode.QUADS, var18}, 2113993867561115133L, var3
         ),
         new Object[0],
         2110221475436130974L,
         var3
      );
   }

   public static void jReturningVoid(Object[] var0) {
      float var3 = (Float)var0[0];
      float var1 = (Float)var0[1];
      float var5 = (Float)var0[2];
      float var2 = (Float)var0[3];
      Color var4 = (Color)var0[4];
      long var6 = (Long)var0[5];
      var6 = 11430233873117L ^ var6;
      long var8 = var6 ^ 15340317275269L;
      Matrix4f var10000 = c;
      int var10005 = invokeBinding61(var4, -2703361501071035453L, var6);
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10005;
      var10008[4] = var2;
      var10008[3] = var5;
      var10008[2] = var1;
      var10008[1] = var3;
      var10008[0] = var10000;
      invokeBinding62(var10008, -2705510191997234430L, var6);
   }

   public static void kReturningVoid(Object[] var0) {
      Matrix4f var8 = (Matrix4f)var0[0];
      float var6 = (Float)var0[1];
      float var9 = (Float)var0[2];
      float var1 = (Float)var0[3];
      float var5 = (Float)var0[4];
      float var4 = (Float)var0[5];
      float var10 = (Float)var0[6];
      int var7 = (Integer)var0[7];
      long var2 = (Long)var0[8];
      var2 = 11430233873117L ^ var2;
      long var11 = var2 ^ 56258104560886L;
      long var13 = var2 ^ 139188798626474L;
      Object[] var15 = new Object[]{var13};
      RenderCommandBatcher var10000 = aReturningf4(var15);
      Object[] var17 = new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding63(var7, var8, var6, var9, var1, var5, var4, var10)), var11};
      RenderCommandBatcher var16 = var10000;
      var16.bReturningVoid(var17);
   }

   public static void lReturningVoid(Object[] var0) {
      Matrix4f var8 = (Matrix4f)var0[0];
      float var1 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var4 = (Float)var0[3];
      float var3 = (Float)var0[4];
      Color var2 = (Color)var0[5];
      long var5 = (Long)var0[6];
      var5 = 11430233873117L ^ var5;
      long var9 = var5 ^ 59288296037157L;
      Color var11 = var2;
      int var10005 = var11.getRGB();
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var9};
      var10008[5] = var10005;
      var10008[4] = var3;
      var10008[3] = var4;
      var10008[2] = var7;
      var10008[1] = var1;
      var10008[0] = var8;
      Object[] var12 = var10008;
      mReturningVoid(var12);
   }

   public static void mReturningVoid(Object[] var0) {
      Matrix4f var6 = (Matrix4f)var0[0];
      float var2 = (Float)var0[1];
      float var8 = (Float)var0[2];
      float var1 = (Float)var0[3];
      float var3 = (Float)var0[4];
      int var7 = (Integer)var0[5];
      long var4 = (Long)var0[6];
      var4 = 11430233873117L ^ var4;
      long var9 = var4 ^ 111335735573473L;
      long var11 = var4 ^ 45078505106877L;
      Object[] var13 = new Object[]{var11};
      RenderCommandBatcher var10000 = aReturningf4(var13);
      Object[] var15 = new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding64(var7, var6, var2, var3, var1, var8)), var9};
      RenderCommandBatcher var14 = var10000;
      var14.bReturningVoid(var15);
   }

   public static void nReturningVoid(Object[] var0) {
      float var4 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var5 = (Float)var0[3];
      Color var1 = (Color)var0[4];
      Color var8 = (Color)var0[5];
      Color var2 = (Color)var0[6];
      Color var7 = (Color)var0[7];
      long var9 = (Long)var0[8];
      var9 = 11430233873117L ^ var9;
      long var11 = var9 ^ 65745212818168L;
      Matrix4f var10000 = c;
      int var10005 = invokeBinding65(var1, -8868514266728108716L, var9);
      int var10006 = invokeBinding66(var8, -8868514266728108716L, var9);
      int var10007 = invokeBinding67(var2, -8868514266728108716L, var9);
      int var10008 = invokeBinding68(var7, -8868514266728108716L, var9);
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var11};
      var10011[8] = var10008;
      var10011[7] = var10007;
      var10011[6] = var10006;
      var10011[5] = var10005;
      var10011[4] = var5;
      var10011[3] = var6;
      var10011[2] = var3;
      var10011[1] = var4;
      var10011[0] = var10000;
      invokeBinding69(var10011, -8869783790134493253L, var9);
   }

   public static void o(Object[] var0) {
      Matrix4f var10 = (Matrix4f)var0[0];
      float var8 = (Float)var0[1];
      float var11 = (Float)var0[2];
      float var7 = (Float)var0[3];
      float var1 = (Float)var0[4];
      int var5 = (Integer)var0[5];
      int var4 = (Integer)var0[6];
      int var6 = (Integer)var0[7];
      int var9 = (Integer)var0[8];
      long var2 = (Long)var0[9];
      var2 = 11430233873117L ^ var2;
      long var12 = var2 ^ 102464091149067L;
      long var14 = var2 ^ 18198605972823L;
      invokeBinding72(
         invokeBinding70(new Object[]{var14}, 6685140256936804814L, var2),
         new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding71(var5, var4, var6, var9, var10, var8, var1, var7, var11)), var12},
         6684465710099144972L,
         var2
      );
   }

   public static void p(Object[] var0) {
      Matrix4f var4 = (Matrix4f)var0[0];
      float var5 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var2 = (Float)var0[3];
      float var3 = (Float)var0[4];
      int var1 = (Integer)var0[5];
      long var7 = (Long)var0[6];
      var7 = 11430233873117L ^ var7;
      long var9 = var7 ^ 132035955954922L;
      long var11 = var7 ^ 59012631495350L;
      invokeBinding75(
         invokeBinding73(new Object[]{var11}, -7266761948708993489L, var7),
         new Object[]{new PipelineRenderCommand(DrawPipelines.d, invokeBinding74(var1, var4, var5, var3, var2, var6)), var9},
         -7268006042687183123L,
         var7
      );
   }

   public static void q(Object[] var0) {
      Matrix4f var3 = (Matrix4f)var0[0];
      float var6 = (Float)var0[1];
      float var1 = (Float)var0[2];
      float var2 = (Float)var0[3];
      float var7 = (Float)var0[4];
      int var8 = (Integer)var0[5];
      long var4 = (Long)var0[6];
      var4 = 11430233873117L ^ var4;
      long var9 = var4 ^ 8985581918044L;
      long var11 = var4 ^ 76492979273984L;
      invokeBinding78(
         invokeBinding76(new Object[]{var11}, 1770256293136401817L, var4),
         new Object[]{new PipelineRenderCommand(DrawPipelines.d, invokeBinding77(var8, var3, var6, var1, var2, var7)), var9},
         1771228815202674011L,
         var4
      );
   }

   public static void r(Object[] var0) {
      Matrix4f var1 = (Matrix4f)var0[0];
      float var6 = (Float)var0[1];
      float var2 = (Float)var0[2];
      float var9 = (Float)var0[3];
      float var8 = (Float)var0[4];
      float var7 = (Float)var0[5];
      Color var5 = (Color)var0[6];
      Color var10 = (Color)var0[7];
      long var3 = (Long)var0[8];
      var3 = 11430233873117L ^ var3;
      long var11 = var3 ^ 50929993712501L;
      long var13 = var3 ^ 109882017551657L;
      invokeBinding81(
         invokeBinding79(new Object[]{var13}, 916500967423185328L, var3),
         new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding80(var5, var10, var9, var6, var8, var2, var7, var1)), var11},
         918045235476656498L,
         var3
      );
   }

   public static void s(Object[] var0) {
      float var9 = (Float)var0[0];
      float var4 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var7 = (Float)var0[3];
      float var8 = (Float)var0[4];
      Color var1 = (Color)var0[5];
      Color var2 = (Color)var0[6];
      long var5 = (Long)var0[7];
      var5 = 11430233873117L ^ var5;
      long var10 = var5 ^ 32150670800643L;
      Matrix4f var10000 = c;
      Object[] var10010 = new Object[]{null, null, null, null, null, null, var1, var2, var10};
      var10010[5] = var8;
      var10010[4] = var7;
      var10010[3] = var3;
      var10010[2] = var4;
      var10010[1] = var9;
      var10010[0] = var10000;
      invokeBinding82(var10010, 7020931937148543652L, var5);
   }

   public static void t(Object[] var0) {
      float var1 = (Float)var0[0];
      float var3 = (Float)var0[1];
      float var2 = (Float)var0[2];
      float var4 = (Float)var0[3];
      Color var8 = (Color)var0[4];
      float var7 = (Float)var0[5];
      long var5 = (Long)var0[6];
      var5 = 11430233873117L ^ var5;
      long var9 = var5 ^ 91095115963559L;
      Matrix4f var10000 = c;
      Object[] var10009 = new Object[]{null, null, null, null, null, var8, new Vector4f(var7), var9};
      var10009[4] = var4;
      var10009[3] = var2;
      var10009[2] = var3;
      var10009[1] = var1;
      var10009[0] = var10000;
      invokeBinding83(var10009, -1862730415221038580L, var5);
   }

   public static void u(Object[] var0) {
      Matrix4f var9 = (Matrix4f)var0[0];
      float var7 = (Float)var0[1];
      float var1 = (Float)var0[2];
      float var6 = (Float)var0[3];
      float var4 = (Float)var0[4];
      Color var5 = (Color)var0[5];
      Vector4f var8 = (Vector4f)var0[6];
      long var2 = (Long)var0[7];
      var2 = 11430233873117L ^ var2;
      long var10 = var2 ^ 31637557964695L;
      long var12 = var2 ^ 76543235905132L;
      long var14 = var2 ^ 89592075647435L;
      Object[] var16 = new Object[]{var14};
      RenderCommandBatcher var10000 = aReturningf4(var16);
      Object[] var17 = new Object[]{var8, var12};
      Object[] var19 = new Object[]{new PipelineRenderCommand(DrawPipelines.aReturningdn_C0192(var17), invokeBinding84(var5, var6, var7, var4, var1, var9)), var10};
      RenderCommandBatcher var18 = var10000;
      var18.bReturningVoid(var19);
   }

   public static void v(Object[] var0) {
      float var6 = (Float)var0[0];
      float var4 = (Float)var0[1];
      float var5 = (Float)var0[2];
      float var7 = (Float)var0[3];
      Color var3 = (Color)var0[4];
      Color var9 = (Color)var0[5];
      Color var1 = (Color)var0[6];
      Color var8 = (Color)var0[7];
      float var2 = (Float)var0[8];
      long var10 = (Long)var0[9];
      var10 = 11430233873117L ^ var10;
      long var12 = var10 ^ 127802028642254L;
      Matrix4f var10000 = c;
      Object[] var10012 = new Object[]{null, null, null, null, null, var3, var9, var1, var8, new Vector4f(var2), var12};
      var10012[4] = var7;
      var10012[3] = var5;
      var10012[2] = var4;
      var10012[1] = var6;
      var10012[0] = var10000;
      invokeBinding85(var10012, -4050173140073234896L, var10);
   }

   public static void w(Object[] var0) {
      Matrix4f var1 = (Matrix4f)var0[0];
      float var11 = (Float)var0[1];
      float var3 = (Float)var0[2];
      float var8 = (Float)var0[3];
      float var12 = (Float)var0[4];
      Color var6 = (Color)var0[5];
      Color var4 = (Color)var0[6];
      Color var5 = (Color)var0[7];
      Color var7 = (Color)var0[8];
      Vector4f var2 = (Vector4f)var0[9];
      long var9 = (Long)var0[10];
      var9 = 11430233873117L ^ var9;
      long var13 = var9 ^ 89583794756893L;
      long var15 = var9 ^ 8944122995942L;
      long var17 = var9 ^ 31628893293377L;
      Object[] var19 = new Object[]{var17};
      RenderCommandBatcher var10000 = aReturningf4(var19);
      Object[] var20 = new Object[]{var2, var15};
      Object[] var22 = new Object[]{
         new PipelineRenderCommand(DrawPipelines.aReturningdn_C0192(var20), invokeBinding86(var6, var4, var5, var7, var8, var11, var12, var3, var1)), var13
      };
      RenderCommandBatcher var21 = var10000;
      var21.bReturningVoid(var22);
   }

   public static void x(Object[] var0) {
      float var1 = (Float)var0[0];
      float var6 = (Float)var0[1];
      float var2 = (Float)var0[2];
      Color var3 = (Color)var0[3];
      long var4 = (Long)var0[4];
      var4 = 11430233873117L ^ var4;
      long var7 = var4 ^ 4224005514092L;
      Matrix4f var10000 = c;
      int var10004 = invokeBinding87(var3, -5212688407751827952L, var4);
      Object[] var10007 = new Object[]{null, null, null, null, null, var7};
      var10007[4] = var10004;
      var10007[3] = var2;
      var10007[2] = var6;
      var10007[1] = var1;
      var10007[0] = var10000;
      invokeBinding88(var10007, -5211771126362698409L, var4);
   }

   public static void y(Object[] var0) {
      Matrix4f var3 = (Matrix4f)var0[0];
      float var4 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var5 = (Float)var0[3];
      int var6 = (Integer)var0[4];
      long var1 = (Long)var0[5];
      var1 = 11430233873117L ^ var1;
      long var8 = var1 ^ 35106536161755L;
      long var10 = var1 ^ 90503923013511L;
      Object[] var12 = new Object[]{var10};
      RenderCommandBatcher var10000 = aReturningf4(var12);
      Object[] var14 = new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding89(var6, var3, var4, var7, var5)), var8};
      RenderCommandBatcher var13 = var10000;
      var13.bReturningVoid(var14);
   }

   public static void z(Object[] var0) {
      float var4 = (Float)var0[0];
      float var5 = (Float)var0[1];
      float var7 = (Float)var0[2];
      float var6 = (Float)var0[3];
      Color var3 = (Color)var0[4];
      long var1 = (Long)var0[5];
      var1 = 11430233873117L ^ var1;
      long var8 = var1 ^ 99055760246776L;
      Matrix4f var10000 = c;
      int var10005 = invokeBinding90(var3, -7983040850577983346L, var1);
      Object[] var10008 = new Object[]{null, null, null, null, null, null, var8};
      var10008[5] = var10005;
      var10008[4] = var6;
      var10008[3] = var7;
      var10008[2] = var5;
      var10008[1] = var4;
      var10008[0] = var10000;
      invokeBinding91(var10008, -7987793224085047454L, var1);
   }

   public static void A(Object[] var0) {
      Matrix4f var5 = (Matrix4f)var0[0];
      float var1 = (Float)var0[1];
      float var6 = (Float)var0[2];
      float var8 = (Float)var0[3];
      float var2 = (Float)var0[4];
      int var7 = (Integer)var0[5];
      long var3 = (Long)var0[6];
      var3 = 11430233873117L ^ var3;
      long var9 = var3 ^ 3345902863313L;
      long var11 = var3 ^ 86547649697165L;
      Object[] var13 = new Object[]{var11};
      RenderCommandBatcher var10000 = aReturningf4(var13);
      Object[] var15 = new Object[]{new PipelineRenderCommand(DrawPipelines.c, invokeBinding92(var7, var2, var8, var1, var6, var5)), var9};
      RenderCommandBatcher var14 = var10000;
      var14.bReturningVoid(var15);
   }

   public static void B(Object[] var0) {
      MeshBufferManager var11 = (MeshBufferManager)var0[0];
      RenderContext var7 = (RenderContext)var0[1];
      float var8 = (Float)var0[2];
      float var10 = (Float)var0[3];
      float var4 = (Float)var0[4];
      float var5 = (Float)var0[5];
      Color var6 = (Color)var0[6];
      float var9 = (Float)var0[7];
      float var3 = (Float)var0[8];
      long var1 = (Long)var0[9];
      var1 = 11430233873117L ^ var1;
      long var12 = var1 ^ 44742595691783L;
      float var10004 = var4 - var8;
      float var10005 = var5 - var10;
      Object[] var10011 = new Object[]{null, null, null, null, null, null, null, null, null, var12};
      var10011[8] = var3;
      var10011[7] = var9;
      var10011[6] = var6;
      var10011[5] = var10005;
      var10011[4] = var10004;
      var10011[3] = var10;
      var10011[2] = var8;
      var10011[1] = var7;
      var10011[0] = var11;
      invokeBinding93(var10011, -3096573896552567837L, var1);
   }

   public static void C(Object[] var0) {
      MeshBufferManager var11 = (MeshBufferManager)var0[0];
      RenderContext var8 = (RenderContext)var0[1];
      Matrix4f var9 = (Matrix4f)var0[2];
      float var2 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var10 = (Float)var0[5];
      float var3 = (Float)var0[6];
      Color var6 = (Color)var0[7];
      float var12 = (Float)var0[8];
      float var7 = (Float)var0[9];
      long var4 = (Long)var0[10];
      var4 = 11430233873117L ^ var4;
      long var13 = var4 ^ 96145222013117L;
      float var10005 = var10 - var2;
      float var10006 = var3 - var1;
      Object[] var10012 = new Object[]{null, null, null, null, null, null, null, null, null, null, var13};
      var10012[9] = var7;
      var10012[8] = var12;
      var10012[7] = var6;
      var10012[6] = var10006;
      var10012[5] = var10005;
      var10012[4] = var1;
      var10012[3] = var2;
      var10012[2] = var9;
      var10012[1] = var8;
      var10012[0] = var11;
      Object[] var15 = var10012;
      OutlinedRectangleRenderer.cReturningVoid(var15);
   }

   public static Color aReturningColor(Object[] var0) {
      Color var1 = (Color)var0[0];
      float var2 = (Float)var0[1];
      long var3 = (Long)var0[2];
      long var10000 = 11430233873117L ^ var3;
      Color var8 = var1;
      float var5 = var8.getRed() / 255.0F;
      Color var9 = var1;
      float var6 = var9.getGreen() / 255.0F;
      Color var10 = var1;
      float var7 = var10.getBlue() / 255.0F;
      return new Color(var5, var6, var7, var2);
   }

   public static int aReturningInt(Object[] var0) {
      Color var1 = (Color)var0[0];
      long var2 = (Long)var0[1];
      var2 = 11430233873117L ^ var2;
      long var4 = var2 ^ 34074772046531L;
      Color var6 = var1;
      int var10000 = var6.getRGB();
      Object[] var10003 = new Object[]{null, var4};
      var10003[0] = var10000;
      Object[] var7 = var10003;
      return bReturningInt(var7);
   }

   public static int bReturningInt(Object[] var0) {
      int var1 = (Integer)var0[0];
      long var2 = (Long)var0[1];
      var2 = 11430233873117L ^ var2;
      short var10001 = 15902;
      long var10002 = 6627933977297582118L ^ var2;
      int var10000 = var1 >> 24;
      var10001 = 9788;
      var10002 = 6103381462438043662L ^ var2;
      int var4 = var10000 & 0xFF;
      var10001 = 2098;
      var10002 = 7068456433865477646L ^ var2;
      var10000 = var1 >> 16;
      var10001 = 12006;
      var10002 = 4983350821771897045L ^ var2;
      int var5 = var10000 & 0xFF;
      var10001 = 20017;
      var10002 = 6108649345166477319L ^ var2;
      var10000 = var1 >> 8;
      var10001 = 12006;
      var10002 = 4983350821771897045L ^ var2;
      int var6 = var10000 & 0xFF;
      var10001 = 12006;
      var10002 = 4983350821771897045L ^ var2;
      int var7 = var1 & 0xFF;
      var10001 = 1211;
      var10002 = 3775825036183028362L ^ var2;
      var10000 = var4 << 24;
      short var27 = 8560;
      long var10003 = 3974400123672094543L ^ var2;
      var10000 |= var7 << 16;
      short var28 = 21465;
      var10003 = 1765215952542602732L ^ var2;
      return var10000 | var6 << 8 | var5;
   }

   private static void lambda$circleOutline$9(int var0, float var1, float var2, float var3, float var4, Matrix4f var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 83423355663486L ^ 70717208065220L;
      var10001 = 83423355663486L ^ 11850760104034L;
      var10001 = 83423355663486L ^ 23806513738735L;
      var10001 = 83423355663486L ^ 3335994349461L;
      var10001 = 83423355663486L ^ 82620563589015L;
      var10001 = 83423355663486L ^ 44689617902116L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var36 = var10003;
      int var23 = bReturningInt(var36);
      float var25 = var1 / 2.0F;
      int var10000 = Event.cReturningInt();
      float var26 = var2 + var25;
      float var38 = var2 - var25;
      float var37 = 0.0F;
      float var27 = Math.max(var37, var38);
      int var22 = var10000;
      Object[] var40 = new Object[]{12707221340346L};
      MeshDataConsumer var39 = var7;
      var39.kReturningVoid(var40);
      while (true) {
         byte var61 = 100;
         int var60 = var28;
         if (var60 <= var61) {
            float var29 = (float)((Math.PI * 2) * var28 / 100);
            double var41 = var29;
            float var30 = (float)Math.cos(var41);
            double var43 = var29;
            float var31 = (float)Math.sin(var43);
            float var32 = var3 + var26 * var30;
            float var33 = var4 + var26 * var31;
            float var34 = var3 + var27 * var30;
            float var35 = var4 + var27 * var31;
            Float var45 = var6;
            float var10004 = var45;
            Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
            var10007[3] = var10004;
            var10007[2] = var33;
            var10007[1] = var32;
            var10007[0] = var5;
            Object[] var47 = var10007;
            MeshDataConsumer var46 = var7;
            MeshDataConsumer var64 = var46.dReturningMeshDataConsumer(var47);
            Object[] var72 = new Object[]{null, 103875423078289L};
            var72[0] = var23;
            Object[] var49 = var72;
            MeshDataConsumer var48 = var64;
            var48.eReturningMeshDataConsumer(var49);
            Float var50 = var6;
            var10004 = var50;
            var10007 = new Object[]{null, null, null, null, 71574474611740L};
            var10007[3] = var10004;
            var10007[2] = var35;
            var10007[1] = var34;
            var10007[0] = var5;
            Object[] var52 = var10007;
            MeshDataConsumer var51 = var7;
            MeshDataConsumer var65 = var51.dReturningMeshDataConsumer(var52);
            Object[] var74 = new Object[]{null, 103875423078289L};
            var74[0] = var23;
            Object[] var54 = var74;
            MeshDataConsumer var53 = var65;
            var53.eReturningMeshDataConsumer(var54);
            var28++;
            int var62 = var22;
            if (var62 == 0) {
               break;
            }

            int var63 = var22;
            if (var63 != 0) {
               continue;
            }
         }

         Object[] var57 = new Object[]{PrimitiveMode.QUAD_STRIP, 1078475289577L};
         MeshDataConsumer var56 = var7;
         MeshDataConsumer var66 = var56.iReturningVoid(var57);
         Object[] var59 = new Object[]{80089257141227L};
         MeshDataConsumer var58 = var66;
         var58.hReturningMeshDataConsumer(var59);
         break;
      }
   }

   private static void lambda$circle$8(int var0, Matrix4f var1, float var2, float var3, float var4, Float var5, MeshDataConsumer var6) {
      long var10001 = 51195349462905L ^ 40688271257539L;
      var10001 = 51195349462905L ^ 122696004023141L;
      var10001 = 51195349462905L ^ 124204971190504L;
      var10001 = 51195349462905L ^ 112531954109586L;
      var10001 = 51195349462905L ^ 51079018224784L;
      var10001 = 51195349462905L ^ 85715856146723L;
      int var10000 = Event.cReturningInt();
      Object[] var10004 = new Object[]{null, 109378316676698L};
      var10004[0] = var0;
      Object[] var26 = var10004;
      int var22 = bReturningInt(var26);
      int var21 = var10000;
      Object[] var28 = new Object[]{12707221340346L};
      MeshDataConsumer var27 = var6;
      var27.kReturningVoid(var28);
      Float var29 = var5;
      float var65 = var29;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var65;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var31 = var10007;
      MeshDataConsumer var30 = var6;
      MeshDataConsumer var54 = var30.dReturningMeshDataConsumer(var31);
      var10004 = new Object[]{null, 103875423078289L};
      var10004[0] = var22;
      Object[] var33 = var10004;
      MeshDataConsumer var32 = var54;
      var32.eReturningMeshDataConsumer(var33);
      byte var55 = 12;
      int var35 = (int)(var4 * 2.0F);
      int var23 = Math.max(12, var35);
      while (true) {
         int var51 = var23;
         int var50 = var24;
         if (var50 < var51) {
            float var25 = (float)((Math.PI * 2) * var24 / var23);
            double var10002 = var2;
            double var36 = var25;
            float var63 = (float)(var10002 + Math.sin(var36) * var4);
            double var10003 = var3;
            double var38 = var25;
            float var64 = (float)(var10003 + Math.cos(var38) * var4);
            Float var40 = var5;
            float var67 = var40;
            var10007 = new Object[]{null, null, null, null, 71574474611740L};
            var10007[3] = var67;
            var10007[2] = var64;
            var10007[1] = var63;
            var10007[0] = var1;
            Object[] var42 = var10007;
            MeshDataConsumer var41 = var6;
            MeshDataConsumer var56 = var41.dReturningMeshDataConsumer(var42);
            var10004 = new Object[]{null, 103875423078289L};
            var10004[0] = var22;
            Object[] var44 = var10004;
            MeshDataConsumer var43 = var56;
            var43.eReturningMeshDataConsumer(var44);
            var24++;
            int var52 = var21;
            if (var52 == 0) {
               break;
            }

            int var53 = var21;
            if (var53 != 0) {
               continue;
            }
         }

         Object[] var47 = new Object[]{PrimitiveMode.TRIANGLES_FAN, 1078475289577L};
         MeshDataConsumer var46 = var6;
         MeshDataConsumer var57 = var46.iReturningVoid(var47);
         Object[] var49 = new Object[]{80089257141227L};
         MeshDataConsumer var48 = var57;
         var48.hReturningMeshDataConsumer(var49);
         break;
      }
   }

   private static void lambda$roundedRectGradient$7(
      Color var0, Color var1, Color var2, Color var3, float var4, float var5, float var6, float var7, Matrix4f var8, Float var9, MeshDataConsumer var10
   ) {
      long var10001 = 104269159069863L ^ 93852270983197L;
      var10001 = 104269159069863L ^ 34968366326971L;
      var10001 = 104269159069863L ^ 45318216437475L;
      var10001 = 104269159069863L ^ 740607033142L;
      var10001 = 104269159069863L ^ 24198744841036L;
      var10001 = 104269159069863L ^ 103551997905742L;
      var10001 = 104269159069863L ^ 114289114670267L;
      Object[] var33 = new Object[]{var0, 131814528038468L};
      int var27 = aReturningInt(var33);
      Object[] var34 = new Object[]{var1, 131814528038468L};
      int var28 = aReturningInt(var34);
      Object[] var35 = new Object[]{var2, 131814528038468L};
      int var29 = aReturningInt(var35);
      Object[] var36 = new Object[]{var3, 131814528038468L};
      int var30 = aReturningInt(var36);
      float var31 = var4 - var5;
      float var32 = var6 - var7;
      Object[] var38 = new Object[]{12707221340346L};
      MeshDataConsumer var37 = var10;
      MeshDataConsumer var10000 = var37.kReturningVoid(var38);
      Float var39 = var9;
      float var10004 = var39;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var5;
      var10007[0] = var8;
      Object[] var41 = var10007;
      MeshDataConsumer var40 = var10000;
      var10000 = var40.dReturningMeshDataConsumer(var41);
      Object[] var43 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var42 = var10000;
      var10000 = var42.bReturningMeshDataConsumer(var43);
      Object[] var45 = new Object[]{new float[]{var31, var32}, 62839871708188L};
      MeshDataConsumer var44 = var10000;
      var10000 = var44.bReturningMeshDataConsumer(var45);
      Object[] var102 = new Object[]{null, 103875423078289L};
      var102[0] = var27;
      Object[] var47 = var102;
      MeshDataConsumer var46 = var10000;
      var10000 = var46.eReturningMeshDataConsumer(var47);
      Float var48 = var9;
      var10004 = var48;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var4;
      var10007[0] = var8;
      Object[] var50 = var10007;
      MeshDataConsumer var49 = var10000;
      var10000 = var49.dReturningMeshDataConsumer(var50);
      Object[] var52 = new Object[]{new float[]{var31, 0.0F}, 62839871708188L};
      MeshDataConsumer var51 = var10000;
      var10000 = var51.bReturningMeshDataConsumer(var52);
      Object[] var54 = new Object[]{new float[]{var31, var32}, 62839871708188L};
      MeshDataConsumer var53 = var10000;
      var10000 = var53.bReturningMeshDataConsumer(var54);
      Object[] var104 = new Object[]{null, 103875423078289L};
      var104[0] = var28;
      Object[] var56 = var104;
      MeshDataConsumer var55 = var10000;
      var10000 = var55.eReturningMeshDataConsumer(var56);
      Float var57 = var9;
      var10004 = var57;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var7;
      var10007[1] = var4;
      var10007[0] = var8;
      Object[] var59 = var10007;
      MeshDataConsumer var58 = var10000;
      var10000 = var58.dReturningMeshDataConsumer(var59);
      Object[] var61 = new Object[]{new float[]{var31, var32}, 62839871708188L};
      MeshDataConsumer var60 = var10000;
      var10000 = var60.bReturningMeshDataConsumer(var61);
      Object[] var63 = new Object[]{new float[]{var31, var32}, 62839871708188L};
      MeshDataConsumer var62 = var10000;
      var10000 = var62.bReturningMeshDataConsumer(var63);
      Object[] var106 = new Object[]{null, 103875423078289L};
      var106[0] = var29;
      Object[] var65 = var106;
      MeshDataConsumer var64 = var10000;
      var10000 = var64.eReturningMeshDataConsumer(var65);
      Float var66 = var9;
      var10004 = var66;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var7;
      var10007[1] = var5;
      var10007[0] = var8;
      Object[] var68 = var10007;
      MeshDataConsumer var67 = var10000;
      var10000 = var67.dReturningMeshDataConsumer(var68);
      Object[] var70 = new Object[]{new float[]{0.0F, var32}, 62839871708188L};
      MeshDataConsumer var69 = var10000;
      var10000 = var69.bReturningMeshDataConsumer(var70);
      Object[] var72 = new Object[]{new float[]{var31, var32}, 62839871708188L};
      MeshDataConsumer var71 = var10000;
      var10000 = var71.bReturningMeshDataConsumer(var72);
      Object[] var108 = new Object[]{null, 103875423078289L};
      var108[0] = var30;
      Object[] var74 = var108;
      MeshDataConsumer var73 = var10000;
      var10000 = var73.eReturningMeshDataConsumer(var74);
      Object[] var76 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var75 = var10000;
      var10000 = var75.iReturningVoid(var76);
      Object[] var78 = new Object[]{80089257141227L};
      MeshDataConsumer var77 = var10000;
      var77.hReturningMeshDataConsumer(var78);
   }

   private static void lambda$roundedRect$6(Color var0, float var1, float var2, float var3, float var4, Matrix4f var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 106430266984219L ^ 117933815351201L;
      var10001 = 106430266984219L ^ 37196587571975L;
      var10001 = 106430266984219L ^ 68948652474506L;
      var10001 = 106430266984219L ^ 44096462333168L;
      var10001 = 106430266984219L ^ 105789882840306L;
      var10001 = 106430266984219L ^ 4083003418945L;
      var10001 = 106430266984219L ^ 98866766207751L;
      Color var27 = var0;
      int var10000 = var27.getRGB();
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var10000;
      Object[] var28 = var10003;
      int var24 = bReturningInt(var28);
      float var25 = var1 - var2;
      float var26 = var3 - var4;
      Object[] var30 = new Object[]{12707221340346L};
      MeshDataConsumer var29 = var7;
      MeshDataConsumer var71 = var29.kReturningVoid(var30);
      Float var31 = var6;
      float var10004 = var31;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var5;
      Object[] var33 = var10007;
      MeshDataConsumer var32 = var71;
      MeshDataConsumer var72 = var32.dReturningMeshDataConsumer(var33);
      Object[] var35 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var34 = var72;
      MeshDataConsumer var73 = var34.bReturningMeshDataConsumer(var35);
      Object[] var37 = new Object[]{new float[]{var25, var26}, 62839871708188L};
      MeshDataConsumer var36 = var73;
      MeshDataConsumer var74 = var36.bReturningMeshDataConsumer(var37);
      Object[] var95 = new Object[]{null, 103875423078289L};
      var95[0] = var24;
      Object[] var39 = var95;
      MeshDataConsumer var38 = var74;
      MeshDataConsumer var75 = var38.eReturningMeshDataConsumer(var39);
      Float var40 = var6;
      var10004 = var40;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var1;
      var10007[0] = var5;
      Object[] var42 = var10007;
      MeshDataConsumer var41 = var75;
      MeshDataConsumer var76 = var41.dReturningMeshDataConsumer(var42);
      Object[] var44 = new Object[]{new float[]{var25, 0.0F}, 62839871708188L};
      MeshDataConsumer var43 = var76;
      MeshDataConsumer var77 = var43.bReturningMeshDataConsumer(var44);
      Object[] var46 = new Object[]{new float[]{var25, var26}, 62839871708188L};
      MeshDataConsumer var45 = var77;
      MeshDataConsumer var78 = var45.bReturningMeshDataConsumer(var46);
      Object[] var97 = new Object[]{null, 103875423078289L};
      var97[0] = var24;
      Object[] var48 = var97;
      MeshDataConsumer var47 = var78;
      MeshDataConsumer var79 = var47.eReturningMeshDataConsumer(var48);
      Float var49 = var6;
      var10004 = var49;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var4;
      var10007[1] = var1;
      var10007[0] = var5;
      Object[] var51 = var10007;
      MeshDataConsumer var50 = var79;
      MeshDataConsumer var80 = var50.dReturningMeshDataConsumer(var51);
      Object[] var53 = new Object[]{new float[]{var25, var26}, 62839871708188L};
      MeshDataConsumer var52 = var80;
      MeshDataConsumer var81 = var52.bReturningMeshDataConsumer(var53);
      Object[] var55 = new Object[]{new float[]{var25, var26}, 62839871708188L};
      MeshDataConsumer var54 = var81;
      MeshDataConsumer var82 = var54.bReturningMeshDataConsumer(var55);
      Object[] var99 = new Object[]{null, 103875423078289L};
      var99[0] = var24;
      Object[] var57 = var99;
      MeshDataConsumer var56 = var82;
      MeshDataConsumer var83 = var56.eReturningMeshDataConsumer(var57);
      Float var58 = var6;
      var10004 = var58;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var4;
      var10007[1] = var2;
      var10007[0] = var5;
      Object[] var60 = var10007;
      MeshDataConsumer var59 = var83;
      MeshDataConsumer var84 = var59.dReturningMeshDataConsumer(var60);
      Object[] var62 = new Object[]{new float[]{0.0F, var26}, 62839871708188L};
      MeshDataConsumer var61 = var84;
      MeshDataConsumer var85 = var61.bReturningMeshDataConsumer(var62);
      Object[] var64 = new Object[]{new float[]{var25, var26}, 62839871708188L};
      MeshDataConsumer var63 = var85;
      MeshDataConsumer var86 = var63.bReturningMeshDataConsumer(var64);
      Object[] var101 = new Object[]{null, 103875423078289L};
      var101[0] = var24;
      Object[] var66 = var101;
      MeshDataConsumer var65 = var86;
      MeshDataConsumer var87 = var65.eReturningMeshDataConsumer(var66);
      Object[] var68 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var67 = var87;
      MeshDataConsumer var88 = var67.iReturningVoid(var68);
      Object[] var70 = new Object[]{80089257141227L};
      MeshDataConsumer var69 = var88;
      var69.hReturningMeshDataConsumer(var70);
   }

   private static void lambda$gradientLine$5(
      Color var0, Color var1, float var2, float var3, float var4, float var5, float var6, Matrix4f var7, Float var8, MeshDataConsumer var9
   ) {
      long var10001 = 110720034044960L ^ 122310554451098L;
      var10001 = 110720034044960L ^ 41419581300796L;
      var10001 = 110720034044960L ^ 64640968948657L;
      var10001 = 110720034044960L ^ 48809081348043L;
      var10001 = 110720034044960L ^ 110260910985161L;
      var10001 = 110720034044960L ^ 8562486694522L;
      int var10000 = Event.bReturningInt();
      Color var40 = var0;
      int var99 = var40.getRGB();
      Object[] var10004 = new Object[]{null, 109378316676698L};
      var10004[0] = var99;
      Object[] var41 = var10004;
      int var25 = bReturningInt(var41);
      int var24 = var10000;
      Color var42 = var1;
      var10000 = var42.getRGB();
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var10000;
      Object[] var43 = var10003;
      int var26 = bReturningInt(var43);
      float var27 = var2 - var3;
      float var28 = var4 - var5;
      double var44 = var27 * var27 + var28 * var28;
      float var29 = (float)Math.sqrt(var44);
      int var80 = var24;
      float var79 = 0.0F;
      float var78 = var29;
      float var76 = var78;
      float var77 = var79;
      float var74 = var78;
      float var75 = var79;
      if (var80 == 0) {
         float var111;
         int var81 = (var111 = var74 - var75) == 0.0F ? 0 : (var111 < 0.0F ? -1 : 1);
         if (!((var81) != 0)) {
            return;
         }

         float var83 = -var28 / var29;
         var77 = var6 / 2.0F;
         var76 = var83;
      }

      float var30 = var76 * var77;
      float var31 = var27 / var29 * (var6 / 2.0F);
      float var32 = var3 - var30;
      float var33 = var5 - var31;
      float var34 = var3 + var30;
      float var35 = var5 + var31;
      float var36 = var2 - var30;
      float var37 = var4 - var31;
      float var38 = var2 + var30;
      float var39 = var4 + var31;
      Object[] var49 = new Object[]{12707221340346L};
      MeshDataConsumer var48 = var9;
      MeshDataConsumer var84 = var48.kReturningVoid(var49);
      Float var50 = var8;
      float var100 = var50;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var100;
      var10007[2] = var33;
      var10007[1] = var32;
      var10007[0] = var7;
      Object[] var52 = var10007;
      MeshDataConsumer var51 = var84;
      MeshDataConsumer var85 = var51.dReturningMeshDataConsumer(var52);
      var10004 = new Object[]{null, 103875423078289L};
      var10004[0] = var25;
      Object[] var54 = var10004;
      MeshDataConsumer var53 = var85;
      MeshDataConsumer var86 = var53.eReturningMeshDataConsumer(var54);
      Float var55 = var8;
      float var102 = var55;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var102;
      var10007[2] = var35;
      var10007[1] = var34;
      var10007[0] = var7;
      Object[] var57 = var10007;
      MeshDataConsumer var56 = var86;
      MeshDataConsumer var87 = var56.dReturningMeshDataConsumer(var57);
      var10004 = new Object[]{null, 103875423078289L};
      var10004[0] = var25;
      Object[] var59 = var10004;
      MeshDataConsumer var58 = var87;
      MeshDataConsumer var88 = var58.eReturningMeshDataConsumer(var59);
      Float var60 = var8;
      float var104 = var60;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var104;
      var10007[2] = var39;
      var10007[1] = var38;
      var10007[0] = var7;
      Object[] var62 = var10007;
      MeshDataConsumer var61 = var88;
      MeshDataConsumer var89 = var61.dReturningMeshDataConsumer(var62);
      var10004 = new Object[]{null, 103875423078289L};
      var10004[0] = var26;
      Object[] var64 = var10004;
      MeshDataConsumer var63 = var89;
      MeshDataConsumer var90 = var63.eReturningMeshDataConsumer(var64);
      Float var65 = var8;
      float var106 = var65;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var106;
      var10007[2] = var37;
      var10007[1] = var36;
      var10007[0] = var7;
      Object[] var67 = var10007;
      MeshDataConsumer var66 = var90;
      MeshDataConsumer var91 = var66.dReturningMeshDataConsumer(var67);
      var10004 = new Object[]{null, 103875423078289L};
      var10004[0] = var26;
      Object[] var69 = var10004;
      MeshDataConsumer var68 = var91;
      MeshDataConsumer var92 = var68.eReturningMeshDataConsumer(var69);
      Object[] var71 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var70 = var92;
      MeshDataConsumer var93 = var70.iReturningVoid(var71);
      Object[] var73 = new Object[]{80089257141227L};
      MeshDataConsumer var72 = var93;
      var72.hReturningMeshDataConsumer(var73);
   }

   private static void lambda$line$4(int var0, Matrix4f var1, float var2, float var3, float var4, float var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 39234262826877L ^ 44119265542087L;
      var10001 = 39234262826877L ^ 108535089079137L;
      var10001 = 39234262826877L ^ 138364820781292L;
      var10001 = 39234262826877L ^ 118170857020566L;
      var10001 = 39234262826877L ^ 38851912305812L;
      var10001 = 39234262826877L ^ 71281155920167L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var23 = var10003;
      int var22 = bReturningInt(var23);
      Object[] var25 = new Object[]{12707221340346L};
      MeshDataConsumer var24 = var7;
      MeshDataConsumer var10000 = var24.kReturningVoid(var25);
      Float var26 = var6;
      float var10004 = var26;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var28 = var10007;
      MeshDataConsumer var27 = var10000;
      var10000 = var27.dReturningMeshDataConsumer(var28);
      Object[] var50 = new Object[]{null, 103875423078289L};
      var50[0] = var22;
      Object[] var30 = var50;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.eReturningMeshDataConsumer(var30);
      Float var31 = var6;
      var10004 = var31;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var33 = var10007;
      MeshDataConsumer var32 = var10000;
      var10000 = var32.dReturningMeshDataConsumer(var33);
      Object[] var52 = new Object[]{null, 103875423078289L};
      var52[0] = var22;
      Object[] var35 = var52;
      MeshDataConsumer var34 = var10000;
      var10000 = var34.eReturningMeshDataConsumer(var35);
      Object[] var37 = new Object[]{PrimitiveMode.LINES, 1078475289577L};
      MeshDataConsumer var36 = var10000;
      var10000 = var36.iReturningVoid(var37);
      Object[] var39 = new Object[]{80089257141227L};
      MeshDataConsumer var38 = var10000;
      var38.hReturningMeshDataConsumer(var39);
   }

   private static void lambda$rectOutline$3(int var0, Matrix4f var1, float var2, float var3, float var4, float var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 40007939905275L ^ 52697946510913L;
      var10001 = 40007939905275L ^ 111581776677607L;
      var10001 = 40007939905275L ^ 134254012551530L;
      var10001 = 40007939905275L ^ 119521032746256L;
      var10001 = 40007939905275L ^ 40235407320338L;
      var10001 = 40007939905275L ^ 78175061014689L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var23 = var10003;
      int var22 = bReturningInt(var23);
      Object[] var25 = new Object[]{12707221340346L};
      MeshDataConsumer var24 = var7;
      MeshDataConsumer var10000 = var24.kReturningVoid(var25);
      Float var26 = var6;
      float var10004 = var26;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var28 = var10007;
      MeshDataConsumer var27 = var10000;
      var10000 = var27.dReturningMeshDataConsumer(var28);
      Object[] var92 = new Object[]{null, 103875423078289L};
      var92[0] = var22;
      Object[] var30 = var92;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.eReturningMeshDataConsumer(var30);
      Float var31 = var6;
      var10004 = var31;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var33 = var10007;
      MeshDataConsumer var32 = var10000;
      var10000 = var32.dReturningMeshDataConsumer(var33);
      Object[] var94 = new Object[]{null, 103875423078289L};
      var94[0] = var22;
      Object[] var35 = var94;
      MeshDataConsumer var34 = var10000;
      var10000 = var34.eReturningMeshDataConsumer(var35);
      Float var36 = var6;
      var10004 = var36;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var38 = var10007;
      MeshDataConsumer var37 = var10000;
      var10000 = var37.dReturningMeshDataConsumer(var38);
      Object[] var96 = new Object[]{null, 103875423078289L};
      var96[0] = var22;
      Object[] var40 = var96;
      MeshDataConsumer var39 = var10000;
      var10000 = var39.eReturningMeshDataConsumer(var40);
      Float var41 = var6;
      var10004 = var41;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var43 = var10007;
      MeshDataConsumer var42 = var10000;
      var10000 = var42.dReturningMeshDataConsumer(var43);
      Object[] var98 = new Object[]{null, 103875423078289L};
      var98[0] = var22;
      Object[] var45 = var98;
      MeshDataConsumer var44 = var10000;
      var10000 = var44.eReturningMeshDataConsumer(var45);
      Float var46 = var6;
      var10004 = var46;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var48 = var10007;
      MeshDataConsumer var47 = var10000;
      var10000 = var47.dReturningMeshDataConsumer(var48);
      Object[] var100 = new Object[]{null, 103875423078289L};
      var100[0] = var22;
      Object[] var50 = var100;
      MeshDataConsumer var49 = var10000;
      var10000 = var49.eReturningMeshDataConsumer(var50);
      Float var51 = var6;
      var10004 = var51;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var53 = var10007;
      MeshDataConsumer var52 = var10000;
      var10000 = var52.dReturningMeshDataConsumer(var53);
      Object[] var102 = new Object[]{null, 103875423078289L};
      var102[0] = var22;
      Object[] var55 = var102;
      MeshDataConsumer var54 = var10000;
      var10000 = var54.eReturningMeshDataConsumer(var55);
      Float var56 = var6;
      var10004 = var56;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var58 = var10007;
      MeshDataConsumer var57 = var10000;
      var10000 = var57.dReturningMeshDataConsumer(var58);
      Object[] var104 = new Object[]{null, 103875423078289L};
      var104[0] = var22;
      Object[] var60 = var104;
      MeshDataConsumer var59 = var10000;
      var10000 = var59.eReturningMeshDataConsumer(var60);
      Float var61 = var6;
      var10004 = var61;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var63 = var10007;
      MeshDataConsumer var62 = var10000;
      var10000 = var62.dReturningMeshDataConsumer(var63);
      Object[] var106 = new Object[]{null, 103875423078289L};
      var106[0] = var22;
      Object[] var65 = var106;
      MeshDataConsumer var64 = var10000;
      var10000 = var64.eReturningMeshDataConsumer(var65);
      Object[] var67 = new Object[]{PrimitiveMode.LINES, 1078475289577L};
      MeshDataConsumer var66 = var10000;
      var10000 = var66.iReturningVoid(var67);
      Object[] var69 = new Object[]{80089257141227L};
      MeshDataConsumer var68 = var10000;
      var68.hReturningMeshDataConsumer(var69);
   }

   private static void lambda$rectGradient$2(
      int var0, int var1, int var2, int var3, Matrix4f var4, float var5, float var6, float var7, float var8, Float var9, MeshDataConsumer var10
   ) {
      long var10001 = 140057305176987L ^ 128569854810913L;
      var10001 = 140057305176987L ^ 68689861674887L;
      var10001 = 140057305176987L ^ 36390190308362L;
      var10001 = 140057305176987L ^ 61257412819056L;
      var10001 = 140057305176987L ^ 140302552574066L;
      var10001 = 140057305176987L ^ 30903335810497L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var29 = var10003;
      int var25 = bReturningInt(var29);
      var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var1;
      Object[] var30 = var10003;
      int var26 = bReturningInt(var30);
      var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var2;
      Object[] var31 = var10003;
      int var27 = bReturningInt(var31);
      var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var3;
      Object[] var32 = var10003;
      int var28 = bReturningInt(var32);
      Object[] var34 = new Object[]{12707221340346L};
      MeshDataConsumer var33 = var10;
      MeshDataConsumer var10000 = var33.kReturningVoid(var34);
      Float var35 = var9;
      float var10004 = var35;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var5;
      var10007[0] = var4;
      Object[] var37 = var10007;
      MeshDataConsumer var36 = var10000;
      var10000 = var36.dReturningMeshDataConsumer(var37);
      Object[] var76 = new Object[]{null, 103875423078289L};
      var76[0] = var25;
      Object[] var39 = var76;
      MeshDataConsumer var38 = var10000;
      var10000 = var38.eReturningMeshDataConsumer(var39);
      Float var40 = var9;
      var10004 = var40;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var7;
      var10007[0] = var4;
      Object[] var42 = var10007;
      MeshDataConsumer var41 = var10000;
      var10000 = var41.dReturningMeshDataConsumer(var42);
      Object[] var78 = new Object[]{null, 103875423078289L};
      var78[0] = var26;
      Object[] var44 = var78;
      MeshDataConsumer var43 = var10000;
      var10000 = var43.eReturningMeshDataConsumer(var44);
      Float var45 = var9;
      var10004 = var45;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var8;
      var10007[1] = var7;
      var10007[0] = var4;
      Object[] var47 = var10007;
      MeshDataConsumer var46 = var10000;
      var10000 = var46.dReturningMeshDataConsumer(var47);
      Object[] var80 = new Object[]{null, 103875423078289L};
      var80[0] = var27;
      Object[] var49 = var80;
      MeshDataConsumer var48 = var10000;
      var10000 = var48.eReturningMeshDataConsumer(var49);
      Float var50 = var9;
      var10004 = var50;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var8;
      var10007[1] = var5;
      var10007[0] = var4;
      Object[] var52 = var10007;
      MeshDataConsumer var51 = var10000;
      var10000 = var51.dReturningMeshDataConsumer(var52);
      Object[] var82 = new Object[]{null, 103875423078289L};
      var82[0] = var28;
      Object[] var54 = var82;
      MeshDataConsumer var53 = var10000;
      var10000 = var53.eReturningMeshDataConsumer(var54);
      Object[] var56 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var55 = var10000;
      var10000 = var55.iReturningVoid(var56);
      Object[] var58 = new Object[]{80089257141227L};
      MeshDataConsumer var57 = var10000;
      var57.hReturningMeshDataConsumer(var58);
   }

   private static void lambda$rect$1(int var0, Matrix4f var1, float var2, float var3, float var4, float var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 105334817124763L ^ 92649108369697L;
      var10001 = 105334817124763L ^ 33902718168455L;
      var10001 = 105334817124763L ^ 1873912985098L;
      var10001 = 105334817124763L ^ 25400837378672L;
      var10001 = 105334817124763L ^ 104686446805618L;
      var10001 = 105334817124763L ^ 66759695359937L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var23 = var10003;
      int var22 = bReturningInt(var23);
      Object[] var25 = new Object[]{12707221340346L};
      MeshDataConsumer var24 = var7;
      MeshDataConsumer var10000 = var24.kReturningVoid(var25);
      Float var26 = var6;
      float var10004 = var26;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var28 = var10007;
      MeshDataConsumer var27 = var10000;
      var10000 = var27.dReturningMeshDataConsumer(var28);
      Object[] var64 = new Object[]{null, 103875423078289L};
      var64[0] = var22;
      Object[] var30 = var64;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.eReturningMeshDataConsumer(var30);
      Float var31 = var6;
      var10004 = var31;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var33 = var10007;
      MeshDataConsumer var32 = var10000;
      var10000 = var32.dReturningMeshDataConsumer(var33);
      Object[] var66 = new Object[]{null, 103875423078289L};
      var66[0] = var22;
      Object[] var35 = var66;
      MeshDataConsumer var34 = var10000;
      var10000 = var34.eReturningMeshDataConsumer(var35);
      Float var36 = var6;
      var10004 = var36;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var38 = var10007;
      MeshDataConsumer var37 = var10000;
      var10000 = var37.dReturningMeshDataConsumer(var38);
      Object[] var68 = new Object[]{null, 103875423078289L};
      var68[0] = var22;
      Object[] var40 = var68;
      MeshDataConsumer var39 = var10000;
      var10000 = var39.eReturningMeshDataConsumer(var40);
      Float var41 = var6;
      var10004 = var41;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var43 = var10007;
      MeshDataConsumer var42 = var10000;
      var10000 = var42.dReturningMeshDataConsumer(var43);
      Object[] var70 = new Object[]{null, 103875423078289L};
      var70[0] = var22;
      Object[] var45 = var70;
      MeshDataConsumer var44 = var10000;
      var10000 = var44.eReturningMeshDataConsumer(var45);
      Object[] var47 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var46 = var10000;
      var10000 = var46.iReturningVoid(var47);
      Object[] var49 = new Object[]{80089257141227L};
      MeshDataConsumer var48 = var10000;
      var48.hReturningMeshDataConsumer(var49);
   }

   private static void lambda$triangle$0(
      int var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, float var7, Float var8, MeshDataConsumer var9
   ) {
      long var10001 = 107048729137943L ^ 117452727079853L;
      var10001 = 107048729137943L ^ 35478616870667L;
      var10001 = 107048729137943L ^ 69429635896454L;
      var10001 = 107048729137943L ^ 45677023441148L;
      var10001 = 107048729137943L ^ 107370480640254L;
      var10001 = 107048729137943L ^ 2365030628685L;
      Object[] var10003 = new Object[]{null, 109378316676698L};
      var10003[0] = var0;
      Object[] var25 = var10003;
      int var24 = bReturningInt(var25);
      Object[] var27 = new Object[]{12707221340346L};
      MeshDataConsumer var26 = var9;
      MeshDataConsumer var10000 = var26.kReturningVoid(var27);
      Float var28 = var8;
      float var10004 = var28;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var30 = var10007;
      MeshDataConsumer var29 = var10000;
      var10000 = var29.dReturningMeshDataConsumer(var30);
      Object[] var59 = new Object[]{null, 103875423078289L};
      var59[0] = var24;
      Object[] var32 = var59;
      MeshDataConsumer var31 = var10000;
      var10000 = var31.eReturningMeshDataConsumer(var32);
      Float var33 = var8;
      var10004 = var33;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var5;
      var10007[1] = var4;
      var10007[0] = var1;
      Object[] var35 = var10007;
      MeshDataConsumer var34 = var10000;
      var10000 = var34.dReturningMeshDataConsumer(var35);
      Object[] var61 = new Object[]{null, 103875423078289L};
      var61[0] = var24;
      Object[] var37 = var61;
      MeshDataConsumer var36 = var10000;
      var10000 = var36.eReturningMeshDataConsumer(var37);
      Float var38 = var8;
      var10004 = var38;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var7;
      var10007[1] = var6;
      var10007[0] = var1;
      Object[] var40 = var10007;
      MeshDataConsumer var39 = var10000;
      var10000 = var39.dReturningMeshDataConsumer(var40);
      Object[] var63 = new Object[]{null, 103875423078289L};
      var63[0] = var24;
      Object[] var42 = var63;
      MeshDataConsumer var41 = var10000;
      var10000 = var41.eReturningMeshDataConsumer(var42);
      Object[] var44 = new Object[]{PrimitiveMode.TRIANGLES, 1078475289577L};
      MeshDataConsumer var43 = var10000;
      var10000 = var43.iReturningVoid(var44);
      Object[] var46 = new Object[]{80089257141227L};
      MeshDataConsumer var45 = var10000;
      var45.hReturningMeshDataConsumer(var46);
   }

   static {

      {

      aReturningVoid();
      Cipher var0;
      Cipher var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var1 = 1; var1 < 8; var1++) {
         var10003[var1] = (byte)(128485200379706L << var1 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var6 = new long[16];
      String var4 = "Ê\u001b£\u0004oé\u000bÏ\u0010\u0017Ào\u008a\u0087ÿß³¹\tï\u0086\u008c\u0000tÓ\f÷ÕÝµ\u0012ûÉÝh>r\r\u008fË\u0084\u0084yH°j\u001fÖ@Á\u0019Äñ:&©^\u0012\u00007\u009aÛç¡9W5ío\u0001(]ÖfÚ\"tÃ«°¾sí8\u0016\u0018\u0094ÇY\u0097L¤\u0091ÛRô½òÕI\n\u0084\u0017ß\u00ad\u0093ÇK{·Hx";
      int var5 = "Ê\u001b£\u0004oé\u000bÏ\u0010\u0017Ào\u008a\u0087ÿß³¹\tï\u0086\u008c\u0000tÓ\f÷ÕÝµ\u0012ûÉÝh>r\r\u008fË\u0084\u0084yH°j\u001fÖ@Á\u0019Äñ:&©^\u0012\u00007\u009aÛç¡9W5ío\u0001(]ÖfÚ\"tÃ«°¾sí8\u0016\u0018\u0094ÇY\u0097L¤\u0091ÛRô½òÕI\n\u0084\u0017ß\u00ad\u0093ÇK{·Hx"
         .length();
      label23:
      while (true) {
         int var10001 = var2;
         var2 += 8;
         byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
         long[] var16 = var6;
         var10001 = var3++;
         long var19 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         
            long var8 = var19;
            byte[] var10 = var0.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var23 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var21) {
               case 0:
                  var16[var10001] = var23;
                  if (var2 >= var5) {
                     f = var6;
                     g = new Integer[16];
                     a = new AtomicReference();
                     Supplier var13 = invokeBinding94();
                     b = ThreadLocal.withInitial(var13);
                     c = new Matrix4f();
                     Supplier var14 = invokeBinding95();
                     d = ThreadLocal.withInitial(var14);
                     break;
                  }
                  break;
               default:
                  var16[var10001] = var23;
                  if (var2 < var5) {
                     continue label23;
                  }

                  var4 = "|ðÅÉ\u0095¯Ù\u0005ÀZ¼\nÀ\u0084ëX";
                  var5 = "|ðÅÉ\u0095¯Ù\u0005ÀZ¼\nÀ\u0084ëX".length();
                  var2 = 0;
            }

            int var18 = var2;
            var2 += 8;
            var7 = var4.substring(var18, var2).getBytes("ISO-8859-1");
            var16 = var6;
            var10001 = var3++;
            var19 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var21 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 29375;
      if (g[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = f[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])h.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dv", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         g[var3] = var15;
      }

      return g[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dv_C0206",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dv" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = j[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = i[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 16;
            yield var15;
         }
         case 1 -> {
            byte var16 = 62;
            yield var16;
         }
         case 2 -> {
            byte var17 = 47;
            yield var17;
         }
         case 3 -> {
            byte var18 = 53;
            yield var18;
         }
         case 4 -> {
            byte var19 = 46;
            yield var19;
         }
         case 5 -> {
            byte var20 = 44;
            yield var20;
         }
         case 6 -> {
            byte var21 = 18;
            yield var21;
         }
         case 7 -> {
            byte var22 = 32;
            yield var22;
         }
         case 8 -> {
            byte var23 = 33;
            yield var23;
         }
         case 9 -> {
            byte var24 = 9;
            yield var24;
         }
         case 10 -> {
            byte var25 = 22;
            yield var25;
         }
         case 11 -> {
            byte var26 = 2;
            yield var26;
         }
         case 12 -> {
            byte var27 = 24;
            yield var27;
         }
         case 13 -> {
            byte var28 = 34;
            yield var28;
         }
         case 14 -> {
            byte var29 = 59;
            yield var29;
         }
         case 15 -> {
            byte var30 = 13;
            yield var30;
         }
         case 16 -> {
            byte var31 = 58;
            yield var31;
         }
         case 17 -> {
            byte var32 = 57;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 63;
            yield var34;
         }
         case 20 -> {
            byte var35 = 51;
            yield var35;
         }
         case 21 -> {
            byte var36 = 36;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 19;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 11;
            yield var40;
         }
         case 26 -> {
            byte var41 = 45;
            yield var41;
         }
         case 27 -> {
            byte var42 = 61;
            yield var42;
         }
         case 28 -> {
            byte var43 = 54;
            yield var43;
         }
         case 29 -> {
            byte var44 = 3;
            yield var44;
         }
         case 30 -> {
            byte var45 = 0;
            yield var45;
         }
         case 31 -> {
            byte var46 = 35;
            yield var46;
         }
         case 32 -> {
            byte var47 = 1;
            yield var47;
         }
         case 33 -> {
            byte var48 = 56;
            yield var48;
         }
         case 34 -> {
            byte var49 = 12;
            yield var49;
         }
         case 35 -> {
            byte var50 = 26;
            yield var50;
         }
         case 36 -> {
            byte var51 = 5;
            yield var51;
         }
         case 37 -> {
            byte var52 = 20;
            yield var52;
         }
         case 38 -> {
            byte var53 = 43;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 52;
            yield var55;
         }
         case 41 -> {
            byte var56 = 6;
            yield var56;
         }
         case 42 -> {
            byte var57 = 29;
            yield var57;
         }
         case 43 -> {
            byte var58 = 48;
            yield var58;
         }
         case 44 -> {
            byte var59 = 7;
            yield var59;
         }
         case 45 -> {
            byte var60 = 4;
            yield var60;
         }
         case 46 -> {
            byte var61 = 41;
            yield var61;
         }
         case 47 -> {
            byte var62 = 27;
            yield var62;
         }
         case 48 -> {
            byte var63 = 17;
            yield var63;
         }
         case 49 -> {
            byte var64 = 30;
            yield var64;
         }
         case 50 -> {
            byte var65 = 40;
            yield var65;
         }
         case 51 -> {
            byte var66 = 31;
            yield var66;
         }
         case 52 -> {
            byte var67 = 50;
            yield var67;
         }
         case 53 -> {
            byte var68 = 55;
            yield var68;
         }
         case 54 -> {
            byte var69 = 8;
            yield var69;
         }
         case 55 -> {
            byte var70 = 10;
            yield var70;
         }
         case 56 -> {
            byte var71 = 42;
            yield var71;
         }
         case 57 -> {
            byte var72 = 28;
            yield var72;
         }
         case 58 -> {
            byte var73 = 25;
            yield var73;
         }
         case 59 -> {
            byte var74 = 14;
            yield var74;
         }
         case 60 -> {
            byte var75 = 21;
            yield var75;
         }
         case 61 -> {
            byte var76 = 15;
            yield var76;
         }
         case 62 -> {
            byte var77 = 37;
            yield var77;
         }
         default -> 60;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            j[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      i[0] = "a m\u0011'|w hK4k`kkM8\u007fq,|Zsj1";
      i[1] = "h?Eyd0\u001d\u001fNvu\u007f|\u0011E}q%\b";
      i[2] = void.class;
      j[2] = "java/lang/Void";
      i[3] = " [\r_H!6[\b\u0005[6!\u0010\u000b\u0003W\"0W\u001c\u0014\u001c52";
      i[4] = "'\u000e=V&+R.6Y7d3 =R3>G";
      i[5] = "Q\u0017\u001bX1}G\u0017\u001e\u0002\"jP\\\u001d\u0004.~A\u001b\n\u0013eod";
      i[6] = "ay?\u0001/m\u0014Y4\u000e>\"uW?\u0005:x\u0001";
      i[7] = "\u000fQr(^\t\rO;PQ\u0005\u0014Lg5P";
      i[8] = double.class;
      j[8] = "java/lang/Double";
      i[9] = "*|f\n\u0007\u0007_\\m\u0005\u0016H>Rf\u000e\u0012\u0012J";
      i[10] = "m\u001ft-R&{\u001fqwA1lTrqM%}\u0013ef\u00065J";
      i[11] = "\t?eW\u0004\u0007|\u001fnX\u0015H\u001d\u0011eS\u0011\u0012i";
      i[12] = "YI8^RtOI=\u0004AcX\u0002>\u0002MwIE)\u0015\u0006`W";
      i[13] = "/12LnSZ\u00119C\u007f\u001c;\u001f2H{FO";
      i[14] = "Q\u0003Gf;\u001aG\u0003B<(\rPHA:$\u0019A\u000fV-o\u000b[";
      i[15] = "h2\u0001Rlu\u001d\u0012\n]}:|\u001c\u0001Vy`\b";
      i[16] = "a\u001cr$\u0005\u0019\u0014<y+\u0014Vu2r \u0010\f\u0001";
      i[17] = "\u0005.X5:\u001cp\u000eS:+S\u0011\u0000X1/\te";
      i[18] = "?(\u001f\u0016[tJ\b\u0014\u0019J;+\u0006\u001f\u0012Na_";
      i[19] = int.class;
      j[19] = "java/lang/Integer";
      i[20] = "Y\u0012S.\u001d\u007f,2X!\f0M<S*\bj9";
      i[21] = "HA\u0017\u001f\tS=a\u001c\u0010\u0018\u001c\\o\u0017\u001b\u001cF(";
      i[22] = ",i\u0007\u000b\bK'f\u0016D`K)i\u0005";
      i[23] = float.class;
      j[23] = "java/lang/Float";
      i[24] = "',\u000eb\u000fcR\f\u0005m\u001e,3\u0002\u000ef\u001avG";
      i[25] = "+dm\bD|^Df\u0007U3?Jm\fQiK";
      i[26] = "{NNF?!\u000enEI.no`NB*4\u001b";
      i[27] = "K\u0014\u0005E\u001d(>4\u000eJ\fg_:\u0005A\b=+";
      i[28] = "Sw\u0013sK{QiZ\u0010@`Nl\fiG";
      i[29] = "o\u0014\u0006V\r]d\u001b\u0017\u0019wYw\u0010\u0011So^f\u0014\u001c";
      i[30] = "('\u0014&]R#(\u0005i<\\(#\u00013";
      i[31] = "MS;!r:[S>{a-L\u0018=}m9]_*j&.Y";
      i[32] = "\u001eGYqL\u000bkgR~]D\niYuY\u001e~";
      i[33] = "a1p-^1w1uwM&`zvqA2q=af\n%k";
      i[34] = "JunxJ'?Uew[h^[n|_2*";
      i[35] = "{J\u0010\u0016(\nf_H4i\u0007~Y";
      i[36] = "4iZ,\r\u0012AIQ#\u001c] GZ(\u0018\u0007T";
      i[37] = "\u0014\u0010\u000279.a0\t8(a\u0000>\u00023,;t";
      i[38] = "4!H\u001fLO\"!ME_X5jNCSL$-YT\u0018[5";
      i[39] = "g\u0013)L;0\u00123\"C*\u007fs=)H.%\u0007";
      i[40] = "\u000e\b\fuM*{(\u0007z\\e\u001a&\fqX?n";
      i[41] = "2(lFhp9'}\t\u000b},!";
      i[42] = "\fh}\u0011ty\u001ahxKgn\r#{Mkz\u001cdlZ h-";
      i[43] = "\u000e\u000b\u0014.`\u000f\u0005\u0004\u0005a\u0003\u0002\u0010\t\n\n6\u0000\u0001\u001a\u0016&!\r";
      i[44] = "d9-`6\u0005d9:<:\n~r:\":\u001fy\u0003kzh";
      i[45] = "\u0010G\u0002IB2\u000eO\u0018\u0006-5\bG\rd\u00054\u000e";
      i[46] = "E\u001fx|=\u001a[\u0017b3Z\u001bJ\foi|\u001d";
      i[47] = "\u0010DboW\u0002edi`FM\u0004jbkB\u0017p";
      i[48] = boolean.class;
      j[48] = "java/lang/Boolean";
      i[49] = "+@M\u0018c\u00115HWW+\u0011/BO\u0010\"\norN\t=\b(DI";
      i[50] = "hc)Tk\u0019\u001dC\"[zV|M)P~\f\b";
      i[51] = "\u0017\t\u000f>:&b)\u00041+i\u0003'\u000f:/3w";
      i[52] = "wOTS~G\u0002o_\\o\bcaTWkR\u0017";
      i[53] = "\u001fe\u0002!rcjE\t.c,\u000bK\u0002%gv\u007f";
      i[54] = "RZ28\u001c~'z97\r1Ft2<\tk2";
      i[55] = "U3\"[O$K;8\u0014\u0002>Q1!H\u00134Q&z[\u0015>R;7\u0014 %P?=Y34Y7&_\u000f2Z";
      i[56] = "%.%\u0000e\u007fP\u000e.\u000ft01\u0000%\u0004pjE";
      i[57] = "zl-m\br\u000fL&b\u0019=nB-i\u001dg\u001a";
      i[58] = "pD\u0002\r;^\u0005d\t\u0002*\u0011dj\u0002\t.K\u0010";
      i[59] = "'(G[\u007f]?!UN\u0007J558On\u0017c=]XfQ8ETJ?\u0010$ CByK\\)Q\u001b8W9>Y]c/";
      i[60] = "\u00172&J*yU-?\u0019G ,h`B5:L)d\u00149{,j?_(-\u0015( F{@";
      i[61] = "xg\u0010.\u0004\u001d(a\u0019x\u0004p.0\u0000\u0012\u001b\u001c/:\u0012`\u0007\u001e><|";
      i[62] = "yw5\u001a(:/)e\u0011\u0013*Dp3\u001ev%},1F(";
      i[63] = "?C'=E\u001aa\u00125
      i[64] = "&jhp\u0010{.ky+~uCn*r\ff#/.$\u0000'C1t-\u0003 &&&+\u0015\u001c";
      i[65] = "XM08?m\u001c\\!3\\gf\u0004o>.|\u0006Ekh\"=f\u0003#:=e\rG2+6\u0006";
      i[66] = "\u0006[9\u0007s\"BJ(\f\u0010*8\u0012f\u0001b3XSbWnr8\u0015*\u0005q*SQ;\u0014zI";
      i[67] = "jU4\u0001\u0012\u000f)Lm\u0005`\u0001\u0013\u000b8\u000f\u0012\u0012sJ<Y\u001eS\u0013\u000be\u0016]\u0003yYe\r\th";
      i[68] = "\u0016BvlGgT]o?*1-\u00180dX$MY42Te-\u001aoyE3\u0014Xp`\u0016^";
      i[69] = "LzNLN8\u0012+\\^$`vx\fDVs\u00169\b\u0012Z2vxQ]\u0019b\u001c*QFM\t";
      i[70] = "y(\u0016w\u0010qx|Eamtkb[\u0006\t~huIt\u0015|ys'";
      i[71] = ",L9\u001fD\u001c4E+\n<\u00050ZFY\u0000\n2^\u007f\u0005\u0002Rl!x[X\u000b(\u0018$Y\u0000UW";
      i[72] = "K\f?!\u0000\u000e\u000f\u001d.*c\u000fuE`'\u0011\u001f\u0015\u0004dq\u001d^uB,#\u0002\u0006\u001e\u0006=2\te";
      i[73] = "%]\\TEd=TNA=m'J_,\u0003*:U\\\u0015_(b\u000b#\u0012\u0001r;O\u001aN\u0003*e0";
      i[74] = "h\u000f[)eZ\u007f\u0012\\2\u0004Wb\u001eh\"h8c\u000b\np|]t\u0003L+\u0004";
      i[75] = "D.HyL>\u001d{T|p.J8.`\u001c/@*\\|\u001e>FD";
      i[76] = "DkhjO7\u001a:zx%o~i*bW|\u001e(.4[=~klj\u001c\u007fD1*o%";
      i[77] = "#VP\u001dp\\}\u0007B\u000f\u001a\b\u0019T\u0012\u0015h\u0017y\u0015\u0016CdV\u0019TO\f'\u0006s\u0006O\u0017sm";
      i[78] = "6\u0012[~f@t\rB-\u000b\u0014\rH\u001dvy\u0003m\t\u0019 uB\rJBkd\u00144\b]r7y";
      i[79] = "\u0013$L\r\u0013QSuMPy^\fqN\u0000.\tV!\u0010lG\f\tyUU\u001b\u000eQ'";
      i[80] = "\u001apf\u0010m\u0010Z!gM\u0007\u001f\u0005%d\u001dPH_u9q9M\u0000-\u007fHeOXs";
      i[81] = "\u001fQ\u0010#vs\\Z\\)N`\u001dP[z2f\u001b=^)\u007fp\u001c^_},fa";
      i[82] = "N{9\u0010'w@}s\u0002I\"~>5\f;2\u001e\u007f1Z7s~:0Q)s\u001eln\u0001\"H";
      i[83] = "@M<\u0010\u0010P\u001e\u001c.\u0002z\u000bzO~\u0018\b\u001b\u001a\u000ezN\u0004Zz\u001a+GE\u0019\u001f\r#\u0001\u001ea";
      i[84] = "#\u001c~\u001a(8}Ml\bBt\u0019\u001e<\u00120sy_8D<2\u0019\u001ea\u000b\u007fbsLa\u0010+\t";
      i[85] = "~\u001ctblLu\u001dvy\u0003\u0013p\u0000/zb\u000emm+w>\u0016sS v<\r\u001c";
      i[86] = "~9b^FU hpL,\rD; V^\u001e$z$\u0000R_Dnu\t\u0013\u001c!y}OHd";
      i[87] = "\u0010RI\fg1SY\u0005\u0006_\"\u0015s\u001dD#2nN\u0014\\/?\u0012\\\u0014\u0005.C";
      i[88] = "5t\u000b\u0007\u0018|\"i\f\u001cyq?e-\u001b\u0014s4\u0019\u000e\bA!*|\u0019\u0000\u0007zR";
      i[89] = "p\u001f$6i}4\u000e5=\nzNV{0xl.\u0017\u007fft-NQ74ku%\u0015&%`\u0016";
      i[90] = "L0f\u00046\u0017\u0016vc=%-NvnO5M\u000fr8Ct-N+w\u0000$G\u001c+lTO";
      i[91] = "I\u0011}gAR\r\u0000ll\"TwX\"aPC\u0017\u0019&7\\\u0002w_neCZ\u001c\u001b\u007ftH9";
      i[92] = "\u0007\u001e\bIX6YO\u001a[2j=\u001cJA@}]]N\u0017L<=\u001c\u0017X\u000flWN\u0017C[\u0007";
      i[93] = "%y\tL$\u0003<j\u001bB@YYw\t\u001f\u007fK<`\u0001Y$3";
      i[94] = "x^sVl1.\u0000#]W#EYuR2.|\u0005w\nl";
      i[95] = "R;\u001b]k7J2\tH\u0013>H0d\u001b/!L)]G-y\u0012VZ\u0019w Vo\u0006\u001b/~)";
      i[96] = "VO\u00181U\u001c\b\u001e\n#?\\lMZ9MW\f\f^oA\u0016lM\u0007 \u0002F\u0006\u001f\u0007;V-";
      i[97] = "1WGE\u0001\u0001o\u0006UWkW\u000bU\u0005M\u0019Jk\u0014\u0001\u001b\u0015\u000b\u000bUXTV[a\u0007XO\u00020";
      i[98] = " X\"S\u001e .^hApv\u0010\u001d.O\u0002ep\\*\u0019\u000e$\u0010\u0019+\u0012\u0010$pOuB\u001b\u001f";
      i[99] = "r:L7Q\u0019kw\\s0H\u001b>\u000b+B[{\u007f\u000f}N\u001a\u001b<T6_L\"~K/\f!";
      i[100] = "\u0012\u0000\n\u0010~,\u000b\u0013\u0018\u001e\u001awn\u000e\nC%d\u000b\u0019\u0002\u0005~\u001c";
      i[101] = "[]\u000bs$8\u0019B\u0012 Im`\u0007M{;{\u0000FI-7:`\u0005\u0012f&lYG\r\u007fu\u0001";
      i[102] = "f\u007f`:\u007fE&.ag\u0015Jy*b7B\u001d#z>[+\u0018|\"ybw\u001a$|";
      i[103] = "t/\u001bqp@.i\u001eHbzvi\u0013:s\u001a7mE62zv4\nub\u0010$4\u0011!\t";
      i[104] = "\u00129S\u0002\u001d\u0001B?ZT\u001dl@dZF\u000f\u0016FJYR=\u0001W\u0003[R\b\u000bEqGP\u0019\r+gSP\u0001\u0002Y{QA\u0007l[o_N\u001a\u0010Io\u0006Of";
      i[105] = "Cx)I\u001e\u007f\u001d);[t4yzkA\u00064\u0019;o\u0017\nuyz6XI%\u0013(6C\u001dN";
      i[106] = "\"\u0014w\n|7#@$\u001c\u000144U\u0000\u0016q(]^*\u001bq(!L*BpT";
      i[107] = "0\t>()\u0001nX,:CO\n\u000b| 1JjJxv=\u000b\n\u000b!9~[`Y!\"*0";
      i[108] = "\u0006\u0006$c8lE\u001f}gJ`\u007fX(m8q\u001f\u0019,;40\u007fXutw`\u0015\nuo#\u000b";
      i[109] = "9x<;\u000b\u0018!q..s\u000f+eC,\u0011S>e&!\nT}\u0015,!J\u00162p!:MUBz!z\u000f\u001a'w:}Lj";
      i[110] = ",\u0006H4\u00006;\u001bO/a;&\u0017k6\u001c9K\u0007Hj^,.\u0010@,\u0005T";
      i[111] = "\u0014\\s\u001e9iVCjMT9/\u00065\u0016&*OG1@*k/\u0006h\u000fi;ETh\u0014=P";
      i[112] = ",>\u0018\u0001\\|h/\t\n?w\u0012wG\u0007Mmr6CQA,\u0012p\u000b\u0003^ty4\u001a\u0012U\u0017";
      i[113] = "\bshZ+1^x,Q\u001b<\u0002~|WE;\u0002dx+t0_eeNy+X&\u0015";
      i[114] = "Z\u0011e?JV\u0003Dy:vVX\u0007c\u0003\u0010HE\u001aj&vXR@\u007f2\u0018@^\u0007:B\u0015C_\u0006?=L\u0016C\u0003\u0003";
      i[115] = "\r\u000b8\u0013\"v\u001a\u0016?\bC{\u0007\u001a\u000b:\t\u0014\u0006\u000fiJ;q\u0011\u0007/\u0011C";
      i[116] = "6San|_`\r1eGN\u000bTgj\"@2\be2|";
      i[117] = "QGo\u0018|U\u000f\u0016}\n\u0016\rk\u0001z\rn\u0016\f\u0019c\u0011}d\u0016\u0017k\u000fd\u0003\u000e\u000ew\u001c\u0016";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = i[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(j[var4]);
            i[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            i[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  i[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(2170662191037378L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = i[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = j[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  i[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(2170662191037378L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        i[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(2170662191037378L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 36;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 98;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 201;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 234;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 193;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 106;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 36;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 98;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 201;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dv_C0206",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dv" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Vector3d invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)Lorg/joml/Vector3d;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Vector3d)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static GlBufferMeshBuilder invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static double invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding4(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache4;
         MethodHandle var8 = bindingCache4;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache4 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding5(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache5;
         MethodHandle var8 = bindingCache5;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache5 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding6(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache6;
         MethodHandle var8 = bindingCache6;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache6 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static double invokeBinding8(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache8;
         MethodHandle var8 = bindingCache8;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache8 = b(MethodHandles.lookup(), "$", SourceSupport.methodType("(Ljava/lang/Object;JJ)D", MethodHandles.lookup())).dynamicInvoker();
         }

         return (double)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding9(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache9;
         MethodHandle var8 = bindingCache9;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache9 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static MeshDataConsumer invokeBinding10(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache10;
         MethodHandle var9 = bindingCache10;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache10 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cC_C0115;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MeshDataConsumer)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding14(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache14;
         MethodHandle var9 = bindingCache14;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache14 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding15(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache15;
         MethodHandle var9 = bindingCache15;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache15 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding17(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache17;
         MethodHandle var9 = bindingCache17;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache17 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding25(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache25;
         MethodHandle var9 = bindingCache25;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache25 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding26(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding27(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache27;
         MethodHandle var9 = bindingCache27;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache27 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding28(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding29(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding30(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache30;
         MethodHandle var9 = bindingCache30;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache30 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding32(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache32;
         MethodHandle var9 = bindingCache32;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache32 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding34(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache34;
         MethodHandle var9 = bindingCache34;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache34 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding35(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache35;
         MethodHandle var9 = bindingCache35;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache35 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding36(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache36;
         MethodHandle var9 = bindingCache36;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache36 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding37(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache37;
         MethodHandle var9 = bindingCache37;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache37 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding38(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache38;
         MethodHandle var9 = bindingCache38;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache38 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding40(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache40;
         MethodHandle var9 = bindingCache40;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache40 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding41(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache41;
         MethodHandle var9 = bindingCache41;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache41 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding42(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache42;
         MethodHandle var9 = bindingCache42;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache42 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding43(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache43;
         MethodHandle var9 = bindingCache43;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache43 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding44(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache44;
         MethodHandle var9 = bindingCache44;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache44 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding45(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache45;
         MethodHandle var9 = bindingCache45;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache45 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding47(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache47;
         MethodHandle var9 = bindingCache47;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache47 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding48(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding49(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache49;
         MethodHandle var9 = bindingCache49;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache49 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding50(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache50;
         MethodHandle var9 = bindingCache50;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache50 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding51(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache51;
         MethodHandle var9 = bindingCache51;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache51 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding52(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache52;
         MethodHandle var9 = bindingCache52;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache52 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding53(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache53;
         MethodHandle var9 = bindingCache53;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache53 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding54(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache54;
         MethodHandle var9 = bindingCache54;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache54 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding55(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache55;
         MethodHandle var9 = bindingCache55;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache55 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding56(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache56;
         MethodHandle var9 = bindingCache56;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache56 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding57(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache57;
         MethodHandle var9 = bindingCache57;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache57 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding58(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache58;
         MethodHandle var9 = bindingCache58;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache58 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static MeshDataConsumer invokeBinding59(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache59;
         MethodHandle var9 = bindingCache59;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache59 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/cC_C0115;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (MeshDataConsumer)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlBufferMeshBuilder invokeBinding60(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache60;
         MethodHandle var9 = bindingCache60;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache60 = b(
                  MethodHandles.lookup(),
                  "Á",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bQ_C0089;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlBufferMeshBuilder)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding61(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache61;
         MethodHandle var8 = bindingCache61;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache61 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding62(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache62;
         MethodHandle var8 = bindingCache62;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache62 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding63(int var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, float var7) {
         MethodHandle var12 = bindingCache63;
         MethodHandle var11 = bindingCache63;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache63 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFFFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$triangle$0",
                     "(ILorg/joml/Matrix4f;FFFFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var9.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5, (float)var6, (float)var7);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static BiConsumer invokeBinding64(int var0, Matrix4f var1, float var2, float var3, float var4, float var5) {
         MethodHandle var10 = bindingCache64;
         MethodHandle var9 = bindingCache64;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache64 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$rect$1",
                     "(ILorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding65(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache65;
         MethodHandle var8 = bindingCache65;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache65 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding66(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache66;
         MethodHandle var8 = bindingCache66;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache66 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding67(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache67;
         MethodHandle var8 = bindingCache67;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache67 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding68(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache68;
         MethodHandle var8 = bindingCache68;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache68 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding69(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache69;
         MethodHandle var8 = bindingCache69;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache69 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static RenderCommandBatcher invokeBinding70(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache70;
         MethodHandle var8 = bindingCache70;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache70 = b(
                  MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderCommandBatcher)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding71(int var0, int var1, int var2, int var3, Matrix4f var4, float var5, float var6, float var7, float var8) {
         MethodHandle var13 = bindingCache71;
         MethodHandle var12 = bindingCache71;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache71 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(IIIILorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$rectGradient$2",
                     "(IIIILorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var10.invokeExact((int)var0, (int)var1, (int)var2, (int)var3, (Matrix4f)var4, (float)var5, (float)var6, (float)var7, (float)var8);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static void invokeBinding72(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache72;
         MethodHandle var9 = bindingCache72;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache72 = b(
                  MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RenderCommandBatcher invokeBinding73(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache73;
         MethodHandle var8 = bindingCache73;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache73 = b(
                  MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderCommandBatcher)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding74(int var0, Matrix4f var1, float var2, float var3, float var4, float var5) {
         MethodHandle var10 = bindingCache74;
         MethodHandle var9 = bindingCache74;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache74 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$rectOutline$3",
                     "(ILorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding75(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache75;
         MethodHandle var9 = bindingCache75;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache75 = b(
                  MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RenderCommandBatcher invokeBinding76(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache76;
         MethodHandle var8 = bindingCache76;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache76 = b(
                  MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderCommandBatcher)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding77(int var0, Matrix4f var1, float var2, float var3, float var4, float var5) {
         MethodHandle var10 = bindingCache77;
         MethodHandle var9 = bindingCache77;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache77 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$line$4",
                     "(ILorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding78(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache78;
         MethodHandle var9 = bindingCache78;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache78 = b(
                  MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RenderCommandBatcher invokeBinding79(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache79;
         MethodHandle var8 = bindingCache79;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache79 = b(
                  MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderCommandBatcher)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding80(Color var0, Color var1, float var2, float var3, float var4, float var5, float var6, Matrix4f var7) {
         MethodHandle var12 = bindingCache80;
         MethodHandle var11 = bindingCache80;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache80 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/awt/Color;Ljava/awt/Color;FFFFFLorg/joml/Matrix4f;)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$gradientLine$5",
                     "(Ljava/awt/Color;Ljava/awt/Color;FFFFFLorg/joml/Matrix4f;Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var9.invokeExact((Color)var0, (Color)var1, (float)var2, (float)var3, (float)var4, (float)var5, (float)var6, (Matrix4f)var7);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static void invokeBinding81(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache81;
         MethodHandle var9 = bindingCache81;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache81 = b(
                  MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding82(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache82;
         MethodHandle var8 = bindingCache82;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache82 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding83(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache83;
         MethodHandle var8 = bindingCache83;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache83 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding84(Color var0, float var1, float var2, float var3, float var4, Matrix4f var5) {
         MethodHandle var10 = bindingCache84;
         MethodHandle var9 = bindingCache84;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache84 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/awt/Color;FFFFLorg/joml/Matrix4f;)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$roundedRect$6",
                     "(Ljava/awt/Color;FFFFLorg/joml/Matrix4f;Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((Color)var0, (float)var1, (float)var2, (float)var3, (float)var4, (Matrix4f)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding85(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache85;
         MethodHandle var8 = bindingCache85;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache85 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding86(Color var0, Color var1, Color var2, Color var3, float var4, float var5, float var6, float var7, Matrix4f var8) {
         MethodHandle var13 = bindingCache86;
         MethodHandle var12 = bindingCache86;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache86 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;FFFFLorg/joml/Matrix4f;)Ljava/util/function/BiConsumer;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$roundedRectGradient$7",
                     "(Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;FFFFLorg/joml/Matrix4f;Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var10.invokeExact((Color)var0, (Color)var1, (Color)var2, (Color)var3, (float)var4, (float)var5, (float)var6, (float)var7, (Matrix4f)var8);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static int invokeBinding87(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache87;
         MethodHandle var8 = bindingCache87;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache87 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding88(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache88;
         MethodHandle var8 = bindingCache88;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache88 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding89(int var0, Matrix4f var1, float var2, float var3, float var4) {
         MethodHandle var9 = bindingCache89;
         MethodHandle var8 = bindingCache89;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache89 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(ILorg/joml/Matrix4f;FFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$circle$8",
                     "(ILorg/joml/Matrix4f;FFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var6.invokeExact((int)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static int invokeBinding90(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache90;
         MethodHandle var8 = bindingCache90;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache90 = b(MethodHandles.lookup(), "Á", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding91(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache91;
         MethodHandle var8 = bindingCache91;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache91 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding92(int var0, float var1, float var2, float var3, float var4, Matrix4f var5) {
         MethodHandle var10 = bindingCache92;
         MethodHandle var9 = bindingCache92;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache92 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(IFFFFLorg/joml/Matrix4f;)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dv_C0206",
                     "lambda$circleOutline$9",
                     "(IFFFFLorg/joml/Matrix4f;Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((int)var0, (float)var1, (float)var2, (float)var3, (float)var4, (Matrix4f)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding93(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache93;
         MethodHandle var8 = bindingCache93;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache93 = b(MethodHandles.lookup(), "j", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Supplier invokeBinding94() {
         MethodHandle var4 = bindingCache94;
         MethodHandle var3 = bindingCache94;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache94 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 8, "org/joml/Matrix4f", "<init>", "()V"),
                  SourceSupport.methodType("()Lorg/joml/Matrix4f;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Supplier invokeBinding95() {
         MethodHandle var4 = bindingCache95;
         MethodHandle var3 = bindingCache95;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache95 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "get",
                  SourceSupport.methodType("()Ljava/util/function/Supplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 8, "org/joml/Vector3d", "<init>", "()V"),
                  SourceSupport.methodType("()Lorg/joml/Vector3d;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Supplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }
}
