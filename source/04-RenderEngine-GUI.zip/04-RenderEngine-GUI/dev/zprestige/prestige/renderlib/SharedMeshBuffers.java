package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;

import java.util.concurrent.atomic.AtomicReference;

public record SharedMeshBuffers(ManagedGlBuffer ag, ManagedGlBuffer ah, GlVertexArray ai, AtomicReference<GlBufferMeshBuilder> aj) {

    public final java.util.concurrent.atomic.AtomicReference<dev.zprestige.prestige.renderlib.GlBufferMeshBuilder> recoveryAccess_read_aj() { return this.aj; }

    public final dev.zprestige.prestige.renderlib.ManagedGlBuffer recoveryAccess_read_ag() { return this.ag; }

    public final dev.zprestige.prestige.renderlib.ManagedGlBuffer recoveryAccess_read_ah() { return this.ah; }

    public final dev.zprestige.prestige.renderlib.GlVertexArray recoveryAccess_read_ai() { return this.ai; }
}
