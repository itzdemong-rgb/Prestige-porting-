package dev.zprestige.prestige.renderlib;
import org.lwjgl.system.MemoryStack;
import java.nio.IntBuffer;
import org.lwjgl.stb.STBImage;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL30;



import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.io.IOException;
import java.io.InputStream;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GLCapabilities;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TextureLoader {
   private static final Logger a;
   private static final boolean b;
   private static final float c;
   private static final long d = 139233777445104L;
   private static final String[] e;
   private static final String[] f;
   private static final Map g = new HashMap(13);
   private static final long[] h;
   private static final Integer[] i;
   private static final Map j;
   private static final Object[] k = new Object[76];
   private static final String[] l = new String[76];
   private static volatile MethodHandle bindingCache1;

   public static ManagedGlTexture aReturningbT_C0095(Object[] var0) {
      String var1 = (String)var0[0];
      long var2 = (Long)var0[1];
      var2 = 139233777445104L ^ var2;
      long var4 = var2 ^ 33701176664164L;

      try {
         short var10001 = 26317;
         long var10002 = 1053445288880403300L ^ var2;
         short var12 = 28013;
         long var10003 = 8136230403635050711L ^ var2;
         Object[] var10006 = new Object[]{null, null, null, null, var4};
         var10006[3] = true;
         var10006[2] = 33071;
         var10006[1] = 9729;
         var10006[0] = var1;
         Object[] var7 = var10006;
         return cReturningbT_C0095(var7);
      } catch (IOException var10) {
         throw new RuntimeException(var10);
      }
   }

   public static ManagedGlTexture bReturningbT_C0095(Object[] var0) throws IOException {
      String var1 = (String)var0[0];
      int var5 = (Integer)var0[1];
      int var2 = (Integer)var0[2];
      long var3 = (Long)var0[3];
      var3 = 139233777445104L ^ var3;
      long var6 = var3 ^ 83539403015054L;
      Object[] var10006 = new Object[]{null, null, null, null, var6};
      var10006[3] = true;
      var10006[2] = var2;
      var10006[1] = var5;
      var10006[0] = var1;
      return invokeBinding1(var10006, 5710558728340676047L, var3);
   }

    public static ManagedGlTexture cReturningbT_C0095(final Object[] array) throws IOException {
        final String s = (String)array[0];
        final int intValue = (int)array[1];
        final int intValue2 = (int)array[2];
        final int booleanValue = ((boolean)array[3]) ? 1 : 0;
        final long n = 0x7EA1E3D868F0L ^ (long)array[4];
        final long l = n ^ 0x7CD7280B385BL;
        final long n2 = n ^ 0x4D02E67D3925L;
        final long i = n ^ 0x1C9B73A63201L;
        final long j = n ^ 0x7F61D1BC03A6L;
        final long k = n ^ 0x6AF5231F31E5L;
        final long m = n ^ 0x66D45FDDC822L;
        final int cReturningInt = Event.cReturningInt();
        final ByteBuffer aReturningByteBuffer = aReturningByteBuffer(new Object[] { s, j });
        final MemoryStack stackPush = MemoryStack.stackPush();
        final int n3 = cReturningInt;
        try {
            final IntBuffer mallocInt = stackPush.mallocInt(1);
            final IntBuffer mallocInt2 = stackPush.mallocInt(1);
            final ByteBuffer stbi_load_from_memory = STBImage.stbi_load_from_memory((ByteBuffer)aReturningByteBuffer, (IntBuffer)mallocInt, (IntBuffer)mallocInt2, (IntBuffer)stackPush.mallocInt(1), 4);
            if (stbi_load_from_memory == null) {
                throw new IOException("Failed to load image: " + STBImage.stbi_failure_reason());
            }
            try {
                final int value = mallocInt.get(0);
                final int value2 = mallocInt2.get(0);
                final int n4 = value * value2 * 4;
                final int remaining = stbi_load_from_memory.remaining();
                if (n3 != 0 && remaining < n4) {
                    throw new IOException("Image buffer too small: " + stbi_load_from_memory.remaining() + " bytes, expected " + n4);
                }
                final ManagedGlTexture aReturningbT_C0095 = ManagedGlTexture.aReturningbT_C0095(new Object[] { remaining, m });
                aReturningbT_C0095.cReturningVoid(new Object[] { 32856, value, value2, l });
                GL15.glBindBuffer(35052, 0);
                GL11.glPixelStorei(3314, 0);
                GL11.glPixelStorei(3316, 0);
                GL11.glPixelStorei(3315, 0);
                GL11.glPixelStorei(3317, 4);
                GL11.glBindTexture(3553, aReturningbT_C0095.a);
                final ManagedGlTexture bt_C0095 = aReturningbT_C0095;
                final int n5 = 0;
                Label_1021: {
                    if (n3 != 0) {
                        bt_C0095.dReturningVoid(new Object[] { n5, 0, value, value2, 6408, 5121, stbi_load_from_memory, i });
                        if (booleanValue != 0) {
                            GL30.glGenerateMipmap(3553);
                            if (n3 != 0) {
                                if (intValue == 9729) {
                                    GL11.glTexParameteri(3553, 10241, 9987);
                                    GL11.glTexParameteri(3553, 10240, 9729);
                                    if (n3 != 0) {
                                        break Label_1021;
                                    }
                                }
                                aReturningbT_C0095.bReturningVoid(new Object[] { intValue, n2 });
                            }
                            if (n3 != 0) {
                                break Label_1021;
                            }
                        }
                    }
                    bt_C0095.bReturningVoid(new Object[] { n5, n2 });
                }
                aReturningbT_C0095.eReturningVoid(new Object[] { intValue2, k });
                final boolean b2;
                final boolean b = b2 = TextureLoader.b;
                int n6 = 0;
                if (n3 != 0) {
                    if (b) {
                        n6 = booleanValue;
                        if (n3 != 0) {
                            if (n6 != 0) {
                                GL11.glTexParameterf(3553, 34046, Math.min(64.0f, TextureLoader.c));
                            }
                        }
                    }
                }
                GL11.glBindTexture(n6, 0);
                final ManagedGlTexture bt_C96 = aReturningbT_C0095;
                STBImage.stbi_image_free((ByteBuffer)stbi_load_from_memory);
                final MemoryStack memoryStack = stackPush;
                if (n3 == 0 || memoryStack != null) {
                    memoryStack.close();
                }
                return bt_C96;
            }
            finally {
                STBImage.stbi_image_free((ByteBuffer)stbi_load_from_memory);
            }
        }
        catch (final Throwable t) {
            final MemoryStack memoryStack2 = stackPush;
            if (n3 != 0) {
                if (memoryStack2 == null) {
                    throw t;
                }
            }
            try {
                memoryStack2.close();
            }
            catch (final Throwable t2) {
                t.addSuppressed(t2);
            }
            throw t;
        }
    }

   
   
   private static ByteBuffer aReturningByteBuffer(Object[] var0) throws IOException {
      String var1 = (String)var0[0];
      long var2 = (Long)var0[1];
      var2 = 139233777445104L ^ var2;
      int var4 = Event.cReturningInt();
      int var44 = var4;
      String var43 = var1;
      String var33 = var43;
      String var32 = var43;
      String var34;
      if (var44 != 0) {
         String var11 = "/";
         String var10 = var32;
         boolean var45 = var10.startsWith(var11);
         if (var45) {
            String var13 = var1;
            String var46 = var13.substring(1);
            var34 = var46;
         } else {
            var34 = var1;
         }
      } else {
         String var47 = var33;
         var34 = var47;
      }

      String var5 = var34;
      Class<TextureLoader> var16 = TextureLoader.class;
      ClassLoader var10000 = var16.getClassLoader();
      String var18 = var5;
      ClassLoader var17 = var10000;
      InputStream var6 = var17.getResourceAsStream(var18);

      ByteBuffer var9;
      try {
         int var49 = var4;
         InputStream var48 = var6;
         InputStream var36 = var48;
         InputStream var35 = var48;
         if (var49 != 0) {
            InputStream var50 = var35;
            if (var50 == null) {
               short var10003 = 21688;
               long var10004 = 3713224662543909093L ^ var2;
               throw new IOException("Resource not found: " + var5);
            }

            var36 = var6;
         }

         InputStream var21 = var36;
         byte[] var7 = var21.readAllBytes();
         int var22 = var7.length;
         ByteBuffer var8 = ByteBuffer.allocateDirect(var22);
         byte[] var24 = var7;
         ByteBuffer var23 = var8;
         var23.put(var24);
         ByteBuffer var25 = var8;
         var25.flip();
         var9 = var8;
      } catch (Throwable var59) {
         int var55 = var4;
         InputStream var54 = var6;
         InputStream var41 = var54;
         InputStream var40 = var54;
         if (var55 != 0) {
            InputStream var56 = var40;
            if (var56 == null) {
               throw var59;
            }

            try {
               var41 = var6;
            } catch (Throwable var58) {
               var59.addSuppressed(var58);
               throw var59;
            }
         }

         try {
            InputStream var29 = var41;
            var29.close();
         } catch (Throwable var57) {
            var59.addSuppressed(var57);
         }

         throw var59;
      }

      int var52 = var4;
      InputStream var51 = var6;
      InputStream var38 = var51;
      InputStream var37 = var51;
      if (var52 != 0) {
         InputStream var53 = var37;
         if (var53 == null) {
            return var9;
         }

         var38 = var6;
      }

      InputStream var27 = var38;
      var27.close();
      return var9;
   }

   static {

      {

      aReturningVoid();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(137384221920757L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[6];
      String var15 = "\u0097Mö\f]¡*¹±{ÍV\u0002Å`µ\u0097|\u0017Æ=ð¤ìÙt¥\u009f¯W:ìÜÝ#\u001dÝ\u007f\u0011ò8ä¬\u0004ÞMó(ã\u0003p¯\u001eà\"Ãq!G\u007f\u001c³Ø\u007f0Þ'ê\u001eîh/G ©ü°n\u009bYµ\u0018ñ²\u0080oê×6|/\u00193²k^((fèh»\u0010\u000f÷åÏ¸êÇ\u009aVh\u008eª]H«\b'æ^Ãl]\u009d\u0095\u0005\u001f=\u0004ÙÅ_\u007f¡ø/Pö¶\u009bN\u0097Ì\u000bú\u007f\u00113\u008c2\u0007\u0004ûÂÝ¸\u001f\u0089´&¨³*\\Át±ýVx½ï>\n\u0016C°¨\u0016ä\u0098ÜØ¥»UÀL¥çHgf\u0013?DO\u001dSÐ\u0017¤E§¸yD¬PÜHëwíÂ\u0086©";
      int var17 = "\u0097Mö\f]¡*¹±{ÍV\u0002Å`µ\u0097|\u0017Æ=ð¤ìÙt¥\u009f¯W:ìÜÝ#\u001dÝ\u007f\u0011ò8ä¬\u0004ÞMó(ã\u0003p¯\u001eà\"Ãq!G\u007f\u001c³Ø\u007f0Þ'ê\u001eîh/G ©ü°n\u009bYµ\u0018ñ²\u0080oê×6|/\u00193²k^((fèh»\u0010\u000f÷åÏ¸êÇ\u009aVh\u008eª]H«\b'æ^Ãl]\u009d\u0095\u0005\u001f=\u0004ÙÅ_\u007f¡ø/Pö¶\u009bN\u0097Ì\u000bú\u007f\u00113\u008c2\u0007\u0004ûÂÝ¸\u001f\u0089´&¨³*\\Át±ýVx½ï>\n\u0016C°¨\u0016ä\u0098ÜØ¥»UÀL¥çHgf\u0013?DO\u001dSÐ\u0017¤E§¸yD¬PÜHëwíÂ\u0086©"
         .length();
      char var14 = '(';
      int var34 = -1;

      label60:
      while (true) {
         String var35 = var15.substring(++var34, var34 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var35.getBytes("ISO-8859-1"));
            String var47 = a(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var47;
                  if ((var34 += var14) >= var17) {
                     e = var18;
                     f = new String[6];
                     j = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(137384221920757L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[18];
                     String var4 = "ØRf+E\"ä\u001aäbrø\u0001\bÙW_.\u0083AÜ¶ìWö\rZÑïþ\u00ad«\u0093\u008a¹\u009bL\u0001a\u001dß\u0083þÏó6/¸~¢½{¤CC[}9×\u008c3ÚS\rÿÿ×ÕSÒ\u009e{ËÂ\u0084\u0094i\u00adÖj²ÿ^yb\u0012î\u0098\u0012-\u009ao}ÂÊ\u008d\u009dI²Ý\u0094Ô¿\u0010bQ\u0000\u0017Ù;µq\u008aYLN\"$EìÑ0\u0087\u0010§D#9";
                     int var5 = "ØRf+E\"ä\u001aäbrø\u0001\bÙW_.\u0083AÜ¶ìWö\rZÑïþ\u00ad«\u0093\u008a¹\u009bL\u0001a\u001dß\u0083þÏó6/¸~¢½{¤CC[}9×\u008c3ÚS\rÿÿ×ÕSÒ\u009e{ËÂ\u0084\u0094i\u00adÖj²ÿ^yb\u0012î\u0098\u0012-\u009ao}ÂÊ\u008d\u009dI²Ý\u0094Ô¿\u0010bQ\u0000\u0017Ù;µq\u008aYLN\"$EìÑ0\u0087\u0010§D#9"
                        .length();
                     label42:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var38 = var6;
                        var10001 = var3++;
                        long var51 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var51;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var56 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var54) {
                              case 0:
                                 var38[var10001] = var56;
                                 if (var2 >= var5) {
                                    h = var6;
                                    i = new Integer[18];
                                    Class<TextureLoader> var22 = TextureLoader.class;
                                    a = LoggerFactory.getLogger(var22);
                                    GLCapabilities var23 = GL.getCapabilities();
                                    b = var23.GL_EXT_texture_filter_anisotropic;
                                    if (b) {
                                       c = GL11.glGetFloat(34047);
                                       Logger var39 = a;
                                       float var25 = c;
                                       Float var28 = var25;
                                       String var27 = "Anisotropic filtering supported: Max {}x";
                                       Logger var26 = var39;
                                       var26.info(var27, var28);
                                    } else {
                                       c = 1.0F;
                                       String var31 = "Anisotropic filtering not supported";
                                       Logger var30 = a;
                                       var30.info(var31);
                                    }

                                    break;
                                 }
                                 break;
                              default:
                                 var38[var10001] = var56;
                                 if (var2 < var5) {
                                    continue label42;
                                 }

                                 var4 = "\u0097\u0087Ø9¨½¦üd\u001d9IóuUJ";
                                 var5 = "\u0097\u0087Ø9¨½¦üd\u001d9IóuUJ".length();
                                 var2 = 0;
                           }

                           int var45 = var2;
                           var2 += 8;
                           var7 = var4.substring(var45, var2).getBytes("ISO-8859-1");
                           var38 = var6;
                           var10001 = var3++;
                           var51 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var54 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var34);
                  break;
               default:
                  var18[var16++] = var47;
                  if ((var34 += var14) < var17) {
                     var14 = var15.charAt(var34);
                     continue label60;
                  }

                  var15 = "\u0006G9\u0095¾(õh?i+2\u0017\u00ad§\u007f®\u0089ck\u0097\u0013{\"Ó\u0018¯jü\u000e\\Jl4&O\rf\u001b;\u000e!\u001a& iýá\u0018\u0000{6\u0017(Ôz+\u0018·gÍ¥`\u0004(>0èe\b\u001b+7\u0016Y\u001e°©èpw\u009eü\u001f\u0006\u0085Çä©óv\u0001»£Þ\t\u0012ÏËð\u0010\\´ß\u0088";
                  var17 = "\u0006G9\u0095¾(õh?i+2\u0017\u00ad§\u007f®\u0089ck\u0097\u0013{\"Ó\u0018¯jü\u000e\\Jl4&O\rf\u001b;\u000e!\u001a& iýá\u0018\u0000{6\u0017(Ôz+\u0018·gÍ¥`\u0004(>0èe\b\u001b+7\u0016Y\u001e°©èpw\u009eü\u001f\u0006\u0085Çä©óv\u0001»£Þ\t\u0012ÏËð\u0010\\´ß\u0088"
                     .length();
                  var14 = '@';
                  var34 = -1;
            }

            var35 = var15.substring(++var34, var34 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 23366;
      if (f[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])g.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               g.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dh", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = e[var5].getBytes("ISO-8859-1");
         f[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return f[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dh_C0180",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 14688;
      if (i[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = h[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])j.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dh", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         i[var3] = var15;
      }

      return i[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dh_C0180",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 2;
            yield var15;
         }
         case 1 -> {
            byte var16 = 36;
            yield var16;
         }
         case 2 -> {
            byte var17 = 56;
            yield var17;
         }
         case 3 -> {
            byte var18 = 22;
            yield var18;
         }
         case 4 -> {
            byte var19 = 60;
            yield var19;
         }
         case 5 -> {
            byte var20 = 61;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 39;
            yield var22;
         }
         case 8 -> {
            byte var23 = 41;
            yield var23;
         }
         case 9 -> {
            byte var24 = 46;
            yield var24;
         }
         case 10 -> {
            byte var25 = 44;
            yield var25;
         }
         case 11 -> {
            byte var26 = 14;
            yield var26;
         }
         case 12 -> {
            byte var27 = 3;
            yield var27;
         }
         case 13 -> {
            byte var28 = 16;
            yield var28;
         }
         case 14 -> {
            byte var29 = 29;
            yield var29;
         }
         case 15 -> {
            byte var30 = 57;
            yield var30;
         }
         case 16 -> {
            byte var31 = 15;
            yield var31;
         }
         case 17 -> {
            byte var32 = 10;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 20;
            yield var34;
         }
         case 20 -> {
            byte var35 = 53;
            yield var35;
         }
         case 21 -> {
            byte var36 = 58;
            yield var36;
         }
         case 22 -> {
            byte var37 = 11;
            yield var37;
         }
         case 23 -> {
            byte var38 = 27;
            yield var38;
         }
         case 24 -> {
            byte var39 = 25;
            yield var39;
         }
         case 25 -> {
            byte var40 = 31;
            yield var40;
         }
         case 26 -> {
            byte var41 = 55;
            yield var41;
         }
         case 27 -> {
            byte var42 = 49;
            yield var42;
         }
         case 28 -> {
            byte var43 = 34;
            yield var43;
         }
         case 29 -> {
            byte var44 = 7;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 45;
            yield var46;
         }
         case 32 -> {
            byte var47 = 18;
            yield var47;
         }
         case 33 -> {
            byte var48 = 24;
            yield var48;
         }
         case 34 -> {
            byte var49 = 54;
            yield var49;
         }
         case 35 -> {
            byte var50 = 21;
            yield var50;
         }
         case 36 -> {
            byte var51 = 59;
            yield var51;
         }
         case 37 -> {
            byte var52 = 38;
            yield var52;
         }
         case 38 -> {
            byte var53 = 28;
            yield var53;
         }
         case 39 -> {
            byte var54 = 19;
            yield var54;
         }
         case 40 -> {
            byte var55 = 51;
            yield var55;
         }
         case 41 -> {
            byte var56 = 32;
            yield var56;
         }
         case 42 -> {
            byte var57 = 62;
            yield var57;
         }
         case 43 -> {
            byte var58 = 37;
            yield var58;
         }
         case 44 -> {
            byte var59 = 30;
            yield var59;
         }
         case 45 -> {
            byte var60 = 0;
            yield var60;
         }
         case 46 -> {
            byte var61 = 23;
            yield var61;
         }
         case 47 -> {
            byte var62 = 43;
            yield var62;
         }
         case 48 -> {
            byte var63 = 40;
            yield var63;
         }
         case 49 -> {
            byte var64 = 26;
            yield var64;
         }
         case 50 -> {
            byte var65 = 6;
            yield var65;
         }
         case 51 -> {
            byte var66 = 17;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 4;
            yield var68;
         }
         case 54 -> {
            byte var69 = 47;
            yield var69;
         }
         case 55 -> {
            byte var70 = 9;
            yield var70;
         }
         case 56 -> {
            byte var71 = 48;
            yield var71;
         }
         case 57 -> {
            byte var72 = 42;
            yield var72;
         }
         case 58 -> {
            byte var73 = 1;
            yield var73;
         }
         case 59 -> {
            byte var74 = 50;
            yield var74;
         }
         case 60 -> {
            byte var75 = 35;
            yield var75;
         }
         case 61 -> {
            byte var76 = 5;
            yield var76;
         }
         case 62 -> {
            byte var77 = 63;
            yield var77;
         }
         default -> 13;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      k[0] = "xhnJj&{f6i=<wKmM\"-`";
      k[1] = "kh";
      k[2] = "\u0002~\u00100\u0014\b\u00071/?J\u0014\u001cL\u0012#_\u0000\u0005";
      k[3] = "^7";
      k[4] = "\b\u0014\u0016\u0018r>\u0003\u001b\u0007W\u001f>\u0003\u0006\u0013";
      k[5] = "\u0013\u0007noPE\u0018\b\u007f =E\u0018\u0015kB\u0011H\u001d\u0003j";
      k[6] = void.class;
      l[6] = "java/lang/Void";
      k[7] = "\u0015#\nc>\n\u001e,\u001b,C\u0012\r+\u0012e";
      k[8] = int.class;
      l[8] = "java/lang/Integer";
      k[9] = "I''}\u001e\u0010_'\"'\r\u0007Hl!!\u0001\u0013Y+66J\u0001h";
      k[10] = "+6H]\u0003, 9Y\u0012y(38I]O,$";
      k[11] = "c\u000f\u0002Dbzu\u000f\u0007\u001eqmbD\u0004\u0018}ys\u0003\u0013\u000f6no";
      k[12] = boolean.class;
      l[12] = "java/lang/Boolean";
      k[13] = "\u0012\u001e\u0003>n\b\u0017\u000b\b>q\u0006\u000e\u0018\u0001},2\u0018\u0001\u000bb{,\t\r\u0007{";
      k[14] = "-oAw\u0018c(zJw\u001bd'sA5ZS\u000e.\u0016";
      k[15] = "2W]\\g-7BV\\d*8K]\u001e%\u001d\u0011\u0014\u000f";
      k[16] = "G\u000e\u0001jujB\u001b\njjiJR5\u0010[TE\u001d\u0001!";
      k[17] = "\u001a\u001a\bb\u0016E\u0019\u0014PJV_2\u000e\u0018e]Y";
      k[18] = "f\u0004g\u0005f3p\u0004b_u$gOaYy0v\bvN2!V";
      k[19] = "}g\u000bio}\bG\u0000f~2iI\u000bmzh\u001d";
      k[20] = "fFO1\r\u0013\u0013fD>\u001c\\rhO5\u0018\u0006\u0006";
      k[21] = "W9iTYw\\6x\u001b:zI0";
      k[22] = float.class;
      l[22] = "java/lang/Float";
      k[23] = "\u0015Gn_]\n\u0010Re_^\r\u001f[n\u001d\u001f:6\u00048";
      k[24] = "\u001a\u000b\n\u0018\u001fYo+\u0001\u0017\u000e\u0016\u000e%\n\u001c\nLz";
      k[25] = "9FGWe^LfLXt\u0011-hGSpKY";
      k[26] = "\u001ctxwp1iTsxa~\bZxse$|";
      k[27] = "\"\n+\u0014[YW* \u001bJ\u00166$+\u0010NLB";
      k[28] = "!\u0019rkFqT9ydW>57roSdA";
      k[29] = "\"Ad\u001aAF'To\u001aBA(]dX\u0003v\u0001pbDLS$_j@DT>";
      k[30] = "bi\u0019&/Ak/\u0014&\u0010Bj|\u001bz\u001aLno\u0011z%";
      k[31] = "tez5C{}#w5|x|pxi";
      k[32] = "Y\u0017 &iTR\u00181i\bZY\u001353";
      k[33] = "AG~J3\u0002JHo\u0005[\u0002DG|";
      k[34] = "\fu.MXl\t`%M[k\u0006i.\u000f\u001a\\/";
      k[35] = "\u001de*\u000687\u0003~:\u0004Y\u001f:T\t2\u0005\u0007\u0002n4\u001e$*\u0013T*\u0003=,\u0013y\u0013\u000b?1\u0005d8\u0018>(\u001fhDR'*\u0013z|\u0010b5\u001a";
      k[36] = "chRI\u0013 2iJ\u001fs:.b]F+<)k6\u0014\u0010%>kWE\u0011=h\u000b";
      k[37] = "\r\u0005b\u0000\f)\u0018\u0005h\u0011=\u007f\u0000{4\nPj\rH4)\\h\u0001]!l\u0000j\u001f\t)\u000bZ!\u0015IYPFh\u0006X&\rQq\u001a4";
      k[38] = "qY\"\u0014\b\u001c3\u001e)[k\u001f%L?`\u000f\u0001\u0002T/D\u0010erCcC\u0004\u0003.K?\u0015k";
      k[39] = "\u0016{q2@kA{d1{t\u001bCu=\u0017Q\u0002gz6\u0001\u001bBsof\u000b|\u00188e&{&\u0005r)+\u001c|Nxi[G`\u0007kx$\u001aw\u001ew\u0014";
      k[40] = "\u0001\u0017>\u001e\u001cDP\u0005{LcBj\u0016!\u001f\r\u0013\u0011JzD\u0004+\u0001\u0017>\u001e\u001cDP\u0005{Lc";
      k[41] = "7k3d_A3}#pfT`k\u0015y\u000f@vS9t\nVw\u0017er\u001aAlrc~\u001b\u0003\r";
      k[42] = "0X\u001cadKf\u001fH(\u001b@&\r\u0010\u000fuR;\u0003\f\"vl \n\u0018#|]ZZ\u001d!y\u0001k\b\u001e &;";
      k[43] = "\u0002;\u0004<j-\u00047\u0005~\u000b'T(\"+p/D.\u0013+B3b(\u0002+b-9i\u0014?ir\b;\u0017>6H\u0000(\t{h1Bo\u00024\u000b";
      k[44] = "@V\u0011\t\u0004A\u0011DT[{B+W\u000e\b\u0015\u0016P\u000bUS\u001c.\u0017N\u0012\u0000\u0017QJY\u000b\u001c{";
      k[45] = "\u0017\u0018|\u0006YX\u0004L(\u00023B\u0018D\u0016P]@EA(Z\n^\u001a\"xPT\u001b\u001a\u001cr\u0007JDyLxY\u000fDGF/GP'";
      k[46] = "heGTH\"ib\u0005F*)V'OA\u001721}\u0004KWB";
      k[47] = "GE\u0018]\u0003B\u0016W]\u000f|G,D\u0007\\\u0012\u0015W\u0018\\\u0007\u001b-\u0010]\u001bT\u0010RMJ\u0002H|";
      k[48] = ")_Ji-_q\u000bM>L\tz\t)*4\u0018l\b\t,!\f\u0016ZHor\u0001)\u0002\u001ch%`*\u001e\n5 \u001fw\t\u0013)L";
      k[49] = "u+.BI\u0011!7#Q7\u0013w7\"-\n\u001eh;\u007f\u001cX\u001didEH\t\u000fha8\u0015T\u001bpYyVO\u0010}&$AV\f\u0011";
      k[50] = "{-Q6Y</1\\%'>y1]Y\u001a3f=\u0000hH0gb:e\\'}3E8K>a_";
      k[51] = "(r\u001d,\u001e\"d1X,u7\u0018)A-\u001bdcu\u001av\u0012\\s(^,\n3\":\u001b~u";
      k[52] = "-\u0015`_C%!\blJ-'&/`S@,\u0019\u000bfY@)BJ{X\u00108%\u00100RPH\u007f\rz\u001e]/%Fp^-t9\u000fcOR).\u0016\u007f#";
      k[53] = "\"\u0018:\u0012 V.\u00056\u0007NT)&6\u001e\u0016R7\u0013>\u00032V7\u001b[S4@p\n<\t\u007fJ0zf\u00145\u0006=\u001d<_?FMG!\u0015sK*\u001dj\u001f3;q\u0001#\f\"D,\u0016:\u0010N";
      k[54] = "sAh|\u0014z?\u0002-|\u007fmC\u001a4}\u0011<8Fo&\u0018\u0004$\u0011!sDz*\u001da\u0017";
      k[55] = "\tq!t~j[r +D Iw#j>:RrX+> \tm?qu*I\u001dez=9\u000e,7y<f4";
      k[56] = "v\fODPv'\u001e\n\u0016/t\u001d\rPEA!fQ\u000b\u001eH\u0019!\u0014LMCf|\u0003UQ/";
      k[57] = "\u0003s\u0002\u001b\u0007{O0G\u001bll3u\u0000HRd\f-TO\u0005\u0005\fp\u0002N\r:T$\u0005\u0019l";
      k[58] = "\u0018\u001fYD\u000bzJ\u001cX\u001b10Y\u001aZZJ\u0014D\u000f@&\f'\\\u0011\u001a\u0017^$]N \u0016O1H\n\u0018T\n.As";
      k[59] = "a,\u001c/\"\u0015zs\u0014&L\u0000j46+4\u0006m)\u0019#0\u000ej3}!*\u0001c)\u001a?1\u0011aH";
      k[60] = "\ru\b\u0012\n\r\u0001h\u0004\u0007d\u000f\u0006X\u0004\u0012*\u0004\u0005~\u0015nY\u001a\u0019*\u0019\t\u0003Q\u0013ji\u0000\n\u0007^tW\n]\u0019\u0001\u0017";
      k[61] = "R.\u0004]\u001dF\\\"D9^EIGO_\u0016RZ!\u0013WJ\u00045 \u001cHB\u0003K.\u0010\b&";
      k[62] = "@\\\u0001\u001b\u0010*NPA\u007fE0FMp\u0018B%C\u000e\u000e\u0016Ne'";
      k[63] = "mF`\u0011a\u001b;\u00014X\u001e\u0010{\u0013l\u007fz\fn\u0015ZFd\fb.hE{\f}\b\rOw\u001acBsA{Z\u0007\u0012<L~\u0007c\u0002iI\"klHiHr\u000f|\u001dl\u0014\u001e\u00006\u001dmDz\u0010c\u00181(#\u0011|D}OyZv\u0004\rOw\u001acBsA{Z\u0007";
      k[64] = "\u0018;\u0016cF\u0007\u00109\u00176v\u0001\u0011}l=\u0019\u0001\u0011{(`\n\u0003\u00058Rd\u001c\u0013\u0011\u0001L(\u001d\u0001\u0002b\u00184\u0010\u0012|";
      k[65] = "#A\u0018\r-\u001ba\u0006\u0013BN\t~Z\u0012]N^aE\u000b\\1\u0003v\\\u00170";
      k[66] = "\u0018s\u0012\\LdIr\n\n,`@t\u0012WGDOlv\rV~\u0014`\u0011W\u001dtT\u0010\u001d\u0001HeEt\rTM9)";
      k[67] = "t7c\u000fjW%6{Y\n]!3|\u000e\n\n>,e\u000fuW)5yc";
      k[68] = "S\u0004~bC!]\b>\u0006\u0011;P\ndo\u00042x\fuk\u0013#4Pu}E/S\n>w\u0005_S\u0004~bC!]\b>\u0006";
      k[69] = "cd\u001c2tZoy\u0010'\u001aXhL\u001c(vkav\u00013`Z\f;\u00075'GkaL?g71|\u0006sjPk7\f3\u001a\u000bw~\u001f\"eV`g\u0003N";
      k[70] = "sv\u0014\u0003H\u0018\u007fk\u0018\u0016&\u001axH\u0018\u000f~\u001cf}\u0010\u0012Z\u0018fzuB\\\u000e!d\u0012\u0018\u0017\u0004a\u0014H\u0005]Hls\u0012NW\b\u001cz\u001b\u0018\u001a\u0016\"pL\u0006Eu o\r\u001dJ\n}x\u0014\u0001&";
      k[71] = "708z>X'e=&RS1}\\'(Gaq;}cM!\u0001a`)\u0001,f;+#A\\";
      k[72] = "\u0016\\$]N\u001a\r]'\u001c/\u0014\u0019\u0006&Lh\u0004p\f5F\u0013\tN\u0006bXLj\u0016\\$]N\u001a\r]'\u001c/";
      k[73] = "8)\u001e9U<6%^]\u0014/:)\u000e;\u000f$0@R'\u0015\u007f/'\bl\u001f?_";
      k[74] = "\u0015J?\u0011 \u001dC\rkX_\u0016\u0003\u001f3\u007f>\b\u0016\u001a?\u007f1\u0017\u0012\u0018RO6\u001c\u001bN,A:\\\u007fI)P=\u0001\u0000\u0014>I!m";
      k[75] = "Ag\u000fVRw\u0010uJ\u0004-s*f\u0010WC Q:K\fJ\u0018\u0016\u007f\f_AgKh\u0015C-";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(2253653277828282L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(2253653277828282L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(2253653277828282L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 199;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 244;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 90;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 232;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 219;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 121;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 199;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 244;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 90;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dh_C0180",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dh" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static ManagedGlTexture invokeBinding1(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache1;
         MethodHandle var8 = bindingCache1;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache1 = c(
                  MethodHandles.lookup(), "y", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ldev/zprestige/prestige/bT_C0095;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (ManagedGlTexture)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
