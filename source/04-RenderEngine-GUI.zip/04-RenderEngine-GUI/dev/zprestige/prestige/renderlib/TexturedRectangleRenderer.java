package dev.zprestige.prestige.renderlib;
import dev.zprestige.prestige.renderlib.state.BlendFunctionState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.MeshDataConsumer;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;

public class TexturedRectangleRenderer extends PrimitiveRenderer {
   private static final TexturedRectangleRenderer a;
   private static final Map b;
   private final int c;
   private final int d;
   private static final long e = 1045094376700L;
   private static final String[] f;
   private static final String[] g;
   private static final Map h = new HashMap(13);
   private static final long[] i;
   private static final Integer[] j;
   private static final Map k;
   private static final Object[] l = new Object[102];
   private static final String[] m = new String[102];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;

   private TexturedRectangleRenderer(long var1) {
      super("shaders/rounded_texture.vert", "shaders/rounded_texture.frag", ((1045094376700L ^ (1045094376700L ^ var1)) ^ 109570912584985L));
      var1 = 1045094376700L ^ var1;
      long var3 = var1 ^ 49767094643590L;
      long var5 = var1 ^ 109570912584985L;
      long var7 = var1 ^ 53351630349243L;
      short var10001 = 15366;
      long var10002 = 6003305228312789134L ^ var1;
      short var25 = 23710;
      long var10003 = 1207490495173926932L ^ var1;

      Object[] var10 = new Object[0];
      TexturedRectangleRenderer var9 = this;
      GlProgram var22 = var9.aReturningfM_C0295(var10);
      short var26 = 24549;
      var10003 = 5429531982176592750L ^ var1;
      Object[] var12 = new Object[]{"tintMode", var3};
      GlProgram var11 = var22;
      this.c = var11.dReturningInt(var12);
      Object[] var14 = new Object[0];
      TexturedRectangleRenderer var13 = this;
      GlProgram var23 = var13.aReturningfM_C0295(var14);
      short var27 = 26656;
      var10003 = 3198894955169060014L ^ var1;
      Object[] var16 = new Object[]{"roundness", var3};
      GlProgram var15 = var23;
      this.d = var15.dReturningInt(var16);
      Object[] var18 = new Object[0];
      TexturedRectangleRenderer var17 = this;
      GlProgram var10000 = var17.aReturningfM_C0295(var18);
      var10001 = 6209;
      var10002 = 9044558808156431560L ^ var1;
      Object[] var10005 = new Object[]{null, null, var7};
      var10005[1] = 0;
      var10005[0] = "texSampler";
      Object[] var20 = var10005;
      GlProgram var19 = var10000;
      var19.aReturningVoid(var20);
   }

   public static void aReturningVoid(Object[] var0) {
      MeshBufferManager var2 = (MeshBufferManager)var0[0];
      RenderContext var4 = (RenderContext)var0[1];
      ManagedGlTexture var3 = (ManagedGlTexture)var0[2];
      float var5 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var6 = (Float)var0[6];
      long var8 = (Long)var0[7];
      var8 = 1045094376700L ^ var8;
      long var10 = var8 ^ 93247195949048L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{
         null, null, null, null, null, null, null, null, new Vector4f(0.0F), invokeBinding1(-8327233591574341452L, var8), TextureTintMode.MULTIPLY, var10
      };
      var10014[7] = var6;
      var10014[6] = var7;
      var10014[5] = var1;
      var10014[4] = var5;
      var10014[3] = var3;
      var10014[2] = var10003;
      var10014[1] = var4;
      var10014[0] = var2;
      invokeBinding2(var10000, var10014, -8326862557509037036L, var8);
   }

   public static void bReturningVoid(Object[] var0) {
      MeshBufferManager var3 = (MeshBufferManager)var0[0];
      RenderContext var2 = (RenderContext)var0[1];
      ManagedGlTexture var1 = (ManagedGlTexture)var0[2];
      float var9 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var5 = (Float)var0[5];
      float var4 = (Float)var0[6];
      Color var8 = (Color)var0[7];
      long var6 = (Long)var0[8];
      var6 = 1045094376700L ^ var6;
      long var11 = var6 ^ 60771949805369L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(0.0F), var8, TextureTintMode.MULTIPLY, var11};
      var10014[7] = var4;
      var10014[6] = var5;
      var10014[5] = var10;
      var10014[4] = var9;
      var10014[3] = var1;
      var10014[2] = var10003;
      var10014[1] = var2;
      var10014[0] = var3;
      invokeBinding3(var10000, var10014, -3120879006045762347L, var6);
   }

   public static void cReturningVoid(Object[] var0) {
      MeshBufferManager var1 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      Matrix4f var8 = (Matrix4f)var0[2];
      ManagedGlTexture var2 = (ManagedGlTexture)var0[3];
      float var6 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var3 = (Float)var0[6];
      float var10 = (Float)var0[7];
      Color var11 = (Color)var0[8];
      long var4 = (Long)var0[9];
      var4 = 1045094376700L ^ var4;
      long var12 = var4 ^ 13210520170765L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(0.0F), var11, TextureTintMode.MULTIPLY, var12};
      var10014[7] = var10;
      var10014[6] = var3;
      var10014[5] = var7;
      var10014[4] = var6;
      var10014[3] = var2;
      var10014[2] = var8;
      var10014[1] = var9;
      var10014[0] = var1;
      Object[] var15 = var10014;
      TexturedRectangleRenderer var14 = var10000;
      var14.y(var15);
   }

   public static void dReturningVoid(Object[] var0) {
      MeshBufferManager var8 = (MeshBufferManager)var0[0];
      RenderContext var7 = (RenderContext)var0[1];
      ManagedGlTexture var11 = (ManagedGlTexture)var0[2];
      float var2 = (Float)var0[3];
      float var9 = (Float)var0[4];
      float var3 = (Float)var0[5];
      float var1 = (Float)var0[6];
      Matrix4f var10 = (Matrix4f)var0[7];
      Color var4 = (Color)var0[8];
      long var5 = (Long)var0[9];
      var5 = 1045094376700L ^ var5;
      long var12 = var5 ^ 22144836295508L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(0.0F), var4, TextureTintMode.MULTIPLY, var12};
      var10014[7] = var1;
      var10014[6] = var3;
      var10014[5] = var9;
      var10014[4] = var2;
      var10014[3] = var11;
      var10014[2] = var10;
      var10014[1] = var7;
      var10014[0] = var8;
      Object[] var15 = var10014;
      TexturedRectangleRenderer var14 = var10000;
      var14.y(var15);
   }

   public static void eReturningVoid(Object[] var0) {
      MeshBufferManager var4 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[2];
      float var6 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var5 = (Float)var0[5];
      float var8 = (Float)var0[6];
      float var7 = (Float)var0[7];
      long var2 = (Long)var0[8];
      var2 = 1045094376700L ^ var2;
      long var11 = var2 ^ 3905790996450L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{
         null, null, null, null, null, null, null, null, new Vector4f(var7), invokeBinding4(-4290260936700751698L, var2), TextureTintMode.MULTIPLY, var11
      };
      var10014[7] = var8;
      var10014[6] = var5;
      var10014[5] = var1;
      var10014[4] = var6;
      var10014[3] = var10;
      var10014[2] = var10003;
      var10014[1] = var9;
      var10014[0] = var4;
      invokeBinding5(var10000, var10014, -4293234617330623474L, var2);
   }

   public static void fReturningVoid(Object[] var0) {
      MeshBufferManager var3 = (MeshBufferManager)var0[0];
      RenderContext var6 = (RenderContext)var0[1];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[2];
      float var7 = (Float)var0[3];
      float var11 = (Float)var0[4];
      float var8 = (Float)var0[5];
      float var9 = (Float)var0[6];
      float var5 = (Float)var0[7];
      Color var4 = (Color)var0[8];
      long var1 = (Long)var0[9];
      var1 = 1045094376700L ^ var1;
      long var12 = var1 ^ 106068016475887L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var5), var4, TextureTintMode.MULTIPLY, var12};
      var10014[7] = var9;
      var10014[6] = var8;
      var10014[5] = var11;
      var10014[4] = var7;
      var10014[3] = var10;
      var10014[2] = var10003;
      var10014[1] = var6;
      var10014[0] = var3;
      invokeBinding6(var10000, var10014, -8834305285278376701L, var1);
   }

   public static void gReturningVoid(Object[] var0) {
      MeshBufferManager var9 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[2];
      float var7 = (Float)var0[3];
      float var2 = (Float)var0[4];
      float var3 = (Float)var0[5];
      float var8 = (Float)var0[6];
      Vector4f var6 = (Vector4f)var0[7];
      long var4 = (Long)var0[8];
      var4 = 1045094376700L ^ var4;
      long var11 = var4 ^ 62664431195401L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{
         null, null, null, null, null, null, null, null, var6, invokeBinding7(9123964211239987781L, var4), TextureTintMode.MULTIPLY, var11
      };
      var10014[7] = var8;
      var10014[6] = var3;
      var10014[5] = var2;
      var10014[4] = var7;
      var10014[3] = var10;
      var10014[2] = var10003;
      var10014[1] = var1;
      var10014[0] = var9;
      invokeBinding8(var10000, var10014, 9115398551377585893L, var4);
   }

   public static void hReturningVoid(Object[] var0) {
      MeshBufferManager var4 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      ManagedGlTexture var1 = (ManagedGlTexture)var0[2];
      float var5 = (Float)var0[3];
      float var6 = (Float)var0[4];
      float var8 = (Float)var0[5];
      float var2 = (Float)var0[6];
      Vector4f var11 = (Vector4f)var0[7];
      Color var7 = (Color)var0[8];
      long var9 = (Long)var0[9];
      var9 = 1045094376700L ^ var9;
      long var12 = var9 ^ 101141940220366L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, var11, var7, TextureTintMode.MULTIPLY, var12};
      var10014[7] = var2;
      var10014[6] = var8;
      var10014[5] = var6;
      var10014[4] = var5;
      var10014[3] = var1;
      var10014[2] = var10003;
      var10014[1] = var3;
      var10014[0] = var4;
      invokeBinding9(var10000, var10014, 1893488409502728738L, var9);
   }

   public static void iReturningVoid(Object[] var0) {
      MeshBufferManager var1 = (MeshBufferManager)var0[0];
      RenderContext var6 = (RenderContext)var0[1];
      Matrix4f var10 = (Matrix4f)var0[2];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[3];
      float var9 = (Float)var0[4];
      float var3 = (Float)var0[5];
      float var2 = (Float)var0[6];
      float var11 = (Float)var0[7];
      Vector4f var4 = (Vector4f)var0[8];
      long var7 = (Long)var0[9];
      var7 = 1045094376700L ^ var7;
      long var12 = var7 ^ 70357553159348L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10014 = new Object[]{
         null, null, null, null, null, null, null, null, var4, invokeBinding10(-5250121737151323144L, var7), TextureTintMode.MULTIPLY, var12
      };
      var10014[7] = var11;
      var10014[6] = var2;
      var10014[5] = var3;
      var10014[4] = var9;
      var10014[3] = var5;
      var10014[2] = var10;
      var10014[1] = var6;
      var10014[0] = var1;
      invokeBinding11(var10000, var10014, -5242926996754305192L, var7);
   }

   public static void jReturningVoid(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      Matrix4f var12 = (Matrix4f)var0[2];
      ManagedGlTexture var8 = (ManagedGlTexture)var0[3];
      float var4 = (Float)var0[4];
      float var11 = (Float)var0[5];
      float var9 = (Float)var0[6];
      float var3 = (Float)var0[7];
      Vector4f var7 = (Vector4f)var0[8];
      Color var2 = (Color)var0[9];
      long var5 = (Long)var0[10];
      var5 = 1045094376700L ^ var5;
      long var13 = var5 ^ 136147686099887L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, var7, var2, TextureTintMode.MULTIPLY, var13};
      var10014[7] = var3;
      var10014[6] = var9;
      var10014[5] = var11;
      var10014[4] = var4;
      var10014[3] = var8;
      var10014[2] = var12;
      var10014[1] = var1;
      var10014[0] = var10;
      invokeBinding12(var10000, var10014, -6906791735940712381L, var5);
   }

   public static void kReturningVoid(Object[] var0) {
      MeshBufferManager var5 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      ManagedGlTexture var12 = (ManagedGlTexture)var0[2];
      float var6 = (Float)var0[3];
      float var8 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var13 = (Float)var0[6];
      float var10 = (Float)var0[7];
      float var11 = (Float)var0[8];
      Color var2 = (Color)var0[9];
      float var1 = (Float)var0[10];
      long var3 = (Long)var0[11];
      var3 = 1045094376700L ^ var3;
      long var14 = var3 ^ 16030516593622L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10011 = invokeBinding13(var2, 4695191445148490276L, var3);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, new Vector4f(var1), TextureTintMode.MULTIPLY, var14};
      var10016[10] = var10011;
      var10016[9] = var11;
      var10016[8] = var10;
      var10016[7] = var13;
      var10016[6] = var7;
      var10016[5] = var8;
      var10016[4] = var6;
      var10016[3] = var12;
      var10016[2] = var10003;
      var10016[1] = var9;
      var10016[0] = var5;
      invokeBinding14(var10000, var10016, 4694128831775463163L, var3);
   }

   public static void lReturningVoid(Object[] var0) {
      MeshBufferManager var13 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      ManagedGlTexture var6 = (ManagedGlTexture)var0[2];
      float var11 = (Float)var0[3];
      float var8 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var5 = (Float)var0[6];
      float var1 = (Float)var0[7];
      float var2 = (Float)var0[8];
      Color var12 = (Color)var0[9];
      Vector4f var4 = (Vector4f)var0[10];
      long var9 = (Long)var0[11];
      var9 = 1045094376700L ^ var9;
      long var14 = var9 ^ 29336779257388L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10011 = invokeBinding15(var12, 8418001229949857758L, var9);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, var4, TextureTintMode.MULTIPLY, var14};
      var10016[10] = var10011;
      var10016[9] = var2;
      var10016[8] = var1;
      var10016[7] = var5;
      var10016[6] = var7;
      var10016[5] = var8;
      var10016[4] = var11;
      var10016[3] = var6;
      var10016[2] = var10003;
      var10016[1] = var3;
      var10016[0] = var13;
      invokeBinding16(var10000, var10016, 8421433849561768705L, var9);
   }

   public static void mReturningVoid(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var14 = (RenderContext)var0[1];
      Matrix4f var8 = (Matrix4f)var0[2];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[3];
      float var13 = (Float)var0[4];
      float var3 = (Float)var0[5];
      float var11 = (Float)var0[6];
      float var6 = (Float)var0[7];
      float var7 = (Float)var0[8];
      float var9 = (Float)var0[9];
      Color var12 = (Color)var0[10];
      float var4 = (Float)var0[11];
      long var1 = (Long)var0[12];
      var1 = 1045094376700L ^ var1;
      long var15 = var1 ^ 87886791980199L;
      TexturedRectangleRenderer var10000 = a;
      Color var17 = var12;
      int var10011 = var17.getRGB();
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, new Vector4f(var4), TextureTintMode.MULTIPLY, var15};
      var10016[10] = var10011;
      var10016[9] = var9;
      var10016[8] = var7;
      var10016[7] = var6;
      var10016[6] = var11;
      var10016[5] = var3;
      var10016[4] = var13;
      var10016[3] = var5;
      var10016[2] = var8;
      var10016[1] = var14;
      var10016[0] = var10;
      Object[] var19 = var10016;
      TexturedRectangleRenderer var18 = var10000;
      var18.G(var19);
   }

   public static void nReturningVoid(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      Matrix4f var11 = (Matrix4f)var0[2];
      ManagedGlTexture var5 = (ManagedGlTexture)var0[3];
      float var3 = (Float)var0[4];
      float var4 = (Float)var0[5];
      float var12 = (Float)var0[6];
      float var1 = (Float)var0[7];
      float var2 = (Float)var0[8];
      float var6 = (Float)var0[9];
      Color var10 = (Color)var0[10];
      Vector4f var8 = (Vector4f)var0[11];
      long var13 = (Long)var0[12];
      var13 = 1045094376700L ^ var13;
      long var15 = var13 ^ 63734282417801L;
      TexturedRectangleRenderer var10000 = a;
      int var10011 = invokeBinding17(var10, 8392348905491885947L, var13);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, var8, TextureTintMode.MULTIPLY, var15};
      var10016[10] = var10011;
      var10016[9] = var6;
      var10016[8] = var2;
      var10016[7] = var1;
      var10016[6] = var12;
      var10016[5] = var4;
      var10016[4] = var3;
      var10016[3] = var5;
      var10016[2] = var11;
      var10016[1] = var9;
      var10016[0] = var7;
      invokeBinding18(var10000, var10016, 8393533427249931172L, var13);
   }

   public static void o(Object[] var0) {
      MeshBufferManager var2 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      Matrix4f var9 = (Matrix4f)var0[2];
      ManagedGlTexture var16 = (ManagedGlTexture)var0[3];
      float var12 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var6 = (Float)var0[6];
      float var14 = (Float)var0[7];
      float var5 = (Float)var0[8];
      float var18 = (Float)var0[9];
      Color var13 = (Color)var0[10];
      Color var4 = (Color)var0[11];
      Color var8 = (Color)var0[12];
      Color var15 = (Color)var0[13];
      float var1 = (Float)var0[14];
      boolean var17 = (Boolean)var0[15];
      long var10 = (Long)var0[16];
      var10 = 1045094376700L ^ var10;
      long var19 = var10 ^ 100999489647451L;
      TexturedRectangleRenderer var10000 = a;
      Color var21 = var13;
      int var10011 = var21.getRGB();
      Color var22 = var4;
      int var10012 = var22.getRGB();
      Color var23 = var8;
      int var10013 = var23.getRGB();
      Color var24 = var15;
      int var10014 = var24.getRGB();
      Vector4f var10015 = new Vector4f(var1);
      Object[] var10020 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, TextureTintMode.MULTIPLY, var19};
      var10020[15] = var17;
      var10020[14] = var10015;
      var10020[13] = var10014;
      var10020[12] = var10013;
      var10020[11] = var10012;
      var10020[10] = var10011;
      var10020[9] = var18;
      var10020[8] = var5;
      var10020[7] = var14;
      var10020[6] = var6;
      var10020[5] = var7;
      var10020[4] = var12;
      var10020[3] = var16;
      var10020[2] = var9;
      var10020[1] = var3;
      var10020[0] = var2;
      Object[] var26 = var10020;
      TexturedRectangleRenderer var25 = var10000;
      var25.H(var26);
   }

   public static void p(Object[] var0) {
      MeshBufferManager var6 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[2];
      float var5 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var9 = (Float)var0[5];
      float var4 = (Float)var0[6];
      Color var2 = (Color)var0[7];
      TextureTintMode var11 = (TextureTintMode)var0[8];
      long var7 = (Long)var0[9];
      var7 = 1045094376700L ^ var7;
      long var12 = var7 ^ 8460619214344L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(0.0F), var2, var11, var12};
      var10014[7] = var4;
      var10014[6] = var9;
      var10014[5] = var1;
      var10014[4] = var5;
      var10014[3] = var10;
      var10014[2] = var10003;
      var10014[1] = var3;
      var10014[0] = var6;
      invokeBinding19(var10000, var10014, -4214988956696961564L, var7);
   }

   public static void q(Object[] var0) {
      MeshBufferManager var8 = (MeshBufferManager)var0[0];
      RenderContext var6 = (RenderContext)var0[1];
      ManagedGlTexture var11 = (ManagedGlTexture)var0[2];
      float var2 = (Float)var0[3];
      float var12 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var4 = (Float)var0[6];
      float var1 = (Float)var0[7];
      Color var5 = (Color)var0[8];
      TextureTintMode var3 = (TextureTintMode)var0[9];
      long var9 = (Long)var0[10];
      var9 = 1045094376700L ^ var9;
      long var13 = var9 ^ 119600456394208L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, new Vector4f(var1), var5, var3, var13};
      var10014[7] = var4;
      var10014[6] = var7;
      var10014[5] = var12;
      var10014[4] = var2;
      var10014[3] = var11;
      var10014[2] = var10003;
      var10014[1] = var6;
      var10014[0] = var8;
      invokeBinding20(var10000, var10014, -3573269203250702836L, var9);
   }

   public static void r(Object[] var0) {
      MeshBufferManager var11 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      ManagedGlTexture var2 = (ManagedGlTexture)var0[2];
      float var6 = (Float)var0[3];
      float var10 = (Float)var0[4];
      float var8 = (Float)var0[5];
      float var5 = (Float)var0[6];
      Vector4f var12 = (Vector4f)var0[7];
      Color var7 = (Color)var0[8];
      TextureTintMode var9 = (TextureTintMode)var0[9];
      long var3 = (Long)var0[10];
      var3 = 1045094376700L ^ var3;
      long var13 = var3 ^ 69166244268041L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, var12, var7, var9, var13};
      var10014[7] = var5;
      var10014[6] = var8;
      var10014[5] = var10;
      var10014[4] = var6;
      var10014[3] = var2;
      var10014[2] = var10003;
      var10014[1] = var1;
      var10014[0] = var11;
      invokeBinding21(var10000, var10014, -6665221097220572187L, var3);
   }

   public static void s(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      Matrix4f var8 = (Matrix4f)var0[2];
      ManagedGlTexture var7 = (ManagedGlTexture)var0[3];
      float var13 = (Float)var0[4];
      float var4 = (Float)var0[5];
      float var1 = (Float)var0[6];
      float var11 = (Float)var0[7];
      Vector4f var5 = (Vector4f)var0[8];
      Color var6 = (Color)var0[9];
      TextureTintMode var12 = (TextureTintMode)var0[10];
      long var2 = (Long)var0[11];
      var2 = 1045094376700L ^ var2;
      long var14 = var2 ^ 108162396072097L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, var5, var6, var12, var14};
      var10014[7] = var11;
      var10014[6] = var1;
      var10014[5] = var4;
      var10014[4] = var13;
      var10014[3] = var7;
      var10014[2] = var8;
      var10014[1] = var9;
      var10014[0] = var10;
      invokeBinding22(var10000, var10014, 227497813467192141L, var2);
   }

   public static void t(Object[] var0) {
      MeshBufferManager var5 = (MeshBufferManager)var0[0];
      RenderContext var1 = (RenderContext)var0[1];
      ManagedGlTexture var11 = (ManagedGlTexture)var0[2];
      float var3 = (Float)var0[3];
      float var8 = (Float)var0[4];
      float var10 = (Float)var0[5];
      float var9 = (Float)var0[6];
      float var12 = (Float)var0[7];
      float var6 = (Float)var0[8];
      Color var7 = (Color)var0[9];
      float var4 = (Float)var0[10];
      TextureTintMode var2 = (TextureTintMode)var0[11];
      long var13 = (Long)var0[12];
      var13 = 1045094376700L ^ var13;
      long var15 = var13 ^ 53187835166063L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10011 = invokeBinding23(var7, 9192292648071554205L, var13);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, new Vector4f(var4), var2, var15};
      var10016[10] = var10011;
      var10016[9] = var6;
      var10016[8] = var12;
      var10016[7] = var9;
      var10016[6] = var10;
      var10016[5] = var8;
      var10016[4] = var3;
      var10016[3] = var11;
      var10016[2] = var10003;
      var10016[1] = var1;
      var10016[0] = var5;
      invokeBinding24(var10000, var10016, 9195747386706585666L, var13);
   }

   public static void u(Object[] var0) {
      MeshBufferManager var11 = (MeshBufferManager)var0[0];
      RenderContext var3 = (RenderContext)var0[1];
      ManagedGlTexture var4 = (ManagedGlTexture)var0[2];
      float var13 = (Float)var0[3];
      float var6 = (Float)var0[4];
      float var9 = (Float)var0[5];
      float var8 = (Float)var0[6];
      float var14 = (Float)var0[7];
      float var10 = (Float)var0[8];
      Color var5 = (Color)var0[9];
      Vector4f var12 = (Vector4f)var0[10];
      TextureTintMode var7 = (TextureTintMode)var0[11];
      long var1 = (Long)var0[12];
      var1 = 1045094376700L ^ var1;
      long var15 = var1 ^ 19307253294580L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      int var10011 = invokeBinding25(var5, 7424945558386736134L, var1);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, var12, var7, var15};
      var10016[10] = var10011;
      var10016[9] = var10;
      var10016[8] = var14;
      var10016[7] = var8;
      var10016[6] = var9;
      var10016[5] = var6;
      var10016[4] = var13;
      var10016[3] = var4;
      var10016[2] = var10003;
      var10016[1] = var3;
      var10016[0] = var11;
      invokeBinding26(var10000, var10016, 7423896285174001881L, var1);
   }

   public static void v(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var12 = (RenderContext)var0[1];
      Matrix4f var8 = (Matrix4f)var0[2];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[3];
      float var9 = (Float)var0[4];
      float var5 = (Float)var0[5];
      float var3 = (Float)var0[6];
      float var15 = (Float)var0[7];
      float var11 = (Float)var0[8];
      float var6 = (Float)var0[9];
      Color var2 = (Color)var0[10];
      Vector4f var1 = (Vector4f)var0[11];
      TextureTintMode var4 = (TextureTintMode)var0[12];
      long var13 = (Long)var0[13];
      var13 = 1045094376700L ^ var13;
      long var16 = var13 ^ 137725655786784L;
      TexturedRectangleRenderer var10000 = a;
      int var10011 = invokeBinding27(var2, 2872971557346622674L, var13);
      Object[] var10016 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, var1, var4, var16};
      var10016[10] = var10011;
      var10016[9] = var6;
      var10016[8] = var11;
      var10016[7] = var15;
      var10016[6] = var3;
      var10016[5] = var5;
      var10016[4] = var9;
      var10016[3] = var10;
      var10016[2] = var8;
      var10016[1] = var12;
      var10016[0] = var7;
      invokeBinding28(var10000, var10016, 2869521509046562829L, var13);
   }

   public static void w(Object[] var0) {
      MeshBufferManager var9 = (MeshBufferManager)var0[0];
      RenderContext var12 = (RenderContext)var0[1];
      ManagedGlTexture var3 = (ManagedGlTexture)var0[2];
      float var2 = (Float)var0[3];
      float var13 = (Float)var0[4];
      float var1 = (Float)var0[5];
      float var10 = (Float)var0[6];
      Color var15 = (Color)var0[7];
      Color var4 = (Color)var0[8];
      Color var11 = (Color)var0[9];
      Color var8 = (Color)var0[10];
      float var5 = (Float)var0[11];
      TextureTintMode var14 = (TextureTintMode)var0[12];
      long var6 = (Long)var0[13];
      var6 = 1045094376700L ^ var6;
      long var16 = var6 ^ 31625126975754L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10017 = new Object[]{null, null, null, null, null, null, null, null, var15, var4, var11, var8, new Vector4f(var5), var14, var16};
      var10017[7] = var10;
      var10017[6] = var1;
      var10017[5] = var13;
      var10017[4] = var2;
      var10017[3] = var3;
      var10017[2] = var10003;
      var10017[1] = var12;
      var10017[0] = var9;
      invokeBinding29(var10000, var10017, 5483660371736877541L, var6);
   }

   public static void x(Object[] var0) {
      MeshBufferManager var6 = (MeshBufferManager)var0[0];
      RenderContext var2 = (RenderContext)var0[1];
      ManagedGlTexture var11 = (ManagedGlTexture)var0[2];
      float var7 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var13 = (Float)var0[5];
      float var5 = (Float)var0[6];
      Color var14 = (Color)var0[7];
      Color var8 = (Color)var0[8];
      Color var10 = (Color)var0[9];
      Color var9 = (Color)var0[10];
      Vector4f var12 = (Vector4f)var0[11];
      TextureTintMode var15 = (TextureTintMode)var0[12];
      long var3 = (Long)var0[13];
      var3 = 1045094376700L ^ var3;
      long var16 = var3 ^ 8267920273726L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10017 = new Object[]{null, null, null, null, null, null, null, null, var14, var8, var10, var9, var12, var15, var16};
      var10017[7] = var5;
      var10017[6] = var13;
      var10017[5] = var1;
      var10017[4] = var7;
      var10017[3] = var11;
      var10017[2] = var10003;
      var10017[1] = var2;
      var10017[0] = var6;
      invokeBinding30(var10000, var10017, -6616355975240240687L, var3);
   }

   private void y(Object[] var1) {
      Matrix4f var11 = (Matrix4f)var1[2];
      ManagedGlTexture var14 = (ManagedGlTexture)var1[3];
      float var3 = (Float)var1[4];
      float var9 = (Float)var1[5];
      float var2 = (Float)var1[6];
      float var8 = (Float)var1[7];
      Vector4f var12 = (Vector4f)var1[8];
      Color var13 = (Color)var1[9];
      TextureTintMode var5 = (TextureTintMode)var1[10];
      long var6 = (Long)var1[11];
      var6 = 1045094376700L ^ var6;
      long var15 = var6 ^ 87627550851177L;
      long var17 = var6 ^ 37712107634874L;
      Object[] var10007 = new Object[]{null, null, null, null, var15};
      var10007[3] = true;
      var10007[2] = var5;
      var10007[1] = var12;
      var10007[0] = var14;
      Object[] var21 = var10007;
      TexturedRectangleRenderer var20 = this;
      DrawPipeline var19 = var20.aReturningdn_C0192(var21);
      AtomicReference var22 = ShapeRenderer.a;
      RenderCommandBatcher var10000 = (RenderCommandBatcher)var22.get();
      Object[] var24 = new Object[]{new PipelineRenderCommand(var19, invokeBinding31(var13, var11, var3, var9, var8, var2)), var17};
      RenderCommandBatcher var23 = var10000;
      var23.bReturningVoid(var24);
   }

   private void z(Object[] var1) {
      Matrix4f var5 = (Matrix4f)var1[2];
      ManagedGlTexture var13 = (ManagedGlTexture)var1[3];
      float var16 = (Float)var1[4];
      float var17 = (Float)var1[5];
      float var9 = (Float)var1[6];
      float var12 = (Float)var1[7];
      float var8 = (Float)var1[8];
      float var18 = (Float)var1[9];
      float var14 = (Float)var1[10];
      float var11 = (Float)var1[11];
      Vector4f var3 = (Vector4f)var1[12];
      Color var2 = (Color)var1[13];
      TextureTintMode var4 = (TextureTintMode)var1[14];
      long var6 = (Long)var1[15];
      var6 = 1045094376700L ^ var6;
      long var19 = var6 ^ 88190796439153L;
      long var21 = var6 ^ 67943913561762L;
      Object[] var10007 = new Object[]{null, null, null, null, var19};
      var10007[3] = true;
      var10007[2] = var4;
      var10007[1] = var3;
      var10007[0] = var13;
      Object[] var25 = var10007;
      TexturedRectangleRenderer var24 = this;
      DrawPipeline var23 = var24.aReturningdn_C0192(var25);
      AtomicReference var26 = ShapeRenderer.a;
      RenderCommandBatcher var10000 = (RenderCommandBatcher)var26.get();
      Object[] var28 = new Object[]{new PipelineRenderCommand(var23, invokeBinding32(var2, var5, var16, var17, var12, var8, var18, var9, var14, var11)), var21};
      RenderCommandBatcher var27 = var10000;
      var27.bReturningVoid(var28);
   }

   public static void A(Object[] var0) {
      MeshBufferManager var7 = (MeshBufferManager)var0[0];
      RenderContext var2 = (RenderContext)var0[1];
      ManagedGlTexture var10 = (ManagedGlTexture)var0[2];
      float var12 = (Float)var0[3];
      float var1 = (Float)var0[4];
      float var13 = (Float)var0[5];
      float var11 = (Float)var0[6];
      float var8 = (Float)var0[7];
      float var5 = (Float)var0[8];
      float var6 = (Float)var0[9];
      float var9 = (Float)var0[10];
      long var3 = (Long)var0[11];
      var3 = 1045094376700L ^ var3;
      long var14 = var3 ^ 109528863004697L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10018 = new Object[]{
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         null,
         new Vector4f(0.0F),
         invokeBinding33(7896659523217471821L, var3),
         TextureTintMode.MULTIPLY,
         var14
      };
      var10018[11] = var9;
      var10018[10] = var6;
      var10018[9] = var5;
      var10018[8] = var8;
      var10018[7] = var11;
      var10018[6] = var13;
      var10018[5] = var1;
      var10018[4] = var12;
      var10018[3] = var10;
      var10018[2] = var10003;
      var10018[1] = var2;
      var10018[0] = var7;
      invokeBinding34(var10000, var10018, 7890779020949339204L, var3);
   }

   public static void B(Object[] var0) {
      MeshBufferManager var3 = (MeshBufferManager)var0[0];
      RenderContext var9 = (RenderContext)var0[1];
      ManagedGlTexture var7 = (ManagedGlTexture)var0[2];
      float var5 = (Float)var0[3];
      float var11 = (Float)var0[4];
      float var8 = (Float)var0[5];
      float var13 = (Float)var0[6];
      float var4 = (Float)var0[7];
      float var10 = (Float)var0[8];
      float var6 = (Float)var0[9];
      float var14 = (Float)var0[10];
      Color var12 = (Color)var0[11];
      long var1 = (Long)var0[12];
      var1 = 1045094376700L ^ var1;
      long var15 = var1 ^ 127838718298940L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10018 = new Object[]{
         null, null, null, null, null, null, null, null, null, null, null, null, new Vector4f(0.0F), var12, TextureTintMode.MULTIPLY, var15
      };
      var10018[11] = var14;
      var10018[10] = var6;
      var10018[9] = var10;
      var10018[8] = var4;
      var10018[7] = var13;
      var10018[6] = var8;
      var10018[5] = var11;
      var10018[4] = var5;
      var10018[3] = var7;
      var10018[2] = var10003;
      var10018[1] = var9;
      var10018[0] = var3;
      invokeBinding35(var10000, var10018, 4513937712592875361L, var1);
   }

   public static void C(Object[] var0) {
      MeshBufferManager var10 = (MeshBufferManager)var0[0];
      RenderContext var6 = (RenderContext)var0[1];
      ManagedGlTexture var13 = (ManagedGlTexture)var0[2];
      float var4 = (Float)var0[3];
      float var3 = (Float)var0[4];
      float var7 = (Float)var0[5];
      float var14 = (Float)var0[6];
      float var5 = (Float)var0[7];
      float var1 = (Float)var0[8];
      float var12 = (Float)var0[9];
      float var2 = (Float)var0[10];
      float var15 = (Float)var0[11];
      Color var11 = (Color)var0[12];
      long var8 = (Long)var0[13];
      var8 = 1045094376700L ^ var8;
      long var16 = var8 ^ 80441662360294L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10018 = new Object[]{
         null, null, null, null, null, null, null, null, null, null, null, null, new Vector4f(var15), var11, TextureTintMode.MULTIPLY, var16
      };
      var10018[11] = var2;
      var10018[10] = var12;
      var10018[9] = var1;
      var10018[8] = var5;
      var10018[7] = var14;
      var10018[6] = var7;
      var10018[5] = var3;
      var10018[4] = var4;
      var10018[3] = var13;
      var10018[2] = var10003;
      var10018[1] = var6;
      var10018[0] = var10;
      invokeBinding36(var10000, var10018, 9186928734765526715L, var8);
   }

   public static void D(Object[] var0) {
      MeshBufferManager var13 = (MeshBufferManager)var0[0];
      RenderContext var12 = (RenderContext)var0[1];
      ManagedGlTexture var7 = (ManagedGlTexture)var0[2];
      float var14 = (Float)var0[3];
      float var4 = (Float)var0[4];
      float var6 = (Float)var0[5];
      float var3 = (Float)var0[6];
      float var1 = (Float)var0[7];
      float var15 = (Float)var0[8];
      float var9 = (Float)var0[9];
      float var2 = (Float)var0[10];
      Vector4f var8 = (Vector4f)var0[11];
      Color var5 = (Color)var0[12];
      long var10 = (Long)var0[13];
      var10 = 1045094376700L ^ var10;
      long var16 = var10 ^ 12576648898653L;
      TexturedRectangleRenderer var10000 = a;
      Matrix4f var10003 = new Matrix4f();
      Object[] var10018 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var8, var5, TextureTintMode.MULTIPLY, var16};
      var10018[11] = var2;
      var10018[10] = var9;
      var10018[9] = var15;
      var10018[8] = var1;
      var10018[7] = var3;
      var10018[6] = var6;
      var10018[5] = var4;
      var10018[4] = var14;
      var10018[3] = var7;
      var10018[2] = var10003;
      var10018[1] = var12;
      var10018[0] = var13;
      invokeBinding37(var10000, var10018, 2145337796280339456L, var10);
   }

   public static void E(Object[] var0) {
      MeshBufferManager var8 = (MeshBufferManager)var0[0];
      RenderContext var5 = (RenderContext)var0[1];
      Matrix4f var6 = (Matrix4f)var0[2];
      ManagedGlTexture var4 = (ManagedGlTexture)var0[3];
      float var12 = (Float)var0[4];
      float var13 = (Float)var0[5];
      float var1 = (Float)var0[6];
      float var7 = (Float)var0[7];
      float var15 = (Float)var0[8];
      float var14 = (Float)var0[9];
      float var9 = (Float)var0[10];
      float var16 = (Float)var0[11];
      Vector4f var3 = (Vector4f)var0[12];
      Color var2 = (Color)var0[13];
      long var10 = (Long)var0[14];
      var10 = 1045094376700L ^ var10;
      long var17 = var10 ^ 8668698799509L;
      TexturedRectangleRenderer var10000 = a;
      Object[] var10018 = new Object[]{null, null, null, null, null, null, null, null, null, null, null, null, var3, var2, TextureTintMode.MULTIPLY, var17};
      var10018[11] = var16;
      var10018[10] = var9;
      var10018[9] = var14;
      var10018[8] = var15;
      var10018[7] = var7;
      var10018[6] = var1;
      var10018[5] = var13;
      var10018[4] = var12;
      var10018[3] = var4;
      var10018[2] = var6;
      var10018[1] = var5;
      var10018[0] = var8;
      Object[] var20 = var10018;
      TexturedRectangleRenderer var19 = var10000;
      var19.z(var20);
   }

   private void F(Object[] var1) {
      Matrix4f var11 = (Matrix4f)var1[2];
      ManagedGlTexture var9 = (ManagedGlTexture)var1[3];
      float var3 = (Float)var1[4];
      float var15 = (Float)var1[5];
      float var13 = (Float)var1[6];
      float var5 = (Float)var1[7];
      Color var4 = (Color)var1[8];
      Color var10 = (Color)var1[9];
      Color var16 = (Color)var1[10];
      Color var2 = (Color)var1[11];
      Vector4f var12 = (Vector4f)var1[12];
      TextureTintMode var6 = (TextureTintMode)var1[13];
      long var7 = (Long)var1[14];
      var7 = 1045094376700L ^ var7;
      long var18 = var7 ^ 61160307326711L;
      long var20 = var7 ^ 99373055311396L;
      Object[] var10007 = new Object[]{null, null, null, null, var18};
      var10007[3] = true;
      var10007[2] = var6;
      var10007[1] = var12;
      var10007[0] = var9;
      DrawPipeline var22 = invokeBinding38(this, var10007, 8208927668798985263L, var7);
      invokeBinding41(
         (RenderCommandBatcher)invokeBinding39(ShapeRenderer.a, 8211597531637846749L, var7),
         new Object[]{new PipelineRenderCommand(var22, invokeBinding40(var4, var10, var16, var2, var11, var3, var15, var5, var13)), var20},
         8211207245989805401L,
         var7
      );
   }

   private DrawPipeline aReturningdn_C0192(Object[] var1) {
      ManagedGlTexture var5 = (ManagedGlTexture)var1[0];
      Vector4f var4 = (Vector4f)var1[1];
      TextureTintMode var6 = (TextureTintMode)var1[2];
      boolean var7 = (Boolean)var1[3];
      long var2 = (Long)var1[4];
      long var10000 = 1045094376700L ^ var2;
      TextureRegion var8 = new TextureRegion(var5, var4, var6, var7);
      Map var12 = b;
      Function var11 = invokeBinding42(this, var7, var5, var6, var4);
      TextureRegion var10 = var8;
      Map var9 = var12;
      return (DrawPipeline)var9.computeIfAbsent(var10, var11);
   }

   private void G(Object[] var1) {
      MeshBufferManager var10 = (MeshBufferManager)var1[0];
      Matrix4f var9 = (Matrix4f)var1[2];
      ManagedGlTexture var16 = (ManagedGlTexture)var1[3];
      float var7 = (Float)var1[4];
      float var8 = (Float)var1[5];
      float var4 = (Float)var1[6];
      float var12 = (Float)var1[7];
      float var11 = (Float)var1[8];
      float var6 = (Float)var1[9];
      int var5 = (Integer)var1[10];
      Vector4f var3 = (Vector4f)var1[11];
      TextureTintMode var13 = (TextureTintMode)var1[12];
      long var14 = (Long)var1[13];
      var14 = 1045094376700L ^ var14;
      long var17 = var14 ^ 39616901785248L;
      long var19 = var14 ^ 29520544818989L;
      long var21 = var14 ^ 37536143656372L;
      long var23 = var14 ^ 41252306843461L;
      long var25 = var14 ^ 52217072801267L;
      long var27 = var14 ^ 91965387008598L;
      float var36 = var12 - var7;
      float var29 = Math.abs(var36);
      float var37 = var11 - var8;
      float var30 = Math.abs(var37);
      short var10001 = 3907;
      long var10002 = 668567096099852310L ^ var14;
      int var10000 = var5 >> 24;
      var10001 = 14112;
      var10002 = 6207073185690937449L ^ var14;
      int var31 = var10000 & 0xFF;
      var10001 = 4138;
      var10002 = 6889099685338468209L ^ var14;
      var10000 = var5 >> 16;
      var10001 = 14112;
      var10002 = 6207073185690937449L ^ var14;
      int var32 = var10000 & 0xFF;
      var10001 = 26211;
      var10002 = 1752565634913220919L ^ var14;
      var10000 = var5 >> 8;
      var10001 = 14112;
      var10002 = 6207073185690937449L ^ var14;
      int var33 = var10000 & 0xFF;
      var10001 = 14112;
      var10002 = 6207073185690937449L ^ var14;
      int var34 = var5 & 0xFF;
      var10001 = 3907;
      var10002 = 668567096099852310L ^ var14;
      var10000 = var31 << 24;
      short var116 = 4138;
      long var10003 = 6889099685338468209L ^ var14;
      var10000 |= var34 << 16;
      short var117 = 26211;
      var10003 = 1752565634913220919L ^ var14;
      int var35 = var10000 | var33 << 8 | var32;
      Object[] var10008 = new Object[]{null, null, null, null, null, var27};
      var10008[4] = true;
      var10008[3] = var13;
      var10008[2] = var3;
      var10008[1] = var16;
      var10008[0] = var10;
      Object[] var39 = var10008;
      TexturedRectangleRenderer var38 = this;
      GlBufferMeshBuilder var83 = var38.aReturningGlBufferMeshBuilder(var39);
      Object[] var41 = new Object[]{var17};
      GlBufferMeshBuilder var40 = var83;
      GlBufferMeshBuilder var84 = (GlBufferMeshBuilder)var40.kReturningVoid(var41);
      Object[] var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var6;
      var10007[2] = var11;
      var10007[1] = var7;
      var10007[0] = var9;
      Object[] var43 = var10007;
      GlBufferMeshBuilder var42 = var84;
      GlBufferMeshBuilder var85 = var42.dReturningGlBufferMeshBuilder(var43);
      Object[] var45 = new Object[]{new float[]{0.0F, 0.0F}, var19};
      GlBufferMeshBuilder var44 = var85;
      GlBufferMeshBuilder var86 = var44.bReturningGlBufferMeshBuilder(var45);
      Object[] var47 = new Object[]{new float[]{var29, var30}, var19};
      GlBufferMeshBuilder var46 = var86;
      GlBufferMeshBuilder var87 = var46.bReturningGlBufferMeshBuilder(var47);
      Object[] var10004 = new Object[]{null, var21};
      var10004[0] = var35;
      Object[] var49 = var10004;
      GlBufferMeshBuilder var48 = var87;
      GlBufferMeshBuilder var88 = var48.eReturningGlBufferMeshBuilder(var49);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var6;
      var10007[2] = var11;
      var10007[1] = var12;
      var10007[0] = var9;
      Object[] var51 = var10007;
      GlBufferMeshBuilder var50 = var88;
      GlBufferMeshBuilder var89 = var50.dReturningGlBufferMeshBuilder(var51);
      Object[] var53 = new Object[]{new float[]{var29, 0.0F}, var19};
      GlBufferMeshBuilder var52 = var89;
      GlBufferMeshBuilder var90 = var52.bReturningGlBufferMeshBuilder(var53);
      Object[] var55 = new Object[]{new float[]{var29, var30}, var19};
      GlBufferMeshBuilder var54 = var90;
      GlBufferMeshBuilder var91 = var54.bReturningGlBufferMeshBuilder(var55);
      var10004 = new Object[]{null, var21};
      var10004[0] = var35;
      Object[] var57 = var10004;
      GlBufferMeshBuilder var56 = var91;
      GlBufferMeshBuilder var92 = var56.eReturningGlBufferMeshBuilder(var57);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var4;
      var10007[2] = var8;
      var10007[1] = var12;
      var10007[0] = var9;
      Object[] var59 = var10007;
      GlBufferMeshBuilder var58 = var92;
      GlBufferMeshBuilder var93 = var58.dReturningGlBufferMeshBuilder(var59);
      Object[] var61 = new Object[]{new float[]{var29, var30}, var19};
      GlBufferMeshBuilder var60 = var93;
      GlBufferMeshBuilder var94 = var60.bReturningGlBufferMeshBuilder(var61);
      Object[] var63 = new Object[]{new float[]{var29, var30}, var19};
      GlBufferMeshBuilder var62 = var94;
      GlBufferMeshBuilder var95 = var62.bReturningGlBufferMeshBuilder(var63);
      var10004 = new Object[]{null, var21};
      var10004[0] = var35;
      Object[] var65 = var10004;
      GlBufferMeshBuilder var64 = var95;
      GlBufferMeshBuilder var96 = var64.eReturningGlBufferMeshBuilder(var65);
      var10007 = new Object[]{null, null, null, null, var23};
      var10007[3] = var4;
      var10007[2] = var8;
      var10007[1] = var7;
      var10007[0] = var9;
      Object[] var67 = var10007;
      GlBufferMeshBuilder var66 = var96;
      GlBufferMeshBuilder var97 = var66.dReturningGlBufferMeshBuilder(var67);
      Object[] var69 = new Object[]{new float[]{0.0F, var30}, var19};
      GlBufferMeshBuilder var68 = var97;
      GlBufferMeshBuilder var98 = var68.bReturningGlBufferMeshBuilder(var69);
      Object[] var71 = new Object[]{new float[]{var29, var30}, var19};
      GlBufferMeshBuilder var70 = var98;
      GlBufferMeshBuilder var99 = var70.bReturningGlBufferMeshBuilder(var71);
      var10004 = new Object[]{null, var21};
      var10004[0] = var35;
      Object[] var73 = var10004;
      GlBufferMeshBuilder var72 = var99;
      GlBufferMeshBuilder var100 = var72.eReturningGlBufferMeshBuilder(var73);
      Object[] var75 = new Object[]{PrimitiveMode.QUADS, var25};
      GlBufferMeshBuilder var74 = var100;
      GlBufferMeshBuilder var101 = (GlBufferMeshBuilder)var74.iReturningVoid(var75);
      Object[] var77 = new Object[0];
      GlBufferMeshBuilder var76 = var101;
      var76.hReturningGlBufferMeshBuilder(var77);
   }

   private void H(Object[] var1) {
      MeshBufferManager var14 = (MeshBufferManager)var1[0];
      Matrix4f var19 = (Matrix4f)var1[2];
      ManagedGlTexture var13 = (ManagedGlTexture)var1[3];
      float var2 = (Float)var1[4];
      float var17 = (Float)var1[5];
      float var8 = (Float)var1[6];
      float var7 = (Float)var1[7];
      float var11 = (Float)var1[8];
      float var10 = (Float)var1[9];
      int var5 = (Integer)var1[10];
      int var18 = (Integer)var1[11];
      int var12 = (Integer)var1[12];
      int var4 = (Integer)var1[13];
      Vector4f var3 = (Vector4f)var1[14];
      boolean var20 = (Boolean)var1[15];
      TextureTintMode var9 = (TextureTintMode)var1[16];
      long var15 = (Long)var1[17];
      var15 = 1045094376700L ^ var15;
      long var21 = var15 ^ 47985844771772L;
      long var23 = var15 ^ 23595979282993L;
      long var25 = var15 ^ 50092285540520L;
      long var27 = var15 ^ 46352788130393L;
      long var29 = var15 ^ 36082698922223L;
      long var31 = var15 ^ 74013794071900L;
      long var33 = var15 ^ 101192790808394L;
      float var41 = var7 - var2;
      float var35 = Math.abs(var41);
      float var42 = var11 - var17;
      float var36 = Math.abs(var42);
      Object[] var10003 = new Object[]{null, var31};
      var10003[0] = var5;
      Object[] var43 = var10003;
      int var37 = ShapeRenderer.bReturningInt(var43);
      var10003 = new Object[]{null, var31};
      var10003[0] = var18;
      Object[] var44 = var10003;
      int var38 = ShapeRenderer.bReturningInt(var44);
      var10003 = new Object[]{null, var31};
      var10003[0] = var12;
      Object[] var45 = var10003;
      int var39 = ShapeRenderer.bReturningInt(var45);
      var10003 = new Object[]{null, var31};
      var10003[0] = var4;
      Object[] var46 = var10003;
      int var40 = ShapeRenderer.bReturningInt(var46);
      Object[] var10008 = new Object[]{null, null, null, null, null, var33};
      var10008[4] = var20;
      var10008[3] = var9;
      var10008[2] = var3;
      var10008[1] = var13;
      var10008[0] = var14;
      Object[] var48 = var10008;
      TexturedRectangleRenderer var47 = this;
      GlBufferMeshBuilder var10000 = var47.aReturningGlBufferMeshBuilder(var48);
      Object[] var50 = new Object[]{var21};
      GlBufferMeshBuilder var49 = var10000;
      var10000 = (GlBufferMeshBuilder)var49.kReturningVoid(var50);
      Object[] var10007 = new Object[]{null, null, null, null, var27};
      var10007[3] = var10;
      var10007[2] = var11;
      var10007[1] = var2;
      var10007[0] = var19;
      Object[] var52 = var10007;
      GlBufferMeshBuilder var51 = var10000;
      var10000 = var51.dReturningGlBufferMeshBuilder(var52);
      Object[] var54 = new Object[]{new float[]{0.0F, 0.0F}, var23};
      GlBufferMeshBuilder var53 = var10000;
      var10000 = var53.bReturningGlBufferMeshBuilder(var54);
      Object[] var56 = new Object[]{new float[]{var35, var36}, var23};
      GlBufferMeshBuilder var55 = var10000;
      var10000 = var55.bReturningGlBufferMeshBuilder(var56);
      Object[] var10004 = new Object[]{null, var25};
      var10004[0] = var37;
      Object[] var58 = var10004;
      GlBufferMeshBuilder var57 = var10000;
      var10000 = var57.eReturningGlBufferMeshBuilder(var58);
      var10007 = new Object[]{null, null, null, null, var27};
      var10007[3] = var10;
      var10007[2] = var11;
      var10007[1] = var7;
      var10007[0] = var19;
      Object[] var60 = var10007;
      GlBufferMeshBuilder var59 = var10000;
      var10000 = var59.dReturningGlBufferMeshBuilder(var60);
      Object[] var62 = new Object[]{new float[]{var35, 0.0F}, var23};
      GlBufferMeshBuilder var61 = var10000;
      var10000 = var61.bReturningGlBufferMeshBuilder(var62);
      Object[] var64 = new Object[]{new float[]{var35, var36}, var23};
      GlBufferMeshBuilder var63 = var10000;
      var10000 = var63.bReturningGlBufferMeshBuilder(var64);
      var10004 = new Object[]{null, var25};
      var10004[0] = var38;
      Object[] var66 = var10004;
      GlBufferMeshBuilder var65 = var10000;
      var10000 = var65.eReturningGlBufferMeshBuilder(var66);
      var10007 = new Object[]{null, null, null, null, var27};
      var10007[3] = var8;
      var10007[2] = var17;
      var10007[1] = var7;
      var10007[0] = var19;
      Object[] var68 = var10007;
      GlBufferMeshBuilder var67 = var10000;
      var10000 = var67.dReturningGlBufferMeshBuilder(var68);
      Object[] var70 = new Object[]{new float[]{var35, var36}, var23};
      GlBufferMeshBuilder var69 = var10000;
      var10000 = var69.bReturningGlBufferMeshBuilder(var70);
      Object[] var72 = new Object[]{new float[]{var35, var36}, var23};
      GlBufferMeshBuilder var71 = var10000;
      var10000 = var71.bReturningGlBufferMeshBuilder(var72);
      var10004 = new Object[]{null, var25};
      var10004[0] = var39;
      Object[] var74 = var10004;
      GlBufferMeshBuilder var73 = var10000;
      var10000 = var73.eReturningGlBufferMeshBuilder(var74);
      var10007 = new Object[]{null, null, null, null, var27};
      var10007[3] = var8;
      var10007[2] = var17;
      var10007[1] = var2;
      var10007[0] = var19;
      Object[] var76 = var10007;
      GlBufferMeshBuilder var75 = var10000;
      var10000 = var75.dReturningGlBufferMeshBuilder(var76);
      Object[] var78 = new Object[]{new float[]{0.0F, var36}, var23};
      GlBufferMeshBuilder var77 = var10000;
      var10000 = var77.bReturningGlBufferMeshBuilder(var78);
      Object[] var80 = new Object[]{new float[]{var35, var36}, var23};
      GlBufferMeshBuilder var79 = var10000;
      var10000 = var79.bReturningGlBufferMeshBuilder(var80);
      var10004 = new Object[]{null, var25};
      var10004[0] = var40;
      Object[] var82 = var10004;
      GlBufferMeshBuilder var81 = var10000;
      var10000 = var81.eReturningGlBufferMeshBuilder(var82);
      Object[] var84 = new Object[]{PrimitiveMode.QUADS, var29};
      GlBufferMeshBuilder var83 = var10000;
      var10000 = (GlBufferMeshBuilder)var83.iReturningVoid(var84);
      Object[] var86 = new Object[0];
      GlBufferMeshBuilder var85 = var10000;
      var85.hReturningGlBufferMeshBuilder(var86);
   }

   private static int aReturningInt(Object[] var0) {
      int var3 = (Integer)var0[0];
      long var1 = (Long)var0[1];
      var1 = 1045094376700L ^ var1;
      short var10001 = 7454;
      long var10002 = 5028918409070379297L ^ var1;
      int var10000 = var3 >> 24;
      var10001 = 18028;
      var10002 = 7057098703285279300L ^ var1;
      int var4 = var10000 & 0xFF;
      var10001 = 32334;
      var10002 = 2315032276120396414L ^ var1;
      var10000 = var3 >> 16;
      var10001 = 14112;
      var10002 = 6207032771831704329L ^ var1;
      int var5 = var10000 & 0xFF;
      var10001 = 25365;
      var10002 = 5601261121611824931L ^ var1;
      var10000 = var3 >> 8;
      var10001 = 14112;
      var10002 = 6207032771831704329L ^ var1;
      int var6 = var10000 & 0xFF;
      var10001 = 14112;
      var10002 = 6207032771831704329L ^ var1;
      int var7 = var3 & 0xFF;
      var10001 = 3907;
      var10002 = 668504707047789430L ^ var1;
      var10000 = var4 << 24;
      short var27 = 4138;
      long var10003 = 6889035113394572305L ^ var1;
      var10000 |= var7 << 16;
      short var28 = 26211;
      var10003 = 1752575830439393879L ^ var1;
      return var10000 | var6 << 8 | var5;
   }

   private GlBufferMeshBuilder aReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var6 = (MeshBufferManager)var1[0];
      ManagedGlTexture var8 = (ManagedGlTexture)var1[1];
      Vector4f var7 = (Vector4f)var1[2];
      TextureTintMode var5 = (TextureTintMode)var1[3];
      boolean var4 = (Boolean)var1[4];
      long var2 = (Long)var1[5];
      var2 = 1045094376700L ^ var2;
      long var9 = var2 ^ 101663992272018L;
      TextureRegion var11 = new TextureRegion(var8, var7, var5, var4);
      Map var10000 = b;
      Function var15 = invokeBinding43(this, var4, var8, var5, var7);
      TextureRegion var14 = var11;
      Map var13 = var10000;
      DrawPipeline var12 = (DrawPipeline)var13.computeIfAbsent(var14, var15);
      Object[] var17 = new Object[]{var12, var9};
      MeshBufferManager var16 = var6;
      return var16.aReturningGlBufferMeshBuilder(var17);
   }

   public static void I(Object[] var0) {
      long var1 = (Long)var0[0];
      var1 = 1045094376700L ^ var1;
      invokeBinding44(b, 1411236642659655894L, var1);
   }

   private DrawPipeline lambda$getBuffer$6(boolean var1, ManagedGlTexture var2, TextureTintMode var3, Vector4f var4, TextureRegion var5) {
      long var10001 = 84613588441532L ^ 38575761771484L;
      VertexFormat var10002 = VertexFormats.e;
      RenderState[] var10005 = new RenderState[]{RenderState.a, null, null, null, null, null};
      Object[] var11 = new Object[0];
      TexturedRectangleRenderer var10 = this;
      Object[] var12 = new Object[]{var10.aReturningfM_C0295(var11)};
      var10005[1] = RenderState.aReturninggH_C0339(var12);
      Object[] var10011 = new Object[]{null, var1};
      var10011[0] = 2929;
      Object[] var13 = var10011;
      var10005[2] = RenderState.aReturninggF_C0335(var13);
      var10011 = new Object[]{null, true};
      var10011[0] = false;
      Object[] var14 = var10011;
      var10005[3] = RenderState.aReturninggE_C0333(var14);
      var10005[4] = new BlendFunctionState(true, true, 770, 771, 1, 771);
      Object[] var15 = new Object[]{invokeBinding45(this, var2, var3, var4)};
      var10005[5] = RenderState.aReturningfP_C0301(var15);
      return new DrawPipeline(var10002, 4, false, var10005, 123013172433504L);
   }

   private void lambda$getBuffer$5(ManagedGlTexture var1, TextureTintMode var2, Vector4f var3, RenderPass var4) {
      GL13.glActiveTexture(33984);
      int var10000 = 3553;
      int var9 = var1.a;
      GL11.glBindTexture(3553, var9);
      var10000 = this.c;
      TextureTintMode var10 = var2;
      int var12 = var10.ordinal();
      int var11 = var10000;
      GL20.glUniform1i(var11, var12);
      Vector4f var13 = var3;
      Vector4f var14 = var3;
      Vector4f var15 = var3;
      Vector4f var16 = var3;
      float var21 = var16.w;
      float var20 = var15.z;
      float var19 = var14.y;
      float var18 = var13.x;
      int var17 = this.d;
      GL20.glUniform4f(var17, var18, var19, var20, var21);
   }

   private DrawPipeline lambda$getRenderLayer$4(boolean var1, ManagedGlTexture var2, TextureTintMode var3, Vector4f var4, TextureRegion var5) {
      long var10001 = 21802940649728L ^ 136568567907168L;
      VertexFormat var10002 = VertexFormats.e;
      RenderState[] var10005 = new RenderState[]{RenderState.a, null, null, null, null, null};
      Object[] var11 = new Object[0];
      TexturedRectangleRenderer var10 = this;
      Object[] var12 = new Object[]{var10.aReturningfM_C0295(var11)};
      var10005[1] = RenderState.aReturninggH_C0339(var12);
      Object[] var10011 = new Object[]{null, var1};
      var10011[0] = 2929;
      Object[] var13 = var10011;
      var10005[2] = RenderState.aReturninggF_C0335(var13);
      Object[] var14 = new Object[]{true};
      var10005[3] = RenderState.bReturninggE_C0333(var14);
      var10005[4] = new BlendFunctionState(true, true, 770, 771, 1, 771);
      Object[] var15 = new Object[]{invokeBinding46(this, var2, var3, var4)};
      var10005[5] = RenderState.aReturningfP_C0301(var15);
      return new DrawPipeline(var10002, 4, false, var10005, 123013172433504L);
   }

   private void lambda$getRenderLayer$3(ManagedGlTexture var1, TextureTintMode var2, Vector4f var3, RenderPass var4) {
      GL13.glActiveTexture(33984);
      int var10000 = 3553;
      int var9 = var1.a;
      GL11.glBindTexture(3553, var9);
      var10000 = this.c;
      TextureTintMode var10 = var2;
      int var12 = var10.ordinal();
      int var11 = var10000;
      GL20.glUniform1i(var11, var12);
      Vector4f var13 = var3;
      Vector4f var14 = var3;
      Vector4f var15 = var3;
      Vector4f var16 = var3;
      float var21 = var16.w;
      float var20 = var15.z;
      float var19 = var14.y;
      float var18 = var13.x;
      int var17 = this.d;
      GL20.glUniform4f(var17, var18, var19, var20, var21);
   }

   private static void lambda$drawGradientInternal$2(
      Color var0, Color var1, Color var2, Color var3, Matrix4f var4, float var5, float var6, float var7, float var8, Float var9, MeshDataConsumer var10
   ) {
      long var10001 = 52362838333354L ^ 39655651858192L;
      var10001 = 52362838333354L ^ 121526489877430L;
      var10001 = 52362838333354L ^ 65610656683564L;
      var10001 = 52362838333354L ^ 125236109463611L;
      var10001 = 52362838333354L ^ 113561482835009L;
      var10001 = 52362838333354L ^ 52109601023043L;
      var10001 = 52362838333354L ^ 24982220164022L;
      Color var31 = var0;
      int var10000 = var31.getRGB();
      Object[] var10003 = new Object[]{null, 22211549348230L};
      var10003[0] = var10000;
      Object[] var32 = var10003;
      int var27 = aReturningInt(var32);
      Color var33 = var1;
      var10000 = var33.getRGB();
      var10003 = new Object[]{null, 22211549348230L};
      var10003[0] = var10000;
      Object[] var34 = var10003;
      int var28 = aReturningInt(var34);
      Color var35 = var2;
      var10000 = var35.getRGB();
      var10003 = new Object[]{null, 22211549348230L};
      var10003[0] = var10000;
      Object[] var36 = var10003;
      int var29 = aReturningInt(var36);
      Color var37 = var3;
      var10000 = var37.getRGB();
      var10003 = new Object[]{null, 22211549348230L};
      var10003[0] = var10000;
      Object[] var38 = var10003;
      int var30 = aReturningInt(var38);
      Object[] var40 = new Object[]{12707221340346L};
      MeshDataConsumer var39 = var10;
      MeshDataConsumer var84 = var39.kReturningVoid(var40);
      float var112 = var6 + var7;
      Float var41 = var9;
      float var10004 = var41;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var112;
      var10007[1] = var5;
      var10007[0] = var4;
      Object[] var43 = var10007;
      MeshDataConsumer var42 = var84;
      MeshDataConsumer var85 = var42.dReturningMeshDataConsumer(var43);
      Object[] var45 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var44 = var85;
      MeshDataConsumer var86 = var44.bReturningMeshDataConsumer(var45);
      Object[] var47 = new Object[]{new float[]{var8, var7}, 62839871708188L};
      MeshDataConsumer var46 = var86;
      MeshDataConsumer var87 = var46.bReturningMeshDataConsumer(var47);
      Object[] var114 = new Object[]{null, 103875423078289L};
      var114[0] = var30;
      Object[] var49 = var114;
      MeshDataConsumer var48 = var87;
      MeshDataConsumer var88 = var48.eReturningMeshDataConsumer(var49);
      float var10002 = var5 + var8;
      float var113 = var6 + var7;
      Float var50 = var9;
      var10004 = var50;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var113;
      var10007[1] = var10002;
      var10007[0] = var4;
      Object[] var52 = var10007;
      MeshDataConsumer var51 = var88;
      MeshDataConsumer var89 = var51.dReturningMeshDataConsumer(var52);
      Object[] var54 = new Object[]{new float[]{var8, 0.0F}, 62839871708188L};
      MeshDataConsumer var53 = var89;
      MeshDataConsumer var90 = var53.bReturningMeshDataConsumer(var54);
      Object[] var56 = new Object[]{new float[]{var8, var7}, 62839871708188L};
      MeshDataConsumer var55 = var90;
      MeshDataConsumer var91 = var55.bReturningMeshDataConsumer(var56);
      Object[] var116 = new Object[]{null, 103875423078289L};
      var116[0] = var29;
      Object[] var58 = var116;
      MeshDataConsumer var57 = var91;
      MeshDataConsumer var92 = var57.eReturningMeshDataConsumer(var58);
      var10002 = var5 + var8;
      Float var59 = var9;
      var10004 = var59;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var10002;
      var10007[0] = var4;
      Object[] var61 = var10007;
      MeshDataConsumer var60 = var92;
      MeshDataConsumer var93 = var60.dReturningMeshDataConsumer(var61);
      Object[] var63 = new Object[]{new float[]{var8, var7}, 62839871708188L};
      MeshDataConsumer var62 = var93;
      MeshDataConsumer var94 = var62.bReturningMeshDataConsumer(var63);
      Object[] var65 = new Object[]{new float[]{var8, var7}, 62839871708188L};
      MeshDataConsumer var64 = var94;
      MeshDataConsumer var95 = var64.bReturningMeshDataConsumer(var65);
      Object[] var118 = new Object[]{null, 103875423078289L};
      var118[0] = var28;
      Object[] var67 = var118;
      MeshDataConsumer var66 = var95;
      MeshDataConsumer var96 = var66.eReturningMeshDataConsumer(var67);
      Float var68 = var9;
      var10004 = var68;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var6;
      var10007[1] = var5;
      var10007[0] = var4;
      Object[] var70 = var10007;
      MeshDataConsumer var69 = var96;
      MeshDataConsumer var97 = var69.dReturningMeshDataConsumer(var70);
      Object[] var72 = new Object[]{new float[]{0.0F, var7}, 62839871708188L};
      MeshDataConsumer var71 = var97;
      MeshDataConsumer var98 = var71.bReturningMeshDataConsumer(var72);
      Object[] var74 = new Object[]{new float[]{var8, var7}, 62839871708188L};
      MeshDataConsumer var73 = var98;
      MeshDataConsumer var99 = var73.bReturningMeshDataConsumer(var74);
      Object[] var120 = new Object[]{null, 103875423078289L};
      var120[0] = var27;
      Object[] var76 = var120;
      MeshDataConsumer var75 = var99;
      MeshDataConsumer var100 = var75.eReturningMeshDataConsumer(var76);
      Object[] var78 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var77 = var100;
      MeshDataConsumer var101 = var77.iReturningVoid(var78);
      Object[] var80 = new Object[]{80089257141227L};
      MeshDataConsumer var79 = var101;
      var79.hReturningMeshDataConsumer(var80);
   }

   private static void lambda$drawInternalWithUV$1(
      Color var0,
      Matrix4f var1,
      float var2,
      float var3,
      float var4,
      float var5,
      float var6,
      float var7,
      float var8,
      float var9,
      Float var10,
      MeshDataConsumer var11
   ) {
      long var10001 = 74506560246083L ^ 79498911715833L;
      var10001 = 74506560246083L ^ 3143147244895L;
      var10001 = 74506560246083L ^ 32684847863506L;
      var10001 = 74506560246083L ^ 12181914940072L;
      var10001 = 74506560246083L ^ 73909729518250L;
      var10001 = 74506560246083L ^ 135121369140575L;
      Color var32 = var0;
      int var26 = var32.getRGB();
      int var27 = var26 >> 24 & 0xFF;
      int var28 = var26 >> 16 & 0xFF;
      int var29 = var26 >> 8 & 0xFF;
      int var30 = var26 & 0xFF;
      int var31 = var27 << 24 | var30 << 16 | var29 << 8 | var28;
      Object[] var34 = new Object[]{12707221340346L};
      MeshDataConsumer var33 = var11;
      MeshDataConsumer var10000 = var33.kReturningVoid(var34);
      float var10003 = var3 + var4;
      Float var35 = var10;
      float var10004 = var35;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var37 = var10007;
      MeshDataConsumer var36 = var10000;
      var10000 = var36.dReturningMeshDataConsumer(var37);
      Object[] var39 = new Object[]{new float[]{var5, var6}, 62839871708188L};
      MeshDataConsumer var38 = var10000;
      var10000 = var38.bReturningMeshDataConsumer(var39);
      Object[] var41 = new Object[]{new float[]{var7, var4}, 62839871708188L};
      MeshDataConsumer var40 = var10000;
      var10000 = var40.bReturningMeshDataConsumer(var41);
      Object[] var99 = new Object[]{null, 103875423078289L};
      var99[0] = var31;
      Object[] var43 = var99;
      MeshDataConsumer var42 = var10000;
      var10000 = var42.eReturningMeshDataConsumer(var43);
      float var10002 = var2 + var7;
      var10003 = var3 + var4;
      Float var44 = var10;
      var10004 = var44;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var46 = var10007;
      MeshDataConsumer var45 = var10000;
      var10000 = var45.dReturningMeshDataConsumer(var46);
      Object[] var48 = new Object[]{new float[]{var5 + var8, var6}, 62839871708188L};
      MeshDataConsumer var47 = var10000;
      var10000 = var47.bReturningMeshDataConsumer(var48);
      Object[] var50 = new Object[]{new float[]{var7, var4}, 62839871708188L};
      MeshDataConsumer var49 = var10000;
      var10000 = var49.bReturningMeshDataConsumer(var50);
      Object[] var101 = new Object[]{null, 103875423078289L};
      var101[0] = var31;
      Object[] var52 = var101;
      MeshDataConsumer var51 = var10000;
      var10000 = var51.eReturningMeshDataConsumer(var52);
      var10002 = var2 + var7;
      Float var53 = var10;
      var10004 = var53;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var55 = var10007;
      MeshDataConsumer var54 = var10000;
      var10000 = var54.dReturningMeshDataConsumer(var55);
      Object[] var57 = new Object[]{new float[]{var5 + var8, var6 + var9}, 62839871708188L};
      MeshDataConsumer var56 = var10000;
      var10000 = var56.bReturningMeshDataConsumer(var57);
      Object[] var59 = new Object[]{new float[]{var7, var4}, 62839871708188L};
      MeshDataConsumer var58 = var10000;
      var10000 = var58.bReturningMeshDataConsumer(var59);
      Object[] var103 = new Object[]{null, 103875423078289L};
      var103[0] = var31;
      Object[] var61 = var103;
      MeshDataConsumer var60 = var10000;
      var10000 = var60.eReturningMeshDataConsumer(var61);
      Float var62 = var10;
      var10004 = var62;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var64 = var10007;
      MeshDataConsumer var63 = var10000;
      var10000 = var63.dReturningMeshDataConsumer(var64);
      Object[] var66 = new Object[]{new float[]{var5, var6 + var9}, 62839871708188L};
      MeshDataConsumer var65 = var10000;
      var10000 = var65.bReturningMeshDataConsumer(var66);
      Object[] var68 = new Object[]{new float[]{var7, var4}, 62839871708188L};
      MeshDataConsumer var67 = var10000;
      var10000 = var67.bReturningMeshDataConsumer(var68);
      Object[] var105 = new Object[]{null, 103875423078289L};
      var105[0] = var31;
      Object[] var70 = var105;
      MeshDataConsumer var69 = var10000;
      var10000 = var69.eReturningMeshDataConsumer(var70);
      Object[] var72 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var71 = var10000;
      var10000 = var71.iReturningVoid(var72);
      Object[] var74 = new Object[]{80089257141227L};
      MeshDataConsumer var73 = var10000;
      var73.hReturningMeshDataConsumer(var74);
   }

   private static void lambda$drawInternal$0(Color var0, Matrix4f var1, float var2, float var3, float var4, float var5, Float var6, MeshDataConsumer var7) {
      long var10001 = 91571696842199L ^ 97607747384685L;
      var10001 = 91571696842199L ^ 20134963210699L;
      var10001 = 91571696842199L ^ 14507657638470L;
      var10001 = 91571696842199L ^ 30372025783868L;
      var10001 = 91571696842199L ^ 92031088379454L;
      var10001 = 91571696842199L ^ 117028166642123L;
      Color var28 = var0;
      int var22 = var28.getRGB();
      int var23 = var22 >> 24 & 0xFF;
      int var24 = var22 >> 16 & 0xFF;
      int var25 = var22 >> 8 & 0xFF;
      int var26 = var22 & 0xFF;
      int var27 = var23 << 24 | var26 << 16 | var25 << 8 | var24;
      Object[] var30 = new Object[]{12707221340346L};
      MeshDataConsumer var29 = var7;
      MeshDataConsumer var10000 = var29.kReturningVoid(var30);
      float var10003 = var3 + var4;
      Float var31 = var6;
      float var10004 = var31;
      Object[] var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var33 = var10007;
      MeshDataConsumer var32 = var10000;
      var10000 = var32.dReturningMeshDataConsumer(var33);
      Object[] var35 = new Object[]{new float[]{0.0F, 0.0F}, 62839871708188L};
      MeshDataConsumer var34 = var10000;
      var10000 = var34.bReturningMeshDataConsumer(var35);
      Object[] var37 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var36 = var10000;
      var10000 = var36.bReturningMeshDataConsumer(var37);
      Object[] var95 = new Object[]{null, 103875423078289L};
      var95[0] = var27;
      Object[] var39 = var95;
      MeshDataConsumer var38 = var10000;
      var10000 = var38.eReturningMeshDataConsumer(var39);
      float var10002 = var2 + var5;
      var10003 = var3 + var4;
      Float var40 = var6;
      var10004 = var40;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var10003;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var42 = var10007;
      MeshDataConsumer var41 = var10000;
      var10000 = var41.dReturningMeshDataConsumer(var42);
      Object[] var44 = new Object[]{new float[]{var5, 0.0F}, 62839871708188L};
      MeshDataConsumer var43 = var10000;
      var10000 = var43.bReturningMeshDataConsumer(var44);
      Object[] var46 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var45 = var10000;
      var10000 = var45.bReturningMeshDataConsumer(var46);
      Object[] var97 = new Object[]{null, 103875423078289L};
      var97[0] = var27;
      Object[] var48 = var97;
      MeshDataConsumer var47 = var10000;
      var10000 = var47.eReturningMeshDataConsumer(var48);
      var10002 = var2 + var5;
      Float var49 = var6;
      var10004 = var49;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var10002;
      var10007[0] = var1;
      Object[] var51 = var10007;
      MeshDataConsumer var50 = var10000;
      var10000 = var50.dReturningMeshDataConsumer(var51);
      Object[] var53 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var52 = var10000;
      var10000 = var52.bReturningMeshDataConsumer(var53);
      Object[] var55 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var54 = var10000;
      var10000 = var54.bReturningMeshDataConsumer(var55);
      Object[] var99 = new Object[]{null, 103875423078289L};
      var99[0] = var27;
      Object[] var57 = var99;
      MeshDataConsumer var56 = var10000;
      var10000 = var56.eReturningMeshDataConsumer(var57);
      Float var58 = var6;
      var10004 = var58;
      var10007 = new Object[]{null, null, null, null, 71574474611740L};
      var10007[3] = var10004;
      var10007[2] = var3;
      var10007[1] = var2;
      var10007[0] = var1;
      Object[] var60 = var10007;
      MeshDataConsumer var59 = var10000;
      var10000 = var59.dReturningMeshDataConsumer(var60);
      Object[] var62 = new Object[]{new float[]{0.0F, var4}, 62839871708188L};
      MeshDataConsumer var61 = var10000;
      var10000 = var61.bReturningMeshDataConsumer(var62);
      Object[] var64 = new Object[]{new float[]{var5, var4}, 62839871708188L};
      MeshDataConsumer var63 = var10000;
      var10000 = var63.bReturningMeshDataConsumer(var64);
      Object[] var101 = new Object[]{null, 103875423078289L};
      var101[0] = var27;
      Object[] var66 = var101;
      MeshDataConsumer var65 = var10000;
      var10000 = var65.eReturningMeshDataConsumer(var66);
      Object[] var68 = new Object[]{PrimitiveMode.QUADS, 1078475289577L};
      MeshDataConsumer var67 = var10000;
      var10000 = var67.iReturningVoid(var68);
      Object[] var70 = new Object[]{80089257141227L};
      MeshDataConsumer var69 = var10000;
      var69.hReturningMeshDataConsumer(var70);
   }

   static {

      {

      long var10001 = 125752655418621L ^ 31963195628578L;
      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(125752655418621L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[5];
      String var15 = "G\fä\\OÏ\u0005\u00991<\u0015d6ãñF\u009aà¡\u0081\u0098\u0005Cúõ»\u001aðÄI\u0004åÙ²ï\u00adì:ÁE\u0015ÂGàM\u0012Zú\u000bÃ-¶¹\u009e\u001b\u0016 <¼g·Ô|x¸\u0095¬ZÚ\u0004S\u0082¤YÈ=wpó\u009c\u009e²kÜî%ÕÂ;0§Tÿ\u0085ÁÀ^3Kñ\u0015IÒ\u0098ï\u0097!=\u0085ÈýLo\u0095\u0096÷Wás®(¾\u008760»\u009eu\u000504\u0005\u0091£æ\rxØ";
      int var17 = "G\fä\\OÏ\u0005\u00991<\u0015d6ãñF\u009aà¡\u0081\u0098\u0005Cúõ»\u001aðÄI\u0004åÙ²ï\u00adì:ÁE\u0015ÂGàM\u0012Zú\u000bÃ-¶¹\u009e\u001b\u0016 <¼g·Ô|x¸\u0095¬ZÚ\u0004S\u0082¤YÈ=wpó\u009c\u009e²kÜî%ÕÂ;0§Tÿ\u0085ÁÀ^3Kñ\u0015IÒ\u0098ï\u0097!=\u0085ÈýLo\u0095\u0096÷Wás®(¾\u008760»\u009eu\u000504\u0005\u0091£æ\rxØ"
         .length();
      char var14 = '8';
      int var22 = -1;

      label54:
      while (true) {
         String var23 = var15.substring(++var22, var22 + var14);
         
            byte[] var19 = var11.doFinal(var23.getBytes("ISO-8859-1"));
            String var35 = a(var19).intern();
            switch (var27) {
               case 0:
                  var18[var16++] = var35;
                  if ((var22 += var14) >= var17) {
                     f = var18;
                     g = new String[5];
                     k = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(125752655418621L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[20];
                     String var4 = "ôó@à=Ñ\u0083\u001aÇB9V»§:\u009a{=&s£\u0012Ï\u0003±~[±\u0096¬/z\u008dRVá\u0084]í\u0085´ô\u0005çKö¿ÙÚ\u001d\u009d\u0005&¶üN\u001eY!\u0013,w\u0081´\u009e\u0011\u0094kAý¯¿\u0011qÁTR\u0088\u0093|\u0086\u008bðqÜ8(èÙÍë\u0081Ê\u0091Ì4Òl*\u000b{L Ó\u008e{º%ò;JàT\rV\u0087\u0094î1Ù5ýF\u0083\u009eü\u008bL\u0015\u0092\u0014\u0086ÍÝÞ¶\u0098\u0016Òç`(õÀ";
                     int var5 = "ôó@à=Ñ\u0083\u001aÇB9V»§:\u009a{=&s£\u0012Ï\u0003±~[±\u0096¬/z\u008dRVá\u0084]í\u0085´ô\u0005çKö¿ÙÚ\u001d\u009d\u0005&¶üN\u001eY!\u0013,w\u0081´\u009e\u0011\u0094kAý¯¿\u0011qÁTR\u0088\u0093|\u0086\u008bðqÜ8(èÙÍë\u0081Ê\u0091Ì4Òl*\u000b{L Ó\u008e{º%ò;JàT\rV\u0087\u0094î1Ù5ýF\u0083\u009eü\u008bL\u0015\u0092\u0014\u0086ÍÝÞ¶\u0098\u0016Òç`(õÀ"
                        .length();
                     label36:
                     while (true) {
                        int var31 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var31, var2).getBytes("ISO-8859-1");
                        long[] var26 = var6;
                        int var32 = var3++;
                        long var39 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var39;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var44 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var42) {
                              case 0:
                                 var26[var32] = var44;
                                 if (var2 >= var5) {
                                    i = var6;
                                    j = new Integer[20];
                                    a = new TexturedRectangleRenderer(122376783186143L);
                                    b = new HashMap();
                                    break;
                                 }
                                 break;
                              default:
                                 var26[var32] = var44;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "Qc\u008bÆæ\u001a\u008f«ç\u000fæ\u0005\u0018\u0094'\"";
                                 var5 = "Qc\u008bÆæ\u001a\u008f«ç\u000fæ\u0005\u0018\u0094'\"".length();
                                 var2 = 0;
                           }

                           int var33 = var2;
                           var2 += 8;
                           var7 = var4.substring(var33, var2).getBytes("ISO-8859-1");
                           var26 = var6;
                           var32 = var3++;
                           var39 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var42 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var22);
                  break;
               default:
                  var18[var16++] = var35;
                  if ((var22 += var14) < var17) {
                     var14 = var15.charAt(var22);
                     continue label54;
                  }

                  var15 = "Ð\u0081\u008cYÞU\u001c\u000f=\u0003\u0000\u001fß'tè\u0005g³\u008aìpÈÒ O²\u0093th|J\u0018BY\u0015hÍçN\u0000.Ìª\u0087ân¿ð\u0013\bf\bÁ6\u0014ý";
                  var17 = "Ð\u0081\u008cYÞU\u001c\u000f=\u0003\u0000\u001fß'tè\u0005g³\u008aìpÈÒ O²\u0093th|J\u0018BY\u0015hÍçN\u0000.Ìª\u0087ân¿ð\u0013\bf\bÁ6\u0014ý"
                     .length();
                  var14 = ' ';
                  var22 = -1;
            }

            var23 = var15.substring(++var22, var22 + var14);
            var27 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 4265;
      if (g[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])h.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               h.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dg", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = f[var5].getBytes("ISO-8859-1");
         g[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return g[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dg_C0178",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 31040;
      if (j[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = i[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])k.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               k.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dg", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         j[var3] = var15;
      }

      return j[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dg_C0178",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int e(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = m[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = l[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 12;
            yield var15;
         }
         case 1 -> {
            byte var16 = 45;
            yield var16;
         }
         case 2 -> {
            byte var17 = 32;
            yield var17;
         }
         case 3 -> {
            byte var18 = 9;
            yield var18;
         }
         case 4 -> {
            byte var19 = 10;
            yield var19;
         }
         case 5 -> {
            byte var20 = 28;
            yield var20;
         }
         case 6 -> {
            byte var21 = 52;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 19;
            yield var23;
         }
         case 9 -> {
            byte var24 = 59;
            yield var24;
         }
         case 10 -> {
            byte var25 = 48;
            yield var25;
         }
         case 11 -> {
            byte var26 = 0;
            yield var26;
         }
         case 12 -> {
            byte var27 = 15;
            yield var27;
         }
         case 13 -> {
            byte var28 = 29;
            yield var28;
         }
         case 14 -> {
            byte var29 = 60;
            yield var29;
         }
         case 15 -> {
            byte var30 = 1;
            yield var30;
         }
         case 16 -> {
            byte var31 = 27;
            yield var31;
         }
         case 17 -> {
            byte var32 = 16;
            yield var32;
         }
         case 18 -> {
            byte var33 = 7;
            yield var33;
         }
         case 19 -> {
            byte var34 = 6;
            yield var34;
         }
         case 20 -> {
            byte var35 = 57;
            yield var35;
         }
         case 21 -> {
            byte var36 = 5;
            yield var36;
         }
         case 22 -> {
            byte var37 = 2;
            yield var37;
         }
         case 23 -> {
            byte var38 = 44;
            yield var38;
         }
         case 24 -> {
            byte var39 = 53;
            yield var39;
         }
         case 25 -> {
            byte var40 = 43;
            yield var40;
         }
         case 26 -> {
            byte var41 = 50;
            yield var41;
         }
         case 27 -> {
            byte var42 = 18;
            yield var42;
         }
         case 28 -> {
            byte var43 = 3;
            yield var43;
         }
         case 29 -> {
            byte var44 = 61;
            yield var44;
         }
         case 30 -> {
            byte var45 = 4;
            yield var45;
         }
         case 31 -> {
            byte var46 = 25;
            yield var46;
         }
         case 32 -> {
            byte var47 = 63;
            yield var47;
         }
         case 33 -> {
            byte var48 = 41;
            yield var48;
         }
         case 34 -> {
            byte var49 = 17;
            yield var49;
         }
         case 35 -> {
            byte var50 = 51;
            yield var50;
         }
         case 36 -> {
            byte var51 = 13;
            yield var51;
         }
         case 37 -> {
            byte var52 = 55;
            yield var52;
         }
         case 38 -> {
            byte var53 = 58;
            yield var53;
         }
         case 39 -> {
            byte var54 = 37;
            yield var54;
         }
         case 40 -> {
            byte var55 = 39;
            yield var55;
         }
         case 41 -> {
            byte var56 = 30;
            yield var56;
         }
         case 42 -> {
            byte var57 = 33;
            yield var57;
         }
         case 43 -> {
            byte var58 = 49;
            yield var58;
         }
         case 44 -> {
            byte var59 = 22;
            yield var59;
         }
         case 45 -> {
            byte var60 = 56;
            yield var60;
         }
         case 46 -> {
            byte var61 = 24;
            yield var61;
         }
         case 47 -> {
            byte var62 = 34;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 35;
            yield var64;
         }
         case 50 -> {
            byte var65 = 46;
            yield var65;
         }
         case 51 -> {
            byte var66 = 54;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 21;
            yield var68;
         }
         case 54 -> {
            byte var69 = 40;
            yield var69;
         }
         case 55 -> {
            byte var70 = 31;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 38;
            yield var72;
         }
         case 58 -> {
            byte var73 = 8;
            yield var73;
         }
         case 59 -> {
            byte var74 = 26;
            yield var74;
         }
         case 60 -> {
            byte var75 = 20;
            yield var75;
         }
         case 61 -> {
            byte var76 = 42;
            yield var76;
         }
         case 62 -> {
            byte var77 = 47;
            yield var77;
         }
         default -> 62;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            m[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      l[0] = "\u001c0\bTy*\n0\r\u000ej=\u001d{\u000e\bf)\f<\u0019\u001f-<L";
      l[1] = "\u0005@X!C'p`S.Rh\u0011nX%V2e";
      l[2] = void.class;
      m[2] = "java/lang/Void";
      l[3] = ".w4\u0001rP0\u007f.N?J*u7\u0012.@*bl\u0001(J)\u007f!N\u001dQ+{+\u0003\u000e@\"s0\u00052F!";
      l[4] = "qCg`\u0002yzLv/cwqGru";
      l[5] = "28k=\u0010S$8ng\u0003D3sma\u000fP\"4zvDG1";
      l[6] = "RC\u001e~\u0010\n'c\u0015q\u0001EFm\u001ez\u0005\u001f2";
      l[7] = "ngcz\u0002.xgf \u00119o,e&\u001d-~kr1V:d";
      l[8] = "|B\tF5jjB\f\u001c&}}\t\u000f\u001a*ilN\u0018\raxI";
      l[9] = "5,w\r|F@\f|\u0002m\t!\u0002w\tiSU";
      l[10] = "<#ubQ\"I\u0003~m@m(\rufD7\\";
      l[11] = "qj\u001c72\\\u0004J\u00178#\u0013eD\u001c3'I\u0011";
      l[12] = "\u0010^DjH\u0007\u0006^A0[\u0010\u0011\u0015B6W\u0004\u0000RU!\u001c\u00147";
      l[13] = "Sau}pG&A~ra\bGOuyeR3";
      l[14] = "d6\u0003uh3\u0011\u0016\bzy|p\u0018\u0003q}&\u0004";
      l[15] = "&^K=R\u0006S~@2CI2pK9G\u0013F";
      l[16] = "$!\u007f/H*Q\u0001t Ye0\u000f\u007f+]?D";
      l[17] = "E$ :u\rN+1u\u0016\u0000[-";
      l[18] = float.class;
      m[18] = "java/lang/Float";
      l[19] = "\u0011z,@!\"dZ'O0m\u0005T,D47q";
      l[20] = "DR\\9Vi1rW6G&P|\\=C|$";
      l[21] = "|G\bkk8bO\u0012$\b,f";
      l[22] = "@t_2\u0019P]a\u0007\u0010X]Eg";
      l[23] = int.class;
      m[23] = "java/lang/Integer";
      l[24] = "\u001dV\u0011\u0007.zhv\u001a\b?5\tx\u0011\u0003;o}";
      l[25] = "$wds*pQWo|;?0Ydw?eD";
      l[26] = "\u001ah(!\u0001\u0010\fh-{\u0012\u0007\u001b#.}\u001e\u0013\nd9jU\u0003F";
      l[27] = "\u0010r\u00179z\u007feR\u001c6k0\u0004\\\u0017=ojp";
      l[28] = "\b(\u00058[1\u001e(\u0000bH&\tc\u0003dD2\u0018$\u0014s\u000f'!";
      l[29] = "\r D_M+x\u0000OP\\d\u0019\u000eD[X>m";
      l[30] = "y\u001f\u0000#*3\f?\u000b,;|m1\u0000'?&\u0019";
      l[31] = "(q\u001bAAi]Q\u0010NP&<_\u001bET|H";
      l[32] = "E\u007f{Kui0_pDd&QQ{O`|%";
      l[33] = ".\u000e\u0015 {Y%\u0001\u0004o\u0013Y+\u000e\u0017";
      l[34] = "BlD\u001a\u000e\u00157LO\u0015\u001fZVBD\u001e\u001b\u0000\"";
      l[35] = "cZ!3QC\u0016z*<@\fwt!7DV\u0003";
      l[36] = "\u0011\u001bi\u001d;H\u0014\u000eb\u001d8O\u001b\u0007i_yx2[>";
      l[37] = "v\u001c\u001a \u001a`t\u0002SX\u0015lm\u0001\u000f:\u0016";
      l[38] = "0:E\u001b\u0006t5/N\u001b\u0005s:&EYDD\u0013y\u0013";
      l[39] = "*A\u000bk4r/T\u0000k7u ]\u000b)vB\t\u0002_";
      l[40] = "\u0010UOn\u0006\u0015\u0006UJ4\u0015\u0002\u0011\u001eI2\u0019\u0016\u0000Y^%R\u001d";
      l[41] = "\b*h*5u}\nc%$:\u001c\u0004h. `h";
      l[42] = "Zl[@\u001d\u007fDdA\u000fU\u007f^nYH\\d\u001eKXOP~YbC";
      l[43] = " E\u001b\f!P6E\u001eV2G!\u000e\u001dP>S0I\nGuD2";
      l[44] = "g\u0016q~H@\u00126zqY\u000fs8qz]U\u0007";
      l[45] = "9V^Y%8/V[\u00036/8\u001dX\u0005:;)ZO\u0012q)3";
      l[46] = "\u000bSEB8\u0000~sNM)O\u001f}EF-\u0015k";
      l[47] = "qy<$]\u0004gy9~N\u0013p2:xB\u0007au-o\t\u0012E";
      l[48] = "N]\u000bp\f+;}\u0000\u007f\u001ddZs\u000bt\u0019>.";
      l[49] = "1;>N|\u000b';;\u0014o\u001c0p8\u0012c\b!7/\u0005(\u001c\u0010";
      l[50] = "q.\u0007q\u001f&\u0004\u000e\f~\u000eie\u0000\u0007u\n3\u0011";
      l[51] = "#?8*`CV\u001f3%q\f7\u00118.uVC";
      l[52] = "@lNB<fVlK\u0018/qA'H\u001e#eP`_\thqb";
      l[53] = "za\u0002EY7\u000fA\tJHxnO\u0002AL\"\u001a";
      l[54] = "X\u0000Y\u0010\u001fiN\u0000\\J\f~YK_L\u0000jH\fH[K~t";
      l[55] = "\u0003#\u001fG11v\u0003\u0014H ~\u0017\r\u001fC$$c";
      l[56] = "I \u001a{nP<\u0000\u0011t\u007f\u001f]\u000e\u001a\u007f{E)";
      l[57] = "B\u001fERer\u001c\nFkp\u0014\u001a^H\u0005xiC\r\u0007Qh\u0014\u001a\u001fC\r#uS\u0005\u000b\u0010\u001a";
      l[58] = "\u0006c\f)K\u0004Xd\u0010.4\r6\"F!Z\u0002K{\u0015n\u000e\u00126+\u0004#N\u001fRu\u0003?I`";
      l[59] = "\u0016;1BN\u0002Y6.\u0003v\u0012+}iL\u0018\u0010V$:\u0003L\u0000+y,\\\nJ[6!CKr";
      l[60] = "!} $(\u0014ajl4N@vh\u001eq?@a-\u007f{6Pu\u0014";
      l[61] = "u\u0017 K\u0013'5RtP|3NV\u007fA\u001283\u000f,\u000eF(NR:Q\u0000b>\u001d7NAZ";
      l[62] = "\u001b\u000bs\u0019|\u0019\u0016\b2NAIdJ8U/B\u0019\u0013k\u001a{Rd\u0002gU{L\u001a\u001e}C> ";
      l[63] = "b2n7\u0004jn7u2{IL\u0018V\u001e{xg=n,\u0007tb&k";
      l[64] = "\u0015)G\u0019\u001e\u0004K.[\u001ea\u0001%h\r\u0011\u000f\u0002X1^^[\u0012%aO\u0013\u001b\u001fA?H\u000f\u001c`";
      l[65] = "\u000f\u0004#f\u001d\f@\t<'%\u00162B{hK\u001eO\u001b('\u001f\u000e2F>xYDB\t3g\u0018|";
      l[66] = "\u0006~TM +XyHJ_,6?\u001eE1-KfM\ne=66\\G%0Rh[[\"O";
      l[67] = "4:I{\u0003n/d@b\u007f>J<\u0003j\u001157eP%E%J8Fz\u0003o:wKeBW";
      l[68] = "\u0003mn\u007fK\u0011\u0015c+w/\u0004\u001f\u000e2lA\f\u00016hc/\u0004A=kcNWA9m\rD\u0017A)0dTW\u00191TfSQ\u00017=v\u0013\t\u0019S?q\u0015\u0011\u001f:/1M\t{8(7U\u000f\u0012(hoMkB(-k\u0016\n\u000b2ev/";
      l[69] = "\u0000]9bp.@\u0018my\u001f\";\u001cfhq1FE5'%!;\u001c'cyjZU=+dS";
      l[70] = "@c2|C[\u0000&fg,O{\"mvBD\u0006{>9\u0016T{&i<V\u001e\u001eq2h\u001d&";
      l[71] = "W+5Kq^\u0018&*\nIBjmmE'L\u00174>\ns\\ji(U5\u0016\u001a&%Jt.";
      l[72] = "\u000f\u000b6k]O\u0011@9h!RvPz=[F\u001f@:eC";
      l[73] = "t@I\u0005K'yC\bRvw\u000b\u0001\u0002I\u0018|vXQ\u0006Ll\u000bG@JH#2JC\u000b\u001f\u001e";
      l[74] = "\u000b\u000eb\u00118H\u000b\u000b5YQA\n^h\u00078Bp]3\u000fnH\u0011\u000e3\u000bh&";
      l[75] = "\\4]v<A\u00023AqCOlu\u0017~-G\u0011,D1yWl|U|9Z\b\"R`>%";
      l[76] = "VK\u0007vC\t\\\u0012\u001b\u007f/\fW\u0000{zS_G\u001f\u0012j\u0013\u0007_{\u0010m\u0015\u001fY\u0012\u0000-M\u0007=";
      l[77] = "z~q)+&w}0~\u0016v\u0005?:ex}xfi*,m\u0005?9td|=ff}lp\u0005";
      l[78] = "YS\\ }z\u0019\u0016\b;\u0012Gb\u0012\u0003*|e\u001fKPe(ub\u0012B!t>\u0003[Xii\u0007";
      l[79] = "\u001c VW\u0006Y\n.\u0013_bL\u0000C\nD\fD\u001e{UDbL^pSK\u0003\u001f^tU%\r\u0019\n!\u0002D^\u0019\u000e'l\u001c\u0019Z\u0002'\rU\u0003\u0012\u001f\u001e";
      l[80] = "\u0018\u0004\u001c\"W5\u0006O\u0013!+'a_PtQ<\bO\u0010,I";
      l[81] = "Y^p\tX\u0003T]1^eP&\u001f;E\u000bX[Fh\n_H&WdE_VXK~S\u001a:";
      l[82] = "F-J]<s\t U\u001c\u0004n{k\u0012Sja\u00062A\u001c>q{oWCx;\u000b Z\\9\u0003";
      l[83] = "AZ,Qk]\u0001\u001fxJ\u0004oz\u001bs[jB\u0007B \u0014>Rz\u001b2Pb\u0019\u001bR(\u0018\u007f ";
      l[84] = "\u0014NP\u001coY\u001c\u000eA\u000eR\n\u001d\u0012G\u0001.\f;\u0019v\u0016)\f\u001c\u000b?F#\u000e\u0000N^L*\u001e\u0014wC\u00126ZAN_\u0000<ZzMN\u0013(X\u001bGG\u0003<a";
      l[85] = "^qq\u0015,eB*{JM}?r(\u0001#vB+{Nwf?()NvuR;h\u000e4\u0014";
      l[86] = "O:\u0016\u001ej>\u000f\u007fB\u0005\u0005\rt{I\u0014k!\t\"\u001a[?1t{\b\u001fcz\u00152\u0012W~C";
      l[87] = "\u0015xD\u0002n\u000e\fzL\u0007\u0007\u000e\bPK]k=\u0001jVF}\flu\u0010U8\u000f\r&\u0010Q>a\u0003 D\u0004i\u0000P @\u0002\u0007X\u0017cL\u0002f\u0011\r+Q;";
      l[88] = "A\u0019+~P1\u001f\u001e7y/5qXavA7\f\u000129\u0015'qQ#tU*\u0015\u000f$hRU";
      l[89] = "\fK\u0007]\u000f\u001e\u000eJ\u001aCvIp\u0003DP\u0018A\rZ\u0017\u001fLQpUDLIM\u0011\u0006DHO#";
      l[90] = "v;a2'\u0017i8d.M\u0004hO`0,\u0015aZf<1\u0016vk\u000b#w\u00053hjpw\u00015\u0006274\r5g{-|\u0010\f";
      l[91] = "\u0015f2YlK\u0018es\u000eQ\u001bj'y\u0015?\u0010\u0017~*Zk\u0000j'{\u0002m\u000bP\u007f1\tnMj";
      l[92] = "L\f\u001a{\u0010v\fIN`\u007fbwMEq\u0011i\n\u0014\u0016>Eyw\u001bEm@e\u0016HEiF\u000b";
      l[93] = "\u000fb$9ff\u0010r,p\u000bk\u000ez$<Ul\u000e` @`yPg))p9\b\u007fM";
      l[94] = "B[&Z\u0006\u0011J\u001b7H;BH\u000f @;\u0010W\u001b/\u0003ZYMS2:";
      l[95] = "gE5QfHy\u000e:R\u001aW\u001e\u001ey\u0007`Aw\u000e9_x";
      l[96] = ",Ot\u007fT!?\u000e4=5 OMs6[.2\u0014 y\u000f>O\u001bs*\n\".Hs.\fL";
      l[97] = "r,WV\u0010\nlgXUl\u0016\u000bw\u001b\u0000\u0016\u0003bg[X\u000e";
      l[98] = "\\\u000fBWRwP\nYR-d_\u0018||g\u000b]^H\fCj\u000e^L\n-";
      l[99] = ",us)h<l0'2\u00073\u00174,#i#jm\u007fl=3\u00174m(axv}w`|A";
      l[100] = "\b'\u0002\u0011 `V \u001e\u0016_h8fH\u00191fE?\u001bVev8o\n\u001b%{\\1\r\u0007\"\u0004";
      l[101] = "\u000eiGX{\u000e\u001d(\u0007\u001a\u001a\nmk@\u0011t\u0001\u00102\u0013^ \u0011mk\u0001\u001a|Z\f\"\u001bRac";
   }

   private static Class f(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var6 = l[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(m[var4]);
            l[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field c(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field d(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = c(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = d(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field g(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = l[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = f(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = c(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            l[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = d(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  l[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = f(300350341045023L, 0L);
         }
      }
   }

   private static Method c(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method d(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = c(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = d(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method h(long var0, long var2) {
      int var4 = e(var0, var2);
      Object var5 = l[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = m[var4];
      int var7 = var6.indexOf(8);
      Class var8 = f(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = c(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  l[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  f(300350341045023L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = d(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        l[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = f(300350341045023L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = f(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 164;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 66;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 69;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 85;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = h(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 108;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 114;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = g(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 164;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 66;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 69;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object b(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = b(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dg_C0178",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dg" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Color invokeBinding1(long var0, long var2) {
         MethodHandle var8 = bindingCache1;
         MethodHandle var7 = bindingCache1;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache1 = c(MethodHandles.lookup(), "E", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding2(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache2;
         MethodHandle var9 = bindingCache2;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache2 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding3(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache3;
         MethodHandle var9 = bindingCache3;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache3 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Color invokeBinding4(long var0, long var2) {
         MethodHandle var8 = bindingCache4;
         MethodHandle var7 = bindingCache4;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache4 = c(MethodHandles.lookup(), "E", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Color invokeBinding7(long var0, long var2) {
         MethodHandle var8 = bindingCache7;
         MethodHandle var7 = bindingCache7;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache7 = c(MethodHandles.lookup(), "E", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Color invokeBinding10(long var0, long var2) {
         MethodHandle var8 = bindingCache10;
         MethodHandle var7 = bindingCache10;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache10 = c(MethodHandles.lookup(), "E", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding12(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache12;
         MethodHandle var9 = bindingCache12;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache12 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding13(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache13;
         MethodHandle var8 = bindingCache13;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache13 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding14(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache14;
         MethodHandle var9 = bindingCache14;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache14 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding15(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache15;
         MethodHandle var8 = bindingCache15;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache15 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding17(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache17;
         MethodHandle var8 = bindingCache17;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache17 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding23(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache23;
         MethodHandle var8 = bindingCache23;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache23 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding24(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache24;
         MethodHandle var9 = bindingCache24;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache24 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding25(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache25;
         MethodHandle var8 = bindingCache25;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache25 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding26(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache26;
         MethodHandle var9 = bindingCache26;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache26 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding27(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache27;
         MethodHandle var8 = bindingCache27;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache27 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding28(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache28;
         MethodHandle var9 = bindingCache28;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache28 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding29(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding30(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache30;
         MethodHandle var9 = bindingCache30;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache30 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiConsumer invokeBinding31(Color var0, Matrix4f var1, float var2, float var3, float var4, float var5) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/awt/Color;Lorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$drawInternal$0",
                     "(Ljava/awt/Color;Lorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var7.invokeExact((Color)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static BiConsumer invokeBinding32(
      Color var0, Matrix4f var1, float var2, float var3, float var4, float var5, float var6, float var7, float var8, float var9
   ) {
         MethodHandle var14 = bindingCache32;
         MethodHandle var13 = bindingCache32;
         MethodHandle var11 = var13;
         if (var14 == null) {
            var11 = bindingCache32 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ljava/awt/Color;Lorg/joml/Matrix4f;FFFFFFFF)Ljava/util/function/BiConsumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$drawInternalWithUV$1",
                     "(Ljava/awt/Color;Lorg/joml/Matrix4f;FFFFFFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var11.invokeExact((Color)var0, (Matrix4f)var1, (float)var2, (float)var3, (float)var4, (float)var5, (float)var6, (float)var7, (float)var8, (float)var9);
      } catch (Throwable var15) {
         throw SourceSupport.rethrow(var15);
      }
   }

   private static Color invokeBinding33(long var0, long var2) {
         MethodHandle var8 = bindingCache33;
         MethodHandle var7 = bindingCache33;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache33 = c(MethodHandles.lookup(), "E", SourceSupport.methodType("(JJ)Ljava/awt/Color;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (Color)var5.invokeExact((long)var0, (long)var2);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static void invokeBinding34(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache34;
         MethodHandle var9 = bindingCache34;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache34 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding35(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache35;
         MethodHandle var9 = bindingCache35;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache35 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding36(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache36;
         MethodHandle var9 = bindingCache36;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache36 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding37(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache37;
         MethodHandle var9 = bindingCache37;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache37 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static DrawPipeline invokeBinding38(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache38;
         MethodHandle var9 = bindingCache38;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache38 = c(
                  MethodHandles.lookup(),
                  "l",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (DrawPipeline)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding39(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache39;
         MethodHandle var8 = bindingCache39;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache39 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (Object)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static BiConsumer invokeBinding40(Color var0, Color var1, Color var2, Color var3, Matrix4f var4, float var5, float var6, float var7, float var8) {
         MethodHandle var13 = bindingCache40;
         MethodHandle var12 = bindingCache40;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache40 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Lorg/joml/Matrix4f;FFFF)Ljava/util/function/BiConsumer;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$drawGradientInternal$2",
                     "(Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Ljava/awt/Color;Lorg/joml/Matrix4f;FFFFLjava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Float;Ldev/zprestige/prestige/cC_C0115;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (BiConsumer)var10.invokeExact((Color)var0, (Color)var1, (Color)var2, (Color)var3, (Matrix4f)var4, (float)var5, (float)var6, (float)var7, (float)var8);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static void invokeBinding41(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache41;
         MethodHandle var9 = bindingCache41;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache41 = c(
                  MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Function invokeBinding42(TexturedRectangleRenderer var0, boolean var1, ManagedGlTexture var2, TextureTintMode var3, Vector4f var4) {
         MethodHandle var9 = bindingCache42;
         MethodHandle var8 = bindingCache42;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache42 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/dg_C0178;ZLdev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;)Ljava/util/function/Function;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$getRenderLayer$4",
                     "(ZLdev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;Ldev/zprestige/prestige/dD_C0171;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dD_C0171;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var6.invokeExact((TexturedRectangleRenderer)var0, (boolean)var1, (ManagedGlTexture)var2, (TextureTintMode)var3, (Vector4f)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding43(TexturedRectangleRenderer var0, boolean var1, ManagedGlTexture var2, TextureTintMode var3, Vector4f var4) {
         MethodHandle var9 = bindingCache43;
         MethodHandle var8 = bindingCache43;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache43 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/dg_C0178;ZLdev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;)Ljava/util/function/Function;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$getBuffer$6",
                     "(ZLdev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;Ldev/zprestige/prestige/dD_C0171;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dD_C0171;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var6.invokeExact((TexturedRectangleRenderer)var0, (boolean)var1, (ManagedGlTexture)var2, (TextureTintMode)var3, (Vector4f)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = c(MethodHandles.lookup(), "l", SourceSupport.methodType("(Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Consumer invokeBinding45(TexturedRectangleRenderer var0, ManagedGlTexture var1, TextureTintMode var2, Vector4f var3) {
         MethodHandle var8 = bindingCache45;
         MethodHandle var7 = bindingCache45;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache45 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/dg_C0178;Ldev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;)Ljava/util/function/Consumer;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$getBuffer$5",
                     "(Ldev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var5.invokeExact((TexturedRectangleRenderer)var0, (ManagedGlTexture)var1, (TextureTintMode)var2, (Vector4f)var3);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }

   private static Consumer invokeBinding46(TexturedRectangleRenderer var0, ManagedGlTexture var1, TextureTintMode var2, Vector4f var3) {
         MethodHandle var8 = bindingCache46;
         MethodHandle var7 = bindingCache46;
         MethodHandle var5 = var7;
         if (var8 == null) {
            var5 = bindingCache46 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/dg_C0178;Ldev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;)Ljava/util/function/Consumer;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dg_C0178",
                     "lambda$getRenderLayer$3",
                     "(Ldev/zprestige/prestige/bT_C0095;Ldev/zprestige/prestige/x_C0448;Lorg/joml/Vector4f;Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var5.invokeExact((TexturedRectangleRenderer)var0, (ManagedGlTexture)var1, (TextureTintMode)var2, (Vector4f)var3);
      } catch (Throwable var9) {
         throw SourceSupport.rethrow(var9);
      }
   }
}
