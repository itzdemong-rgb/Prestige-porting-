package dev.zprestige.prestige.renderlib;

public record VertexAttribute(int b3, int b4, int b5, boolean b6) {
}
