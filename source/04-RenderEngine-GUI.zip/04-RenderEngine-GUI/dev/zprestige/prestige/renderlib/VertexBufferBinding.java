package dev.zprestige.prestige.renderlib;

public record VertexBufferBinding(ManagedGlBuffer bZ, VertexAttribute b0, int b1, long b2) {

    public final dev.zprestige.prestige.renderlib.ManagedGlBuffer recoveryAccess_read_bZ() { return this.bZ; }

    public final dev.zprestige.prestige.renderlib.VertexAttribute recoveryAccess_read_b0() { return this.b0; }

    public final long recoveryAccess_read_b2() { return this.b2; }

    public final int recoveryAccess_read_b1() { return this.b1; }
}
