package dev.zprestige.prestige.renderlib;

import javax.crypto.Cipher;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class VertexFormats {
   public static final VertexFormat a;
   public static final VertexFormat b;
   public static final VertexFormat c;
   public static final VertexFormat d;
   public static final VertexFormat e;
   public static final VertexFormat f;
   public static final VertexFormat g;

   static {

      {

      long var10001 = 3004373429506L ^ 106937653397329L;
      Cipher var1;
      Cipher var10000 = var1 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var2 = 1; var2 < 8; var2++) {
         var10003[var2] = (byte)(3004373429506L << var2 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var0 = new long[4];
      String var5 = ",Ç\u001eÑ(>\u0005}~Xc»¼\u008f»ö";
      int var6 = ",Ç\u001eÑ(>\u0005}~Xc»¼\u008f»ö".length();
      label24:
      while (true) {
         int var13 = var3;
         var3 += 8;
         byte[] var7 = var5.substring(var13, var3).getBytes("ISO-8859-1");
         long[] var12 = var0;
         int var14 = var4++;
         long var16 = (var7[0] & 255L) << 56
            | (var7[1] & 255L) << 48
            | (var7[2] & 255L) << 40
            | (var7[3] & 255L) << 32
            | (var7[4] & 255L) << 24
            | (var7[5] & 255L) << 16
            | (var7[6] & 255L) << 8
            | var7[7] & 255L;
         
            long var8 = var16;
            byte[] var10 = var1.doFinal(
               new byte[]{
                  (byte)(var8 >>> 56),
                  (byte)(var8 >>> 48),
                  (byte)(var8 >>> 40),
                  (byte)(var8 >>> 32),
                  (byte)(var8 >>> 24),
                  (byte)(var8 >>> 16),
                  (byte)(var8 >>> 8),
                  (byte)var8
               }
            );
            long var20 = (var10[0] & 255L) << 56
               | (var10[1] & 255L) << 48
               | (var10[2] & 255L) << 40
               | (var10[3] & 255L) << 32
               | (var10[4] & 255L) << 24
               | (var10[5] & 255L) << 16
               | (var10[6] & 255L) << 8
               | var10[7] & 255L;
            switch (var18) {
               case 0:
                  var12[var14] = var20;
                  if (var3 >= var6) {
                     a = new VertexFormat(new VertexAttribute[]{new VertexAttribute(3, (int)var0[2], 4, false)}, 109924827032147L);
                     b = new VertexFormat(new VertexAttribute[]{new VertexAttribute(3, (int)var0[1], 4, false), new VertexAttribute(4, (int)var0[0], 1, true)}, 109924827032147L);
                     c = new VertexFormat(
                        new VertexAttribute[]{
                           new VertexAttribute(3, (int)var0[1], 4, false), new VertexAttribute(4, (int)var0[3], 1, true), new VertexAttribute(2, (int)var0[1], 4, false)
                        },
                        109924827032147L
                     );
                     d = new VertexFormat(
                        new VertexAttribute[]{
                           new VertexAttribute(3, (int)var0[1], 4, false),
                           new VertexAttribute(3, (int)var0[1], 4, false),
                           new VertexAttribute(4, (int)var0[3], 1, true),
                           new VertexAttribute(2, (int)var0[1], 4, false)
                        },
                        109924827032147L
                     );
                     e = new VertexFormat(
                        new VertexAttribute[]{
                           new VertexAttribute(3, (int)var0[1], 4, false),
                           new VertexAttribute(2, (int)var0[1], 4, false),
                           new VertexAttribute(2, (int)var0[1], 4, false),
                           new VertexAttribute(4, (int)var0[3], 1, true)
                        },
                        109924827032147L
                     );
                     f = new VertexFormat(new VertexAttribute[]{new VertexAttribute(3, (int)var0[1], 4, false), new VertexAttribute(2, (int)var0[1], 4, false)}, 109924827032147L);
                     g = new VertexFormat(
                        new VertexAttribute[]{
                           new VertexAttribute(3, (int)var0[1], 4, false), new VertexAttribute(2, (int)var0[1], 4, false), new VertexAttribute(2, (int)var0[1], 4, false)
                        },
                        109924827032147L
                     );
                     break;
                  }
                  break;
               default:
                  var12[var14] = var20;
                  if (var3 < var6) {
                     continue label24;
                  }

                  var5 = "y\u0003å\"êGYÑ%4\u0089În\u00822N";
                  var6 = "y\u0003å\"êGYÑ%4\u0089În\u00822N".length();
                  var3 = 0;
            }

            int var15 = var3;
            var3 += 8;
            var7 = var5.substring(var15, var3).getBytes("ISO-8859-1");
            var12 = var0;
            var14 = var4++;
            var16 = (var7[0] & 255L) << 56
               | (var7[1] & 255L) << 48
               | (var7[2] & 255L) << 40
               | (var7[3] & 255L) << 32
               | (var7[4] & 255L) << 24
               | (var7[5] & 255L) << 16
               | (var7[6] & 255L) << 8
               | var7[7] & 255L;
            var18 = 0;
         }
      }
   
      }

      
}
}
