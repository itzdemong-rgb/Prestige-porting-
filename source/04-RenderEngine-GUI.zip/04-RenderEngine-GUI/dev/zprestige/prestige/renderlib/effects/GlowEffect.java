package dev.zprestige.prestige.renderlib.effects;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderPassSequence;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.RenderThreadUtil;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RLUniforms;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL30;

public class GlowEffect extends FramebufferEffect {
   private final Color a;
   private final int b;
   private final float c;
   private final float f;
   private final float i;
   private final float k;
   private final float l;
   private static final long m = 54578827976800L;
   private static final String[] p;
   private static final String[] q;
   private static final Map r = new HashMap(13);
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x;
   private static final long[] y;
   private static final Long[] z;
   private static final Map A;
   private static final Object[] F = new Object[74];
   private static final String[] G = new String[74];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public GlowEffect(long var1) {
      super("shaders/post.vert", "shaders/aura_outline.frag", ((54578827976800L ^ (54578827976800L ^ var1)) ^ 104416415592277L));
      var1 = 54578827976800L ^ var1;
      long var3 = var1 ^ 104416415592277L;
      short var10001 = 29126;
      long var10002 = 3626282406279252452L ^ var1;
      short var7 = 3553;
      long var10003 = 8911207950244541895L ^ var1;

      this.a = Color.WHITE;
      var10001 = 14506;
      var10002 = 466419584967019074L ^ var1;
      this.b = 5;
      this.c = 15.0F;
      this.f = 0.0F;
      this.i = 2.0F;
      this.k = 0.7F;
      this.l = 0.8F;
   }

   @Override
   protected GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var3 = (MeshBufferManager)var1[0];
      int var2 = (Integer)var1[1];
      long var4 = (Long)var1[2];
      long var6 = var4 ^ 52933111772063L;
      Map var10001 = this.j;
      int var8 = var2;
      Integer var10002 = var8;
      Function var11 = invokeBinding1(this, var2);
      Integer var10 = var10002;
      Map var9 = var10001;
      Object[] var13 = new Object[]{(DrawPipeline)var9.computeIfAbsent(var10, var11), var6};
      MeshBufferManager var12 = var3;
      return var12.aReturningGlBufferMeshBuilder(var13);
   }

   @Override
   public void cReturningVoid(Object[] var1) {
      RLUniforms var2 = (RLUniforms)var1[0];
      long var3 = (Long)var1[1];
      short var10001 = 30788;
      long var10002 = 5735994659746652145L ^ var3;
      Color var5 = this.a;
      float var44 = var5.getRed() / 255.0F;
      Color var6 = this.a;
      float var10003 = var6.getGreen() / 255.0F;
      Color var7 = this.a;
      float var10004 = var7.getBlue() / 255.0F;
      Color var8 = this.a;
      float var14 = var8.getAlpha() / 255.0F;
      float var13 = var10004;
      float var12 = var10003;
      float var11 = var44;
      String var10 = "color";
      RLUniforms var9 = var2;
      RLUniforms var10000 = var9.aReturningVoid(var10, var11, var12, var13, var14);
      var10001 = 25440;
      var10002 = 3180273041793156307L ^ var3;
      byte var46 = 5;
      String var16 = "quality";
      RLUniforms var15 = var10000;
      var10000 = var15.aReturningVoid(var16, 5);
      var10001 = 27276;
      var10002 = 1148514034715036989L ^ var3;
      float var20 = 15.0F;
      String var19 = "radius";
      RLUniforms var18 = var10000;
      var10000 = var18.aReturningVoid(var19, var20);
      var10001 = 25346;
      var10002 = 1651060853760230578L ^ var3;
      float var23 = 0.0F;
      String var22 = "fill";
      RLUniforms var21 = var10000;
      var10000 = var21.aReturningVoid(var22, var23);
      var10001 = 3194;
      var10002 = 8113186470932868032L ^ var3;
      float var26 = 2.0F;
      String var25 = "lineWidth";
      RLUniforms var24 = var10000;
      var10000 = var24.aReturningVoid(var25, var26);
      var10001 = 24250;
      var10002 = 5826362758085196035L ^ var3;
      float var29 = 0.7F;
      String var28 = "haloOpacity";
      RLUniforms var27 = var10000;
      var10000 = var27.aReturningVoid(var28, var29);
      var10001 = 3355;
      var10002 = 595853172235201196L ^ var3;
      float var32 = 0.8F;
      String var31 = "coreBoost";
      RLUniforms var30 = var10000;
      var30.aReturningVoid(var31, var32);
   }

   @Override
   public RenderPassSequence aReturningc4(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 89607565886074L;
      RenderPassSequence var10000 = new RenderPassSequence();
      Object[] var7 = new Object[0];
      GlowEffect var6 = this;
      Object[] var9 = new Object[]{var6.aReturningfM_C0295(var7), invokeBinding2(this), invokeBinding3(), var4};
      RenderPassSequence var8 = var10000;
      return var8.bReturningVoid(var9);
   }

   private void lambda$getPipeline$2(RenderPass var1) {
      long var10001 = 76108562307116L ^ 109700030193651L;
      GL13.glActiveTexture(33984);
      int var10000 = Event.bReturningInt();
      short var69 = 3553;
      int var9 = this.h.a;
      GL11.glBindTexture(3553, var9);
      int var6 = var10000;
      Object[] var10 = new Object[0];
      long var70;
      var10000 = (var70 = (RenderThreadUtil.aReturningLong(var10) & 1L) - 0L) == 0L ? 0 : (var70 < 0L ? -1 : 1);
      int var50 = var6;
      int var49 = var10000;
      int var31 = var49;
      int var30 = var49;
      if (var50 == 0) {
         int var51 = var30;
         if (var51 == 0) {
            GL30.glGenerateMipmap(3553);
         }

         GL11.glTexParameteri(3553, 10241, 9985);
         Object[] var18 = new Object[]{42871835510751L};
         GlowEffect var17 = this;
         var17.eReturningVoid(var18);
         Object[] var20 = new Object[0];
         GlowEffect var19 = this;
         GlProgram var67 = var19.aReturningfM_C0295(var20);
         Object[] var22 = new Object[0];
         GlProgram var21 = var67;
         var31 = var21.aReturningInt(var22);
      }

      int var23 = var31;
      RLUniforms var68 = RLUniforms.aReturningVoid(var23);
      int var54 = this.d;
      String var53 = "oneTexel";
      RLUniforms var52 = var68;
      RLUniforms var34 = var52;
      String var35 = var53;
      RLUniforms var32 = var52;
      String var33 = var53;
      RLUniforms var36;
      String var37;
      float var38;
      if (var54 > 0) {
         float var57 = 1.0F / this.d;
         String var56 = var33;
         RLUniforms var55 = var32;
         var36 = var55;
         var37 = var56;
         var38 = var57;
      } else {
         var38 = 0.0F;
         var37 = var35;
         var36 = var34;
      }

      int var61 = this.e;
      float var60 = var38;
      String var59 = var37;
      RLUniforms var58 = var36;
      RLUniforms var42 = var58;
      String var43 = var59;
      float var44 = var60;
      RLUniforms var39 = var58;
      String var40 = var59;
      float var41 = var60;
      RLUniforms var45;
      String var46;
      float var47;
      float var48;
      if (var61 > 0) {
         float var65 = 1.0F / this.e;
         float var64 = var41;
         String var63 = var40;
         RLUniforms var62 = var39;
         var45 = var62;
         var46 = var63;
         var47 = var64;
         var48 = var65;
      } else {
         var48 = 0.0F;
         var47 = var44;
         var46 = var43;
         var45 = var42;
      }

      float var29 = var48;
      float var28 = var47;
      String var27 = var46;
      RLUniforms var26 = var45;
      var26.aReturningVoid(var27, var28, var29);
   }

   private DrawPipeline lambda$createBuffer$1(int var1, Integer var2) {
      long var10001 = 104889821858591L ^ 53346394216831L;
      VertexFormat var10002 = VertexFormats.c;
      RenderState[] var10005 = new RenderState[6];
      Object[] var7 = new Object[]{this.g.a};
      var10005[0] = RenderState.aReturninggJ_C0343(var7);
      Object[] var8 = new Object[]{ShaderPrograms.b};
      var10005[1] = RenderState.aReturninggH_C0339(var8);
      Object[] var10012 = new Object[]{null, null, true};
      var10012[1] = false;
      var10012[0] = 2884;
      Object[] var9 = var10012;
      var10005[2] = RenderState.bReturninggF_C0335(var9);
      Object[] var10011 = new Object[]{null, true};
      var10011[0] = true;
      Object[] var10 = var10011;
      var10005[3] = RenderState.aReturninggI_C0341(var10);
      var10011 = new Object[]{null, 515};
      var10011[0] = 519;
      Object[] var11 = var10011;
      var10005[4] = RenderState.aReturninggD_C0331(var11);
      Object[] var12 = new Object[]{invokeBinding4(var1)};
      var10005[5] = RenderState.aReturningfP_C0301(var12);
      return new DrawPipeline(var10002, 4, true, var10005, 123013172433504L);
   }

   private static void lambda$createBuffer$0(int var0, RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = var0;
      GL11.glBindTexture(3553, var6);
   }

   static {

      {

      long var10001 = 26246138377368L ^ 80149591816960L;
      c();
      Cipher var22;
      Cipher var10000 = var22 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var23 = 1; var23 < 8; var23++) {
         var10003[var23] = (byte)(26246138377368L << var23 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var29 = new String[11];
      String var26 = "c\u0015eéOg¹\u0018ú\u009b5\fG\u007f\u007f÷\u0010µ®\u0082²X\u000e\u0080BD\u0084\u0019Ñ´*\u008f|8\u0093Eþ\u001avÝWR%Ý\u000fïi(pbg7©¤°ì\u0017ê\b\u0017³<GàÛ7-\u0006Üyp¦)·\u0091:Uô\u008c®½\u0087\u008b9A?\u0092ëØR\u0010NÏ\u0007\u0087Í^\u009b_\u0014¯g8dÉÐ¢\u0018\u0015\u0014B\u00980Q]\u008e³±î\u008eú\u009còç\u0005\u0084\u0098®VÂL<\u0010±!¬\u001coäÁFÆ}¾¥\f\u000bh³(²\u0004eÚªg»ÐaÎ{îBÁ¾ÉÞ¿Î\u000fçàÙûvÈwó\u0013qdf¸d\u001bßmqoE \u009d\tü\u001d\u00075,6C\u0092¦ÒKÙ\u0015\u009aöê\u0019ñÔVèiH¨\u0093\u0002Î«ºY µî¢\u0096õW1n\u001ciá0\u0090íx|Ñ#m\u007f\u008b\u0001~¡Âv\u0005(%,\u0019Ô";
      int var28 = "c\u0015eéOg¹\u0018ú\u009b5\fG\u007f\u007f÷\u0010µ®\u0082²X\u000e\u0080BD\u0084\u0019Ñ´*\u008f|8\u0093Eþ\u001avÝWR%Ý\u000fïi(pbg7©¤°ì\u0017ê\b\u0017³<GàÛ7-\u0006Üyp¦)·\u0091:Uô\u008c®½\u0087\u008b9A?\u0092ëØR\u0010NÏ\u0007\u0087Í^\u009b_\u0014¯g8dÉÐ¢\u0018\u0015\u0014B\u00980Q]\u008e³±î\u008eú\u009còç\u0005\u0084\u0098®VÂL<\u0010±!¬\u001coäÁFÆ}¾¥\f\u000bh³(²\u0004eÚªg»ÐaÎ{îBÁ¾ÉÞ¿Î\u000fçàÙûvÈwó\u0013qdf¸d\u001bßmqoE \u009d\tü\u001d\u00075,6C\u0092¦ÒKÙ\u0015\u009aöê\u0019ñÔVèiH¨\u0093\u0002Î«ºY µî¢\u0096õW1n\u001ciá0\u0090íx|Ñ#m\u007f\u008b\u0001~¡Âv\u0005(%,\u0019Ô"
         .length();
      char var25 = 16;
      int var39 = -1;

      label72:
      while (true) {
         String var40 = var26.substring(++var39, var39 + var25);
         
            byte[] var30 = var22.doFinal(var40.getBytes("ISO-8859-1"));
            String var56 = a(var30).intern();
            switch (var46) {
               case 0:
                  var29[var27++] = var56;
                  if ((var39 += var25) >= var28) {
                     p = var29;
                     q = new String[11];
                     x = new HashMap(13);
                     Cipher var11;
                     var10000 = var11 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var12 = 1; var12 < 8; var12++) {
                        var10003[var12] = (byte)(26246138377368L << var12 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var17 = new long[11];
                     String var15 = "©\u0085¼ÂV%`,Ó\u007fV?ùZ\u0005KK÷Kk\n1Ã7Ùl\u0094©\u008d\rLs\u001aÅ¸v_¦ÂÜ¶\u009bÑ\u001bü\u001eÖZÛ»w\u0087#Òp$\u0094\u0095¢\u0090e¦\u0082³\u0089Ì\u0082Íå¦âß";
                     int var16 = "©\u0085¼ÂV%`,Ó\u007fV?ùZ\u0005KK÷Kk\n1Ã7Ùl\u0094©\u008d\rLs\u001aÅ¸v_¦ÂÜ¶\u009bÑ\u001bü\u001eÖZÛ»w\u0087#Òp$\u0094\u0095¢\u0090e¦\u0082³\u0089Ì\u0082Íå¦âß"
                        .length();
                     label54:
                     while (true) {
                        int var50 = var13;
                        var13 += 8;
                        byte[] var18 = var15.substring(var50, var13).getBytes("ISO-8859-1");
                        long[] var43 = var17;
                        int var51 = var14++;
                        long var60 = (var18[0] & 255L) << 56
                           | (var18[1] & 255L) << 48
                           | (var18[2] & 255L) << 40
                           | (var18[3] & 255L) << 32
                           | (var18[4] & 255L) << 24
                           | (var18[5] & 255L) << 16
                           | (var18[6] & 255L) << 8
                           | var18[7] & 255L;
                        
                           long var19 = var60;
                           byte[] var21 = var11.doFinal(
                              new byte[]{
                                 (byte)(var19 >>> 56),
                                 (byte)(var19 >>> 48),
                                 (byte)(var19 >>> 40),
                                 (byte)(var19 >>> 32),
                                 (byte)(var19 >>> 24),
                                 (byte)(var19 >>> 16),
                                 (byte)(var19 >>> 8),
                                 (byte)var19
                              }
                           );
                           long var68 = (var21[0] & 255L) << 56
                              | (var21[1] & 255L) << 48
                              | (var21[2] & 255L) << 40
                              | (var21[3] & 255L) << 32
                              | (var21[4] & 255L) << 24
                              | (var21[5] & 255L) << 16
                              | (var21[6] & 255L) << 8
                              | var21[7] & 255L;
                           switch (var64) {
                              case 0:
                                 var43[var51] = var68;
                                 if (var13 >= var16) {
                                    v = var17;
                                    w = new Integer[11];
                                    A = new HashMap(13);
                                    Cipher var0;
                                    var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                                    var10002 = SecretKeyFactory.getInstance("DES");
                                    var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                                    for (int var1 = 1; var1 < 8; var1++) {
                                       var10003[var1] = (byte)(26246138377368L << var1 * 8 >>> 56);
                                    }

                                    var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                                    long[] var6 = new long[2];
                                    String var4 = "i\u0091\u0015\u007f\u009bXñ\u000e«1Æ¨Çþ\u000f\u0019";
                                    int var5 = "i\u0091\u0015\u007f\u009bXñ\u000e«1Æ¨Çþ\u000f\u0019".length();
                                    do {
                                       int var53 = var2;
                                       var2 += 8;
                                       byte[] var7 = var4.substring(var53, var2).getBytes("ISO-8859-1");
                                       int var54 = var3++;
                                       long var8 = (var7[0] & 255L) << 56
                                          | (var7[1] & 255L) << 48
                                          | (var7[2] & 255L) << 40
                                          | (var7[3] & 255L) << 32
                                          | (var7[4] & 255L) << 24
                                          | (var7[5] & 255L) << 16
                                          | (var7[6] & 255L) << 8
                                          | var7[7] & 255L;
                                       byte[] var10 = var0.doFinal(
                                          new byte[]{
                                             (byte)(var8 >>> 56),
                                             (byte)(var8 >>> 48),
                                             (byte)(var8 >>> 40),
                                             (byte)(var8 >>> 32),
                                             (byte)(var8 >>> 24),
                                             (byte)(var8 >>> 16),
                                             (byte)(var8 >>> 8),
                                             (byte)var8
                                          }
                                       );
                                       var68 = (var10[0] & 255L) << 56
                                          | (var10[1] & 255L) << 48
                                          | (var10[2] & 255L) << 40
                                          | (var10[3] & 255L) << 32
                                          | (var10[4] & 255L) << 24
                                          | (var10[5] & 255L) << 16
                                          | (var10[6] & 255L) << 8
                                          | var10[7] & 255L;
                                       
                                    } while (var2 < var5);

                                    y = var6;
                                    z = new Long[2];
                                    GlProgram var45 = ShaderPrograms.b;
                                    Object[] var10005 = new Object[]{null, null, 104709695459224L};
                                    var10005[1] = 0;
                                    var10005[0] = "texSampler";
                                    Object[] var36 = var10005;
                                    GlProgram var35 = var45;
                                    var35.aReturningVoid(var36);
                                    break;
                                 }
                                 break;
                              default:
                                 var43[var51] = var68;
                                 if (var13 < var16) {
                                    continue label54;
                                 }

                                 var15 = "7«»Ë\u0013ö\u0011u\u0017g\u008d~¾Òô\u0003";
                                 var16 = "7«»Ë\u0013ö\u0011u\u0017g\u008d~¾Òô\u0003".length();
                                 var13 = 0;
                           }

                           int var52 = var13;
                           var13 += 8;
                           var18 = var15.substring(var52, var13).getBytes("ISO-8859-1");
                           var43 = var17;
                           var51 = var14++;
                           var60 = (var18[0] & 255L) << 56
                              | (var18[1] & 255L) << 48
                              | (var18[2] & 255L) << 40
                              | (var18[3] & 255L) << 32
                              | (var18[4] & 255L) << 24
                              | (var18[5] & 255L) << 16
                              | (var18[6] & 255L) << 8
                              | var18[7] & 255L;
                           var64 = 0;
                        }
                     }
                  }

                  var25 = var26.charAt(var39);
                  break;
               default:
                  var29[var27++] = var56;
                  if ((var39 += var25) < var28) {
                     var25 = var26.charAt(var39);
                     continue label72;
                  }

                  var26 = "\u009c?\f\u000b[\u0005Ö\u001d\u0007\u008a\bØâ\u0013fd¢Q£3\u009aJÇ\u000b4åßh\u0095\u0090à¸ 8\u0080î¢«àEÀÑß'\u001d(N\u000b8\u009b$4<°2\f>cBîa](\u009eW";
                  var28 = "\u009c?\f\u000b[\u0005Ö\u001d\u0007\u008a\bØâ\u0013fd¢Q£3\u009aJÇ\u000b4åßh\u0095\u0090à¸ 8\u0080î¢«àEÀÑß'\u001d(N\u000b8\u009b$4<°2\f>cBîa](\u009eW"
                     .length();
                  var25 = ' ';
                  var39 = -1;
            }

            var40 = var26.substring(++var39, var39 + var25);
            var46 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 31255;
      if (q[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])r.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/da", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = p[var5].getBytes("ISO-8859-1");
         q[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return q[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/da_C0166",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/da" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12510;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/da", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/da_C0166",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/da" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static long d(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12098;
      if (z[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = y[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])A.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               A.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/da", var14);
         }

         long var15 = (var10[0] & 255L) << 56
            | (var10[1] & 255L) << 48
            | (var10[2] & 255L) << 40
            | (var10[3] & 255L) << 32
            | (var10[4] & 255L) << 24
            | (var10[5] & 255L) << 16
            | (var10[6] & 255L) << 8
            | var10[7] & 255L;
         z[var3] = var15;
      }

      return z[var3];
   }

   private static long d(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      long var7 = d(var4, var5);
      MethodHandle var9 = MethodHandles.constant(long.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var9, 0, int.class, long.class));
      return var7;
   }

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/da_C0166",
                        "d",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)J"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/da" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = G[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = F[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 38;
            yield var15;
         }
         case 1 -> {
            byte var16 = 35;
            yield var16;
         }
         case 2 -> {
            byte var17 = 49;
            yield var17;
         }
         case 3 -> {
            byte var18 = 19;
            yield var18;
         }
         case 4 -> {
            byte var19 = 40;
            yield var19;
         }
         case 5 -> {
            byte var20 = 34;
            yield var20;
         }
         case 6 -> {
            byte var21 = 46;
            yield var21;
         }
         case 7 -> {
            byte var22 = 14;
            yield var22;
         }
         case 8 -> {
            byte var23 = 25;
            yield var23;
         }
         case 9 -> {
            byte var24 = 22;
            yield var24;
         }
         case 10 -> {
            byte var25 = 6;
            yield var25;
         }
         case 11 -> {
            byte var26 = 55;
            yield var26;
         }
         case 12 -> {
            byte var27 = 62;
            yield var27;
         }
         case 13 -> {
            byte var28 = 17;
            yield var28;
         }
         case 14 -> {
            byte var29 = 41;
            yield var29;
         }
         case 15 -> {
            byte var30 = 7;
            yield var30;
         }
         case 16 -> {
            byte var31 = 52;
            yield var31;
         }
         case 17 -> {
            byte var32 = 15;
            yield var32;
         }
         case 18 -> {
            byte var33 = 8;
            yield var33;
         }
         case 19 -> {
            byte var34 = 30;
            yield var34;
         }
         case 20 -> {
            byte var35 = 45;
            yield var35;
         }
         case 21 -> {
            byte var36 = 47;
            yield var36;
         }
         case 22 -> {
            byte var37 = 21;
            yield var37;
         }
         case 23 -> {
            byte var38 = 1;
            yield var38;
         }
         case 24 -> {
            byte var39 = 56;
            yield var39;
         }
         case 25 -> {
            byte var40 = 28;
            yield var40;
         }
         case 26 -> {
            byte var41 = 3;
            yield var41;
         }
         case 27 -> {
            byte var42 = 33;
            yield var42;
         }
         case 28 -> {
            byte var43 = 31;
            yield var43;
         }
         case 29 -> {
            byte var44 = 24;
            yield var44;
         }
         case 30 -> {
            byte var45 = 16;
            yield var45;
         }
         case 31 -> {
            byte var46 = 20;
            yield var46;
         }
         case 32 -> {
            byte var47 = 23;
            yield var47;
         }
         case 33 -> {
            byte var48 = 5;
            yield var48;
         }
         case 34 -> {
            byte var49 = 42;
            yield var49;
         }
         case 35 -> {
            byte var50 = 0;
            yield var50;
         }
         case 36 -> {
            byte var51 = 36;
            yield var51;
         }
         case 37 -> {
            byte var52 = 13;
            yield var52;
         }
         case 38 -> {
            byte var53 = 4;
            yield var53;
         }
         case 39 -> {
            byte var54 = 43;
            yield var54;
         }
         case 40 -> {
            byte var55 = 53;
            yield var55;
         }
         case 41 -> {
            byte var56 = 18;
            yield var56;
         }
         case 42 -> {
            byte var57 = 26;
            yield var57;
         }
         case 43 -> {
            byte var58 = 12;
            yield var58;
         }
         case 44 -> {
            byte var59 = 63;
            yield var59;
         }
         case 45 -> {
            byte var60 = 50;
            yield var60;
         }
         case 46 -> {
            byte var61 = 57;
            yield var61;
         }
         case 47 -> {
            byte var62 = 29;
            yield var62;
         }
         case 48 -> {
            byte var63 = 39;
            yield var63;
         }
         case 49 -> {
            byte var64 = 2;
            yield var64;
         }
         case 50 -> {
            byte var65 = 54;
            yield var65;
         }
         case 51 -> {
            byte var66 = 9;
            yield var66;
         }
         case 52 -> {
            byte var67 = 61;
            yield var67;
         }
         case 53 -> {
            byte var68 = 10;
            yield var68;
         }
         case 54 -> {
            byte var69 = 44;
            yield var69;
         }
         case 55 -> {
            byte var70 = 60;
            yield var70;
         }
         case 56 -> {
            byte var71 = 32;
            yield var71;
         }
         case 57 -> {
            byte var72 = 58;
            yield var72;
         }
         case 58 -> {
            byte var73 = 48;
            yield var73;
         }
         case 59 -> {
            byte var74 = 51;
            yield var74;
         }
         case 60 -> {
            byte var75 = 27;
            yield var75;
         }
         case 61 -> {
            byte var76 = 37;
            yield var76;
         }
         case 62 -> {
            byte var77 = 59;
            yield var77;
         }
         default -> 11;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            G[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      F[0] = "N0oP'\u000bX0j\n4\u001cO{i\f8\b^<~\u001bs\u0018\u0012";
      F[1] = "%5\r&LOP\u0015\u0006)]\u00001\u001b\r\"YZE";
      F[2] = "\u001c\u0010M6\u001c\t\n\u0010Hl\u000f\u001e\u001d[Kj\u0003\n\f\u001c\\}H\u001f5";
      F[3] = "3G<u6\u0013%G9/%\u00042\f:))\u0010#K->b\u0000c";
      F[4] = "<\u0010W5.0I0\\:?\u007f(>W1;%\\";
      F[5] = "l\u0010|x\u001d6z\u0010y\"\u000e!m[z$\u00025|\u001cm3I X";
      F[6] = "e\f4\u0002C\u0017\u0010,?\rRXq\"4\u0006V\u0002\u0005";
      F[7] = ".k[4B.8k^nQ9/ ]h]->gJ\u007f\u00169\u000e";
      F[8] = "waed\u0001/\u0002Ank\u0010`cOe`\u0014:\u0017";
      F[9] = "A \r\u007f\u0003cW \b%\u0010t@k\u000b#\u001c`Q,\u001c4Wtc";
      F[10] = "3w\u0015<{\"FW\u001e3jm'Y\u00158n7S";
      F[11] = "QeR\u0006U0$EY\tD\u007fEKR\u0002@%1";
      F[12] = "r\bwtQ\u0010d\br.B\u0007sCq(N\u0013b\u0004f?\u0005\u0007\\";
      F[13] = "t\b;]wm\u0001(0Rf\"`&;Ybx\u0014";
      F[14] = "wl\u0007\u0016\u0003Xal\u0002L\u0010Ov'\u0001J\u001c[g`\u0016]WOZ";
      F[15] = "}B\t/t\u000e\bb\u0002 eAil\t+a\u001b\u001d";
      F[16] = "N^$aFMX^!;UZO\u0015\"=YN^R5*\u0012Zb";
      F[17] = "'6v9w\u000fR\u0016}6f@3\u0018v=b\u001aG";
      F[18] = void.class;
      G[18] = "java/lang/Void";
      F[19] = "\fF\u000fO;Y\u0011SWmzT\tU";
      F[20] = int.class;
      G[20] = "java/lang/Integer";
      F[21] = "#\u0010S\\L\u001c5\u0010V\u0006_\u000b\"[U\u0000S\u001f3\u001cB\u0017\u0018\u000b>";
      F[22] = "w\u0006yP\b1|\th\u001fu)o\u000eaV";
      F[23] = float.class;
      G[23] = "java/lang/Float";
      F[24] = "\u0001,yH:5\u0017,|\u0012)\"\u0000g\u007f\u0014%6\u0011 h\u0003n&:";
      F[25] = "\u001cp{9)^iPp68\u0011\b^{=<K|";
      F[26] = "B&\u0007jC\u000eG3\fj@\tH:\u0007(\u0001>agP";
      F[27] = "Z27iq\u0016L223b\u0001[y15n\u0015J>&\"%\u0007{";
      F[28] = "B<(x9\u0005T<-\"*\u0012Cw.$&\u0006R093m\u0011G";
      F[29] = "Pwuy\"N[xd6ACNuk]tA_fwqcL";
      F[30] = "SV\u0003&\u000b\\VC\b&\b[YJ\u0003dIlp\u0015U";
      F[31] = "c6\u001bDu0f#\u0010Dv7i*\u001b\u00067\u0000@uO";
      F[32] = "<EY`\u0001W*E\\:\u0012@=\u000e_<\u001eT,IH+UC2";
      F[33] = "/j_\u000f\u0004$ZJT\u0000\u0015k;D_\u000b\u00111O";
      F[34] = long.class;
      G[34] = "java/lang/Long";
      F[35] = "kA4GuS\u001ea?Hd\u001c\u007fo4C`F\u000b";
      F[36] = "\u0016\t^\u000e0\u0004\u001d\u0006OAW\u0006\b\rO\nl";
      F[37] = "\u0000\u001bb9\u000bf\u001e\u0013xvhr\u001a";
      F[38] = "R.\u0013+\u0004@Y!\u0002deNR*\u0006>";
      F[39] = "amj:c\u0011\u007fepu+\u0011eoh2\"\n%Ji5.\u0010bcr";
      F[40] = "Ybjj-rObo0>eX)l62qIn{!ycS";
      F[41] = "j\u0006\u0000*y\u0007\u001f&\u000b%hH~(\u0000.l\u0012\n";
      F[42] = "Y,i\u0007+\u0010O,l]8\u0007Xgo[4\u0013I xL\u007f\u0002l";
      F[43] = "A,\f8._\u001dbL MHDRX; ]IaX\u0018,_EtM] H@{N?4BPz561\u0016LgO>t^\\\u001d";
      F[44] = "XdxC\u001di\u001fdeU~1c`eT\u0004e\u0013#fJ\u0013X^t'\u0019\u0005\"_kpK~";
      F[45] = "\b<2\u001d\u0017K\u0013b2\bz[jo0\u0005\u001cJ\b{:\u0015\u001d1";
      F[46] = "wQ|784}Zq1Q'vJS7)(r6w<1.`Tc6!/\u001b";
      F[47] = "\u0019\u0010\u0019\u000fMM\u0013\u001b\u0014\t$n56#&$]\u0012\u0011\u001b\u0002XW\u0019\u001c\u001d";
      F[48] = ")1gV,}?6b\u001cM}D:o\n-m67v\u0006'\u0014+im\b4j~-t\nM{y0g\u001f3.=)ef\") :p\u0018wm98\t\tpp*-w\\4i(Td\u0003#$%=r\u0004&nD";
      F[49] = ")W\u001c=[,0\u0003\u0013l#;R\u001c\u0004qYo\"_\u0007oNR.\u001cJb]0/\u0019N`#";
      F[50] = "p\u0014:\u0016H_7\u0014'\u0000+\u0007K\u0010'\u0001QS;S$\u001fFnp\u0014:\u0016H_7\u0014'\u0000+";
      F[51] = "G\u0019>o^\u0016\u0000\u0019#y=N|\u001d#xG\u001a\f^ fP'M\u001e(9\fV\u001a\u001e+w=";
      F[52] = "-ij\u001em&/= MU(-Z|^\r.3otC)*3g\u0011C:'/}sW07.\u0006|A5!2dhK% Ik~N3<+\u007ft^2G\"z B/=*?hRU";
      F[53] = "k{/\u001d\rm}|*Wlm\u0006p'A\f}t}>M\u0006\u0004i#%C\u0015z<g<Alk;z/T\u0012>\u007fc--\u0001ah. D\u0017fmdA";
      F[54] = "1Q7{X^0\u000f%%;ZT\u001b+dA\u000e$X(zV32\u0006cbPQ>\u0012\"v;";
      F[55] = "Yfb@\u000f\u001d\u0018m#\u0016t\u0012`zjR\u000eF\u00109iL\u0019{\rnxI\u000f\u0019\u0019dhHt";
      F[56] = ".o**V:io7<5b\u0015k7=O6e(4#X\u000b\u007fr,yYz$b.25";
      F[57] = "P*)1m_Z!$7\u0004LQ1\u00158h#Q\"/3\u007fAE(?2\u0004";
      F[58] = "\u007fI\u0017*u-sJ\u0005 \u0007:\u0010U\u000f>}j`\u0016\f jW{RL/}-s\u0017\u0004?\u0007";
      F[59] = "S`UY+{\u0013mTOF|B8N]\u0001l+1\\P yI%V@!\u0002S`UY+{\u0013mTOF";
      F[60] = "\u000b]\u0003\t\u0013\u007f\r\u0004\u0000\u0002jw\u0015\u0005\u0002\u001a\u0016q3\u000e3\r\u0011q\u0014\u001cz\u001e\n,I\fD\u0019\u0000w\u0019`\u0000]\u000be\u0017\u0005F\u001f\u0005yr\u0019\u001aWQpL\u001e\u0010\f\u0001\u001c";
      F[61] = "/7\n\u000f\u0011%%<\u0007\tx6.,&\u000f\u00054C=\u0003\u000b\u001e\"!)\t\u001b\u001fY";
      F[62] = "r\u0002\u00199m\td\u0005\u001cs\f\t\u001f\t\u0011el\u0019m\u0004\bif`pZ\u0013gu\u001e%\u001e\ne\f\rz\tGhe\u001b}\f\r\t";
      F[63] = "/H\u001d\u0015`\u0007'\r\u001b^\u000eWMV\u0019IpR*\u0005\u0007\u0010g>.R\u001bRbY}LBE\u000e";
      F[64] = "$N2'&[<\u0002h[~8:A-!*HyB36\u0017\u0001&I? q@-\bi[";
      F[65] = "\fe\u0014\f\u000f\u001eKe\t\u001alE7a\t\u001b\u0016\u0012G\"\n\u0005\u0001/\taB\n\rSSv\u0015Xl";
      F[66] = "hxjk\u0003~~\u007fo!b~\u0005pk;\u0004lgda+\u0005\u0017hxjk\u0003~~\u007fo!b";
      F[67] = "[5{\u00074[Ya1T\fU[\u0010aQ`fR*|JvW?7oWjA]#eGk:R5`QwXF?pP\fQCklMvY\u0006#|7";
      F[68] = "\u0016Ik\u001eNE\u0000NnT/E{BcBOU\tOzNE,\u0016CeHTN\u0002IuI/A\u001eB5OFW\u0019G\u007f.";
      F[69] = "T\u0010o\u000f\u0015\u0018\u0013\u0010r\u0019v@o\u0014r\u0018\f\u0014\u001fWq\u0006\u001b)_\u0011:^\u0007\u0012\u0010T`\fv";
      F[70] = "G\u000e\b\u0019\nR\\AS\u0018h\u0003G5]\u0005\t\u0012N [\t\u0014\u0011Y\u00116\u0014\u0007\fE\u0007T\u0000\r\u001cD|]\u0005Y\u0000Y\u0006U@\u0011\u0010#";
      F[71] = "\u0013\u0006Ept:YRI|\u000f9)C\u000b0unY\u0000\b.bS\u0013\u0006Ept:YRI|\u000f";
      F[72] = "Yk5\u0003\u0001^S`8\u0005hMXp\u001c\u001d\u0005OS\f>\b\bDNn*\u0002\u0018E5";
      F[73] = "~;&F)X?0g\u0010RWG'.T(\u00037d-J?>, mE(D$e%UR";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = F[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(G[var4]);
            F[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = F[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = G[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            F[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  F[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(2689151983064364L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = F[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = G[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  F[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(2689151983064364L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        F[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(2689151983064364L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 224;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 122;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 121;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 81;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 65;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 249;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 224;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 122;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 121;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite g(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/da_C0166",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/da" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(GlowEffect var0, int var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/da_C0166;I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/da_C0166",
                     "lambda$createBuffer$1",
                     "(ILjava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var3.invokeExact((GlowEffect)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Consumer invokeBinding2(GlowEffect var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/da_C0166;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/da_C0166", "lambda$getPipeline$2", "(Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((GlowEffect)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntSupplier invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding4(int var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(I)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/da_C0166", "lambda$createBuffer$0", "(ILdev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
