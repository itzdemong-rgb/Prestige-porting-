package dev.zprestige.prestige.renderlib.effects;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderPassSequence;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RLUniforms;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class RainbowEffect extends FramebufferEffect {
   private final float a;
   private final float c;
   private final float f;
   private final float i;
   private static final long m = 33572626239379L;
   private static final String[] p;
   private static final String[] q;
   private static final Map r = new HashMap(13);
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x;
   private static final Object[] y = new Object[60];
   private static final String[] z = new String[60];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public RainbowEffect(long var1) {
      super("shaders/post.vert", "shaders/rainbow_outline.frag", ((33572626239379L ^ (33572626239379L ^ var1)) ^ 123621547935699L));
      var1 = 33572626239379L ^ var1;
      long var3 = var1 ^ 123621547935699L;
      short var10001 = 30102;
      long var10002 = 31571344797684638L ^ var1;
      short var6 = 16470;
      long var10003 = 928798103156024927L ^ var1;

      this.a = 0.5F;
      this.c = 0.2F;
      this.f = 1.0F;
      this.i = 1.0F;
   }

   @Override
   protected GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      int var4 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      long var6 = var2 ^ 52933111772063L;
      Map var10001 = this.j;
      int var8 = var4;
      Integer var10002 = var8;
      Function var11 = invokeBinding1(this, var4);
      Integer var10 = var10002;
      Map var9 = var10001;
      Object[] var13 = new Object[]{(DrawPipeline)var9.computeIfAbsent(var10, var11), var6};
      MeshBufferManager var12 = var5;
      return var12.aReturningGlBufferMeshBuilder(var13);
   }

   @Override
   public void cReturningVoid(Object[] var1) {
      RLUniforms var4 = (RLUniforms)var1[0];
      long var2 = (Long)var1[1];
      short var10001 = 3923;
      long var10002 = 4646313910874873421L ^ var2;
      float var7 = (float)(System.currentTimeMillis() - b) / 1000.0F;
      String var6 = "time";
      RLUniforms var5 = var4;
      RLUniforms var10000 = var5.aReturningVoid(var6, var7);
      var10001 = 26504;
      var10002 = 7401455717702039188L ^ var2;
      float var10 = 0.5F;
      String var9 = "rainbowSpeed";
      RLUniforms var8 = var10000;
      var10000 = var8.aReturningVoid(var9, var10);
      var10001 = 10895;
      var10002 = 889319450638236562L ^ var2;
      float var13 = 0.2F;
      String var12 = "saturation";
      RLUniforms var11 = var10000;
      var10000 = var11.aReturningVoid(var12, var13);
      var10001 = 31564;
      var10002 = 8639099672810842707L ^ var2;
      float var16 = 1.0F;
      String var15 = "brightness";
      RLUniforms var14 = var10000;
      var10000 = var14.aReturningVoid(var15, var16);
      var10001 = 1541;
      var10002 = 4858596129009407762L ^ var2;
      float var19 = 1.0F;
      String var18 = "size";
      RLUniforms var17 = var10000;
      var17.aReturningVoid(var18, var19);
   }

   @Override
   public RenderPassSequence aReturningc4(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 89607565886074L;
      RenderPassSequence var10000 = new RenderPassSequence();
      Object[] var7 = new Object[0];
      RainbowEffect var6 = this;
      Object[] var9 = new Object[]{var6.aReturningfM_C0295(var7), invokeBinding2(this), invokeBinding3(), var4};
      RenderPassSequence var8 = var10000;
      return var8.bReturningVoid(var9);
   }

   private void lambda$getPipeline$2(RenderPass var1) {
      long var10001 = 53044484037864L ^ 25028941191991L;
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var8 = this.h.a;
      GL11.glBindTexture(3553, var8);
      Object[] var10 = new Object[]{42871835510751L};
      RainbowEffect var9 = this;
      var9.eReturningVoid(var10);
      Object[] var12 = new Object[0];
      RainbowEffect var11 = this;
      GlProgram var53 = var11.aReturningfM_C0295(var12);
      Object[] var14 = new Object[0];
      GlProgram var13 = var53;
      int var15 = var13.aReturningInt(var14);
      RLUniforms var54 = RLUniforms.aReturningVoid(var15);
      int var41 = this.d;
      String var40 = "oneTexel";
      RLUniforms var39 = var54;
      RLUniforms var24 = var39;
      String var25 = var40;
      RLUniforms var22 = var39;
      String var23 = var40;
      RLUniforms var26;
      String var27;
      float var28;
      if (var41 > 0) {
         float var44 = 1.0F / this.d;
         String var43 = var23;
         RLUniforms var42 = var22;
         var26 = var42;
         var27 = var43;
         var28 = var44;
      } else {
         var28 = 0.0F;
         var27 = var25;
         var26 = var24;
      }

      int var48 = this.e;
      float var47 = var28;
      String var46 = var27;
      RLUniforms var45 = var26;
      RLUniforms var32 = var45;
      String var33 = var46;
      float var34 = var47;
      RLUniforms var29 = var45;
      String var30 = var46;
      float var31 = var47;
      RLUniforms var35;
      String var36;
      float var37;
      float var38;
      if (var48 > 0) {
         float var52 = 1.0F / this.e;
         float var51 = var31;
         String var50 = var30;
         RLUniforms var49 = var29;
         var35 = var49;
         var36 = var50;
         var37 = var51;
         var38 = var52;
      } else {
         var38 = 0.0F;
         var37 = var34;
         var36 = var33;
         var35 = var32;
      }

      float var21 = var38;
      float var20 = var37;
      String var19 = var36;
      RLUniforms var18 = var35;
      var18.aReturningVoid(var19, var20, var21);
   }

   private DrawPipeline lambda$createBuffer$1(int var1, Integer var2) {
      long var10001 = 4164568048473L ^ 118921737498937L;
      VertexFormat var10002 = VertexFormats.c;
      RenderState[] var10005 = new RenderState[6];
      Object[] var7 = new Object[]{this.g.a};
      var10005[0] = RenderState.aReturninggJ_C0343(var7);
      Object[] var8 = new Object[]{ShaderPrograms.b};
      var10005[1] = RenderState.aReturninggH_C0339(var8);
      Object[] var10012 = new Object[]{null, null, true};
      var10012[1] = false;
      var10012[0] = 2884;
      Object[] var9 = var10012;
      var10005[2] = RenderState.bReturninggF_C0335(var9);
      Object[] var10011 = new Object[]{null, true};
      var10011[0] = true;
      Object[] var10 = var10011;
      var10005[3] = RenderState.aReturninggI_C0341(var10);
      var10011 = new Object[]{null, 515};
      var10011[0] = 519;
      Object[] var11 = var10011;
      var10005[4] = RenderState.aReturninggD_C0331(var11);
      Object[] var12 = new Object[]{invokeBinding4(var1)};
      var10005[5] = RenderState.aReturningfP_C0301(var12);
      return new DrawPipeline(var10002, 4, true, var10005, 123013172433504L);
   }

   private static void lambda$createBuffer$0(int var0, RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = var0;
      GL11.glBindTexture(3553, var6);
   }

   static {

      {

      long var10001 = 85277853090910L ^ 20568264395718L;
      c();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(85277853090910L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[9];
      String var15 = "Í¡ë²w\u0087Ö¼&F<Ï\u001b9\u0001zëj?óþay\f\u0010lFâU\u009d²À\u007f-û3³Æ>\u0019\u008c ÂÿU§Ä«ï\u001c\u0012»ø|3íÔ\u0083ó\\q\u00adº\u008fº\u0000¬ð1\u0006LÏî¹\u0018\u009e`]§\u007f@\u0097º\u008d§ôªé\u007f½\u00178¡Â99\u008bæQ80\u009fô\u0007{-òÙ-\u000fdò\u0001î»Óã£ñ\u007fÞøû\u0081\u0014h\u008d\u0087\u001cc\f\u008f%\u0018£\u0087£\u000b©Ï\nlÿ'é\u0090\u0091Ó\u0012\u008e \u001d\u008fì½\u0099(ü~Ò§9:\u0011Á\u0096U§@V±©+U@[¿WÎ\u0017®\u0092_±µ\u0092\u0011øHâ\u0084\u0000¸ls£×\u0018b¢# ¼´8q\u0006K_Vþ¶ØpÙ¬\u009eë(\f\u009f9";
      int var17 = "Í¡ë²w\u0087Ö¼&F<Ï\u001b9\u0001zëj?óþay\f\u0010lFâU\u009d²À\u007f-û3³Æ>\u0019\u008c ÂÿU§Ä«ï\u001c\u0012»ø|3íÔ\u0083ó\\q\u00adº\u008fº\u0000¬ð1\u0006LÏî¹\u0018\u009e`]§\u007f@\u0097º\u008d§ôªé\u007f½\u00178¡Â99\u008bæQ80\u009fô\u0007{-òÙ-\u000fdò\u0001î»Óã£ñ\u007fÞøû\u0081\u0014h\u008d\u0087\u001cc\f\u008f%\u0018£\u0087£\u000b©Ï\nlÿ'é\u0090\u0091Ó\u0012\u008e \u001d\u008fì½\u0099(ü~Ò§9:\u0011Á\u0096U§@V±©+U@[¿WÎ\u0017®\u0092_±µ\u0092\u0011øHâ\u0084\u0000¸ls£×\u0018b¢# ¼´8q\u0006K_Vþ¶ØpÙ¬\u009eë(\f\u009f9"
         .length();
      char var14 = 24;
      int var28 = -1;

      label54:
      while (true) {
         String var29 = var15.substring(++var28, var28 + var14);
         
            byte[] var19 = var11.doFinal(var29.getBytes("ISO-8859-1"));
            String var42 = a(var19).intern();
            switch (var34) {
               case 0:
                  var18[var16++] = var42;
                  if ((var28 += var14) >= var17) {
                     p = var18;
                     q = new String[9];
                     x = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(85277853090910L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "Ï!(½\u0004\u0011\u008cVâÈ\u009dÂ\"¹\u0012É\u000fÑ«\u0092\u008c\f'\b\u0010fê¸\u0098U\u009bÅ{àÝ\u009ckª°{Aí]ûµojb";
                     int var5 = "Ï!(½\u0004\u0011\u008cVâÈ\u009dÂ\"¹\u0012É\u000fÑ«\u0092\u008c\f'\b\u0010fê¸\u0098U\u009bÅ{àÝ\u009ckª°{Aí]ûµojb".length();
                     label36:
                     while (true) {
                        int var38 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                        long[] var32 = var6;
                        int var39 = var3++;
                        long var46 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var46;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var51 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var49) {
                              case 0:
                                 var32[var39] = var51;
                                 if (var2 >= var5) {
                                    v = var6;
                                    w = new Integer[8];
                                    GlProgram var33 = ShaderPrograms.b;
                                    Object[] var10005 = new Object[]{null, null, 104709695459224L};
                                    var10005[1] = 0;
                                    var10005[0] = "texSampler";
                                    Object[] var25 = var10005;
                                    GlProgram var24 = var33;
                                    var24.aReturningVoid(var25);
                                    break;
                                 }
                                 break;
                              default:
                                 var32[var39] = var51;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u0006aÖN\u0019UÈ\u009c\\\u007f¯\u0086Lëtû";
                                 var5 = "\u0006aÖN\u0019UÈ\u009c\\\u007f¯\u0086Lëtû".length();
                                 var2 = 0;
                           }

                           int var40 = var2;
                           var2 += 8;
                           var7 = var4.substring(var40, var2).getBytes("ISO-8859-1");
                           var32 = var6;
                           var39 = var3++;
                           var46 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var49 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var28);
                  break;
               default:
                  var18[var16++] = var42;
                  if ((var28 += var14) < var17) {
                     var14 = var15.charAt(var28);
                     continue label54;
                  }

                  var15 = "|\u009f\u0095ªazÁÎ]\u007f\u0083\u000e\u0003ß»ü ©\u001fÛÈ|g\u008aØ<\u0012\u001a\u007f\u0098KQ\u0010BÝ\u001f\u0086®kÐ_ø<gåpè.ù";
                  var17 = "|\u009f\u0095ªazÁÎ]\u007f\u0083\u000e\u0003ß»ü ©\u001fÛÈ|g\u008aØ<\u0012\u001a\u007f\u0098KQ\u0010BÝ\u001f\u0086®kÐ_ø<gåpè.ù"
                     .length();
                  var14 = ' ';
                  var28 = -1;
            }

            var29 = var15.substring(++var28, var28 + var14);
            var34 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 3256;
      if (q[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])r.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dd", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = p[var5].getBytes("ISO-8859-1");
         q[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return q[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dd_C0172",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 12932;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dd", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dd_C0172",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 15;
            yield var15;
         }
         case 1 -> {
            byte var16 = 16;
            yield var16;
         }
         case 2 -> {
            byte var17 = 17;
            yield var17;
         }
         case 3 -> {
            byte var18 = 26;
            yield var18;
         }
         case 4 -> {
            byte var19 = 14;
            yield var19;
         }
         case 5 -> {
            byte var20 = 35;
            yield var20;
         }
         case 6 -> {
            byte var21 = 58;
            yield var21;
         }
         case 7 -> {
            byte var22 = 49;
            yield var22;
         }
         case 8 -> {
            byte var23 = 60;
            yield var23;
         }
         case 9 -> {
            byte var24 = 13;
            yield var24;
         }
         case 10 -> {
            byte var25 = 27;
            yield var25;
         }
         case 11 -> {
            byte var26 = 44;
            yield var26;
         }
         case 12 -> {
            byte var27 = 5;
            yield var27;
         }
         case 13 -> {
            byte var28 = 32;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 46;
            yield var30;
         }
         case 16 -> {
            byte var31 = 18;
            yield var31;
         }
         case 17 -> {
            byte var32 = 23;
            yield var32;
         }
         case 18 -> {
            byte var33 = 3;
            yield var33;
         }
         case 19 -> {
            byte var34 = 11;
            yield var34;
         }
         case 20 -> {
            byte var35 = 55;
            yield var35;
         }
         case 21 -> {
            byte var36 = 28;
            yield var36;
         }
         case 22 -> {
            byte var37 = 6;
            yield var37;
         }
         case 23 -> {
            byte var38 = 19;
            yield var38;
         }
         case 24 -> {
            byte var39 = 43;
            yield var39;
         }
         case 25 -> {
            byte var40 = 42;
            yield var40;
         }
         case 26 -> {
            byte var41 = 29;
            yield var41;
         }
         case 27 -> {
            byte var42 = 24;
            yield var42;
         }
         case 28 -> {
            byte var43 = 63;
            yield var43;
         }
         case 29 -> {
            byte var44 = 54;
            yield var44;
         }
         case 30 -> {
            byte var45 = 20;
            yield var45;
         }
         case 31 -> {
            byte var46 = 22;
            yield var46;
         }
         case 32 -> {
            byte var47 = 37;
            yield var47;
         }
         case 33 -> {
            byte var48 = 34;
            yield var48;
         }
         case 34 -> {
            byte var49 = 21;
            yield var49;
         }
         case 35 -> {
            byte var50 = 10;
            yield var50;
         }
         case 36 -> {
            byte var51 = 7;
            yield var51;
         }
         case 37 -> {
            byte var52 = 53;
            yield var52;
         }
         case 38 -> {
            byte var53 = 59;
            yield var53;
         }
         case 39 -> {
            byte var54 = 2;
            yield var54;
         }
         case 40 -> {
            byte var55 = 8;
            yield var55;
         }
         case 41 -> {
            byte var56 = 51;
            yield var56;
         }
         case 42 -> {
            byte var57 = 39;
            yield var57;
         }
         case 43 -> {
            byte var58 = 56;
            yield var58;
         }
         case 44 -> {
            byte var59 = 25;
            yield var59;
         }
         case 45 -> {
            byte var60 = 41;
            yield var60;
         }
         case 46 -> {
            byte var61 = 45;
            yield var61;
         }
         case 47 -> {
            byte var62 = 50;
            yield var62;
         }
         case 48 -> {
            byte var63 = 61;
            yield var63;
         }
         case 49 -> {
            byte var64 = 57;
            yield var64;
         }
         case 50 -> {
            byte var65 = 1;
            yield var65;
         }
         case 51 -> {
            byte var66 = 30;
            yield var66;
         }
         case 52 -> {
            byte var67 = 9;
            yield var67;
         }
         case 53 -> {
            byte var68 = 12;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 38;
            yield var70;
         }
         case 56 -> {
            byte var71 = 31;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 52;
            yield var73;
         }
         case 59 -> {
            byte var74 = 47;
            yield var74;
         }
         case 60 -> {
            byte var75 = 40;
            yield var75;
         }
         case 61 -> {
            byte var76 = 48;
            yield var76;
         }
         case 62 -> {
            byte var77 = 4;
            yield var77;
         }
         default -> 33;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      y[0] = "9bFk8p<wMk;w3~F)z@\u001a!\u0010";
      y[1] = int.class;
      z[1] = "java/lang/Integer";
      y[2] = void.class;
      z[2] = "java/lang/Void";
      y[3] = "\u001cWh4cb\u0019Bc4`e\u0016Khv!R?\u0014<";
      y[4] = "@u>\u001c:\u001fVu;F)\bA>8@%\u001cPy/Wn\ti";
      y[5] = "/)\u000e\u0013;YZ\t\u0005\u001c*\u0016;\u0007\u000e\u0017.LO";
      y[6] = "e[\u001bo\"hnT\n Ej{_\nk~";
      y[7] = "L\u0018!bk!R\u0010;-\b5V";
      y[8] = "\u0016R~b\u00191\u001d]o-x?\u0016Vkw";
      y[9] = "WR;l\u000f6IZ!#G6SP9dN-\u0013u8cB7T\\#";
      y[10] = "tuAO&ObuD\u00155Xu>G\u00139LdyP\u0004r^~";
      y[11] = "AA2M\u0017\u001c4a9B\u0006SUo2I\u0002\t!";
      y[12] = "s\u0006:c\u0011Ye\u0006?9\u0002NrM<?\u000eZc\n+(EKF";
      y[13] = "R\u000f5{\u001eKD\u000f0!\r\\SD3'\u0001HB\u0003$0J]f";
      y[14] = "'}U\u0018(^R]^\u00179\u00113SU\u001c=KG";
      y[15] = "\u001e\u0005Sp #\b\u0005V*34\u001fNU,? \u000e\tB;t4>";
      y[16] = "E>e\u001fF!0\u001en\u0010WnQ\u0010e\u001bS4%";
      y[17] = "K;g;\u0017L];ba\u0004[Jpag\bO[7vpC[i";
      y[18] = "I\u000bBK0\u0012<+ID!]]%BO%\u0007)";
      y[19] = "b\u000bN|\u001d\u001b\u0017+Es\fTv%Nx\b\u000e\u0002";
      y[20] = "r\u0017\u001f&b`d\u0017\u001a|qws\\\u0019z}cb\u001b\u000em6w\\";
      y[21] = "\t~\u0018&\u000bU|^\u0013)\u001a\u001a\u001dP\u0018\"\u001e@i";
      y[22] = "\u0010\u0016{FiP\u0006\u0016~\u001czG\u0011]}\u001avS\u0000\u001aj\r=G=";
      y[23] = "\u0003A\\b94vaWm({\u0017o\\f,!c";
      y[24] = ")yVM\u007f\n?yS\u0017l\u001d(2P\u0011`\t9uG\u0006+\u001d\u0005";
      y[25] = "ph+V~)fh.\fm>q#-\na*`d:\u001d*:,";
      y[26] = "DM-\tI`1m&\u0006X/Pc-\r\\u$";
      y[27] = ">n\t8\u0010h(n\fb\u0003\u007f?%\u000fd\u000fk.b\u0018sD{n";
      y[28] = "3#]L}hF\u0003VCl''\r]Hh}S";
      y[29] = "M\u0015A2%\u007f[\u0015Dh6hL^Gn:|]\u0019PyqhP";
      y[30] = "#\u0000C\u0006\nZ(\u000fRIwB;\b[\u0000";
      y[31] = float.class;
      z[31] = "java/lang/Float";
      y[32] = "y{)'\n:rt8hw/`n:+";
      y[33] = long.class;
      z[33] = "java/lang/Long";
      y[34] = "7\u00140\u0010?h!\u00145J,\u007f6_6L k'\u0018![k{\f";
      y[35] = "N\u0016,\u0016\u0007>;6'\u0019\u0016qZ8,\u0012\u0012+.";
      y[36] = "\u0000\u0011-d):u1&k8u\u0014?-`</`";
      y[37] = "\u0012|\u001b>\"L\u0004|\u001ed1[\u00137\u001db=O\u0002p\nuvX\u0012";
      y[38] = "Ez]\u0018_`NuLW<m[xC<\toJk_\u0010\u001eb";
      y[39] = "\u0006\u0014n`>w[Vo;\\rS\tvg\u001bb:\u00101u\"0EQ`c\\0C\bah'm\u0001\t:\n";
      y[40] = "\u001dSf\u0015J^\u0004\u0007:\u0011sCz\u00126EJ\u001e\u000b\u0006i\u0000\u000b.C\u000ei\u001e\nI\u0003\u0016j\u0018s";
      y[41] = "(+L\u000f\u000eNy/N\rp\u001b\u0019l\r\fIBhxRI\brs-PI\u0016M|qVQp";
      y[42] = "e\u0018Y,[\";JY5d(?\u0017H7\u0018.\u0019\u001cy \u001f.>\u000e0w\u001b;?\u000e\r8\u0018'<r\u000e/T%4\u000bTvZ&XOO2\u0003?e\u0000L.\u0000C";
      y[43] = "\u000b\u000bFl\u0011\u0016\bI\u0016z~\u0011h\u0015G4\fDX\r@zBx\f\u0014Ya\u001cB\u0019\u000b\u001di~\u001b\u0012\u0010Ae\u0010\u0018P@W\n";
      y[44] = "{\u0012P\u0014\u0014\u0014iOV\u001fp\u0013\u001b\u0006\u000bCIJj\u0012T\u0006\bz OH\u0019\u000e\u0006v\u0007ZCp";
      y[45] = "+\u0013\u0010\u001d\u0016E5R\u001a\u0017vP3\u0013Q@\u0010G\u0012\bN@3Z*\rJVv]\u007f\fJQ\u0015Tv\u0019Y-";
      y[46] = "Gid\u0014\u001c\f\u0016mf\u0016bZv.%\u0017[\u0000\u0007:zR\u001a0\u001d:{C\u0005\bG;z\u0016b";
      y[47] = "\rj7|\r\t\u000e(gjb\u000enmle\u001c[\u0011,=sb\u0004\u0014q0u\f\u0007V!&\u001a";
      y[48] = "ZY)4#z\u0007\u0012}1\u0018(e\u0018-e!q\u0014\fr `AU\u001cx0b0\b\th2\u0018";
      y[49] = "\u000b\u0006\bj\u001fI_K\t\u0006\u001eG.\u0016\u001ej-N\u0014\u000b\u0005|\u001c#\u0019M\u0007xM\\X\u001c\u0011\u0006\f\u0019\u001b\tDyMH\rwAb\u0012C\u001d\u0010\u0001z\u0011Ed";
      y[50] = "\u0018sfhBZIwdj<\u000f)4'k\u0005VX x.Df\u0018sfhBZIwdj<";
      y[51] = "Crl\"\b\u0012\u000b!c)h\u0012\u001d\u0007w8\t\u0003\u0014\u0012q4\u0014\u0000\u0003#\u001c9R\u0002\u0007rcx\u0003\u0014ywx'\b\u0004\u001e7`$\u000e}";
      y[52] = "[\\\u001ec!\u0001\nX\u001ca_Tj\u001b_`f\r\u001b\u000f\u0000%'=\u0007[_%=[\u000b\n\u0007>_";
      y[53] = "- z\u00155h|$x\u0017K=\u001cg;\u0016rdmsdS3Trpf\u0012!6pbuWK";
      y[54] = "VW_fKoU\u0015\u000fp$h5I^>V=\u0005QYp\u0018\u0001QH@kF;DW\u0004c$ePSUb\u001epO\u0017]\u0000G{TKQnD9\u0004]>";
      y[55] = "J,\u0019\u00165\u001dK5\u0012\u0011RH++U\u0013k\u0012Z?\nV*\"J,\u0019\u00165\u001dK5\u0012\u0011R";
      y[56] = ".&\u0015?!:xn\u0007e_/\u0015oVefvd{\t 'Fh-\u0015 c9)|\u0003^";
      y[57] = "$\u0002I,\u0003wu\u0006K.}\"\u0015E\b/D{dQWj\u0005KzE_\u007f\u0006.%FE.}";
      y[58] = "::\u0015\u000b\\\u000blr\u0007Q\"\u001e\u0001sVQ\u001bGpg\t\u0014Zw8o\t\n[\u0010xw\n\f\"";
      y[59] = "Bt\u0015a\r\u0012\u0004z\tts\u0004:j\b&O\u0004\u0001|\no\bmCkH\"\u001aVUi\u0001es";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(600088410847641L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(600088410847641L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(600088410847641L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 89;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 244;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 229;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 99;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 225;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 72;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 89;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 244;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 229;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dd_C0172",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dd" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(RainbowEffect var0, int var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dd_C0172;I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dd_C0172",
                     "lambda$createBuffer$1",
                     "(ILjava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var3.invokeExact((RainbowEffect)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Consumer invokeBinding2(RainbowEffect var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dd_C0172;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/dd_C0172", "lambda$getPipeline$2", "(Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((RainbowEffect)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntSupplier invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding4(int var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(I)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/dd_C0172", "lambda$createBuffer$0", "(ILdev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
