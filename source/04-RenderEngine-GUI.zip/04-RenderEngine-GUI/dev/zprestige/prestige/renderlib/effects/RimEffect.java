package dev.zprestige.prestige.renderlib.effects;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderPassSequence;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RLUniforms;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class RimEffect extends FramebufferEffect {
   private final Color a;
   private static final long m = 44421343829628L;
   private static final String[] p;
   private static final String[] q;
   private static final Map r = new HashMap(13);
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x;
   private static final Object[] y = new Object[61];
   private static final String[] z = new String[61];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public RimEffect(long var1) {
      super("shaders/post.vert", "shaders/chams_outline.frag", ((44421343829628L ^ (44421343829628L ^ var1)) ^ 24752189979453L));
      var1 = 44421343829628L ^ var1;
      long var3 = var1 ^ 24752189979453L;
      short var10001 = 293;
      long var10002 = 1344493920394271198L ^ var1;
      short var6 = 2464;
      long var10003 = 7706381246441378138L ^ var1;

      this.a = Color.WHITE;
   }

   @Override
   protected GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      int var2 = (Integer)var1[1];
      long var3 = (Long)var1[2];
      long var6 = var3 ^ 52933111772063L;
      Map var10001 = this.j;
      int var8 = var2;
      Integer var10002 = var8;
      Function var11 = invokeBinding1(this, var2);
      Integer var10 = var10002;
      Map var9 = var10001;
      Object[] var13 = new Object[]{(DrawPipeline)var9.computeIfAbsent(var10, var11), var6};
      MeshBufferManager var12 = var5;
      return var12.aReturningGlBufferMeshBuilder(var13);
   }

   @Override
   public void cReturningVoid(Object[] var1) {
      RLUniforms var2 = (RLUniforms)var1[0];
      long var3 = (Long)var1[1];
      short var10001 = 13617;
      long var10002 = 1587671055444272693L ^ var3;
      Color var5 = this.a;
      float var24 = var5.getRed() / 255.0F;
      Color var6 = this.a;
      float var10003 = var6.getGreen() / 255.0F;
      Color var7 = this.a;
      float var10004 = var7.getBlue() / 255.0F;
      Color var8 = this.a;
      float var14 = var8.getAlpha() / 255.0F;
      float var13 = var10004;
      float var12 = var10003;
      float var11 = var24;
      String var10 = "color";
      RLUniforms var9 = var2;
      RLUniforms var10000 = var9.aReturningVoid(var10, var11, var12, var13, var14);
      var10001 = 6598;
      var10002 = 6374181364487801542L ^ var3;
      float var17 = 0.5F;
      String var16 = "opacity";
      RLUniforms var15 = var10000;
      var10000 = var15.aReturningVoid(var16, var17);
      var10001 = 32064;
      var10002 = 8052785566863732290L ^ var3;
      float var20 = 2.0F;
      String var19 = "rimWidth";
      RLUniforms var18 = var10000;
      var18.aReturningVoid(var19, var20);
   }

   @Override
   public RenderPassSequence aReturningc4(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 89607565886074L;
      RenderPassSequence var10000 = new RenderPassSequence();
      Object[] var7 = new Object[0];
      RimEffect var6 = this;
      Object[] var9 = new Object[]{var6.aReturningfM_C0295(var7), invokeBinding2(this), invokeBinding3(), var4};
      RenderPassSequence var8 = var10000;
      return var8.bReturningVoid(var9);
   }

   private void lambda$getPipeline$2(RenderPass var1) {
      long var10001 = 55591529124311L ^ 22482171876872L;
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var8 = this.h.a;
      GL11.glBindTexture(3553, var8);
      Object[] var10 = new Object[]{42871835510751L};
      RimEffect var9 = this;
      var9.eReturningVoid(var10);
      Object[] var12 = new Object[0];
      RimEffect var11 = this;
      GlProgram var20 = var11.aReturningfM_C0295(var12);
      Object[] var14 = new Object[0];
      GlProgram var13 = var20;
      int var15 = var13.aReturningInt(var14);
      RLUniforms var21 = RLUniforms.aReturningVoid(var15);
      float var10002 = 1.0F / this.d;
      float var19 = 1.0F / this.e;
      float var18 = var10002;
      String var17 = "oneTexel";
      RLUniforms var16 = var21;
      var16.aReturningVoid(var17, var18, var19);
   }

   private DrawPipeline lambda$createBuffer$1(int var1, Integer var2) {
      long var10001 = 107315052412669L ^ 15921576012957L;
      VertexFormat var10002 = VertexFormats.c;
      RenderState[] var10005 = new RenderState[6];
      Object[] var7 = new Object[]{this.g.a};
      var10005[0] = RenderState.aReturninggJ_C0343(var7);
      Object[] var8 = new Object[]{ShaderPrograms.b};
      var10005[1] = RenderState.aReturninggH_C0339(var8);
      Object[] var10012 = new Object[]{null, null, true};
      var10012[1] = false;
      var10012[0] = 2884;
      Object[] var9 = var10012;
      var10005[2] = RenderState.bReturninggF_C0335(var9);
      Object[] var10011 = new Object[]{null, true};
      var10011[0] = true;
      Object[] var10 = var10011;
      var10005[3] = RenderState.aReturninggI_C0341(var10);
      var10011 = new Object[]{null, 515};
      var10011[0] = 519;
      Object[] var11 = var10011;
      var10005[4] = RenderState.aReturninggD_C0331(var11);
      Object[] var12 = new Object[]{invokeBinding4(var1)};
      var10005[5] = RenderState.aReturningfP_C0301(var12);
      return new DrawPipeline(var10002, 4, true, var10005, 123013172433504L);
   }

   private static void lambda$createBuffer$0(int var0, RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = var0;
      GL11.glBindTexture(3553, var6);
   }

   static {

      {

      long var10001 = 2725625704759L ^ 102534756728495L;
      c();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(2725625704759L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[7];
      String var15 = "#W°³ã\u0003Þ\u0016¸N,¦ÒE\u0019G\u001avL\u0001\b6U\u0092\u0018\u0083\u0094§b\u0086õð\u0084£ \u008dö§\u0092e¿èI×à\u0093\u0095Â2\u0010NOùn;Ö\u0011ó\u0098Ü¦\u0095Í\u001f\nÜ K\u0007)Í¨\u0098\t\u008e¨Ãð\u0012.Bá5\u009dM_Ñ\u0006Z°\u0015G\u0007\u009f9¯ØÇn0h^æ~,\u0010¢c7\u000eb\u0006®üT_'-\u0081\u000b\u000bâ\u0096ó\u00101-Î³«¢òú[\u0007¼\u0017S'ù¤\u0013Ã\u001cxGøö";
      int var17 = "#W°³ã\u0003Þ\u0016¸N,¦ÒE\u0019G\u001avL\u0001\b6U\u0092\u0018\u0083\u0094§b\u0086õð\u0084£ \u008dö§\u0092e¿èI×à\u0093\u0095Â2\u0010NOùn;Ö\u0011ó\u0098Ü¦\u0095Í\u001f\nÜ K\u0007)Í¨\u0098\t\u008e¨Ãð\u0012.Bá5\u009dM_Ñ\u0006Z°\u0015G\u0007\u009f9¯ØÇn0h^æ~,\u0010¢c7\u000eb\u0006®üT_'-\u0081\u000b\u000bâ\u0096ó\u00101-Î³«¢òú[\u0007¼\u0017S'ù¤\u0013Ã\u001cxGøö"
         .length();
      char var14 = 24;
      int var28 = -1;

      label54:
      while (true) {
         String var29 = var15.substring(++var28, var28 + var14);
         
            byte[] var19 = var11.doFinal(var29.getBytes("ISO-8859-1"));
            String var42 = a(var19).intern();
            switch (var34) {
               case 0:
                  var18[var16++] = var42;
                  if ((var28 += var14) >= var17) {
                     p = var18;
                     q = new String[7];
                     x = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(2725625704759L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "`Ý\u0018Æ°ÕT\u0005\u0003\u0090z\u0099¯Çd46\u0019\u0086P8\u0093«~P\u009aw\u0085C5\nÿ\u0013dQh^\u001f\u0088\u001f{hå\u0085.X¤ü";
                     int var5 = "`Ý\u0018Æ°ÕT\u0005\u0003\u0090z\u0099¯Çd46\u0019\u0086P8\u0093«~P\u009aw\u0085C5\nÿ\u0013dQh^\u001f\u0088\u001f{hå\u0085.X¤ü"
                        .length();
                     label36:
                     while (true) {
                        int var38 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                        long[] var32 = var6;
                        int var39 = var3++;
                        long var46 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var46;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var51 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var49) {
                              case 0:
                                 var32[var39] = var51;
                                 if (var2 >= var5) {
                                    v = var6;
                                    w = new Integer[8];
                                    GlProgram var33 = ShaderPrograms.b;
                                    Object[] var10005 = new Object[]{null, null, 104709695459224L};
                                    var10005[1] = 0;
                                    var10005[0] = "texSampler";
                                    Object[] var25 = var10005;
                                    GlProgram var24 = var33;
                                    var24.aReturningVoid(var25);
                                    break;
                                 }
                                 break;
                              default:
                                 var32[var39] = var51;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "\u009bÈ,j\u001bß]v\u009bÕLqþd`ª";
                                 var5 = "\u009bÈ,j\u001bß]v\u009bÕLqþd`ª".length();
                                 var2 = 0;
                           }

                           int var40 = var2;
                           var2 += 8;
                           var7 = var4.substring(var40, var2).getBytes("ISO-8859-1");
                           var32 = var6;
                           var39 = var3++;
                           var46 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var49 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var28);
                  break;
               default:
                  var18[var16++] = var42;
                  if ((var28 += var14) < var17) {
                     var14 = var15.charAt(var28);
                     continue label54;
                  }

                  var15 = "~¦©\u0091¿5È[lØÛBÈðuÁm¾\u0086\u001ek[ÖýÜZåÔÏ@¿AR`j\u0095<\"\u001eW\u0010\u0090bçÊ!¦¦¹]³\u001fÖÓJ]¨";
                  var17 = "~¦©\u0091¿5È[lØÛBÈðuÁm¾\u0086\u001ek[ÖýÜZåÔÏ@¿AR`j\u0095<\"\u001eW\u0010\u0090bçÊ!¦¦¹]³\u001fÖÓJ]¨".length();
                  var14 = '(';
                  var28 = -1;
            }

            var29 = var15.substring(++var28, var28 + var14);
            var34 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 20133;
      if (q[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])r.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/db", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = p[var5].getBytes("ISO-8859-1");
         q[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return q[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/db_C0168",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/db" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 15625;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/db", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/db_C0168",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/db" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 25;
            yield var15;
         }
         case 1 -> {
            byte var16 = 36;
            yield var16;
         }
         case 2 -> {
            byte var17 = 15;
            yield var17;
         }
         case 3 -> {
            byte var18 = 58;
            yield var18;
         }
         case 4 -> {
            byte var19 = 49;
            yield var19;
         }
         case 5 -> {
            byte var20 = 0;
            yield var20;
         }
         case 6 -> {
            byte var21 = 50;
            yield var21;
         }
         case 7 -> {
            byte var22 = 17;
            yield var22;
         }
         case 8 -> {
            byte var23 = 45;
            yield var23;
         }
         case 9 -> {
            byte var24 = 63;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 13;
            yield var26;
         }
         case 12 -> {
            byte var27 = 59;
            yield var27;
         }
         case 13 -> {
            byte var28 = 38;
            yield var28;
         }
         case 14 -> {
            byte var29 = 47;
            yield var29;
         }
         case 15 -> {
            byte var30 = 41;
            yield var30;
         }
         case 16 -> {
            byte var31 = 39;
            yield var31;
         }
         case 17 -> {
            byte var32 = 48;
            yield var32;
         }
         case 18 -> {
            byte var33 = 11;
            yield var33;
         }
         case 19 -> {
            byte var34 = 62;
            yield var34;
         }
         case 20 -> {
            byte var35 = 31;
            yield var35;
         }
         case 21 -> {
            byte var36 = 44;
            yield var36;
         }
         case 22 -> {
            byte var37 = 28;
            yield var37;
         }
         case 23 -> {
            byte var38 = 34;
            yield var38;
         }
         case 24 -> {
            byte var39 = 6;
            yield var39;
         }
         case 25 -> {
            byte var40 = 35;
            yield var40;
         }
         case 26 -> {
            byte var41 = 40;
            yield var41;
         }
         case 27 -> {
            byte var42 = 9;
            yield var42;
         }
         case 28 -> {
            byte var43 = 23;
            yield var43;
         }
         case 29 -> {
            byte var44 = 10;
            yield var44;
         }
         case 30 -> {
            byte var45 = 19;
            yield var45;
         }
         case 31 -> {
            byte var46 = 21;
            yield var46;
         }
         case 32 -> {
            byte var47 = 43;
            yield var47;
         }
         case 33 -> {
            byte var48 = 3;
            yield var48;
         }
         case 34 -> {
            byte var49 = 26;
            yield var49;
         }
         case 35 -> {
            byte var50 = 52;
            yield var50;
         }
         case 36 -> {
            byte var51 = 27;
            yield var51;
         }
         case 37 -> {
            byte var52 = 51;
            yield var52;
         }
         case 38 -> {
            byte var53 = 53;
            yield var53;
         }
         case 39 -> {
            byte var54 = 55;
            yield var54;
         }
         case 40 -> {
            byte var55 = 12;
            yield var55;
         }
         case 41 -> {
            byte var56 = 33;
            yield var56;
         }
         case 42 -> {
            byte var57 = 42;
            yield var57;
         }
         case 43 -> {
            byte var58 = 54;
            yield var58;
         }
         case 44 -> {
            byte var59 = 2;
            yield var59;
         }
         case 45 -> {
            byte var60 = 1;
            yield var60;
         }
         case 46 -> {
            byte var61 = 5;
            yield var61;
         }
         case 47 -> {
            byte var62 = 61;
            yield var62;
         }
         case 48 -> {
            byte var63 = 4;
            yield var63;
         }
         case 49 -> {
            byte var64 = 8;
            yield var64;
         }
         case 50 -> {
            byte var65 = 29;
            yield var65;
         }
         case 51 -> {
            byte var66 = 60;
            yield var66;
         }
         case 52 -> {
            byte var67 = 32;
            yield var67;
         }
         case 53 -> {
            byte var68 = 20;
            yield var68;
         }
         case 54 -> {
            byte var69 = 18;
            yield var69;
         }
         case 55 -> {
            byte var70 = 37;
            yield var70;
         }
         case 56 -> {
            byte var71 = 24;
            yield var71;
         }
         case 57 -> {
            byte var72 = 7;
            yield var72;
         }
         case 58 -> {
            byte var73 = 56;
            yield var73;
         }
         case 59 -> {
            byte var74 = 57;
            yield var74;
         }
         case 60 -> {
            byte var75 = 30;
            yield var75;
         }
         case 61 -> {
            byte var76 = 14;
            yield var76;
         }
         case 62 -> {
            byte var77 = 46;
            yield var77;
         }
         default -> 22;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      y[0] = "aHKM\"z|]\u0013ocwd[";
      y[1] = int.class;
      z[1] = "java/lang/Integer";
      y[2] = "\u0002\u0002\n sW\u0014\u0002\u000fz`@\u0003I\f|lT\u0012\u000e\u001bk'@\u001f";
      y[3] = "@qYiH%K~H&5=XyAo";
      y[4] = float.class;
      z[4] = "java/lang/Float";
      y[5] = "x\\)ivfn\\,3eqy\u0017/5iehP8\"\"uC";
      y[6] = "uZ]8\f0\u0000zV7\u001d\u007fat]<\u0019%\u0015";
      y[7] = void.class;
      z[7] = "java/lang/Void";
      y[8] = "<\u00104I\u0018\u0001*\u00101\u0013\u000b\u0016=[2\u0015\u0007\u0002,\u001c%\u0002L\u0012`";
      y[9] = "wV-PTy\u0002v&_E6cx-TAl\u0017";
      y[10] = "0\u0014!ob\u0007&\u0014$5q\u00101_'3}\u0004 \u00180$6\u0011\u0019";
      y[11] = "$\tB\\\n=!\u001cI\\\t:.\u0015B\u001eH\r\u0007J\u0014";
      y[12] = ".z\u0019?@=+o\u0012?C:$f\u0019}\u0002\r\r9M";
      y[13] = "\u001dsY\u0016! hSR\u00190o\t]Y\u001245}";
      y[14] = "ep!c\u001f}sp$9\fjd;'?\u0000~u|0(Kn5";
      y[15] = "d8\u0004\u0017~&\u0011\u0018\u000f\u0018oip\u0016\u0004\u0013k3\u0004";
      y[16] = "#OE0\u000eV(@T\u007fiT=KT4R";
      y[17] = "k\bAs;3u\u0000[<X'q";
      y[18] = "0,=sA;;#,< 50((f";
      y[19] = "i\u0001\u00142?aw\t\u000e}wam\u0003\u0016:~z-&\u0017=r`j\u000f\f";
      y[20] = "&t<t\u0001N0t9.\u0012Y'?:(\u001eM6x-?U_,";
      y[21] = "UHnC9K heL(\u0004AfnG,^5";
      y[22] = "\u0014'/9C\u001d\u0002'*cP\n\u0015l)e\\\u001e\u0004+>r\u0017\u000f!";
      y[23] = "Eh\u001eP2\fSh\u001b\n!\u001bD#\u0018\f-\u000fUd\u000f\u001bf\u001aq";
      y[24] = "g!?\u000bum\u0012\u00014\u0004d\"s\u000f?\u000f`x\u0007";
      y[25] = "KY\u0002J6r]Y\u0007\u0010%eJ\u0012\u0004\u0016)q[U\u0013\u0001bek";
      y[26] = "U\u0007JA`# 'ANqlA)JEu65";
      y[27] = "gw\u000epI*qw\u000b*Z=f<\b,V)w{\u001f;\u001d=E";
      y[28] = "EY\b9\u0011\u000e0y\u00036\u0000AQw\b=\u0004\u001b%";
      y[29] = "\u001bvX\"\u0002MnVS-\u0013\u0002\u000fXX&\u0017X{";
      y[30] = "cKQhmBuKT2~Ub\u0000W4rAsG@#9UM";
      y[31] = "Q\u0006i\u001doR$&b\u0012~\u001dE(i\u0019zG1";
      y[32] = "\u001aKk\u0004pi\fKn^c~\u001b\u0000mXoj\nGzO$~7";
      y[33] = "r_\u0016\u0001h@\u0007\u007f\u001d\u000ey\u000ffq\u0016\u0005}U\u0012";
      y[34] = "D]g0\u00131R]bj\u0000&E\u0016al\f2TQv{G&h";
      y[35] = "Gl\b*HF2L\u0003%Y\tSB\b.]S'";
      y[36] = "H\u000eP/\u00009^^\u000f)1-'RQ;M?\u001bX\u0000o\u000eDGD\u0001iQ<\u0016R\f&1";
      y[37] = "I |DV(\r?e4\u0002>\n\u0019{L\r:visHQ-\f9.Q\rS";
      y[38] = "LT\u0011\u001d!}\bK\bmEF2x?m%v\u0010TI\u0016ai\t";
      y[39] = "|\u0017\u0004\u001d\u0010S%\u001a\u001bXz]E_W\u001fCV!X\u0003Y\u001e4\u007f\u0015\u000bN\u0000\u000e7ZQEz\u000e5\u0004\u0003]@Fz^\b'@D$\f\u0010\u001d\b\u000b~\u0007j\u001d\nU,\u001fPUE\u000f'eSU\u0014\u000e/\u0002\nX\u000bKE";
      y[40] = "U>\t)\u0015IYh\u0016:{O8i\u0011-\u0007]\u0004c@yD&Vk\b2\u001bZJ1\b0{";
      y[41] = "\u007fv^n\u0003Gi&\u0001h2S\u0010*_zNA, \u000e.\r:\u007fv^n\u0003Gi&\u0001h2";
      y[42] = "ndw7(?x4(1\u0019+\u00018v#e9=2'w&Bd\",$v08.hp\u0019";
      y[43] = ":kp\u0013\u0003OcfoViA\u0003##\u0011PJg$wW\r(9i\u007f@\u0013\u0012q&%Ki\u0012sxwSSZ<\"|)PZm#tN\tWrf\u001e";
      y[44] = "kp*_T\u0016%$7Rj\rT.5\u0002\u0016\u001fh$dVUdm%)S\u0014\u001e=x0\u000fj";
      y[45] = "diZ\u0017H~r9\u0005\u0011yj\u000b5[\u0003\u0005x7?\nWF\u0003lhR\u0001\u0012}y4P\by";
      y[46] = "W\u001f5~\u001e\u007f\u0013\u0000,\u000eJi\u00145;b%=\u0004\u0013jp_mY\n6\u000e";
      y[47] = "<C\u001b&FW>H\u0003#=\u0006\u0007B\u001c*A\u0010;HM~\u0002k:\u0019ExMUh^\u0003+=";
      y[48] = "CVutd\u0012@A0$\u000b]@XssLM)\u0005bb7]SU?{k#CVutd\u0012@A0$\u000b";
      y[49] = ">5E@\u00132>3B\u001cm'3.WP\u0011!\u0015%fG\u0016!27/F\t0&3]\u0012Sv&KCL\u0014+,;I\\\u0017tT KQ\u001f4&t\u0011\u0017\u001fL";
      y[50] = "_\u007fA\r\u0010\u0015\u001b`X}D\u0003\u001cEF\u0000FnYc^AU\u0014\t>G\u001d+";
      y[51] = "FH>rtL\u001fE!7\u001eB\u007f\u0000mp'I\u001b\u000796z+EJ1!d\u0011\r\u0005k*\u001e\u0012\rTj\"yK\u0000K/H";
      y[52] = "Bo>(\u00176\u0012bx*/>\u007ftg|S,C~6(\u0010W@*x!\u0011%\u000e~e,/";
      y[53] = "\u001e&N`\u001a|G+Q%pr'mL&Le]=\u0011?\u0010\u001b\u001e&N`\u001a|G+Q%p";
      y[54] = "DcT`cbR3\u000bfRu+?Ut.d\u00175\u0004 m\u001fJ#G\u007f1xS`IkR";
      y[55] = ": 4||\u001cg;<:\u001cMa\r$%p~h79>fO\u0005~)? \\\u007f.t&|\"<+9\u007fbXlv #\u001c\u001f9~z3\"M~8)C";
      y[56] = "\r%z'#\u0001\r%y \u001a\u000fY\u0010\u007f2{\u001eP\u0005y>f\u001dG4\u0014wv\u001c\u0001'n'+\u0005]Y)r#_Mg{5e\f=";
      y[57] = "u\u0005z\u0016\u001dccU%\u0010,w\u001aY{\u0002Pe&S*V\u0013\u001eyEk\u0004\\\u007fh\u0006'\u0003,";
      y[58] = "\u0016%dF^;C0{E%;':~\u0010Y*\u001b0/D\u001aQ\u0016%dF^;C0{E%";
      y[59] = "$S\u0007r\u0015\u0000`L\u001e\u0002A\u0016gl\u001eoC\u001d\u001b\u001a\b~\u0012\u0005aJUgN{";
      y[60] = "!\u001df\u0001@YoI{\f~B\u001eCy\\\u0002P\"I(\bA+#\u0018 \u000e\u000e\u0015q_f]~";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(1280313106993547L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(1280313106993547L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(1280313106993547L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 229;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 70;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 212;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 214;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 253;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 107;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 229;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 70;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 212;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/db_C0168",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/db" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(RimEffect var0, int var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/db_C0168;I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/db_C0168",
                     "lambda$createBuffer$1",
                     "(ILjava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var3.invokeExact((RimEffect)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Consumer invokeBinding2(RimEffect var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/db_C0168;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/db_C0168", "lambda$getPipeline$2", "(Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((RimEffect)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntSupplier invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding4(int var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(I)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/db_C0168", "lambda$createBuffer$0", "(ILdev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
