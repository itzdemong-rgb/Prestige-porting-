package dev.zprestige.prestige.renderlib.effects;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.FramebufferEffect;
import dev.zprestige.prestige.renderlib.GlProgram;
import dev.zprestige.prestige.renderlib.MeshBufferManager;
import dev.zprestige.prestige.renderlib.RenderPassSequence;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.renderlib.GlBufferMeshBuilder;
import dev.zprestige.prestige.renderlib.RLUniforms;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.awt.Color;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntSupplier;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

public class SolidColorEffect extends FramebufferEffect {
   private final Color a;
   private static final long m = 81449373079691L;
   private static final String[] p;
   private static final String[] q;
   private static final Map r = new HashMap(13);
   private static final long[] v;
   private static final Integer[] w;
   private static final Map x;
   private static final Object[] y = new Object[63];
   private static final String[] z = new String[63];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;

   public SolidColorEffect(long var1) {
      super("shaders/post.vert", "shaders/outline.frag", ((81449373079691L ^ (81449373079691L ^ var1)) ^ 131705514874350L));
      var1 = 81449373079691L ^ var1;
      long var3 = var1 ^ 131705514874350L;
      short var10001 = 11518;
      long var10002 = 859865567156574219L ^ var1;
      short var6 = 26059;
      long var10003 = 3201281309707424060L ^ var1;

      this.a = Color.WHITE;
   }

   @Override
   protected GlBufferMeshBuilder bReturningGlBufferMeshBuilder(Object[] var1) {
      MeshBufferManager var5 = (MeshBufferManager)var1[0];
      int var4 = (Integer)var1[1];
      long var2 = (Long)var1[2];
      long var6 = var2 ^ 52933111772063L;
      Map var10001 = this.j;
      int var8 = var4;
      Integer var10002 = var8;
      Function var11 = invokeBinding1(this, var4);
      Integer var10 = var10002;
      Map var9 = var10001;
      Object[] var13 = new Object[]{(DrawPipeline)var9.computeIfAbsent(var10, var11), var6};
      MeshBufferManager var12 = var5;
      return var12.aReturningGlBufferMeshBuilder(var13);
   }

   @Override
   public void cReturningVoid(Object[] var1) {
      RLUniforms var4 = (RLUniforms)var1[0];
      long var2 = (Long)var1[1];
      short var10001 = 17410;
      long var10002 = 4546691629417862621L ^ var2;
      Color var5 = this.a;
      float var15 = var5.getRed() / 255.0F;
      Color var6 = this.a;
      float var10003 = var6.getGreen() / 255.0F;
      Color var7 = this.a;
      float var10004 = var7.getBlue() / 255.0F;
      Color var8 = this.a;
      float var14 = var8.getAlpha() / 255.0F;
      float var13 = var10004;
      float var12 = var10003;
      float var11 = var15;
      String var10 = "color";
      RLUniforms var9 = var4;
      var9.aReturningVoid(var10, var11, var12, var13, var14);
   }

   @Override
   public RenderPassSequence aReturningc4(Object[] var1) {
      long var2 = (Long)var1[0];
      long var4 = var2 ^ 89607565886074L;
      RenderPassSequence var10000 = new RenderPassSequence();
      Object[] var7 = new Object[0];
      SolidColorEffect var6 = this;
      Object[] var9 = new Object[]{var6.aReturningfM_C0295(var7), invokeBinding2(this), invokeBinding3(), var4};
      RenderPassSequence var8 = var10000;
      return var8.bReturningVoid(var9);
   }

   private void lambda$getPipeline$2(RenderPass var1) {
      long var10001 = 4188592662167L ^ 40900354187592L;
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var8 = this.h.a;
      GL11.glBindTexture(3553, var8);
      Object[] var10 = new Object[]{42871835510751L};
      SolidColorEffect var9 = this;
      var9.eReturningVoid(var10);
      Object[] var12 = new Object[0];
      SolidColorEffect var11 = this;
      GlProgram var53 = var11.aReturningfM_C0295(var12);
      Object[] var14 = new Object[0];
      GlProgram var13 = var53;
      int var15 = var13.aReturningInt(var14);
      RLUniforms var54 = RLUniforms.aReturningVoid(var15);
      int var41 = this.d;
      String var40 = "oneTexel";
      RLUniforms var39 = var54;
      RLUniforms var24 = var39;
      String var25 = var40;
      RLUniforms var22 = var39;
      String var23 = var40;
      RLUniforms var26;
      String var27;
      float var28;
      if (var41 > 0) {
         float var44 = 1.0F / this.d;
         String var43 = var23;
         RLUniforms var42 = var22;
         var26 = var42;
         var27 = var43;
         var28 = var44;
      } else {
         var28 = 0.0F;
         var27 = var25;
         var26 = var24;
      }

      int var48 = this.e;
      float var47 = var28;
      String var46 = var27;
      RLUniforms var45 = var26;
      RLUniforms var32 = var45;
      String var33 = var46;
      float var34 = var47;
      RLUniforms var29 = var45;
      String var30 = var46;
      float var31 = var47;
      RLUniforms var35;
      String var36;
      float var37;
      float var38;
      if (var48 > 0) {
         float var52 = 1.0F / this.e;
         float var51 = var31;
         String var50 = var30;
         RLUniforms var49 = var29;
         var35 = var49;
         var36 = var50;
         var37 = var51;
         var38 = var52;
      } else {
         var38 = 0.0F;
         var37 = var34;
         var36 = var33;
         var35 = var32;
      }

      float var21 = var38;
      float var20 = var37;
      String var19 = var36;
      RLUniforms var18 = var35;
      var18.aReturningVoid(var19, var20, var21);
   }

   private DrawPipeline lambda$createBuffer$1(int var1, Integer var2) {
      long var10001 = 114768347967505L ^ 8249204974193L;
      VertexFormat var10002 = VertexFormats.c;
      RenderState[] var10005 = new RenderState[6];
      Object[] var7 = new Object[]{this.g.a};
      var10005[0] = RenderState.aReturninggJ_C0343(var7);
      Object[] var8 = new Object[]{ShaderPrograms.b};
      var10005[1] = RenderState.aReturninggH_C0339(var8);
      Object[] var10012 = new Object[]{null, null, true};
      var10012[1] = false;
      var10012[0] = 2884;
      Object[] var9 = var10012;
      var10005[2] = RenderState.bReturninggF_C0335(var9);
      Object[] var10011 = new Object[]{null, true};
      var10011[0] = true;
      Object[] var10 = var10011;
      var10005[3] = RenderState.aReturninggI_C0341(var10);
      var10011 = new Object[]{null, 515};
      var10011[0] = 519;
      Object[] var11 = var10011;
      var10005[4] = RenderState.aReturninggD_C0331(var11);
      Object[] var12 = new Object[]{invokeBinding4(var1)};
      var10005[5] = RenderState.aReturningfP_C0301(var12);
      return new DrawPipeline(var10002, 4, true, var10005, 123013172433504L);
   }

   private static void lambda$createBuffer$0(int var0, RenderPass var1) {
      GL13.glActiveTexture(33984);
      short var10000 = 3553;
      int var6 = var0;
      GL11.glBindTexture(3553, var6);
   }

   static {

      {

      long var10001 = 65277991922655L ^ 110385352336455L;
      c();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(65277991922655L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[5];
      String var15 = "\u0084ýQV¤3×\u009c\u0084k\u0094jT÷K\u0003\u0004\f\u0004Ý/\u0087F1Ø»ÃØìë\u0091C( \u0017Ïqò\u000f\u009eå×\r,\u008bÁLÝ\u001f\u0005sÞ\u0007æ\u001e¦\u009d\u00adõD\u0090¿G?xÈ¥ØÝó×x/ \ré\u0099\u0097Óó\\Àþ\fï¢b\u0017TßwA*\u0083\\\u0019¤\u0089Î\u001e\u009c\u0001fVí0";
      int var17 = "\u0084ýQV¤3×\u009c\u0084k\u0094jT÷K\u0003\u0004\f\u0004Ý/\u0087F1Ø»ÃØìë\u0091C( \u0017Ïqò\u000f\u009eå×\r,\u008bÁLÝ\u001f\u0005sÞ\u0007æ\u001e¦\u009d\u00adõD\u0090¿G?xÈ¥ØÝó×x/ \ré\u0099\u0097Óó\\Àþ\fï¢b\u0017TßwA*\u0083\\\u0019¤\u0089Î\u001e\u009c\u0001fVí0"
         .length();
      char var14 = ' ';
      int var28 = -1;

      label54:
      while (true) {
         String var29 = var15.substring(++var28, var28 + var14);
         
            byte[] var19 = var11.doFinal(var29.getBytes("ISO-8859-1"));
            String var42 = a(var19).intern();
            switch (var34) {
               case 0:
                  var18[var16++] = var42;
                  if ((var28 += var14) >= var17) {
                     p = var18;
                     q = new String[5];
                     x = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(65277991922655L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[8];
                     String var4 = "NTf\u0087Ï[\u001eÐ¼:Q¨'\u0005\u0088\u0018°R;\u0014î\u009bº`ÐT\u00adÂ\u000f\u008d\u0012x3EÅä±\rÖ\u001d\u0080Iõ,!Hkd";
                     int var5 = "NTf\u0087Ï[\u001eÐ¼:Q¨'\u0005\u0088\u0018°R;\u0014î\u009bº`ÐT\u00adÂ\u000f\u008d\u0012x3EÅä±\rÖ\u001d\u0080Iõ,!Hkd".length();
                     label36:
                     while (true) {
                        int var38 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var38, var2).getBytes("ISO-8859-1");
                        long[] var32 = var6;
                        int var39 = var3++;
                        long var46 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var46;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var51 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var49) {
                              case 0:
                                 var32[var39] = var51;
                                 if (var2 >= var5) {
                                    v = var6;
                                    w = new Integer[8];
                                    GlProgram var33 = ShaderPrograms.b;
                                    Object[] var10005 = new Object[]{null, null, 104709695459224L};
                                    var10005[1] = 0;
                                    var10005[0] = "texSampler";
                                    Object[] var25 = var10005;
                                    GlProgram var24 = var33;
                                    var24.aReturningVoid(var25);
                                    break;
                                 }
                                 break;
                              default:
                                 var32[var39] = var51;
                                 if (var2 < var5) {
                                    continue label36;
                                 }

                                 var4 = "0s\u0000C\u001b}^Ü!\u0010x\bÿ©Dc";
                                 var5 = "0s\u0000C\u001b}^Ü!\u0010x\bÿ©Dc".length();
                                 var2 = 0;
                           }

                           int var40 = var2;
                           var2 += 8;
                           var7 = var4.substring(var40, var2).getBytes("ISO-8859-1");
                           var32 = var6;
                           var39 = var3++;
                           var46 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var49 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var28);
                  break;
               default:
                  var18[var16++] = var42;
                  if ((var28 += var14) < var17) {
                     var14 = var15.charAt(var28);
                     continue label54;
                  }

                  var15 = "+\u001a\u001dO©ÀüxÛ5\u0084h?3Sþ\u0094)F¯gX¨U-C\u00012*íIÔ¹\np\u0080ß¯áCêÝQ\u009aôÌð\u008e\u0010îa\u0080\u009d3Zz^\u0001K\u0093c¥rÅ\u0010";
                  var17 = "+\u001a\u001dO©ÀüxÛ5\u0084h?3Sþ\u0094)F¯gX¨U-C\u00012*íIÔ¹\np\u0080ß¯áCêÝQ\u009aôÌð\u008e\u0010îa\u0080\u009d3Zz^\u0001K\u0093c¥rÅ\u0010"
                     .length();
                  var14 = '0';
                  var28 = -1;
            }

            var29 = var15.substring(++var28, var28 + var14);
            var34 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 19580;
      if (q[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])r.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               r.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/dc", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = p[var5].getBytes("ISO-8859-1");
         q[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return q[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dc_C0170",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int c(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 2403;
      if (w[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = v[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])x.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               x.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/dc", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         w[var3] = var15;
      }

      return w[var3];
   }

   private static int c(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = c(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dc_C0170",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int i(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = z[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = y[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 21;
            yield var15;
         }
         case 1 -> {
            byte var16 = 20;
            yield var16;
         }
         case 2 -> {
            byte var17 = 13;
            yield var17;
         }
         case 3 -> {
            byte var18 = 12;
            yield var18;
         }
         case 4 -> {
            byte var19 = 39;
            yield var19;
         }
         case 5 -> {
            byte var20 = 1;
            yield var20;
         }
         case 6 -> {
            byte var21 = 15;
            yield var21;
         }
         case 7 -> {
            byte var22 = 55;
            yield var22;
         }
         case 8 -> {
            byte var23 = 18;
            yield var23;
         }
         case 9 -> {
            byte var24 = 40;
            yield var24;
         }
         case 10 -> {
            byte var25 = 60;
            yield var25;
         }
         case 11 -> {
            byte var26 = 23;
            yield var26;
         }
         case 12 -> {
            byte var27 = 61;
            yield var27;
         }
         case 13 -> {
            byte var28 = 7;
            yield var28;
         }
         case 14 -> {
            byte var29 = 16;
            yield var29;
         }
         case 15 -> {
            byte var30 = 50;
            yield var30;
         }
         case 16 -> {
            byte var31 = 58;
            yield var31;
         }
         case 17 -> {
            byte var32 = 44;
            yield var32;
         }
         case 18 -> {
            byte var33 = 0;
            yield var33;
         }
         case 19 -> {
            byte var34 = 48;
            yield var34;
         }
         case 20 -> {
            byte var35 = 26;
            yield var35;
         }
         case 21 -> {
            byte var36 = 17;
            yield var36;
         }
         case 22 -> {
            byte var37 = 42;
            yield var37;
         }
         case 23 -> {
            byte var38 = 11;
            yield var38;
         }
         case 24 -> {
            byte var39 = 8;
            yield var39;
         }
         case 25 -> {
            byte var40 = 29;
            yield var40;
         }
         case 26 -> {
            byte var41 = 10;
            yield var41;
         }
         case 27 -> {
            byte var42 = 6;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 56;
            yield var44;
         }
         case 30 -> {
            byte var45 = 57;
            yield var45;
         }
         case 31 -> {
            byte var46 = 30;
            yield var46;
         }
         case 32 -> {
            byte var47 = 35;
            yield var47;
         }
         case 33 -> {
            byte var48 = 38;
            yield var48;
         }
         case 34 -> {
            byte var49 = 62;
            yield var49;
         }
         case 35 -> {
            byte var50 = 41;
            yield var50;
         }
         case 36 -> {
            byte var51 = 27;
            yield var51;
         }
         case 37 -> {
            byte var52 = 52;
            yield var52;
         }
         case 38 -> {
            byte var53 = 14;
            yield var53;
         }
         case 39 -> {
            byte var54 = 37;
            yield var54;
         }
         case 40 -> {
            byte var55 = 19;
            yield var55;
         }
         case 41 -> {
            byte var56 = 47;
            yield var56;
         }
         case 42 -> {
            byte var57 = 9;
            yield var57;
         }
         case 43 -> {
            byte var58 = 4;
            yield var58;
         }
         case 44 -> {
            byte var59 = 28;
            yield var59;
         }
         case 45 -> {
            byte var60 = 63;
            yield var60;
         }
         case 46 -> {
            byte var61 = 43;
            yield var61;
         }
         case 47 -> {
            byte var62 = 46;
            yield var62;
         }
         case 48 -> {
            byte var63 = 3;
            yield var63;
         }
         case 49 -> {
            byte var64 = 49;
            yield var64;
         }
         case 50 -> {
            byte var65 = 34;
            yield var65;
         }
         case 51 -> {
            byte var66 = 22;
            yield var66;
         }
         case 52 -> {
            byte var67 = 32;
            yield var67;
         }
         case 53 -> {
            byte var68 = 53;
            yield var68;
         }
         case 54 -> {
            byte var69 = 5;
            yield var69;
         }
         case 55 -> {
            byte var70 = 25;
            yield var70;
         }
         case 56 -> {
            byte var71 = 59;
            yield var71;
         }
         case 57 -> {
            byte var72 = 54;
            yield var72;
         }
         case 58 -> {
            byte var73 = 2;
            yield var73;
         }
         case 59 -> {
            byte var74 = 33;
            yield var74;
         }
         case 60 -> {
            byte var75 = 24;
            yield var75;
         }
         case 61 -> {
            byte var76 = 31;
            yield var76;
         }
         case 62 -> {
            byte var77 = 36;
            yield var77;
         }
         default -> 51;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            z[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void c() {
      y[0] = "o\u0015`\u001f/Id\u001aqPHKq\u0011q\u001bs";
      y[1] = int.class;
      z[1] = "java/lang/Integer";
      y[2] = "9m\u0003\u007fV\u0003'e\u001905\u0017#";
      y[3] = "N#e\u001e\u007fOE,tQ\u001eAN'p\u000b";
      y[4] = "&_Y\u00006\u00018WCO~\u0001\"][\bw\u001abxZ\u000f{\u0000%QA";
      y[5] = "\u0002f`\u001f\\\u0011\u0014feEO\u0006\u0003-fCC\u0012\u0012jqT\b\u0000\b";
      y[6] = "@dFCo95DML~vTJFGz, ";
      y[7] = "\u0005P$\u0013\u000b\\\u0013P!I\u0018K\u0004\u001b\"O\u0014_\u0015\\5X_N0";
      y[8] = "+h3\u0018\u000596}k:D4.{";
      y[9] = "Q\u0017<]J,G\u00179\u0007Y;P\\:\u0001U/A\u001b-\u0016\u001e;L";
      y[10] = "\u000eI\n}WD\u0005F\u001b2*\\\u0016A\u0012{";
      y[11] = float.class;
      z[11] = "java/lang/Float";
      y[12] = "\t\u0010\tc+c\u001f\u0010\f98t\b[\u000f?4`\u0019\u001c\u0018(\u007fpU";
      y[13] = "8R?j]YMr4eL\u0016,|?nHLX";
      y[14] = "\u0002*LIg\u000e\u0014*I\u0013t\u0019\u0003aJ\u0015x\r\u0012&]\u00023\u0018+";
      y[15] = "PZ[*o\u0012FZ^p|\u0005Q\u0011]vp\u0011@VJa;\u0001\u0000";
      y[16] = "(D\u001e><u]d\u00151-:<j\u001e:)`H";
      y[17] = "\u001dC\u0010P]B\u000bC\u0015\nNU\u001c\b\u0016\fBA\rO\u0001\u001b\tQ&";
      y[18] = "\rB%F\u0017\u000fxb.I\u0006@\u0019l%B\u0002\u001am";
      y[19] = void.class;
      z[19] = "java/lang/Void";
      y[20] = "gp\u000b(V\tqp\u000erE\u001ef;\rtI\nw|\u001ac\u0002\u001d`";
      y[21] = "\u00147\nK\u001a:\u001f8\u001b\u0004y7\n5\u0014oL5\u001b&\bC[8";
      y[22] = "f\t#DT,c\u001c(DW+l\u0015#\u0006\u0016\u001cEJu";
      y[23] = "y\u001086&,|\u000536%+s\f8td\u001cZSl";
      y[24] = ",0\u0007d\n\u0004Y\u0010\fk\u001bK8\u001e\u0007`\u001f\u0011L";
      y[25] = "\u0014O\u001eM\u0004.ao\u0015B\u0015a\u0000a\u001eI\u0011;t";
      y[26] = "*\u0005=\n\u0013P<\u00058P\u0000G+N;V\fS:\t,AGF\u001e";
      y[27] = "B\f\\\u001a\u001aP7,W\u0015\u000b\u001fV\"\\\u001e\u000fE\"";
      y[28] = "[\u000fldyUM\u000fi>jBZDj8fVK\u0003}/-B{";
      y[29] = "g`h\u0018\u0017v\u0012@c\u0017\u00069sNh\u001c\u0002c\u0007";
      y[30] = "\n\rg\u00050W\u001c\rb_#@\u000bFaY/T\u001a\u0001vNd@(";
      y[31] = "|FUl<%\tf^c-jhhUh)0\u001c";
      y[32] = "@nBT2j5NI[#%T@BP'\u007f ";
      y[33] = "NW (7 XW%r$7O\u001c&t(#^[1cc7`";
      y[34] = "\b\u000e\u001a P\u0000}.\u0011/AO\u001c \u001a$E\u0015h";
      y[35] = "-+eW|g;+`\rop,`c\u000bcd='t\u001c(p\u0000";
      y[36] = "\u001dzB%GuhZI*V:\tTB!R`}";
      y[37] = "8A\t_dK.A\f\u0005w\\9\n\u000f\u0003{H(M\u0018\u00140\\\u0014";
      y[38] = "\u0000O.g.IXM9\"W\u001aa\tr +\u0014\u0003\u001b8!fs\u0003\r0z.\u0002\u001a\u001apwW";
      y[39] = "H\\\u0013\u0010y\u001b\f\u0004B\u0017\u0016L\u001b\u001e6OnC\u001fb\u000e[q\u001a\u001c\u000b\u0014Ox#";
      y[40] = "\u001c\u001fu\u0014zdXG$\u0013\u0015\u0003b`Eb\u0015b\u001cM\"@-&D\u001c%";
      y[41] = "~\u0018}M\"QqLgK\u001eQ@\u0016mEaW>Hr\u0015z8p\u0018}Nu\u00030C0B\u001e\bqT`E%H*\u0019l..\t=Ik\u0015nRpE\u0000\u001e/E B;^t\b,)>\u001fc[|@1Ky]@";
      y[42] = "\f\u001d{W&\u001c\r\u001a-\u0002^I7\u0001&U\"GU\u0013lTo \nIl\u0005#OW\u001csT^";
      y[43] = "\u001a3\u0014U7%B1\u0003\u0010Nv{uH\u00122x\u0019g\u0002\u0013\u007f\u001f\u001a3\u0014U7%B1\u0003\u0010N";
      y[44] = "&K\u0011l0O~I\u0006)I\u001cG\rM+5\u0012%\u001f\u0007*xu D\u0006tsE{O\u001eqI";
      y[45] = "P\u0019\f\u0004\u0007`_M\u0016\u0002;`n\u0017\u001c\fDf\u0010I\u0003\\_\t^\u0019\f\u0007P2\u001eBA\u000b;9_U\u0011\f\u0000y\u0004\u0018\u001dg\u00058\u0013KM\u000e\nl\tMq";
      y[46] = "n`e.gIx'dr\tY\u0007 nruWe2$s80v(3pcYl<:I";
      y[47] = "\u0004k$>\u001a\"\\i3{cqe-xy\u001f\u007f\u0007?2xR\u0018\u001cdz|\u000ef\u0000e&zc";
      y[48] = "t12\u0005\u001d`0ic\u0002r7's\u0004S\u001eX;\u007f9\u0007\u00181!k0>";
      y[49] = "P\u0000)Iws\u0011\u0013-.cd\b\u00038is\r\u001d\u000e2\u0017wd\u0007\u001a;.!s\u0010\u0019?P``\u0014~";
      y[50] = "aqM=\u0006qtxJ58f\ng\u000faDlhuE`\t\u000bff\t&\u0000kpqK!8";
      y[51] = " \u0002zE#q \u0012)UJy~\u0007=G6\u007fX\f\fP1\u007f\u007f\u001eE\u0000'rd[tQ!)vb~\u0005*+}\u000byB5m\u0019X(Z7+(\t.\u0001%\u0012";
      y[52] = "8|G\tQS|$\u0016\u000e>\u0004k>aVC\u0006\u00063[U\u0007\u0001o)O\\>";
      y[53] = "=CBo:\u0004,\u0011K6\u0003\u0016P@\fbi\u0003!A\u0015l9\u007f=R\u001fd\u007f\u000e<K\u00114\u0003";
      y[54] = "cG<N\u0012[c_-\t(USEhLT[1W\"M\u0019<:\u0005c\u0010FE,BbL(";
      y[55] = "_\u00072\u0001'\fPS(\u0007\u001b\faG?\u0005\"\u000f\b]+\f\u001b[PK,^rT\u0004Q*b";
      y[56] = " #z_x+x!m\u001a\u0001{Ae&\u0018}v#wl\u00190\u0011%q Gav+\u007fg\u001d\u0001";
      y[57] = "Yp\u007fTt)E1=[\t&SEb]e\u0015Z\u007f\u007fFs$7~s\\0#^dgU\t8Gh:Q`\"Sa\u0003WpuK7cAg7L\u000f";
      y[58] = "._`H\u001eI/\u000en\u000fc\u0018%(fK\u0002\t,=`G\u001f\n;\f\rF\u0013\u0010x\u000bd\\\u0007\u0019A\rt\u000b\u001fO!\u001bcI\u0018w";
      y[59] = "oX9+F;7Z.n?h\u000e\u001eelCfl\f/m\u000e\u0001h^/h^z0\u0019;<?";
      y[60] = "Thj'(IB5z8N^=},c2S_ofb\u007f4Thj'(IB5z8N";
      y[61] = "-KX\u007f\u0010fi\u0013\tx\u007f1~\t{>\u00123uuE4\u0018gy\u001c_ \u0011^";
      y[62] = "[\u0015L>xUMRMb\u0016E2UGbjKPG\rc',^TA%.LHC\u0003\"\u0016";
   }

   private static Class j(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var6 = y[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(z[var4]);
            y[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field e(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field f(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = e(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = f(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field k(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = j(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = e(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            y[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = f(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  y[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = j(244013022459196L, 0L);
         }
      }
   }

   private static Method e(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method f(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = e(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = f(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method l(long var0, long var2) {
      int var4 = i(var0, var2);
      Object var5 = y[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = z[var4];
      int var7 = var6.indexOf(8);
      Class var8 = j(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = e(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  y[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  j(244013022459196L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = f(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        y[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = j(244013022459196L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = j(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 227;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 193;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 88;
               char var27 = var8;
               if (var27 != var28) {
                  short var30 = 250;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = l(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 196;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 236;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = k(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 227;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 193;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 88;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object c(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = c(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite d(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/dc_C0170",
                        "c",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/dc" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1(SolidColorEffect var0, int var1) {
         MethodHandle var6 = bindingCache1;
         MethodHandle var5 = bindingCache1;
         MethodHandle var3 = var5;
         if (var6 == null) {
            var3 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dc_C0170;I)Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/dc_C0170",
                     "lambda$createBuffer$1",
                     "(ILjava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;"
                  ),
                  SourceSupport.methodType("(Ljava/lang/Integer;)Ldev/zprestige/prestige/dn_C0192;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var3.invokeExact((SolidColorEffect)var0, (int)var1);
      } catch (Throwable var7) {
         throw SourceSupport.rethrow(var7);
      }
   }

   private static Consumer invokeBinding2(SolidColorEffect var0) {
         MethodHandle var5 = bindingCache2;
         MethodHandle var4 = bindingCache2;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache2 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dc_C0170;)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 5, "dev/zprestige/prestige/dc_C0170", "lambda$getPipeline$2", "(Ldev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Consumer)var2.invokeExact((SolidColorEffect)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static IntSupplier invokeBinding3() {
         MethodHandle var4 = bindingCache3;
         MethodHandle var3 = bindingCache3;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache3 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "getAsInt",
                  SourceSupport.methodType("()Ljava/util/function/IntSupplier;", MethodHandles.lookup()),
                  SourceSupport.methodType("()I", MethodHandles.lookup()),
                  SourceSupport.handle(MethodHandles.lookup(), 6, "dev/zprestige/prestige/dj_C0184", "a", "()I"),
                  SourceSupport.methodType("()I", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (IntSupplier)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static Consumer invokeBinding4(int var0) {
         MethodHandle var5 = bindingCache4;
         MethodHandle var4 = bindingCache4;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "accept",
                  SourceSupport.methodType("(I)Ljava/util/function/Consumer;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)V", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/dc_C0170", "lambda$createBuffer$0", "(ILdev/zprestige/prestige/dt_C0202;)V"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/dt_C0202;)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Consumer)var2.invokeExact((int)var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }
}
