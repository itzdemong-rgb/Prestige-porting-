package dev.zprestige.prestige.renderlib.font;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.prestige.recovery.SourceSupport;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class FontMetrics {
   private int a;
   private float b;
   private float c;
   private float d;
   private float e;
   private float f;
   private static final long g = 60437553460800L;
   private static final String[] h;
   private static final String[] i;
   private static final Map j = new HashMap(13);
   private static final Object[] k = new Object[9];
   private static final String[] l = new String[9];

   public FontMetrics() {
   }

   public FontMetrics(int var1, float var2, float var3, float var4, float var5, float var6) {
      this.a = var1;
      this.b = var2;
      this.c = var3;
      this.d = var4;
      this.e = var5;
      this.f = var6;
   }

   public static FontMetrics aReturningcA_C0111(Object[] var0) {
      JsonObject var3 = (JsonObject)var0[0];
      long var1 = (Long)var0[1];
      var1 = 60437553460800L ^ var1;
      FontMetrics var4 = new FontMetrics();
      short var10002 = 19632;
      long var10003 = 1260177848874577760L ^ var1;
      String var6 = "emSize";
      JsonObject var5 = var3;
      JsonElement var7 = var5.get(var6);
      var4.a = var7.getAsInt();
      var10002 = 25230;
      var10003 = 7585694971478147417L ^ var1;
      String var9 = "lineHeight";
      JsonObject var8 = var3;
      JsonElement var10 = var8.get(var9);
      var4.b = var10.getAsFloat();
      var10002 = 2358;
      var10003 = 7048947256305281767L ^ var1;
      String var12 = "ascender";
      JsonObject var11 = var3;
      JsonElement var13 = var11.get(var12);
      var4.c = var13.getAsFloat();
      var10002 = 1649;
      var10003 = 8819020796088772004L ^ var1;
      String var15 = "descender";
      JsonObject var14 = var3;
      JsonElement var16 = var14.get(var15);
      var4.d = var16.getAsFloat();
      var10002 = 13366;
      var10003 = 8441251869059274722L ^ var1;
      String var18 = "underlineY";
      JsonObject var17 = var3;
      JsonElement var19 = var17.get(var18);
      var4.e = var19.getAsFloat();
      var10002 = 22969;
      var10003 = 2879690638233582191L ^ var1;
      String var21 = "underlineThickness";
      JsonObject var20 = var3;
      JsonElement var22 = var20.get(var21);
      var4.f = var22.getAsFloat();
      return var4;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   public float aReturningFloat(Object[] var1) {
      return this.b;
   }

   public float bReturningFloat(Object[] var1) {
      return this.c;
   }

   public float cReturningFloat(Object[] var1) {
      return this.d;
   }

   public float dReturningFloat(Object[] var1) {
      return this.e;
   }

   public float eReturningFloat(Object[] var1) {
      return this.f;
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(3774470967056L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[6];
      String var6 = "ÒÖ\u0093´\u00ad\u009f1\u0086\u000f\u0095ï>¶ç\u009di\u0001J%\u0091\u001a\u0087|\u0082þ\u008aF\r%À?ý\u0018>UÎÂT\u000eû\u009a\u008fgÇÙ¢^éÀ_ÂvtüÐ\u0017\u0015 hªá\u0017zÁ\u0011ö¾lp«\u0000+uïåÃdÊ\u0000oê~\u00975r]\u0014ðÜÝ(\u009aJ\u008d×F\u0010ûÄ\u0086\u001dùÑÙ\u0000\u0083\u0082\u0095\u0099kÓ-\u0017±úÿæ2nä2ã¤æ2/_\u0012»t%";
      int var8 = "ÒÖ\u0093´\u00ad\u009f1\u0086\u000f\u0095ï>¶ç\u009di\u0001J%\u0091\u001a\u0087|\u0082þ\u008aF\r%À?ý\u0018>UÎÂT\u000eû\u009a\u008fgÇÙ¢^éÀ_ÂvtüÐ\u0017\u0015 hªá\u0017zÁ\u0011ö¾lp«\u0000+uïåÃdÊ\u0000oê~\u00975r]\u0014ðÜÝ(\u009aJ\u008d×F\u0010ûÄ\u0086\u001dùÑÙ\u0000\u0083\u0082\u0095\u0099kÓ-\u0017±úÿæ2nä2ã¤æ2/_\u0012»t%"
         .length();
      char var5 = ' ';
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = a(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     h = var9;
                     i = new String[6];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "»q¹\u00164Êó\u0086¹&\u0089F\u000bÅÕ)ày'et¯v(\u0004:]3\u0092\u009eüÞ\u0010\u009an~Å\u0089Y\u0010ó§P®l'N\u0082Ê";
                  var8 = "»q¹\u00164Êó\u0086¹&\u0089F\u000bÅÕ)ày'et¯v(\u0004:]3\u0092\u009eüÞ\u0010\u009an~Å\u0089Y\u0010ó§P®l'N\u0082Ê".length();
                  var5 = ' ';
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 16085;
      if (i[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])j.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               j.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cA", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = h[var5].getBytes("ISO-8859-1");
         i[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return i[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cA_C0111",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cA" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = l[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = k[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 46;
            yield var15;
         }
         case 1 -> {
            byte var16 = 3;
            yield var16;
         }
         case 2 -> {
            byte var17 = 60;
            yield var17;
         }
         case 3 -> {
            byte var18 = 6;
            yield var18;
         }
         case 4 -> {
            byte var19 = 37;
            yield var19;
         }
         case 5 -> {
            byte var20 = 40;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 10;
            yield var22;
         }
         case 8 -> {
            byte var23 = 50;
            yield var23;
         }
         case 9 -> {
            byte var24 = 25;
            yield var24;
         }
         case 10 -> {
            byte var25 = 15;
            yield var25;
         }
         case 11 -> {
            byte var26 = 11;
            yield var26;
         }
         case 12 -> {
            byte var27 = 16;
            yield var27;
         }
         case 13 -> {
            byte var28 = 27;
            yield var28;
         }
         case 14 -> {
            byte var29 = 62;
            yield var29;
         }
         case 15 -> {
            byte var30 = 53;
            yield var30;
         }
         case 16 -> {
            byte var31 = 17;
            yield var31;
         }
         case 17 -> {
            byte var32 = 20;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 57;
            yield var34;
         }
         case 20 -> {
            byte var35 = 9;
            yield var35;
         }
         case 21 -> {
            byte var36 = 4;
            yield var36;
         }
         case 22 -> {
            byte var37 = 38;
            yield var37;
         }
         case 23 -> {
            byte var38 = 51;
            yield var38;
         }
         case 24 -> {
            byte var39 = 56;
            yield var39;
         }
         case 25 -> {
            byte var40 = 43;
            yield var40;
         }
         case 26 -> {
            byte var41 = 36;
            yield var41;
         }
         case 27 -> {
            byte var42 = 55;
            yield var42;
         }
         case 28 -> {
            byte var43 = 45;
            yield var43;
         }
         case 29 -> {
            byte var44 = 19;
            yield var44;
         }
         case 30 -> {
            byte var45 = 12;
            yield var45;
         }
         case 31 -> {
            byte var46 = 47;
            yield var46;
         }
         case 32 -> {
            byte var47 = 0;
            yield var47;
         }
         case 33 -> {
            byte var48 = 61;
            yield var48;
         }
         case 34 -> {
            byte var49 = 31;
            yield var49;
         }
         case 35 -> {
            byte var50 = 18;
            yield var50;
         }
         case 36 -> {
            byte var51 = 14;
            yield var51;
         }
         case 37 -> {
            byte var52 = 48;
            yield var52;
         }
         case 38 -> {
            byte var53 = 29;
            yield var53;
         }
         case 39 -> {
            byte var54 = 39;
            yield var54;
         }
         case 40 -> {
            byte var55 = 63;
            yield var55;
         }
         case 41 -> {
            byte var56 = 34;
            yield var56;
         }
         case 42 -> {
            byte var57 = 22;
            yield var57;
         }
         case 43 -> {
            byte var58 = 2;
            yield var58;
         }
         case 44 -> {
            byte var59 = 1;
            yield var59;
         }
         case 45 -> {
            byte var60 = 5;
            yield var60;
         }
         case 46 -> {
            byte var61 = 7;
            yield var61;
         }
         case 47 -> {
            byte var62 = 58;
            yield var62;
         }
         case 48 -> {
            byte var63 = 35;
            yield var63;
         }
         case 49 -> {
            byte var64 = 42;
            yield var64;
         }
         case 50 -> {
            byte var65 = 41;
            yield var65;
         }
         case 51 -> {
            byte var66 = 24;
            yield var66;
         }
         case 52 -> {
            byte var67 = 23;
            yield var67;
         }
         case 53 -> {
            byte var68 = 30;
            yield var68;
         }
         case 54 -> {
            byte var69 = 28;
            yield var69;
         }
         case 55 -> {
            byte var70 = 54;
            yield var70;
         }
         case 56 -> {
            byte var71 = 59;
            yield var71;
         }
         case 57 -> {
            byte var72 = 44;
            yield var72;
         }
         case 58 -> {
            byte var73 = 49;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 52;
            yield var75;
         }
         case 61 -> {
            byte var76 = 26;
            yield var76;
         }
         case 62 -> {
            byte var77 = 21;
            yield var77;
         }
         default -> 8;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            l[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      k[0] = "Zbo=\u0007(VjnvN Jbl=*4VcMq\n\"Zy";
      k[1] = "l|#H\u0002\u0003gs2\u0007\u007f\u001btt;N";
      k[2] = ";\u0006H(OS7\u000eIc\u0006[+\u0006K(bO7\u0007`jMQ=\u0007Q";
      k[3] = int.class;
      l[3] = "java/lang/Integer";
      k[4] = float.class;
      l[4] = "java/lang/Float";
      k[5] = "ER!\u0003XqN]0L9\u007fEV4\u0016";
      k[6] = "\u0003\b$8=_T\u001e,%M@W\u0019\u001c=\fIFeox,\u0014\\\u0017((\"T:";
      k[7] = ":\u000f\u0013,ugm\u0019\u001b1\u0005xn\u001e+)Ksd\u000b\u001eR?i}\u001f\u001f4gpn\u0001b";
      k[8] = "i\tx9\u0014&h\t<@\u001bw)kx)\f\"e\nq&\u001b\u001al\u0006r>\u0004j;\u0010z#t";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = k[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(l[var4]);
            k[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            k[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  k[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(421070553502412L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = k[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = l[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  k[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(421070553502412L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        k[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(421070553502412L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 255;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 213;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 110;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 79;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 66;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 240;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 255;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 213;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 110;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cA_C0111",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cA" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
