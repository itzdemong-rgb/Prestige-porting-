package dev.zprestige.prestige.renderlib.font;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;

public class GlyphMetrics {
   private int a;
   private float b;
   private float c;
   private float d;
   private float e;
   private float f;
   private float g;
   private float h;
   private float i;
   private float j;
   private static final long k = 21033704538608L;
   private static final String[] l;
   private static final String[] m;
   private static final Map n = new HashMap(13);
   private static final Object[] o = new Object[17];
   private static final String[] p = new String[17];

   public static GlyphMetrics aReturningcB_C0113(Object[] var0) {
      GlyphMetrics var5;
      JsonObject var54;
      String var55;
      long var66;
      label26: {
         JsonObject var3 = (JsonObject)var0[0];
         long var1 = (Long)var0[1];
         var66 = 21033704538608L ^ var1;
         int var10000 = Event.bReturningInt();
         var5 = new GlyphMetrics();
         int var4 = var10000;
         short var10002 = 14686;
         long var10003 = 858954603123251830L ^ var66;
         String var8 = "unicode";
         JsonObject var7 = var3;
         JsonElement var9 = var7.get(var8);
         var5.a = var9.getAsInt();
         var10002 = 3664;
         var10003 = 4448353740382317941L ^ var66;
         String var11 = "advance";
         JsonObject var10 = var3;
         JsonElement var12 = var10.get(var11);
         var5.b = var12.getAsFloat();
         short var10001 = 6945;
         long var73 = 3432305842906937345L ^ var66;
         String var14 = "planeBounds";
         JsonObject var13 = var3;
         boolean var68 = var13.has(var14);
         int var57 = var4;
         boolean var56 = var68;
         boolean var53 = var56;
         boolean var50 = var56;
         if (var57 == 0) {
            boolean var58 = var50;
            if (var58) {
               var10001 = 32249;
               long var74 = 7471803663479824083L ^ var66;
               String var17 = "planeBounds";
               JsonObject var16 = var3;
               JsonElement var18 = var16.get(var17);
               JsonObject var6 = var18.getAsJsonObject();
               var10002 = 23385;
               var10003 = 1132280379476637812L ^ var66;
               String var20 = "left";
               JsonObject var19 = var6;
               JsonElement var21 = var19.get(var20);
               var5.c = var21.getAsFloat();
               var10002 = 20526;
               var10003 = 6637202307840996097L ^ var66;
               String var23 = "bottom";
               JsonObject var22 = var6;
               JsonElement var24 = var22.get(var23);
               var5.d = var24.getAsFloat();
               var10002 = 17047;
               var10003 = 3933702107872158132L ^ var66;
               String var26 = "right";
               JsonObject var25 = var6;
               JsonElement var27 = var25.get(var26);
               var5.e = var27.getAsFloat();
               var10002 = 30571;
               var10003 = 5169170016841258050L ^ var66;
               String var29 = "top";
               JsonObject var28 = var6;
               JsonElement var30 = var28.get(var29);
               var5.f = var30.getAsFloat();
            }

            var10001 = 27728;
            long var79 = 3060807490490945406L ^ var66;
            int var61 = var4;
            String var60 = "atlasBounds";
            JsonObject var59 = var3;
            var54 = var59;
            var55 = var60;
            JsonObject var51 = var59;
            String var52 = var60;
            if (var61 != 0) {
               break label26;
            }

            String var32 = var52;
            JsonObject var31 = var51;
            boolean var62 = var31.has(var32);
            var53 = var62;
         }

         boolean var63 = var53;
         if (!var63) {
            return var5;
         }

         var10001 = 29634;
         long var80 = 8418477746147512550L ^ var66;
         String var65 = "atlasBounds";
         JsonObject var64 = var3;
         var54 = var64;
         var55 = var65;
      }

      String var36 = var55;
      JsonObject var35 = var54;
      JsonElement var37 = var35.get(var36);
      JsonObject var67 = var37.getAsJsonObject();
      short var81 = 5176;
      long var90 = 7690813595881125657L ^ var66;
      String var39 = "left";
      JsonObject var38 = var67;
      JsonElement var40 = var38.get(var39);
      var5.g = var40.getAsFloat();
      var81 = 30191;
      var90 = 9115144419766884035L ^ var66;
      String var42 = "bottom";
      JsonObject var41 = var67;
      JsonElement var43 = var41.get(var42);
      var5.h = var43.getAsFloat();
      var81 = 16007;
      var90 = 7156048939530427820L ^ var66;
      String var45 = "right";
      JsonObject var44 = var67;
      JsonElement var46 = var44.get(var45);
      var5.i = var46.getAsFloat();
      var81 = 4200;
      var90 = 7747177423909794634L ^ var66;
      String var48 = "top";
      JsonObject var47 = var67;
      JsonElement var49 = var47.get(var48);
      var5.j = var49.getAsFloat();
      return var5;
   }

   public int aReturningInt(Object[] var1) {
      return this.a;
   }

   public float aReturningFloat(Object[] var1) {
      return this.b;
   }

   public float bReturningFloat(Object[] var1) {
      return this.c;
   }

   public float cReturningFloat(Object[] var1) {
      return this.d;
   }

   public float dReturningFloat(Object[] var1) {
      return this.e;
   }

   public float eReturningFloat(Object[] var1) {
      return this.f;
   }

   public float fReturningFloat(Object[] var1) {
      return this.g;
   }

   public float gReturningFloat(Object[] var1) {
      return this.h;
   }

   public float hReturningFloat(Object[] var1) {
      return this.i;
   }

   public float iReturningFloat(Object[] var1) {
      return this.j;
   }

   static {

      {

      aReturningVoid();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(4996173981445L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var9 = new String[14];
      String var6 = "\u0097ñÐÇÙïÚêµ\u0001!\u0094È«Ìó\u0010F\"\u00adò\u0081 %¶\u0085t\u009d¿M\u0014\u0098\u0087 8\u00969Ü·Ô[¼Ú\u009e©Gÿ Ô´\u0094¡ÆµêVþB\u008dÏ\u0088ü>+\u0089í\u0010W\u0085%hª\u008dB\u008cÁo\u0088§ÒxÕP\u0010J=ù\u0099¸Dû¢ÚÚ&¶Ýd\\\u001d\u0010B\u000eÉíÌl\u0090+\u009eÏÔC\n6Lò\u0018mêÃ\u008f4»ô\u0005}BÕs\u0094j¯\u000e\u001e\b(¼¯¶¾)\u0010¾ÌuôS;VÌTÙ\u0000\u000f\u001f2Fð Þ\u0094ö\t\u0082\u00ad\u0093R\u0017\u0083Ny³UD%Õosö\u007f¼\u0098'NäéyÚºKK\u0010t_à¿@\u009c÷¤Ô\u008bà¡\u000fÆa`\u0010îú·\u0092\u0002N5òH\u008d\u0080ô]¬6ì\u0010ý¡¨\u0007\u0012\u0094\u0086Ï×b²`ûã\u001f ";
      int var8 = "\u0097ñÐÇÙïÚêµ\u0001!\u0094È«Ìó\u0010F\"\u00adò\u0081 %¶\u0085t\u009d¿M\u0014\u0098\u0087 8\u00969Ü·Ô[¼Ú\u009e©Gÿ Ô´\u0094¡ÆµêVþB\u008dÏ\u0088ü>+\u0089í\u0010W\u0085%hª\u008dB\u008cÁo\u0088§ÒxÕP\u0010J=ù\u0099¸Dû¢ÚÚ&¶Ýd\\\u001d\u0010B\u000eÉíÌl\u0090+\u009eÏÔC\n6Lò\u0018mêÃ\u008f4»ô\u0005}BÕs\u0094j¯\u000e\u001e\b(¼¯¶¾)\u0010¾ÌuôS;VÌTÙ\u0000\u000f\u001f2Fð Þ\u0094ö\t\u0082\u00ad\u0093R\u0017\u0083Ny³UD%Õosö\u007f¼\u0098'NäéyÚºKK\u0010t_à¿@\u009c÷¤Ô\u008bà¡\u000fÆa`\u0010îú·\u0092\u0002N5òH\u008d\u0080ô]¬6ì\u0010ý¡¨\u0007\u0012\u0094\u0086Ï×b²`ûã\u001f "
         .length();
      char var5 = 16;
      int var12 = -1;

      label27:
      while (true) {
         String var13 = var6.substring(++var12, var12 + var5);
         
            byte[] var10 = var2.doFinal(var13.getBytes("ISO-8859-1"));
            String var19 = a(var10).intern();
            switch (var10001) {
               case 0:
                  var9[var7++] = var19;
                  if ((var12 += var5) >= var8) {
                     l = var9;
                     m = new String[14];
                     break;
                  }

                  var5 = var6.charAt(var12);
                  break;
               default:
                  var9[var7++] = var19;
                  if ((var12 += var5) < var8) {
                     var5 = var6.charAt(var12);
                     continue label27;
                  }

                  var6 = "]pM§´îÉÀõc\u0012£BöÛJÆ\u0017}÷Ï\u0090Q\u008f\u0010\u0013\u0017\u0013ÝÜ\u0018Ð\u0095ABhW3¤¶\u0018";
                  var8 = "]pM§´îÉÀõc\u0012£BöÛJÆ\u0017}÷Ï\u0090Q\u008f\u0010\u0013\u0017\u0013ÝÜ\u0018Ð\u0095ABhW3¤¶\u0018".length();
                  var5 = 24;
                  var12 = -1;
            }

            var13 = var6.substring(++var12, var12 + var5);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 21490;
      if (m[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])n.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               n.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cB", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = l[var5].getBytes("ISO-8859-1");
         m[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return m[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cB_C0113",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = p[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = o[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 1;
            yield var15;
         }
         case 1 -> {
            byte var16 = 7;
            yield var16;
         }
         case 2 -> {
            byte var17 = 15;
            yield var17;
         }
         case 3 -> {
            byte var18 = 63;
            yield var18;
         }
         case 4 -> {
            byte var19 = 23;
            yield var19;
         }
         case 5 -> {
            byte var20 = 8;
            yield var20;
         }
         case 6 -> {
            byte var21 = 45;
            yield var21;
         }
         case 7 -> {
            byte var22 = 25;
            yield var22;
         }
         case 8 -> {
            byte var23 = 61;
            yield var23;
         }
         case 9 -> {
            byte var24 = 38;
            yield var24;
         }
         case 10 -> {
            byte var25 = 16;
            yield var25;
         }
         case 11 -> {
            byte var26 = 56;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 37;
            yield var28;
         }
         case 14 -> {
            byte var29 = 27;
            yield var29;
         }
         case 15 -> {
            byte var30 = 59;
            yield var30;
         }
         case 16 -> {
            byte var31 = 35;
            yield var31;
         }
         case 17 -> {
            byte var32 = 52;
            yield var32;
         }
         case 18 -> {
            byte var33 = 13;
            yield var33;
         }
         case 19 -> {
            byte var34 = 28;
            yield var34;
         }
         case 20 -> {
            byte var35 = 6;
            yield var35;
         }
         case 21 -> {
            byte var36 = 10;
            yield var36;
         }
         case 22 -> {
            byte var37 = 49;
            yield var37;
         }
         case 23 -> {
            byte var38 = 9;
            yield var38;
         }
         case 24 -> {
            byte var39 = 5;
            yield var39;
         }
         case 25 -> {
            byte var40 = 22;
            yield var40;
         }
         case 26 -> {
            byte var41 = 54;
            yield var41;
         }
         case 27 -> {
            byte var42 = 43;
            yield var42;
         }
         case 28 -> {
            byte var43 = 18;
            yield var43;
         }
         case 29 -> {
            byte var44 = 12;
            yield var44;
         }
         case 30 -> {
            byte var45 = 62;
            yield var45;
         }
         case 31 -> {
            byte var46 = 3;
            yield var46;
         }
         case 32 -> {
            byte var47 = 2;
            yield var47;
         }
         case 33 -> {
            byte var48 = 20;
            yield var48;
         }
         case 34 -> {
            byte var49 = 46;
            yield var49;
         }
         case 35 -> {
            byte var50 = 14;
            yield var50;
         }
         case 36 -> {
            byte var51 = 57;
            yield var51;
         }
         case 37 -> {
            byte var52 = 21;
            yield var52;
         }
         case 38 -> {
            byte var53 = 47;
            yield var53;
         }
         case 39 -> {
            byte var54 = 51;
            yield var54;
         }
         case 40 -> {
            byte var55 = 41;
            yield var55;
         }
         case 41 -> {
            byte var56 = 31;
            yield var56;
         }
         case 42 -> {
            byte var57 = 24;
            yield var57;
         }
         case 43 -> {
            byte var58 = 11;
            yield var58;
         }
         case 44 -> {
            byte var59 = 50;
            yield var59;
         }
         case 45 -> {
            byte var60 = 17;
            yield var60;
         }
         case 46 -> {
            byte var61 = 60;
            yield var61;
         }
         case 47 -> {
            byte var62 = 55;
            yield var62;
         }
         case 48 -> {
            byte var63 = 32;
            yield var63;
         }
         case 49 -> {
            byte var64 = 44;
            yield var64;
         }
         case 50 -> {
            byte var65 = 26;
            yield var65;
         }
         case 51 -> {
            byte var66 = 33;
            yield var66;
         }
         case 52 -> {
            byte var67 = 53;
            yield var67;
         }
         case 53 -> {
            byte var68 = 48;
            yield var68;
         }
         case 54 -> {
            byte var69 = 0;
            yield var69;
         }
         case 55 -> {
            byte var70 = 29;
            yield var70;
         }
         case 56 -> {
            byte var71 = 4;
            yield var71;
         }
         case 57 -> {
            byte var72 = 36;
            yield var72;
         }
         case 58 -> {
            byte var73 = 19;
            yield var73;
         }
         case 59 -> {
            byte var74 = 30;
            yield var74;
         }
         case 60 -> {
            byte var75 = 34;
            yield var75;
         }
         case 61 -> {
            byte var76 = 58;
            yield var76;
         }
         case 62 -> {
            byte var77 = 39;
            yield var77;
         }
         default -> 42;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            p[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void aReturningVoid() {
      o[0] = "\u0016VY\u000f\n\u000b\u0000V\\U\u0019\u001c\u0017\u001d_S\u0015\b\u0006ZHD^\u001a7";
      o[1] = int.class;
      p[1] = "java/lang/Integer";
      o[2] = "\u0000g\u0017l]\u0005\u0016g\u00126N\u0012\u0001,\u00110B\u0006\u0010k\u0006'\t\u0016&";
      o[3] = "sbQjV\u0001xm@%5\fm`ON\u0000\u000e|sSb\u0017\u0003";
      o[4] = ")U\u001b&^+%]\u001am\u0017#9U\u0018&s7%T9jS!)N";
      o[5] = "foI@\u00143m`X\u000fi+~gQF";
      o[6] = "\u0010\"Ae>\u0010\u001c*@.w\u0018\u0000\"Be\u0013\f\u001c#i'<\u0012\u0016#X";
      o[7] = boolean.class;
      p[7] = "java/lang/Boolean";
      o[8] = float.class;
      p[8] = "java/lang/Float";
      o[9] = ";ey\u0013?m0jh\\^c;al\u0006";
      o[10] = "/dxBlv$bq\u0001V-|d\u001f\fo$/}.Qk2o\u001f\"\u00013)+{x\b0.\u0015";
      o[11] = "A)K'15E0\u0012U \u000fF.C'2a\u0002:Q)J";
      o[12] = "\u000f\u0019Zs@\u007fW\u0012U2-/^\u000b}wl&Ow\r`B2K\u0019ItP<3";
      o[13] = "\f\u0016=<a\u007fT\u001d2}\f/]\u0004\u001a8B$W\u0011/C10Z\u0011(&m~_\u0017S";
      o[14] = "\\M\u0002\u0011%f\u0004F\rPH6\r_%\u0015\n\"\u0007E+\u0004*4\u000b_lT3>\u0012\u0019W_57Q#";
      o[15] = "q\u0002\u000eM= $\f\u001f[A'HJ\u0007S9)5\tUJ9Nr\u001a\fJ&31H\u0015JA";
      o[16] = "wF5h]c|@<+g7 AR&^1w_c{Z'7=nt\t' \u00026\u007f\u0006fM";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = o[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(p[var4]);
            o[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = o[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            o[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  o[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(653902911245191L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = o[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = p[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  o[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(653902911245191L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        o[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(653902911245191L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         byte var24 = 116;
         char var23 = var8;
         if (var23 != var24) {
            byte var26 = 89;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 233;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 82;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 77;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 36;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         byte var32 = 116;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            byte var34 = 89;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 233;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cB_C0113",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cB" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
