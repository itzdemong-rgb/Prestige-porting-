package dev.zprestige.prestige.renderlib.font;

@FunctionalInterface
public interface GlyphVisitor {
   boolean a(int var1, GlyphMetrics var2);
}
