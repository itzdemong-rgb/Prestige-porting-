package dev.zprestige.prestige.renderlib.font;
import dev.zprestige.prestige.api.util.NumberUtil;
import dev.zprestige.prestige.renderlib.DrawPipeline;
import dev.zprestige.prestige.renderlib.ManagedGlTexture;
import dev.zprestige.prestige.renderlib.QuadRenderCommand;
import dev.zprestige.prestige.renderlib.RenderBatchKey;
import dev.zprestige.prestige.renderlib.RenderCommandBatcher;
import dev.zprestige.prestige.renderlib.RenderState;
import dev.zprestige.prestige.renderlib.ResourceName;
import dev.zprestige.prestige.renderlib.ShaderPrograms;
import dev.zprestige.prestige.renderlib.ShapeRenderer;
import dev.zprestige.prestige.renderlib.VertexFormat;
import dev.zprestige.prestige.renderlib.VertexFormats;
import dev.zprestige.prestige.renderlib.state.BlurTextureState;
import dev.zprestige.prestige.renderlib.state.CapabilityState;


import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.invoke.CallSite;
import java.lang.invoke.LambdaMetafactory;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.BiConsumer;
import java.util.function.Function;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import net.minecraft.client.texture.NativeImage;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;

public class MsdfFont {
   private static final int[][] a;
   private float b;
   private int c;
   private int d;
   private float e;
   private float f;
   private float g;
   private final Int2ObjectOpenHashMap h;
   private final Map i;
   private FontMetrics j;
   private ManagedGlTexture k;
   private BiConsumer l;
   private Function m;
   private DrawPipeline n;
   private RenderBatchKey o;
   private static final long p = 118462210935962L;
   private static final String[] q;
   private static final String[] r;
   private static final Map s = new HashMap(13);
   private static final long[] t;
   private static final Integer[] u;
   private static final Map v;
   private static final Object[] w = new Object[171];
   private static final String[] x = new String[171];
   private static volatile MethodHandle bindingCache1;
   private static volatile MethodHandle bindingCache2;
   private static volatile MethodHandle bindingCache3;
   private static volatile MethodHandle bindingCache4;
   private static volatile MethodHandle bindingCache5;
   private static volatile MethodHandle bindingCache6;
   private static volatile MethodHandle bindingCache7;
   private static volatile MethodHandle bindingCache8;
   private static volatile MethodHandle bindingCache9;
   private static volatile MethodHandle bindingCache10;
   private static volatile MethodHandle bindingCache11;
   private static volatile MethodHandle bindingCache12;
   private static volatile MethodHandle bindingCache13;
   private static volatile MethodHandle bindingCache14;
   private static volatile MethodHandle bindingCache15;
   private static volatile MethodHandle bindingCache16;
   private static volatile MethodHandle bindingCache17;
   private static volatile MethodHandle bindingCache18;
   private static volatile MethodHandle bindingCache19;
   private static volatile MethodHandle bindingCache20;
   private static volatile MethodHandle bindingCache21;
   private static volatile MethodHandle bindingCache22;
   private static volatile MethodHandle bindingCache23;
   private static volatile MethodHandle bindingCache24;
   private static volatile MethodHandle bindingCache25;
   private static volatile MethodHandle bindingCache26;
   private static volatile MethodHandle bindingCache27;
   private static volatile MethodHandle bindingCache28;
   private static volatile MethodHandle bindingCache29;
   private static volatile MethodHandle bindingCache30;
   private static volatile MethodHandle bindingCache31;
   private static volatile MethodHandle bindingCache32;
   private static volatile MethodHandle bindingCache33;
   private static volatile MethodHandle bindingCache34;
   private static volatile MethodHandle bindingCache35;
   private static volatile MethodHandle bindingCache36;
   private static volatile MethodHandle bindingCache37;
   private static volatile MethodHandle bindingCache38;
   private static volatile MethodHandle bindingCache39;
   private static volatile MethodHandle bindingCache40;
   private static volatile MethodHandle bindingCache41;
   private static volatile MethodHandle bindingCache42;
   private static volatile MethodHandle bindingCache43;
   private static volatile MethodHandle bindingCache44;
   private static volatile MethodHandle bindingCache45;
   private static volatile MethodHandle bindingCache46;
   private static volatile MethodHandle bindingCache47;
   private static volatile MethodHandle bindingCache48;
   private static volatile MethodHandle bindingCache49;

   
   
   public MsdfFont(String var1, long var2) throws IOException {
      super();
      var2 = 118462210935962L ^ var2;
      long var4 = var2 ^ 115762433281161L;
      long var6 = var2 ^ 109284721262827L;
      long var8 = var2 ^ 66852097883057L;
      long var10 = var2 ^ 107060167197084L;
      int var10000 = Event.cReturningInt();

      int var12 = var10000;
      this.e = 8.0F;
      this.h = new Int2ObjectOpenHashMap();
      short var10001 = 14403;
      long var10002 = 5130474269425803093L ^ var2;
      Object[] var10004 = new Object[]{null, var8};
      var10004[0] = 256;
      Object[] var19 = var10004;
      this.i = NumberUtil.aReturningMap(var19);
      this.m = invokeBinding1();
      var10001 = 19531;
      var10002 = 7006277997842866541L ^ var2;
      short var74 = 19971;
      long var10003 = 68447302727246626L ^ var2;
      Object[] var20 = new Object[]{"assets/prestige/msdf/" + var1 + ".json", var6};
      ResourceName var13 = ResourceName.aReturningc7(var20);
      var10001 = 22747;
      var10002 = 2912479378044073468L ^ var2;
      short var76 = 14404;
      var10003 = 2838721523516757354L ^ var2;
      Object[] var21 = new Object[]{"assets/prestige/msdf/" + var1 + ".png", var6};
      ResourceName var14 = ResourceName.aReturningc7(var21);
      Object[] var23 = new Object[]{var10};
      ResourceName var22 = var13;
      InputStream var15 = var22.aReturningInputStream(var23);

      InputStream var45;
      label76: {
         try {
            Object[] var25 = new Object[]{var10};
            ResourceName var24 = var14;
            InputStream var16 = var24.aReturningInputStream(var25);

            try {
               Object[] var27 = new Object[]{new InputStreamReader(var15), var16, var4};
               MsdfFont var26 = this;
               var26.aReturningVoid(var27);
            } catch (Throwable var68) {
               int var56 = var12;
               InputStream var55 = var16;
               InputStream var43 = var55;
               InputStream var42 = var55;
               if (var56 != 0) {
                  InputStream var57 = var42;
                  if (var57 == null) {
                     throw var68;
                  }

                  try {
                     var43 = var16;
                  } catch (Throwable var67) {
                     var68.addSuppressed(var67);
                     throw var68;
                  }
               }

               try {
                  InputStream var31 = var43;
                  var31.close();
               } catch (Throwable var65) {
                  var68.addSuppressed(var65);
               }

               throw var68;
            }

            int var53 = var12;
            InputStream var52 = var16;
            var45 = var52;
            InputStream var40 = var52;
            if (var53 == 0) {
               break label76;
            }

            InputStream var54 = var40;
            if (var54 != null) {
               InputStream var28 = var16;
               var28.close();
         } catch (Throwable var69) {
            int var62 = var12;
            InputStream var61 = var15;
            InputStream var50 = var61;
            InputStream var49 = var61;
            if (var62 != 0) {
               InputStream var63 = var49;
               if (var63 == null) {
                  throw var69;
               }

               try {
                  var50 = var15;
               } catch (Throwable var66) {
                  var69.addSuppressed(var66);
                  throw var69;
               }
            }

            try {
               InputStream var37 = var50;
               var37.close();
            } catch (Throwable var64) {
               var69.addSuppressed(var64);
            }

            throw var69;
         }

         var45 = var15;
      }

      int var59 = var12;
      InputStream var58 = var45;
      InputStream var47 = var58;
      InputStream var46 = var58;
      if (var59 != 0) {
         InputStream var60 = var46;
         if (var60 == null) {
            return;
         }

         var47 = var15;
      }

      InputStream var35 = var47;
      var35.close();
   }

   public MsdfFont(Reader var1, InputStream var2, long var3) throws IOException {
      super();
      var3 = 118462210935962L ^ var3;
      long var5 = var3 ^ 65866177091448L;
      long var7 = var3 ^ 121374017036352L;

      this.e = 8.0F;
      this.h = new Int2ObjectOpenHashMap();
      int var10001 = invokeBinding2(11527, 5543210190152978941L ^ var3);
      Object[] var10004 = new Object[]{null, var7};
      var10004[0] = var10001;
      this.i = invokeBinding3(var10004, -50048422918771760L, var3);
      this.m = invokeBinding4();
      invokeBinding5(this, new Object[]{var1, var2, var5}, -53497416407003498L, var3);
   }

   private void aReturningVoid(Object[] var1) throws IOException {
      Reader var3 = (Reader)var1[0];
      InputStream var2 = (InputStream)var1[1];
      long var4 = (Long)var1[2];
      var4 = 118462210935962L ^ var4;
      long var6 = var4 ^ 100836784339106L;
      long var8 = var4 ^ 138413041061876L;
      long var10 = var4 ^ 116961266891228L;
      long var12 = var4 ^ 65943838978808L;
      long var14 = var4 ^ 85314955768092L;
      long var16 = var4 ^ 117304184001950L;
      long var18 = var4 ^ 72252412594395L;
      int var10000 = Event.cReturningInt();
      Reader var30 = var3;
      JsonElement var31 = JsonParser.parseReader(var30);
      JsonObject var21 = var31.getAsJsonObject();
      int var20 = var10000;
      int var108 = var20;
      if (var108 != 0) {
         short var125 = 20796;
         long var10001 = 625529631310183434L ^ var4;
         short var10002 = 11890;
         long var10003 = 7286550400206570316L ^ var4;
         String var33 = "atlas";
         JsonObject var32 = var21;
         JsonObject var136 = var32.getAsJsonObject(var33);
         var10002 = 21153;
         var10003 = 1629153497991085979L ^ var4;
         String var35 = "type";
         JsonObject var34 = var136;
         JsonElement var36 = var34.get(var35);
         String var38 = var36.getAsString();
         String var37 = "msdf";
         boolean var109 = var37.equals(var38);
         if (!var109) {
            var10002 = 15274;
            var10003 = 8689191095150745233L ^ var4;
            throw new RuntimeException("not msdf atlas");
         }

         var10002 = 30353;
         var10003 = 6638766578307029929L ^ var4;
         String var42 = "atlas";
         JsonObject var41 = var21;
         JsonObject var137 = var41.getAsJsonObject(var42);
         var10002 = 21682;
         var10003 = 3794668737246394754L ^ var4;
         String var44 = "width";
         JsonObject var43 = var137;
         JsonElement var45 = var43.get(var44);
         this.c = var45.getAsInt();
         var10002 = 30353;
         var10003 = 6638766578307029929L ^ var4;
         String var47 = "atlas";
         JsonObject var46 = var21;
         JsonObject var138 = var46.getAsJsonObject(var47);
         var10002 = 30951;
         var10003 = 3965486948121597400L ^ var4;
         String var49 = "height";
         JsonObject var48 = var138;
         JsonElement var50 = var48.get(var49);
         this.d = var50.getAsInt();
         var10002 = 30353;
         var10003 = 6638766578307029929L ^ var4;
         String var52 = "atlas";
         JsonObject var51 = var21;
         JsonObject var139 = var51.getAsJsonObject(var52);
         var10002 = 12192;
         var10003 = 8019843166127325841L ^ var4;
         String var54 = "distanceRange";
         JsonObject var53 = var139;
         JsonElement var55 = var53.get(var54);
         this.b = var55.getAsFloat();
         var10002 = 13789;
         var10003 = 386820234162116833L ^ var4;
         String var57 = "metrics";
         JsonObject var56 = var21;
         Object[] var58 = new Object[]{var56.getAsJsonObject(var57), var8};
         this.j = FontMetrics.aReturningcA_C0111(var58);
         this.f = 1.0F / this.c;
         this.g = 1.0F / this.d;
      }

      InputStream var59 = var2;
      NativeImage var22 = NativeImage.read(var59);
      int var140 = 8100;
      long var159 = 8356077182669420704L ^ var4;
      Object[] var10004 = new Object[]{null, var18};
      var10004[0] = 3553;
      Object[] var60 = var10004;
      this.k = ManagedGlTexture.aReturningbT_C0095(var60);
      ManagedGlTexture var126 = this.k;
      var140 = (short)2200;
      var159 = 1139570179632328603L ^ var4;
      NativeImage var61 = var22;
      int var161 = var61.getWidth();
      NativeImage var62 = var22;
      int var174 = var62.getHeight();
      Object[] var10006 = new Object[]{null, null, null, var6};
      var10006[2] = var174;
      var10006[1] = var161;
      var10006[0] = 32856;
      Object[] var64 = var10006;
      ManagedGlTexture var63 = var126;
      var63.cReturningVoid(var64);
      NativeImage var65 = var22;
      int var23 = var65.getWidth();
      NativeImage var66 = var22;
      int var24 = var66.getHeight();
      int var67 = var23 * var24 * 4;
      ByteBuffer var25 = BufferUtils.createByteBuffer(var67);
      ByteOrder var69 = ByteOrder.LITTLE_ENDIAN;
      ByteBuffer var68 = var25;
      var68.order(var69);
      short var107;
      while (true) {
         int var111 = var24;
         int var110 = var26;
         if (var110 < var111) {
            int var113 = var20;
            byte var112 = 0;
            var107 = var112;
            byte var106 = var112;
            if (var113 == 0) {
               break;
            }

            int var27 = var106;

            label47: {
               int var117;
               do {
                  int var115 = var23;
                  int var114 = var27;
                  if (var114 >= var115) {
                     break;
                  }

                  int var72 = var26;
                  int var71 = var27;
                  NativeImage var70 = var22;
                  int var28 = var70.getColorArgb(var71, var72);
                  int var74 = var28;
                  ByteBuffer var73 = var25;
                  var73.putInt(var74);
                  var27++;
                  int var116 = var20;
                  if (var116 == 0) {
                     break label47;
                  }

                  var117 = var20;
               } while (var117 != 0);

               var26++;
            }

            int var118 = var20;
            if (var118 != 0) {
               continue;
            }
         }

         ByteBuffer var76 = var25;
         var76.flip();
         short var127 = 5158;
         long var142 = 7940072030002934568L ^ var4;
         GL11.glPixelStorei(3317, 1);
         var127 = 27489;
         long var143 = 7146513783109160032L ^ var4;
         GL11.glPixelStorei(3314, 0);
         var127 = 25010;
         long var144 = 9194443934330652329L ^ var4;
         GL11.glPixelStorei(3316, 0);
         var127 = 20354;
         long var145 = 2551840830678837405L ^ var4;
         GL11.glPixelStorei(3315, 0);
         ManagedGlTexture var131 = this.k;
         short var10005 = 10156;
         long var178 = 4765970056932409535L ^ var4;
         short var179 = 29391;
         long var10007 = 5183525949258798546L ^ var4;
         Object[] var10010 = new Object[]{null, null, null, null, null, null, var25, var12};
         var10010[5] = 5121;
         var10010[4] = 6408;
         var10010[3] = var24;
         var10010[2] = var23;
         var10010[1] = 0;
         var10010[0] = 0;
         Object[] var86 = var10010;
         ManagedGlTexture var85 = var131;
         var85.dReturningVoid(var86);
         var127 = 28956;
         long var146 = 3995179308022273547L ^ var4;
         var107 = 3317;
         break;
      }

      short var87 = var107;
      GL11.glPixelStorei(var87, 4);
      ManagedGlTexture var133 = this.k;
      var140 = (short)25414;
      var159 = 8710341465805620289L ^ var4;
      var10004 = new Object[]{null, var10};
      var10004[0] = 9729;
      Object[] var90 = var10004;
      ManagedGlTexture var89 = var133;
      var89.bReturningVoid(var90);
      ManagedGlTexture var134 = this.k;
      var140 = (short)8957;
      var159 = 1993395258388202993L ^ var4;
      var10004 = new Object[]{null, var14};
      var10004[0] = 33071;
      Object[] var92 = var10004;
      ManagedGlTexture var91 = var134;
      var91.eReturningVoid(var92);
      NativeImage var93 = var22;
      var93.close();
      var140 = (short)10497;
      var159 = 140139746950317106L ^ var4;
      String var95 = "glyphs";
      JsonObject var94 = var21;
      JsonArray var96 = var94.getAsJsonArray(var95);
      Iterator var122 = var96.iterator();

      int var120;
      do {
         Iterator var97 = var122;
         boolean var119 = var97.hasNext();
         if (!var119) {
            break;
         }

         Iterator var98 = var122;
         JsonElement var123 = (JsonElement)var98.next();
         JsonElement var99 = var123;
         JsonObject var124 = var99.getAsJsonObject();
         Object[] var100 = new Object[]{var124, var16};
         GlyphMetrics var29 = GlyphMetrics.aReturningcB_C0113(var100);
         Int2ObjectOpenHashMap var135 = this.h;
         Object[] var102 = new Object[0];
         GlyphMetrics var101 = var29;
         var140 = var101.aReturningInt(var102);
         GlyphMetrics var105 = var29;
         int var104 = var140;
         Int2ObjectOpenHashMap var103 = var135;
         var103.put(var104, var105);
         var120 = var20;
      } while (var120 != 0);
   }

   public void bReturningVoid(Object[] var1) {
      BiConsumer var2 = (BiConsumer)var1[0];
      this.l = var2;
   }

   public void cReturningVoid(Object[] var1) {
      Function var2 = (Function)var1[0];
      this.m = var2;
   }

   public void dReturningVoid(Object[] var1) {
      String var2 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var5 = (Float)var1[2];
      int var4 = (Integer)var1[3];
      long var6 = (Long)var1[4];
      var6 = 118462210935962L ^ var6;
      long var8 = var6 ^ 121686149876794L;
      float var10004 = this.e;
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var4;
      var10008[3] = var10004;
      var10008[2] = var5;
      var10008[1] = var3;
      var10008[0] = var2;
      invokeBinding6(this, var10008, 4420716565838773541L, var6);
   }

   public void eReturningVoid(Object[] var1) {
      String var7 = (String)var1[0];
      float var2 = (Float)var1[1];
      float var3 = (Float)var1[2];
      Color var6 = (Color)var1[3];
      long var4 = (Long)var1[4];
      var4 = 118462210935962L ^ var4;
      long var8 = var4 ^ 110290188699323L;
      float var10004 = this.e;
      int var10005 = invokeBinding7(var6, -582659011335388862L, var4);
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var10005;
      var10008[3] = var10004;
      var10008[2] = var3;
      var10008[1] = var2;
      var10008[0] = var7;
      invokeBinding8(this, var10008, -587578284750342236L, var4);
   }

   public void fReturningVoid(Object[] var1) {
      String var7 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var4 = (Float)var1[2];
      float var8 = (Float)var1[3];
      int var2 = (Integer)var1[4];
      long var5 = (Long)var1[5];
      var5 = 118462210935962L ^ var5;
      long var9 = var5 ^ 78491182107486L;
      long var11 = var5 ^ 10372912984928L;
      RenderCommandBatcher var13 = (RenderCommandBatcher)invokeBinding9(this.m, this, 9078274593074536313L, var5);
      RenderBatchKey var14 = invokeBinding10(this, new Object[]{var11}, 9064035061852595160L, var5);
      float var15 = invokeBinding11(this.j, new Object[0], 9063986747761094136L, var5) * var8;
      float[] var16 = new float[]{var3};
      invokeBinding13(this, new Object[]{var7, invokeBinding12(this, var16, var13, var14, var4, var8, var15, var2), var9}, 9077550935163644809L, var5);
   }

   public void gReturningVoid(Object[] var1) {
      String var7 = (String)var1[0];
      float var5 = (Float)var1[1];
      float var6 = (Float)var1[2];
      SourceSupport.discard(var1[3]);
      float var2 = (Float)var1[4];
      int var8 = (Integer)var1[5];
      long var3 = (Long)var1[6];
      var3 = 118462210935962L ^ var3;
      long var10 = var3 ^ 62788042501911L;
      Object[] var10008 = new Object[]{null, null, null, null, null, var10};
      var10008[4] = var8;
      var10008[3] = var2;
      var10008[2] = var6;
      var10008[1] = var5;
      var10008[0] = var7;
      invokeBinding14(this, var10008, -2417063017691357688L, var3);
   }

   public void hReturningVoid(Object[] var1) {
      Matrix4f var2 = (Matrix4f)var1[0];
      String var4 = (String)var1[1];
      float var5 = (Float)var1[2];
      float var3 = (Float)var1[3];
      float var8 = (Float)var1[4];
      int var9 = (Integer)var1[5];
      long var6 = (Long)var1[6];
      var6 = 118462210935962L ^ var6;
      long var10 = var6 ^ 115715394249579L;
      long var12 = var6 ^ 43095973698389L;
      MsdfFont var20 = this;
      Function var19 = this.m;
      RenderCommandBatcher var14 = (RenderCommandBatcher)var19.apply(var20);
      Object[] var22 = new Object[]{var12};
      MsdfFont var21 = this;
      RenderBatchKey var15 = var21.aReturninggA_C0325(var22);
      Matrix4f var16 = new Matrix4f(var2);
      FontMetrics var10000 = this.j;
      Object[] var24 = new Object[0];
      FontMetrics var23 = var10000;
      float var17 = var23.bReturningFloat(var24) * var8;
      float[] var18 = new float[]{var5};
      Object[] var26 = new Object[]{var4, invokeBinding15(this, var18, var14, var15, var16, var3, var8, var17, var9), var10};
      MsdfFont var25 = this;
      var25.x(var26);
   }

   public void iReturningVoid(Object[] var1) {
      String var4 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var2 = (Float)var1[2];
      float var5 = (Float)var1[3];
      int var6 = (Integer)var1[4];
      long var7 = (Long)var1[5];
      var7 = 118462210935962L ^ var7;
      long var9 = var7 ^ 63354544573236L;
      long var11 = var7 ^ 75335764942006L;
      Object[] var10008 = new Object[]{null, null, var9};
      var10008[1] = var5;
      var10008[0] = var4;
      float var10002 = var3 - invokeBinding16(this, var10008, -1307258496516649880L, var7);
      var10008 = new Object[]{null, null, null, null, null, var11};
      var10008[4] = var6;
      var10008[3] = var5;
      var10008[2] = var2;
      var10008[1] = var10002;
      var10008[0] = var4;
      invokeBinding17(this, var10008, -1308963768180413015L, var7);
   }

   public void jReturningVoid(Object[] var1) {
      String var5 = (String)var1[0];
      float var6 = (Float)var1[1];
      float var4 = (Float)var1[2];
      int var7 = (Integer)var1[3];
      long var2 = (Long)var1[4];
      var2 = 118462210935962L ^ var2;
      long var8 = var2 ^ 48287159481655L;
      long var10 = var2 ^ 12087109875313L;
      float var10002 = var6 - invokeBinding18(this, new Object[]{var5, var8}, 509804580603401617L, var2);
      float var10004 = this.e;
      Object[] var10008 = new Object[]{null, null, null, null, null, var10};
      var10008[4] = var7;
      var10008[3] = var10004;
      var10008[2] = var4;
      var10008[1] = var10002;
      var10008[0] = var5;
      invokeBinding19(this, var10008, 509731499321198446L, var2);
   }

   public void kReturningVoid(Object[] var1) {
      String var7 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var6 = (Float)var1[2];
      int var2 = (Integer)var1[3];
      long var4 = (Long)var1[4];
      var4 = 118462210935962L ^ var4;
      long var8 = var4 ^ 98383782480568L;
      long var10 = var4 ^ 132415040719358L;
      float var10002 = var3 - invokeBinding20(this, new Object[]{var7, var8}, -532478084491810274L, var4) / 2.0F;
      float var10004 = this.e;
      Object[] var10008 = new Object[]{null, null, null, null, null, var10};
      var10008[4] = var2;
      var10008[3] = var10004;
      var10008[2] = var6;
      var10008[1] = var10002;
      var10008[0] = var7;
      invokeBinding21(this, var10008, -532097066935322399L, var4);
   }

   public void lReturningVoid(Object[] var1) {
      String var4 = (String)var1[0];
      float var8 = (Float)var1[1];
      float var7 = (Float)var1[2];
      float var6 = (Float)var1[3];
      int var5 = (Integer)var1[4];
      long var2 = (Long)var1[5];
      var2 = 118462210935962L ^ var2;
      long var9 = var2 ^ 95634127517903L;
      long var11 = var2 ^ 48241453248333L;
      Object[] var10008 = new Object[]{null, null, var9};
      var10008[1] = var6;
      var10008[0] = var4;
      float var10002 = var8 - invokeBinding22(this, var10008, -2440739656742027373L, var2) / 2.0F;
      var10008 = new Object[]{null, null, null, null, null, var11};
      var10008[4] = var5;
      var10008[3] = var6;
      var10008[2] = var7;
      var10008[1] = var10002;
      var10008[0] = var4;
      invokeBinding23(this, var10008, -2436782718406435246L, var2);
   }

   public void mReturningVoid(Object[] var1) {
      String var8 = (String)var1[0];
      float var6 = (Float)var1[1];
      float var2 = (Float)var1[2];
      float var7 = (Float)var1[3];
      int var5 = (Integer)var1[4];
      long var3 = (Long)var1[5];
      var3 = 118462210935962L ^ var3;
      long var9 = var3 ^ 134269304066108L;
      int var11 = (var5 >>> invokeBinding24(6832, 3462272113907284063L ^ var3) & invokeBinding25(8494, 5890080540862972877L ^ var3))
            * invokeBinding26(25789, 1666763668720961112L ^ var3)
         >> invokeBinding27(11093, 8247995717696293300L ^ var3);
      int var12 = var11 << invokeBinding28(6832, 3462272113907284063L ^ var3);
      float var10002 = var6 + 0.5F;
      float var10003 = var2 + 0.5F;
      Object[] var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var12;
      var10008[3] = var7;
      var10008[2] = var10003;
      var10008[1] = var10002;
      var10008[0] = var8;
      invokeBinding29(this, var10008, -6818556517758688989L, var3);
      var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var5;
      var10008[3] = var7;
      var10008[2] = var2;
      var10008[1] = var6;
      var10008[0] = var8;
      invokeBinding30(this, var10008, -6818556517758688989L, var3);
   }

   public void nReturningVoid(Object[] var1) {
      Matrix4f var7 = (Matrix4f)var1[0];
      String var4 = (String)var1[1];
      float var9 = (Float)var1[2];
      float var6 = (Float)var1[3];
      float var5 = (Float)var1[4];
      Color var8 = (Color)var1[5];
      long var2 = (Long)var1[6];
      var2 = 118462210935962L ^ var2;
      long var10 = var2 ^ 66793552749442L;
      Color var15 = var8;
      int var12 = var15.getRGB();
      short var10001 = 6404;
      long var10002 = 1587235443114532990L ^ var2;
      int var10000 = var12 >>> 24;
      var10001 = 7619;
      var10002 = 2576220121788179632L ^ var2;
      var10000 &= 255;
      var10001 = 9243;
      var10002 = 8099491274937654650L ^ var2;
      var10000 *= 140;
      var10001 = 32444;
      var10002 = 8302059991666165712L ^ var2;
      int var13 = var10000 >> 8;
      var10001 = 6832;
      var10002 = 3462176128465134548L ^ var2;
      int var14 = var13 << 24;
      float var10003 = var9 + 0.5F;
      float var10004 = var6 + 0.5F;
      Object[] var10009 = new Object[]{null, null, null, null, null, null, var10};
      var10009[5] = var14;
      var10009[4] = var5;
      var10009[3] = var10004;
      var10009[2] = var10003;
      var10009[1] = var4;
      var10009[0] = var7;
      Object[] var17 = var10009;
      MsdfFont var16 = this;
      var16.hReturningVoid(var17);
      var10009 = new Object[]{null, null, null, null, null, null, var10};
      var10009[5] = var12;
      var10009[4] = var5;
      var10009[3] = var6;
      var10009[2] = var9;
      var10009[1] = var4;
      var10009[0] = var7;
      Object[] var19 = var10009;
      MsdfFont var18 = this;
      var18.hReturningVoid(var19);
   }

   public void o(Object[] var1) {
      String var5 = (String)var1[0];
      float var6 = (Float)var1[1];
      float var2 = (Float)var1[2];
      int var7 = (Integer)var1[3];
      long var3 = (Long)var1[4];
      var3 = 118462210935962L ^ var3;
      long var8 = var3 ^ 20023214876044L;
      float var10004 = this.e;
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var7;
      var10008[3] = var10004;
      var10008[2] = var2;
      var10008[1] = var6;
      var10008[0] = var5;
      invokeBinding31(this, var10008, 598977624654216316L, var3);
   }

   public void p(Object[] var1) {
      String var4 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var7 = (Float)var1[2];
      int var2 = (Integer)var1[3];
      long var5 = (Long)var1[4];
      var5 = 118462210935962L ^ var5;
      long var8 = var5 ^ 53625191494453L;
      float var10004 = this.e;
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var2;
      var10008[3] = var10004;
      var10008[2] = var7;
      var10008[1] = var3;
      var10008[0] = var4;
      invokeBinding32(this, var10008, 6842898621273909957L, var5);
   }

   public void q(Object[] var1) {
      String var8 = (String)var1[0];
      float var6 = (Float)var1[1];
      float var7 = (Float)var1[2];
      float var5 = (Float)var1[3];
      int var2 = (Integer)var1[4];
      long var3 = (Long)var1[5];
      var3 = 118462210935962L ^ var3;
      long var9 = var3 ^ 25848396734953L;
      Object[] var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var2;
      var10008[3] = var5;
      var10008[2] = var7;
      var10008[1] = var6;
      var10008[0] = var8;
      invokeBinding33(this, var10008, 5488475406886942745L, var3);
   }

   public void r(Object[] var1) {
      String var5 = (String)var1[0];
      float var6 = (Float)var1[1];
      float var7 = (Float)var1[2];
      Color var2 = (Color)var1[3];
      long var3 = (Long)var1[4];
      var3 = 118462210935962L ^ var3;
      long var8 = var3 ^ 59897763212654L;
      float var10004 = this.e;
      int var10005 = invokeBinding34(var2, 43550693963036209L, var3);
      Object[] var10008 = new Object[]{null, null, null, null, null, var8};
      var10008[4] = var10005;
      var10008[3] = var10004;
      var10008[2] = var7;
      var10008[1] = var6;
      var10008[0] = var5;
      invokeBinding35(this, var10008, 48935645880644766L, var3);
   }

   public void s(Object[] var1) {
      String var8 = (String)var1[0];
      float var4 = (Float)var1[1];
      float var3 = (Float)var1[2];
      float var5 = (Float)var1[3];
      Color var2 = (Color)var1[4];
      long var6 = (Long)var1[5];
      var6 = 118462210935962L ^ var6;
      long var9 = var6 ^ 41940246413557L;
      int var10005 = invokeBinding36(var2, 7854745587683957674L, var6);
      Object[] var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var10005;
      var10008[3] = var5;
      var10008[2] = var3;
      var10008[1] = var4;
      var10008[0] = var8;
      invokeBinding37(this, var10008, 7869700510013102341L, var6);
   }

   public void t(Object[] var1) {
      String var6 = (String)var1[0];
      float var8 = (Float)var1[1];
      float var2 = (Float)var1[2];
      float var7 = (Float)var1[3];
      Color var3 = (Color)var1[4];
      long var4 = (Long)var1[5];
      var4 = 118462210935962L ^ var4;
      long var9 = var4 ^ 123094057187111L;
      float var10004 = this.e * var7;
      int var10005 = invokeBinding38(var3, 6544821721462484088L, var4);
      Object[] var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var10005;
      var10008[3] = var10004;
      var10008[2] = var2;
      var10008[1] = var8;
      var10008[0] = var6;
      invokeBinding39(this, var10008, 6549504051639922391L, var4);
   }

   public void u(Object[] var1) {
      String var8 = (String)var1[0];
      float var3 = (Float)var1[1];
      float var4 = (Float)var1[2];
      Color var2 = (Color)var1[3];
      float var7 = (Float)var1[4];
      long var5 = (Long)var1[5];
      var5 = 118462210935962L ^ var5;
      long var9 = var5 ^ 43428193017025L;
      float var10004 = this.e * var7;
      int var10005 = invokeBinding40(var2, -5677446876324837474L, var5);
      Object[] var10008 = new Object[]{null, null, null, null, null, var9};
      var10008[4] = var10005;
      var10008[3] = var10004;
      var10008[2] = var4;
      var10008[1] = var3;
      var10008[0] = var8;
      invokeBinding41(this, var10008, -5691763019861506767L, var5);
   }

   public void v(Object[] var1) {
      Matrix4f var2 = (Matrix4f)var1[0];
      String var5 = (String)var1[1];
      float var4 = (Float)var1[2];
      float var6 = (Float)var1[3];
      Color var3 = (Color)var1[4];
      long var7 = (Long)var1[5];
      var7 = 118462210935962L ^ var7;
      long var9 = var7 ^ 88186219662415L;
      float var10005 = this.e;
      Object[] var10009 = new Object[]{null, null, null, null, null, var3, var9};
      var10009[4] = var10005;
      var10009[3] = var6;
      var10009[2] = var4;
      var10009[1] = var5;
      var10009[0] = var2;
      Object[] var12 = var10009;
      MsdfFont var11 = this;
      var11.nReturningVoid(var12);
   }

   public void w(Object[] var1) {
      Matrix4f var4 = (Matrix4f)var1[0];
      String var7 = (String)var1[1];
      float var5 = (Float)var1[2];
      float var9 = (Float)var1[3];
      float var8 = (Float)var1[4];
      Color var6 = (Color)var1[5];
      long var2 = (Long)var1[6];
      var2 = 118462210935962L ^ var2;
      long var10 = var2 ^ 32321322023285L;
      float var10005 = this.e * var8;
      Object[] var10009 = new Object[]{null, null, null, null, null, var6, var10};
      var10009[4] = var10005;
      var10009[3] = var9;
      var10009[2] = var5;
      var10009[1] = var7;
      var10009[0] = var4;
      Object[] var13 = var10009;
      MsdfFont var12 = this;
      var12.nReturningVoid(var13);
   }

   public float aReturningFloat(Object[] var1) {
      String var4 = (String)var1[0];
      long var2 = (Long)var1[1];
      var2 = 118462210935962L ^ var2;
      long var5 = var2 ^ 61245151664222L;
      float var10002 = this.e;
      Object[] var10005 = new Object[]{null, null, var5};
      var10005[1] = var10002;
      var10005[0] = var4;
      Object[] var8 = var10005;
      MsdfFont var7 = this;
      return var7.bReturningFloat(var8);
   }

   public float bReturningFloat(Object[] var1) {
      String var5 = (String)var1[0];
      float var2 = (Float)var1[1];
      long var3 = (Long)var1[2];
      var3 = 118462210935962L ^ var3;
      long var6 = var3 ^ 64294580051164L;
      int var8 = Event.bReturningInt();
      int var30 = var8;
      String var29 = var5;
      Object var26 = var29;
      String var25 = var29;
      if (var30 == 0) {
         String var12 = var25;
         boolean var31 = var12.isEmpty();
         if (var31) {
            return 0.0F;
         }

         String var16 = var5;
         Map var15 = this.i;
         var26 = var15.get(var16);
      }

      label25: {
         Float var9 = (Float)var26;
         int var33 = var8;
         Float var32 = var9;
         Float var28 = var32;
         Float var27 = var32;
         if (var33 == 0) {
            Float var34 = var27;
            if (var34 == null) {
               break label25;
            }

            var28 = var9;
         }

         Float var18 = var28;
         float var10 = var18;
         int var35 = var8;
         if (var35 == 0) {
            return var2 * var10;
         }
      }

      float[] var11 = new float[]{0.0F};
      Object[] var20 = new Object[]{var5, invokeBinding42(var11), var6};
      MsdfFont var19 = this;
      var19.x(var20);
      float var37 = var11[0];
      Map var10000 = this.i;
      float var21 = var37;
      Float var24 = var21;
      String var23 = var5;
      Map var22 = var10000;
      var22.put(var23, var24);
      return var2 * var37;
   }

   public float cReturningFloat(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 118462210935962L ^ var2;
      long var4 = var2 ^ 68245440180614L;
      float var10001 = this.e;
      Object[] var10004 = new Object[]{null, var4};
      var10004[0] = var10001;
      Object[] var7 = var10004;
      MsdfFont var6 = this;
      return var6.dReturningFloat(var7);
   }

   public float dReturningFloat(Object[] var1) {
      float var2 = (Float)var1[0];
      long var3 = (Long)var1[1];
      long var10000 = 118462210935962L ^ var3;
      FontMetrics var7 = this.j;
      Object[] var6 = new Object[0];
      FontMetrics var5 = var7;
      return var5.aReturningFloat(var6) * var2;
   }

   public String aReturningString(Object[] var1) {

      String var2 = (String)var1[0];
      float var4 = (Float)var1[1];
      float var3 = (Float)var1[2];
      long var5 = (Long)var1[3];
      var5 = 118462210935962L ^ var5;
      long var7 = var5 ^ 29738970555382L;
      long var9 = var5 ^ 82223816307632L;

      try {
         Object[] var10005 = new Object[]{null, null, var9};
         var10005[1] = var3;
         var10005[0] = var2;
         float var19;
         int var15 = (var19 = invokeBinding43(this, var10005, -3071494510874675988L, var5) - var4) == 0.0F ? 0 : (var19 < 0.0F ? -1 : 1);
         if (var15 <= 0) {
            return var2;
         }
      } catch (RuntimeException var16) {
         throw invokeBinding44(var16, -3071176578369704022L, var5);
      }

      StringBuilder var11 = new StringBuilder();
      String var10001 = invokeBinding45(31150, 4872313258852607338L ^ var5);
      Object[] var18 = new Object[]{null, null, var9};
      var18[1] = var3;
      var18[0] = var10001;
      float var12 = invokeBinding46(this, var18, -3071494510874675988L, var5);
      float[] var13 = new float[]{0.0F};
      invokeBinding48(this, new Object[]{var2, invokeBinding47(var3, var13, var12, var4, var11), var7}, -3075487868430318815L, var5);
      return invokeBinding49(var11, -3068486381232528976L, var5);
   
      
}

   private void x(Object[] var1) {
      String var3 = (String)var1[0];
      GlyphVisitor var2 = (GlyphVisitor)var1[1];
      long var4 = (Long)var1[2];
      var4 = 118462210935962L ^ var4;
      String var11 = var3;
      int var7 = var11.length();
      int var10000 = Event.bReturningInt();
      int var6 = var10000;

      while (true) {
         int var34 = var7;
         int var33 = var8;
         if (var33 >= var34) {
            break;
         }

         int var9;
         int var31;
         int var32;
         int var13 = var8;
         String var12 = var3;
         var9 = var12.codePointAt(var13);
         short var10001 = 2360;
         long var10002 = 8523346782538821795L ^ var4;
         int var37 = var6;
         short var36 = 167;
         int var35 = var9;
         var31 = var35;
         var32 = var36;
         int var25 = var35;
         short var26 = var36;
         label36:
         if (var37 == 0) {
            short var39 = var26;
            int var38 = var25;
            if (var38 == var39) {
               var10000 = var8 + 1;
               int var42 = var6;
               int var41 = var7;
               int var40 = var10000;
               var31 = var40;
               var32 = var41;
               int var27 = var40;
               int var28 = var41;
               if (var42 != 0) {
                  break label36;
               }

               int var44 = var28;
               int var43 = var27;
               int var29 = var43;
               int var30 = var44;
               int var46 = var30;
               int var45 = var29;
               if (var45 < var46) {
                  var8 += 2;
                  int var47 = var6;
                  if (var47 == 0) {
                     continue;
                  }
               }
            }

            int var18 = var9;
            var32 = Character.charCount(var18);
            var31 = var8;
         }

         var8 = var31 + var32;
         int var20 = var9;
         Int2ObjectOpenHashMap var19 = this.h;
         GlyphMetrics var10 = (GlyphMetrics)var19.get(var20);
         GlyphMetrics var48 = var10;
         if (var48 != null) {
            GlyphMetrics var24 = var10;
            int var23 = var9;
            GlyphVisitor var22 = var2;
            boolean var49 = var22.aReturningVoid(var23, var24);
            if (!var49) {
               return;
            }

            int var50 = var6;
            if (var50 != 0) {
               break;
            }
         }
      }
   }

   public float eReturningFloat(Object[] var1) {
      return this.e;
   }

   public void y(Object[] var1) {
      float var2 = (Float)var1[0];
      this.e = var2;
   }

   private float fReturningFloat(Object[] var1) {
      RenderCommandBatcher var10 = (RenderCommandBatcher)var1[0];
      RenderBatchKey var4 = (RenderBatchKey)var1[1];
      GlyphMetrics var11 = (GlyphMetrics)var1[2];
      float var6 = (Float)var1[3];
      float var2 = (Float)var1[4];
      float var9 = (Float)var1[5];
      float var3 = (Float)var1[6];
      int var5 = (Integer)var1[7];
      long var7 = (Long)var1[8];
      var7 = 118462210935962L ^ var7;
      long var12 = var7 ^ 29866062863323L;
      long var14 = var7 ^ 118609858965352L;
      int var16 = Event.cReturningInt();
      Object[] var26 = new Object[0];
      GlyphMetrics var25 = var11;
      float var10000 = var25.dReturningFloat(var26);
      Object[] var28 = new Object[0];
      GlyphMetrics var27 = var11;
      var10000 -= var27.bReturningFloat(var28);
      int var56 = var16;
      float var55 = 0.0F;
      float var54 = var10000;
      float var52 = var54;
      float var53 = var55;
      float var50 = var54;
      float var51 = var55;
      if (var56 != 0) {
         float var62;
         int var57 = (var62 = var50 - var51) == 0.0F ? 0 : (var62 < 0.0F ? -1 : 1);
         if (((var57) != 0)) {
            Object[] var31 = new Object[0];
            GlyphMetrics var30 = var11;
            float var17 = var6 + var30.bReturningFloat(var31) * var9;
            Object[] var33 = new Object[0];
            GlyphMetrics var32 = var11;
            float var18 = var6 + var32.dReturningFloat(var33) * var9;
            var10000 = var2 + var3;
            Object[] var35 = new Object[0];
            GlyphMetrics var34 = var11;
            float var19 = var10000 - var34.eReturningFloat(var35) * var9;
            var10000 = var2 + var3;
            Object[] var37 = new Object[0];
            GlyphMetrics var36 = var11;
            float var20 = var10000 - var36.cReturningFloat(var37) * var9;
            Object[] var39 = new Object[0];
            GlyphMetrics var38 = var11;
            float var21 = var38.fReturningFloat(var39) * this.f;
            Object[] var41 = new Object[0];
            GlyphMetrics var40 = var11;
            float var22 = var40.hReturningFloat(var41) * this.f;
            Object[] var43 = new Object[0];
            GlyphMetrics var42 = var11;
            float var23 = 1.0F - var42.iReturningFloat(var43) * this.g;
            Object[] var45 = new Object[0];
            GlyphMetrics var44 = var11;
            float var24 = 1.0F - var44.gReturningFloat(var45) * this.g;
            Object[] var47 = new Object[]{new QuadRenderCommand(var4, var17, var19, var18, var20, var5, var21, var23, var22, var24, null, var12), var14};
            RenderCommandBatcher var46 = var10;
            var46.bReturningVoid(var47);
         }

         Object[] var49 = new Object[0];
         GlyphMetrics var48 = var11;
         var53 = var48.aReturningFloat(var49);
         var52 = var9;
      }

      return var52 * var53;
   }

   private float gReturningFloat(Object[] var1) {
      RenderCommandBatcher var10 = (RenderCommandBatcher)var1[0];
      RenderBatchKey var2 = (RenderBatchKey)var1[1];
      Matrix4f var3 = (Matrix4f)var1[2];
      GlyphMetrics var6 = (GlyphMetrics)var1[3];
      float var9 = (Float)var1[4];
      float var4 = (Float)var1[5];
      float var12 = (Float)var1[6];
      float var5 = (Float)var1[7];
      int var11 = (Integer)var1[8];
      long var7 = (Long)var1[9];
      var7 = 118462210935962L ^ var7;
      long var13 = var7 ^ 83040412563748L;
      long var15 = var7 ^ 65214327885207L;
      int var17 = Event.cReturningInt();
      Object[] var27 = new Object[0];
      GlyphMetrics var26 = var6;
      float var10000 = var26.dReturningFloat(var27);
      Object[] var29 = new Object[0];
      GlyphMetrics var28 = var6;
      var10000 -= var28.bReturningFloat(var29);
      int var57 = var17;
      float var56 = 0.0F;
      float var55 = var10000;
      float var53 = var55;
      float var54 = var56;
      float var51 = var55;
      float var52 = var56;
      if (var57 != 0) {
         float var63;
         int var58 = (var63 = var51 - var52) == 0.0F ? 0 : (var63 < 0.0F ? -1 : 1);
         if (((var58) != 0)) {
            Object[] var32 = new Object[0];
            GlyphMetrics var31 = var6;
            float var18 = var9 + var31.bReturningFloat(var32) * var12;
            Object[] var34 = new Object[0];
            GlyphMetrics var33 = var6;
            float var19 = var9 + var33.dReturningFloat(var34) * var12;
            var10000 = var4 + var5;
            Object[] var36 = new Object[0];
            GlyphMetrics var35 = var6;
            float var20 = var10000 - var35.eReturningFloat(var36) * var12;
            var10000 = var4 + var5;
            Object[] var38 = new Object[0];
            GlyphMetrics var37 = var6;
            float var21 = var10000 - var37.cReturningFloat(var38) * var12;
            Object[] var40 = new Object[0];
            GlyphMetrics var39 = var6;
            float var22 = var39.fReturningFloat(var40) * this.f;
            Object[] var42 = new Object[0];
            GlyphMetrics var41 = var6;
            float var23 = var41.hReturningFloat(var42) * this.f;
            Object[] var44 = new Object[0];
            GlyphMetrics var43 = var6;
            float var24 = 1.0F - var43.iReturningFloat(var44) * this.g;
            Object[] var46 = new Object[0];
            GlyphMetrics var45 = var6;
            float var25 = 1.0F - var45.gReturningFloat(var46) * this.g;
            Object[] var48 = new Object[]{new QuadRenderCommand(var2, var18, var20, var19, var21, var11, var22, var24, var23, var25, var3, var13), var15};
            RenderCommandBatcher var47 = var10;
            var47.bReturningVoid(var48);
         }

         Object[] var50 = new Object[0];
         GlyphMetrics var49 = var6;
         var54 = var49.aReturningFloat(var50);
         var53 = var12;
      }

      return var53 * var54;
   }

   public RenderBatchKey aReturninggA_C0325(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 118462210935962L ^ var2;
      long var4 = var2 ^ 10937905743058L;
      int var6 = Event.cReturningInt();
      int var13 = var6;
      RenderBatchKey var12 = this.o;
      RenderBatchKey var11 = var12;
      RenderBatchKey var10 = var12;
      if (var13 != 0) {
         RenderBatchKey var14 = var10;
         if (var14 == null) {
            Object[] var9 = new Object[]{var4};
            MsdfFont var8 = this;
            this.o = new RenderBatchKey(null, var8.aReturningdn_C0192(var9));
         }

         var11 = this.o;
      }

      return var11;
   }

   public DrawPipeline aReturningdn_C0192(Object[] var1) {
      long var2 = (Long)var1[0];
      var2 = 118462210935962L ^ var2;
      long var4 = var2 ^ 87062861568051L;
      int var6 = Event.cReturningInt();
      int var22 = var6;
      DrawPipeline var21 = this.n;
      DrawPipeline var20 = var21;
      DrawPipeline var16 = var21;
      if (var22 != 0) {
         MsdfFont var19;
         label20: {
            DrawPipeline var23 = var16;
            if (var23 == null) {
               VertexFormat var10003 = VertexFormats.c;
               short var10006 = 11075;
               long var10007 = 8934322725470954165L ^ var2;
               RenderState[] var29 = new RenderState[]{RenderState.a, null, null, null, null, null};
               Object[] var8 = new Object[]{ShaderPrograms.e};
               var29[1] = RenderState.aReturninggH_C0339(var8);
               short var10009 = 25747;
               long var10010 = 2806037072866782588L ^ var2;
               Object[] var10013 = new Object[]{null, null, true};
               var10013[1] = false;
               var10013[0] = 2884;
               Object[] var9 = var10013;
               var29[2] = RenderState.bReturninggF_C0335(var9);
               Object[] var10012 = new Object[]{null, true};
               var10012[0] = true;
               Object[] var10 = var10012;
               var29[3] = RenderState.aReturninggI_C0341(var10);
               short var10011 = 4673;
               long var30 = 6568637847776058291L ^ var2;
               var29[4] = new CapabilityState(2929, false);
               var29[5] = new BlurTextureState(this.k, this.b / this.c, this.b / this.d);
               this.n = new DrawPipeline(var10003, 4, false, var29, var4);
               int var25 = var6;
               MsdfFont var24 = this;
               var19 = var24;
               MsdfFont var17 = var24;
               if (var25 == 0) {
                  break label20;
               }

               MsdfFont var26 = var17;
               MsdfFont var18 = var26;
               BiConsumer var27 = var18.l;
               if (var27 != null) {
                  DrawPipeline var15 = this.n;
                  MsdfFont var14 = this;
                  BiConsumer var13 = this.l;
                  var13.accept(var14, var15);
               }
            }

            var19 = this;
         }

         var20 = var19.n;
      }

      return var20;
   }

   public void aReturningVoid() {
      int var3 = Event.cReturningInt();
      int var10 = var3;
      ManagedGlTexture var9 = this.k;
      ManagedGlTexture var8 = var9;
      ManagedGlTexture var7 = var9;
      if (var10 != 0) {
         ManagedGlTexture var11 = var7;
         if (var11 == null) {
            return;
         }

         ManagedGlTexture var12 = this.k;
         var8 = var12;
      }

      ManagedGlTexture var6 = var8;
      var6.close();
   }

   private static boolean lambda$truncate$4(float var0, float[] var1, float var2, float var3, StringBuilder var4, int var5, GlyphMetrics var6) {
      int var10000 = Event.bReturningInt();
      Object[] var12 = new Object[0];
      GlyphMetrics var11 = var6;
      float var10 = var0 * var11.aReturningFloat(var12);
      int var9 = var10000;
      float var25;
      var10000 = (var25 = var1[0] + var10 + var2 - var3) == 0.0F ? 0 : (var25 < 0.0F ? -1 : 1);
      int var22 = var9;
      int var21 = var10000;
      int var20 = var21;
      int var19 = var21;
      if (var22 == 0) {
         int var23 = var19;
         if (var23 > 0) {
            String var15 = "...";
            StringBuilder var14 = var4;
            var14.append(var15);
            return false;
         }

         var1[0] += var10;
         int var18 = var5;
         StringBuilder var17 = var4;
         var17.appendCodePoint(var18);
         var20 = 1;
      }

      return dev.prestige.recovery.SourceSupport.asBoolean(var20);
   }

   private static boolean lambda$getWidth$3(float[] var0, int var1, GlyphMetrics var2) {
      float var10002 = var0[0];
      Object[] var6 = new Object[0];
      GlyphMetrics var5 = var2;
      var0[0] = var10002 + var5.aReturningFloat(var6);
      return true;
   }

   private boolean lambda$render$2(float[] var1, RenderCommandBatcher var2, RenderBatchKey var3, Matrix4f var4, float var5, float var6, float var7, int var8, int var9, GlyphMetrics var10) {
      long var10001 = 12118495473524L ^ 98396266406311L;
      float var10002 = var1[0];
      float var10008 = var1[0];
      Object[] var10015 = new Object[]{null, null, null, null, null, null, null, null, null, 90675955601107L};
      var10015[8] = var8;
      var10015[7] = var7;
      var10015[6] = var6;
      var10015[5] = var5;
      var10015[4] = var10008;
      var10015[3] = var10;
      var10015[2] = var4;
      var10015[1] = var3;
      var10015[0] = var2;
      Object[] var16 = var10015;
      MsdfFont var15 = this;
      var1[0] = var10002 + var15.gReturningFloat(var16);
      return true;
   }

   private boolean lambda$render$1(float[] var1, RenderCommandBatcher var2, RenderBatchKey var3, float var4, float var5, float var6, int var7, int var8, GlyphMetrics var9) {
      long var10001 = 132065498360896L ^ 135012957143148L;
      float var10002 = var1[0];
      float var10007 = var1[0];
      Object[] var10014 = new Object[]{null, null, null, null, null, null, null, null, 3125700471852L};
      var10014[7] = var7;
      var10014[6] = var6;
      var10014[5] = var5;
      var10014[4] = var4;
      var10014[3] = var10007;
      var10014[2] = var9;
      var10014[1] = var3;
      var10014[0] = var2;
      Object[] var15 = var10014;
      MsdfFont var14 = this;
      var1[0] = var10002 + var14.fReturningFloat(var15);
      return true;
   }

   private static RenderCommandBatcher lambda$new$0(MsdfFont var0) {
      long var10001 = 128442376304207L ^ 20613024977221L;
      Object[] var5 = new Object[]{112622804313866L};
      ShapeRenderer.aReturningVoid(var5);
      AtomicReference var6 = ShapeRenderer.a;
      return (RenderCommandBatcher)var6.get();
   }

   static {

      {

      b();
      Cipher var11;
      Cipher var10000 = var11 = Cipher.getInstance("DES/CBC/PKCS5Padding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var12 = 1; var12 < 8; var12++) {
         var10003[var12] = (byte)(13536763091142L << var12 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      String[] var18 = new String[16];
      String var15 = "ìÙ«Û\u0084Í!\u0091hA\u009c¸54\u0084í#?\u0001Ôc\u000f\u0017\nW~v$ÓöÂ÷\u0010¨,\u009aZ\u008e_\u007f\u0007\u001a¡Ú\u0088\u0093m/\u009c\u0010l!é\u0088jí¯&ïë\u0016Í\u0089#\u001d\u001e\u0010§C3i\u007fC\u0092pÿ£B'Ò:WG(<V,eL\u0086³_ÚÁW\u0017õ?ÆLºÇ\nõék\u001f¬¶Ð¯è>I!eÅù.\u00adf\u0085\u0096Ä(¡\u0001ÍÖ¥½ºº\\X£äè\u0001¶AÂªåu\u008e=\u008f__y\n ¢d\u0016\u0003Vq÷JÍò\u0094\u0092\u0010\u0086\u0090\u0092¦H\u0019ì48\fTD\u0086w¶¸\u0010ç JÒeØÚ´ø M*Õù\u0013\u0092\u0010\u0012ky\u001e]-ï¼zH\u009e,Ç¸\u0019§\u0010\u0015ÒQGæwÕ\u0011\u00061sí\u0092ówº {Æ^@SÍÃY¸\u000fÆÅ\u0088\u0093cÆ®|\u0080k¨¦\f5\u008eý\u000b(Zi\u009e\u000f\u0010MÚÞ\u009dûÕÊQqG\u0086iòñÄ»\u0010\u000b¥cU\u0085J\u009bÆ\u001c\u0003RÕ}¼ \u0086\u0010BàúµÆ«Å!ò\u0002~N,\u009c\u0006s";
      int var17 = "ìÙ«Û\u0084Í!\u0091hA\u009c¸54\u0084í#?\u0001Ôc\u000f\u0017\nW~v$ÓöÂ÷\u0010¨,\u009aZ\u008e_\u007f\u0007\u001a¡Ú\u0088\u0093m/\u009c\u0010l!é\u0088jí¯&ïë\u0016Í\u0089#\u001d\u001e\u0010§C3i\u007fC\u0092pÿ£B'Ò:WG(<V,eL\u0086³_ÚÁW\u0017õ?ÆLºÇ\nõék\u001f¬¶Ð¯è>I!eÅù.\u00adf\u0085\u0096Ä(¡\u0001ÍÖ¥½ºº\\X£äè\u0001¶AÂªåu\u008e=\u008f__y\n ¢d\u0016\u0003Vq÷JÍò\u0094\u0092\u0010\u0086\u0090\u0092¦H\u0019ì48\fTD\u0086w¶¸\u0010ç JÒeØÚ´ø M*Õù\u0013\u0092\u0010\u0012ky\u001e]-ï¼zH\u009e,Ç¸\u0019§\u0010\u0015ÒQGæwÕ\u0011\u00061sí\u0092ówº {Æ^@SÍÃY¸\u000fÆÅ\u0088\u0093cÆ®|\u0080k¨¦\f5\u008eý\u000b(Zi\u009e\u000f\u0010MÚÞ\u009dûÕÊQqG\u0086iòñÄ»\u0010\u000b¥cU\u0085J\u009bÆ\u001c\u0003RÕ}¼ \u0086\u0010BàúµÆ«Å!ò\u0002~N,\u009c\u0006s"
         .length();
      char var14 = ' ';
      int var29 = -1;

      label70:
      while (true) {
         String var30 = var15.substring(++var29, var29 + var14);
         int var10001 = -1;

         while (true) {
            byte[] var19 = var11.doFinal(var30.getBytes("ISO-8859-1"));
            String var41 = a(var19).intern();
            switch (var10001) {
               case 0:
                  var18[var16++] = var41;
                  if ((var29 += var14) >= var17) {
                     q = var18;
                     r = new String[16];
                     v = new HashMap(13);
                     Cipher var0;
                     var10000 = var0 = Cipher.getInstance("DES/CBC/NoPadding");
                     var10002 = SecretKeyFactory.getInstance("DES");
                     var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

                     for (int var1 = 1; var1 < 8; var1++) {
                        var10003[var1] = (byte)(13536763091142L << var1 * 8 >>> 56);
                     }

                     var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
                     long[] var6 = new long[32];
                     String var4 = "\u0001ú\u0016ò¦Er7\u001fy?l\u0092û\\\u0090<\u00126Ìmuî\u001c\u008fp\u000b\u0001\u0012¡\u0017ú\u009f\u0090Î\u0090¨ÎrÈÜ\u001f\u0099d;Þ;Ö\u0016Ö¯\u00008\u00859\u0081-c\nð\\\u0099Ëí¬\u0083âã\u009bËIÞ8á*¦-#Sô:\u0000Ár=\u008d\u0006\u009c\\M\u0097eÐp\u0097j\u0002¸!¾hó\u0006\\U\fî·\bF¶ø\n»Ï\u009aú\u0018ÁL\u0081;©H/Í\u0013ÓÚ\u0016SÝWÕ\u0088ý\fÚË³Z,§1$Ò\t\u009aÐi\u008có\u0095¸\u001fJ\u0084\u0096Áx¼È?1\u0011Öî\u009fïu+\u0015Í#« P$¦2\u009eÆ\u0010ÓLâ¦\u0005àO#\u0090$¤ò`z\u009cMvP\u0017`\u0015\u00ad\u0081\u008d\u0003K\u008eÏ\u009f<Hpu8»bþ¬\u00905\u0015X ½JsýÊj\u0016-\u009e~\u0092ÑÀÌ";
                     int var5 = "\u0001ú\u0016ò¦Er7\u001fy?l\u0092û\\\u0090<\u00126Ìmuî\u001c\u008fp\u000b\u0001\u0012¡\u0017ú\u009f\u0090Î\u0090¨ÎrÈÜ\u001f\u0099d;Þ;Ö\u0016Ö¯\u00008\u00859\u0081-c\nð\\\u0099Ëí¬\u0083âã\u009bËIÞ8á*¦-#Sô:\u0000Ár=\u008d\u0006\u009c\\M\u0097eÐp\u0097j\u0002¸!¾hó\u0006\\U\fî·\bF¶ø\n»Ï\u009aú\u0018ÁL\u0081;©H/Í\u0013ÓÚ\u0016SÝWÕ\u0088ý\fÚË³Z,§1$Ò\t\u009aÐi\u008có\u0095¸\u001fJ\u0084\u0096Áx¼È?1\u0011Öî\u009fïu+\u0015Í#« P$¦2\u009eÆ\u0010ÓLâ¦\u0005àO#\u0090$¤ò`z\u009cMvP\u0017`\u0015\u00ad\u0081\u008d\u0003K\u008eÏ\u009f<Hpu8»bþ¬\u00905\u0015X ½JsýÊj\u0016-\u009e~\u0092ÑÀÌ"
                        .length();
                     label52:
                     while (true) {
                        var10001 = var2;
                        var2 += 8;
                        byte[] var7 = var4.substring(var10001, var2).getBytes("ISO-8859-1");
                        long[] var33 = var6;
                        var10001 = var3++;
                        long var45 = (var7[0] & 255L) << 56
                           | (var7[1] & 255L) << 48
                           | (var7[2] & 255L) << 40
                           | (var7[3] & 255L) << 32
                           | (var7[4] & 255L) << 24
                           | (var7[5] & 255L) << 16
                           | (var7[6] & 255L) << 8
                           | var7[7] & 255L;
                        
                           long var8 = var45;
                           byte[] var10 = var0.doFinal(
                              new byte[]{
                                 (byte)(var8 >>> 56),
                                 (byte)(var8 >>> 48),
                                 (byte)(var8 >>> 40),
                                 (byte)(var8 >>> 32),
                                 (byte)(var8 >>> 24),
                                 (byte)(var8 >>> 16),
                                 (byte)(var8 >>> 8),
                                 (byte)var8
                              }
                           );
                           long var50 = (var10[0] & 255L) << 56
                              | (var10[1] & 255L) << 48
                              | (var10[2] & 255L) << 40
                              | (var10[3] & 255L) << 32
                              | (var10[4] & 255L) << 24
                              | (var10[5] & 255L) << 16
                              | (var10[6] & 255L) << 8
                              | var10[7] & 255L;
                           switch (var48) {
                              case 0:
                                 var33[var10001] = var50;
                                 if (var2 >= var5) {
                                    t = var6;
                                    u = new Integer[32];
                                    a = new int[32][3];

                                    for (var22 < 32; var22++) {
                                       int var23 = (var22 >> 3 & 1) * 85;
                                       int var24 = (var22 >> 2 & 1) * 170 + var23;
                                       int var25 = (var22 >> 1 & 1) * 170 + var23;
                                       int var26 = (var22 & 1) * 170 + var23;
                                       if (var22 == 6) {
                                          var24 += 85;
                                       }

                                       if (var22 >= 16) {
                                          var24 /= 4;
                                          var25 /= 4;
                                          var26 /= 4;
                                       }

                                       a[var22][0] = var24;
                                       a[var22][1] = var25;
                                       a[var22][2] = var26;
                                    }

                                    break;
                                 }
                                 break;
                              default:
                                 var33[var10001] = var50;
                                 if (var2 < var5) {
                                    continue label52;
                                 }

                                 var4 = "3N\u0098¯ôS\u0081_\u0091©ÚT\u0092%\u001fÂ";
                                 var5 = "3N\u0098¯ôS\u0081_\u0091©ÚT\u0092%\u001fÂ".length();
                                 var2 = 0;
                           }

                           int var39 = var2;
                           var2 += 8;
                           var7 = var4.substring(var39, var2).getBytes("ISO-8859-1");
                           var33 = var6;
                           var10001 = var3++;
                           var45 = (var7[0] & 255L) << 56
                              | (var7[1] & 255L) << 48
                              | (var7[2] & 255L) << 40
                              | (var7[3] & 255L) << 32
                              | (var7[4] & 255L) << 24
                              | (var7[5] & 255L) << 16
                              | (var7[6] & 255L) << 8
                              | var7[7] & 255L;
                           var48 = 0;
                        }
                     }
                  }

                  var14 = var15.charAt(var29);
                  break;
               default:
                  var18[var16++] = var41;
                  if ((var29 += var14) < var17) {
                     var14 = var15.charAt(var29);
                     continue label70;
                  }

                  var15 = "7gúù¢\u009c\u0018b\u0018'_\u0005'N¸\u009c\u0010\u0005|Ç+qF9Ë,ê`cÕÛ*ú";
                  var17 = "7gúù¢\u009c\u0018b\u0018'_\u0005'N¸\u009c\u0010\u0005|Ç+qF9Ë,ê`cÕÛ*ú".length();
                  var14 = 16;
                  var29 = -1;
            }

            var30 = var15.substring(++var29, var29 + var14);
            var10001 = 0;
         }
      }
   
      }

      
}

   private static Throwable a(Throwable var0) {
      return var0;
   }

   private static String a(byte[] var0) {
      int var2;
      char[] var3 = new char[var2 = var0.length];

      for (int var4 = 0; var4 < var2; var4++) {
         int var5;
         if ((var5 = 255 & var0[var4]) < 192) {
            var3[var1++] = (char)var5;
         } else if (var5 < 224) {
            char var6 = (char)((char)(var5 & 31) << 6);
            byte var8 = var0[++var4];
            var6 = (char)(var6 | (char)(var8 & 63));
            var3[var1++] = var6;
         } else if (var4 < var2 - 2) {
            char var12 = (char)((char)(var5 & 15) << '\f');
            byte var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63) << 6);
            var9 = var0[++var4];
            var12 = (char)(var12 | (char)(var9 & 63));
            var3[var1++] = var12;
         }
      }

      return new String(var3, 0, var1);
   }

   private static String a(int var0, long var1) {

      int var5 = var0 ^ (int)(var1 & 32767L) ^ 18821;
      if (r[var5] == null) {
         Object[] var4;
         try {
            Long var3 = Thread.currentThread().threadId();
            var4 = (Object[])s.get(var3);
            if (var4 == null) {
               var4 = new Object[]{Cipher.getInstance("DES/CBC/PKCS5Padding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               s.put(var3, var4);
            }
         } catch (Exception var10) {
            throw new RuntimeException("dev/zprestige/prestige/cx", var10);
         }

         byte[] var6 = new byte[8];
         var6[0] = (byte)(var1 >>> 56);

         for (int var7 = 1; var7 < 8; var7++) {
            var6[var7] = (byte)(var1 << var7 * 8 >>> 56);
         }

         DESKeySpec var11 = new DESKeySpec(var6);
         SecretKey var8 = ((SecretKeyFactory)var4[1]).generateSecret(var11);
         ((Cipher)var4[0]).init(2, var8, (IvParameterSpec)var4[2]);
         byte[] var9 = q[var5].getBytes("ISO-8859-1");
         r[var5] = a(((Cipher)var4[0]).doFinal(var9));
      }

      return r[var5];
   
      
}

   private static Object a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      String var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(String.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cx_C0158",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int b(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 942;
      if (u[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = t[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])v.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               v.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/cx", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         u[var3] = var15;
      }

      return u[var3];
   }

   private static int b(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = b(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cx_C0158",
                        "b",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = x[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = w[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 59;
            yield var15;
         }
         case 1 -> {
            byte var16 = 1;
            yield var16;
         }
         case 2 -> {
            byte var17 = 38;
            yield var17;
         }
         case 3 -> {
            byte var18 = 25;
            yield var18;
         }
         case 4 -> {
            byte var19 = 5;
            yield var19;
         }
         case 5 -> {
            byte var20 = 41;
            yield var20;
         }
         case 6 -> {
            byte var21 = 3;
            yield var21;
         }
         case 7 -> {
            byte var22 = 21;
            yield var22;
         }
         case 8 -> {
            byte var23 = 34;
            yield var23;
         }
         case 9 -> {
            byte var24 = 46;
            yield var24;
         }
         case 10 -> {
            byte var25 = 60;
            yield var25;
         }
         case 11 -> {
            byte var26 = 54;
            yield var26;
         }
         case 12 -> {
            byte var27 = 62;
            yield var27;
         }
         case 13 -> {
            byte var28 = 61;
            yield var28;
         }
         case 14 -> {
            byte var29 = 33;
            yield var29;
         }
         case 15 -> {
            byte var30 = 63;
            yield var30;
         }
         case 16 -> {
            byte var31 = 6;
            yield var31;
         }
         case 17 -> {
            byte var32 = 22;
            yield var32;
         }
         case 18 -> {
            byte var33 = 20;
            yield var33;
         }
         case 19 -> {
            byte var34 = 51;
            yield var34;
         }
         case 20 -> {
            byte var35 = 10;
            yield var35;
         }
         case 21 -> {
            byte var36 = 24;
            yield var36;
         }
         case 22 -> {
            byte var37 = 55;
            yield var37;
         }
         case 23 -> {
            byte var38 = 49;
            yield var38;
         }
         case 24 -> {
            byte var39 = 13;
            yield var39;
         }
         case 25 -> {
            byte var40 = 31;
            yield var40;
         }
         case 26 -> {
            byte var41 = 30;
            yield var41;
         }
         case 27 -> {
            byte var42 = 52;
            yield var42;
         }
         case 28 -> {
            byte var43 = 28;
            yield var43;
         }
         case 29 -> {
            byte var44 = 40;
            yield var44;
         }
         case 30 -> {
            byte var45 = 39;
            yield var45;
         }
         case 31 -> {
            byte var46 = 29;
            yield var46;
         }
         case 32 -> {
            byte var47 = 11;
            yield var47;
         }
         case 33 -> {
            byte var48 = 26;
            yield var48;
         }
         case 34 -> {
            byte var49 = 57;
            yield var49;
         }
         case 35 -> {
            byte var50 = 16;
            yield var50;
         }
         case 36 -> {
            byte var51 = 8;
            yield var51;
         }
         case 37 -> {
            byte var52 = 37;
            yield var52;
         }
         case 38 -> {
            byte var53 = 50;
            yield var53;
         }
         case 39 -> {
            byte var54 = 15;
            yield var54;
         }
         case 40 -> {
            byte var55 = 47;
            yield var55;
         }
         case 41 -> {
            byte var56 = 9;
            yield var56;
         }
         case 42 -> {
            byte var57 = 23;
            yield var57;
         }
         case 43 -> {
            byte var58 = 56;
            yield var58;
         }
         case 44 -> {
            byte var59 = 14;
            yield var59;
         }
         case 45 -> {
            byte var60 = 48;
            yield var60;
         }
         case 46 -> {
            byte var61 = 53;
            yield var61;
         }
         case 47 -> {
            byte var62 = 17;
            yield var62;
         }
         case 48 -> {
            byte var63 = 12;
            yield var63;
         }
         case 49 -> {
            byte var64 = 7;
            yield var64;
         }
         case 50 -> {
            byte var65 = 44;
            yield var65;
         }
         case 51 -> {
            byte var66 = 35;
            yield var66;
         }
         case 52 -> {
            byte var67 = 2;
            yield var67;
         }
         case 53 -> {
            byte var68 = 58;
            yield var68;
         }
         case 54 -> {
            byte var69 = 19;
            yield var69;
         }
         case 55 -> {
            byte var70 = 43;
            yield var70;
         }
         case 56 -> {
            byte var71 = 36;
            yield var71;
         }
         case 57 -> {
            byte var72 = 4;
            yield var72;
         }
         case 58 -> {
            byte var73 = 0;
            yield var73;
         }
         case 59 -> {
            byte var74 = 32;
            yield var74;
         }
         case 60 -> {
            byte var75 = 42;
            yield var75;
         }
         case 61 -> {
            byte var76 = 45;
            yield var76;
         }
         case 62 -> {
            byte var77 = 18;
            yield var77;
         }
         default -> 27;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            x[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      w[0] = "1X)4O4'X,n\\#0\u0013/hP7!T8\u007f\u001b\"a";
      w[1] = "\u001d\u0006\u0013yyDh&\u0018vh\u000b\t(\u0013}lQ}";
      w[2] = void.class;
      x[2] = "java/lang/Void";
      w[3] = "nv@t@JxvE.S]o=F(_I~zQ?\u0014YH";
      w[4] = "s\tc\u0016iv\u0006)h\u0019x9g'c\u0012|c\u0013";
      w[5] = float.class;
      x[5] = "java/lang/Float";
      w[6] = "\u000f\u001fx'\u0003Wz?s(\u0012\u0018\u001b1x#\u0016Bo";
      w[7] = "\u0010|*b\\\u001be\\!mMT\u0004R*fI\u000ep";
      w[8] = "X/Sh#\n-\u000fXg2EL\u0001Sl6\u001f8";
      w[9] = "U:\u001c\u0015\\]C:\u0019OOJTq\u001aIC^E6\r^\bLt";
      w[10] = int.class;
      x[10] = "java/lang/Integer";
      w[11] = "\n\u0007?4QI\u007f'4;@\u0006\u001e)?0D\\j";
      w[12] = "\u0019ur\u0011\u0013clUy\u001e\u0002,\r[r\u0015\u0006vy";
      w[13] = "Kd%\u0014+L]d N8[J/#H4O[h4_\u007f_W";
      w[14] = "2bi|k\u000e9mx3\u0011\n*lh|'\u000e=";
      w[15] = "_1 1\u0003~*\u0011+>\u00121K\u001f 5\u0016k?";
      w[16] = "\u001cvuY\u001cqiV~V\r>\bXu]\td|";
      w[17] = "\u00187VQ]\u0018m\u0017]^LW\f\u0019VUH\rx";
      w[18] = "w\u0010IH:1a\u0010L\u0012)&v[O\u0014%2g\u001cX\u0003n#G";
      w[19] = ",}\u0006qn Y]\r~\u007fo8S\u0006u{5L";
      w[20] = "gH\u000f\t1\u0013\u0012h\u0004\u0006 \\sf\u000f\r$\u0006\u0007";
      w[21] = "\u0015\u000bK\rX\u0011\b\u001e\u0013/\u0019\u001c\u0010\u0018";
      w[22] = "bS[jO\u0005\u0017sPe^Jv}[nZ\u0010\u0002";
      w[23] = "\u001e\n!\u001eKHk**\u0011Z\u0007\n$!\u001a^]~";
      w[24] = "K.TyW\u001e].Q#D\tJeR%H\u001d[\"E2\u0003\b\u001a";
      w[25] = "Rk=op%'K6`ajFE=ke02";
      w[26] = "hc;\u0000\u0000\u001avk!Oc\u000er";
      w[27] = ">yH)KX(yMsXO?2NuT[.uYb\u001fK\u001b";
      w[28] = "=\u0004Y\u0001!6H$R\u000e0y)*Y\u00054#]";
      w[29] = "QF4\u0005{{$f?\nj4Eh4\u0001nn1";
      w[30] = "=l\f\b\"d+l\tR1s<'\nT=g-`\u001dCvs\u0018";
      w[31] = "N\u0006\njKU;&\u0001eZ\u001aZ(\nn^@.";
      w[32] = "\u007fu\"/p\u0013a}8`8\u0013{w '1\b;R! =\u0012|{:";
      w[33] = "q%0@\u000f/z*!\u000fn!q!%U";
      w[34] = "t\fh\u00037s\u0001,c\f&<`\"h\u0007\"f\u0014";
      w[35] = "q\u0018\u0002t`\u000e\u00048\t{qAe6\u0002pu\u001b\u0011";
      w[36] = "-\u0016K[ ^;\u0016N\u00013I,]M\u0007?]=\u001aZ\u0010tJ'";
      w[37] = "bCJ2\u0013L\u0017cA=\u0002\u0003vmJ6\u0006Y\u0002";
      w[38] = "H\u001f$\f\u001cuC\u00105CamP\u0017<\nplK\u00126\b@";
      w[39] = "S\u0006zy\u0011xX\tk6l`K\u000eb\u007f";
      w[40] = "6\u001fh'n\u0006C?c(\u007fI\"1h#{\u0013V";
      w[41] = "\u001b1T=\u0005;n\u0011_2\u0014t\u000f\u001fT9\u0010.{";
      w[42] = "\u0013Y\u0004\u0013Q!fy\u000f\u001c@n\u0007w\u0004\u0017D4s";
      w[43] = "!/\u0013qI\u001dT\u000f\u0018~XR5\u0001\u0013u\\\bA";
      w[44] = "c5O4Uq`;\u0017\u0017\u0002kl\u001bK1\u001em";
      w[45] = "7hR\\wTBHYSf\u001b#FRXbAW";
      w[46] = "Aw\u001801\u0014M\u007f\u0019{x\u001cQw\u001b0\u001c\bMv:|<\u001eAl";
      w[47] = "z)L\u001fc0v!MT*8j)O\u001fN,v(d]a2|(U";
      w[48] = "{\u00004o\u000f@\u000e ?`\u001e\u000fo.4k\u001aU\u001b";
      w[49] = "{'n?kS~2e?hTq;n})cXd8";
      w[50] = "\u000f)y\u000b\u0012I\u0011!cDuH\u0000:n\u001eSN";
      w[51] = "5v\u0018\u000f\f\n@V\u0013\u0000\u001dE!X\u0018\u000b\u0019\u001fU";
      w[52] = boolean.class;
      x[52] = "java/lang/Boolean";
      w[53] = "\u0014-1\u001da,\u0014-&Am#\u000ef&_m6\t\u0017t\u0003=t";
      w[54] = "\"U\u0000\u0010F='\u001a?\u001f\u0018!<g\u0002\u0003\r5%";
      w[55] = "Q\bGhg<R\u0006\u001fK0&^+Do/7I";
      w[56] = "\u0006\u0012\u0018\u0003\u0012\n\u0002\u000f\u0018\u0012\u000f\nA\u0000W\u0005\b\u0016\u001b\u000fZX\u0015\r\u001b\u0015\u0018?\u0012\u0017])T\u001c\u0019\u0000\u001b)F\u0013\u0012+\u000e\u0015^;\u001d\u0013";
      w[57] = "|[\u007f\\ItpS~\u0017\u0000|l[|\\dhpZS\u0000\\zf";
      w[58] = "\n~\u0010w>u\u0006v\u0011<w}\u001a~\u0013w\u0013i\u0006\u007f-8+i\fc";
      w[59] = "A-p\u0001|2DbT\u00053?N>";
      w[60] = "G\u001c!\u0006a\u0010B\t*\u0006O\u0012N\b#ZX\u0013A\u00025";
      w[61] = ":3F\u0005,{O\u0013M\n=4.\u001dF\u00019nZ";
      w[62] = "F\u001ex9YS3>s6H\u001cR0x=LF&";
      w[63] = "(\u0002-D-\u001b6\n7\u000b`\u0001,\u0000.Wq\u000b,\u0017uDw\u0001/\n8\u000bB\u001a-\u000e2FQ\u000b$\u0006)@m\r'";
      w[64] = "\u0001'\u0015\t\u0007\u0014\u0017'\u0010S\u0014\u0003\u0000l\u0013U\u0018\u0017\u0011+\u0004BS\u0000\u0013";
      w[65] = "2`>JE,G@5ETc&N>NP9R";
      w[66] = "D@<w#{R@9-0lE\u000b:+<xTL-<wh\u0017";
      w[67] = "+K\u0011&\u001dP^k\u001a)\f\u001f?e\u0011\"\bEK";
      w[68] = "\u0011I\u001b\u001de9di\u0010\u0012tv\u0005g\u001b\u0019p,q";
      w[69] = "\u0007yN\u0010@8rYE\u001fQw\u0013WN\u0014U-g";
      w[70] = "66K.w8=9Za\u001f836I";
      w[71] = "08R\u001c\u0012\u000bE\u0018Y\u0013\u0003D$\u0016R\u0018\u0007\u001eP";
      w[72] = "0x@8&bEXK77-$V@<3wP";
      w[73] = "^w'H\u0015BHw\"\u0012\u0006U_<!\u0014\nAN{6\u0003ATj";
      w[74] = "XD\"\u001fg?-d)\u0010vpLj\"\u001br*8";
      w[75] = "py{dt\ffy~>g\u001bq2}8k\u000f`uj/ \u001bR";
      w[76] = "2)j'(s,!ph`s6+h/ihv\nu\u0005ih+=q#t";
      w[77] = "Id)\u0012\u0006l<D\"\u001d\u0017#]J)\u0016\u0013y)";
      w[78] = "!$G\u001c737$BF$$ oA@(01(VWc$\f";
      w[79] = "=k\u00103\\5HK\u001b<Mz)E\u00107I ]";
      w[80] = "'\u001b;J\n\u000e1\u001b>\u0010\u0019\u0019&P=\u0016\u0015\r7\u0017*\u0001^\u0019\u000b";
      w[81] = "zbH[;[\u000fBCT*\u0014nLH_.N\u001a";
      w[82] = "\u0019xk\u0004.2\u000fxn^=%\u00183mX11\ttzOz!\u0004";
      w[83] = ".0\u0002O#Z%?\u0013\u0000N^%#\u0015MyS6";
      w[84] = "\u0002L\f9\u001dR\u0019\u0019\u00154r[`I\toMY\u0012\u0010\u0004<OK`\u0012V9\u0014]\u0000\t\u0003 \u00192";
      w[85] = "%4\b\u0018I\u0017{fCR\u0016isiE\"O\u000b#\u007f\u0001R[\fa49";
      w[86] = ")\u001b\u001d0\u0001Uo\u0011\u000f2\t.y\u007fLq\u0002\u0012!C\u0003'\rG\u0010E\u0013uSHsD\u0017\"\u0002.)G\u0014rS\u001eo\u001d\u0016\"\u001d.";
      w[87] = "$?Yt9\u000b?*]h]\u0005O~U=b\u0007='Xn`\u0015O,Nb$\b(7[f8l";
      w[88] = "P_N\u000f\u0005\nS[\u0015\u0012o2lby/\"!`xi*&0-CD\u0000\u000b\u001cQ@@[\u0016";
      w[89] = "\u001e\u0012=~zu\u001f\u0016j/\u001c{$Kg~#}V\u0012j-!o$Ik<{,_M`rn\u0016";
      w[90] = "aP#K%E/\fxM\u001c\u0014PW}F#\u0015\"\u000ep\u0015!\u0007PUq\u0004{D+QzJn~";
      w[91] = "Fe]\u0013h8Ga\nB\u000e5|<\u0007\u001310\u000ee\n@3\"|>\u000bQia\u0007:\u0000\u001f|[";
      w[92] = "B=g!^5\u001d70}\\E\u0012\r0}Qz\u0010\u007fip\u0002x\u0002\r0z\f(\u001avgr\u0007~{";
      w[93] = ":IWA\f#~WH\u001d<~-A\\\u0006\\\u001a\u007f\u001aRF\r&0L]\u0013<";
      w[94] = "U\n8\"\u001b4\u001bVc$\"fd\rf/\u001dd\u0016Tk|\u001fvd\rarOn\u001fZiy\u0019\u000f";
      w[95] = "\u0006Q\u0018vZ]EU\txfF\u0019\u001d\r\u0016\u0000BK\u0016If\u0014E\t]q";
      w[96] = "2\b\u0005yNJd\u0001Sp\f.bf\u0004\"@\u0011`\u0014]/\u0013\u0013rf\u0004 \u001b@2\u001fQ\"\u0011M6f";
      w[97] = "\u001d@^xsA\u001cJ_:\u001d\u0013r\u001eF1\"\u0011\u0000GKb \u0003rF\u0018o~\u0019C\u001e\u0014c&z";
      w[98] = "\u0010c9\u0011y\u001f^?b\u0017@J!dg\u001c\u007fOS=jO}]!d`A-EZ3hJ{$";
      w[99] = ":%EX\u001bUty\u001e^\"\u001e\u000b\"\u001bU\u001d\u0005y{\u0016\u0006\u001f\u0017\u000b\"\u001c\bO\u000fpu\u0014\u0003\u0019n";
      w[100] = "}\u0011\u000bxy:f\u0004\u000fd\u001d0\u0016P\u00071\"6d\t\nb $\u0016P\u0000lp<m\u0007\bg&]";
      w[101] = "-L\u001e\u001b8Lc\u0010E\u001d\u0001\u001e\u001cK@\u0016>\u001cn\u0012ME<\u000e\u001cILTfMgMG\u001asw";
      w[102] = "UJ8G\u0015\u007fEZ#\u0018mvGO\u0001\u0003/bMU\u000f\u0012\u000ftAOH\u0007Q#OX.\b\u000bb\u00123";
      w[103] = "*\u0000Uc\u0010\u0006+\u0004\u00022v\t\u0010Y\u000fcI\u000eb\u0000\u00020K\u001c\u0010[\u0003!\u0011_k_\bo\u0004e";
      w[104] = "\u0013eo\r9~W{pQ\t&\u0012FnNu6i23Q7wYtiSg9i";
      w[105] = "\u0018\u0015X!\u0006\u0005VI\u0003'?^)\u0012\u0006,\u0000U[K\u000b\u007f\u0002G)\u0012\u0001qR_RE\tz\u0004>";
      w[106] = "\u0013t\u0004\u0000[,Wj\u001b\\kx\u0010g\t_\u0010\u0015\u000fx_@Se\u001b\u007f\u001d\u000bk,Q}^\u000b[j\u000b\u007f\u000eEk";
      w[107] = "T\u0016\u0005bE_\u0012NQ S!\nV\f2X!\u0010M\u000b;H]\u0013IP&\"\u0018WI]8\\^\u000f\u001d\u001f.\"";
      w[108] = "\u0003\u0006>\u0002D\tG\u0018!^t[\u001e\u00047a\u0013Q\u001f\u0014\u0013Et\u000fD\tf\bH@\u0012\u000639K\r\u0018Tk\u0005\u0004[\u0017\u0001Z";
      w[109] = "woj\u0014r\t>)9U!d6).d.Y/hcXa\u000f =R\u0002s[5l\"\u0016t\u0019~T4\u0006.\u001fv$ \u0001lTN";
      w[110] = "#vm'\bt'ki\"\u000b\u0005s};s\by\u001ap2!\u000b=jd5c@\u0005|toeHuhs-.p<~{=\u007f\u000bkvpk\u001e";
      w[111] = "\u000f-\u007f\u0011\u00044\u0011#&\u001fo<\u000e:)G\u0003U\f, \u001a_lH2?Fo,\u0019ytJ\u000e2\u0017 z!";
      w[112] = "3K/SCt6^\"\u001eF\faO!\u0018ikwI4b\u001d1k\u0013y^RgdFH]\u001fm6\u001et\u0012Ibc/";
      w[113] = "]]\u0019b\u0001oMM\u0002=yfOX &7mEM\u0015]BfPCS&Fm\u001eVi";
      w[114] = "\u0004J~\rW(\u000b\u0010?P<!\u0016\n\r\u0013~5\u001c\u0010\u0003\u0002^#\u0010\nD\u0012R*@F}VL5\u001cv;T\u0006+\u0010\u00104\u000eGv{";
      w[115] = "G0f\u0019\u0006eF41H`g}i<\u0019_m\u000f01J]\u007f}k0[\u0007<\u0006o;\u0015\u0012\u0006";
      w[116] = "\u000eR0b\u001elWD5yHRIP,a\u001c\u0015Y9ss\u00035\rBwxM 7\u0000#d\u000f=\tY5a\u0014k7";
      w[117] = "\u0011Fr\\8>\u0010B%\r^2+\u001f(\\a6YF%\u000fc$+\u001d$\u001e9gP\u0019/P,]";
      w[118] = "B\r_;$\u0011VL\u000f1\u001e\b_J\u0005$\u001e\u0007E\r\u001amn\u0013BOQUx\u0003\u0018IY%l\u0004Z\u0002a";
      w[119] = "DK\u0015\"kF\u001cO\u00145r9\u0016\f\b9nT7\u0007\u0019=XD\u0013\u0018\b*\u0012\u0006@\u0017Ya.I\u0016\u0018\fP+\u0003\u0018K\u0002.m[L\t\u0014P";
      w[120] = "b2k)L(y'o5($\tsg`\u0017${*j3\u00156\ts`=E.r$h6\u0013O";
      w[121] = "\u0015tA2\u001cC\u0014p\u0016czI/-\u001b2EK]t\u0016aGY/+EcF\u0011\u0013d\u0013l\u0013 ";
      w[122] = "\u0019=j\"\tNWa1$0\u0010(:4/\u000f\u001eZc9|\r\f(:3r]\u0014Sm;y\u000bu";
      w[123] = "p\u000f>\r+Fp\b>N7|(On\b9\u0000.I\u0003\u0000l\u0015)\u000f~Ch\u0004'3";
      w[124] = "\u001d\u0004\u0015\u0001\u0015\u0016\u001cO\u00160\u001cqBV^\u000f\u001d\u0003\u001b[\r\r\u000fqBQ\u0003]\u0017\n\u0015Y\b\u000bv";
      w[125] = "\u0017\\\u0017\u0014)\u0007H\u0004\u0002Wx?G5BJt\u0000EG\u001bG'\u0002W5B@(\u0002C\r\u001d\u0018=A\u00125";
      w[126] = "t\u0004\u001c{\u00138u\u0000K*u2N]F{J0<\u0004K(H\"N^ErE=-_A%\u0014[";
      w[127] = "D=\u000f5\b[C,K7q\bzb\f.MSF-Z!\u0018b";
      w[128] = "M)VO\"v\u0003u\rI\u001b!|.\bB$&\u000ew\u0005\u0011&4|,\u0004\u0000|w\u0007(\u000fNiM";
      w[129] = "v\r;\u0004\u001bOm\u0018?\u0018\u007fD\u001dL7M@Co\u0015:\u001eBQ\u001dL0\u0010\u0012If\u001b8\u001bD(";
      w[130] = "@hafK_\u000e4:`r\u000bqo?kM\u000f\u0003628O\u001dqm3)\u0015^\ni8g\u0000d";
      w[131] = "\u0013?\u0005wN4\u001ceD*%=\u0001\u007f?hK6W3\u0006,U)\u000b\u0003@kUm\u0014eP{N2l";
      w[132] = "mUw\u001fmPjD3\u001d\u0014\u0002S\nt\u0004(XoE\"\u000b}i";
      w[133] = "+6Sf%\u00050#WzA\b@w_/~\t2.R||\u001b@wXr,\u0003; Pyzb";
      w[134] = "{M{z\u000by&_:1uk&Z\u001d|\rz0[=z\u0018nJ\u0007=<\u000e|1Z/}E\u0002sR+l\u0014y$Z :u";
      w[135] = "a D\u001cyOz5@\u0000\u001dCn?P\b\u001d\u0011n5F\u0004fFf>\u0010e";
      w[136] = "( t1wpi){`\u0013'=\u0015z}~,\u00021|w~)Yr&l/ye=pczHfpz1\"t)&ud\u0013q= vlh&5+ \r";
      w[137] = "w, \u0003>?ly9\u000eQ6\u0015)%Un4gp(\u0006l&\u0015+)\u00176en/\"Y#_";
      w[138] = "e\u0014\u0007X#W=\u0018\u000b\u0000@\tiUi]\"Y\u007f\u0011\u0019I%\u001b4)\u000fY\u007f\u001d<Y\u001b^=V\u0004";
      w[139] = "wBZ=\u0019\u00019\u001e\u0001; TFE\u00040\u001fQ4\u001c\tc\u001dCFG\brG\u0000=C\u0003<R:";
      w[140] = "t\f08\u0013$+T%{B\u001c$eefN#&\u0017<k\u001d!4ee?F{?\u001c<|\u0015e6e";
      w[141] = "B8>\"y8\u0001</,E%Y\u007f\u0011/590=o%{u\u0000{5'+;0";
      w[142] = "'W*Iu\u0019o\u001f/Jtgu\nrKug'\nx]y\u001cp\u0002s\u000b\u0018";
      w[143] = "?\f1O_%!\u0002hA48!8v\u0005U\")cp\u0011P\u007fvZ4\u000fO#F";
      w[144] = "e2>\u000eC\u00063;h\u0007\u0001b5\\?UM]7.fX\u001e_%\\?T\u0007\u0002b#y\f\u0001\u0004c\\";
      w[145] = "\u007f: G9\f1f{A\u0000^N=~J?\\<ds\u0019=NN|-Kn\u0007qm}\u001f17";
      w[146] = "\u0013~xW\rI[6}T\f7O*;N\u0007[}{|\u0016Q7\u0013}\u007fI\u0012NJ>,W\u001b7\u0013~xW\rI[6}T\f7";
      w[147] = "Ts'C#OUwp\u0012EFn*}CzG\u001csp\u0010xUn(q\u0001\"\u0016\u0015,zO7,";
      w[148] = "\u0001QG\u001f\\\t\u0000U\u0010N:\u0001;\b\u001d\u001f\u0005\u0001IQ\u0010L\u0007\u0013;\n\u0011]]P@\u000e\u001a\u0013Hj";
      w[149] = "%NJs\u001fmc\u0016\u001e1\t\u0013d\tS\u000f\u001eo\u001cK\u0012/D\" \u0004D \u0011\u0013%NJs\u001fmc\u0016\u001e1\t\u0013";
      w[150] = "e%]\u0001\u0011,#}\tC\u0007R2{YDvkfz\u0005[\b->.GMv";
      w[151] = "]\u0011&Wz*\u0014Wu\u0016)G\u000bGb'&z\u0005\u0016/\u001bi,\nC\u001eA{x\u001f\u0012nU|:T*";
      w[152] = "-YqA\u0013Pt\u001a\"_\u001a)\u007f\u0007.]\f)-\u0007$K\u0000Rz\u000f/\u001da";
      w[153] = "\u00042<\u0010*\u0006R;j\u0019hbW\\=K$]V.dFw_D\\=Gq\u001bR zNv\bG\\";
      w[154] = "L\u0010<f\u001a]\u0004X9e\u001b#\u0010D\u007f\u007f\u0010O\"\u00158'H#J\u0014b#F\u001f\u0005Bmvw";
      w[155] = "8U\u001cN\u001487\u000f]\u0013\u007f1*\u0015oP=% \u000foQ\u000576i\\E\u001bewP\u0018[\u00049GP\u001a\u0016\u0000%}P\u001d\u0016C9G";
      w[156] = "\nmf`y\u001aB%ccxdV9%ys\bdhb#/d\fi8%%XC?7p\u0014";
      w[157] = "z1:,&Fj!!s^Oh4\u0003h\u0005\\\u007f),|^Zk,q#g\u001eu3-\u0013";
      w[158] = "y,S'<rq}\u000focB8yD$`\u0018-yR2wBy-\u00040vz){\u0002`}B?iN`u$/yU?\r";
      w[159] = "FyK\u0007\u0017aViPXohT|rC.aE\u0000\u0004\u0005\u000e;\b<KS\u0001n9";
      w[160] = "-\u0012\u0015bi\u0010eZ\u0010ahnqFV{c\u0002C\u0015\u0013*8V\u0014\u0014\u0017z8_([Aumn+\u0016K'5Rd@Dr\u0004Q)J\u0016*8\u001e\u007fEC\u001b";
      w[161] = "\u000f\u0015_5fUV\u0003Z.0kX\u001a@\"u5_\u001aZ&\tPY\f@qrTRBUK";
      w[162] = "\u0002j#Avb\u0019?:L\u0019h`o&\u0017&i\u00126+D${`m*U~8\u001bi!\u001bk\u0002";
      w[163] = "|g\u0007k!>2;\\m\u0018lM`Yf'n?9T5%|M=Q1fk&+B2 \u0005";
      w[164] = "<\u0017]F?i=\u0013\n\u0017Yj\u0006N\u0007Ffat\u0017\n\u0015ds\u0006L\u000b\u0004>0}H\u0000J+\n";
      w[165] = "\u0011{<JO(_'gLvu |bGIxR%o\u0014Kj |e\u001a\u001br[+m\u0011M\u0013";
      w[166] = ".1_\u0019[k`m\u0004\u001fb9\u001f>\u0019\u0019\u0019.dc\u000bXRP.t__\u001c+sf\u001e\u0014b";
      w[167] = "\u000e\u001cM&\u0006p\u0018\u001d\u0015=;/\r^,\u0014q@_\u001f\u0017g\n|\u0010I\u00182;";
      w[168] = "\u0019o*0\u000f'\u0007as>d/\u0018x|f\b\r\u0007l|X\u0003'\u0006|\u0011?Y'\\1-p\u000f(\t\u0000ho_v\u000bava\u0006x`";
      w[169] = "$\u0005ydQv|\tu<2?8D\u0017aPx>\u0000guW:u8qe\r<}HebOwE^u8I\u007f5Jrz\u0002G";
      w[170] = "p,Y\u0004e-q(\u000eU\u0003'Ju\u0003\u0004<%8,\u000eW>7Jw\u000fFdt1s\u0004\bqN";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = w[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(x[var4]);
            w[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = w[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = x[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            w[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  w[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(2390089647759200L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = w[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = x[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  w[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(2390089647759200L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        w[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(2390089647759200L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 230;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 186;
            char var25 = var8;
            if (var25 != var26) {
               byte var28 = 68;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 106;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     byte var38 = 120;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     short var40 = 202;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 230;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 186;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               byte var36 = 68;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite c(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/cx_C0158",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/cx" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static Function invokeBinding1() {
         MethodHandle var4 = bindingCache1;
         MethodHandle var3 = bindingCache1;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache1 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cx_C0158",
                     "lambda$new$0",
                     "(Ldev/zprestige/prestige/cx_C0158;)Ldev/zprestige/prestige/f4;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/cx_C0158;)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         try {
            return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static int invokeBinding2(int var0, long var1) {
         MethodHandle var7 = bindingCache2;
         MethodHandle var6 = bindingCache2;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache2 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         try {
            return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static Map invokeBinding3(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache3;
         MethodHandle var8 = bindingCache3;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache3 = c(MethodHandles.lookup(), "Ê", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/util/Map;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         try {
            return (Map)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static Function invokeBinding4() {
         MethodHandle var4 = bindingCache4;
         MethodHandle var3 = bindingCache4;
         MethodHandle var1 = var3;
         if (var4 == null) {
            var1 = bindingCache4 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "apply",
                  SourceSupport.methodType("()Ljava/util/function/Function;", MethodHandles.lookup()),
                  SourceSupport.methodType("(Ljava/lang/Object;)Ljava/lang/Object;", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cx_C0158",
                     "lambda$new$0",
                     "(Ldev/zprestige/prestige/cx_C0158;)Ldev/zprestige/prestige/f4;"
                  ),
                  SourceSupport.methodType("(Ldev/zprestige/prestige/cx_C0158;)Ldev/zprestige/prestige/f4;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Function)var1.invokeExact();
      } catch (Throwable var5) {
         throw SourceSupport.rethrow(var5);
      }
   }

   private static void invokeBinding5(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache5;
         MethodHandle var9 = bindingCache5;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache5 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding6(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache6;
         MethodHandle var9 = bindingCache6;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache6 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding7(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache7;
         MethodHandle var8 = bindingCache7;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache7 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding8(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache8;
         MethodHandle var9 = bindingCache8;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache8 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Object invokeBinding9(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache9;
         MethodHandle var9 = bindingCache9;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache9 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ljava/lang/Object;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Object)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static RenderBatchKey invokeBinding10(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache10;
         MethodHandle var9 = bindingCache10;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache10 = c(
                  MethodHandles.lookup(),
                  "x",
                  SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)Ldev/zprestige/prestige/gA_C0325;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (RenderBatchKey)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding11(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache11;
         MethodHandle var9 = bindingCache11;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache11 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlyphVisitor invokeBinding12(MsdfFont var0, float[] var1, RenderCommandBatcher var2, RenderBatchKey var3, float var4, float var5, float var6, int var7) {
         MethodHandle var12 = bindingCache12;
         MethodHandle var11 = bindingCache12;
         MethodHandle var9 = var11;
         if (var12 == null) {
            var9 = bindingCache12 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/cx_C0158;[FLdev/zprestige/prestige/f4;Ldev/zprestige/prestige/gA_C0325;FFFI)Ldev/zprestige/prestige/cy_C0160;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/cx_C0158",
                     "lambda$render$1",
                     "([FLdev/zprestige/prestige/f4;Ldev/zprestige/prestige/gA_C0325;FFFIILdev/zprestige/prestige/cB_C0113;)Z"
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlyphVisitor)var9.invokeExact((MsdfFont)var0, (float[])var1, (RenderCommandBatcher)var2, (RenderBatchKey)var3, (float)var4, (float)var5, (float)var6, (int)var7);
      } catch (Throwable var13) {
         throw SourceSupport.rethrow(var13);
      }
   }

   private static void invokeBinding13(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache13;
         MethodHandle var9 = bindingCache13;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache13 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding14(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache14;
         MethodHandle var9 = bindingCache14;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache14 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlyphVisitor invokeBinding15(MsdfFont var0, float[] var1, RenderCommandBatcher var2, RenderBatchKey var3, Matrix4f var4, float var5, float var6, float var7, int var8) {
         MethodHandle var13 = bindingCache15;
         MethodHandle var12 = bindingCache15;
         MethodHandle var10 = var12;
         if (var13 == null) {
            var10 = bindingCache15 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType(
                     "(Ldev/zprestige/prestige/cx_C0158;[FLdev/zprestige/prestige/f4;Ldev/zprestige/prestige/gA_C0325;Lorg/joml/Matrix4f;FFFI)Ldev/zprestige/prestige/cy_C0160;",
                     MethodHandles.lookup()
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     5,
                     "dev/zprestige/prestige/cx_C0158",
                     "lambda$render$2",
                     "([FLdev/zprestige/prestige/f4;Ldev/zprestige/prestige/gA_C0325;Lorg/joml/Matrix4f;FFFIILdev/zprestige/prestige/cB_C0113;)Z"
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlyphVisitor)var10.invokeExact((MsdfFont)var0, (float[])var1, (RenderCommandBatcher)var2, (RenderBatchKey)var3, (Matrix4f)var4, (float)var5, (float)var6, (float)var7, (int)var8);
      } catch (Throwable var14) {
         throw SourceSupport.rethrow(var14);
      }
   }

   private static float invokeBinding16(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache16;
         MethodHandle var9 = bindingCache16;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache16 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding17(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache17;
         MethodHandle var9 = bindingCache17;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache17 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding18(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache18;
         MethodHandle var9 = bindingCache18;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache18 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding19(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache19;
         MethodHandle var9 = bindingCache19;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache19 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding20(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache20;
         MethodHandle var9 = bindingCache20;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache20 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding21(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache21;
         MethodHandle var9 = bindingCache21;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache21 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static float invokeBinding22(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache22;
         MethodHandle var9 = bindingCache22;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache22 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding23(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache23;
         MethodHandle var9 = bindingCache23;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache23 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding24(int var0, long var1) {
         MethodHandle var7 = bindingCache24;
         MethodHandle var6 = bindingCache24;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache24 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding25(int var0, long var1) {
         MethodHandle var7 = bindingCache25;
         MethodHandle var6 = bindingCache25;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache25 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding26(int var0, long var1) {
         MethodHandle var7 = bindingCache26;
         MethodHandle var6 = bindingCache26;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache26 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding27(int var0, long var1) {
         MethodHandle var7 = bindingCache27;
         MethodHandle var6 = bindingCache27;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache27 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static int invokeBinding28(int var0, long var1) {
         MethodHandle var7 = bindingCache28;
         MethodHandle var6 = bindingCache28;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache28 = b(MethodHandles.lookup(), "g", SourceSupport.methodType("(IJ)I", MethodHandles.lookup())).dynamicInvoker();
         }

         return (int)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static void invokeBinding29(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache29;
         MethodHandle var9 = bindingCache29;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache29 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding30(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache30;
         MethodHandle var9 = bindingCache30;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache30 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding31(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache31;
         MethodHandle var9 = bindingCache31;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache31 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding32(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache32;
         MethodHandle var9 = bindingCache32;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache32 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static void invokeBinding33(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache33;
         MethodHandle var9 = bindingCache33;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache33 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding34(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache34;
         MethodHandle var8 = bindingCache34;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache34 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding35(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache35;
         MethodHandle var9 = bindingCache35;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache35 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding36(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache36;
         MethodHandle var8 = bindingCache36;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache36 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding37(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache37;
         MethodHandle var9 = bindingCache37;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache37 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding38(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache38;
         MethodHandle var8 = bindingCache38;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache38 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding39(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache39;
         MethodHandle var9 = bindingCache39;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache39 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static int invokeBinding40(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache40;
         MethodHandle var8 = bindingCache40;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache40 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)I", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (int)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding41(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache41;
         MethodHandle var9 = bindingCache41;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache41 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlyphVisitor invokeBinding42(float[] var0) {
         MethodHandle var5 = bindingCache42;
         MethodHandle var4 = bindingCache42;
         MethodHandle var2 = var4;
         if (var5 == null) {
            var2 = bindingCache42 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("([F)Ldev/zprestige/prestige/cy_C0160;", MethodHandles.lookup()),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(), 6, "dev/zprestige/prestige/cx_C0158", "lambda$getWidth$3", "([FILdev/zprestige/prestige/cB_C0113;)Z"
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlyphVisitor)var2.invokeExact((float[])var0);
      } catch (Throwable var6) {
         throw SourceSupport.rethrow(var6);
      }
   }

   private static float invokeBinding43(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache43;
         MethodHandle var9 = bindingCache43;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache43 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static Throwable invokeBinding44(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache44;
         MethodHandle var8 = bindingCache44;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache44 = c(
                  MethodHandles.lookup(), "Ê", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/Throwable;", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (Throwable)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static String invokeBinding45(int var0, long var1) {
         MethodHandle var7 = bindingCache45;
         MethodHandle var6 = bindingCache45;
         MethodHandle var4 = var6;
         if (var7 == null) {
            var4 = bindingCache45 = a(MethodHandles.lookup(), "f", SourceSupport.methodType("(IJ)Ljava/lang/String;", MethodHandles.lookup())).dynamicInvoker();
         }

         return (String)var4.invokeExact((int)var0, (long)var1);
      } catch (Throwable var8) {
         throw SourceSupport.rethrow(var8);
      }
   }

   private static float invokeBinding46(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache46;
         MethodHandle var9 = bindingCache46;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache46 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)F", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (float)var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static GlyphVisitor invokeBinding47(float var0, float[] var1, float var2, float var3, StringBuilder var4) {
         MethodHandle var9 = bindingCache47;
         MethodHandle var8 = bindingCache47;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache47 = LambdaMetafactory.metafactory(
                  MethodHandles.lookup(),
                  "a",
                  SourceSupport.methodType("(F[FFFLjava/lang/StringBuilder;)Ldev/zprestige/prestige/cy_C0160;", MethodHandles.lookup()),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup()),
                  SourceSupport.handle(
                     MethodHandles.lookup(),
                     6,
                     "dev/zprestige/prestige/cx_C0158",
                     "lambda$truncate$4",
                     "(F[FFFLjava/lang/StringBuilder;ILdev/zprestige/prestige/cB_C0113;)Z"
                  ),
                  SourceSupport.methodType("(ILdev/zprestige/prestige/cB_C0113;)Z", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         return (GlyphVisitor)var6.invokeExact((float)var0, (float[])var1, (float)var2, (float)var3, (StringBuilder)var4);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }

   private static void invokeBinding48(Object var0, Object var1, long var2, long var4) {
         MethodHandle var10 = bindingCache48;
         MethodHandle var9 = bindingCache48;
         MethodHandle var7 = var9;
         if (var10 == null) {
            var7 = bindingCache48 = c(
                  MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;Ljava/lang/Object;JJ)V", MethodHandles.lookup())
               )
               .dynamicInvoker();
         }

         var7.invokeExact((Object)var0, (Object)var1, (long)var2, (long)var4);
      } catch (Throwable var11) {
         throw SourceSupport.rethrow(var11);
      }
   }

   private static String invokeBinding49(Object var0, long var1, long var3) {
         MethodHandle var9 = bindingCache49;
         MethodHandle var8 = bindingCache49;
         MethodHandle var6 = var8;
         if (var9 == null) {
            var6 = bindingCache49 = c(MethodHandles.lookup(), "x", SourceSupport.methodType("(Ljava/lang/Object;JJ)Ljava/lang/String;", MethodHandles.lookup()))
               .dynamicInvoker();
         }

         return (String)var6.invokeExact((Object)var0, (long)var1, (long)var3);
      } catch (Throwable var10) {
         throw SourceSupport.rethrow(var10);
      }
   }
}
