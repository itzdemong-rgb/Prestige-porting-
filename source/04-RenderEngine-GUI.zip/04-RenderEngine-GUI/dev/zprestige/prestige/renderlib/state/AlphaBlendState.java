package dev.zprestige.prestige.renderlib.state;
import dev.zprestige.prestige.renderlib.RenderState;


import dev.prestige.recovery.SourceSupport;
import dev.zprestige.prestige.api.eventbus.Event;
import dev.zprestige.prestige.renderlib.RenderPass;
import java.lang.invoke.CallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.invoke.MutableCallSite;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;

public record AlphaBlendState(boolean bN, boolean bO) implements RenderState {
   private static final long b = 21159200807843L;
   private static final long[] c;
   private static final Integer[] d;
   private static final Map e = new HashMap(13);
   private static final Object[] f = new Object[14];
   private static final String[] g = new String[14];

   @Override
   public void a(RenderPass var1) {
      int var4 = Event.bReturningInt();
      int var17 = var4;
      byte var16 = ((byte)((this.bN) ? 1 : 0));
      short var15 = var16;
      byte var14 = var16;
      if (var17 == 0) {
         byte var18 = var14;
         if (var18 != 0) {
            GL11.glEnable(3042);
            short var10000 = 16515;
            long var10001 = 2963401536975167305L;
            GL14.glBlendFuncSeparate(770, 771, 1, 771);
            int var19 = var4;
            if (var19 == 0) {
               return;
            }
         }

         short var20 = 3042;
         var15 = var20;
      }

      short var13 = var15;
      GL11.glDisable(var13);
   }

   @Override
   public void aReturningVoid() {
      int var3 = Event.cReturningInt();
      int var16 = var3;
      byte var15 = ((byte)((this.bO) ? 1 : 0));
      byte var12 = var15;
      byte var11 = var15;
      if (var16 != 0) {
         byte var18 = ((byte)((this.bN) ? 1 : 0));
         byte var17 = var11;
         if (var17 == var18) {
            return;
         }

         byte var19 = ((byte)((this.bO) ? 1 : 0));
         var12 = var19;
      }

      int var21 = var3;
      byte var20 = var12;
      short var14 = var20;
      byte var13 = var20;
      if (var21 != 0) {
         byte var22 = var13;
         if (var22 != 0) {
            GL11.glEnable(3042);
            int var23 = var3;
            if (var23 != 0) {
               return;
            }
         }

         short var24 = 3042;
         var14 = var24;
      }

      short var10 = var14;
      GL11.glDisable(var10);
   }

   static {

      {

      b();
      Cipher var2;
      Cipher var10000 = var2 = Cipher.getInstance("DES/CBC/NoPadding");
      SecretKeyFactory var10002 = SecretKeyFactory.getInstance("DES");
      byte[] var10003 = new byte[]{(byte)0L, 0, 0, 0, 0, 0, 0, 0};

      for (int var3 = 1; var3 < 8; var3++) {
         var10003[var3] = (byte)(6845034040880L << var3 * 8 >>> 56);
      }

      var10000.init(2, var10002.generateSecret(new DESKeySpec(var10003)), new IvParameterSpec(new byte[8]));
      long[] var8 = new long[5];
      String var6 = "\u000f©LÐJp2ÉoB\u00048þ\u0010:l6\r^i\u0099ð\u0003¾";
      int var7 = "\u000f©LÐJp2ÉoB\u00048þ\u0010:l6\r^i\u0099ð\u0003¾".length();
      label23:
      while (true) {
         int var10001 = var4;
         var4 += 8;
         byte[] var9 = var6.substring(var10001, var4).getBytes("ISO-8859-1");
         long[] var14 = var8;
         var10001 = var5++;
         long var17 = (var9[0] & 255L) << 56
            | (var9[1] & 255L) << 48
            | (var9[2] & 255L) << 40
            | (var9[3] & 255L) << 32
            | (var9[4] & 255L) << 24
            | (var9[5] & 255L) << 16
            | (var9[6] & 255L) << 8
            | var9[7] & 255L;
         
            long var10 = var17;
            byte[] var12 = var2.doFinal(
               new byte[]{
                  (byte)(var10 >>> 56),
                  (byte)(var10 >>> 48),
                  (byte)(var10 >>> 40),
                  (byte)(var10 >>> 32),
                  (byte)(var10 >>> 24),
                  (byte)(var10 >>> 16),
                  (byte)(var10 >>> 8),
                  (byte)var10
               }
            );
            long var21 = (var12[0] & 255L) << 56
               | (var12[1] & 255L) << 48
               | (var12[2] & 255L) << 40
               | (var12[3] & 255L) << 32
               | (var12[4] & 255L) << 24
               | (var12[5] & 255L) << 16
               | (var12[6] & 255L) << 8
               | var12[7] & 255L;
            switch (var19) {
               case 0:
                  var14[var10001] = var21;
                  if (var4 >= var7) {
                     c = var8;
                     d = new Integer[5];
                     break;
                  }
                  break;
               default:
                  var14[var10001] = var21;
                  if (var4 < var7) {
                     continue label23;
                  }

                  var6 = "qÒ\u009c\u009e@c~Fþ\u0005\u009d.U!ú@";
                  var7 = "qÒ\u009c\u009e@c~Fþ\u0005\u009d.U!ú@".length();
                  var4 = 0;
            }

            int var16 = var4;
            var4 += 8;
            var9 = var6.substring(var16, var4).getBytes("ISO-8859-1");
            var14 = var8;
            var10001 = var5++;
            var17 = (var9[0] & 255L) << 56
               | (var9[1] & 255L) << 48
               | (var9[2] & 255L) << 40
               | (var9[3] & 255L) << 32
               | (var9[4] & 255L) << 24
               | (var9[5] & 255L) << 16
               | (var9[6] & 255L) << 8
               | var9[7] & 255L;
            var19 = 0;
         }
      }
   
      }

      
}

   private static MatchException a(MatchException var0) {
      return var0;
   }

   private static int a(int var0, long var1) {
      int var3 = var0 ^ (int)(var1 & 32767L) ^ 8142;
      if (d[var3] == null) {
         byte[] var4 = new byte[]{
            (byte)(var1 >>> 56),
            (byte)(var1 >>> 48),
            (byte)(var1 >>> 40),
            (byte)(var1 >>> 32),
            (byte)(var1 >>> 24),
            (byte)(var1 >>> 16),
            (byte)(var1 >>> 8),
            (byte)var1
         };
         long var5 = c[var3];
         byte[] var7 = new byte[]{
            (byte)(var5 >>> 56),
            (byte)(var5 >>> 48),
            (byte)(var5 >>> 40),
            (byte)(var5 >>> 32),
            (byte)(var5 >>> 24),
            (byte)(var5 >>> 16),
            (byte)(var5 >>> 8),
            (byte)var5
         };
         Long var8 = Thread.currentThread().threadId();
         Object[] var9 = (Object[])e.get(var8);

         byte[] var10;
         try {
            if (var9 == null) {
               var9 = new Object[]{Cipher.getInstance("DES/CBC/NoPadding"), SecretKeyFactory.getInstance("DES"), new IvParameterSpec(new byte[8])};
               e.put(var8, var9);
            }

            DESKeySpec var11 = new DESKeySpec(var4);
            SecretKey var12 = ((SecretKeyFactory)var9[1]).generateSecret(var11);
            Cipher var13 = (Cipher)var9[0];
            var13.init(2, var12, (IvParameterSpec)var9[2]);
            var10 = var13.doFinal(var7);
         } catch (Exception var14) {
            throw new RuntimeException("dev/zprestige/prestige/gI", var14);
         }

         int var15 = (var10[4] & 255) << 24 | (var10[5] & 255) << 16 | (var10[6] & 255) << 8 | var10[7] & 255;
         d[var3] = var15;
      }

      return d[var3];
   }

   private static int a(Lookup var0, MutableCallSite var1, String var2, Object[] var3) {
      int var4 = (Integer)var3[0];
      long var5 = (Long)var3[1];
      int var7 = a(var4, var5);
      MethodHandle var8 = MethodHandles.constant(int.class, var7);
      var1.setTarget(MethodHandles.dropArguments(var8, 0, int.class, long.class));
      return var7;
   }

   private static CallSite a(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gI_C0341",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;[Ljava/lang/Object;)I"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gI" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }

   private static int a(long var0, long var2) {
      var0 ^= var2 << 48 | var2;
      int var4 = (int)(var0 >>> 46);
      String var12 = g[var4];
      if (var12 != null) {
         return var4;
      }

      Object var5 = f[var4];
      boolean var13 = var5 instanceof String;
      if (!var13) {
         return var4;
      }

      int var14 = (int)(var0 >>> 42 & 63L);

      byte var6 = switch (var14) {
         case 0 -> {
            byte var15 = 18;
            yield var15;
         }
         case 1 -> {
            byte var16 = 46;
            yield var16;
         }
         case 2 -> {
            byte var17 = 24;
            yield var17;
         }
         case 3 -> {
            byte var18 = 7;
            yield var18;
         }
         case 4 -> {
            byte var19 = 31;
            yield var19;
         }
         case 5 -> {
            byte var20 = 53;
            yield var20;
         }
         case 6 -> {
            byte var21 = 33;
            yield var21;
         }
         case 7 -> {
            byte var22 = 1;
            yield var22;
         }
         case 8 -> {
            byte var23 = 27;
            yield var23;
         }
         case 9 -> {
            byte var24 = 17;
            yield var24;
         }
         case 10 -> {
            byte var25 = 26;
            yield var25;
         }
         case 11 -> {
            byte var26 = 58;
            yield var26;
         }
         case 12 -> {
            byte var27 = 40;
            yield var27;
         }
         case 13 -> {
            byte var28 = 36;
            yield var28;
         }
         case 14 -> {
            byte var29 = 9;
            yield var29;
         }
         case 15 -> {
            byte var30 = 19;
            yield var30;
         }
         case 16 -> {
            byte var31 = 48;
            yield var31;
         }
         case 17 -> {
            byte var32 = 4;
            yield var32;
         }
         case 18 -> {
            byte var33 = 23;
            yield var33;
         }
         case 19 -> {
            byte var34 = 2;
            yield var34;
         }
         case 20 -> {
            byte var35 = 47;
            yield var35;
         }
         case 21 -> {
            byte var36 = 51;
            yield var36;
         }
         case 22 -> {
            byte var37 = 62;
            yield var37;
         }
         case 23 -> {
            byte var38 = 56;
            yield var38;
         }
         case 24 -> {
            byte var39 = 49;
            yield var39;
         }
         case 25 -> {
            byte var40 = 35;
            yield var40;
         }
         case 26 -> {
            byte var41 = 28;
            yield var41;
         }
         case 27 -> {
            byte var42 = 50;
            yield var42;
         }
         case 28 -> {
            byte var43 = 32;
            yield var43;
         }
         case 29 -> {
            byte var44 = 37;
            yield var44;
         }
         case 30 -> {
            byte var45 = 39;
            yield var45;
         }
         case 31 -> {
            byte var46 = 5;
            yield var46;
         }
         case 32 -> {
            byte var47 = 55;
            yield var47;
         }
         case 33 -> {
            byte var48 = 21;
            yield var48;
         }
         case 34 -> {
            byte var49 = 45;
            yield var49;
         }
         case 35 -> {
            byte var50 = 61;
            yield var50;
         }
         case 36 -> {
            byte var51 = 30;
            yield var51;
         }
         case 37 -> {
            byte var52 = 14;
            yield var52;
         }
         case 38 -> {
            byte var53 = 29;
            yield var53;
         }
         case 39 -> {
            byte var54 = 57;
            yield var54;
         }
         case 40 -> {
            byte var55 = 22;
            yield var55;
         }
         case 41 -> {
            byte var56 = 10;
            yield var56;
         }
         case 42 -> {
            byte var57 = 34;
            yield var57;
         }
         case 43 -> {
            byte var58 = 3;
            yield var58;
         }
         case 44 -> {
            byte var59 = 59;
            yield var59;
         }
         case 45 -> {
            byte var60 = 54;
            yield var60;
         }
         case 46 -> {
            byte var61 = 42;
            yield var61;
         }
         case 47 -> {
            byte var62 = 20;
            yield var62;
         }
         case 48 -> {
            byte var63 = 11;
            yield var63;
         }
         case 49 -> {
            byte var64 = 13;
            yield var64;
         }
         case 50 -> {
            byte var65 = 8;
            yield var65;
         }
         case 51 -> {
            byte var66 = 63;
            yield var66;
         }
         case 52 -> {
            byte var67 = 52;
            yield var67;
         }
         case 53 -> {
            byte var68 = 6;
            yield var68;
         }
         case 54 -> {
            byte var69 = 15;
            yield var69;
         }
         case 55 -> {
            byte var70 = 38;
            yield var70;
         }
         case 56 -> {
            byte var71 = 12;
            yield var71;
         }
         case 57 -> {
            byte var72 = 44;
            yield var72;
         }
         case 58 -> {
            byte var73 = 0;
            yield var73;
         }
         case 59 -> {
            byte var74 = 16;
            yield var74;
         }
         case 60 -> {
            byte var75 = 60;
            yield var75;
         }
         case 61 -> {
            byte var76 = 43;
            yield var76;
         }
         case 62 -> {
            byte var77 = 41;
            yield var77;
         }
         default -> 25;
      };
      int[] var7 = new int[6];
      while (true) {
         byte var80 = 6;
         int var79 = var8;
         if (var79 >= var80) {
            char[] var85 = ((String)var5).toCharArray();
            while (true) {
               int var83 = var85.length;
               int var82 = var86;
               if (var82 >= var83) {
                  break;
               }

               int var88 = var7[var86 % var7.length];
               int var81 = var88;
               if (var81 == 0) {
                  break;
               }

               var85[var86] = (char)(var85[var86] ^ var88);
               var86++;
            }

            g[var4] = new String(var85);
            return var4;
         }

         int var9 = 7 * (5 - var8);
         int var10 = (int)(var0 >>> var9 & 127L);
         var10 -= var6;
         int var78 = var10;
         if (var78 < 0) {
            var10 += 128;
         }

         var7[var8] = var10;
         var8++;
      }
   }

   private static void b() {
      f[0] = "i[\u0001<]\u0017\u007f[\u0004fN\u0000h\u0010\u0007`B\u0014yW\u0010w\t\u0006H";
      f[1] = int.class;
      g[1] = "java/lang/Integer";
      f[2] = "\b\\q{\u001f7\u001e\\t!\f \t\u0017w'\u00004\u0018P`0K %";
      f[3] = "d{zd\u0012Dotk+qIzyd@DKkjxlSF";
      f[4] = "g+3A%!b>8A&&m73\u0003g\u0011Dhe";
      f[5] = void.class;
      g[5] = "java/lang/Void";
      f[6] = ".]m)k@+Hf)hG$Amk)p\r\u001e>";
      f[7] = "O+b\u000e)\u0018D$sAH\u0016O/w\u001b";
      f[8] = "' UK]fj#V\u000f1o\u007f\u0012N\u001fWlU%L\u0019jmc1P\u001bMm\u001b&R\u0018\u0000auf\u001b\u00101~c2\u001b\u0013_>*:*\fIj*9DL\u0000b\u001b&R\u0018\u0000auf\u001b\u00101;x\"S\u0018\u000fzg(Kr";
      f[9] = "\u001a:\u007f\u000b\t[\u0001 9v\u001f?\u000f3iG\u0014QOzav";
      f[10] = "\u0002yC\u0003\t\u0000GtO\u00068\u0002; \u0012\\_\u0019\u0003p\u0000_\u0000k\u0001z\u0011XJSQh\u0012\u00078";
      f[11] = "m=,g}\u007fj 'f\u001cp3\u000bqhv{:Fiyv.6()0~\u001fl%mxv!-:g`\u001c";
      f[12] = "V@\f8\f\u0015MZJE\u001bqCI\u001at\u0011\u001f\u0003\u0000\u0012E";
      f[13] = "{Ir_eg|Ty^\u0004h%~(Bmm%_IG|mpS'\u00075eA\t*C}m\u007fH5Ie\u0007";
   }

   private static Class b(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var6 = f[var4];
      Object var8 = var6;

      try {
         boolean var10 = var8 instanceof String;
         if (var10) {
            Class var5 = dev.prestige.recovery.RecoveryNames.forName(g[var4]);
            f[var4] = var5;
            return var5;
         }
      } catch (Exception var11) {
         throw new RuntimeException(var11.toString());
      }

      return (Class)var6;
   }

   private static Field a(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field[] var3 = var0.getDeclaredFields();
      int var4 = var3.length;
      while (true) {
         int var8 = var4;
         int var7 = var5;
         if (var7 >= var8) {
            return null;
         }

         Field var6 = var3[var5];
         boolean var9 = var6.getName().equals(var1);
         if (var9) {
            Class var10000 = var6.getType();
            Class var11 = var2;
            Class var10 = var10000;
            if (var10 == var11) {
               return var6;
            }
         }

         var5++;
      }
   }

   private static Field b(Class var0, String var1, Class var2) {
      var1=dev.prestige.recovery.RecoveryNames.fieldName(var1);

      Field var3 = a(var0, var1, var2);
      Field var6 = var3;
      if (var6 != null) {
         return var3;
      }

      Class[] var4 = var0.getInterfaces();
      Class[] var7 = var4;
      if (var7 != null) {
         while (true) {
            int var9 = var4.length;
            int var8 = var5;
            if (var8 >= var9) {
               break;
            }

            var3 = b(var4[var5], var1, var2);
            Field var10 = var3;
            if (var10 != null) {
               return var3;
            }

            var5++;
         }
      }

      return null;
   }

   private static Field c(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var16 = var5 instanceof String;
      if (!var16) {
         return (Field)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      Class var11 = b(Long.parseLong(var6.substring(++var9), 36), 0L);
      Class var12 = var8;

      while (true) {
         Field var13 = a(var12, var10, var11);
         Field var17 = var13;
         if (var17 != null) {
            f[var4] = var13;
            return var13;
         }

         Class[] var14 = var12.getInterfaces();
         Class[] var18 = var14;
         if (var18 != null) {
            while (true) {
               int var20 = var14.length;
               int var19 = var15;
               if (var19 >= var20) {
                  break;
               }

               var13 = b(var14[var15], var10, var11);
               Field var21 = var13;
               if (var21 != null) {
                  f[var4] = var13;
                  return var13;
               }

               var15++;
            }
         }

         boolean var22 = var12.getName().equals("java.lang.Object");
         if (var22) {
            StringBuffer var27 = new StringBuffer();
            var27.append("NoSuchFieldException in ").append(var8.getName()).append(' ').append(var11.getName()).append(' ').append(var10);
            throw new RuntimeException(var27.toString());
         }

         var12 = var12.getSuperclass();
         Class var23 = var12;
         if (var23 == null) {
            var12 = b(509213913359155L, 0L);
         }
      }
   }

   private static Method a(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method[] var5 = var0.getDeclaredMethods();
      int var6 = var5.length;
      while (true) {
         int var12 = var6;
         int var11 = var7;
         if (var11 >= var12) {
            return null;
         }

         Method var8 = var5[var7];
         boolean var13 = var8.getName().equals(var1);
         if (var13) {
            Class var10000 = var8.getReturnType();
            Class var15 = var2;
            Class var14 = var10000;
            if (var14 == var15) {
               Class[] var9 = var8.getParameterTypes();
               int var22 = var9.length;
               int var17 = var3;
               int var16 = var22;
               if (var16 == var17) {
                  while (true) {
                     int var19 = var3;
                     int var18 = var10;
                     if (var18 >= var19) {
                        return var8;
                     }

                     var10000 = var9[var10];
                     Class var21 = var4[var10];
                     Class var20 = var10000;
                     if (var20 != var21) {
                        break;
                     }

                     var10++;
                  }
               }
            }
         }

         var7++;
      }
   }

   private static Method b(Class var0, String var1, Class var2, int var3, Class[] var4) {
      var1=dev.prestige.recovery.RecoveryNames.methodName(var0,var1,var2,var4);

      Method var5 = a(var0, var1, var2, var3, var4);
      Method var8 = var5;
      if (var8 != null) {
         return var5;
      }

      Class[] var6 = var0.getInterfaces();
      Class[] var9 = var6;
      if (var9 != null) {
         while (true) {
            int var11 = var6.length;
            int var10 = var7;
            if (var10 >= var11) {
               break;
            }

            var5 = b(var6[var7], var1, var2, var3, var4);
            Method var12 = var5;
            if (var12 != null) {
               return var5;
            }

            var7++;
         }
      }

      return null;
   }

   private static Method d(long var0, long var2) {
      int var4 = a(var0, var2);
      Object var5 = f[var4];
      boolean var20 = var5 instanceof String;
      if (!var20) {
         return (Method)var5;
      }

      String var6 = g[var4];
      int var7 = var6.indexOf(8);
      Class var8 = b(Long.parseLong(var6.substring(0, var7), 36), 0L);
      int var9 = var6.indexOf(8, ++var7);
      String var10 = var6.substring(var7, var9);
      int var11 = -1;
      int var12 = var9;

      int var21;
      byte var22;
      do {
         var11++;
         int var10000 = var12 = var6.indexOf(8, ++var12);
         var22 = -1;
         var21 = var10000;
      } while (var21 > var22);

      int var13;
      Class[] var14 = new Class[var13 = var11 - 1];
      Class var15 = null;
      var12 = var9 + 1;
      while (true) {
         int var24 = var11;
         int var23 = var16;
         if (var23 >= var24) {
            Class var43 = var8;

            while (true) {
               Method var45 = a(var43, var10, var15, var13, var14);
               Method var27 = var45;
               if (var27 != null) {
                  f[var4] = var45;
                  return var45;
               }

               boolean var28 = var43.getName().equals("java.lang.Object");
               if (var28) {
                  break;
               }

               Class var29 = var43 = var43.getSuperclass();
               if (var29 == null) {
                  b(509213913359155L, 0L);
                  break;
               }
            }

            Class var44 = var8;

            while (true) {
               Class[] var46;
               Class[] var30 = var46 = var44.getInterfaces();
               if (var30 != null) {
                  while (true) {
                     int var32 = var46.length;
                     int var31 = var18;
                     if (var31 >= var32) {
                        break;
                     }

                     Method var19 = b(var46[var18], var10, var15, var13, var14);
                     Method var33 = var19;
                     if (var33 != null) {
                        f[var4] = var19;
                        return var19;
                     }

                     var18++;
                  }
               }

               boolean var34 = var44.getName().equals("java.lang.Object");
               if (var34) {
                  StringBuffer var47 = new StringBuffer();
                  var47.append("NoSuchMethodException in ").append(var8.getName()).append(' ').append(var15.getName()).append(' ').append(var10).append('(');
                  while (true) {
                     int var37 = var13;
                     int var36 = var48;
                     if (var36 >= var37) {
                        var47.append(')');
                        throw new RuntimeException(var47.toString());
                     }

                     var47.append(var14[var48].getName());
                     var48++;
                     int var39 = var13;
                     int var38 = var48;
                     if (var38 < var39) {
                        var47.append(", ");
                     }
                  }
               }

               Class var35 = var44 = var44.getSuperclass();
               if (var35 == null) {
                  var44 = b(509213913359155L, 0L);
               }
            }
         }

         int var17 = var6.indexOf(8, var12);
         var15 = b(Long.parseLong(var6.substring(var12, var17), 36), 0L);
         int var26 = var13;
         int var25 = var16;
         if (var25 < var26) {
            var14[var16] = var15;
         }

         var12 = var17 + 1;
         var16++;
      }
   }

   private static MethodHandle a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, long var4, long var6) {
      char var8 = var2.charAt(0);
      Field var10 = null;
      Method var11 = null;

      try {
         short var24 = 201;
         char var23 = var8;
         if (var23 != var24) {
            short var26 = 253;
            char var25 = var8;
            if (var25 != var26) {
               short var28 = 218;
               char var27 = var8;
               if (var27 != var28) {
                  byte var30 = 67;
                  char var29 = var8;
                  if (var29 != var30) {
                     var11 = d(var4, var6);
                     Class var50 = var11.getDeclaringClass();
                     String var52 = var11.getName();
                     MethodType var53 = MethodType.methodType(var11.getReturnType(), var11.getParameterTypes());
                     short var38 = 216;
                     char var37 = var8;
                     if (var37 == var38) {
                        MethodHandle var54 = var0.findVirtual(var50, var52, var53);
                        return MethodHandles.dropArguments(var54, var3.parameterCount() - 2, long.class, long.class);
                     }

                     byte var40 = 82;
                     char var39 = var8;
                     MethodHandle var55;
                     if (var39 == var40) {
                        var55 = var0.findStatic(var50, var52, var53);
                     } else {
                        var55 = var0.findSpecial(var50, var52, var53, var50);
                     }

                     return MethodHandles.dropArguments(var55, var3.parameterCount() - 2, long.class, long.class);
                  }
               }
            }
         }

         var10 = c(var4, var6);
         Class var12 = var10.getDeclaringClass();
         String var51 = var10.getName();
         Class var14 = var10.getType();
         short var32 = 201;
         char var31 = var8;
         MethodHandle var9;
         if (var31 == var32) {
            var9 = var0.findGetter(var12, var51, var14);
         } else {
            short var34 = 253;
            char var33 = var8;
            if (var33 == var34) {
               var9 = var0.findSetter(var12, var51, var14);
            } else {
               short var36 = 218;
               char var35 = var8;
               if (var35 == var36) {
                  var9 = var0.findStaticGetter(var12, var51, var14);
               } else {
                  var9 = var0.findStaticSetter(var12, var51, var14);
               }
            }
         }

         return MethodHandles.dropArguments(var9, var3.parameterCount() - 2, long.class, long.class);
      } catch (Exception var49) {
         StringBuilder var13 = new StringBuilder();
         StringBuilder var10000 = var13.append(var49.getClass().getName()).append(" : ");
         Field var42 = var10;
         StringBuilder var41 = var10000;
         StringBuilder var18 = var41;
         StringBuilder var17 = var41;
         StringBuilder var21;
         String var22;
         if (var42 != null) {
            String var44 = var10.toString();
            StringBuilder var43 = var17;
            var21 = var43;
            var22 = var44;
         } else {
            Method var46 = var11;
            StringBuilder var45 = var18;
            StringBuilder var20 = var45;
            StringBuilder var19 = var45;
            if (var46 != null) {
               String var48 = var11.toString();
               StringBuilder var47 = var19;
               var21 = var47;
               var22 = var48;
            } else {
               var22 = " null ";
               var21 = var20;
            }
         }

         var21.append(var22).append(" : ").append(var49.toString());
         throw new RuntimeException(var13.toString());
      }
   }

   private static Object a(Lookup var0, MutableCallSite var1, String var2, MethodType var3, Object[] var4) {

      int var5 = var4.length - 2;
      long var6 = (Long)var4[var5];
      long var9 = (Long)var4[++var5];
      MethodHandle var8 = a(var0, var1, var2, var3, var6, var9);
      var1.setTarget(MethodHandles.explicitCastArguments(var8, var3));
      return (Object)var8.asSpreader(Object[].class, var4.length).invoke(var4);
   
      
}

   private static CallSite b(Lookup var0, String var1, MethodType var2) {
      MutableCallSite var3 = new MutableCallSite(var2);

      try {
         var3.setTarget(
            MethodHandles.explicitCastArguments(
               MethodHandles.insertArguments(
                  SourceSupport.handle(
                        MethodHandles.lookup(),
                        6,
                        "dev/zprestige/prestige/gI_C0341",
                        "a",
                        "(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/invoke/MutableCallSite;Ljava/lang/String;Ljava/lang/invoke/MethodType;[Ljava/lang/Object;)Ljava/lang/Object;"
                     )
                     .asCollector(Object[].class, var2.parameterCount()),
                  0,
                  var0,
                  var3,
                  var1,
                  var2
               ),
               var2
            )
         );
         return var3;
      } catch (Exception var6) {
         throw new RuntimeException("dev/zprestige/prestige/gI" + " : " + var1 + " : " + var2.toString(), var6);
      }
   }
}
